package com.reactive.spring.reactivewebflux;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.reactive.spring.reactivewebflux.client.ReactiveWebfluxWebClient;

@SpringBootApplication
public class ReactiveWebfluxApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReactiveWebfluxApplication.class, args);
		ReactiveWebfluxWebClient gwc = new ReactiveWebfluxWebClient();
	    System.out.println(gwc.getResult());
	}

}
