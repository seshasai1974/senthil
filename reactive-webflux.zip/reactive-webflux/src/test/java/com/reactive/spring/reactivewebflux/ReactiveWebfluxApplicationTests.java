package com.reactive.spring.reactivewebflux;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReactiveWebfluxApplicationTests {

	@Test
	void contextLoads() {
	}

}
