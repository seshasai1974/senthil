package com.dre.spring.batch.account.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/*
 * localhost
 */

@RestController
@RequestMapping("/run")
public class HelloWorldController {
	
	@GetMapping("/accountbatch")
	public String runBatch() {
		
		
		return "This is My Hello World Batch added project depemdecies";
	}

}
