package com.springboot.exceptionhandling.springbootexceptionhandling.controller;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.exceptionhandling.springbootexceptionhandling.exception.ProductNotfoundException;
import com.springboot.exceptionhandling.springbootexceptionhandling.model.Product;

@RestController
public class ProductServiceController {
   private static Map<String, Product> productRepo = new HashMap<>();
   static {
      Product mercedesbenz = new Product();
      mercedesbenz.setId("1");
      mercedesbenz.setName("Mercedes Benz");
      productRepo.put(mercedesbenz.getId(), mercedesbenz);
      
      Product porsche = new Product();
      porsche.setId("2");
      porsche.setName("Porsche");
      productRepo.put(porsche.getId(), porsche);
   }
   
  
   
   @GetMapping("/test")
   public String testmethod() {
	   return " Application Running well " ;
   }
   
   @GetMapping("/exception/{id}")
   public String testmethod1(@PathVariable("id") String id) {
	   if(!productRepo.containsKey(id))throw new ProductNotfoundException();
	   else {
		   Product p = productRepo.get(id);
		   return p.getName();
	   }
   }
}