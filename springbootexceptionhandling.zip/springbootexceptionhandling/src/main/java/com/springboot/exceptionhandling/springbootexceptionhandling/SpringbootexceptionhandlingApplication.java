package com.springboot.exceptionhandling.springbootexceptionhandling;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootexceptionhandlingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootexceptionhandlingApplication.class, args);
	}

}
