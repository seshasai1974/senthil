
DELIMITER ;

DROP FUNCTION IF EXISTS EscapeDoubleQuotes;

DELIMITER //

CREATE FUNCTION EscapeDoubleQuotes(string varchar(500), delim varchar(10)) RETURNS varchar(500)
    DETERMINISTIC
BEGIN
        IF string IS NULL THEN
                SET string = '';
        ELSEIF LOCATE("\"", string) > 0 THEN
                SET string = REPLACE(string, "\"", "\"\"");
                SET string = CONCAT("\"", string, "\"");
        ELSEIF delim IS NOT NULL AND LOCATE(delim, string) > 0 THEN
                SET string = CONCAT("\"", string, "\"");
        END IF;

        RETURN string;
END
//

DELIMITER ;

DROP FUNCTION IF EXISTS GetSearchAddress;

DELIMITER //

CREATE FUNCTION GetSearchAddress (in_mbr_id bigint(20), in_address_hierarchy varchar(64), in_cnty_nm varchar(30), in_zip_cd_txt varchar(10)) RETURNS VARCHAR(500)
DETERMINISTIC
  BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE i INT DEFAULT 999;
    DECLARE j INT DEFAULT 999;
    DECLARE hierarchy_list VARCHAR(64);
    DECLARE address VARCHAR(500) DEFAULT '';
    DECLARE address_delim VARCHAR(10) DEFAULT "\,";
    -- cursor variables
    DECLARE adr_typ_id_1 VARCHAR(2);
    DECLARE adr_ln_1_txt_1 VARCHAR(55);
    DECLARE adr_ln_2_txt_1 VARCHAR(55);
    DECLARE cty_nm_1 VARCHAR(30);
    DECLARE st_cd_1 VARCHAR(2);
    DECLARE zip_cd_txt_1 VARCHAR(10);
    DECLARE zip_sufx_cd_txt_1 VARCHAR(4);
    DECLARE cntry_cd_1 VARCHAR(3);
    DECLARE cnty_nm_1 VARCHAR(25);
    DECLARE adr_ln_3_txt_1 VARCHAR(100);
    DECLARE adr_ln_5_txt_1 VARCHAR(100);
    -- flag to determine if hierarchy should be checked
    DECLARE check_address INT DEFAULT FALSE;
    -- cursor and handler
    DECLARE address_cur CURSOR FOR SELECT adr_typ_id, adr_ln_1_txt, adr_ln_2_txt, cty_nm, st_cd, zip_cd_txt, zip_sufx_cd_txt, cntry_cd, cnty_nm, adr_ln_3_txt, adr_ln_5_txt FROM mbr_adr WHERE mbr_id = in_mbr_id;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    -- change address hierarchy list from #,#,# to *#*#*#*  e.g. 3,5,7,2 to *3*5*7*2*
    SET hierarchy_list = CONCAT('*', REPLACE(in_address_hierarchy, ',', '*'), '*');

    OPEN address_cur;

    read_loop: LOOP
      -- cursor handling
      FETCH address_cur INTO adr_typ_id_1, adr_ln_1_txt_1, adr_ln_2_txt_1, cty_nm_1, st_cd_1, zip_cd_txt_1, zip_sufx_cd_txt_1, cntry_cd_1, cnty_nm_1, adr_ln_3_txt_1, adr_ln_5_txt_1;
      IF done THEN
        LEAVE read_loop;
      END IF;

      SET check_address = FALSE;

      IF (in_cnty_nm IS NULL OR in_cnty_nm = '') AND (in_zip_cd_txt IS NULL OR in_zip_cd_txt = '') THEN
        -- no county or zip in search critiera - most common
        SET check_address = TRUE;
      ELSEIF in_cnty_nm IS NOT NULL AND in_cnty_nm != '' AND in_zip_cd_txt IS NOT NULL AND in_zip_cd_txt != '' THEN
        -- county and zip in search criteria
        IF INSTR(cnty_nm_1, in_cnty_nm) > 0 AND INSTR(zip_cd_txt_1, in_zip_cd_txt) > 0 THEN
          SET check_address = TRUE;
        END IF;
      ELSEIF in_cnty_nm IS NOT NULL AND in_cnty_nm != '' THEN
        -- county only in search criteria
        IF INSTR(cnty_nm_1, in_cnty_nm) > 0 THEN
          SET check_address = TRUE;
        END IF;
      ELSEIF in_zip_cd_txt IS NOT NULL AND in_zip_cd_txt != '' THEN
        -- zip only in search criteria
        IF INSTR(zip_cd_txt_1, in_zip_cd_txt) > 0 THEN
          SET check_address = TRUE;
        END IF;
      END IF;

      IF check_address THEN
        -- check for location of address type in hierarchy list, e.g.  *7* in *3*5*7*2*
        SET j = LOCATE(CONCAT('*', adr_typ_id_1, '*'), hierarchy_list);
        IF j > 0 AND j < i THEN
          -- address type in hierarchy and before previous address identified
          SET address = CONCAT(adr_typ_id_1, address_delim, EscapeDoubleQuotes(adr_ln_1_txt_1, address_delim), address_delim, EscapeDoubleQuotes(adr_ln_2_txt_1, address_delim), address_delim, EscapeDoubleQuotes(cty_nm_1, address_delim), address_delim, IFNULL(st_cd_1,''), address_delim, EscapeDoubleQuotes(zip_cd_txt_1, address_delim), address_delim, EscapeDoubleQuotes(zip_sufx_cd_txt_1, address_delim), address_delim, IFNULL(cntry_cd_1,''), address_delim, EscapeDoubleQuotes(cnty_nm_1, address_delim), address_delim, EscapeDoubleQuotes(adr_ln_3_txt_1, address_delim), address_delim, EscapeDoubleQuotes(adr_ln_5_txt_1, address_delim));
          SET i = j;
        END IF;
      END IF;
    END LOOP;

    RETURN address;

    CLOSE address_cur;
END
//

DELIMITER ;

DROP FUNCTION if exists getreferencedescription;

DELIMITER //

create function getreferencedescription (name varchar(32), code varchar(10)) returns varchar(300)
  DETERMINISTIC
begin
  DECLARE description varchar(300);
  select ref_desc
  into description
  from ref
  where ref_nm = name
  and ref_cd = code;
  return (description);
end
//

DELIMITER ;

DROP FUNCTION IF EXISTS GetHostName;

DELIMITER //

CREATE FUNCTION GetHostName () RETURNS VARCHAR(64)
DETERMINISTIC
  BEGIN
    DECLARE local_hostname VARCHAR(64);

    SELECT variable_value INTO local_hostname
    FROM information_schema.global_variables
    WHERE variable_name = 'hostname';

    RETURN local_hostname;
  END
//

DELIMITER ;
