-- Complex Views (identified by the "Virtual" flag in Tables table). "Complex" = needing outer joins, unions, inner select / temp data, etc.
-- Comments must be prefixed with "--"
CREATE OR REPLACE VIEW memberworklistview
            AS
            SELECT
                mwl.mbr_id                           AS memberID,
                ifnull(mi.mbr_id_txt, null)           AS memberIDText,
                ifnull(mi.mbr_id_typ_id, null)        AS memberIDType,
                mwl.mbr_full_nm                      AS memberFullName,
                mwl.rsk_tier                         AS riskTier,
                mwl.asgn_id                          AS assignmentID,
                mwl.stb_clr                          AS stabilityColourCode,
                mwl.creat_dttm                       AS createDateTime,
                mwl.asgn_prr_typ_id                  AS assignmentPriorityType,
                mwl.asgn_due_dt                      AS assignmentDueDate,
                mwl.asgn_typ_id                      AS assignmentType,
                mwl.asgn_sts_typ_id                  AS assignmentStatusType,
                mwl.chg_dttm                         AS changeDateTime,
                mwl.asgn_hilght_typ_id               AS assignmentHighlightType,
                mwl.asgn_to_user_id                  AS assignedToUserID,
                mwl.asgn_to_wrk_que_id               AS assignedToWorkQueueID,
                r.ref_desc                           AS assignmentTypeRefDesc,
                m.fst_nm                             AS memberFirstName,
                m.lst_nm                             AS memberLastName,
                m.midl_nm                            AS middleName
            FROM
                mbr_wrk_list mwl
                LEFT JOIN (SELECT mbr_id, MIN(mbr_id_typ_id) as mbr_id_typ_id, mbr_id_txt FROM mbr_id GROUP BY mbr_id) mi ON mi.mbr_id = mwl.mbr_id
                LEFT JOIN mbr m ON m.mbr_id = mwl.mbr_id
                LEFT JOIN ref r ON r.ref_cd = mwl.asgn_typ_id AND r.ref_nm = 'taskType';

CREATE OR REPLACE VIEW
       assignmentView AS
   SELECT DISTINCT
       a.asgn_id   AS assignmentID,
       a.mbr_id    AS memberID,
       a.asgn_prr_typ_id AS assignmentPriorityType,
       r1.ref_desc AS assignmentDescriptorRefDesc,
       r2.ref_desc AS assignmentStatusTypeRefDesc,
       r3.ref_desc AS assignmentTypeRefDesc,
       a.asgn_to_user_id AS assignedToUserId,
       a.init_creat_dttm AS initialCreateDateTime,
       a.asgn_due_dt AS assignmentDueDate,
       w.wrk_que_nm_txt as assignedToWorkQueueName,
       CASE
       WHEN (a.asgn_to_user_id IS NOT NULL AND a.asgn_to_user_id != '')
       THEN a.asgn_to_user_id
       ELSE w.wrk_que_nm_txt
       END                            AS assignedToDisplay,
       CASE
       WHEN (n.assignmentNoteCount > 0)
       THEN TRUE
       ELSE FALSE
       END                            AS hasAssignmentNote,
       n.assignmentNoteCount          AS assignmentNoteCount
   FROM
       asgn a
       LEFT OUTER JOIN ref r1 ON r1.ref_cd = a.asgn_desc_typ_id AND r1.ref_nm = 'taskDescriptorType'
       LEFT OUTER JOIN ref r2 ON r2.ref_cd = a.asgn_sts_typ_id AND r2.ref_nm = 'assignmentStatusType'
       LEFT OUTER JOIN ref r3 ON r3.ref_cd = a.asgn_typ_id AND r3.ref_nm = 'taskType'
       LEFT OUTER JOIN wrk_que w ON w.wrk_que_id = a.asgn_to_wrk_que_id
       LEFT OUTER JOIN(SELECT asgn_id, note_txt_lobj, COUNT(*) AS assignmentNoteCount FROM note group by asgn_id) n ON n.asgn_id = a.asgn_id;

CREATE OR REPLACE VIEW
memberclinicalconditionview
AS SELECT
M.mbr_id AS memberID,
M.prob_seq_nbr AS problemSequenceNumber,
M.strt_dt AS startDate,
M.end_dt AS endDate,
C.snomed_cncpt_id AS snomedConceptID,
PL.snomed_fully_spec_nm AS snomedFullySpecifiedName,
C.othr_clin_cond_txt AS otherClinicalCondText
FROM
mbr_clin_cond C LEFT JOIN snomed_subset_core_prob_list PL ON(C.snomed_cncpt_id = PL.snomed_cncpt_id)
INNER JOIN mbr_prob M ON (C.prob_seq_nbr = M.prob_seq_nbr)
AND C.mbr_id = M.mbr_id;

CREATE OR REPLACE VIEW
    memberclinicalmedicationview AS
SELECT
    a.mbr_id     AS memberID,
    a.othr_medcn_txt AS otherMedicationText,
    a.dose_txt  AS doseText,
    r1.ref_desc  AS medicationAdminRouteTypeRefDesc,
    r2.ref_desc  AS medicationFrequencyTypeRefDesc,
    a.strt_dt    AS startDate,
    a.end_dt     AS endDate,
    a.medcn_seq_nbr AS medicationSequenceNumber,
    a.medcn_admin_rte_typ_id AS medicationAdminRouteType,
    a.medcn_freq_typ_id AS medicationFrequencyType
FROM
    mbr_medcn a
    LEFT OUTER JOIN ref r1 ON r1.ref_cd = a.medcn_admin_rte_typ_id AND r1.ref_nm = 'medicationAdminRouteType'
    LEFT OUTER JOIN ref r2 ON r2.ref_cd = a.medcn_freq_typ_id AND r2.ref_nm = 'medicationFrequencyType';

CREATE OR REPLACE VIEW
    activityview AS
SELECT
    a.actv_id             AS activityID,
    r1.ref_desc           AS activityTypeRefDesc,
    r2.ref_desc           AS actvResolutionOutcomeRefDesc,
    r3.ref_desc           AS contactRoleTypeRefDesc,
    r4.ref_desc           AS noteTypeRefDesc,
    a.actv_strt_dttm      AS activityStartDatetime,
    n.note_txt_lobj       AS noteTextLargeObject,
    a.mbr_id              AS memberID,
    a.actv_typ_id         AS activityType,
    a.rslv_otcome_typ_id  AS activityResolutionOutcomeType,
    a.cntc_role_typ_id    AS contactRoleType,
    n.note_typ_id         AS noteType,
    r5.ref_desc           AS actvResolutionRsnTypeRefDesc
FROM
    actv a LEFT OUTER JOIN note n ON n.actv_id = a.actv_id
    LEFT OUTER JOIN ref r1 ON r1.ref_cd = a.actv_typ_id and r1.ref_nm = 'activityType'
    LEFT OUTER JOIN ref r2 ON r2.ref_cd = a.rslv_otcome_typ_id and r2.ref_nm = 'activityResolutionOutcomeType'
    LEFT OUTER JOIN ref r3 ON r3.ref_cd = a.cntc_role_typ_id and r3.ref_nm = 'contactRoleType'
    LEFT OUTER JOIN ref r4 ON r4.ref_cd = n.note_typ_id and r4.ref_nm = 'noteType'
    LEFT OUTER JOIN ref r5 on r5.ref_cd = a.rslv_rsn_typ_id and r5.ref_nm = 'activityResolutionReasonType';

CREATE OR REPLACE VIEW
        activityhistoryview AS
    SELECT
        a.actv_id             AS activityID,
        a.cmnct_trans_id      AS communicationTransactionID,
        a.mbr_id              AS memberID,
        a.actv_typ_id         AS activityType,
        a.rslv_otcome_typ_id  AS activityResolutionOutcomeType,
        a.rslv_rsn_typ_id     AS activityResolutionReasonType,
        a.asgn_desc_typ_id    AS assignmentDescriptorType,
        a.cntc_role_typ_id    AS contactRoleType,
        c.cntc_nm             AS contactName,
        a.actv_strt_dttm      AS activityStartDateTime,
        c.cmnct_dttm          AS communicationDateTime,
        a.creat_dttm          AS createDateTime,
        a.chg_dttm            AS changeDateTime,
        a.creat_user_id       AS createUserID,
        a.chg_user_id         AS changeUserID,
        c.cmnct_typ_id        AS communicationType,
        c.pri_tel_nbr         AS primaryPhone,
        c.pri_tel_intntl_ind  AS primaryPhoneInternationalInd,
        c.chnl_src_typ_id     AS channelSourceType,
        r1.ref_desc           AS activityTypeRefDesc,
        r2.ref_desc           AS actvResolutionOutcomeRefDesc,
        r3.ref_desc           AS contactRoleTypeRefDesc,
        r4.ref_desc           AS channelSourceTypeRefDesc,
        r5.ref_desc           AS communicationTypeRefDesc,
        n.note_txt_lobj       AS noteTextLargeObject,
        n.note_typ_id         AS noteType,
        c.fax_nbr             AS fax,
        a.actv_prtn_typ_id    AS actvPartnerTypeID,
        u.fst_nm              AS createUserFirstName,
        u.lst_nm              AS createUserLastName,
        r7.ref_desc           AS actvPartnerTypeRefDesc,
        r6.ref_desc           AS actvResolutionRsnTypeRefDesc
FROM
        actv a
        LEFT OUTER JOIN note n ON n.actv_id = a.actv_id
        LEFT OUTER JOIN user_tbl u ON u.user_id = a.creat_user_id
        LEFT OUTER JOIN cmnct_trans c ON a.cmnct_trans_id = c.cmnct_trans_id
        LEFT OUTER JOIN ref r1 ON r1.ref_cd = a.actv_typ_id and r1.ref_nm = 'activityType'
        LEFT OUTER JOIN ref r2 ON r2.ref_cd = a.rslv_otcome_typ_id and r2.ref_nm = 'activityResolutionOutcomeType'
        LEFT OUTER JOIN ref r3 ON r3.ref_cd = a.cntc_role_typ_id and r3.ref_nm = 'contactRoleType'
        LEFT OUTER JOIN ref r4 ON r4.ref_cd = c.chnl_src_typ_id and r4.ref_nm = 'channelSourceType'
        LEFT OUTER JOIN ref r5 ON r5.ref_cd = c.cmnct_typ_id and r5.ref_nm = 'communicationType'
        LEFT OUTER JOIN ref r6 on r6.ref_cd = a.rslv_rsn_typ_id and r5.ref_nm = 'activityResolutionReasonType'
        LEFT OUTER JOIN ref r7 on r7.ref_cd = a.actv_prtn_typ_id and r7.ref_nm = 'activityPartnerType';

CREATE OR REPLACE VIEW
  activitytrackinghistoryview AS
  SELECT
    a.actv_id AS activityID,
    a.cmnct_trans_id AS communicationTransactionID,
    a.extr_ref_id AS externalRefID,
    a.mbr_id AS memberID,
    a.actv_typ_id AS activityType,
    a.rslv_otcome_typ_id AS activityResolutionOutcomeType,
    a.rslv_rsn_typ_id AS activityResolutionReasonType,
    c.cntc_role_typ_id AS contactRoleType,
    c.cntc_nm AS contactName,
    c.rpt_prov_nm AS facilityProviderName,
    a.actv_strt_dttm AS activityStartDateTime,
    c.cmnct_dttm AS communicationDateTime,
    a.creat_dttm AS createDateTime,
    a.chg_dttm AS changeDateTime,
    a.creat_user_id AS createUserID,
    a.chg_user_id AS changeUserID,
    c.cmnct_typ_id AS communicationType,
    c.pri_tel_nbr AS primaryPhone,
    c.pri_tel_intntl_ind AS primaryPhoneInternationalInd,
    c.chnl_src_typ_id AS channelSourceType,
    r1.ref_desc AS activityTypeRefDesc,
    r2.ref_desc AS actvResolutionOutcomeRefDesc,
    r3.ref_desc AS contactRoleTypeRefDesc,
    r4.ref_desc AS channelSourceTypeRefDesc,
    r5.ref_desc AS communicationTypeRefDesc,
    n.note_txt_lobj AS noteTextLargeObject,
    n.note_typ_id AS noteType,
    u.fst_nm AS createUserFirstName,
    u.lst_nm AS createUserLastName,
    r6.ref_desc AS actvResolutionRsnTypeRefDesc
  FROM
    actv a
    LEFT JOIN note n ON n.actv_id = a.actv_id
    LEFT JOIN user_tbl u ON u.user_id = a.creat_user_id
    LEFT JOIN cmnct_trans c ON a.cmnct_trans_id = c.cmnct_trans_id
    LEFT JOIN ref r1 ON r1.ref_cd = a.actv_typ_id and r1.ref_nm = 'activityType'
    LEFT JOIN ref r2 ON r2.ref_cd = a.rslv_otcome_typ_id and r2.ref_nm = 'activityResolutionOutcomeType'
    LEFT JOIN ref r3 ON r3.ref_cd = c.cntc_role_typ_id and r3.ref_nm = 'contactType'
    LEFT JOIN ref r4 ON r4.ref_cd = c.chnl_src_typ_id and r4.ref_nm = 'channelSourceType'
    LEFT JOIN ref r5 ON r5.ref_cd = c.cmnct_typ_id and r5.ref_nm = 'communicationType'
    LEFT JOIN ref r6 on r6.ref_cd = a.rslv_rsn_typ_id and r6.ref_nm = 'activityResolutionReasonType';

CREATE OR REPLACE VIEW
    memberprogramview AS
SELECT
    mp.mbr_id                     AS memberID,
    mp.mbr_pgm_id                 AS memberProgramID,
    mp.pgm_catgy_typ_id           AS programCategoryType,
    mp.pgm_typ_id                 AS programType,
    mp.nom_dept_typ_id            AS nominatingDepartmentType,
    mp.nom_rsn_typ_id             AS nominationReasonType,
    mp.nom_acpt_rsn_typ_id        AS nominationAcceptanceReasonType,
    mp.nom_src_appl_typ_id        AS nominationSourceApplType,
    mp.nom_dt                     AS nominationDate,
    mp.mbr_pgm_sts_typ_id         AS memberProgramStatusType,
    mp.mbr_pgm_sts_rsn_typ_id     AS memberProgramStatusReasonType,
    r1.ref_desc                   AS programCategoryTypeRefDesc,
    r2.ref_dspl                   AS programTypeRefDesc,
    r3.ref_desc                   AS nominatingDepartmentTypeRefDesc,
    r4.ref_desc                   AS nominationReasonTypeRefDesc,
    r5.ref_desc                   AS nomAcceptanceReasonTypeRefDesc,
    r6.ref_desc                   AS memberProgramStatusTypeRefDesc,
    r7.ref_desc                   AS nominationSourceApplDesc,
    r8.ref_desc                   AS memberPgmStatusReasonTypeRefDesc,
    mp.end_dt                     AS endDate,
    mp.creat_user_id              AS createUserID,
    mp.creat_dttm                 AS createDateTime,
    mp.chg_user_id                AS changeUserID,
    mp.enrl_dt                    AS enrollmentDate,
    mp.chg_dttm                   AS changeDateTime,
    mp.enrl_dt                    AS startDate,
    if(mp.end_dt is null, 0, 1)   AS inactiveInd,
    CONCAT( IFNULL(m.lst_nm, ''), ', ', IFNULL(m.fst_nm, ''), ' ', IFNULL(m.midl_nm, '') ) AS memberFullName,
    IFNULL(memberIDTypeHierarchy.mbr_id_typ_id, '') AS memberIDType,
    IFNULL(memberIDTypeHierarchy.mbr_id_txt , '')   AS memberIDText,
    m.bth_dt                                        AS birthDate,
    m.dth_dt                                        AS deathDate,
    IF(ISNULL(md.mbr_pgm_id), 0, 1)                 AS attachmentInd
FROM
    mbr_pgm mp
    LEFT OUTER JOIN mbr m ON mp.mbr_id = m.mbr_id
    LEFT OUTER JOIN ref r1 ON r1.ref_cd = mp.pgm_catgy_typ_id AND r1.ref_nm = 'programCategoryType'
    INNER JOIN ref r2 ON r2.ref_cd = mp.pgm_typ_id AND r2.ref_nm = 'programType'
    LEFT OUTER JOIN ref r3 ON r3.ref_cd = mp.nom_dept_typ_id AND r3.ref_nm = 'nominatingDepartmentType'
    LEFT OUTER JOIN ref r4 ON r4.ref_cd = mp.nom_rsn_typ_id AND r4.ref_nm = 'nominationReasonType'
    LEFT OUTER JOIN ref r5 ON r5.ref_cd = mp.nom_acpt_rsn_typ_id AND r5.ref_nm = 'nominationAcceptanceReasonType'
    INNER JOIN ref r6 ON r6.ref_cd = mp.mbr_pgm_sts_typ_id AND r6.ref_nm = 'memberProgramStatusType'
    LEFT OUTER JOIN ref r7 ON r7.ref_cd = mp.nom_src_appl_typ_id AND r7.ref_nm = 'sourceApplicationType'
    LEFT OUTER JOIN ref r8 ON r8.ref_cd = mp.mbr_pgm_sts_rsn_typ_id AND r8.ref_nm = 'memberProgramStatusReasonType'
    LEFT OUTER JOIN (select distinct mbr_id, mbr_pgm_id from mbr_docmnt where  doc_typ = 9) md on (m.mbr_id = md.mbr_id and mp.mbr_pgm_id = md.mbr_pgm_id)
    LEFT OUTER JOIN (select mi.mbr_id, mi.mbr_id_txt, min(mi.mbr_id_typ_id) as mbr_id_typ_id
                        from ref_hrchy rf
                        left join mbr_id mi on mi.mbr_id_typ_id = rf.ref_cd
                        where rf.hrchy_typ_id = 'GMIDH' and rf.ref_nm = 'memberIDType'
                        group by mi.mbr_id) memberIDTypeHierarchy on memberIDTypeHierarchy.mbr_id = mp.mbr_id;

  CREATE OR REPLACE VIEW
    memberpocnotehistoryview AS
  SELECT
    n.mbr_id AS memberID,
    n.note_seq_nbr AS noteSequenceNumber,
    n.creat_dttm AS createDateTime,
    n.creat_user_id AS createUserID,
    u.fst_nm AS createUserFirstName,
    u.lst_nm AS createUserLastName,
    u.user_grp_id AS createUserRole,
    n.note_typ_id AS noteType,
    n.note_catgy_typ_id AS noteCategoryType,
    p.poc_sgn_symp_nm AS pocSignSymptomName,
    n.intrvn_seq_nbr AS interventionSequenceNumber,
    a.poc_intrvn_catgy_nm AS pocInterventionCategoryName,
    b.poc_intrvn_tgt_nm AS pocInterventionTargetName,
    c.poc_intrvn_care_desc AS pocInterventionCareDescription,
    n.note_txt_lobj AS noteTextLargeObject
  FROM
    mbr_poc_note n
  LEFT JOIN user_tbl u ON u.user_id = n.creat_user_id
  LEFT OUTER JOIN mbr_poc_prob_sgn_symp pss ON n.mbr_poc_prob_id = pss.mbr_poc_prob_id AND n.sgn_symp_seq_nbr = pss.sgn_symp_seq_nbr
  LEFT OUTER JOIN poc_sgn_symp p ON pss.poc_sgn_symp_id = p.poc_sgn_symp_id
  LEFT JOIN mbr_poc_prob_intrvn pi ON n.mbr_poc_prob_id = pi.mbr_poc_prob_id AND n.intrvn_seq_nbr = pi.intrvn_seq_nbr
  LEFT JOIN poc_intrvn i ON pi.poc_intrvn_id = i.poc_intrvn_id
  LEFT JOIN poc_intrvn_catgy a ON i.poc_intrvn_catgy_id = a.poc_intrvn_catgy_id
  LEFT JOIN poc_intrvn_tgt b ON i.poc_intrvn_tgt_id = b.poc_intrvn_tgt_id
  LEFT JOIN poc_intrvn_care_rgn c ON i.poc_intrvn_care_rgn_id = c.poc_intrvn_care_rgn_id;


  CREATE OR REPLACE VIEW
    memberpocpathwayview AS
  SELECT
    m.mbr_id AS memberID,
    p.poc_pthway_id AS pocPathwayID,
    p.poc_pthway_nm AS pocPathwayName,
    m.creat_dttm AS createDateTime
  FROM
    mbr_poc_prob m
  JOIN
    poc_pthway p ON m.poc_pthway_id = p.poc_pthway_id
  GROUP BY memberID, pocPathwayID;

  CREATE OR REPLACE VIEW
    customermemberview AS
  SELECT
    `cm`.`cust_id`      AS `customerID`,
    `c`.`cust_shrt_nm` AS `customerName`,
    `cm`.`mbr_id` AS `memberID`,
    `m`.`fst_nm` AS `firstName`,
    `m`.`lst_nm` AS `lastName`,
    `m`.`midl_nm` AS `middleName`,
    `cm`.`strt_dt`      AS `startDate`,
    `cm`.`end_dt`       AS `endDate`,
    `cm`.`chg_user_id` AS `changeUserID`,
    IFNULL(`memberIDTypeHierarchy`.mbr_id_typ_id, '') AS `memberIDType`,
    IFNULL(`memberIDTypeHierarchy`.mbr_id_txt , '')   AS `memberIDText`,
    `m`.`bth_dt` AS `birthDate`
  FROM cust_mbr cm
  JOIN mbr m ON cm.mbr_id = m.mbr_id
  JOIN cust c ON cm.cust_id = c.cust_id
  LEFT OUTER JOIN (select mi.mbr_id, mi.mbr_id_txt, min(mi.mbr_id_typ_id) as mbr_id_typ_id
                        from ref_hrchy rf
                        left join mbr_id mi on mi.mbr_id_typ_id = rf.ref_cd
                        where rf.hrchy_typ_id = 'GMIDH' and rf.ref_nm = 'memberIDType'
                        group by mi.mbr_id) memberIDTypeHierarchy on memberIDTypeHierarchy.mbr_id = cm.mbr_id;

  CREATE OR REPLACE VIEW
    helptextview AS
  SELECT
    `h`.`hlp_id`       AS `helpID`,
    `h`.`hlp_txt_id`   AS `helpTextID`,
    `h`.`hlp_txt`      AS `helpText`,
    `h`.`cust_id`      AS `customerID`,
    `c`.`cust_shrt_nm` AS `customerName`,
    `h`.`strt_dt`      AS `startDate`,
    `h`.`end_dt`       AS `endDate`
  FROM
    (`help_text` `h`
  JOIN
    `cust` `c`)
  WHERE
    (`c`.`cust_id` = `h`.`cust_id`);

CREATE OR REPLACE VIEW
    memberpocproblemsummaryview AS
SELECT
    mp.mbr_id                   AS memberID,
    mp.poc_prob_sts_typ_id      AS pocProbStatus,
    mp.poc_prob_xpln_txt        AS pocProbExplanationText,
    mp.poc_prob_id              AS pocProblemID,
    mp.poc_prob_urgncy_mod_id   AS pocProbUrgencyModifierID,
    mp.bhv_otcome_rt_id         AS behaviorRatingID,
    mp.knw_otcome_rt_id         AS knowledgeRatingID,
    mp.sts_otcome_rt_id         AS statusRatingID,
    pp.poc_prob_nm              AS pocProblemName,
    pu.poc_prob_urgncy_mod_nm   AS pocProblemUrgencyModifierName,
    pp.poc_prob_desc            AS pocProblemDescription,
    pp.prob_dom_id              AS problemDomainID,
    ppd.prob_dom_nm             AS ProblemDomainName
FROM
    mbr_poc_prob mp
    LEFT OUTER JOIN poc_prob pp ON mp.poc_prob_id = pp.poc_prob_id
    LEFT OUTER JOIN poc_prob_dom ppd ON pp.prob_dom_id = ppd.prob_dom_id
    LEFT OUTER JOIN poc_prob_urgncy_mod pu ON mp.poc_prob_urgncy_mod_id = pu.poc_prob_urgncy_mod_id;

CREATE OR REPLACE VIEW
  incidentview AS
SELECT
  iv.incid_id                  AS incidentID,
  iv.mbr_id                    AS memberID,
  iv.cust_id                   AS customerID,
  cs.cust_shrt_nm              AS customerName,
  r2.ref_desc                  AS incidentStatusTypeDesc,
  r1.ref_desc                  AS incidentTypeDesc,
  iv.prov_clin_id              AS providerClinicalID,
  iv.incid_dt                  AS incidentDate,
  iv.incid_lvl                 AS incidentLevel,
  (select mbr_id_txt from mbr_id mi where mi.mbr_id_typ_id = 6 && iv.mbr_id = mi.mbr_id) AS memberIDText,
  pc.prov_grp_nm               AS providerGroupName,
  iv.chg_dttm                  AS changeDateTime,
  iv.creat_user_id             AS userID
FROM
  incid iv
  LEFT OUTER JOIN cust cs ON iv.cust_id = cs.cust_id
  LEFT OUTER JOIN prov_clin pc ON iv.prov_clin_id = pc.prov_clin_id
  LEFT OUTER JOIN ref r1 ON r1.ref_cd = iv.incid_typ_id and r1.ref_nm = 'incidentType'
  LEFT OUTER JOIN ref r2 ON r2.ref_cd = iv.incid_sts_typ_id and r2.ref_nm = 'incidentStatus';

CREATE OR REPLACE VIEW
    pocpathwaymaintenanceview AS
SELECT
    p.poc_pthway_id             AS pocPathWayID,
    p.poc_pthway_nm             AS pocPathWayName,
    p.poc_pthway_src_desc       AS pocPathWaySourceDescription,
    p.strt_dt                   AS startDate,
    p.end_dt                    AS endDate,
    CONCAT_WS(', ', u.lst_nm, u.fst_nm)  AS createFullUserName,
    CONCAT_WS(', ', uc.lst_nm, uc.fst_nm) AS changeFullUserName,
    p.creat_dttm                AS createDateTime,
    p.chg_dttm                  AS changeDateTime
FROM
    poc_pthway p
    LEFT OUTER JOIN user_tbl u ON p.creat_user_id = u.user_id
    LEFT OUTER JOIN user_tbl uc ON p.chg_user_id = uc.user_id;

CREATE OR REPLACE VIEW
    memberpocinterventionview AS
SELECT
    a.intrvn_seq_nbr         AS interventionSequenceNumber,
    a.mbr_poc_prob_id        AS memberPocProblemID,
    b.mbr_id                 AS memberID,
    b.poc_prob_sts_typ_id    AS pocProbStatus,
    a.add_desc               AS additionalDescription,
    a.remv_from_pln_list_ind AS removeFromPlannedListInd,
    a.cqm_ind                AS cqmInd,
    d.poc_intrvn_care_rgn_id     AS pocInterventionCareRgnID,
    d.poc_intrvn_catgy_id    AS pocInterventionCategoryID,
    d.poc_intrvn_id          AS pocInterventionID,
    d.poc_intrvn_tgt_id      AS pocInterventionTargetID,
    g.poc_intrvn_care_desc   AS pocInterventionCareDescription,
    e.poc_intrvn_catgy_nm    AS pocInterventionCategoryName,
    f.poc_intrvn_tgt_nm      AS pocInterventionTargetName,
    c.poc_prob_id            AS pocProblemID,
    c.poc_prob_nm            AS pocProblemName,
    r.ref_desc               AS referenceDesc
FROM
    mbr_poc_prob_intrvn a
    JOIN mbr_poc_prob b ON a.mbr_poc_prob_id = b.mbr_poc_prob_id
    LEFT OUTER JOIN poc_intrvn d ON a.poc_intrvn_id = d.poc_intrvn_id
    LEFT OUTER JOIN poc_intrvn_care_rgn g ON d.poc_intrvn_care_rgn_id = g.poc_intrvn_care_rgn_id
    LEFT OUTER JOIN poc_intrvn_catgy e ON d.poc_intrvn_catgy_id = e.poc_intrvn_catgy_id
    LEFT OUTER JOIN poc_intrvn_tgt f ON d.poc_intrvn_tgt_id = f.poc_intrvn_tgt_id
    LEFT OUTER JOIN ref r ON r.ref_nm = 'pocProbStatusType' AND b.poc_prob_sts_typ_id = r.ref_cd
    LEFT OUTER JOIN poc_prob c ON d.poc_prob_id = c.poc_prob_id;

CREATE OR REPLACE VIEW ASMTPOCDERIVATIONVIEW
    (
        BUILDERASSESSMENTID,
        CHOICEID,
        POCPROBLEMID,
        QUESTIONID,
        ASSESSMENTCATEGORYTYPEID,
        ASSESSMENTTEMPLATENAME,
        PROMPTTEXT,
        CHOICETEXT,
        POCPROBLEMNAME,
        POCINTERVENTIONID,
        KNOWLEDGEPROBOUTCOMERATINGID,
        BEHAVIORPROBOUTCOMERATINGID,
        STATUSPROBOUTCOMERATINGID,
        POCSIGNSYMPTOMID,
        POCINTERVENTIONCATEGORYID,
        POCINTERVENTIONTARGETID,
        POCINTERVENTIONCAREID,
        POCINTERVENTIONCATEGORYNAME,
        POCINTERVENTIONTARGETNAME,
        POCINTERVENTIONCAREDESCRIPTION,
        POCSIGNSYMPTOMNAME,
        POCELIGIBILITYTYPE,
        KNOWLEDGEPROBOUTCOMERATINGVAL,
        BEHAVIORPROBOUTCOMERATINGVAL,
        STATUSPROBOUTCOMERATINGVAL,
        CHILDQUESTIONCHOICETEXT,
        RSAPOPULATIONTYPE
    )
     AS
  SELECT
    s.bld_asmt_id               AS builderAssessmentID,
    s.cho_id                    AS choiceID,
    s.poc_prob_id               AS pocProblemID,
    s.quest_id                  AS questionID,
    null         AS assessmentCategoryTypeID,
    null             AS assessmentTemplateName,
    null                AS promptText,
    null                   AS choiceText,
    p.poc_prob_nm               AS pocProblemName,
    s.poc_intrvn_id             AS pocInterventionID,
    s.knw_otcome_rt_id          AS knowledgeProbOutcomeRatingID,
    s.bhv_otcome_rt_id          AS behaviorProbOutcomeRatingID,
    s.sts_otcome_rt_id          AS statusProbOutcomeRatingID,
    s.poc_sgn_symp_id           AS pocSignSymptomID,
    null       AS pocInterventionCategoryID,
    null AS pocInterventionTargetID,
    null AS pocInterventionCareID,
    null AS pocInterventionCategoryName,
    null AS pocInterventionTargetName,
    null AS pocInterventionCareDescription,
    ps.poc_sgn_symp_nm          AS pocSignSymptomName,
    s.poc_elig_typ_id           AS pocEligibilityType,
    (select POC_OTCOME_RT_VAL from POC_OTCOME_RT pr where pr.POC_OTCOME_RT_ID = s.knw_otcome_rt_id) AS knowledgeProbOutcomeRatingVal,
    (select POC_OTCOME_RT_VAL from POC_OTCOME_RT pr where pr.POC_OTCOME_RT_ID = s.bhv_otcome_rt_id) AS behaviorProbOutcomeRatingVal,
    (select POC_OTCOME_RT_VAL from POC_OTCOME_RT pr where pr.POC_OTCOME_RT_ID = s.sts_otcome_rt_id) AS statusProbOutcomeRatingVal,
    s.chld_quest_cho_txt        AS childQuestionChoiceText,
    s.rsa_pop_typ_id            AS  rsaPopulationType
  FROM
    poc_prob p,
    asmt_poc_deriv s
    LEFT OUTER JOIN
    poc_sgn_symp ps on s.poc_sgn_symp_id = ps.poc_sgn_symp_id
  WHERE
    s.cho_id is not null
    AND s.poc_prob_id = p.poc_prob_id
union
SELECT
    s.bld_asmt_id               AS builderAssessmentID,
    null                        AS choiceID,
    s.poc_prob_id               AS pocProblemID,
    s.quest_id                  AS questionID,
    null         AS assessmentCategoryTypeID,
    null             AS assessmentTemplateName,
    null                AS promptText,
    null                        AS choiceText,
    p.poc_prob_nm               AS pocProblemName,
    s.poc_intrvn_id             AS pocInterventionID,
    s.knw_otcome_rt_id          AS knowledgeProbOutcomeRatingID,
    s.bhv_otcome_rt_id          AS behaviorProbOutcomeRatingID,
    s.sts_otcome_rt_id          AS statusProbOutcomeRatingID,
    s.poc_sgn_symp_id           AS pocSignSymptomID,
    null       AS pocInterventionCategoryID,
    null         AS pocInterventionTargetID,
    null        AS pocInterventionCareID,
    null       AS pocInterventionCategoryName,
    null         AS pocInterventionTargetName,
    null      AS pocInterventionCareDescription,
    ps.poc_sgn_symp_nm          AS pocSignSymptomName,
    s.poc_elig_typ_id           AS pocEligibilityType,
    (select POC_OTCOME_RT_VAL from POC_OTCOME_RT pr where pr.POC_OTCOME_RT_ID = s.knw_otcome_rt_id) AS knowledgeProbOutcomeRatingVal,
    (select POC_OTCOME_RT_VAL from POC_OTCOME_RT pr where pr.POC_OTCOME_RT_ID = s.bhv_otcome_rt_id) AS behaviorProbOutcomeRatingVal,
    (select POC_OTCOME_RT_VAL from POC_OTCOME_RT pr where pr.POC_OTCOME_RT_ID = s.sts_otcome_rt_id) AS statusProbOutcomeRatingVal,
    s.chld_quest_cho_txt        AS childQuestionChoiceText,
    s.rsa_pop_typ_id            AS  rsaPopulationType
  FROM
    poc_prob p,
    asmt_poc_deriv s
    LEFT OUTER JOIN
    poc_sgn_symp ps on s.poc_sgn_symp_id = ps.poc_sgn_symp_id
  WHERE
    s.cho_id is null
    AND s.poc_prob_id = p.poc_prob_id;


CREATE OR REPLACE VIEW
    memberpocsignsymphistoryview AS
SELECT
    m.mbr_poc_prob_sgn_symp_hist_id AS memberPocProblemSnSymHistoryID,
    m.mbr_poc_prob_id           AS memberPocProblemID,
    m.poc_sgn_symp_id           AS pocSignSymptomID,
    m.chg_dttm                  AS changeDateTime,
    p.poc_sgn_symp_nm           AS pocSignSymptomName,
    m.add_desc                  AS additionalDescription,
    m.actv_ind                  AS activeInd,
    CONCAT_WS(', ', uc.lst_nm, uc.fst_nm) AS changeFullUserName,
    uc.user_grp_id              AS userGroupID
FROM
    mbr_poc_prob_sgn_symp_hist m
    LEFT OUTER JOIN poc_sgn_symp p ON m.poc_sgn_symp_id = p.poc_sgn_symp_id
    LEFT OUTER JOIN user_tbl uc ON m.chg_user_id = uc.user_id;


CREATE OR REPLACE VIEW
    memberpocproblemsignsympview AS
SELECT
    m.mbr_poc_prob_id           AS memberPocProblemID,
    m.poc_sgn_symp_id           AS pocSignSymptomID,
    p.poc_sgn_symp_nm           AS pocSignSymptomName,
    m.add_desc                  AS additionalDescription
FROM
    mbr_poc_prob_sgn_symp m
    LEFT OUTER JOIN poc_sgn_symp p ON m.poc_sgn_symp_id = p.poc_sgn_symp_id
WHERE
    m.actv_ind;


CREATE OR REPLACE VIEW
    memberpocprobintrvnhistoryview AS
SELECT
    m.mbr_poc_prob_intrvn_hist_id AS memberPocProblemIntvnHistoryID,
    m.mbr_poc_prob_id             AS memberPocProblemID,
    pg.poc_intrvn_catgy_nm        AS pocInterventionCategoryName,
    pt.poc_intrvn_tgt_nm          AS pocInterventionTargetName,
    pr.poc_intrvn_care_desc       AS pocInterventionCareDescription,
    m.chg_dttm                    AS changeDateTime,
    m.add_desc                    AS additionalDescription,
    m.cqm_ind                     AS cqmInd,
    CONCAT_WS(', ', uc.lst_nm, uc.fst_nm) AS changeFullUserName,
    uc.user_grp_id                AS userGroupID
FROM
    mbr_poc_prob_intrvn_hist m
    LEFT OUTER JOIN poc_intrvn pi ON m.poc_intrvn_id = pi.poc_intrvn_id
    LEFT OUTER JOIN poc_intrvn_catgy pg ON pi.poc_intrvn_catgy_id = pg.poc_intrvn_catgy_id
    LEFT OUTER JOIN poc_intrvn_tgt pt ON pi.poc_intrvn_tgt_id = pt.poc_intrvn_tgt_id
    LEFT OUTER JOIN poc_intrvn_care_rgn pr ON pi.poc_intrvn_care_rgn_id = pr.poc_intrvn_care_rgn_id
    LEFT OUTER JOIN user_tbl uc ON m.chg_user_id = uc.user_id;

CREATE or replace VIEW
    memberpocproblemhistoryview  AS
SELECT
    m.mbr_poc_prob_hist_id         AS memberPocProblemHistoryID,
    m.mbr_poc_prob_id              AS memberPocProblemID,
    m.poc_prob_sts_typ_id          AS pocProbStatus,
    m.poc_prob_xpln_txt            AS pocProbExplanationText,
    m.poc_prob_urgncy_mod_id       AS pocProbUrgencyModifierID,
    m.knw_otcome_rt_id             AS knowledgeRatingID,
    m.knw_otcome_rt_add_desc       AS knowledgeRatingAddDescription,
    m.bhv_otcome_rt_id             AS behaviorRatingID,
    m.bhv_otcome_rt_add_desc       AS behaviorRatingAddDescription,
    m.sts_otcome_rt_id             AS statusRatingID,
    m.sts_otcome_rt_add_desc       AS statusRatingAddDescription,
    m.poc_prob_src_typ_id          AS pocProbSourceType,
    m.poc_prob_src_desc            AS pocProbSourceDescription,
    m.chg_dttm                     AS changeDateTime,
    m.chg_user_id                  AS changeUserID,
    CONCAT_WS(', ', uc.lst_nm, uc.fst_nm) AS changeFullUserName,
    uc.user_grp_id                 AS userGroupID
FROM
    mbr_poc_prob_hist m
    LEFT OUTER JOIN  user_tbl uc  ON  m.chg_user_id = uc.user_id;

CREATE OR REPLACE VIEW
    memberpocintrvnworkhistoryview AS
SELECT
    c.mbr_poc_prob_id        AS memberPocProblemID,
    c.intrvn_seq_nbr         AS interventionSequenceNumber,
    c.cqm_ind                AS cqmInd,
    a.add_desc               AS additionalDescription,
    a.chg_dttm               AS changeDateTime,
    a.chg_user_id            AS changeUserID,
    d.poc_intrvn_care_rgn_id AS pocInterventionCareRgnID,
    d.poc_intrvn_catgy_id    AS pocInterventionCategoryID,
    d.poc_intrvn_id          AS pocInterventionID,
    d.poc_intrvn_tgt_id      AS pocInterventionTargetID,
    g.poc_intrvn_care_desc   AS pocInterventionCareDescription,
    e.poc_intrvn_catgy_nm   AS pocInterventionCategoryName,
    f.poc_intrvn_tgt_nm     AS pocInterventionTargetName,
    CONCAT_WS(', ', uc.lst_nm, uc.fst_nm) AS changeFullUserName
FROM
    mbr_poc_prob_intrvn c,
    mbr_poc_prob_intrvn_hist a,
    user_tbl uc,
    poc_intrvn d
    LEFT OUTER JOIN poc_intrvn_care_rgn g ON d.poc_intrvn_care_rgn_id = g.poc_intrvn_care_rgn_id
    LEFT OUTER JOIN poc_intrvn_catgy e ON d.poc_intrvn_catgy_id = e.poc_intrvn_catgy_id
    LEFT OUTER JOIN poc_intrvn_tgt f ON d.poc_intrvn_tgt_id = f.poc_intrvn_tgt_id
WHERE
    a.intrvn_seq_nbr = c.intrvn_seq_nbr AND
    a.mbr_poc_prob_id = c.mbr_poc_prob_id AND
    c.poc_intrvn_id = d.poc_intrvn_id AND
    a.chg_user_id = uc.user_id;


CREATE OR REPLACE VIEW
    membercaremanagerview AS
SELECT
    mcm.mbr_id                                        AS memberID,
    mi.mbr_id_typ_id                                  AS memberIDType,
    mcm.user_id                                       AS assignedToUserID,
    usr.fst_nm                                        AS assignedToUserFirstName,
    usr.lst_nm                                        AS assignedToUserLastName,
    m.fst_nm                                          AS firstName,
    m.lst_nm                                          AS lastName,
    m.midl_nm                                         AS middleName,
    m.bth_dt                                          AS birthDate,
    IFNULL(m.dth_dt, null)                            AS deathDate,
    CONCAT(
      IFNULL(m.lst_nm, ''),
      ', ',
      IFNULL(m.fst_nm, ''),
      ' ',
      IFNULL(m.midl_nm, ''))    AS memberFullName,
    (CASE
            WHEN (risk.scor > 0)
            THEN CONVERT(risk.scor, CHAR(1))
            ELSE NULL
     END)                        AS riskTier,
    (CASE
            WHEN (stab.scor > 0)
            THEN CONVERT(stab.scor, CHAR(1))
            ELSE NULL
     END)                        AS stabilityColourCode,
    mcm.chg_dttm                 AS changeDateTime,
    (CASE
            WHEN (mcm.wrk_que_grp_id > 0)
            THEN mcm.wrk_que_grp_id
            ELSE NULL
        END)                     AS assignedToWorkQueueID,
    w.wrk_que_nm_txt             AS assignedToWorkQueueName,
     (
        CASE
            WHEN ((mcm.user_id IS NOT NULL)
                AND (mcm.user_id <> ''))
            THEN CONCAT(usr.lst_nm,', ',usr.fst_nm)
            ELSE w.wrk_que_nm_txt
        END)                     AS assignedToDisplay,
    mi.mbr_id_txt                AS memberIDText,
    usr.user_grp_id              AS userGroupID,
    mcm.end_dt > CURRENT_TIMESTAMP or (mcm.end_dt IS NULL and mcm.strt_dt < CURRENT_TIMESTAMP) AS activeInd,
    mcm.care_mgr_seq_nbr         AS careManagerSeqNbr,
    mcm.strt_dt                  AS startDate,
    mcm.end_dt                   AS endDate,
    mcl.care_lvl_typ_id          AS levelOfCareTypeId,
    usr_mgr.user_id              AS managerUserID,
    usr_mgr.fst_nm               AS managerFirstName,
    usr_mgr.lst_nm               AS managerLastName,
    usr_tel.tel_nbr              AS phone,
    usr.email_adr_txt            AS emailAddress,
    mcm.prmry_ind                AS primaryIndicator,
    IFNULL(m.dth_dt_notif_dt, null)   AS deathDateNotificationDate,
    IFNULL(mcm.asgn_to_dt, null)      AS assignedToDate,
    usr_mgr.email_adr_txt       AS managerEmailAddress,
    mgr_tel.tel_nbr             AS managerPhone,
    usr_adr.adr_ln_1_txt          AS userAddress1,
    usr_adr.adr_ln_2_txt          AS userAddress2,
    usr_adr.cty_nm                AS userCity,
    usr_adr.st_cd                 AS userState,
    usr_adr.zip_cd_txt         AS userZip
FROM
    mbr_care_mgr mcm
    JOIN mbr m ON mcm.mbr_id = m.mbr_id
    LEFT OUTER JOIN (SELECT mbr_id, MIN(mbr_id_typ_id) as mbr_id_typ_id, mbr_id_txt FROM mbr_id GROUP BY mbr_id) mi ON mi.mbr_id = mcm.mbr_id
    LEFT OUTER JOIN mbr_care_mgr_risk risk ON mcm.mbr_id = risk.mbr_id AND mcm.care_mgr_seq_nbr = risk.care_mgr_seq_nbr AND risk.risk_typ_id = '1'
    LEFT OUTER JOIN mbr_care_mgr_risk stab ON mcm.mbr_id = stab.mbr_id AND mcm.care_mgr_seq_nbr = stab.care_mgr_seq_nbr AND stab.risk_typ_id = '2'
    LEFT OUTER JOIN user_tbl usr ON mcm.user_id = usr.user_id
    LEFT OUTER JOIN wrk_que w ON w.wrk_que_id = mcm.wrk_que_grp_id
    LEFT OUTER JOIN (SELECT mbr_care_lvl.* from (SELECT mbr_id, MAX(lvl_of_care_seq_nbr) AS lvl_of_care_seq_nbr from mbr_care_lvl GROUP BY mbr_id) mclInner, mbr_care_lvl where mclInner.mbr_id = mbr_care_lvl.mbr_id and mclInner.lvl_of_care_seq_nbr = mbr_care_lvl.lvl_of_care_seq_nbr) mcl ON mi.mbr_id = mcl.mbr_id AND lvl_of_care_seq_nbr
    LEFT OUTER JOIN user_tbl usr_mgr ON usr.mgr_user_id = usr_mgr.user_id
    LEFT OUTER JOIN user_tel usr_tel ON usr.user_id = usr_tel.user_id AND usr_tel.tel_typ_id='2'
    LEFT OUTER JOIN user_adr usr_adr ON usr.user_id = usr_adr.user_id AND usr_adr.adr_typ_id='3'
    LEFT OUTER JOIN user_tel mgr_tel ON usr.mgr_user_id = mgr_tel.user_id AND mgr_tel.tel_typ_id='2';

 CREATE OR REPLACE VIEW
     memberalertview AS
 SELECT
     m.mbr_id                 AS memberID,
     m.mbr_alrt_seq_nbr       AS memberAlertSeqNbr,
     m.alrt_typ_id            AS alertType,
     m.alrt_sts_typ_id        AS alertStatusType,
     m.clr_by_user_id         AS clearByUserId,
         (
        CASE
            WHEN (m.alrt_sts_typ_id > 0)
            THEN m.clr_dttm
            ELSE NULL
        END)                     AS clearDateTime,
     m.creat_dttm             AS createDateTime,
     usr.fst_nm               AS clearByUserFirstName,
     usr.lst_nm               AS clearByUserLastName,
     r.ref_desc               AS alertTypeDesc,
     r.ref_dspl               AS alertTypeDspl,
     rs.ref_dspl              AS alertStatusTypeDspl,
     m.alrt_evnt_dt          AS alertEventDate,
     m.alrt_evnt_tm          AS alertEventTime
 FROM
     mbr_alrt m
     LEFT OUTER JOIN user_tbl usr ON m.clr_by_user_id = usr.user_id
     LEFT OUTER JOIN ref r ON r.ref_nm = 'alertType' AND m.alrt_typ_id = r.ref_cd
     LEFT OUTER JOIN ref rs ON rs.ref_nm = 'alertStatusType' AND m.alrt_sts_typ_id = rs.ref_cd;

  CREATE OR REPLACE VIEW
     membercontactview AS
  SELECT
     m.mbr_id                 AS memberID,
     m.cntc_seq_nbr           AS contactSequenceNumber,
     CONCAT_WS(', ', m.lst_nm, m.fst_nm) AS contactFullName,
     m.cntc_typ_id            AS contactType,
     m.rel_cntc_typ_id        AS relationshipContactType,
     m.cntc_typ_supp_team_ind AS contactTypeSupportTeamInd,
     m.org_nm                 AS organizationName,
     m.role_desc              AS roleDescription,
     m.rlse_info_ind          AS roiInd,
     (CASE
       WHEN (t.pref_ind = 0 AND t.tel_typ_id = '3') THEN NULL
       WHEN (t.end_dt IS NOT NULL AND t.end_dt <= CURDATE()) THEN NULL
       WHEN (t.eff_dt IS NOT NULL AND t.eff_dt > CURDATE()) THEN NULL
       ELSE t.tel_nbr
      END) AS phone,
     (CASE
       WHEN (t.pref_ind IS NULL) THEN 0
       ELSE t.pref_ind
      END) AS preferredInd,
     t.tel_typ_id             AS phoneType,
     (CASE
       WHEN (m.end_dt IS NOT NULL AND m.end_dt <= CURDATE()) THEN 0
       WHEN (m.eff_dt IS NOT NULL AND m.eff_dt > CURDATE()) THEN 0
       ELSE 1
      END) AS contactActiveInd,
     (CASE
       WHEN (t.end_dt IS NOT NULL AND t.end_dt <= CURDATE()) THEN 0
       WHEN (t.eff_dt IS NOT NULL AND t.eff_dt > CURDATE()) THEN 0
       ELSE 1
      END) AS phoneActiveInd,
     m.prtl_acss_ind          AS portalAccessInd,
     m.cntc_desc              AS contactDescription
  FROM
     MBR_CNTC m
  LEFT JOIN MBR_CNTC_TEL t ON (m.cntc_seq_nbr = t.cntc_seq_nbr);

CREATE OR REPLACE VIEW
    noteview AS
  SELECT
    n.note_id                      AS noteIdentifier,
    n.mbr_id                       AS memberID,
    n.hsc_id                       AS hscID,
    n.creat_dttm                   AS createDateTime,
    (CASE
            WHEN (n.creat_by_cntc_id > 0)
            THEN n.creat_by_cntc_id
            WHEN (n.creat_by_mbr_id > 0)
            THEN n.creat_by_mbr_id
            ELSE n.creat_user_id
        END) AS createUserID,
    n.chg_dttm                     AS changeDateTime,
    n.chg_user_id                  AS changeUserID,
    n.updt_ver_nbr                 AS updateVersion,
    n.note_typ_id                  AS noteType,
    n.note_catgy_typ_id            AS noteCategoryType,
    n.note_txt_lobj                AS noteTextLargeObject,
    n.note_entr_tm_ms              AS noteEntryTimeInMS,
    n.actv_id                      AS activityID,
    n.asmt_id                      AS assessmentID,
    n.asgn_id                      AS assignmentID,
    n.mbr_pgm_id                   AS memberProgramID,
    n.creatr_func_role_typ_id      AS creatorFunctionRoleType,
    n.medcn_seq_nbr                AS medicationSequenceNumber,
    n.creatr_dept_wrk_que_grp_id   AS creatorDeptWorkQueueGroupID,
    n.grd_lvl_scor                 AS gradeLevelScore,
    n.extr_ref_id                  AS externalRefID,
    n.extr_ref_nm                  AS externalUserName,
    n.srvc_pln_id                  AS servicePlanID,
    n.meet_id                      AS meetingID,
    n.prov_clin_id                 AS providerClinicalID,
    r1.ref_desc                    AS noteTypeRefDesc,
    r2.ref_desc                    AS noteCategoryTypeRefDesc,
    (CASE
            WHEN (n.creat_by_cntc_id > 0)
            THEN c.fst_nm
            WHEN (n.creat_by_mbr_id > 0)
            THEN m.fst_nm
            ELSE u.fst_nm
        END) AS createUserFirstName,
    (CASE
            WHEN (n.creat_by_cntc_id > 0)
            THEN c.lst_nm
            WHEN (n.creat_by_mbr_id > 0)
            THEN m.lst_nm
            ELSE u.lst_nm
        END) AS createUserLastName,
    n.mbr_srvc_pln_srvc_auth_id    AS memberServicePlanServiceAuthID,
    n.mbr_alrt_seq_nbr             AS memberAlertSeqNbr,
    n.mbr_cntc_id                  AS memberContactID,
    n.mbr_cntc_rel_id              AS memberContactRelationshipID,
    CONCAT_WS(', ', m.lst_nm, m.fst_nm)        AS memberFullName,
    n.note_txt_titl                AS noteTitle,
    (CASE
            WHEN (n.creat_by_cntc_id > 0)
            THEN 'Support Team Member'
            WHEN (n.creat_by_mbr_id > 0)
            THEN 'Individual'
            ELSE u.user_grp_id
        END)                       AS createUserRole,
    (CASE
            WHEN (n.creat_by_cntc_id > 0)
            THEN GROUP_CONCAT( (CASE
                            WHEN (mc_rel.cntc_typ_id = 'PERS')
                            THEN pers_rel_typ.REF_DSPL
                            WHEN (mc_rel.cntc_typ_id = 'PROF')
                            THEN prof_rel_typ.REF_DSPL
                            WHEN (mc_rel.cntc_typ_id = 'WSP')
                            THEN wsp_rel_typ.REF_DSPL
                            ELSE NULL
                        END) SEPARATOR ', ')
            WHEN (creat_by_mbr_id > 0)
            THEN IF(n.mbr_id = n.creat_by_mbr_id, 'Self', NULL)
            ELSE NULL
        END)                       AS createUserRelationship
  FROM
    note n
    JOIN user_tbl u ON u.user_id = n.creat_user_id
    INNER JOIN ref r1 ON r1.ref_cd = n.note_typ_id and r1.ref_nm = 'noteType'
    LEFT OUTER JOIN ref r2 ON r2.ref_cd = n.note_catgy_typ_id and r2.ref_nm = 'noteCategoryType'
    JOIN mbr m ON m.mbr_id = n.mbr_id
    LEFT JOIN cntc c ON (n.creat_by_cntc_id = c.cntc_id)
    LEFT JOIN mbr_cntc_rel mc_rel ON (n.creat_by_cntc_id = mc_rel.cntc_id)
    LEFT JOIN cust_ref pers_rel_typ ON (mc_rel.rel_cntc_typ_id = pers_rel_typ.ref_cd AND pers_rel_typ.ref_nm = 'personalRelationshipType')
    LEFT JOIN cust_ref prof_rel_typ ON (mc_rel.rel_cntc_typ_id = prof_rel_typ.ref_cd AND prof_rel_typ.ref_nm = 'profRelationshipType')
    LEFT JOIN cust_ref wsp_rel_typ ON (mc_rel.rel_cntc_typ_id = wsp_rel_typ.ref_cd AND wsp_rel_typ.ref_nm = 'wspRelationshipType')
    GROUP BY n.note_id;

 CREATE OR REPLACE VIEW
     providerclinicalview AS
 SELECT
     pc.prov_clin_id          AS providerClinicalID,
     pc.bus_nm                AS businessName,
     pc.prov_grp_nm           AS providerGroupName,
     pc.fst_nm                AS firstName,
     pc.lst_nm                AS lastName,
     pca.adr_ln_1_txt         AS address1,
     pca.cty_nm               AS city,
     pca.st_cd                AS state,
     pca.zip_cd_txt           AS zip,
        (CASE
            WHEN (pc.fst_nm IS NOT NULL OR pc.lst_nm IS NOT NULL)
            THEN CONCAT_WS(' ', pc.fst_nm, pc.lst_nm)
            ELSE pc.bus_nm
        END)                  AS providerName,
     pci.prov_clin_id_txt     AS providerNPI
 FROM
     prov_clin pc
     LEFT OUTER JOIN prov_clin_adr pca ON pc.prov_clin_id = pca.prov_clin_id
     LEFT OUTER JOIN prov_clin_id pci ON pc.prov_clin_id = pci.prov_clin_id AND prov_clin_id_typ_id = '1'
 WHERE
     pc.prov_grp_nm IS NULL;

CREATE OR REPLACE VIEW
    memberproviderview AS
  SELECT
    mp.mbr_prov_clin_id AS memberProviderClinicalID,
    mp.prov_clin_id AS providerClinicalID,
    mp.mbr_id AS memberID,
    mp.prov_sts_typ_id AS providerStatusTypeID,
    mp.nom_dt AS nominationDate,
    mp.enrl_dt AS enrollmentDate,
    mp.end_dt AS endDate,
    pc.prov_grp_nm AS providerName,
    mp.mbr_prov_sts_rsn_txt AS memberProviderStatusReasonText,
    mp.mbr_prov_sts_rsn_typ_id AS memberProviderStatusReasonType,
    (CASE
      WHEN mp.end_dt IS NULL AND mp.prov_sts_typ_id != 3 AND mp.prov_sts_typ_id != 4
      THEN true
      ELSE false
    END) AS activeInd
  FROM
    mbr_prov_clin mp
    LEFT OUTER JOIN prov_clin pc ON mp.prov_clin_id = pc.prov_clin_id;

CREATE OR REPLACE VIEW
    memberfundingeligibilityview AS
  SELECT
    mspe.mbr_srvc_pln_elig_id                   AS memberServicePlanEligID,
    m.mbr_id                                    AS memberID,
    cr.cust_id                                  AS customerID,
    c.cust_shrt_nm                              AS customerName,
    cr.ref_cd                                   AS referenceCode,
    cr.ref_dspl                                 AS referenceDisplay,
    mspe.mbr_srvc_pln_elig_sts_typ_id           AS memberServicePlanEligStsTypeID,
    mspe.strt_dt                                AS startDate,
    mspe.end_dt                                 AS endDate,
    mspe.creat_dttm                             AS createDateTime,
    mspe.chg_dttm                               AS changeDateTime,
    mspe.creat_user_id                          AS createUserID,
    mspe.chg_user_id                            AS changeUserID,
    CONCAT_WS(', ', usr.lst_nm, usr.fst_nm)     AS createFullUserName,
    mspe.updt_ver_nbr                           AS updateVersion
FROM
    mbr_srvc_pln_elig mspe
JOIN mbr m ON mspe.mbr_id = m.mbr_id
JOIN cust c ON mspe.cust_id = c.cust_id
INNER JOIN user_tbl usr ON mspe.creat_user_id = usr.user_id
JOIN cust_ref cr ON cr.ref_cd = mspe.fund_elig_typ_id WHERE mspe.cust_id = cr.cust_id AND cr.ref_nm = 'fundingEligType';

CREATE OR REPLACE VIEW
    incidentproviderview AS
SELECT
    0 AS providerClinicalID,
    mpv.providerName AS providerName,
    cm.cust_id AS customerID,
    (CASE
      WHEN pci.prov_clin_id_txt != ""
      THEN pci.prov_clin_id_txt
      ELSE null
    END) AS TIN,
    (CASE
      WHEN pci2.prov_clin_id_txt != ""
      THEN pci2.prov_clin_id_txt
      ELSE null
    END) AS NPI,
    cm.mbr_id AS memberID
  FROM
    cust_mbr cm
    JOIN MemberProviderView mpv ON cm.mbr_id = mpv.memberID and mpv.activeInd = 1
    LEFT JOIN prov_clin_id pci ON pci.prov_clin_id = mpv.providerClinicalID and pci.prov_clin_id_typ_id = 3
    LEFT JOIN prov_clin_id pci2 ON pci2.prov_clin_id = mpv.providerClinicalID and pci2.prov_clin_id_typ_id = 1;

CREATE OR REPLACE VIEW memberPocProblemGoalView
AS
SELECT
    l.mbr_poc_prob_id              AS memberPocProblemID,
    l.poc_ltg_seq_nbr              AS pocGoalSeqNum,
    m.mbr_id                       AS memberID,
    m.poc_prob_sts_typ_id          AS pocProbStatus,
    l.achv_dt                      AS achievedDate,
    l.add_desc                     AS additionalDescription,
    l.creat_dttm                   AS createDateTime,
    l.mbr_poc_goal_clos_rsn_typ_id AS pocCloseReasonType,
    l.mbr_poc_goal_tpc_typ_id      AS pocGoalTopicType,
    l.tgt_dt                       AS targetDate,
    p.poc_prob_id                  AS pocProblemID,
    p.poc_prob_nm                  AS pocProblemName,
    r_ps.ref_desc                  AS referenceDesc,
    z.poc_ltg_nm                   AS pocGoalName,
    l.chg_dttm                     AS changeDateTime,
    l.chg_user_id                  AS changeUserID,
    r_cr.ref_desc                  AS pocCloseReasonTypeDescription,
    r_gt.ref_desc                  AS pocGoalTopicTypeDescription,
    l.close_dt                     AS closeDate,
    l.creat_user_id                AS createUserID
FROM
    mbr_poc_prob_ltg l
    LEFT OUTER JOIN poc_ltg z ON z.poc_ltg_id = l.poc_ltg_id
    LEFT OUTER JOIN mbr_poc_prob m ON m.mbr_poc_prob_id = l.mbr_poc_prob_id
    LEFT OUTER JOIN poc_prob p ON p.poc_prob_id = m.poc_prob_id
    LEFT OUTER JOIN ref r_cr ON r_cr.ref_cd = l.mbr_poc_goal_clos_rsn_typ_id AND r_cr.ref_nm = 'pocCloseReasonType'
    LEFT OUTER JOIN ref r_gt ON r_gt.ref_cd = l.mbr_poc_goal_tpc_typ_id AND r_gt.ref_nm = 'pocGoalTopicType'
    LEFT OUTER JOIN ref r_ps ON r_ps.ref_cd = m.poc_prob_sts_typ_id AND r_gt.ref_nm = 'pocProbStatusType';

CREATE OR REPLACE VIEW memberPocProblemGoalHistView
AS
SELECT
    l.mbr_poc_prob_id                     AS memberPocProblemID,
    l.mbr_poc_goal_tpc_typ_id             AS pocGoalTopicType,
    z.poc_ltg_nm                          AS pocGoalName,
    l.add_desc                            AS additionalDescription,
    l.tgt_dt                              AS targetDate,
    l.achv_dt                             AS achievedDate,
    l.mbr_poc_goal_clos_rsn_typ_id        AS pocCloseReasonType,
    CONCAT_WS(', ', uc.lst_nm, uc.fst_nm) AS changeFullUserName,
    l.chg_dttm                            AS changeDateTime,
    uc.func_role_typ_id                   AS functionRoleType,
    r_cr.ref_desc                         AS pocCloseReasonTypeDescription,
    r_gt.ref_desc                         AS pocGoalTopicTypeDescription,
    l.close_dt                            AS closeDate
FROM
    mbr_poc_prob_ltg_hist l
    LEFT OUTER JOIN poc_ltg z ON z.poc_ltg_id = l.poc_ltg_id
    LEFT OUTER JOIN user_tbl uc ON l.chg_user_id = uc.user_id
    LEFT OUTER JOIN ref r_cr ON r_cr.ref_cd = l.mbr_poc_goal_clos_rsn_typ_id AND r_cr.ref_nm = 'pocCloseReasonType'
    LEFT OUTER JOIN ref r_gt ON r_gt.ref_cd = l.mbr_poc_goal_tpc_typ_id AND r_gt.ref_nm = 'pocGoalTopicType';

CREATE OR REPLACE VIEW pocProblemGoalView
AS
SELECT
    ppga.poc_prob_goal_assoc_id AS POCPROBGOALASSOCID,
    ppga.poc_prob_id AS POCPROBLEMID,
    ppga.poc_ltg_id AS POCGOALID,
    ppga.strt_dt AS STARTDATE,
    ppga.end_dt AS ENDDATE,
    pl.poc_ltg_src_desc AS POCGOALSOURCEDESC,
    pl.poc_ltg_nm AS POCGOALNAME,
    pl.strt_dt AS POCGOALSTARTDATE,
    pl.end_dt AS POCGOALENDDATE,
    pp.poc_prob_nm AS POCPROBLEMNAME,
    pp.poc_prob_desc AS POCPROBLEMDESCRIPTION,
    ppga.creat_dttm as CREATEDATETIME,
    ppga.creat_user_id AS CREATEUSERID,
    ppga.chg_dttm AS CHANGEDATETIME,
    ppga.chg_user_id AS CHANGEUSERID,
    ppga.updt_ver_nbr AS UPDATEVERSION,
    CASE WHEN
        ppga.end_dt < sysdate()
        or pl.end_dt < sysdate()
        or pp.end_dt < sysdate()
        or ppga.strt_dt > sysdate()
        or pl.strt_dt > sysdate()
        or pp.strt_dt > sysdate()
        THEN 'No' ELSE 'Yes' END as VALIDASSOCIATION
FROM POC_PROB_GOAL_ASSOC ppga, POC_LTG pl, POC_PROB pp
WHERE ppga.poc_ltg_id = pl.poc_ltg_id
 AND ppga.poc_prob_id = pp.poc_prob_id;

CREATE OR REPLACE VIEW user_dashboard_view
AS
SELECT
    u_db.user_id AS userID,
    u_db.tile_id AS tileID,
    u_db.tile_pstn AS tilePosition,
    db_tile.template_url AS templateUrl,
    db_tile.title AS title,
    db_tile.descriptiontext AS descriptiontext,
    db_tile.tile_wdth AS tileWidth,
    db_tile.creat_dttm AS createDateTime
FROM user_dashbd u_db
    LEFT OUTER JOIN dashbd_tile db_tile ON db_tile.tile_id = u_db.tile_id;

CREATE OR REPLACE VIEW workfloweventactionview
AS
SELECT
      waa.wrkflw_actn_asgn_id AS workflowActionAssignmentID,
      ws.wrkflw_step_id AS workflowStepID,
      ws.wrkflw_actn_type_id AS workflowActionTypeID,
      waa.asgn_typ_id AS assignmentType,
      waa.dflt_asgn_prr_typ_id AS defaultAssignmentPriorityType,
      CONCAT(waa.dur_nbr, ' ', r1.ref_desc) AS dueAfterEvent,
      waa.asgn_desc_typ_id AS assignmentDescriptorType,
      waa.asgn_rsn_typ_id AS assignmentReasonType,
      waa.dur_nbr AS durationNumber,
      waa.dur_freq AS durationFrequency

FROM wrkflw_step_actn_asgn wsaa
    JOIN wrkflw_step ws ON ws.wrkflw_step_id = wsaa.wrkflw_step_id
    JOIN wrkflw_actn_asgn waa ON waa.wrkflw_actn_asgn_id = wsaa.wrkflw_actn_asgn_id
    LEFT OUTER JOIN ref r1 ON r1.ref_cd = waa.dur_freq AND r1.ref_nm = 'workflowActionDurationType';

CREATE OR REPLACE VIEW
    providercustomerview AS
SELECT
    pc.prov_clin_id             AS providerClinicalID,
    pci.prov_clin_id_typ_id     AS providerClinicalTypeID,
    pca.prov_clin_adr_id        AS providerClinicalAddressID,
    pc.prov_grp_nm              AS providerClinicalGroupName,
    pci.prov_clin_id_txt        AS providerNPI,
    CONCAT_WS(' ', CONCAT_WS(', ', IF(pca.adr_ln_1_txt<>'',pca.adr_ln_1_txt,NULL), IF(pca.adr_ln_2_txt<>'',pca.adr_ln_2_txt,NULL), IF(pca.cty_nm<>'',pca.cty_nm,NULL), IF(pca.st_cd<>'',pca.st_cd,NULL)),  IF(pca.zip_cd_txt<>'',pca.zip_cd_txt,NULL)) AS providerClinicalAddress,
    CASE
        WHEN pc.strt_dt <= CURDATE() AND pc.end_dt > CURDATE() THEN 1
        ELSE 0
    END AS activeInd,
    pca.adr_ln_1_txt            AS address1,
    pca.adr_ln_2_txt            AS address2,
    pca.cty_nm                  AS city,
    pca.st_cd                   AS state,
    pca.zip_cd_txt              AS zip,
    pci.prov_clin_id_typ_id     AS providerClinicalIDTypeID
FROM prov_clin pc
  LEFT JOIN prov_clin_id pci ON pci.prov_clin_id = pc.prov_clin_id
  LEFT JOIN prov_clin_adr pca ON pca.prov_clin_id = pc.prov_clin_id
  order by providerClinicalGroupName asc, providerClinicalAddress asc;

  CREATE OR REPLACE VIEW
    provcustcountyview
    AS
SELECT p.cust_id        AS 'customerID',
       p.prov_clin_id   AS 'providerClinicalID',
       c.cnty_nm        AS 'countyName',
       c.cust_cnty_id   AS 'customerCountyID',
       p.prov_cust_cnty_id AS 'providerCustomerCountyID'
FROM prov_cust_cnty p
  LEFT OUTER JOIN cust_cnty c
    ON p.cust_cnty_id = c.cust_cnty_id
ORDER BY cnty_nm ASC;


CREATE OR REPLACE VIEW
    provcustspecialtyview
    AS
SELECT
      s.cust_id        AS 'customerID',
      s.prov_clin_id   AS 'providerClinicalID',
      r.ref_desc       AS 'referenceDesc'
FROM prov_cust_spcl s
  LEFT OUTER JOIN cust_ref r
    ON s.cust_id = r.cust_id
      AND s.spcl_typ_id = r.ref_cd
WHERE r.ref_nm = 'specialtyType'
    AND r.end_dt > sysdate()
    AND r.strt_dt <= sysdate()
ORDER BY referenceDesc ASC;

CREATE OR REPLACE VIEW
workflowstepview AS
SELECT DISTINCT
    ws.wrkflw_type_id           AS workflowTypeID,
    ws.step_nm                  AS workflowStepName,
    r.ref_desc                  AS workflowEventTypeID,
    ws.strt_dt                  AS startDate,
    (SELECT COUNT(*) FROM wrkflw_step WHERE wrkflw_type_id = ws.wrkflw_type_id AND wrkflw_event_type_id = ws.wrkflw_event_type_id AND step_nm = ws.step_nm AND ws.wrkflw_actn_type_id IS NOT NULL) AS actionCount,
    CASE
        WHEN ws.strt_dt <= CURDATE() AND ws.end_dt >= CURDATE() THEN 1
        ELSE 0
    END AS activeInd
FROM wrkflw_step ws
    LEFT JOIN ref r ON r.ref_cd = ws.wrkflw_event_type_id AND r.ref_nm = 'workflowEventType'
    ORDER BY activeInd DESC, workflowStepName ASC;

CREATE OR REPLACE VIEW memberproviderrecomview
  AS
  SELECT mpr.mbr_prov_recom_id                   AS memberProviderRecommendationID,
         mpr.mbr_id                              AS memberID,
         mpr.prov_recom_nm                       AS providerRecommendationName,
         mpr.prov_recom_txt                      AS providerRecommendationText,
         mpr.creat_user_id                       AS createUserID,
         CONCAT_WS(', ', u.lst_nm, u.fst_nm)     AS fullUsername,
         mpr.creat_dttm                          AS createDateTime
  FROM mbr_prov_recom mpr
  LEFT JOIN user_tbl u ON mpr.creat_user_id = u.user_id;


CREATE OR REPLACE VIEW
    unassignedrosterlistview AS
SELECT
    mcm.mbr_id AS memberID,
    mi.mbr_id_txt AS memberIDText,
    r.ref_dspl AS memberIDType,
    mcm.user_id AS assignedToUserID,
    m.fst_nm AS firstName,
    m.lst_nm AS lastName,
    m.midl_nm AS middleName,
    m.bth_dt AS birthDate,
    IFNULL(m.dth_dt, null) AS deathDate,
    CONCAT(
      IFNULL(m.lst_nm, ''),
      ', ',
      IFNULL(m.fst_nm, ''),
      ' ',
      IFNULL(m.midl_nm, '')) AS memberFullName,
    mcm.creat_dttm AS createDateTime,
    TIMESTAMPDIFF(DAY, mcm.creat_dttm, UTC_TIMESTAMP) + 1 as inQueue,
    mcm.wrk_que_grp_id AS workQueueGroupID,
    mcm.end_dt > CURRENT_TIMESTAMP or (mcm.end_dt IS NULL and mcm.strt_dt < CURRENT_TIMESTAMP) AS activeInd
FROM mbr_care_mgr mcm
JOIN mbr m ON mcm.mbr_id = m.mbr_id
LEFT JOIN (SELECT mbr_id, MIN(mbr_id_typ_id) as mbr_id_typ_id, mbr_id_txt FROM mbr_id GROUP BY mbr_id) mi ON mi.mbr_id = mcm.mbr_id
LEFT JOIN ref r ON r.ref_cd = mi.mbr_id_typ_id AND r.ref_nm = 'memberIDType';


CREATE OR REPLACE VIEW
    memberfundingelighistoryview AS
SELECT
    mcm.mbr_id AS memberID,
    r.ref_dspl AS memberIDType,
    mi.mbr_id_txt AS memberIDText,
    mcm.user_id AS assignedToUserID,
    m.bth_dt AS birthDate,
    IFNULL(m.dth_dt, null) AS deathDate,
    CONCAT(
      IFNULL(m.lst_nm, ''),
      ', ',
      IFNULL(m.fst_nm, ''),
      ' ',
      IFNULL(m.midl_nm, '')) AS memberFullName,
    mcm.end_dt > CURRENT_TIMESTAMP or (mcm.end_dt IS NULL and mcm.strt_dt < CURRENT_TIMESTAMP) AS activeInd,
    IFNULL(mcm.prmry_ind, 0) AS primaryIndicator,
    mspeh.mbr_srvc_pln_elig_id AS memberServicePlanEligID,
    mspeh.mbr_srvc_pln_elig_hist_id AS memberFundingEligHistoryID,
    mspe.creat_dttm AS createDateParent,
    mspeh.creat_dttm AS createDateHistory,
    mspeh.srvc_pln_elig_chg_dt AS servicePlanEligChangeDate,
    IFNULL(r2.ref_dspl,'') AS startFundingElig,
    mspeh.strt_dt AS startDate,
    IFNULL(r2.ref_dspl,'') AS endingFundingElig,
    mspeh.end_dt AS endDate,
    DATE(mspeh.strt_dt) AS startDateDisplay,
    DATE(mspeh.end_dt) AS endDateDisplay,
    mspeh.srvc_pln_elig_chg_dt AS criteriaDate
FROM mbr_care_mgr mcm
JOIN mbr m ON mcm.mbr_id = m.mbr_id
RIGHT JOIN mbr_srvc_pln_elig_hist mspeh ON mspeh.mbr_id = mcm.mbr_id
LEFT JOIN mbr_srvc_pln_elig mspe ON mspe.mbr_srvc_pln_elig_id = mspeh.mbr_srvc_pln_elig_id
LEFT JOIN (SELECT mbr_id, MIN(mbr_id_typ_id) as mbr_id_typ_id, mbr_id_txt FROM mbr_id GROUP BY mbr_id) mi ON mi.mbr_id = mcm.mbr_id
LEFT JOIN cust_ref r ON r.ref_cd = mi.mbr_id_typ_id AND r.ref_nm = 'memberIDType'
LEFT JOIN cust_ref r2 ON r2.ref_cd = mspeh.fund_elig_typ_id AND r2.ref_nm = 'fundingEligType'
LEFT JOIN (select mbr_id, srvc_pln_elig_chg_dt,mbr_srvc_pln_elig_id, MAX(mbr_srvc_pln_elig_hist_id) AS maxHistoryID from mbr_srvc_pln_elig_hist GROUP BY mbr_srvc_pln_elig_id) mspeh2 ON mspeh2.mbr_id=mspeh.mbr_id AND mspeh2.mbr_srvc_pln_elig_id = mspeh.mbr_srvc_pln_elig_id AND mspeh2.srvc_pln_elig_chg_dt IS NOT NULL
WHERE mspeh.srvc_pln_elig_chg_dt IS NOT NULL
ORDER BY mspeh.mbr_id, mspeh.mbr_srvc_pln_elig_id, mspeh.mbr_srvc_pln_elig_hist_id DESC;

CREATE OR REPLACE VIEW
    membercarelevelhistoryview AS
SELECT
    mcm.mbr_id AS memberID,
    r.ref_dspl AS memberIDType,
    mi.mbr_id_typ_id AS memberIDTypeCode,
    mi.mbr_id_txt AS memberIDText,
    mcm.user_id AS assignedToUserID,
    m.bth_dt AS birthDate,
    IFNULL(m.dth_dt, null) AS deathDate,
    CONCAT(
      IFNULL(m.lst_nm, ''),
      ', ',
      IFNULL(m.fst_nm, ''),
      ' ',
      IFNULL(m.midl_nm, '')) AS memberFullName,
    mcm.end_dt > CURRENT_TIMESTAMP or (mcm.end_dt IS NULL and mcm.strt_dt < CURRENT_TIMESTAMP) AS activeInd,
    IFNULL(r2.ref_cd, '') AS currentLevelOfCareTypeID,
    IFNULL(r3.ref_cd, '') AS previousLevelOfCareTypeID,
    mclh.care_lvl_chg_dt AS careLevelChangeDate,
    mbr_care_lvl_hist_id AS memberCareLevelHistoryID
FROM mbr_care_mgr mcm
JOIN mbr m ON mcm.mbr_id = m.mbr_id
RIGHT JOIN mbr_care_lvl_hist mclh ON mclh.mbr_id = mcm.mbr_id and mclh.care_lvl_chg_dt is not null
LEFT JOIN (SELECT mbr_id, MIN(mbr_id_typ_id) as mbr_id_typ_id, mbr_id_txt FROM mbr_id GROUP BY mbr_id) mi ON mi.mbr_id = mcm.mbr_id
LEFT JOIN cust_ref r ON r.ref_cd = mi.mbr_id_typ_id AND r.ref_nm = 'memberIDType'
LEFT JOIN cust_ref r2 ON (r2.ref_cd = mclh.care_lvl_typ_id AND r2.ref_nm = 'levelOfCare' and mclh.care_lvl_chg_dt is not null)
LEFT JOIN cust_ref r3 ON r3.ref_cd = (SELECT sub.care_lvl_typ_id
       FROM   mbr_care_lvl_hist AS sub
       WHERE  sub.mbr_care_lvl_hist_id < mclh.mbr_care_lvl_hist_id and mclh.care_lvl_chg_dt is not null and sub.care_lvl_chg_dt is not null and mclh.mbr_id = sub.mbr_id
       ORDER  BY sub.mbr_care_lvl_hist_id DESC
       LIMIT  1) AND r3.ref_nm = 'levelOfCare'
WHERE mcm.prmry_ind = 1 and mclh.care_lvl_chg_dt is not null
GROUP BY mclh.mbr_care_lvl_hist_id, mcm.mbr_id,mi.mbr_id_typ_id, mi.mbr_id_txt, mcm.user_id   ORDER BY mclh.mbr_care_lvl_hist_id;

CREATE OR REPLACE VIEW
    providercontactrelview AS
SELECT
    rel.prov_clin_id                          AS providerClinicalID,
    rel.cntc_id                               AS contactID,
    cntc.fst_nm                               AS firstName,
    cntc.lst_nm                               AS lastName,
    CONCAT_WS(', ', cntc.lst_nm, cntc.fst_nm) AS contactFullName,
    cntc.bth_dt                               AS birthDate,
    rel.prov_clin_cntc_title                  AS primaryContactTitle,
    (rel.end_dt >= CURRENT_TIMESTAMP
OR  rel.end_dt IS NULL)
AND rel.eff_dt <= CURRENT_TIMESTAMP AS activeInd,
    rel.eff_dt                      AS effectiveDate,
    rel.end_dt                      AS endDate,
    cntc.updt_ver_nbr               AS contactUpdateVersion
FROM
    prov_clin_cntc_rel rel
JOIN
    prov_clin prov
ON
    rel.prov_clin_id = prov.prov_clin_id
JOIN
    cntc cntc
ON
    rel.cntc_id = cntc.cntc_id order by effectiveDate desc;

CREATE OR REPLACE VIEW
    membercontactrelview AS
SELECT
    rel.mbr_cntc_rel_id                       AS memberContactRelationshipID,
    rel.mbr_id                                AS memberID,
    rel.cntc_id                               AS contactID,
    cntc.fst_nm                               AS firstName,
    cntc.lst_nm                               AS lastName,
    CONCAT_WS(', ', cntc.lst_nm, cntc.fst_nm) AS contactFullName,
    rel.cntc_typ_id                           AS contactType,
    mbrContactType.ref_desc                   AS contactTypeText,
    CASE
        WHEN rel.cntc_typ_id = 'PERS'
        THEN personalRelType.ref_desc
        WHEN rel.cntc_typ_id = 'PROF'
        THEN profRelType.ref_desc
        WHEN rel.cntc_typ_id = 'WSP'
        THEN wspRelType.ref_desc
        ELSE NULL
    END                        AS relationshipContactType,
    rel.cntc_typ_supp_team_ind AS contactTypeSupportTeamInd,
    rel.prtl_acss_ind          AS portalAccessInd,
    CASE
        WHEN rel.cntc_typ_id = 'WSP'
        THEN prov.prov_grp_nm
        WHEN rel.cntc_typ_id = 'PROF'
        THEN rel.org_nm
        ELSE NULL
    END AS organizationName,
    rel.role_desc                     AS roleDescription,
    rel.cntc_typ_pri_ind              AS contactTypePrimaryInd,
    rel.cntc_typ_pri_emerg_ind        AS contactTypePrimaryEmergencyInd,
    rel.cntc_typ_evac_resp_ind        AS contactTypeEvacRespInd,
    rel.srvc_pln_all_meet_ind         AS srvcPlnAllMeetingInd,
    rel.srvc_pln_cntc_meet_ind        AS srvcPlnContactMeetingInd,
    rel.srvc_pln_all_need_ind         AS srvcPlnAllNeedInd,
    rel.srvc_pln_cntc_need_ind        AS srvcPlnContactNeedInd,
    rel.srvc_pln_all_dsrd_otcome_ind  AS srvcPlnAllDesiredOutcomeInd,
    rel.srvc_pln_cntc_dsrd_otcome_ind AS srvcPlnContactDesiredOutcomeInd,
    rel.srvc_pln_all_waiv_srvc_ind    AS srvcPlnAllWaiverServiceInd,
    rel.srvc_pln_cntc_waiv_srvc_ind   AS srvcPlnContactWaiverServiceInd,
    rel.srvc_pln_sched_ind            AS srvcPlnScheduleInd,
    rel.roi_attached                  AS roiAttached,
    rel.roi_eff_dt                    AS roiEffectiveDate,
    rel.roi_end_dt                    AS roiEndDate,
    rel.srvc_pln_cntc_ind             AS srvcPlnContactsInd,
    rel.srvc_pln_note_ind             AS srvcPlnNoteInd,
    CASE
        WHEN (rel.eff_dt <= CURDATE()
            AND (rel.end_dt IS NULL
                OR  rel.end_dt >= CURDATE()))
        THEN 1
        ELSE 0
    END                               AS activeInd,
    rel.do_not_cntc_ind               AS doNotContactInd
FROM
    mbr_cntc_rel rel
JOIN
    cntc
ON
    rel.cntc_id = cntc.cntc_id
LEFT JOIN
    wsp_cntc_rel wsp_rel
ON
    rel.mbr_cntc_rel_id = wsp_rel.mbr_cntc_rel_id
LEFT JOIN
    prov_clin prov
ON
    wsp_rel.prov_clin_id = prov.prov_clin_id
LEFT JOIN
    cust_ref mbrContactType
ON
    rel.cntc_typ_id = mbrContactType.ref_cd
AND mbrContactType.ref_nm = 'mbrContactType'
LEFT JOIN
    cust_ref personalRelType
ON
    rel.rel_cntc_typ_id = personalRelType.ref_cd
AND personalRelType.ref_nm = 'personalRelationshipType'
LEFT JOIN
    cust_ref profRelType
ON
    rel.rel_cntc_typ_id = profRelType.ref_cd
AND profRelType.ref_nm = 'profRelationshipType'
LEFT JOIN
    cust_ref wspRelType
ON
    rel.rel_cntc_typ_id = wspRelType.ref_cd
AND wspRelType.ref_nm = 'wspRelationshipType';

CREATE OR REPLACE VIEW bb_table_fields_x_fields
AS
  SELECT
    a.table_name                     AS table_name,
    a.field_name                     AS field_name,
    (CASE WHEN b.field_name_physical IS null THEN a.field_name
     ELSE b.field_name_physical END) AS field_name_physical,
    a.sort_num                       AS sort_num,
    b.data_type                      AS data_type,
    b.field_length                   AS field_length,
    b.field_precision                AS field_precision,
    b.descriptiontext                AS field_descriptiontext,
    b.uppercaseonly                  AS uppercaseonly,
    a.primary_key                    AS primary_key,
    b.field_xref                     AS field_xref,
    c.descriptiontext                AS table_descriptiontext,
    (CASE WHEN c.view_indicator = 1 OR c.virtual_indicator = 1 THEN 'View'
     ELSE 'Table' END)               AS table_or_view
  FROM
      bb_table_fields a
      JOIN bb_fields b
        ON a.field_name = b.field_name
      JOIN bb_tables c
        ON a.table_name = c.table_name
  WHERE c.under_construction <> 1
  ORDER BY a.table_name, a.sort_num;

CREATE OR REPLACE VIEW
    customer_user_view AS
SELECT
    cu.cust_id     AS customerID,
    c.cust_shrt_nm AS customerName,
    cu.user_id     AS userID,
    cu.strt_dt     AS startDate,
    cu.end_dt      AS endDate
FROM
  cust_user cu
  LEFT OUTER JOIN cust c ON cu.cust_id = c.cust_id;


CREATE OR REPLACE VIEW
    display_element_view AS
SELECT DISTINCT
    d.dspl_elmnt_id AS displayElementID,
    d.dspl_elmnt_nm AS displayElementName,
    d.dspl_elmnt_desc AS displayElementDesc,
    dp.dspl_elmnt_par_id AS displayElementParentID,
    de.dspl_elmnt_nm AS displayElementParentName
FROM
   dspl_elmnt d
   LEFT OUTER JOIN dspl_elmnt_par dp ON dp.dspl_elmnt_id = d.dspl_elmnt_id
   LEFT OUTER JOIN dspl_elmnt de ON de.dspl_elmnt_id = dp.dspl_elmnt_par_id;


CREATE OR REPLACE VIEW
    display_element_parent_view AS
SELECT DISTINCT
    dp.dspl_elmnt_par_id AS displayElementParentID,
    de.dspl_elmnt_nm AS displayElementParentName,
    dp.dspl_elmnt_id AS displayElementID,
    d.dspl_elmnt_nm AS displayElementName
FROM
   dspl_elmnt_par dp
   LEFT OUTER JOIN dspl_elmnt d ON d.dspl_elmnt_id = dp.dspl_elmnt_id
   LEFT OUTER JOIN dspl_elmnt de ON de.dspl_elmnt_id = dp.dspl_elmnt_par_id;

CREATE OR REPLACE VIEW
    cust_dspl_elmnt_cnfg_view AS
SELECT
    co.cust_dspl_elmnt_cnfg_id AS customerDisplayElementConfigID,
    co.dspl_elmnt_id           AS displayElementID,
    d.dspl_elmnt_nm            AS displayElementName,
    co.dspl_elmnt_par_id       AS displayElementParentID,
    de.dspl_elmnt_nm           AS displayElementParentName,
    co.cust_id                 AS customerID,
    c.cust_shrt_nm             AS customerName,
    co.elmnt_vsbl_ind          AS elementVisibleIndicator,
    GROUP_CONCAT(' ',cp.prmis_grp_id)  AS permissionGroupID,
    GROUP_CONCAT(' ',cp.prmis_id)      AS permissionID
FROM
    cust_dspl_elmnt_cnfg co
LEFT OUTER JOIN dspl_elmnt d ON co.dspl_elmnt_id = d.dspl_elmnt_id
LEFT OUTER JOIN cust_dspl_elmnt_prmis cp ON co.cust_dspl_elmnt_cnfg_id = cp.cust_dspl_elmnt_cnfg_id
LEFT OUTER JOIN dspl_elmnt de ON de.dspl_elmnt_id = co.dspl_elmnt_par_id
LEFT OUTER JOIN cust c ON co.cust_id = c.cust_id
GROUP BY co.cust_dspl_elmnt_cnfg_id;

CREATE OR REPLACE VIEW
  customerview AS
SELECT
  c.cust_id            AS customerID,
  c.chg_dttm           AS changeDateTime,
  c.chg_user_id        AS changeUserID,
  c.cust_shrt_nm       AS customerName,
  c.cust_desc          AS customerDescription,
  c.strt_dt            AS startDate,
  c.end_dt             AS endDate,
  c.fy_strt_mo         AS fiscalYearStartMonth,
  c.fy_strt_day        AS fiscalYearStartDay,
  c.fy_end_mo          AS fiscalYearEndMonth,
  c.fy_end_day         AS fiscalYearEndDay,
  c.org_id             AS organizationID,
  o.org_shrt_nm	       AS organizationName,
  CONCAT_WS(', ', u.lst_nm, u.fst_nm) AS changeFullUserName
FROM
  cust c
  LEFT OUTER JOIN user_tbl u ON c.chg_user_id = u.user_id
  LEFT OUTER JOIN org o ON c.org_id = o.org_id;

CREATE OR REPLACE VIEW
    customerspecialtyview
    AS
SELECT
    a.ref_desc               AS 'referenceDesc',
    a.sec_val                AS 'secondaryValue',
    a.cust_id                AS 'customerID',
    a.strt_dt                AS 'startDate',
    a.end_dt                 AS 'endDate',
    a.ref_cd                 AS 'referenceCode',
    IF(max(c.prov_cust_spcl_id) is null, 0, 1) AS 'referencedInd',
    IF(a.end_dt <= SYSDATE(),0,1)              AS 'activeInd'
FROM cust_ref a
LEFT OUTER JOIN prov_cust_spcl c
    ON (a.ref_cd = c.spcl_typ_id and a.cust_id = c.cust_id)
    WHERE a.ref_nm = 'specialtyType'
    GROUP BY customerID, referenceCode;

CREATE OR REPLACE VIEW
    customerregionview AS
SELECT
    rgn.cust_id            AS customerID,
    rgn.rgn_cd             AS regionCode,
    rf.ref_dspl            AS regionName,
    COUNT(rgn.cust_rgn_id) AS countiesCount
FROM
    cust_rgn rgn
LEFT JOIN
    CUST_REF rf
ON (rgn.rgn_cd = rf.ref_cd AND rf.ref_nm = 'region' AND rf.cust_id = rgn.cust_id)
GROUP BY
    rgn.cust_id, rgn.rgn_cd
ORDER BY
    regionName, countiesCount;

CREATE OR REPLACE VIEW
    custcntyunallocatedview AS
SELECT
    cnty.cust_id      AS customerID,
    cnty.cust_cnty_id AS customerCountyID,
    cnty.cnty_nm      AS countyName
FROM
    CUST_CNTY cnty
LEFT JOIN
    cust_rgn rgn
ON (cnty.cust_cnty_id = rgn.cust_cnty_id)
WHERE
    cnty.actv_ind = 1
AND rgn.cust_rgn_id IS NULL;
