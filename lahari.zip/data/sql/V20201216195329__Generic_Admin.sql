// Create initial entries into needed tables

// Scheduled Job Lock for Scheduled Jobs Timer
INSERT INTO SCHED_JOB_LCK (SYS_ID, updt_ver_nbr) VALUES (1, 0);

// Administrator Setup
INSERT INTO PRMIS_GRP (PRMIS_GRP_ID, chg_dttm, chg_user_id, creat_dttm, creat_user_id, PRMIS_GRP_DESC, updt_ver_nbr) VALUES ('ADMINISTRATOR', current_timestamp,  'ADMINISTRATOR', current_timestamp, 'ADMINISTRATOR', 'Administrator Permission Group', 0);

INSERT INTO USER_GRP (USER_GRP_ID, chg_dttm, chg_user_id, creat_dttm, creat_user_id, USER_GRP_DESC, MAIN_MNU, updt_ver_nbr) VALUES ('ADMINISTRATOR', current_timestamp,  'ADMINISTRATOR', current_timestamp, 'ADMINISTRATOR', 'Administrator Group', '/app.jsp', 0);
INSERT INTO USER_GRP_PRMIS_GRP (USER_GRP_ID, chg_dttm, chg_user_id, creat_dttm, creat_user_id, PRMIS_GRP_ID, updt_ver_nbr) VALUES ('ADMINISTRATOR', current_timestamp,  'ADMINISTRATOR', current_timestamp, 'ADMINISTRATOR', 'ADMINISTRATOR', 0);

// ************ End of section *********************************************** /
