//** ADMINISTRATOR update - must set the change & create dates for Oracle **/
update ROLE_PRMIS set CHG_DTTM=to_date('2002-06-01 13:44:11', 'YYYY-MM-DD HH24:MI:SS'), CREAT_DTTM=to_date('2002-06-01 13:44:11', 'YYYY-MM-DD HH24:MI:SS');
update Role set CHG_DTTM=to_date('2002-06-01 13:44:11', 'YYYY-MM-DD HH24:MI:SS'), CREAT_DTTM=to_date('2002-06-01 13:44:11', 'YYYY-MM-DD HH24:MI:SS');
update USER_GRP set CHG_DTTM=to_date('2002-06-01 13:44:11', 'YYYY-MM-DD HH24:MI:SS'), CREAT_DTTM=to_date('2002-06-01 13:44:11', 'YYYY-MM-DD HH24:MI:SS');
update USER_GRP_ROLE set CHG_DTTM=to_date('2002-06-01 13:44:11', 'YYYY-MM-DD HH24:MI:SS'), CREAT_DTTM=to_date('2002-06-01 13:44:11', 'YYYY-MM-DD HH24:MI:SS');
update User_Tbl set CHG_DTTM=to_date('2002-06-01 13:44:11', 'YYYY-MM-DD HH24:MI:SS'), CREAT_DTTM=to_date('2002-06-01 13:44:11', 'YYYY-MM-DD HH24:MI:SS');
//*************/
