DELIMITER ;

DROP PROCEDURE IF EXISTS TRUNCATE_TABLE;

DELIMITER //

CREATE PROCEDURE TRUNCATE_TABLE (IN p_tablename varchar(30))

BEGIN

   DECLARE v_count          INTEGER DEFAULT 0;
   DECLARE v_tablename      VARCHAR(30);
   DECLARE v_sqlerrmsg      VARCHAR(256);
   DECLARE p_errcode        NUMERIC;

   SET p_errcode = 1;
   SET v_tablename = TRIM(p_tablename);

   SELECT COUNT(*) INTO v_count FROM information_schema.tables WHERE table_name = v_tablename;
   IF v_count > 0 THEN
        SET @sql = CONCAT('TRUNCATE TABLE ', v_tablename) ;
        PREPARE stmt FROM @sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
   END IF;

   SET p_errcode = 0;

END
//

DELIMITER ;

DROP PROCEDURE IF EXISTS GET_KEY;

DELIMITER //

CREATE PROCEDURE GET_KEY(OUT p_id int)
BEGIN
      SELECT SYS_SEQ_NBR
        INTO p_id
        FROM SYS_KEY
       WHERE TBL_NM = 'sys_mnt_log'
      FOR UPDATE;

      UPDATE SYS_KEY
         SET SYS_SEQ_NBR = SYS_SEQ_NBR + 1, UPDT_VER_NBR = UPDT_VER_NBR + 1
       WHERE TBL_NM = 'sys_mnt_log';

      COMMIT;
END
//

DELIMITER ;

DROP PROCEDURE IF EXISTS MNT_LOG;

DELIMITER //

CREATE PROCEDURE MNT_LOG (IN P_ACT_TM_MS_NBR   INTEGER,
                          IN P_SYS_MNT_NM      VARCHAR(100),
                          IN P_ACT_TXT         VARCHAR(500),
                          IN P_DB_OBJ_NM       VARCHAR(32),
                          IN P_MNT_DTL_TXT     VARCHAR(2000))

BEGIN

   DECLARE PKID   INTEGER DEFAULT 0;

   CALL GET_KEY(PKID);

   INSERT INTO SYS_MNT_LOG (SYS_MNT_LOG_ID,
                            CREAT_USER_ID,
                            CREAT_DTTM,
                            SRVR_NM,
                            ACT_TM_MS_NBR,
                            SYS_MNT_NM,
                            ACT_TXT,
                            DB_OBJ_NM,
                            MNT_DTL_TXT)
           VALUES (PKID,
                   CURRENT_USER,
                   UTC_TIMESTAMP,
                   GetHostName(),
                   P_ACT_TM_MS_NBR,
                   P_SYS_MNT_NM,
                   P_ACT_TXT,
                   P_DB_OBJ_NM,
                   P_MNT_DTL_TXT);
   COMMIT;
END
//

DELIMITER ;
