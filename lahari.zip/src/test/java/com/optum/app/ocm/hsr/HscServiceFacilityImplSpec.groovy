package com.optum.app.ocm.hsr

import com.optum.app.ocm.common.member.businesslogic.Member
import com.optum.rf.bl.businesslogic.HistoryBusinessLogic
import com.optum.rf.common.messages.GlobalMessages
import com.optum.rf.common.security.data.UserSecurityVO
import com.optum.rf.core.util.UhgCalendar
import com.optum.rf.dao.controller.session.SessionThreadLocal
import com.optum.rf.dao.data.ValueObject
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.util.UhgCalendarUtilities
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.optum.rf.test.core.assertion.ValueObjectAsserter
import com.optum.rf.web.controller.session.HttpUserSession
import com.optum.app.common.constants.CommonReferenceConstants
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.Hsc
import com.optum.app.common.hsr.businesslogic.HscFacility
import com.optum.app.common.hsr.businesslogic.HscService
import com.optum.app.common.hsr.businesslogic.HscServiceNonFacility
import com.optum.app.common.hsr.businesslogic.HscTatPointHelper
import com.optum.app.common.hsr.businesslogic.impl.HscServiceFacilityImpl
import com.optum.app.common.hsr.constants.HsrReferenceConstants
import com.optum.app.common.hsr.data.HscFacilityVO
import com.optum.app.common.hsr.data.HscServiceFacilityVO
import com.optum.app.common.hsr.data.HscServiceVO
import com.optum.app.common.hsr.data.HscVO
import spock.lang.Unroll

class HscServiceFacilityImplSpec extends HsrReadLogicSpecification {

    private HscServiceFacilityImpl hscServiceFacility
    private DataAccessObject<HscServiceFacilityVO> mockDao
    private Hsc mockHsc
    private HscFacility mockHscFacility
    private HscService hscService
    private HscServiceNonFacility hscServiceNonFacility
    private HscTatPointHelper tatPointHelper
    private Member member
    private PersistenceHelper persistenceHelper
    private HistoryBusinessLogic historyBusinessLogic

    def setup() {
        SessionThreadLocal.session = new HttpUserSession(userSecurity: new UserSecurityVO(userID: "test"))
        hscServiceFacility = new HscServiceFacilityImpl()
        hscService = Mock(HscService)
        mockDao = Mock(DataAccessObject)
        mockHscFacility = Mock(HscFacility)
        mockHsc = Mock(Hsc)
        hscServiceNonFacility = Mock(HscServiceNonFacility)
        tatPointHelper = Mock(HscTatPointHelper)
        member = Mock(Member)
        historyBusinessLogic = Mock(HistoryBusinessLogic)
        persistenceHelper = Mock(PersistenceHelper)

        hscServiceFacility.setRequiredDao(mockDao)
        hscServiceFacility.setRequiredHsc(mockHsc)
        hscServiceFacility.setRequiredHscFacility(mockHscFacility)
        hscServiceFacility.setRequiredHscService(hscService)
        hscServiceFacility.setRequiredTatPointHelper(tatPointHelper)
        hscServiceFacility.setRequiredHistoryBusinessLogic(historyBusinessLogic)
        hscServiceFacility.setRequiredPersistenceHelper(persistenceHelper)

    }

    @Unroll()
    def "isValidExpectedProcedureDate: valid and invalid conditions where expectedProcedureDate = #expectedProcDate validation result is #expectedResult"() {
        when:
        boolean actualResult = hscServiceFacility.isValidExpectedProcedureDate(expectedProcDate)

        then:
        assert actualResult == expectedResult

        where:
        expectedProcDate                     | expectedResult
        UhgCalendarUtilities.getTodaysDate() | true
        null                                 | false
    }

    def "isValid: Validate hscID and  hscServiceSequenceNum"() {
        when:
        boolean actualResult = hscServiceFacility.isValid((long) 123, (short) 1)

        then:
        1 * mockDao.isValid(_ as ReadProperties)
        0 * _

        }

    def "validate HscServiceFacilityVO"(){
        given:
        long hscID = 4
        HscVO hscVO = new HscVO()
        HscServiceFacilityVO hscServiceNonFacilityVO = new HscServiceFacilityVO(hscID: (long)123, skipValidation: skipValidation, serviceSettingType: HsrReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY)

        when:
        hscServiceFacility.validate(hscServiceNonFacilityVO,true)

        then:
        1 * mockHsc.read(_) >> hscVO

        where: skipValidation << [ false, true ]
    }

    def "Test to validate validateInpatientProcedureDates"(){
        given:
        def mockServiceFacilityVO = new HscServiceFacilityVO(expectedProcedureDate: UhgCalendarUtilities.getTodaysDate(),actualProcedureDate:java.sql.Date.valueOf("2016-01-15"))
        def HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: (long)123, expectedAdmissionDate: UhgCalendarUtilities.getTodaysDate() - 1, expectedDischargeDate: UhgCalendarUtilities.getTodaysDate() + 1,actualAdmissionDateTime:UhgCalendarUtilities.getTodaysCalendarInUserTimeZone(),actualDischargeDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone())

        when:
        hscServiceFacility.validateInpatientProcedureDates(mockServiceFacilityVO,hscFacilityVO)

        then:
        0 * _
    }

    def "Test to execute Update"(){
        given:
        HscServiceFacilityVO vo = new HscServiceFacilityVO(serviceStartDate: UhgCalendarUtilities.getTodaysDate())
        when:
        hscServiceFacility.executeUpdate(vo)

        then:
        1 * persistenceHelper.update(_ as HscServiceFacilityVO)
        1 * historyBusinessLogic.addHistoryVO(_ as ValueObject)
        0 * _
    }

    def "Validate  convertUhgCalendarToDate"(){
        given:
        UhgCalendar uhgCalendar = new UhgCalendar()
        when:
        hscServiceFacility.convertUhgCalendarToDate(uhgCalendar)

        then:
        0 * _
    }

   def "Test to validateYears"(){
        given:
        def mockServiceFacilityVO = new HscServiceFacilityVO(expectedProcedureDate: UhgCalendarUtilities.getTodaysDate())
        def hscVO = new HscVO(serviceSettingType:CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT)
        def HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: (long)123, expectedAdmissionDate: UhgCalendarUtilities.getTodaysDate() - 1, expectedDischargeDate: UhgCalendarUtilities.getTodaysDate() + 1,actualAdmissionDateTime:UhgCalendarUtilities.getTodaysCalendarInUserTimeZone(),actualDischargeDateTime:UhgCalendarUtilities.getTodaysCalendarInUserTimeZone() )

        when:
        hscServiceFacility.validateYears(mockServiceFacilityVO,hscVO,hscFacilityVO)

        then:
        1 * mockDao.read(_ as ReadProperties)>> new HscServiceFacilityVO(hscID: 1234)
        0 * _
    }

    def " validate clearSSOFields"(){
        given:
        def hscServiceFacilityVO = new HscServiceFacilityVO(ssoObtainedInd: false)

        when:
        hscServiceFacility.clearSSOFields(hscServiceFacilityVO)

        then:

        0 * _
    }

    def "Validate For Complete Intake"() {
        setup:
        def hscVO = new HscVO(hscStatusType: HsrReferenceConstants.HSCSTATUSTYPE_CANCELLED, serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT)

        when:
        hscServiceFacility.validateForCompleteIntake((long) 123, (short) 1, "1")

        then:
        (1.._) * mockDao.read(_ as ReadProperties) >> serviceFacilityVO
        if(serviceFacilityVO) {
            1 * mockHsc.read(_) >> hscVO
        }

        where: serviceFacilityVO << [ new HscServiceFacilityVO(hscID: 1234), null ]
    }

    def "ensure Procedure Dates Are Within Service Period validation"() {
        setup:
        def newHscID = 2
        def HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: newHscID,
                                                            serviceSettingType: serviceSetting,
                                                            actualAdmissionDateTime: UhgCalendarUtilities.getTodaysDate() - 5,
                                                            expectedAdmissionDate: UhgCalendarUtilities.getTodaysDate() - 1,
                                                            expectedDischargeDate: facilityExpectedDischargeDate,
                                                            actualDischargeDateTime: actualDischargeDate)
        def List<HscServiceVO> serviceVOs = new ArrayList<HscServiceVO>()
        serviceVOs.add(new HscServiceVO(serviceSeqNum: 1))
        when:
        hscServiceFacility.ensureProcedureDatesAreWithinServicePeriod(hscFacilityVO)

        then:
        1 * hscService.listByHscID(newHscID, false) >> serviceVOs
        2 * mockDao.read(_ as ReadProperties) >> new HscServiceFacilityVO(expectedProcedureDate: UhgCalendarUtilities.getTodaysDate() - 2,
                                                                          actualProcedureDate: actualProcedureDate)
        1 * mockHsc.read(0L) >> new HscVO()
        1 * mockHscFacility.read(0) >> new HscFacilityVO(serviceSettingType: serviceSetting,
                                                                actualDischargeDateTime: actualDischargeDate,
                                                                actualAdmissionDateTime: UhgCalendarUtilities.getTodaysDate() - 5,
                                                                expectedAdmissionDate: UhgCalendarUtilities.getTodaysDate() - 1,
                                                                expectedDischargeDate: facilityExpectedDischargeDate)
        1 * persistenceHelper.update(_ as HscServiceFacilityVO)
        1 * historyBusinessLogic.addHistoryVO(_ as HscServiceFacilityVO)
        0 * _

        where:
        facilityExpectedDischargeDate            | actualProcedureDate                      | actualDischargeDate                  | serviceSetting
        // test for complete expected date range
        UhgCalendarUtilities.getTodaysDate() + 1 | UhgCalendarUtilities.getTodaysDate()     | null                                 | HsrReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY
        // test for open expected date range (no discharge)
        null                                     | UhgCalendarUtilities.getTodaysDate() + 1 | null                                 | HsrReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY
        // verify actual proc dates are within actual date range
        UhgCalendarUtilities.getTodaysDate() + 1 | null                                     | null                                 | HsrReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY
        UhgCalendarUtilities.getTodaysDate() + 1 | null                                     | null                                 | HsrReferenceConstants.SERVICESETTINGTYPE_INPATIENT
        // test for complete actual date range
        UhgCalendarUtilities.getTodaysDate() + 1 | UhgCalendarUtilities.getTodaysDate() + 2 | UhgCalendarUtilities.getTodaysDate() | HsrReferenceConstants.SERVICESETTINGTYPE_INPATIENT
        // test for open actual date range (no discharge)
        UhgCalendarUtilities.getTodaysDate() + 1 | UhgCalendarUtilities.getTodaysDate() - 6 | null                                 | HsrReferenceConstants.SERVICESETTINGTYPE_INPATIENT
    }

    def "validateExpectedProcedureDate: invalid condition"() {
        setup:
        def mockServiceFacilityVO = new HscServiceFacilityVO(expectedProcedureDate: null)

        when:
        hscServiceFacility.validateExpectedProcedureDate(mockServiceFacilityVO)

        then:
        ValueObjectAsserter.assertMessageExists(mockServiceFacilityVO, FieldConstants.EXPECTEDPROCEDUREDATE, GlobalMessages.ERR_REQUIRED_VALUE)
    }

    def "testIfReadmissionWithin30DaysOfDischargeDateIndicator"() {
        setup:
        def serviceSettingType = CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT
        def memberID = 123
        def newHscFacilityVO = new HscFacilityVO(placeOfServiceCode: CommonReferenceConstants.PLACEOFSERVICE_ACUTE_HOSPITAL)
        when:
        boolean returnflag = mockHscFacility.isReadmissionWithin30DaysOfDischargeDateIndicator(serviceSettingType, memberID, newHscFacilityVO)
        then:
        returnflag == false
    }

    def "testIfReadmissionWithin30DaysOfDischargeDateIndicator set to false"() {
        setup:
        def serviceSettingType = CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT
        def memberID = 123
        def newHscFacilityVO = new HscFacilityVO(placeOfServiceCode: CommonReferenceConstants.PLACEOFSERVICE_ACUTE_HOSPITAL)
        when:
        boolean returnflag = mockHscFacility.isReadmissionWithin30DaysOfDischargeDateIndicator(serviceSettingType, memberID, newHscFacilityVO)
        then:
        returnflag == false
    }

    def "test getHscServiceFacilityVOs"() {
        setup:

        when:
        hscServiceFacility.getHscServiceFacilityVOs(123456L)

        then:
        1 * mockDao.list(_ as QueryProperties)
        0 * _
    }

    def "test executeAdd"() {
        setup:
        HscServiceFacilityVO hscServiceFacilityVO = new HscServiceFacilityVO()

        when:
        hscServiceFacility.executeAdd(hscServiceFacilityVO)

        then:
        1 * persistenceHelper.add(_ as HscServiceFacilityVO)
        1 * historyBusinessLogic.addHistoryVO(_ as HscServiceFacilityVO)
        1 * mockHsc.read(0) >> new HscVO(hscStatusType: HsrReferenceConstants.HSCSTATUSTYPE_OPEN)
        1 * hscService.read(0L, _)
        1 * hscService.derivePotentialUrJurisdictions(null)
        1 * tatPointHelper.logIntakeCompleteTatPointForService(0L, _)
        0 * _
    }

}
