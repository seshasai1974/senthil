package com.optum.app.ocm.hsr

import com.optum.app.ocm.common.activity.businesslogic.Activity
import com.optum.app.ocm.common.member.businesslogic.Member
import com.optum.rf.dao.constants.SystemSecurityConstants
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.test.core.spock.ReadLogicSpecification
import com.uhg.app.common.constants.spclcare.TableConstants
import com.optum.app.common.hsr.businesslogic.Hsc
import com.optum.app.common.hsr.businesslogic.impl.AbstractHscDecisionActivity
import com.optum.app.common.hsr.data.AbstractHscDecisionActivityVO
import com.optum.app.common.hsr.data.HscVO

class AbstractHscDecisionActivitySpec extends HsrReadLogicSpecification {

     Activity activity;
     Hsc hsc;
     Member member;
     
    AbstractHscDecisionActivityImpl abstractHscDecisionActivityImpl

    //creating inner class for AbstractHscDecisionActivity(abstract class) and providing dummy implementation for its abstract methods
    class AbstractHscDecisionActivityImpl extends AbstractHscDecisionActivity {
        protected  AbstractHscDecisionActivityImpl(String tableName) {
            super(TableConstants.HSC_FACL_DECN_ACTV);
        }
        //abstract method dummy implementation
        protected void validateNewDecisionActivity(AbstractHscDecisionActivityVO vo, boolean update) {
        }
        //abstract method dummy implementation
        protected DataAccessObject getDao() {
        }
    }
    
    def setup(){
        abstractHscDecisionActivityImpl = new AbstractHscDecisionActivityImpl(TableConstants.HSC_FACL_DECN_ACTV)
        
        activity = Mock(Activity)
        hsc = Mock(Hsc)
        member = Mock(Member)

        abstractHscDecisionActivityImpl.setRequiredActivity(activity)
        abstractHscDecisionActivityImpl.setRequiredHsc(hsc)
        abstractHscDecisionActivityImpl.setRequiredMember(member)
    }
    
    def "Test valid validate"(){
        setup:
        AbstractHscDecisionActivityVO vo = new AbstractHscDecisionActivityVO(hscID: 12345678)
        when:
        abstractHscDecisionActivityImpl.validate(vo,false)
        then:
        0 * _
        !vo.errorMessagesExist()
    }

    def "Test valid validate for system user skip validation"(){
        setup:
        AbstractHscDecisionActivityVO vo = new AbstractHscDecisionActivityVO(hscID: 12345678,changeUserID:SystemSecurityConstants.SYSTEM_USER)
        HscVO hscVO = new HscVO(hscStatusType: "2")

        when:
        abstractHscDecisionActivityImpl.validate(vo,false)
        then:
        0 * _
        !vo.errorMessagesExist()
    }

}
