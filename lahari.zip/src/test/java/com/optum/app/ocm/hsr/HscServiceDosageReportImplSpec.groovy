package com.optum.app.ocm.hsr

import com.optum.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.HscAttribute
import com.optum.app.common.hsr.businesslogic.HscMeasurement
import com.optum.app.common.hsr.businesslogic.HscSpecialtyProcedure
import com.optum.app.common.hsr.businesslogic.impl.HscServiceDosageReportImpl
import com.optum.app.common.hsr.data.HscAttributeVO
import com.optum.app.common.hsr.data.HscMeasurementVO
import com.optum.app.common.hsr.data.HscServiceDosageReportVO
import com.optum.app.common.hsr.data.HscSpecialtyProcedureVO
import com.optum.app.ocm.ref.businesslogic.CustomerReference
import com.optum.app.shared.constants.SpclCareConstants
import com.optum.app.shared.constants.SpclCareReferenceConstants
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.exception.CreateException
import com.optum.rf.dao.sql.exception.RemoveException
import com.optum.rf.dao.sql.query.ReadProperties
import spock.lang.Unroll

class HscServiceDosageReportImplSpec extends HsrReadLogicSpecification {
    HscServiceDosageReportImpl hscServiceDosageReport
    DataAccessObject<HscServiceDosageReportVO> dao
    HscAttribute hscAttribute
    HscMeasurement hscMeasurement
    HscSpecialtyProcedure hscSpecialtyProcedure
    CustomerReference reference

    def setup(){
        hscAttribute = Mock(HscAttribute)
        hscMeasurement = Mock(HscMeasurement)
        hscSpecialtyProcedure = Mock(HscSpecialtyProcedure)
        reference = Mock(CustomerReference)

        hscServiceDosageReport = new HscServiceDosageReportImpl(
                hscAttribute: hscAttribute,
                hscMeasurement: hscMeasurement,
                hscSpecialtyProcedure: hscSpecialtyProcedure,
                reference: reference
        )
        dao = Mock(DataAccessObject)

        hscServiceDosageReport.setRequiredDao(dao)
    }

    def 'test isValid'(){
        Long hscID = new Random().nextLong().abs()
        short serviceSeqNum = (short) new Random().nextInt(Short.MAX_VALUE)
        String dosageType = SpclCareReferenceConstants.DOSAGE_TYPE_INITIAL

        when:
        hscServiceDosageReport.isValid(hscID, serviceSeqNum, dosageType)

        then:
        1 * dao.isValid({ ReadProperties rp ->
            serviceSeqNum == rp.getKeyValue(FieldConstants.SERVICESEQNUM)
        })
        0 * _
    }

    def 'test read'(){
        Long hscID = new Random().nextLong().abs()
        short serviceSeqNum = (short) new Random().nextInt(Short.MAX_VALUE)
        String dosageType = SpclCareReferenceConstants.DOSAGE_TYPE_INITIAL

        when:
        hscServiceDosageReport.read(hscID, serviceSeqNum, dosageType)

        then:
        1 * dao.read({ ReadProperties rp ->
            serviceSeqNum == rp.getKeyValue(FieldConstants.SERVICESEQNUM)
        })
        0 * _
    }

    def 'recordInitialDosage - add new'(){
        given:
        Long hscID = new Random().nextLong().abs()
        short serviceSeqNum = (short) new Random().nextInt(Short.MAX_VALUE)
        List<HscServiceDosageReportVO> vos = [new HscServiceDosageReportVO(
                hscID: hscID,
                serviceSeqNum: serviceSeqNum,
                dosageType: SpclCareReferenceConstants.DOSAGE_TYPE_INITIAL,
                procedureFrequencyType: SpclCareConstants.PROCEDUREFREQUENCY_DAYS
        )]

        when:
        hscServiceDosageReport.recordInitialDosage(hscID, vos,_ as String,_ as String,_ as String)

        then:
        1 * dao.list(_) >> null
        1 * reference.getReferenceDisplay(FieldConstants.PROCEDUREFREQUENCYTYPE, SpclCareConstants.PROCEDUREFREQUENCY_DAYS, 0) >> "Days"
        1 * dao.addBatch(vos)
        0 * _
    }

    def 'recordInitialDosage - update: different # of records'(){
        given:
        long hscID = new Random().nextLong().abs()
        List<HscServiceDosageReportVO> addRecords = [new HscServiceDosageReportVO(
                hscID: hscID,
                serviceSeqNum: 1,
                dosageType: SpclCareReferenceConstants.DOSAGE_TYPE_INITIAL,
                drugPolicyID: new Random().nextLong().abs(),
                procedureFrequencyDesc: "days"
        )]
        long oldPolicyID = new Random().nextLong().abs()
        List<HscServiceDosageReportVO> oldDosages = [
                new HscServiceDosageReportVO(
                        hscID: hscID,
                        serviceSeqNum: 1,
                        dosageType:SpclCareReferenceConstants.DOSAGE_TYPE_INITIAL,
                        drugPolicyID: oldPolicyID
                ),
                new HscServiceDosageReportVO(
                        hscID: hscID,
                        serviceSeqNum: 2,
                        dosageType:SpclCareReferenceConstants.DOSAGE_TYPE_INITIAL,
                        drugPolicyID: oldPolicyID
                )
        ]

        when:
        hscServiceDosageReport.recordInitialDosage(hscID, addRecords, _ as String, _ as String, _ as String)

        then:
        1 * dao.list(_) >> oldDosages
        1 * dao.deleteBatch(oldDosages)
        1 * dao.addBatch(addRecords)
        0 * _
    }

    def 'recordInitialDosage - exception: delete'(){
        given:
        long hscID = new Random().nextLong().abs()
        List<HscServiceDosageReportVO> addRecords = [new HscServiceDosageReportVO(
                hscID: hscID,
                serviceSeqNum: 1,
                dosageType: SpclCareReferenceConstants.DOSAGE_TYPE_INITIAL,
                drugPolicyID: new Random().nextLong().abs(),
                procedureFrequencyDesc: "days"
        )]
        long oldPolicyID = new Random().nextLong().abs()
        List<HscServiceDosageReportVO> oldDosages = [
                new HscServiceDosageReportVO(
                        hscID: hscID,
                        serviceSeqNum: 1,
                        dosageType:SpclCareReferenceConstants.DOSAGE_TYPE_INITIAL,
                        drugPolicyID: oldPolicyID
                ),
                new HscServiceDosageReportVO(
                        hscID: hscID,
                        serviceSeqNum: 2,
                        dosageType:SpclCareReferenceConstants.DOSAGE_TYPE_INITIAL,
                        drugPolicyID: oldPolicyID
                )
        ]

        when:
        hscServiceDosageReport.recordInitialDosage(hscID, addRecords, _ as String, _ as String, _ as String)

        then:
        1 * dao.list(_) >> oldDosages
        1 * dao.deleteBatch(oldDosages) >> {throw new RemoveException()}
        0 * dao.addBatch(addRecords)
        0 * _
        thrown(RemoveException)
    }

    def 'recordInitialDosage - exception: add'(){
        given:
        long hscID = new Random().nextLong().abs()
        List<HscServiceDosageReportVO> addRecords = [new HscServiceDosageReportVO(
                hscID: hscID,
                serviceSeqNum: 1,
                dosageType: SpclCareReferenceConstants.DOSAGE_TYPE_INITIAL,
                drugPolicyID: new Random().nextLong().abs(),
                procedureFrequencyDesc: "days"
        )]
        long oldPolicyID = new Random().nextLong().abs()
        List<HscServiceDosageReportVO> oldDosages = [
                new HscServiceDosageReportVO(
                        hscID: hscID,
                        serviceSeqNum: 1,
                        dosageType:SpclCareReferenceConstants.DOSAGE_TYPE_INITIAL,
                        drugPolicyID: oldPolicyID
                ),
                new HscServiceDosageReportVO(
                        hscID: hscID,
                        serviceSeqNum: 2,
                        dosageType:SpclCareReferenceConstants.DOSAGE_TYPE_INITIAL,
                        drugPolicyID: oldPolicyID
                )
        ]

        when:
        hscServiceDosageReport.recordInitialDosage(hscID, addRecords, _ as String, _ as String, _ as String)

        then:
        1 * dao.list(_) >> oldDosages
        1 * dao.deleteBatch(oldDosages)
        1 * dao.addBatch(addRecords) >> {throw new CreateException()}
        0 * _
        thrown(CreateException)
    }

    /**
     * For full dosage parameter changed scenarios, refer to dosage changed test
     */
    def 'recordInitialDosage - update: dosage parameter changed'(){
        given:
        long hscID = new Random().nextLong().abs()
        List<HscServiceDosageReportVO> list = [new HscServiceDosageReportVO(
                hscID: hscID,
                serviceSeqNum: 1,
                dosageType: SpclCareReferenceConstants.DOSAGE_TYPE_INITIAL,
                procedureFrequencyType: SpclCareConstants.PROCEDUREFREQUENCY_DAYS,
                frequencyOfDosage: 3,
                procedureUnitOfMeasureType: SpclCareConstants.DRUGUNITOFMEASURETYPE_MG,
                procedureUnitCount: 30
        )]

        when:
        hscServiceDosageReport.recordInitialDosage(hscID, list, SpclCareReferenceConstants.HSC_TREATMENT_THERAPY_CONTINUATION, null, _ as String)

        then:
        1 * dao.list(_) >> list
        1 * hscAttribute.read(hscID, SpclCareReferenceConstants.HSCATTRIBUTETYPE_INIT_CHNG_TREATMENT) >> new HscAttributeVO(hscAttributeValue: SpclCareReferenceConstants.HSC_TREATMENT_THERAPY_INITIAL)
        1 * hscSpecialtyProcedure.read(hscID) >> new HscSpecialtyProcedureVO(diseaseState: "Achalasia")
        then:
        1 * dao.deleteBatch(list)
        1 * reference.getReferenceDisplay(FieldConstants.PROCEDUREFREQUENCYTYPE, SpclCareConstants.PROCEDUREFREQUENCY_DAYS, 0) >> "Days"
        1 * dao.addBatch(list)
        0 * _
    }

    @Unroll
    def 'test dosageParametersChanged #param'(){
        given:
        long hscID = new Random().nextLong().abs()

        when:
        boolean result = hscServiceDosageReport.dosageParametersChanged(hscID, treatment, weight, diseaseState)

        then:
        1 * hscAttribute.read(hscID, SpclCareReferenceConstants.HSCATTRIBUTETYPE_INIT_CHNG_TREATMENT) >> new HscAttributeVO(hscAttributeValue: SpclCareReferenceConstants.HSC_TREATMENT_THERAPY_INITIAL)
        (0..1) * hscMeasurement.read(hscID,SpclCareReferenceConstants.MEASUREMENTTYPE_WEIGHT) >> new HscMeasurementVO(measurementValueDescription: "50")
        1 * hscSpecialtyProcedure.read(hscID) >> new HscSpecialtyProcedureVO(diseaseState: "Achalasia")
        0 * _
        result == expectedResult

        where:
        param           | expectedResult    | treatment                                                     | weight    | diseaseState
        "treatment"     | true              | SpclCareReferenceConstants.HSC_TREATMENT_THERAPY_CONTINUATION | "50"      | "Achalasia"
        "weight"        | true              | SpclCareReferenceConstants.HSC_TREATMENT_THERAPY_INITIAL      | "60"      | "Achalasia"
        "diseaseState"  | true              | SpclCareReferenceConstants.HSC_TREATMENT_THERAPY_INITIAL      | "50"      | "Hip osteoarthritis"
        "all"           | true              | SpclCareReferenceConstants.HSC_TREATMENT_THERAPY_CONTINUATION | "60"      | "Hip osteoarthritis"
        "none"          | false             | SpclCareReferenceConstants.HSC_TREATMENT_THERAPY_INITIAL      | "50"      | "Achalasia"
        "empty weight"  | false             | SpclCareReferenceConstants.HSC_TREATMENT_THERAPY_INITIAL      | ""        | "Achalasia"
        "null weight"   | false             | SpclCareReferenceConstants.HSC_TREATMENT_THERAPY_INITIAL      | null      | "Achalasia"
    }

    /**
     * For full dosage update scenarios, refer to shouldUpdate test
     */
    def 'recordInitialDosage - new dosage meets update criteria'(){
        given:
        long hscID = new Random().nextLong().abs()
        List<HscServiceDosageReportVO> addRecords = [new HscServiceDosageReportVO(
                hscID: hscID,
                serviceSeqNum: 1,
                dosageType: SpclCareReferenceConstants.DOSAGE_TYPE_INITIAL,
                procedureUnitCount: 400,
                procedureFrequencyType: SpclCareConstants.PROCEDUREFREQUENCY_DAYS
        )]
        List<HscServiceDosageReportVO> oldDosages = [
                new HscServiceDosageReportVO (
                        hscID: hscID,
                        serviceSeqNum: 1,
                        dosageType:SpclCareReferenceConstants.DOSAGE_TYPE_INITIAL,
                        procedureUnitCount: 30
                )
        ]


        when:
        hscServiceDosageReport.recordInitialDosage(hscID, addRecords, SpclCareReferenceConstants.HSC_TREATMENT_THERAPY_INITIAL, null, "Achalasia")

        then:
        1 * dao.list(_) >> oldDosages
        1 * dao.deleteBatch(oldDosages)
        1 * reference.getReferenceDisplay(FieldConstants.PROCEDUREFREQUENCYTYPE, SpclCareConstants.PROCEDUREFREQUENCY_DAYS, 0) >> "Days"
        1 * dao.addBatch(addRecords)
        0 * _
    }

    /**
     * no new dosage incoming
     * Use diseaseState to trigger dosageParametersChanged.
     * for full parameters changed scenarios refer to specific test
     */
    @Unroll
    def "recordInitialDosage - remove dosage: #testCase"(){
        given:
        long hscID = new Random().nextLong().abs()

        when:
        hscServiceDosageReport.recordInitialDosage(hscID, [], SpclCareReferenceConstants.HSC_TREATMENT_THERAPY_INITIAL, null, "Achalasia")

        then:
        1 * dao.list(_) >> oldDosages
        (0..1) * hscAttribute.read(hscID, SpclCareReferenceConstants.HSCATTRIBUTETYPE_INIT_CHNG_TREATMENT) >> new HscAttributeVO(hscAttributeValue: SpclCareReferenceConstants.HSC_TREATMENT_THERAPY_INITIAL)
        (0..1) * hscSpecialtyProcedure.read(hscID) >> new HscSpecialtyProcedureVO(diseaseState: diseaseState)
        then:
        deletes * dao.deleteBatch(oldDosages)
        0 * _

        where:
        testCase                | deletes   | diseaseState          | oldDosages
        "no existing dosages"   | 0         | "Hip osteoarthritis"  | []
        "dosages removed"       | 1         | "Hip osteoarthritis"  | [new HscServiceDosageReportVO()]
        "dosages not removed"   | 0         | "Achalasia"           | [new HscServiceDosageReportVO()]
    }

/**
     * For full dosage conversion scenarios (including weight-based dosage)
     * and frequencyExceeds scenarios (including frequency unit "TIMES"),
     * refer to respective tests
     */
    @Unroll
    def 'test shouldUpdate: #testCase'(){
        given:
        long hscID = new Random().nextLong().abs()
        List<HscServiceDosageReportVO> addRecords = [new HscServiceDosageReportVO(
                hscID: hscID,
                serviceSeqNum: 1,
                dosageType: SpclCareReferenceConstants.DOSAGE_TYPE_INITIAL,
                procedureUnitCount: procUnitCount,
                procedureUnitOfMeasureType: procUnitMeasure,
                procedureFrequencyType: SpclCareConstants.PROCEDUREFREQUENCY_WEEKS,
                unitPerFrequencyCount: unitPerFreq,
                frequencyOfDosage: 2
        )]
        List<HscServiceDosageReportVO> oldDosages = [
                new HscServiceDosageReportVO (
                        hscID: hscID,
                        serviceSeqNum: 1,
                        dosageType:SpclCareReferenceConstants.DOSAGE_TYPE_INITIAL,
                        procedureUnitCount: 30,
                        procedureUnitOfMeasureType: SpclCareConstants.DRUGUNITOFMEASURETYPE_MG,
                        procedureFrequencyType: SpclCareConstants.PROCEDUREFREQUENCY_WEEKS,
                        unitPerFrequencyCount: 2,
                        frequencyOfDosage: 2
                )
        ]

        when:
        boolean result = hscServiceDosageReport.shouldUpdate(addRecords, oldDosages, _ as String)

        then:
        0 * _
        result == shouldUpdate

        where:
        testCase                    | shouldUpdate  | procUnitCount | procUnitMeasure                               | unitPerFreq
        "dosage not converted"      | true          | 30            | SpclCareConstants.DRUGUNITOFMEASURETYPE_UNITS | 2
        "dosage new > existing"     | true          | 100           | SpclCareConstants.DRUGUNITOFMEASURETYPE_MG    | 2
        "dosage new < existing"     | false         | 10            | SpclCareConstants.DRUGUNITOFMEASURETYPE_MG    | 2
        "frequency new > existing"  | true          | 30            | SpclCareConstants.DRUGUNITOFMEASURETYPE_MG    | 3
        "frequency new < existing"  | false         | 30            | SpclCareConstants.DRUGUNITOFMEASURETYPE_MG    | 1
    }

    /**
     * tests cover supported conversions, some unsupported conversions, and some inconvertible scenarios
     * Unsupported conversions are mathematically possible, but not realistically expected, such as grams to micrograms.
     * Those scenarios are indicated by (U)
     */
    @Unroll
    def "test convertDosage: #testCase"(){
        given:
        double procedureUnitCount = 30d
        final String weight = "50"

        when:
        Double result = hscServiceDosageReport.convertDosage(fromUnit, toUnit, procedureUnitCount, weight)

        then:
        0 * _
        dosageConverted == (result != null)

        where:
        testCase                    | dosageConverted   | fromUnit  | toUnit
        "g to g (no conversion)"    | true              | SpclCareConstants.DRUGUNITOFMEASURETYPE_GRAMS | SpclCareConstants.DRUGUNITOFMEASURETYPE_GRAMS
        "mg to mg (no conversion)"  | true              | SpclCareConstants.DRUGUNITOFMEASURETYPE_MG | SpclCareConstants.DRUGUNITOFMEASURETYPE_MG
        "g to mg"                   | true              | SpclCareConstants.DRUGUNITOFMEASURETYPE_GRAMS | SpclCareConstants.DRUGUNITOFMEASURETYPE_MG
        "mg to mcg"                 | true              | SpclCareConstants.DRUGUNITOFMEASURETYPE_MG | SpclCareConstants.DRUGUNITOFMEASURETYPE_MCG
        "mg/kg to mcg/kg"           | true              | SpclCareConstants.DRUGUNITOFMEASURETYPE_MG_PER_KG | SpclCareConstants.DRUGUNITOFMEASURETYPE_MCG_PER_KG
        "mg to g"                   | true              | SpclCareConstants.DRUGUNITOFMEASURETYPE_MG | SpclCareConstants.DRUGUNITOFMEASURETYPE_GRAMS
        "mcg to mg"                 | true              | SpclCareConstants.DRUGUNITOFMEASURETYPE_MCG | SpclCareConstants.DRUGUNITOFMEASURETYPE_MG
        "mcg/kg to mg/kg"           | true              | SpclCareConstants.DRUGUNITOFMEASURETYPE_MCG_PER_KG | SpclCareConstants.DRUGUNITOFMEASURETYPE_MG_PER_KG
        "mg to mg/kg"               | true              | SpclCareConstants.DRUGUNITOFMEASURETYPE_MG | SpclCareConstants.DRUGUNITOFMEASURETYPE_MG_PER_KG
        "mcg to mcg/kg"             | true              | SpclCareConstants.DRUGUNITOFMEASURETYPE_MCG | SpclCareConstants.DRUGUNITOFMEASURETYPE_MCG_PER_KG
        "units to units/kg"         | true              | SpclCareConstants.DRUGUNITOFMEASURETYPE_UNITS | SpclCareConstants.DRUGUNITOFMEASURETYPE_UNITS_PER_KG
        "g to mg/kg"                | true              | SpclCareConstants.DRUGUNITOFMEASURETYPE_GRAMS | SpclCareConstants.DRUGUNITOFMEASURETYPE_MG_PER_KG
        "mg to mcg/kg"              | true              | SpclCareConstants.DRUGUNITOFMEASURETYPE_MG | SpclCareConstants.DRUGUNITOFMEASURETYPE_MCG_PER_KG
        "g to mcg (U)"              | false             | SpclCareConstants.DRUGUNITOFMEASURETYPE_GRAMS | SpclCareConstants.DRUGUNITOFMEASURETYPE_MCG
        "mcg to g (U)"              | false             | SpclCareConstants.DRUGUNITOFMEASURETYPE_MCG | SpclCareConstants.DRUGUNITOFMEASURETYPE_GRAMS
        "units to g"                | false             | SpclCareConstants.DRUGUNITOFMEASURETYPE_UNITS | SpclCareConstants.DRUGUNITOFMEASURETYPE_GRAMS
        "mcg to units"              | false             | SpclCareConstants.DRUGUNITOFMEASURETYPE_MCG | SpclCareConstants.DRUGUNITOFMEASURETYPE_UNITS
    }

    /**
     * weight invalid parse scenarios
     */
    @Unroll
    def "test convertDosage invalid weight: #testCase"(){
        given:
        double procedureUnitCount = 30d

        when:
        Double result = hscServiceDosageReport.convertDosage(fromUnit, toUnit, procedureUnitCount, weight)

        then:
        0 * _
        result == null

        where:
        testCase                    | weight    | fromUnit  | toUnit
        "mg to mg/kg (null)"        | null      | SpclCareConstants.DRUGUNITOFMEASURETYPE_MG | SpclCareConstants.DRUGUNITOFMEASURETYPE_MG_PER_KG
        "mcg to mcg/kg (NaN)"       | "false"   | SpclCareConstants.DRUGUNITOFMEASURETYPE_MG | SpclCareConstants.DRUGUNITOFMEASURETYPE_MG_PER_KG
        "units to units/kg (zero)"  | "0"       | SpclCareConstants.DRUGUNITOFMEASURETYPE_MG | SpclCareConstants.DRUGUNITOFMEASURETYPE_MG_PER_KG
        "mg to mcg/kg (empty)"      | ""        | SpclCareConstants.DRUGUNITOFMEASURETYPE_MG | SpclCareConstants.DRUGUNITOFMEASURETYPE_MCG_PER_KG
    }

    @Unroll
    def "test frequencyExceeds: #testCase"(){
        given:
        HscServiceDosageReportVO newVO = new HscServiceDosageReportVO(
                procedureFrequencyType: procFreqType,
                unitPerFrequencyCount: unitsPerFreq,
                frequencyOfDosage: freqOfDosage
        )
        HscServiceDosageReportVO existVO = new HscServiceDosageReportVO(
                procedureFrequencyType: oldProcFreqType,
                unitPerFrequencyCount: 2,
                frequencyOfDosage: 2
        )

        when:
        boolean result = hscServiceDosageReport.frequencyExceeds(newVO, existVO)

        then:
        0 * _
        result == frequencyExceeds

        where:
        testCase                        | frequencyExceeds  | procFreqType  | oldProcFreqType   | unitsPerFreq  | freqOfDosage
        "incompatible frequency types"  | true              | SpclCareConstants.PROCEDUREFREQUENCY_WEEKS    | SpclCareConstants.PROCEDUREFREQUENCY_MONTHS   | 2 | 2
        "units per freq: new > exist"   | true              | SpclCareConstants.PROCEDUREFREQUENCY_DAYS     | SpclCareConstants.PROCEDUREFREQUENCY_DAYS     | 3 | 2
        "units per freq: new < exist"   | false             | SpclCareConstants.PROCEDUREFREQUENCY_WEEKS    | SpclCareConstants.PROCEDUREFREQUENCY_WEEKS    | 1 | 2
        "freq of dosage: new > exist"   | false             | SpclCareConstants.PROCEDUREFREQUENCY_MONTHS   | SpclCareConstants.PROCEDUREFREQUENCY_MONTHS   | 2 | 3
        "freq of dosage: new < exist"   | true              | SpclCareConstants.PROCEDUREFREQUENCY_WEEKS    | SpclCareConstants.PROCEDUREFREQUENCY_WEEKS    | 2 | 1
        "freq of dosage times: new > exist"   | true        | SpclCareConstants.PROCEDUREFREQUENCY_TIMES    | SpclCareConstants.PROCEDUREFREQUENCY_TIMES    | 2 | 3
        "freq of dosage times: new < exist"   | false       | SpclCareConstants.PROCEDUREFREQUENCY_TIMES    | SpclCareConstants.PROCEDUREFREQUENCY_TIMES    | 2 | 1
    }

}
