package com.optum.app.ocm.hsr

import com.optum.app.ocm.ref.businesslogic.CustomerReference
import com.optum.rf.common.messages.GlobalMessages
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.exception.FinderException
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.Hsc
import com.optum.app.common.hsr.businesslogic.impl.HscDecisionMemberCoverageImpl
import com.optum.app.common.hsr.data.HscDecisionMemberCoverageVO
import com.optum.app.common.hsr.data.HscVO
import spock.lang.Unroll

/**
 * Contains tests for com.uhg.app.icue.hsr.hsc.businesslogic.impl.HscDecisionMemberCoverageImpl
 */
class HscDecisionMemberCoverageImplSpec extends HsrReadLogicSpecification {
    HscDecisionMemberCoverageImpl hscDecisionMemberCoverage

    DataAccessObject dao
    PersistenceHelper persistenceHelper
    CustomerReference customerReference
    Hsc hsc

    def setup() {
        hscDecisionMemberCoverage = new HscDecisionMemberCoverageImpl()
        dao = Mock(DataAccessObject)
        persistenceHelper = Mock(PersistenceHelper)
        customerReference = Mock(CustomerReference)
        hsc = Mock(Hsc)

        hscDecisionMemberCoverage.setRequiredDao(dao)
        hscDecisionMemberCoverage.setRequiredPersistenceHelper(persistenceHelper)
        hscDecisionMemberCoverage.setRequiredCustomerReference(customerReference)
        hscDecisionMemberCoverage.setRequiredHsc(hsc)
    }

    @Unroll
    def "is valid #testCase"(){
        given:
        long hscID = 1
        short decisionMemberCoverageSeqNum = 2
        ReadProperties rp = getReadProperties(hscID, decisionMemberCoverageSeqNum)

        when:
        boolean retVal = hscDecisionMemberCoverage.isValid(hscID, decisionMemberCoverageSeqNum)

        then:
        1 * dao.isValid(rp) >> expectedVal
        0 * _
        retVal == expectedVal

        where:
        testCase | expectedVal
        "passes" | true
        "fails"  | false
    }

    def "valid read"(){
        given:
        HscDecisionMemberCoverageVO vo = new HscDecisionMemberCoverageVO(hscID: 1 as Long, decisionMemberCoverageSeqNum: 2 as Short, coverageType: "A", marketType: "00", productType: "EP1", productCategoryType: "0", lineOfBusinessType: "1", obligorID: "01", sharedArrangementID: "00", fundingArrangementID: "A", claimPlatformID: "02", cdhPlanType: "2", productCode: "3")
        ReadProperties rp = getReadProperties(vo.getHscID(), vo.getDecisionMemberCoverageSeqNum())

        when:
        HscDecisionMemberCoverageVO retVO = hscDecisionMemberCoverage.read(vo.getHscID(), vo.getDecisionMemberCoverageSeqNum())
        def display = retVO.getCirrusBenefitBundleOptionDisplay()

        then:
        1 * dao.read(rp) >> vo
        0 * _
        retVO == vo
    }

    def "invalid read - VO is null"(){
        given:
        long hscID = 1
        short decisionMemberCoverageSeqNum = 2
        ReadProperties rp = getReadProperties(hscID, decisionMemberCoverageSeqNum)

        when:
        HscDecisionMemberCoverageVO retVO = hscDecisionMemberCoverage.read(hscID, decisionMemberCoverageSeqNum)

        then: "VO is null, dao throws FinderException which is caught. Return value is null."
        1 * dao.read(rp) >> {throw new FinderException()}
        0 * _
        notThrown FinderException
        !retVO
    }

    def "valid update"(){
        given:
        HscDecisionMemberCoverageVO vo = new HscDecisionMemberCoverageVO(hscID: 40019402)

        when: "attempting to update VO"
        hscDecisionMemberCoverage.update(vo)

        then: "error is thrown; update is not supported"
        thrown UnsupportedOperationException
    }

    def "valid delete"(){
        given:
        HscDecisionMemberCoverageVO vo = new HscDecisionMemberCoverageVO(hscID: 40019402)

        when: "attempting to delete VO"
        hscDecisionMemberCoverage.delete(vo)

        then: "error is thrown; delete is not supported"
        thrown UnsupportedOperationException
    }

    private ReadProperties getReadProperties(long hscID, short decisionMemberCoverageSeqNum){
        ReadProperties rp = new ReadProperties([FieldConstants.HSCID, FieldConstants.DECISIONMEMBERCOVERAGESEQNUM] as String[])
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        rp.setKeyValue(FieldConstants.DECISIONMEMBERCOVERAGESEQNUM, decisionMemberCoverageSeqNum)
        return rp
    }
}