package com.optum.app.ocm.hsr

import com.optum.app.common.hsr.businesslogic.Hsc
import com.optum.app.common.hsr.businesslogic.HscMemberCoverage
import com.optum.app.common.hsr.businesslogic.impl.HscServiceLineProgramTypeHelperImpl
import com.optum.app.common.hsr.constants.HsrReferenceConstants
import com.optum.app.common.hsr.data.HscMemberCoverageVO
import com.optum.app.common.hsr.data.HscServiceVO
import com.optum.app.common.hsr.data.HscVO
import spock.lang.Unroll

class HscServiceLineProgramTypeHelperSpec extends HsrReadLogicSpecification {
    HscServiceLineProgramTypeHelperImpl hscServiceLineProgramTypeHelper

    Hsc hsc
    HscMemberCoverage hscMemberCoverage

    def setup() {
        hscServiceLineProgramTypeHelper = new HscServiceLineProgramTypeHelperImpl()

        hsc = Mock(Hsc)
        hscMemberCoverage = Mock(HscMemberCoverage)
        hscServiceLineProgramTypeHelper.setRequiredHsc(hsc)
        hscServiceLineProgramTypeHelper.setRequiredHscMemberCoverage(hscMemberCoverage)
    }

    @Unroll
    def "deriveRadCardProgramTypeBasedOnProcedureCode #specialProcessType #programTypeCode #radiMedNecType #cardiMedNecType #vendorTypeID #channelSourceType"() {
        given:
        def hscVO = new HscVO(hscID: 1, memberCoverageSeqNum: 1, specialProcessType: specialProcessType, vendorTypeID: vendorTypeID)
        def hscMemberCoverageVO = new HscMemberCoverageVO(hscID: 1, medNecessityApplInd: medNecessityAppInd,
                radiologyMedNecType: radiMedNecType, cardiologyMedNecType: cardiMedNecType)
        def hscServiceVO = new HscServiceVO(hscID: 1)

        when:
        def serviceReviewTypeCode = hscServiceLineProgramTypeHelper.getServiceReviewTypeCode(hscServiceVO)

        then:
        1 * hsc.readUnhydrated(hscServiceVO.hscID) >> hscVO
        1 * hscMemberCoverage.read(hscVO.hscID, hscVO.memberCoverageSeqNum) >> hscMemberCoverageVO
        0 * _

        and:
        serviceReviewTypeCode == expectedResult

        where:
        specialProcessType | programTypeCode | radiMedNecType | cardiMedNecType | vendorTypeID | channelSourceType | medNecessityAppInd | expectedResult
        '00'               | '11'            | 'N'            | 'A'             | null         | null              | true               | 'MA'
        '15'               | '11'            | 'A'            | 'N'             | null         | null              | true               | 'MA'
        '08'               | '11'            | 'A'            | 'A'             | null         | null              | true               | 'MA'
        '08'               | '11'            | 'N'            | 'N'             | null         | null              | true               | 'MA'
        '05'               | null            | 'E'            | 'E'             | null         | null              | true               | 'MA'
        '05'               | null            | 'E'            | 'E'             | null         | null              | false              | 'MN'
    }

    @Unroll
    def "deriveOncologyProgramType #programTypeCode #medNecessityAppInd"() {
        given:
        def hscVO = new HscVO(hscID: 1, memberCoverageSeqNum: 1, specialProcessType: specialProcessType, vendorTypeID: vendorTypeID)
        def hscMemberCoverageVO = new HscMemberCoverageVO(hscID: 1, medNecessityApplInd: medNecessityAppInd,
                radiologyMedNecType: radiMedNecType, cardiologyMedNecType: cardiMedNecType, oncologyMedNecType: oncMedNecType)
        def hscServiceVO = new HscServiceVO(hscID: 1)

        when:
        def serviceReviewTypeCode = hscServiceLineProgramTypeHelper.getServiceReviewTypeCode(hscServiceVO)

        then:
        1 * hsc.readUnhydrated(hscServiceVO.hscID) >> hscVO
        1 * hscMemberCoverage.read(hscVO.hscID, hscVO.memberCoverageSeqNum) >> hscMemberCoverageVO
        0 * _

        and:
        serviceReviewTypeCode == expectedResult

        where:
        specialProcessType | programTypeCode                                                | radiMedNecType | oncMedNecType | cardiMedNecType | vendorTypeID | channelSourceType | medNecessityAppInd | expectedResult
        '15'               | HsrReferenceConstants.SERVICEREVIEWTYPE_ONCOLOGY_AUTHORIZATION | 'N'            | 'N'           | 'E'             | null         | null              | false              | HsrReferenceConstants.SERVICEREVIEWTYPE_MEDICAL_NOTIFICATION
        '15'               | HsrReferenceConstants.SERVICEREVIEWTYPE_ONCOLOGY_NOTIFICATION  | 'N'            | 'N'           | 'E'             | null         | null              | false              | HsrReferenceConstants.SERVICEREVIEWTYPE_MEDICAL_NOTIFICATION
    }
}
