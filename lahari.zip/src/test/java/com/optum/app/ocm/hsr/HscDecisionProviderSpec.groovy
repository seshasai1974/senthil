package com.optum.app.ocm.hsr

import com.optum.rf.bl.spring.TransactionInterceptor
import com.optum.rf.core.locator.ServiceLocator
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.optum.app.common.hsr.businesslogic.impl.HscDecisionProviderImpl
import com.optum.app.common.hsr.data.HscDecisionProviderVO
import com.optum.app.common.hsr.data.HscProviderVO

class HscDecisionProviderSpec extends HsrReadLogicSpecification {

    HscDecisionProviderImpl hscDecisionProvider

    DataAccessObject dao
    PersistenceHelper persistenceHelper
    ServiceLocator serviceLocator
    TransactionInterceptor transactionInterceptor

    def setup() {
        hscDecisionProvider = new HscDecisionProviderImpl()

        dao = Mock(DataAccessObject)
        persistenceHelper = Mock(PersistenceHelper)
        serviceLocator = Mock(ServiceLocator)
        transactionInterceptor = Mock(TransactionInterceptor)

        hscDecisionProvider.setRequiredDao(dao)
        hscDecisionProvider.setRequiredPersistenceHelper(persistenceHelper)
        hscDecisionProvider.setRequiredServiceLocator(serviceLocator)
        hscDecisionProvider.setRequiredTransactionInterceptor(transactionInterceptor)
    }

    /**
     * Test valid add.
     */
    def "Test Valid Add"() {
        setup:
        def vo = new HscDecisionProviderVO()

        when:
        hscDecisionProvider.add(vo)

        then:
        1 * persistenceHelper.add(_ as HscDecisionProviderVO)
        0 * _

        expect:
        !vo.errorMessagesExist()
    }

    /**
     * Test valid delete.
     */
    def "Test Valid Delete"() {
        setup:
        def vo = new HscDecisionProviderVO()

        when:
        hscDecisionProvider.delete(vo)

        then:
        1 * persistenceHelper.delete(_ as HscDecisionProviderVO)
        0 * _

        expect:
        !vo.errorMessagesExist()
    }

    /**
     * Test valid update.
     */
    def "Test Valid Update"() {
        setup:
        def vo = new HscDecisionProviderVO()

        when:
        hscDecisionProvider.update(vo)

        then:
        1 * persistenceHelper.update(_ as HscDecisionProviderVO)
        0 * _

        expect:
        !vo.errorMessagesExist()
    }

    def "Test isValid"() {
        setup:

        when:
        hscDecisionProvider.isValid(123456L, (short)1)

        then:
        1 * dao.isValid(_ as ReadProperties)
        0 * _
    }

    def "Test read"() {
        setup:

        when:
        hscDecisionProvider.read(123456L, (short)1)

        then:
        1 * dao.read(_ as ReadProperties)
        0 * _
    }

    def "Test createAndSaveDecisionProviderFromHscProvider"() {
        setup:
        HscProviderVO hscProviderVO = new HscProviderVO()

        when:
        hscDecisionProvider.createAndSaveDecisionProviderFromHscProvider(hscProviderVO)

        then:
        1 * persistenceHelper.add(_ as HscDecisionProviderVO)
        0 * _
    }

}

