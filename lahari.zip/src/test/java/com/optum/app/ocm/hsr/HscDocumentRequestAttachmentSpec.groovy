package com.optum.app.ocm.hsr

import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.optum.app.common.hsr.businesslogic.HscDocumentRequestAttachment
import com.optum.app.common.hsr.businesslogic.impl.HscDocumentRequestAttachmentImpl
import com.optum.app.common.hsr.data.HscDocumentRequestAttachmentVO

class HscDocumentRequestAttachmentSpec extends HsrReadLogicSpecification {

    HscDocumentRequestAttachment hscDocumentRequestAttachment
    DataAccessObject dao
    PersistenceHelper persistenceHelper

    def setup() {
        dao = Mock(DataAccessObject)
        persistenceHelper = Mock(PersistenceHelper)

        hscDocumentRequestAttachment = new HscDocumentRequestAttachmentImpl()

        hscDocumentRequestAttachment.dao = dao
        hscDocumentRequestAttachment.setRequiredPersistenceHelper(persistenceHelper)
    }

    def "test isValid"() {
        setup:

        when:
        hscDocumentRequestAttachment.isValid(123456L)

        then:
        1 * dao.isValid(_ as ReadProperties)
        0 * _._
    }

    def "test read"() {
        setup:

        when:
        hscDocumentRequestAttachment.read(123456L)

        then:
        1 * dao.read(_ as ReadProperties)
        0 * _._
    }

    def "test readByDocReqId"() {
        setup:

        when:
        hscDocumentRequestAttachment.readByDocReqId(123L)

        then:
        1 * dao.read(_ as ReadProperties)
        0 * _._
    }

    def "test listByDoc"() {
        setup:

        when:
        hscDocumentRequestAttachment.listByDoc(123L)

        then:
        1 * dao.list(_ as QueryProperties)
        0 * _._
    }

    def "test deleteAll"() {
        setup:

        when:
        hscDocumentRequestAttachment.deleteAll(123L)

        then:
        1 * dao.read(_ as ReadProperties) >> new HscDocumentRequestAttachmentVO()
        1 * persistenceHelper.delete(_ as HscDocumentRequestAttachmentVO)
        1 * dao.read(_ as ReadProperties)
        0 * _._
    }

    def "test checkForDuplicate"() {
        setup:

        when:
        hscDocumentRequestAttachment.checkForDuplicate('abc')

        then:
        1 * dao.list(_ as QueryProperties) >> [ new HscDocumentRequestAttachmentVO() ]
        0 * _._
    }

    def "test updateDocumentAttachment"() {
        setup:
        double doubleVal = 123456789

        when:
        hscDocumentRequestAttachment.updateDocumentAttachment(123L, 456L, 'attchID', 'extType', 'fName', doubleVal, 'fType', 'origAttchID')

        then:
        1 * dao.isDuplicate(_ as QueryProperties)
        1 * persistenceHelper.add(_ as HscDocumentRequestAttachmentVO)
        0 * _._
    }

    def "test saveDocumentAttachment"() {
        setup:
        double doubleVal = 123456789

        when:
        hscDocumentRequestAttachment.saveDocumentAttachment(123L, 'attchID', 'extType', 'fName', doubleVal, 'fType', 'origAttchID')

        then:
        1 * dao.isDuplicate(_ as QueryProperties)
        1 * persistenceHelper.add(_ as HscDocumentRequestAttachmentVO)
        0 * _._
    }

}
