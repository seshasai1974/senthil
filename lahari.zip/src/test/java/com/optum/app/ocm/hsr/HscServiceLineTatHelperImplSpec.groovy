package com.optum.app.ocm.hsr

import com.optum.app.ocm.common.member.businesslogic.Member
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.util.UhgCalendarUtilities
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.optum.app.common.constants.CommonReferenceConstants
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.Hsc
import com.optum.app.common.hsr.businesslogic.HscFacility
import com.optum.app.common.hsr.businesslogic.HscFacilityDecision
import com.optum.app.common.hsr.businesslogic.HscMemberCoverage
import com.optum.app.common.hsr.businesslogic.HscService
import com.optum.app.common.hsr.businesslogic.HscServiceDecision
import com.optum.app.common.hsr.businesslogic.HscServiceNonFacility
import com.optum.app.common.hsr.businesslogic.HscServiceTatPoint
import com.optum.app.common.hsr.businesslogic.HscServiceTatSummary
import com.optum.app.common.hsr.businesslogic.HscServiceUrJurisdiction
import com.optum.app.common.hsr.businesslogic.HscTatPointHelper
import com.optum.app.common.hsr.businesslogic.impl.HscServiceLineTatHelperImpl
import com.optum.app.common.hsr.constants.HsrReferenceConstants
import com.optum.app.common.hsr.data.HscFacilityVO
import com.optum.app.common.hsr.data.HscMemberCoverageVO
import com.optum.app.common.hsr.data.HscServiceDecisionVO
import com.optum.app.common.hsr.data.HscServiceTatSummaryVO
import com.optum.app.common.hsr.data.HscServiceUrJurisdictionVO
import com.optum.app.common.hsr.data.HscVO
import com.optum.app.common.member.core.data.BaseMemberCoverageVO
import com.optum.app.common.member.core.data.MemberVO

import java.sql.Date

class HscServiceLineTatHelperImplSpec extends HsrReadLogicSpecification {
    private DataAccessObject dao
    private HscService hscService
    private PersistenceHelper persistenceHelper
    private HscServiceLineTatHelperImpl hscServiceLineTatHelper
    private HscServiceTatSummary hscServiceTatSummary
    private HscTatPointHelper tatPointHelper
    private HscServiceTatPoint hscServiceTatPoint
    private HscFacilityDecision hscFacilityDecision
    private HscServiceDecision hscServiceDecision
    private HscServiceUrJurisdiction hscServiceUrJurisdiction
    private Hsc hsc
    private HscMemberCoverage hscMemberCoverage
    private HscServiceNonFacility hscServiceNonFacility
    private HscFacility hscFacility
    private Member member
    
    private static final long HSC_ID = 1234L
    private static final long MEMBER_ID = 555L
    private static final short SERVICE_SEQ_NBR = 2
    private static final short MEMBER_COVERAGE_SEQNUM = 1
    private static final String POLICY_ISSUE_STATE = "MD"
    private static final short DEFAULT_SERVICE_SEQ_NBR = 0
    private static final String REVIEW_PRIORITY_TYPE = '4'
    private static final Date BIRTH_DATE = new Date(1, 1, 1)
    def setup() {
        dao = Mock(DataAccessObject)
        hscService = Mock(HscService)
        persistenceHelper = Mock(PersistenceHelper)
        tatPointHelper = Mock(HscTatPointHelper)
        hscServiceTatSummary = Mock(HscServiceTatSummary)
        hscServiceTatPoint = Mock(HscServiceTatPoint)
        hscFacilityDecision = Mock(HscFacilityDecision)
        hscServiceDecision = Mock(HscServiceDecision)
        hsc = Mock(Hsc)
        hscServiceUrJurisdiction = Mock(HscServiceUrJurisdiction)
        hscMemberCoverage = Mock(HscMemberCoverage)
        hscServiceNonFacility = Mock(HscServiceNonFacility)
        hscFacility = Mock(HscFacility)
        member = Mock(Member)

        hscServiceLineTatHelper = new HscServiceLineTatHelperImpl()
        hscServiceLineTatHelper.setRequiredHscService(hscService)
        hscServiceLineTatHelper.setRequiredHscServiceTatSummary(hscServiceTatSummary)
        hscServiceLineTatHelper.setRequiredHscServiceTatSummary(hscServiceTatSummary)
        hscServiceLineTatHelper.setRequiredHscServiceDecision(hscServiceDecision)
        hscServiceLineTatHelper.setRequiredHsc(hsc)
        hscServiceLineTatHelper.setRequiredHscMemberCoverage(hscMemberCoverage)
        hscServiceLineTatHelper.setRequiredHscServiceNonFacility(hscServiceNonFacility)
        hscServiceLineTatHelper.setRequiredHscFacility(hscFacility)
        hscServiceLineTatHelper.setRequiredMember(member)
    }

    def "performFacilityLineTATForCNS: Null CNS TatRequirements found"() {
        given:
        String triggeredTatPoint = HsrReferenceConstants.TATPOINTTYPE_NOTIFICATION
        HscVO hscVO = new HscVO(hscID: HSC_ID, memberID: MEMBER_ID, memberCoverageSeqNum: MEMBER_COVERAGE_SEQNUM, reviewPriorityType: HsrReferenceConstants.REVIEWPRIORITYTYPE_CONCURRENTEXPEDITED, serviceSettingType: HsrReferenceConstants.SERVICESETTINGTYPE_INPATIENT)
        MemberVO memberVO = new MemberVO(memberID: MEMBER_ID, birthDate: BIRTH_DATE)
        BaseMemberCoverageVO baseMemberCoverageVO = new BaseMemberCoverageVO()
        HscMemberCoverageVO hscMbrCovVO = new HscMemberCoverageVO(baseMemberCoverageVO, HSC_ID)
        hscMbrCovVO.policyIssueState = POLICY_ISSUE_STATE
        hscMbrCovVO.hscID = HSC_ID
        hscMbrCovVO.memberCoverageSeqNum = MEMBER_COVERAGE_SEQNUM

        when:
        hscServiceLineTatHelper.performFacilityLineTATForCNS(HSC_ID, triggeredTatPoint, UhgCalendarUtilities.getMMDDYYDate("021510").getSQLDate(), false)

        then:
        notThrown(NullPointerException)
        1 * hsc.readUnhydrated(HSC_ID) >> hscVO
        1 * hscMemberCoverage.getPrimaryMemberCoverage(HSC_ID, MEMBER_COVERAGE_SEQNUM) >> hscMbrCovVO
        1 * member.read(MEMBER_ID) >> memberVO
        0 * _
    }

    def "performFacilityLineTATForCNS: Empty CNS TatRequirements found"() {
        given:
        String triggeredTatPoint = HsrReferenceConstants.TATPOINTTYPE_NOTIFICATION
        HscVO hscVO = new HscVO(hscID: HSC_ID, memberID: MEMBER_ID, memberCoverageSeqNum: MEMBER_COVERAGE_SEQNUM, reviewPriorityType: HsrReferenceConstants.REVIEWPRIORITYTYPE_CONCURRENTEXPEDITED, serviceSettingType: HsrReferenceConstants.SERVICESETTINGTYPE_INPATIENT)
        MemberVO memberVO = new MemberVO(memberID: MEMBER_ID, birthDate: BIRTH_DATE)
        HscMemberCoverageVO hscMbrCovVO = new HscMemberCoverageVO(policyIssueState: POLICY_ISSUE_STATE, hscID: HSC_ID, memberCoverageSeqNum: MEMBER_COVERAGE_SEQNUM)

        when:
        hscServiceLineTatHelper.performFacilityLineTATForCNS(HSC_ID, triggeredTatPoint, UhgCalendarUtilities.getMMDDYYDate("021510").getSQLDate(), false)

        then:
        1 * hsc.readUnhydrated(HSC_ID) >> hscVO
        1 * hscMemberCoverage.getPrimaryMemberCoverage(HSC_ID, MEMBER_COVERAGE_SEQNUM) >> hscMbrCovVO
        1 * member.read(MEMBER_ID) >> memberVO
        0 * _
    }

    def "performFacilityLineTATForCNS: triggered TatPointType is Decision with DecisionOutcomeType match record not in TatRequirementCNS"() {
        given:
        String triggeredTatPoint = HsrReferenceConstants.TATPOINTTYPE_DECISION
        HscVO hscVO = new HscVO(hscID: HSC_ID, memberID: MEMBER_ID, memberCoverageSeqNum: MEMBER_COVERAGE_SEQNUM, reviewPriorityType: HsrReferenceConstants.REVIEWPRIORITYTYPE_CONCURRENTEXPEDITED, serviceSettingType: HsrReferenceConstants.SERVICESETTINGTYPE_INPATIENT, decisionID: 123)
        MemberVO memberVO = new MemberVO(memberID: MEMBER_ID, birthDate: BIRTH_DATE)
        HscMemberCoverageVO hscMbrCovVO = new HscMemberCoverageVO(policyIssueState: POLICY_ISSUE_STATE, hscID: HSC_ID, memberCoverageSeqNum: MEMBER_COVERAGE_SEQNUM)

        when:
        hscServiceLineTatHelper.performFacilityLineTATForCNS(HSC_ID, triggeredTatPoint, UhgCalendarUtilities.getMMDDYYDate("021510").getSQLDate(), false)

        then:
        1 * hsc.readUnhydrated(HSC_ID) >> hscVO
        1 * hscMemberCoverage.getPrimaryMemberCoverage(HSC_ID, MEMBER_COVERAGE_SEQNUM) >> hscMbrCovVO
        1 * member.read(MEMBER_ID) >> memberVO
        0 * _
    }

    def "performUrJurisdictionForServiceLine no applicableTatRequirementVOs"() {
        given:
        HscServiceDecisionVO hscServiceDecisionVO = new HscServiceDecisionVO()
        HscVO hscVO = new HscVO(reviewPriorityType: "TEST")
        List<HscServiceUrJurisdictionVO> applicableUrJurisdictionVOs = [new HscServiceUrJurisdictionVO(serviceSeqNum: 1)]

        when:
        hscServiceLineTatHelper.performUrJurisdictionForServiceLine(HSC_ID, SERVICE_SEQ_NBR)

        then:
        1 * hscServiceDecision.getLastServiceDecision(HSC_ID, SERVICE_SEQ_NBR) >> hscServiceDecisionVO
        1 * hsc.readUnhydrated(HSC_ID, FieldConstants.REVIEWPRIORITYTYPE) >> hscVO
        0 * _
    }

    def "performUrJurisdictionForServiceLine with applicableTatRequirementVOs"() {
        given:
        HscServiceDecisionVO hscServiceDecisionVO = new HscServiceDecisionVO()
        HscVO hscVO = new HscVO(reviewPriorityType: "TEST")
        List<HscServiceUrJurisdictionVO> applicableUrJurisdictionVOs = [new HscServiceUrJurisdictionVO(serviceSeqNum: 1)]
        HscServiceTatSummaryVO tatSummaryVO = new HscServiceTatSummaryVO(serviceSeqNum: SERVICE_SEQ_NBR, hscID: HSC_ID, tatRqrSeqNum: 4, urJurisCode: "3", tatUnitTypeId: "5", maxTatUnitCount: 6, displayTatUnitTypeId: "7")

        when:
        hscServiceLineTatHelper.performUrJurisdictionForServiceLine(HSC_ID, SERVICE_SEQ_NBR)

        then:
        1 * hscServiceDecision.getLastServiceDecision(HSC_ID, SERVICE_SEQ_NBR) >> hscServiceDecisionVO
        1 * hsc.readUnhydrated(HSC_ID, FieldConstants.REVIEWPRIORITYTYPE) >> hscVO
        0 * _
    }

    def "performFacilityLineTATForCNS: triggered TatPointType is Decision with DecisionOutcomeType that matches record in TatRequirementCNS"() {
        given:
        String triggeredTatPoint = HsrReferenceConstants.TATPOINTTYPE_DECISION
        HscVO hscVO = new HscVO(hscID: HSC_ID, memberID: MEMBER_ID, memberCoverageSeqNum: MEMBER_COVERAGE_SEQNUM, reviewPriorityType: HsrReferenceConstants.REVIEWPRIORITYTYPE_CONCURRENTEXPEDITED, serviceSettingType: HsrReferenceConstants.SERVICESETTINGTYPE_INPATIENT, decisionID: 123)
        MemberVO memberVO = new MemberVO(memberID: MEMBER_ID, birthDate: BIRTH_DATE)
        HscMemberCoverageVO hscMbrCovVO = new HscMemberCoverageVO(policyIssueState: POLICY_ISSUE_STATE, hscID: HSC_ID, memberCoverageSeqNum: MEMBER_COVERAGE_SEQNUM)

        when:
        hscServiceLineTatHelper.performFacilityLineTATForCNS(HSC_ID, triggeredTatPoint, UhgCalendarUtilities.getMMDDYYDate("021510").getSQLDate(), false)

        then:
        1 * hsc.readUnhydrated(HSC_ID) >> hscVO
        1 * hscMemberCoverage.getPrimaryMemberCoverage(HSC_ID, MEMBER_COVERAGE_SEQNUM) >> hscMbrCovVO
        1 * member.read(MEMBER_ID) >> memberVO
        0 * _
    }

    def "performFacilityLineTATForCNS: update TatSummary"() {
        given:
        String triggeredTatPoint = HsrReferenceConstants.TATPOINTTYPE_DECISION
        HscVO hscVO = new HscVO(hscID: HSC_ID, memberID: MEMBER_ID, memberCoverageSeqNum: MEMBER_COVERAGE_SEQNUM, reviewPriorityType: HsrReferenceConstants.REVIEWPRIORITYTYPE_CONCURRENTEXPEDITED, serviceSettingType: HsrReferenceConstants.SERVICESETTINGTYPE_INPATIENT, decisionID: 123)
        MemberVO memberVO = new MemberVO(memberID: MEMBER_ID, birthDate: BIRTH_DATE)
        HscMemberCoverageVO hscMbrCovVO = new HscMemberCoverageVO(policyIssueState: POLICY_ISSUE_STATE, hscID: HSC_ID, memberCoverageSeqNum: MEMBER_COVERAGE_SEQNUM)

        when: "Perform action is called on Facility line"
        hscServiceLineTatHelper.performFacilityLineTATForCNS(HSC_ID, triggeredTatPoint, UhgCalendarUtilities.getMMDDYYDate("021510").getSQLDate(), false)

        then:
        1 * hsc.readUnhydrated(HSC_ID) >> hscVO
        1 * hscMemberCoverage.getPrimaryMemberCoverage(HSC_ID, MEMBER_COVERAGE_SEQNUM) >> hscMbrCovVO
        1 * member.read(MEMBER_ID) >> memberVO
        0 * _
    }

    def "performFacilityLineTATForCNS: No EndTatPeriodType is found to EndDate"() {
        given:
        String triggeredTatPoint = HsrReferenceConstants.TATPOINTTYPE_DECISION
        HscVO hscVO = new HscVO(hscID: HSC_ID, memberID: MEMBER_ID, memberCoverageSeqNum: MEMBER_COVERAGE_SEQNUM, decisionID: 123, reviewPriorityType: HsrReferenceConstants.REVIEWPRIORITYTYPE_CONCURRENTEXPEDITED, serviceSettingType: HsrReferenceConstants.SERVICESETTINGTYPE_INPATIENT)
        MemberVO memberVO = new MemberVO(memberID: MEMBER_ID, birthDate: BIRTH_DATE)
        HscMemberCoverageVO hscMbrCovVO = new HscMemberCoverageVO(policyIssueState: POLICY_ISSUE_STATE, hscID: HSC_ID, memberCoverageSeqNum: MEMBER_COVERAGE_SEQNUM)

        when:
        hscServiceLineTatHelper.performFacilityLineTATForCNS(HSC_ID, triggeredTatPoint, UhgCalendarUtilities.getMMDDYYDate("021510").getSQLDate(), false)

        then:
        1 * hsc.readUnhydrated(HSC_ID) >> hscVO
        1 * hscMemberCoverage.getPrimaryMemberCoverage(HSC_ID, MEMBER_COVERAGE_SEQNUM) >> hscMbrCovVO
        1 * member.read(MEMBER_ID) >> memberVO
        0 * _
    }

    def "performFacilityLineTATForCNS: No TatSummary is found to EndDate"() {
        given:
        String triggeredTatPoint = HsrReferenceConstants.TATPOINTTYPE_DECISION
        HscVO hscVO = new HscVO(hscID: HSC_ID, memberID: MEMBER_ID, memberCoverageSeqNum: MEMBER_COVERAGE_SEQNUM, decisionID: 123, reviewPriorityType: HsrReferenceConstants.REVIEWPRIORITYTYPE_CONCURRENTEXPEDITED, serviceSettingType: HsrReferenceConstants.SERVICESETTINGTYPE_INPATIENT)
        MemberVO memberVO = new MemberVO(memberID: MEMBER_ID, birthDate: BIRTH_DATE)
        HscMemberCoverageVO hscMbrCovVO = new HscMemberCoverageVO(policyIssueState: POLICY_ISSUE_STATE, hscID: HSC_ID, memberCoverageSeqNum: MEMBER_COVERAGE_SEQNUM)

        when:
        hscServiceLineTatHelper.performFacilityLineTATForCNS(HSC_ID, triggeredTatPoint, UhgCalendarUtilities.getMMDDYYDate("021510").getSQLDate(), false)

        then:
        1 * hsc.readUnhydrated(HSC_ID) >> hscVO
        1 * hscMemberCoverage.getPrimaryMemberCoverage(HSC_ID, MEMBER_COVERAGE_SEQNUM) >> hscMbrCovVO
        1 * member.read(MEMBER_ID) >> memberVO
        0 * _
    }

    def "performFacilityLineTATForCNS: update workList"() {
        given:
        String triggeredTatPoint = HsrReferenceConstants.TATPOINTTYPE_DECISION
        boolean updateWorkList = true
        HscVO hscVO = new HscVO(hscID: HSC_ID, memberID: MEMBER_ID, memberCoverageSeqNum: MEMBER_COVERAGE_SEQNUM, reviewPriorityType: HsrReferenceConstants.REVIEWPRIORITYTYPE_CONCURRENTEXPEDITED, serviceSettingType: HsrReferenceConstants.SERVICESETTINGTYPE_INPATIENT)
        MemberVO memberVO = new MemberVO(memberID: MEMBER_ID, birthDate: BIRTH_DATE)
        HscMemberCoverageVO hscMbrCovVO = new HscMemberCoverageVO(policyIssueState: POLICY_ISSUE_STATE, hscID: HSC_ID, memberCoverageSeqNum: MEMBER_COVERAGE_SEQNUM)

        when:
        hscServiceLineTatHelper.performFacilityLineTATForCNS(HSC_ID, triggeredTatPoint, UhgCalendarUtilities.getMMDDYYDate("021510").getSQLDate(), updateWorkList)

        then:
        1 * hsc.readUnhydrated(HSC_ID) >> hscVO
        1 * hscMemberCoverage.getPrimaryMemberCoverage(HSC_ID, MEMBER_COVERAGE_SEQNUM) >> hscMbrCovVO
        1 * member.read(MEMBER_ID) >> memberVO
        0 * _
    }

    def "performFacilityLineTATForCNS: Do not update workList"() {
        given:
        String triggeredTatPoint = HsrReferenceConstants.TATPOINTTYPE_DECISION
        boolean updateWorkList = false
        HscVO hscVO = new HscVO(hscID: HSC_ID, memberID: MEMBER_ID, memberCoverageSeqNum: MEMBER_COVERAGE_SEQNUM, reviewPriorityType: HsrReferenceConstants.REVIEWPRIORITYTYPE_CONCURRENTEXPEDITED, serviceSettingType: HsrReferenceConstants.SERVICESETTINGTYPE_INPATIENT)
        MemberVO memberVO = new MemberVO(memberID: MEMBER_ID, birthDate: BIRTH_DATE)
        HscMemberCoverageVO hscMbrCovVO = new HscMemberCoverageVO(policyIssueState: POLICY_ISSUE_STATE, hscID: HSC_ID, memberCoverageSeqNum: MEMBER_COVERAGE_SEQNUM)

        when:
        hscServiceLineTatHelper.performFacilityLineTATForCNS(HSC_ID, triggeredTatPoint, UhgCalendarUtilities.getMMDDYYDate("021510").getSQLDate(), updateWorkList)

        then:
        1 * hsc.readUnhydrated(HSC_ID) >> hscVO
        1 * hscMemberCoverage.getPrimaryMemberCoverage(HSC_ID, MEMBER_COVERAGE_SEQNUM) >> hscMbrCovVO
        1 * member.read(MEMBER_ID) >> memberVO
        0 * _
    }

    def "performFacilityLineTATForCNS: Inpatient with serviceDetail as Mental Health validate Category when qurying TatRequirementCNS"() {
        given:
        String triggeredTatPoint = HsrReferenceConstants.TATPOINTTYPE_DECISION
        boolean updateWorkList = false
        HscVO hscVO = new HscVO(hscID: HSC_ID, memberID: MEMBER_ID, memberCoverageSeqNum: MEMBER_COVERAGE_SEQNUM, reviewPriorityType: HsrReferenceConstants.REVIEWPRIORITYTYPE_CONCURRENTEXPEDITED, serviceSettingType: HsrReferenceConstants.SERVICESETTINGTYPE_INPATIENT)
        MemberVO memberVO = new MemberVO(memberID: MEMBER_ID, birthDate: BIRTH_DATE)
        HscMemberCoverageVO hscMbrCovVO = new HscMemberCoverageVO(policyIssueState: POLICY_ISSUE_STATE, hscID: HSC_ID, memberCoverageSeqNum: MEMBER_COVERAGE_SEQNUM)

        when:
        hscServiceLineTatHelper.performFacilityLineTATForCNS(HSC_ID, triggeredTatPoint, UhgCalendarUtilities.getMMDDYYDate("021510").getSQLDate(), updateWorkList)

        then:
        1 * hsc.readUnhydrated(HSC_ID) >> hscVO
        1 * hscMemberCoverage.getPrimaryMemberCoverage(HSC_ID, MEMBER_COVERAGE_SEQNUM) >> hscMbrCovVO
        1 * member.read(MEMBER_ID) >> memberVO
        0 * _
    }

    def "performFacilityLineTATForCNS: Inpatient with serviceDetail as Substance-Abuse validate Category when qurying TatRequirementCNS"() {
        given:
        String triggeredTatPoint = HsrReferenceConstants.TATPOINTTYPE_DECISION
        boolean updateWorkList = false
        HscVO hscVO = new HscVO(hscID: HSC_ID, memberID: MEMBER_ID, memberCoverageSeqNum: MEMBER_COVERAGE_SEQNUM, reviewPriorityType: HsrReferenceConstants.REVIEWPRIORITYTYPE_CONCURRENTEXPEDITED, serviceSettingType: HsrReferenceConstants.SERVICESETTINGTYPE_INPATIENT)
        MemberVO memberVO = new MemberVO(memberID: MEMBER_ID, birthDate: BIRTH_DATE)
        HscMemberCoverageVO hscMbrCovVO = new HscMemberCoverageVO(policyIssueState: POLICY_ISSUE_STATE, hscID: HSC_ID, memberCoverageSeqNum: MEMBER_COVERAGE_SEQNUM)

        when:
        hscServiceLineTatHelper.performFacilityLineTATForCNS(HSC_ID, triggeredTatPoint, UhgCalendarUtilities.getMMDDYYDate("021510").getSQLDate(), updateWorkList)

        then:
        1 * hsc.readUnhydrated(HSC_ID) >> hscVO
        1 * hscMemberCoverage.getPrimaryMemberCoverage(HSC_ID, MEMBER_COVERAGE_SEQNUM) >> hscMbrCovVO
        1 * member.read(MEMBER_ID) >> memberVO
        0 * _
    }

    def "performFacilityLineTATForCNS: Inpatient with serviceDetail as other validate Category when qurying TatRequirementCNS"() {
        given:
        String triggeredTatPoint = HsrReferenceConstants.TATPOINTTYPE_DECISION
        boolean updateWorkList = false
        HscVO hscVO = new HscVO(hscID: HSC_ID, memberID: MEMBER_ID, memberCoverageSeqNum: MEMBER_COVERAGE_SEQNUM, reviewPriorityType: HsrReferenceConstants.REVIEWPRIORITYTYPE_CONCURRENTEXPEDITED, serviceSettingType: HsrReferenceConstants.SERVICESETTINGTYPE_INPATIENT)
        MemberVO memberVO = new MemberVO(memberID: MEMBER_ID, birthDate: BIRTH_DATE)
        HscMemberCoverageVO hscMbrCovVO = new HscMemberCoverageVO(policyIssueState: POLICY_ISSUE_STATE, hscID: HSC_ID, memberCoverageSeqNum: MEMBER_COVERAGE_SEQNUM)

        when:
        hscServiceLineTatHelper.performFacilityLineTATForCNS(HSC_ID, triggeredTatPoint, UhgCalendarUtilities.getMMDDYYDate("021510").getSQLDate(), updateWorkList)

        then:
        1 * hsc.readUnhydrated(HSC_ID) >> hscVO
        1 * hscMemberCoverage.getPrimaryMemberCoverage(HSC_ID, MEMBER_COVERAGE_SEQNUM) >> hscMbrCovVO
        1 * member.read(MEMBER_ID) >> memberVO
        0 * _
    }

    def "performFacilityLineTATForCNS: Inpatient with serviceDetail as Hospice validate Category when qurying TatRequirementCNS"() {
        given:
        String triggeredTatPoint = HsrReferenceConstants.TATPOINTTYPE_DECISION
        boolean updateWorkList = false
        HscVO hscVO = new HscVO(hscID: HSC_ID, memberID: MEMBER_ID, memberCoverageSeqNum: MEMBER_COVERAGE_SEQNUM, reviewPriorityType: HsrReferenceConstants.REVIEWPRIORITYTYPE_CONCURRENTEXPEDITED, serviceSettingType: HsrReferenceConstants.SERVICESETTINGTYPE_INPATIENT)
        MemberVO memberVO = new MemberVO(memberID: MEMBER_ID, birthDate: BIRTH_DATE)
        HscMemberCoverageVO hscMbrCovVO = new HscMemberCoverageVO(policyIssueState: POLICY_ISSUE_STATE, hscID: HSC_ID, memberCoverageSeqNum: MEMBER_COVERAGE_SEQNUM)

        when:
        hscServiceLineTatHelper.performFacilityLineTATForCNS(HSC_ID, triggeredTatPoint, UhgCalendarUtilities.getMMDDYYDate("021510").getSQLDate(), updateWorkList)

        then:
        1 * hsc.readUnhydrated(HSC_ID) >> hscVO
        1 * hscMemberCoverage.getPrimaryMemberCoverage(HSC_ID, MEMBER_COVERAGE_SEQNUM) >> hscMbrCovVO
        1 * member.read(MEMBER_ID) >> memberVO
        0 * _
    }

    def "performFacilityLineTATForCNS: OutpatientFacility with serviceDetail as Mental Health validate Category when qurying TatRequirementCNS"() {
        given:
        String triggeredTatPoint = HsrReferenceConstants.TATPOINTTYPE_DECISION
        boolean updateWorkList = false
        HscVO hscVO = new HscVO(hscID: HSC_ID, memberID: MEMBER_ID, memberCoverageSeqNum: MEMBER_COVERAGE_SEQNUM, reviewPriorityType: HsrReferenceConstants.REVIEWPRIORITYTYPE_CONCURRENTEXPEDITED, serviceSettingType: HsrReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY)
        MemberVO memberVO = new MemberVO(memberID: MEMBER_ID, birthDate: BIRTH_DATE)
        HscMemberCoverageVO hscMbrCovVO = new HscMemberCoverageVO(policyIssueState: POLICY_ISSUE_STATE, hscID: HSC_ID, memberCoverageSeqNum: MEMBER_COVERAGE_SEQNUM)

        when:
        hscServiceLineTatHelper.performFacilityLineTATForCNS(HSC_ID, triggeredTatPoint, UhgCalendarUtilities.getMMDDYYDate("021510").getSQLDate(), updateWorkList)

        then:
        1 * hsc.readUnhydrated(HSC_ID) >> hscVO
        1 * hscMemberCoverage.getPrimaryMemberCoverage(HSC_ID, MEMBER_COVERAGE_SEQNUM) >> hscMbrCovVO
        1 * member.read(MEMBER_ID) >> memberVO
        0 * _
    }

    def "performFacilityLineTATForCNS: OutpatientFacility with serviceDetail as Substance-Abuse validate Category when qurying TatRequirementCNS"() {
        given:
        String triggeredTatPoint = HsrReferenceConstants.TATPOINTTYPE_DECISION
        boolean updateWorkList = false
        HscVO hscVO = new HscVO(hscID: HSC_ID, memberID: MEMBER_ID, memberCoverageSeqNum: MEMBER_COVERAGE_SEQNUM, reviewPriorityType: HsrReferenceConstants.REVIEWPRIORITYTYPE_CONCURRENTEXPEDITED, serviceSettingType: HsrReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY)
        MemberVO memberVO = new MemberVO(memberID: MEMBER_ID, birthDate: BIRTH_DATE)
        HscMemberCoverageVO hscMbrCovVO = new HscMemberCoverageVO(policyIssueState: POLICY_ISSUE_STATE, hscID: HSC_ID, memberCoverageSeqNum: MEMBER_COVERAGE_SEQNUM)

        when:
        hscServiceLineTatHelper.performFacilityLineTATForCNS(HSC_ID, triggeredTatPoint, UhgCalendarUtilities.getMMDDYYDate("021510").getSQLDate(), updateWorkList)

        then:
        1 * hsc.readUnhydrated(HSC_ID) >> hscVO
        1 * hscMemberCoverage.getPrimaryMemberCoverage(HSC_ID, MEMBER_COVERAGE_SEQNUM) >> hscMbrCovVO
        1 * member.read(MEMBER_ID) >> memberVO
        0 * _
    }

    def "performFacilityLineTATForCNS: OutpatientFacility with serviceDetail as other validate Category when qurying TatRequirementCNS"() {
        given:
        String triggeredTatPoint = HsrReferenceConstants.TATPOINTTYPE_DECISION
        boolean updateWorkList = false
        HscVO hscVO = new HscVO(hscID: HSC_ID, memberID: MEMBER_ID, memberCoverageSeqNum: MEMBER_COVERAGE_SEQNUM, reviewPriorityType: HsrReferenceConstants.REVIEWPRIORITYTYPE_CONCURRENTEXPEDITED, serviceSettingType: HsrReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY)
        MemberVO memberVO = new MemberVO(memberID: MEMBER_ID, birthDate: BIRTH_DATE)
        HscMemberCoverageVO hscMbrCovVO = new HscMemberCoverageVO(policyIssueState: POLICY_ISSUE_STATE, hscID: HSC_ID, memberCoverageSeqNum: MEMBER_COVERAGE_SEQNUM)

        when:
        hscServiceLineTatHelper.performFacilityLineTATForCNS(HSC_ID, triggeredTatPoint, UhgCalendarUtilities.getMMDDYYDate("021510").getSQLDate(), updateWorkList)

        then:
        1 * hsc.readUnhydrated(HSC_ID) >> hscVO
        1 * hscMemberCoverage.getPrimaryMemberCoverage(HSC_ID, MEMBER_COVERAGE_SEQNUM) >> hscMbrCovVO
        1 * member.read(MEMBER_ID) >> memberVO
        0 * _
    }

    def "performFacilityLineTATForCNS: OutpatientFacility with serviceDetail as Hospice validate Category when qurying TatRequirementCNS"() {
        given:
        String triggeredTatPoint = HsrReferenceConstants.TATPOINTTYPE_DECISION
        boolean updateWorkList = false
        HscVO hscVO = new HscVO(hscID: HSC_ID, memberID: MEMBER_ID, memberCoverageSeqNum: MEMBER_COVERAGE_SEQNUM, reviewPriorityType: HsrReferenceConstants.REVIEWPRIORITYTYPE_CONCURRENTEXPEDITED, serviceSettingType: HsrReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY)
        MemberVO memberVO = new MemberVO(memberID: MEMBER_ID, birthDate: BIRTH_DATE)
        HscMemberCoverageVO hscMbrCovVO = new HscMemberCoverageVO(policyIssueState: POLICY_ISSUE_STATE, hscID: HSC_ID, memberCoverageSeqNum: MEMBER_COVERAGE_SEQNUM)

        when:
        hscServiceLineTatHelper.performFacilityLineTATForCNS(HSC_ID, triggeredTatPoint, UhgCalendarUtilities.getMMDDYYDate("021510").getSQLDate(), updateWorkList)

        then:
        1 * hsc.readUnhydrated(HSC_ID) >> hscVO
        1 * hscMemberCoverage.getPrimaryMemberCoverage(HSC_ID, MEMBER_COVERAGE_SEQNUM) >> hscMbrCovVO
        1 * member.read(MEMBER_ID) >> memberVO
        0 * _
    }

    private HscVO getHscVO(long hscID, boolean facility) {
        HscVO hscVO = new HscVO()
        hscVO.setHscID(hscID)
        if (facility) {
            HscFacilityVO facilityVO = new HscFacilityVO()
            facilityVO.setHscID(HSC_ID)
            hscVO.setHscFacilityVO(facilityVO)
            hscVO.setServiceSettingType(CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT)
        }

        return hscVO
    }
}
