package com.optum.app.ocm.hsr

import com.optum.app.ocm.common.activity.businesslogic.Activity
import com.optum.app.common.hsr.businesslogic.AbstractHscDecisionHelper
import com.optum.app.common.hsr.businesslogic.HscFacilityDecision
import com.optum.app.common.hsr.businesslogic.HscServiceDecision
import com.optum.app.common.hsr.businesslogic.impl.AbstractHscDecisionHelperImpl
import com.optum.app.common.hsr.constants.HsrReferenceConstants
import com.optum.app.common.hsr.data.HscFacilityDecisionVO
import com.optum.app.common.hsr.data.HscServiceDecisionVO
import com.optum.app.common.hsr.data.HscVO
import com.optum.app.ocm.common.workqueue.businesslogic.WorkQueueGroup
import spock.lang.Unroll

class AbstractHscDecisionHelperSpec extends HsrReadLogicSpecification {

    AbstractHscDecisionHelper abstractHscDecisionHelper

    private WorkQueueGroup workQueueGroup
    private Activity activity
    private HscFacilityDecision hscFacilityDecision
    private HscServiceDecision hscServiceDecision

    def setup() {
        abstractHscDecisionHelper = new AbstractHscDecisionHelperImpl()

        workQueueGroup = Mock(WorkQueueGroup)
        activity = Mock(Activity)
        hscFacilityDecision = Mock(HscFacilityDecision)
        hscServiceDecision = Mock(HscServiceDecision)

        abstractHscDecisionHelper.requiredWorkQueueGroup = workQueueGroup
        abstractHscDecisionHelper.requiredActivity = activity
        abstractHscDecisionHelper.requiredHscFacilityDecision = hscFacilityDecision
        abstractHscDecisionHelper.requiredHscServiceDecision = hscServiceDecision
    }

    @Unroll
    def "determineQuestionnaireEditable #hscStatusType #serviceSettingType #decisionOutcomeType"() {
        given:
        HscVO hscVO = new HscVO(hscID: 1, hscStatusType: hscStatusType, serviceSettingType: serviceSettingType)

        when:
        boolean retVal = abstractHscDecisionHelper.determineQuestionnaireEditable(hscVO)

        then:
        if (hscStatusType == HsrReferenceConstants.HSCSTATUSTYPE_OPEN) {
            if (serviceSettingType == HsrReferenceConstants.SERVICESETTINGTYPE_INPATIENT) {
                1 * hscFacilityDecision.getLastFacilityDecision(hscVO.hscID) >> new HscFacilityDecisionVO(hscID: 1, decisionOutcomeType: decisionOutcomeType)
            }
            1 * hscServiceDecision.getCurrentDecisions(hscVO.getHscID(), false) >> [new HscServiceDecisionVO(hscID: 1, decisionOutcomeType: decisionOutcomeType)]
        }
        0 * _
        retVal == expectedVal

        where:
        expectedVal | hscStatusType                                  | serviceSettingType                                  | decisionOutcomeType
        true        | HsrReferenceConstants.HSCSTATUSTYPE_INCOMPLETE | HsrReferenceConstants.SERVICESETTINGTYPE_INPATIENT  | HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED
        false       | HsrReferenceConstants.HSCSTATUSTYPE_OPEN       | HsrReferenceConstants.SERVICESETTINGTYPE_INPATIENT  | HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED
        false       | HsrReferenceConstants.HSCSTATUSTYPE_OPEN       | HsrReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT | HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED
        false       | HsrReferenceConstants.HSCSTATUSTYPE_OPEN       | HsrReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT | HsrReferenceConstants.DECISIONOUTCOMETYPE_DENIED
    }

    @Unroll
    def "determineServiceHasCanceled"() {
        given:
        HscVO hscVO = new HscVO(hscID: 1, hscStatusType: hscStatusType, serviceSettingType: HsrReferenceConstants.SERVICESETTINGTYPE_INPATIENT)

        when:
        boolean retVal = abstractHscDecisionHelper.determineServiceHasCanceled(hscVO, (short) 1)

        then:
        1 * hscServiceDecision.getCurrentDecisions(hscVO.getHscID(), false) >> [new HscServiceDecisionVO(hscID: 1, decisionOutcomeType: decisionOutcomeType, serviceSeqNum: serviceSeqNum)]
        0 * _
        retVal == expectedVal

        where:
        expectedVal | hscStatusType                            | decisionOutcomeType                                | serviceSeqNum
        true        | HsrReferenceConstants.HSCSTATUSTYPE_OPEN | HsrReferenceConstants.DECISIONOUTCOMETYPE_CANCELED | 1
        false       | HsrReferenceConstants.HSCSTATUSTYPE_OPEN | HsrReferenceConstants.DECISIONOUTCOMETYPE_CANCELED | 2
        false       | HsrReferenceConstants.HSCSTATUSTYPE_OPEN | HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED | 1
    }
}
