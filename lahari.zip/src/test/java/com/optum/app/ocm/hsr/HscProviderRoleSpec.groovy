package com.optum.app.ocm.hsr

import com.optum.rf.bl.spring.TransactionInterceptor
import com.optum.rf.core.locator.ServiceLocator
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.uhg.app.common.constants.spclcare.TableConstants
import com.optum.app.common.hsr.businesslogic.Hsc
import com.optum.app.common.hsr.businesslogic.HscProviderRole
import com.optum.app.common.hsr.businesslogic.impl.HscProviderRoleImpl
import com.optum.app.common.hsr.constants.HsrReferenceConstants
import com.optum.app.common.hsr.data.HscProviderRoleVO
import com.optum.app.common.hsr.data.HscProviderVO
import com.optum.app.common.hsr.data.HscVO
import spock.lang.Unroll

class HscProviderRoleSpec extends HsrReadLogicSpecification {

    HscProviderRole hscProviderRole

    DataAccessObject dao
    PersistenceHelper persistenceHelper
    ServiceLocator serviceLocator
    TransactionInterceptor transactionInterceptor
    Hsc hsc

    def setup() {
        dao = Mock(DataAccessObject)
        persistenceHelper = Mock(PersistenceHelper)
        serviceLocator = Mock(ServiceLocator)
        transactionInterceptor = Mock(TransactionInterceptor)
        hsc = Mock(Hsc)

        hscProviderRole = new HscProviderRoleImpl(
                dao: dao,
                requiredPersistenceHelper: persistenceHelper,
                requiredServiceLocator: serviceLocator,
                requiredTransactionInterceptor: transactionInterceptor,
                requiredHsc: hsc
        )
    }

    @Unroll
    def "isValid #testCase"() {
        given:
        def hscID = (long) 1
        def providerSeqNum = (short) 2
        def providerRole = "3"
        ReadProperties rp = new ReadProperties(FieldConstants.HSCID, FieldConstants.PROVIDERSEQNUM, FieldConstants.PROVIDERROLE)
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        rp.setKeyValue(FieldConstants.PROVIDERSEQNUM, providerSeqNum)
        rp.setKeyValue(FieldConstants.PROVIDERROLE, providerRole)
        rp.fields = null

        when:
        boolean retVal = hscProviderRole.isValid(hscID, providerSeqNum, providerRole)

        then:
        1 * dao.isValid(rp) >> expectedVal
        0 * _
        retVal == expectedVal

        where:
        testCase | expectedVal
        "passes" | true
        "fails"  | false
    }

    def "Test to read HscProviderRoleVO"() {
        setup:
        def hscID = (long) 1
        def providerSeqNum = (short) 2
        def providerRole = "3"
        HscProviderRoleVO hscProviderRoleVO = new HscProviderRoleVO(hscID: hscID, providerSeqNum: providerSeqNum, providerRole: providerRole)
        ReadProperties rp = new ReadProperties(FieldConstants.HSCID, FieldConstants.PROVIDERSEQNUM, FieldConstants.PROVIDERROLE)
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        rp.setKeyValue(FieldConstants.PROVIDERSEQNUM, providerSeqNum)
        rp.setKeyValue(FieldConstants.PROVIDERROLE, providerRole)
        rp.fields = null

        when:
        hscProviderRole.read(hscID, providerSeqNum, providerRole)

        then:
        1 * dao.read(rp) >> hscProviderRoleVO
        0 * _
    }

    def "Test list"() {
        setup:
        HscProviderVO hscProviderVO = new HscProviderVO()

        when:
        hscProviderRole.list(hscProviderVO)

        then:
        1 * dao.list(_ as QueryProperties)
        0 * _
    }

    def "Test listByHscID"() {
        setup:

        when:
        hscProviderRole.listByHscID(123456L)

        then:
        1 * dao.list(_ as QueryProperties)
        0 * _
    }

    def "Test isFacility"() {
        setup:
        HscProviderVO hscProviderVO = new HscProviderVO()

        when:
        hscProviderRole.isFacility(hscProviderVO)

        then:
        1 * dao.exists(_ as QueryProperties)
        0 * _
    }

    def "Test isRoleInList"() {
        setup:
        HscProviderVO hscProviderVO = new HscProviderVO()

        when:
        hscProviderRole.isRoleInList(hscProviderVO)

        then:
        1 * dao.exists(_ as QueryProperties)
        0 * _
    }

    def "Test isRole"() {
        setup:

        when:
        hscProviderRole.isRole(123456L, 'SF')

        then:
        1 * dao.exists(_ as QueryProperties)
        0 * _
    }

    def "Test isRoleInList with hscID"() {
        setup:
        HscProviderVO hscProviderVO = new HscProviderVO()

        when:
        hscProviderRole.isRoleInList(123456L, 'SF')

        then:
        1 * dao.exists(_ as QueryProperties)
        0 * _
    }

    def "Test deleteProviderRole"() {
        setup:

        when:
        hscProviderRole.deleteProviderRole(123456L, 'SF')

        then:
        1 * persistenceHelper.deleteCascading(_ as ReadProperties, TableConstants.HSC_PROV_ROLE)
        0 * _
    }

    def "Test copyProviderRoles"() {
        setup:
        HscProviderVO newHscProviderVO = new HscProviderVO()
        HscProviderVO copiedHscProviderVO = new HscProviderVO()

        when:
        hscProviderRole.copyProviderRoles(123456L, 987654L, newHscProviderVO, copiedHscProviderVO)

        then:
        1 * hsc.read(987654L, FieldConstants.SERVICESETTINGTYPE) >> new HscVO(serviceSettingType: HsrReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT)
        1 * dao.list(_ as QueryProperties) >> [ new HscProviderRoleVO(providerRole: HsrReferenceConstants.PROVIDER_ROLE_SERVICING) ]
        1 * persistenceHelper.add(_ as HscProviderRoleVO)
        0 * _
    }

    def "Test listRolesFromOtherProvidersByHscID"() {
        setup:

        when:
        hscProviderRole.listRolesFromOtherProvidersByHscID(123456L, (short)1)

        then:
        1 * dao.list(_ as QueryProperties)
        0 * _
    }

}
