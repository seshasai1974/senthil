package com.optum.app.ocm.hsr

import com.optum.rf.dao.tabledef.TableDefFactory

class SampleSpec extends HsrReadLogicSpecification {

    def "simple test"() {
        when:
        def tableDef = TableDefFactory.getTableDef('user_tbl')

        then:
        tableDef != null
    }

}
