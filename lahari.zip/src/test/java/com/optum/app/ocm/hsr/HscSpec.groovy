package com.optum.app.ocm.hsr

import com.optum.app.common.hsr.businesslogic.HscCgpHistory
import com.optum.app.common.hsr.data.HscCgpHistoryVO
import com.optum.app.ocm.common.activity.businesslogic.Activity
import com.optum.app.ocm.common.assignment.businesslogic.Assignment
import com.optum.app.ocm.common.cpm.common.data.ErrorVO
import com.optum.app.ocm.common.member.businesslogic.CoverageSystemCheckHelper
import com.optum.app.ocm.common.member.businesslogic.Member
import com.optum.app.ocm.common.member.businesslogic.MemberAddress
import com.optum.app.ocm.common.member.businesslogic.MemberCoverage
import com.optum.app.ocm.common.member.businesslogic.MemberTelephone
import com.optum.app.ocm.common.memberprogram.businesslogic.MemberProgram
import com.optum.app.ocm.common.note.businesslogic.Note
import com.optum.app.ocm.ref.businesslogic.CustomerReference
import com.optum.app.shared.constants.SpclCareConstants
import com.optum.app.shared.constants.SpclCareReferenceConstants
import com.optum.app.shared.federatedConfiguration.businesslogic.FederatedConfigService
import com.optum.app.shared.federatedConfiguration.data.PreferredPathway
import com.optum.app.shared.federatedConfiguration.data.SupportedPopulationForPreferredPathway
import com.optum.rf.bl.businesslogic.HistoryBusinessLogic
import com.optum.rf.bl.factory.LogicTypeFactory
import com.optum.rf.bl.spring.TransactionInterceptor
import com.optum.rf.common.messages.GlobalMessages
import com.optum.rf.common.reference.businesslogic.CodeXRef
import com.optum.rf.common.settings.businesslogic.SystemSettingsEmailGroup
import com.optum.rf.common.settings.businesslogic.TemporarySystemSetting
import com.optum.rf.core.locator.ServiceLocator
import com.optum.rf.core.util.GenericUtilities
import com.optum.rf.core.util.UhgCalendar
import com.optum.rf.dao.data.ValueObject
import com.optum.rf.dao.exception.UhgRuntimeException
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.exception.RecordStaleException
import com.optum.rf.dao.sql.exception.UpdateException
import com.optum.rf.dao.sql.query.QueryCriteria
import com.optum.rf.dao.sql.query.QueryFilter
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.tabledef.TableDef
import com.optum.rf.dao.util.UhgCalendarUtilities
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.optum.rf.mail.SendMail
import com.optum.rf.test.core.assertion.ValueObjectAsserter
import com.optum.app.common.activity.data.ActivityVO
import com.optum.app.common.constants.ActivityReferenceConstants
import com.optum.app.common.constants.CommonConstants
import com.optum.app.common.constants.CommonReferenceConstants
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.uhg.app.common.constants.spclcare.TableConstants
import com.optum.app.common.hsr.businesslogic.AbstractHscDecisionHelper
import com.optum.app.common.hsr.businesslogic.HscAdditionalPlanFeature
import com.optum.app.common.hsr.businesslogic.HscAlert
import com.optum.app.common.hsr.businesslogic.HscAlternateIdentifier
import com.optum.app.common.hsr.businesslogic.HscAssessment
import com.optum.app.common.hsr.businesslogic.HscAttribute
import com.optum.app.common.hsr.businesslogic.HscDecisionMemberCoverage
import com.optum.app.common.hsr.businesslogic.HscDiagnosis
import com.optum.app.common.hsr.businesslogic.HscFacility
import com.optum.app.common.hsr.businesslogic.HscFacilityDecision
import com.optum.app.common.hsr.businesslogic.HscFollowUpContact
import com.optum.app.common.hsr.businesslogic.HscLetterRequest
import com.optum.app.common.hsr.businesslogic.HscMeasurement
import com.optum.app.common.hsr.businesslogic.HscMemberCoverage
import com.optum.app.common.hsr.businesslogic.HscMemberOtherCoverage
import com.optum.app.common.hsr.businesslogic.HscProvider
import com.optum.app.common.hsr.businesslogic.HscProviderHelper
import com.optum.app.common.hsr.businesslogic.HscProviderRole
import com.optum.app.common.hsr.businesslogic.HscService
import com.optum.app.common.hsr.businesslogic.HscServiceDecision
import com.optum.app.common.hsr.businesslogic.HscServiceFacility
import com.optum.app.common.hsr.businesslogic.HscServiceNonFacility
import com.optum.app.common.hsr.businesslogic.HscServiceTatPoint
import com.optum.app.common.hsr.businesslogic.HscServiceUrJurisdiction
import com.optum.app.common.hsr.businesslogic.HscSpecialtyProcedure
import com.optum.app.common.hsr.businesslogic.HscTatPointHelper
import com.optum.app.common.hsr.businesslogic.UrJurisdiction
import com.optum.app.common.hsr.businesslogic.impl.HscImpl
import com.optum.app.common.hsr.constants.CssReferenceConstants
import com.optum.app.common.hsr.constants.HsrReferenceConstants
import com.optum.app.common.hsr.data.HscAlternateIdentifierVO
import com.optum.app.common.hsr.data.HscDiagnosisVO
import com.optum.app.common.hsr.data.HscFacilityVO
import com.optum.app.common.hsr.data.HscInitiateIntakeCompositeVO
import com.optum.app.common.hsr.data.HscIntakeCompositeVO
import com.optum.app.common.hsr.data.HscMemberCoverageVO
import com.optum.app.common.hsr.data.HscProviderVO
import com.optum.app.common.hsr.data.HscServiceDecisionSourceVO
import com.optum.app.common.hsr.data.HscServiceDecisionVO
import com.optum.app.common.hsr.data.HscServiceFacilityVO
import com.optum.app.common.hsr.data.HscServiceNonFacilityVO
import com.optum.app.common.hsr.data.HscServiceVO
import com.optum.app.common.hsr.data.HscShortFormVO
import com.optum.app.common.hsr.data.HscSpecialtyProcedureVO
import com.optum.app.common.hsr.data.HscVO
import com.optum.app.common.hsr.messages.HscMessages
import com.optum.app.common.hsr.messages.HsrMessages
import com.optum.app.common.member.core.data.BaseMemberCoverageVO
import com.optum.app.common.member.core.data.MemberAddressVO
import com.optum.app.common.member.core.data.MemberCoverageVO
import com.optum.app.common.member.core.data.MemberTelephoneVO
import com.optum.app.common.member.core.data.MemberVO
import com.optum.app.common.note.data.NoteVO
import com.optum.app.constants.HscConstants
import com.optum.app.ocm.common.workqueue.businesslogic.WorkQueue
import com.optum.app.ocm.constants.SecurityConstants
import org.junit.Assert
import spock.lang.Unroll

import java.sql.Date

class HscSpec extends HsrReadLogicSpecification {

    private HscImpl hsc
    private TransactionInterceptor transactionInterceptor
    private Activity mockActivity
    private Assignment mockAssignment
    private CoverageSystemCheckHelper mockCoverageSystemCheckHelper
    private DataAccessObject mockDao
    private HscDecisionMemberCoverage mockHscDecisionMemberCoverage
    private HscDiagnosis mockHscDiagnosis
    private HscFacility mockHscFacility
    private HscFacilityDecision mockHscFacilityDecision
    private HscFollowUpContact mockHscFollowupContact
    private HscLetterRequest mockHscLetterRequest
    private HscMemberCoverage mockHscMemberCoverage
    private HscMemberOtherCoverage mockHscMemberOtherCoverage
    private HscProvider mockHscProvider
    private HscService mockHscService
    private HscServiceDecision mockHscServiceDecision
    private HscSpecialtyProcedure mockHscSpecialtyProcedure
    private HscServiceNonFacility mockHscServiceNonFacility
    private HscTatPointHelper mockTatPointHelper
    private Member mockMember
    private MemberAddress mockMemberAddress
    private MemberProgram mockMemberProgram
    private MemberTelephone mockMemberTelephone
    private Note mockNote
    private PersistenceHelper mockPersistenceHelper
    private CustomerReference customerReference
    private CodeXRef mockCodeXRef
    private HscAlternateIdentifier mockHscAlternateIdentifier
    private MemberCoverage memberCoverage
    private HscProviderHelper hscProviderHelper
    private HscProviderRole hscProviderRole
    private WorkQueue workQueue
    private HscTatPointHelper hscTatPointHelper
    private HscServiceFacility hscServiceFacility
    private AbstractHscDecisionHelper abstractHscDecisionHelper
    private HscAlert hscAlert
    private SendMail sendMail
    private SystemSettingsEmailGroup systemSettingsEmailGroup
    private TemporarySystemSetting temporarySystemSetting
    private HistoryBusinessLogic historyBusinessLogic
    private ServiceLocator serviceLocator
    private HscAttribute hscAttribute
    private HscAssessment hscAssessment
    private HscMeasurement hscMeasurement
    private HscAdditionalPlanFeature hscAdditionalPlanFeature
    private FederatedConfigService federatedConfigService
    HscServiceTatPoint tatPoint
    HscServiceUrJurisdiction urJurisdiction
    HscCgpHistory hscCgpHistory

    /*Set up any necessary resources.*/

    def setup() {
        mockActivity = Mock(Activity)
        mockAssignment = Mock(Assignment)
        mockCoverageSystemCheckHelper = Mock(CoverageSystemCheckHelper)
        mockDao = Mock(DataAccessObject)
        mockHscDecisionMemberCoverage = Mock(HscDecisionMemberCoverage)
        mockHscDiagnosis = Mock(HscDiagnosis)
        mockHscFacility = Mock(HscFacility)
        mockHscFacilityDecision = Mock(HscFacilityDecision)
        mockHscFollowupContact = Mock(HscFollowUpContact)
        mockHscLetterRequest = Mock(HscLetterRequest)
        mockHscMemberCoverage = Mock(HscMemberCoverage)
        mockHscMemberOtherCoverage = Mock(HscMemberOtherCoverage)
        mockHscProvider = Mock(HscProvider)
        mockHscService = Mock(HscService)
        mockHscSpecialtyProcedure = Mock(HscSpecialtyProcedure)
        mockHscServiceDecision = Mock(HscServiceDecision)
        mockHscServiceNonFacility = Mock(HscServiceNonFacility)
        mockMember = Mock(Member)
        mockMemberAddress = Mock(MemberAddress)
        mockMemberProgram = Mock(MemberProgram)
        mockMemberTelephone = Mock(MemberTelephone)
        mockNote = Mock(Note)
        mockPersistenceHelper = Mock(PersistenceHelper)
        customerReference = Mock(CustomerReference)
        mockTatPointHelper = Mock(HscTatPointHelper)
        mockCodeXRef = Mock(CodeXRef)
        mockHscAlternateIdentifier = Mock(HscAlternateIdentifier)
        memberCoverage = Mock(MemberCoverage)
        hscProviderHelper = Mock(HscProviderHelper)
        hscProviderRole = Mock(HscProviderRole)
        workQueue = Mock(WorkQueue)
        hscTatPointHelper = Mock(HscTatPointHelper)
        hscServiceFacility = Mock(HscServiceFacility)
        abstractHscDecisionHelper = Mock(AbstractHscDecisionHelper)
        hscAlert = Mock(HscAlert)
        sendMail = Mock(SendMail)
        systemSettingsEmailGroup = Mock(SystemSettingsEmailGroup)
        temporarySystemSetting = Mock(TemporarySystemSetting)
        historyBusinessLogic = Mock(HistoryBusinessLogic)
        serviceLocator = Mock(ServiceLocator)
        transactionInterceptor = Mock(TransactionInterceptor)
        hscAttribute = Mock(HscAttribute)
        hscAssessment = Mock(HscAssessment)
        hscMeasurement = Mock(HscMeasurement)
        hscAdditionalPlanFeature = Mock(HscAdditionalPlanFeature)
        tatPoint = Mock(HscServiceTatPoint)
        urJurisdiction = Mock(HscServiceUrJurisdiction)
        federatedConfigService = Mock(FederatedConfigService)
        hscCgpHistory = Mock(HscCgpHistory)

        LogicTypeFactory.putInstance(TableConstants.HSC_FACL, mockHscFacility)
        LogicTypeFactory.putInstance(TableConstants.HSC_SPEC_PROC, mockHscSpecialtyProcedure)
        LogicTypeFactory.putInstance(TableConstants.HSC_SRVC, mockHscService)
        LogicTypeFactory.putInstance(TableConstants.HSC_PROV, mockHscProvider)
        LogicTypeFactory.putInstance(TableConstants.HSC_MBR_COV, mockHscMemberCoverage)
        LogicTypeFactory.putInstance(TableConstants.HSC_MBR_OTHR_COV, mockHscMemberOtherCoverage)
        LogicTypeFactory.putInstance(TableConstants.HSC_FLWUP_CNTC, mockHscFollowupContact)
        LogicTypeFactory.putInstance(TableConstants.HSC_ALT_ID, mockHscAlternateIdentifier)
        hsc = new HscImpl(activity: mockActivity,
                          dao: mockDao, hscDiagnosis: mockHscDiagnosis,
                          hscFacility: mockHscFacility, hscSpecialtyProcedure: mockHscSpecialtyProcedure, hscFacilityDecision: mockHscFacilityDecision, hscFollowUpContact: mockHscFollowupContact,
                          hscMemberCoverage: mockHscMemberCoverage, hscProvider: mockHscProvider, hscService: mockHscService, hscServiceDecision: mockHscServiceDecision,
                          hscServiceNonFacility: mockHscServiceNonFacility, member: mockMember,
                          memberAddress: mockMemberAddress, memberProgram: mockMemberProgram,
                          memberTelephone: mockMemberTelephone, note: mockNote, customerReference: customerReference,
                          tatPointHelper: mockTatPointHelper,
                          codeXRef: mockCodeXRef,
                          hscAlternateIdentifier: mockHscAlternateIdentifier,
                          memberCoverage: memberCoverage,
                          hscProviderHelper: hscProviderHelper, hscProviderRole: hscProviderRole,
                          hscAlert: hscAlert, sendMail: sendMail, systemSettingsEmailGroup: systemSettingsEmailGroup,
                          serviceLocator: serviceLocator, hscAttribute: hscAttribute, hscAssessment: hscAssessment, hscMeasurement: hscMeasurement,
                          hscAdditionalPlanFeature: hscAdditionalPlanFeature,
                          urJurisdiction: urJurisdiction,
                          tatPoint: tatPoint,
                          federatedConfigService: federatedConfigService, coverageSystemCheckHelper: mockCoverageSystemCheckHelper)
        hsc.setRequiredPersistenceHelper(mockPersistenceHelper)
        hsc.setRequiredTransactionInterceptor(transactionInterceptor)
        hsc.setRequiredHistoryBusinessLogic(historyBusinessLogic)
    }
/*
    @Ignore
    def "attempt to complete an hsc that fails validation"() {
        given:
        def hscVO = new HscVO(hscID: 12345678, memberID: 12345, serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT,
                              specialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_LEGACY)

        when:
        hsc.completeHsc(12345L, 12345L)

        then:
        1 * mockHscFacility.read(12345678, [])
        (1.._) * mockDao.read(_ as ReadProperties) >> hscVO
        (1.._) * mockHscDiagnosis.readPrimary(hscVO.hscID) >> null
        (1.._) * mockHscService.validateForCompleteIntake(_ as Long, _ as String) >> new ValueObject()
        (1.._) * mockHscProvider.listByHscID(_ as Long) >> []
        0 * _._
        def e = thrown(UhgRuntimeException)
        e.errorVO.errorMessagesExist()
    }*/

    def "get non hsc id type: service ref"() {
        given:
        String searchID = "12345"
        HscConstants.HscIDTypeEnum result
        HscConstants.HscIDTypeEnum expectedResult = HscConstants.HscIDTypeEnum.SERVICE_REF_NUM
        String[] str = [FieldConstants.PRIMARYSERVICEREFERENCENUM]
        ReadProperties rp = new ReadProperties(str)
        rp.setKeyValue(FieldConstants.PRIMARYSERVICEREFERENCENUM, searchID)

        when:
        result = hsc.getNonHscIDType(searchID)

        then:
        result
        result == expectedResult
        1 * mockDao.read(rp) >> new HscVO()
        0 * _
    }

    def "get non hsc id type: global id"() {
        given:
        HscConstants.HscIDTypeEnum result
        HscConstants.HscIDTypeEnum expectedResult = HscConstants.HscIDTypeEnum.GLOBAL_ID
        String searchID = "1234567812345678"
        String[] refNumStr = [FieldConstants.PRIMARYSERVICEREFERENCENUM]
        ReadProperties refNumRp = new ReadProperties(refNumStr)
        refNumRp.setKeyValue(FieldConstants.PRIMARYSERVICEREFERENCENUM, searchID)
        String[] GblIDStr = [FieldConstants.GLOBALID]
        ReadProperties GblIDRp = new ReadProperties(GblIDStr)
        GblIDRp.setKeyValue(FieldConstants.GLOBALID, searchID)

        when:
        result = hsc.getNonHscIDType(searchID)

        then:
        1 * mockDao.read(refNumRp)
        1 * mockHscService.readByServiceReferenceNumber(searchID)
        1 * mockHscFacility.readByServiceReferenceNumber(searchID)
        1 * mockDao.read(GblIDRp) >> new HscVO()
        0 * _
        result
        result == expectedResult
    }

    def "get non hsc id type: vendor case id"() {
        given:
        HscConstants.HscIDTypeEnum result
        HscConstants.HscIDTypeEnum expectedResult = HscConstants.HscIDTypeEnum.VENDOR_CASE_ID
        String searchID = "12345"
        String[] refNumStr = [FieldConstants.PRIMARYSERVICEREFERENCENUM]
        ReadProperties refNumRp = new ReadProperties(refNumStr)
        refNumRp.setKeyValue(FieldConstants.PRIMARYSERVICEREFERENCENUM, searchID)


        when:
        result = hsc.getNonHscIDType(searchID)

        then:
        1 * mockDao.read(refNumRp)
        1 * mockHscService.readByServiceReferenceNumber(searchID)
        1 * mockHscFacility.readByServiceReferenceNumber(searchID)
        0 * _
        result
        result == expectedResult
    }

    def "get non hsc id type: cc vendor case id"() {
        given:
        HscConstants.HscIDTypeEnum result
        HscConstants.HscIDTypeEnum expectedResult = HscConstants.HscIDTypeEnum.CC_VENDOR_CASE_ID
        String searchID = "A12345"
        String[] refNumStr = [FieldConstants.PRIMARYSERVICEREFERENCENUM]
        ReadProperties refNumRp = new ReadProperties(refNumStr)
        refNumRp.setKeyValue(FieldConstants.PRIMARYSERVICEREFERENCENUM, searchID)

        when:
        result = hsc.getNonHscIDType(searchID)

        then:
        1 * mockDao.read(refNumRp)
        1 * mockHscService.readByServiceReferenceNumber(searchID)
        1 * mockHscFacility.readByServiceReferenceNumber(searchID)
        0 * _
        result
        result == expectedResult
    }

    def "locate hsc: idType hsc id"() {
        given:
        HscConstants.HscIDTypeEnum idType = HscConstants.HscIDTypeEnum.HSC_ID
        String searchID = "12345"
        Long hscID = 12345L
        String[] str = [FieldConstants.HSCID]
        ReadProperties rp = new ReadProperties(str)
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        List<HscVO> results

        when:
        results = hsc.locateHsc(searchID, idType)

        then:
        1 * mockDao.read(rp) >> new HscVO()
        0 * _
        !GenericUtilities.isEmptyOrNull(results)
    }

    def "locate hsc: idType hsc alternate id"() {
        given:
        HscConstants.HscIDTypeEnum idType = HscConstants.HscIDTypeEnum.HSC_ALTERNATE_ID
        String searchID = "12345"
        String altIDType = "Test Alt ID Type"
        Long hscID = 12345L
        String[] str = [FieldConstants.HSCID]
        ReadProperties rp = new ReadProperties(str)
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        List<HscAlternateIdentifierVO> alternateIdentifierVOs = new ArrayList<>()
        HscAlternateIdentifierVO alternateIdentifierVO = new HscAlternateIdentifierVO()
        alternateIdentifierVO.setHscID(hscID)
        alternateIdentifierVO.setHscAlternateID(searchID)
        alternateIdentifierVO.setHscAlternateIDType(altIDType)
        alternateIdentifierVOs.add(alternateIdentifierVO)
        HscVO hscVO = new HscVO()
        List<HscVO> results

        when:
        results = hsc.locateHsc(searchID, idType)

        then:
        1 * mockHscAlternateIdentifier.listByAltHsc(searchID) >> alternateIdentifierVOs
        1 * mockDao.read(rp) >> hscVO
        0 * _
        !GenericUtilities.isEmptyOrNull(results)
        hscVO.getHscAlternateID() == alternateIdentifierVO.getHscAlternateID()
        hscVO.getHscAlternateIDType() == alternateIdentifierVO.getHscAlternateIDType()
    }

    def "locate hsc: idType service ref id"() {
        given:
        HscConstants.HscIDTypeEnum idType = HscConstants.HscIDTypeEnum.SERVICE_REF_NUM
        String searchID = "12345"
        String[] str = [FieldConstants.PRIMARYSERVICEREFERENCENUM]
        ReadProperties rp = new ReadProperties(str)
        rp.setKeyValue(FieldConstants.PRIMARYSERVICEREFERENCENUM, searchID)
        List<HscVO> results

        when:
        results = hsc.locateHsc(searchID, idType)

        then:
        1 * mockDao.read(rp) >> new HscVO()
        0 * _
        !GenericUtilities.isEmptyOrNull(results)
    }

    def "locate hsc: idType unknown to global id"() {
        given:
        HscConstants.HscIDTypeEnum idType = HscConstants.HscIDTypeEnum.UNKNOWN
        String searchID = "1234567812345678"
        String[] refNumStr = [FieldConstants.PRIMARYSERVICEREFERENCENUM]
        ReadProperties refNumRp = new ReadProperties(refNumStr)
        refNumRp.setKeyValue(FieldConstants.PRIMARYSERVICEREFERENCENUM, searchID)
        String[] GblIDStr = [FieldConstants.GLOBALID]
        ReadProperties GblIDRp = new ReadProperties(GblIDStr)
        GblIDRp.setKeyValue(FieldConstants.GLOBALID, searchID)
        List<HscVO> results

        when:
        results = hsc.locateHsc(searchID, idType)

        then:
        1 * mockDao.read(refNumRp)
        1 * mockHscService.readByServiceReferenceNumber(searchID)
        1 * mockHscFacility.readByServiceReferenceNumber(searchID)
        2 * mockDao.read(GblIDRp) >> new HscVO()
        0 * _
        !GenericUtilities.isEmptyOrNull(results)
    }

    def "locate hsc: idType unknown to vendor case id"() {
        given:
        HscConstants.HscIDTypeEnum idType = HscConstants.HscIDTypeEnum.UNKNOWN
        String searchID = "12345"
        String[] refNumStr = [FieldConstants.PRIMARYSERVICEREFERENCENUM]
        ReadProperties refNumRp = new ReadProperties(refNumStr)
        refNumRp.setKeyValue(FieldConstants.PRIMARYSERVICEREFERENCENUM, searchID)
        QueryProperties vendorCaseQp = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        vendorCaseQp.addQueryFilter(new QueryFilter(FieldConstants.VENDORCASEID, searchID))
        List<HscVO> results

        when:
        results = hsc.locateHsc(searchID, idType)

        then:
        1 * mockDao.read(refNumRp)
        1 * mockHscService.readByServiceReferenceNumber(searchID)
        1 * mockHscFacility.readByServiceReferenceNumber(searchID)
        1 * mockDao.list(vendorCaseQp) >> { new ArrayList<HscVO>() << new HscVO() }
        0 * _
        !GenericUtilities.isEmptyOrNull(results)
    }

    def "locate hsc: idType unknown to cc vendor case id"() {
        given:
        HscConstants.HscIDTypeEnum idType = HscConstants.HscIDTypeEnum.UNKNOWN
        String searchID = "A123435"
        String[] refNumStr = [FieldConstants.PRIMARYSERVICEREFERENCENUM]
        ReadProperties refNumRp = new ReadProperties(refNumStr)
        refNumRp.setKeyValue(FieldConstants.PRIMARYSERVICEREFERENCENUM, searchID)
        List<String> specialProcessTypesForCareCore =
                [HsrReferenceConstants.SPECIALPROCESSTYPE_CARECORE,
                 HsrReferenceConstants.SPECIALPROCESSTYPE_CARECORE_EI,
                 HsrReferenceConstants.SPECIALPROCESSTYPE_CARECORE_CSP_FACETS].asImmutable()
        List<String> statusTypesForHscSearchWithCareCore =
                [HsrReferenceConstants.HSCSTATUSTYPE_OPEN,
                 HsrReferenceConstants.HSCSTATUSTYPE_CLOSED,
                 HsrReferenceConstants.HSCSTATUSTYPE_AWAITING_ADMISSION].asImmutable()
        QueryProperties ccVendorCaseQp = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        ccVendorCaseQp.addQueryFilter(new QueryFilter(FieldConstants.VENDORCASEID, searchID))
        ccVendorCaseQp.addQueryFilter(new QueryFilter(FieldConstants.SPECIALPROCESSTYPE, specialProcessTypesForCareCore, QueryCriteria.IN))
        QueryFilter qf = new QueryFilter(FieldConstants.HSCSTATUSTYPE, GenericUtilities.getDelimitedString(statusTypesForHscSearchWithCareCore))
        ccVendorCaseQp.addQueryFilter(qf)
        ccVendorCaseQp.setOrderByAscFields(FieldConstants.HSCSTATUSTYPE)
        ccVendorCaseQp.setFilterType(QueryProperties.FilterType.NEW_FILTER)
        ccVendorCaseQp.setResultSize(1)
        List<HscVO> results

        when:
        results = hsc.locateHsc(searchID, idType)

        then:
        1 * mockDao.read(refNumRp)
        1 * mockHscService.readByServiceReferenceNumber(searchID)
        1 * mockHscFacility.readByServiceReferenceNumber(searchID)
        1 * mockDao.list(ccVendorCaseQp) >> { new ArrayList<>() << new HscVO() }
        0 * _
        !GenericUtilities.isEmptyOrNull(results)
    }

    def "search hsc and add comm txn"() {
        given:
        String hscSearchID = "12345"
        Long hscID = 12345L
        HscConstants.HscIDTypeEnum idType = HscConstants.HscIDTypeEnum.HSC_ID
        String[] str = [FieldConstants.HSCID]
        ReadProperties rp = new ReadProperties(str)
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        HscVO hscVO = new HscVO()
        List<HscVO> results

        when:
        results = hsc.searchHscAndUpdateMember(hscSearchID, idType)

        then:
        notThrown(UhgRuntimeException)
        1 * mockDao.read(rp) >> hscVO
        0 * _
        !GenericUtilities.isEmptyOrNull(results)
    }

    def "checkNewMexicoEVVID searchID does not match pattern"() {
        given:
        String searchID = "00TESTALTID"
        List<HscAlternateIdentifierVO> result

        when:
        result = hsc.checkNewMexicoEVVID(searchID)

        then:
        0 * _
        GenericUtilities.isEmptyOrNull(result)
    }

    def "checkNewMexicoEVVID searchID matches pattern"() {
        given:
        Long hscID = 1
        String searchID = "UTESTALTID00"
        List<HscAlternateIdentifierVO> result

        when:
        result = hsc.checkNewMexicoEVVID(searchID)

        then:
        1 * mockHscAlternateIdentifier.listByAltHsc(searchID.substring(1, 10), HsrReferenceConstants.HSCALTERNATEIDTYPE_NEWMEXICO_EVV_ID) >>
        [new HscAlternateIdentifierVO(hscID: hscID, hscAlternateIDType: HsrReferenceConstants.HSCALTERNATEIDTYPE_NEWMEXICO_EVV_ID, hscAlternateID: searchID.substring(1, 10))]
        0 * _
        result
        !result.isEmpty()
        hscID == result.first().hscID
        HsrReferenceConstants.HSCALTERNATEIDTYPE_NEWMEXICO_EVV_ID.equals(result.first().hscAlternateIDType)
        searchID.substring(1, 10).equals(result.first().hscAlternateID)
    }

    @Unroll("Test deriveUmResponsibility: riskType #riskType")
    def "Test deriveUmResponsibility"() {
        given:
        def hscVO = new HscVO(serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT, derivedNiceProviderRiskType: riskType)

        when:
        hsc.deriveUmResponsibility(hscVO)

        then:
        expectedUmResponsibility.equals(hscVO.getUmResponsibilityType())

        where:
        riskType                                                          | expectedUmResponsibility
        HsrReferenceConstants.DERIVED_NICEPROVIDERRISKTYPE_ADMINISTRATIVE | HsrReferenceConstants.UMRESPONSIBILITYTYPE_PMG_CASE
        HsrReferenceConstants.DERIVED_NICEPROVIDERRISKTYPE_PARTIAL        | HsrReferenceConstants.UMRESPONSIBILITYTYPE_PMG_CASE
        HsrReferenceConstants.DERIVED_NICEPROVIDERRISKTYPE_SHARED         | HsrReferenceConstants.UMRESPONSIBILITYTYPE_PMG_CASE
        HsrReferenceConstants.DERIVED_NICEPROVIDERRISKTYPE_DCN            | HsrReferenceConstants.UMRESPONSIBILITYTYPE_UHG_CASE
        HsrReferenceConstants.DERIVED_NICEPROVIDERRISKTYPE_UNDETERMINED   | HsrReferenceConstants.UMRESPONSIBILITYTYPE_UNDETERMINED
    }

    @Unroll()
    def "setHscCompleteStatus: IP Hsc status set correctly upon completion with expectedAdmissionDate [#expectedAdmDateValue] and actualAdmissionDateTime [#actualAdmDateValue]"() {
        given:
        def hscVO = new HscVO(serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT)
        def hscFacilityVO = new HscFacilityVO(expectedAdmissionDate: expectedAdmDateValue, actualAdmissionDateTime: actualAdmDateValue)

        when:
        hsc.setHscCompleteStatus(hscVO)

        then:
        1 * mockHscFacility.read(hscVO.getHscID()) >> hscFacilityVO

        and:
        assert expectedHscStatusType.equals(hscVO.getHscStatusType())
        assert expectedHscStatusReasonType.equals(hscVO.getHscStatusReasonType())

        where:
        expectedAdmDateValue                                                  | actualAdmDateValue                                     | expectedHscStatusType                                  | expectedHscStatusReasonType
        UhgCalendarUtilities.getNextDay(UhgCalendarUtilities.getTodaysDate()) | null                                                   | HsrReferenceConstants.HSCSTATUSTYPE_AWAITING_ADMISSION | HsrReferenceConstants.HSCSTATUSREASONTYPE_AWAITING_ADMISSION
        UhgCalendarUtilities.getNextDay(UhgCalendarUtilities.getTodaysDate()) | UhgCalendarUtilities.getTodaysCalendarInUserTimeZone() | HsrReferenceConstants.HSCSTATUSTYPE_OPEN               | HsrReferenceConstants.HSCSTATUSREASONTYPE_OPEN
        UhgCalendarUtilities.getTodaysDate()                                  | null                                                   | HsrReferenceConstants.HSCSTATUSTYPE_OPEN               | HsrReferenceConstants.HSCSTATUSREASONTYPE_OPEN
        UhgCalendarUtilities.getTodaysDate()                                  | UhgCalendarUtilities.getTodaysCalendarInUserTimeZone() | HsrReferenceConstants.HSCSTATUSTYPE_OPEN               | HsrReferenceConstants.HSCSTATUSREASONTYPE_OPEN
        UhgCalendarUtilities.getYesterdaysDate()                              | null                                                   | HsrReferenceConstants.HSCSTATUSTYPE_OPEN               | HsrReferenceConstants.HSCSTATUSREASONTYPE_OPEN
        UhgCalendarUtilities.getYesterdaysDate()                              | UhgCalendarUtilities.getTodaysCalendarInUserTimeZone() | HsrReferenceConstants.HSCSTATUSTYPE_OPEN               | HsrReferenceConstants.HSCSTATUSREASONTYPE_OPEN
    }

    @Unroll()
    def "setHscCompleteStatus: OP and OPF Hsc status set correctly upon completion with serviceSettingType [#hscServiceSettingType]"() {
        given:
        def hscVO = new HscVO(serviceSettingType: hscServiceSettingType)

        when:
        hsc.setHscCompleteStatus(hscVO)

        then:
        assert HsrReferenceConstants.HSCSTATUSTYPE_OPEN.equals(hscVO.getHscStatusType())
        assert HsrReferenceConstants.HSCSTATUSREASONTYPE_OPEN.equals(hscVO.getHscStatusReasonType())

        where:
        hscServiceSettingType << [CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT, CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY]
    }

    def "testValidCancelHscFromDecisionTest"() {
        given:
        HscVO vo = new HscVO(hscID: 12345678, memberID: 12345, serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT,
                             specialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_LEGACY, hscStatusReasonType: HsrReferenceConstants.HSCSTATUSREASONTYPE_INELIGIBLE)
        HscServiceDecisionVO serviceDecisionVO = new HscServiceDecisionVO(decisionReasonType: HsrReferenceConstants.DECISIONREASONTYPE_NOTRENDERED)

        when:
        hsc.cancelHscFromDecision(vo, serviceDecisionVO)

        then:
        1 * mockPersistenceHelper.updateSubset(vo, [FieldConstants.HSCSTATUSTYPE, FieldConstants.HSCSTATUSREASONTYPE] as String[], true)
        1 * mockActivity.add(_ as ActivityVO)
        ValueObjectAsserter.assertErrorMessagesDoNotExist(vo)
    }

//    def "testValidChangeAwaitingAdmissionToOpenStatusTest"() {
//        given:
//        HscVO vo = new HscVO(hscID: 12345678, memberID: 12345, serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT,
//                             specialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_LEGACY, hscStatusReasonType: HsrReferenceConstants.HSCSTATUSREASONTYPE_INELIGIBLE,
//                             hscStatusType: HsrReferenceConstants.HSCSTATUSTYPE_AWAITING_ADMISSION, serviceCategoryType: HsrReferenceConstants.SERVICE_CATEGORY_MEDICAL)
//
//        when:
//        hsc.changeAwaitingAdmissionToOpenStatus(vo.getHscID(), new UhgCalendar())
//
//        then:
//        1 * mockPersistenceHelper.add(_ as ValueObject)
//        1 * mockPersistenceHelper.update(_ as ValueObject)
//        (1.._) * mockDao.read(_ as ReadProperties) >> vo
//        (1.._) * mockDao.isDuplicate(_ as QueryProperties) >> false
//        ValueObjectAsserter.assertErrorMessagesDoNotExist(vo)
//    }

    @SuppressWarnings("GroovyAssignabilityCheck")
    def setSaveQuickIntakeDataCommonExpectations(HscVO hscVO, HscFacilityVO facilityVO, MemberAddressVO memberAddressVO, MemberTelephoneVO memberTelephoneVO) {
        (1.._) * mockDao.read(_ as ReadProperties) >> hscVO
        (1.._) * mockHscFacility.read(_ as Long) >> facilityVO

        (1.._) * customerReference.isValidReferenceChildFilter(_ as String, _ as String, _ as String, _ as String) >> true
        2 * customerReference.validateReference(hscVO, FieldConstants.SPECIALPROCESSTYPE, hscVO.getSpecialProcessType(), false)
        2 * customerReference.validateReference(hscVO, FieldConstants.SPECIALPROCESSTYPE, hscVO.getSecondarySpecialProcessType(), false)

        2 * mockPersistenceHelper.update(_ as ValueObject)
        (1.._) * mockMember.updateCascading(_ as MemberVO)
        (1.._) * mockMember.read(_ as Long) >> new MemberVO(memberID: 1234567890L)
        (1.._) * mockMemberAddress.getActiveMemberAddressForMember(_ as Long) >> memberAddressVO
        (1.._) * mockMemberTelephone.read(_ as Long, _) >> memberTelephoneVO
        1 * mockHscMemberCoverage.read(_ as Long, _ as Short) >> new HscMemberCoverageVO()
        (0.._) * mockHscMemberCoverage.checkAndSaveMedicalNecessityInd(_ as HscMemberCoverageVO, _ as HscVO)
    }

    @SuppressWarnings("GroovyAssignabilityCheck")
    def setPHSSaveQuickIntakeDataCommonExpectations(HscVO hscVO, HscFacilityVO facilityVO, MemberAddressVO memberAddressVO, MemberTelephoneVO memberTelephoneVO, HscProviderVO providerVO) {
        (1.._) * mockDao.read(_ as ReadProperties) >> hscVO
        (1.._) * mockHscAlternateIdentifier.listByHscSortByIdType(_) >> []
        (1.._) * mockHscProvider.readByRole(_ as Long, HsrReferenceConstants.PROVIDER_ROLE_PRIMARY_CARE_PROVIDER) >> providerVO
        (1.._) * mockHscFacility.read(_ as Long) >> facilityVO

        (1.._) * customerReference.isValidReferenceChildFilter(_ as String, _ as String, _ as String, _ as String) >> true
        2 * customerReference.validateReference(hscVO, FieldConstants.SPECIALPROCESSTYPE, hscVO.getSpecialProcessType(), false)
        2 * customerReference.validateReference(hscVO, FieldConstants.SPECIALPROCESSTYPE, hscVO.getSecondarySpecialProcessType(), false)

        2 * mockPersistenceHelper.update(_ as ValueObject)
        (1.._) * mockMember.updateCascading(_ as MemberVO)
        (1.._) * mockMember.read(_ as Long) >> new MemberVO(memberID: 1234567890L)
        (1.._) * mockMemberAddress.getActiveMemberAddressForMember(_ as Long) >> memberAddressVO
        (1.._) * mockMemberTelephone.read(_ as Long, _) >> memberTelephoneVO
        1 * mockHscMemberCoverage.read(_ as Long, _ as Short) >> new HscMemberCoverageVO()
        (0.._) * mockHscMemberCoverage.checkAndSaveMedicalNecessityInd(_ as HscMemberCoverageVO, _ as HscVO)
    }

    def "testReopenHsc - Happy Path"() {
        given:
        HscVO vo = new HscVO(hscID: 12345678, memberID: 12345, changeUserID: "AK3", serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT,
                             specialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_LEGACY,
                             hscStatusReasonType: HsrReferenceConstants.HSCSTATUSREASONTYPE_OPEN,
                             hscStatusType: HsrReferenceConstants.HSCSTATUSTYPE_OPEN,
                             serviceCategoryType: HsrReferenceConstants.SERVICE_CATEGORY_MEDICAL)
        HscVO hscVO = new HscVO(hscID: 12345678, memberID: 12345, changeUserID: "AK3", serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT,
                                specialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_LEGACY,
                                hscStatusReasonType: HsrReferenceConstants.HSCSTATUSREASONTYPE_MIXED_CASE,
                                hscStatusType: HsrReferenceConstants.HSCSTATUSTYPE_CLOSED,
                                serviceCategoryType: HsrReferenceConstants.SERVICE_CATEGORY_MEDICAL)
        when:
        hsc.reopenHsc(vo)

        then:
        (1.._) * mockDao.read(_ as ReadProperties) >> hscVO
        ValueObjectAsserter.assertErrorMessagesDoNotExist(vo)
    }

    def "testReopenHsc - Missing status reason on reopen"() {
        given:
        HscVO vo = new HscVO(hscID: 12345678, memberID: 12345, serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT,
                             specialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_LEGACY,
                             hscStatusType: HsrReferenceConstants.HSCSTATUSTYPE_OPEN)
        HscVO hscVO = new HscVO(hscID: 12345678, memberID: 12345, serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT,
                                specialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_LEGACY, hscStatusReasonType: HsrReferenceConstants.HSCSTATUSREASONTYPE_MIXED_CASE,
                                hscStatusType: HsrReferenceConstants.HSCSTATUSTYPE_CLOSED)

        when:
        hsc.reopenHsc(vo)

        then:
        (1.._) * mockDao.read(_ as ReadProperties) >> hscVO
    }

    def "testReopenHsc - Already Open"() {
        given:
        HscVO vo = new HscVO(hscID: 12345678, memberID: 12345, serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT,
                             specialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_LEGACY,
                             hscStatusType: HsrReferenceConstants.HSCSTATUSTYPE_OPEN)
        HscVO hscVO = new HscVO(hscID: 12345678, memberID: 12345, serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT,
                                specialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_LEGACY, hscStatusReasonType: HsrReferenceConstants.HSCSTATUSREASONTYPE_OPEN,
                                hscStatusType: HsrReferenceConstants.HSCSTATUSTYPE_OPEN)

        when:
        hsc.reopenHsc(vo)

        then:
        thrown(UhgRuntimeException)
        (1.._) * mockDao.read(_ as ReadProperties) >> hscVO
        ValueObjectAsserter.assertMessageExists(vo, HscMessages.ERR_HSC_ALREADY_OPEN)
    }

    def "test validate CareCoreServiceSetting Hsc CareCoreEandI Inpatient"() {
        given:
        HscVO hscVO = new HscVO(hscID: 1234L, memberCoverageSeqNum: 1, memberID: 9876L, specialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_CARECORE_EI, serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT)

        when:
        hsc.validateCareCoreBeaconLBSServiceSetting(hscVO)

        then:
        0 * _

        and:
        hscVO != null
        !hscVO.errorMessagesExist()
    }

    def "test validate CareCoreServiceSetting Hsc CareCoreEandI Outpatient"() {
        given:
        HscVO hscVO = new HscVO(hscID: 1234L, memberCoverageSeqNum: 1, memberID: 9876L, specialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_CARECORE_EI, serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT)

        when:
        hsc.validateCareCoreBeaconLBSServiceSetting(hscVO)

        then:
        0 * _

        and:
        hscVO != null
        !hscVO.errorMessagesExist()
    }

    def "test validate CareCoreServiceSetting Hsc CareCoreEandI OutpatientFacility"() {
        given:
        HscVO hscVO = new HscVO(hscID: 1234L, memberCoverageSeqNum: 1, memberID: 9876L, specialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_CARECORE_EI, serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY)

        when:
        hsc.validateCareCoreBeaconLBSServiceSetting(hscVO)

        then:
        0 * _

        and:
        hscVO != null
        !hscVO.errorMessagesExist()
    }

    def "test validate CareCoreServiceSetting Hsc CareCoreMandR Inpatient"() {
        given:
        HscVO hscVO = new HscVO(hscID: 1234L, memberCoverageSeqNum: 1, memberID: 9876L, specialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_CARECORE, serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT)

        when:
        hsc.validateCareCoreBeaconLBSServiceSetting(hscVO)

        then:
        0 * _

        and:
        hscVO != null
        !hscVO.errorMessagesExist()
    }

    def "test validate CareCoreServiceSetting Hsc CareCoreMandR Outpatient"() {
        given:
        HscVO hscVO = new HscVO(hscID: 1234L, memberCoverageSeqNum: 1, memberID: 9876L, specialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_CARECORE, serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT)

        when:
        hsc.validateCareCoreBeaconLBSServiceSetting(hscVO)

        then:
        0 * _

        and:
        hscVO != null
        !hscVO.errorMessagesExist()
    }

    def "test validate CareCoreServiceSetting Hsc CareCoreMandR OutpatientFacility"() {
        given:
        HscVO hscVO = new HscVO(hscID: 1234L, memberCoverageSeqNum: 1, memberID: 9876L, specialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_CARECORE, serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY)

        when:
        hsc.validateCareCoreBeaconLBSServiceSetting(hscVO)

        then:
        0 * _

        and:
        hscVO != null
        !hscVO.errorMessagesExist()
        hscVO.getGlobalMessages().size() == 0
    }

    def "test validate BeaconLBS Inpatient"() {
        given:
        HscVO hscVO = new HscVO(hscID: 1234L, memberCoverageSeqNum: 1, memberID: 9876L, vendorTypeID: CssReferenceConstants.VENDOR_TYPE_BEACONLBS, serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT)

        when:
        hsc.validateCareCoreBeaconLBSServiceSetting(hscVO)

        then:
        0 * _

        and:
        hscVO != null
        hscVO.errorMessagesExist()
        hscVO.getGlobalMessages().size() == 1
        Assert.assertEquals(HsrMessages.ERR_IP_AND_OPF_INVALID_FOR_BEACONLBS.messageString, hscVO.getGlobalMessages().find().messageString)
    }

    def "test validate BeaconLBS OutpatientFacility"() {
        given:
        HscVO hscVO = new HscVO(hscID: 1234L, memberCoverageSeqNum: 1, memberID: 9876L, vendorTypeID: CssReferenceConstants.VENDOR_TYPE_BEACONLBS, serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY)

        when:
        hsc.validateCareCoreBeaconLBSServiceSetting(hscVO)

        then:
        0 * _

        and:
        hscVO != null
        hscVO.errorMessagesExist()
        hscVO.getGlobalMessages().size() == 1
        Assert.assertEquals(HsrMessages.ERR_IP_AND_OPF_INVALID_FOR_BEACONLBS.messageString, hscVO.getGlobalMessages().find().messageString)
    }

    def "testSetHscCompleteStatus - CareCore E and I IP all approved"() {
        given:
        def hscServiceDecisionVO1 = new HscServiceDecisionVO(hscID: 1234L, serviceSeqNum: 1, decisionSeqNum: 1, decisionOutcomeType: HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED)
        def hscServiceVO = new HscServiceVO(hscID: 1234L, serviceSeqNum: 1)
        List<HscServiceVO> hscServiceVOs = new ArrayList<HscServiceVO>()
        hscServiceVOs.add(hscServiceVO)
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: 1234L, expectedAdmissionDate: UhgCalendarUtilities.getTodaysDate() - 1, actualAdmissionDateTime: null)
        HscVO hscVO = new HscVO(hscID: 1234L, memberCoverageSeqNum: 1, memberID: 9876L, specialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_CARECORE_EI, serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT)


        when:
        hsc.setHscCompleteStatus(hscVO)

        then:
        1 * mockHscFacility.read(hscVO.hscID) >> hscFacilityVO

        and:
        hscVO != null
        Assert.assertEquals(HsrReferenceConstants.HSCSTATUSTYPE_OPEN, hscVO.getHscStatusType())
    }

    def "test isPreServiceCase for HSC"() {
        given:
        def isPreServiceCase
        HscVO hscVO = new HscVO(hscID: 1234L, serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT)
        HscFacilityVO hscFacilityVO = new HscFacilityVO(expectedAdmissionDate: UhgCalendarUtilities.getTodaysDate(), placeOfServiceCode: HsrReferenceConstants.PLACEOFSERVICE_ACUTE_HOSPITAL,
                                                        serviceDescriptionType: HsrReferenceConstants.SERVICEDESCRIPTIONTYPE_SCHEDULED, serviceDetailType: HsrReferenceConstants.SERVICEDETAILTYPE_SURGICAL)

        when:
        isPreServiceCase = hsc.isPreServiceCase(hscVO, hscFacilityVO)

        then:
        isPreServiceCase
    }

    def "Test executeUpdate where RecordStaleException is thrown and hscVOs are the same"() {
        given:
        HscVO hscVO = new HscVO(hscID: 1)

        when:
        hsc.executeUpdate(hscVO, false)

        then:
        2 * mockDao.read(_ as ReadProperties) >> hscVO
        1 * mockPersistenceHelper.update(hscVO) >> { throw new RecordStaleException() }
        1 * mockPersistenceHelper.update(hscVO)
        1 * historyBusinessLogic.addHistoryVO(hscVO)
        0 * _
    }

    def "Test executeUpdate where RecordStaleException is thrown and hscVOs are different"() {
        given:
        HscVO hscVO = new HscVO(hscID: 1)

        when:
        hsc.executeUpdate(hscVO, false)

        then:
        thrown(RecordStaleException)
        2 * mockDao.read(_ as ReadProperties) >> new HscVO(hscID: 2)
        1 * mockPersistenceHelper.update(hscVO) >> { throw new RecordStaleException() }
        0 * _
    }

    def "Test validate where isSkeletalHsc is true"() {
        when:
        hsc.validate(new HscVO(skeletalHsc: true), false)

        then:
        0 * _
    }

    def "Test cancelHsc"() {
        given:
        HscVO hscVO = createValidHscVO()

        when:
        hsc.cancelHsc(hscVO)

        then:
        HsrReferenceConstants.HSCSTATUSTYPE_CANCELLED.equals(hscVO.getHscStatusType())
        2 * mockDao.read(getReadProperties(hscVO.getHscID())) >> hscVO
        1 * customerReference.validateReference(hscVO, FieldConstants.SPECIALPROCESSTYPE, hscVO.getSpecialProcessType(), false)
        1 * customerReference.validateReference(hscVO, FieldConstants.SPECIALPROCESSTYPE, hscVO.getSecondarySpecialProcessType(), false)
        1 * mockPersistenceHelper.update(hscVO)
        1 * historyBusinessLogic.addHistoryVO(hscVO)
        1 * mockHscFacilityDecision.cascadeCancelToFacilityLine(hscVO)
        1 * mockHscServiceDecision.cascadeCancelToAllServiceLines(hscVO)
        1 * mockCodeXRef.getInboundAttributeToValue(HsrReferenceConstants.SYSTEMTYPE_HSR, CommonConstants.CD_XREF_ACTV_REASON_TO_ACTV_RESOLUTION_REASON, hscVO.getHscStatusReasonType(), null) >> "00"
        1 * mockActivity.add(_ as ActivityVO)
        0 * _
    }

    def "Test cancelHsc with error message"() {
        given:
        HscVO hscVO = createValidHscVO()
        hscVO.setHscStatusReasonType("")

        when:
        hsc.cancelHsc(hscVO)

        then:
        thrown(UhgRuntimeException)
        hscVO.getGlobalMessages().getAt(0).equals(HsrMessages.ERR_HSC_CANCEL_REASON_REQUIRED)
        HsrReferenceConstants.HSCSTATUSTYPE_CANCELLED.equals(hscVO.getHscStatusType())
    }

    def "Test cancelHscFromDecision when an Exception is thrown"() {
        given:
        HscVO hscVO = new HscVO(hscStatusType: HsrReferenceConstants.HSCSTATUSTYPE_OPEN)
        hscVO.setHscStatusType(HsrReferenceConstants.HSCSTATUSTYPE_CANCELLED)
        HscServiceDecisionVO hscServiceDecisionVO = new HscServiceDecisionVO()

        when:
        hsc.cancelHscFromDecision(hscVO, hscServiceDecisionVO)

        then:
        thrown(UhgRuntimeException)
        HsrReferenceConstants.HSCSTATUSTYPE_CANCELLED.equals(hscVO.getHscStatusType())
        1 * mockPersistenceHelper.updateSubset(hscVO, [FieldConstants.HSCSTATUSTYPE, FieldConstants.HSCSTATUSREASONTYPE] as String[], true) >> { throw new Exception() }
        0 * _
    }

    @Unroll
    def "Test checkHscCoverageDecision with a single parameter where #testcase"() {
        when:
        boolean isDecisionMade = hsc.checkHscCoverageDecision(1 as long)

        then:
        isDecisionMade
        1 * mockDao.read(getReadProperties(1 as long, FieldConstants.SERVICESETTINGTYPE)) >> hscVO
        1 * mockHscService.listByHscID(1, false) >> Arrays.asList(new HscServiceVO(hscServiceLockType: HsrReferenceConstants.HSCSERVICELOCKTYPE_PARTIAL_LOCK))
        0 * _

        where:
        [testcase, hscVO] << [["isOutpatient is true", new HscVO(serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT)],
                              ["isOutpatient is false", new HscVO(serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT)]]
    }

    def "Test checkHscCoverageDecision with two parameters where isOutpatient is true"() {
        given:
        long hscId = 1 as long
        short providerSeqNum = 2 as short

        when:
        boolean isDecisionMade = hsc.checkHscCoverageDecision(hscId, providerSeqNum)

        then:
        isDecisionMade
        1 * mockDao.read(getReadProperties(hscId, FieldConstants.SERVICESETTINGTYPE)) >> new HscVO(serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT)
        1 * mockHscService.listByHscProvider(hscId, providerSeqNum) >> Arrays.asList(new HscServiceVO(hscServiceLockType: HsrReferenceConstants.HSCSERVICELOCKTYPE_PARTIAL_LOCK))

        0 * _
    }

    def "Test checkHscCoverageDecision with two parameters where isOutpatient is false"() {
        given:
        long hscId = 1 as long
        short providerSeqNum = 2 as short

        when:
        boolean isDecisionMade = hsc.checkHscCoverageDecision(hscId, providerSeqNum)

        then:
        isDecisionMade
        1 * mockDao.read(getReadProperties(hscId, FieldConstants.SERVICESETTINGTYPE)) >> new HscVO(serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT)
        1 * hscProviderRole.isValid(hscId, providerSeqNum, HsrReferenceConstants.PROVIDER_ROLE_FACILITY) >> true
        1 * mockHscFacility.read(hscId) >> new HscFacilityVO()
        1 * mockHscService.listByHscProvider(hscId, providerSeqNum) >> Arrays.asList(new HscServiceVO(hscServiceLockType: HsrReferenceConstants.HSCSERVICELOCKTYPE_PARTIAL_LOCK))
        0 * _
    }

    def "Test inactivateMemberProgramAlerts"() {
        given:
        HscVO hscVO = new HscVO(serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT)

        when:
        hsc.inactivateMemberProgramAlerts(hscVO)

        then:
        1 * mockDao.list(new QueryProperties(QueryProperties.FilterType.LIST_ALL, new QueryFilter(FieldConstants.MEMBERID, hscVO.getMemberID()),
                                             new QueryFilter(FieldConstants.HSCSTATUSTYPE, HsrReferenceConstants.HSCSTATUSTYPE_OPEN),
                                             new QueryFilter(FieldConstants.HSCID, hscVO.getHscID(), QueryCriteria.NOT_EQUAL))) >> Arrays.asList(new HscVO())
        1 * mockMemberProgram.inactivateAllAlerts(hscVO.getMemberID())
        0 * _
    }

    /*def "Test inactivateMemberProgramInpatientAlerts"() {
        given:
        HscVO hscVO = new HscVO(serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT)

        when:
        hsc.inactivateMemberProgramInpatientAlerts(hscVO, true)

        then:
        0 * _
    }*/
/*
    @Ignore
    def "Test completeHsc"() {
        given:
        long commTxnId = 1 as long
        HscVO hscVO = createValidHscVO()
        HscProviderVO hscProviderVO = new HscProviderVO(requestingProviderInd: true, facilityProviderInd: true, attendingProviderInd: true)
        HscDiagnosisVO hscDiagnosisVO = new HscDiagnosisVO()
        HscFacilityVO hscFacilityVO = new HscFacilityVO(serviceReferenceNum: "00")
        MemberVO memberVO = new MemberVO(birthDate: new Date(1,1,1))
        HscServiceVO hscServiceVO = new HscServiceVO()
        ValueObject vo = new ValueObject()

        when:
        hsc.completeHsc(hscVO.getHscID(), commTxnId)

        then:
        2 * mockDao.read(getReadProperties(hscVO.getHscID())) >> hscVO
        1 * customerReference.isValidReferenceChildFilter(FieldConstants.HSCSTATUSTYPE, '1', FieldConstants.HSCSTATUSREASONTYPE, '12') >> true
        1 * customerReference.validateReference(hscVO, FieldConstants.SPECIALPROCESSTYPE, hscVO.getSpecialProcessType(), false)
        1 * customerReference.validateReference(hscVO, FieldConstants.SPECIALPROCESSTYPE, hscVO.getSecondarySpecialProcessType(), false)
        1 * mockHscDiagnosis.readPrimary(hscVO.getHscID()) >> hscDiagnosisVO
        1 * mockHscService.validateForCompleteIntake(hscVO.getHscID(), hscVO.getServiceSettingType()) >> vo
        1 * mockHscProvider.listByHscID(hscVO.getHscID()) >> Arrays.asList(hscProviderVO)
        1 * mockHscProvider.setNonPersistedRoles(hscProviderVO)
        3 * mockHscFacility.read(hscVO.getHscID()) >> hscFacilityVO
        1 * mockHscMemberCoverage.read(hscVO.getHscID(), hscVO.getMemberCoverageSeqNum()) >> new HscMemberCoverageVO()
        1 * mockPersistenceHelper.update(hscVO)
        1 * historyBusinessLogic.addHistoryVO(hscVO)
        2 * mockMember.read(hscVO.getMemberID()) >> memberVO
        1 * memberCoverage.getCurrentMemberCoverageVO(memberVO) >> new BaseMemberCoverageVO()
        1 * mockDao.list(_ as QueryProperties)
        1 * mockActivity.add(_ as ActivityVO)
        1 * mockTatPointHelper.logIntakeCompleteTatPoint(hscVO.getHscID())
        0 * _
    }
*/
    /*def "Test setAutoApprovedDecisions"() {
        given:
        HscVO hscVO = new HscVO(hscID: 1 as long, memberCoverageSeqNum: 2 as short, decisionID: "00")
        HscServiceVO hscServiceVO = new HscServiceVO(hscID: 1 as long, serviceSeqNum: 2 as short)
        HscMemberCoverageVO hscMemberCoverageVO = new HscMemberCoverageVO()
        HscServiceDecisionVO currentDecision = new HscServiceDecisionVO(hscID: hscServiceVO.hscID, serviceSeqNum: hscServiceVO.serviceSeqNum)
        HscServiceDecisionVO hscServiceDecisionVO = new HscServiceDecisionVO(decisionOutcomeType: HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED,
                                                                             decisionSubType: HsrReferenceConstants.DECISIONSUBTYPE_ADMIN,
                                                                             decisionReasonType: HsrReferenceConstants.DECISIONREASONTYPE_PREVENTORTREAT,
                                                                             hscServiceDecisionSourceVOs: [new HscServiceDecisionSourceVO(decisionSourceType: HsrReferenceConstants.DECISIONOSOURCETYPE_BENEFIT_DOC,
                                                                                                                                          hscID: hscServiceVO.hscID,
                                                                                                                                          serviceSeqNum: hscServiceVO.serviceSeqNum)],
                                                                             decisionMadeByUserID: SecurityConstants.SYSTEM_HSR,
                                                                             hscID: hscServiceVO.hscID, serviceSeqNum: hscServiceVO.serviceSeqNum)


        when:
        hsc.setAutoApprovedDecisions(hscVO)

        then:
        0 * _
    }*/

    def "Test saveTatForCompleteIntake"() {
        given:
        HscVO hscVO = new HscVO(hscID: 1 as long, serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY)
        HscFacilityVO hscFacilityVO = new HscFacilityVO()
        HscServiceVO hscServiceVO = new HscServiceVO()

        when:
        hsc.saveTatForCompleteIntake(hscVO)

        then:
        1 * mockTatPointHelper.logIntakeCompleteTatPoint(hscVO.getHscID())
        0 * _
    }

    def "Test deleteAll"() {
        when:
        hsc.deleteAll(1 as long)

        then:
        1 * mockPersistenceHelper.deleteCascading(getReadProperties(1 as long), hsc.HSC_TABLES)
        0 * _
    }

    def "Test discardHscMixedCases"() {
        given:
        HscVO hscVO = createValidHscVO()

        when:
        hsc.discardHscMixedCases(hscVO)

        then:
        HsrReferenceConstants.HSCSTATUSTYPE_DISCARDED.equals(hscVO.getHscStatusType())
        HsrReferenceConstants.HSCSTATUSREASONTYPE_MIXED_CASE.equals(hscVO.getHscStatusReasonType())
        1 * mockDao.isDuplicate(new QueryProperties(QueryProperties.FilterType.NEW_FILTER, new QueryFilter(FieldConstants.HSCID, hscVO.getHscID()))) >> true
        2 * mockDao.read(getReadProperties(hscVO.getHscID())) >> hscVO
        1 * customerReference.validateReference(hscVO, FieldConstants.SPECIALPROCESSTYPE, hscVO.getSpecialProcessType(), false)
        1 * customerReference.validateReference(hscVO, FieldConstants.SPECIALPROCESSTYPE, hscVO.getSecondarySpecialProcessType(), false)
        1 * mockPersistenceHelper.update(hscVO)
        1 * historyBusinessLogic.addHistoryVO(hscVO)
        1 * mockNote.add(_ as NoteVO)
        0 * _
    }

    def "Test fetchHscVO where hscVO is null and create is false"() {
        given:
        HscShortFormVO hscShortFormVO = new HscShortFormVO(hscID: 1 as long)

        when:
        HscVO hscVO = hsc.fetchHscVO(hscShortFormVO)

        then:
        thrown(UhgRuntimeException)
        hscVO == null
        1 * mockDao.read(getReadProperties(hscShortFormVO.getHscID())) >> null
        0 * _
    }

    def "Test fetchHscVO where hscVO is null and create is true"() {
        given:
        HscShortFormVO hscShortFormVO = new HscShortFormVO(hscID: 1 as long)

        when:
        HscVO hscVO = hsc.fetchHscVO(hscShortFormVO, true)

        then:
        hscVO == new HscVO()
        1 * mockDao.read(getReadProperties(hscShortFormVO.getHscID())) >> null
        0 * _
    }

    def "Test getDecisionReasonForHscStatusReason"() {
        when:
        String decision = hsc.getDecisionReasonForHscStatusReason(HsrReferenceConstants.HSCSTATUSREASONTYPE_WRONG_MEMBER)

        then:
        HsrReferenceConstants.DECISIONREASONTYPE_WRONG_MEMBER.equals(decision)
        0 * _
    }

    def "Test getPrimaryServiceReferenceNumber where isFacility is true"() {
        given:
        HscVO hscVO = new HscVO(serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY)

        when:
        String serviceReferenceNumber = hsc.getPrimaryServiceReferenceNumber(hscVO)

        then:
        serviceReferenceNumber.equals("00")
        1 * mockHscFacility.read(hscVO.getHscID()) >> new HscFacilityVO(serviceReferenceNum: "00")
        0 * _
    }

    def "Test getPrimaryServiceReferenceNumber where isFacility is false"() {
        given:
        HscVO hscVO = new HscVO()

        when:
        String serviceReferenceNumber = hsc.getPrimaryServiceReferenceNumber(hscVO)

        then:
        serviceReferenceNumber.equals("00")
        1 * mockHscService.readFirstHscServiceVO(hscVO.getHscID()) >> new HscServiceVO(serviceReferenceNum: "00")
        0 * _
    }

    def "Test isValid"() {
        when:
        boolean isValid = hsc.isValid(1 as long)

        then:
        isValid
        1 * mockDao.isValid(getReadProperties(1 as long)) >> true
        0 * _
    }

    def "Test listHscByMember"() {
        given:
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL, new QueryFilter(FieldConstants.MEMBERID, 1 as long),
                                                 new QueryFilter(FieldConstants.HSCSTATUSTYPE, HsrReferenceConstants.HSCSTATUSTYPE_INCOMPLETE, QueryCriteria.NOT_EQUAL))
        qp.setOrderByDescFields(FieldConstants.HSCID)

        when:
        List<HscVO> hscVOList = hsc.listHscByMember(1 as long, true)

        then:
        hscVOList.size() == 1
        1 * mockDao.list(qp) >> Arrays.asList(new HscVO())
        0 * _
    }

    def "Test listHscByMemberHscStatus"() {
        given:
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL, new QueryFilter(FieldConstants.MEMBERID, 1 as long),
                                                 new QueryFilter(FieldConstants.HSCSTATUSTYPE, new StringBuilder().toString()))
        qp.setOrderByDescFields(FieldConstants.HSCID)

        when:
        List<HscVO> hscVOList = hsc.listHscByMemberHscStatus(1 as long)

        then:
        hscVOList.size() == 1
        1 * mockDao.list(qp) >> Arrays.asList(new HscVO())
        0 * _
    }

    def "Test listHscByMemberHscStatusServiceSettingType with 2 parameters"() {
        given:
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL, new QueryFilter(FieldConstants.MEMBERID, 1 as long),
                                                 new QueryFilter(FieldConstants.SERVICESETTINGTYPE, "00"),
                                                 new QueryFilter(FieldConstants.HSCSTATUSTYPE, new StringBuilder().toString()))
        qp.setOrderByDescFields(FieldConstants.HSCID)

        when:
        List<HscVO> hscVOList = hsc.listHscByMemberHscStatusServiceSettingType("00", 1 as long)

        then:
        hscVOList.size() == 1
        1 * mockDao.list(qp) >> Arrays.asList(new HscVO())
        0 * _
    }

    def "Test listHscByMemberHscStatusServiceSettingType with three parameters"() {
        given:
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL, new QueryFilter(FieldConstants.MEMBERID, 1 as long),
                                                 new QueryFilter(FieldConstants.SERVICESETTINGTYPE, "00"),
                                                 new QueryFilter(FieldConstants.HSCSTATUSTYPE, new StringBuilder().toString()),
                                                 new QueryFilter(FieldConstants.HSCID, 1 as long, QueryCriteria.NOT_EQUAL))
        qp.setOrderByDescFields(FieldConstants.HSCID)

        when:
        List<HscVO> hscVOList = hsc.listHscByMemberHscStatusServiceSettingType("00", 1 as long, 1 as long)

        then:
        hscVOList.size() == 1
        1 * mockDao.list(qp) >> Arrays.asList(new HscVO())
        0 * _
    }

    def "Test listHscByMemberServiceSettingType"() {
        given:
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL, new QueryFilter(FieldConstants.MEMBERID, 1 as long),
                                                 new QueryFilter(FieldConstants.SERVICESETTINGTYPE, "00"))
        qp.setOrderByDescFields(FieldConstants.HSCID)

        when:
        List<HscVO> hscVOList = hsc.listHscByMemberServiceSettingType("00", 1 as long)

        then:
        hscVOList.size() == 1
        1 * mockDao.list(qp) >> Arrays.asList(new HscVO())
        0 * _
    }

    def "Test listHscByAutoLetterStatusRequested"() {
        given:
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL, (new QueryFilter(FieldConstants.MEDICAREAUTOLETTERSTATUSTYPE, HsrReferenceConstants.MEDICAREAUTOLETTERSTATUSTYPE_REQUESTED)))
        qp.setOrderByDescFields(FieldConstants.HSCID)
        qp.setUnboundedListAll(true)

        when:
        List<HscVO> hscVOList = hsc.listHscByAutoLetterStatusRequested()

        then:
        hscVOList.size() == 1
        1 * mockDao.list(qp) >> Arrays.asList(new HscVO())
        0 * _
    }

    def "Test updateMedicareAutoLetterStatusToSent where RecordStaleException is thrown"() {
        given:
        HscVO hscVO = new HscVO(hscID: 1 as long, medicareAutoLetterStatusType: HsrReferenceConstants.MEDICAREAUTOLETTERSTATUSTYPE_SENT)

        when:
        hsc.updateMedicareAutoLetterStatusToSent(hscVO)

        then:
        thrown(UpdateException)
        HsrReferenceConstants.MEDICAREAUTOLETTERSTATUSTYPE_SENT.equals(hscVO.getMedicareAutoLetterStatusType())
        1 * mockPersistenceHelper.update(hscVO) >> { throw new RecordStaleException() }
        1 * mockDao.read(getReadProperties(hscVO.getHscID())) >> { throw new UpdateException() }
        0 * _
    }

    def "Test getCaseCountForMember"() {
        when:
        int count = hsc.getCaseCountForMember(1 as long)

        then:
        count == 1
        1 * mockDao.getCount(new QueryProperties(QueryProperties.FilterType.LIST_ALL, new QueryFilter(FieldConstants.MEMBERID, 1 as long))) >> 1
        0 * _
    }

    def "Test listHscWithoutCreateHsc"() {
        given:
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        QueryProperties qp1 = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        qp1.setOrderByDescFields(FieldConstants.HSCID)
        hsc.addExcludeIncompleteHscQueryFilter(qp1)

        when:
        List<HscVO> hscVOList = hsc.listHscWithoutCreateHsc(qp)

        then:
        hscVOList.size() == 1
        1 * mockDao.list(qp1) >> Arrays.asList(new HscVO())
        0 * _
    }

    def "Test logHscCommTxnActivity"() {
        given:
        String activityType = "00"
        HscVO hscVO = new HscVO(hscID: 1 as long, memberID: 1 as long)
        long commTxnId = 1 as long

        when:
        hsc.logHscCommTxnActivity(activityType, hscVO, commTxnId)

        then:
        1 * mockActivity.add(new ActivityVO(activityType: activityType, hscID: hscVO.getHscID(), communicationTransactionID: commTxnId, memberID: hscVO.getMemberID()))
        0 * _
    }
    /*

    @Ignore
    def "Test readCascading"() {
        given:
        HscVO expectedHscVO = new HscVO(hscID: 1 as long)
        expectedHscVO.addGlobalMessage(GlobalMessages.ERR_REQUIRED_VALUE)

        when:
        HscVO actualHscVO = hsc.readCascading(expectedHscVO.getHscID())

        then:
        thrown(NullPointerException) //Shouldn't do this. Needs fix
        1 * mockHscAlternateIdentifier.getTableDef() >> new TableDef(table: TableConstants.HSC_ALT_ID, valueObjectClass: HscAlternateIdentifierVO, listFields: [FieldConstants.CRUD_FIELDS],
                                                                     fields: [FieldConstants.CRUD_FIELDS], key: [FieldConstants.HSCID])
        1 * mockHscAlternateIdentifier.list(new QueryProperties(QueryProperties.FilterType.LIST_ALL, new QueryFilter(FieldConstants.HSCID, expectedHscVO.getHscID()))) >> Arrays.asList(new HscAlternateIdentifierVO())
        1 * mockHscService.getTableDef() >> new TableDef(table: TableConstants.HSC_SRVC, valueObjectClass: HscServiceVO, listFields: [FieldConstants.CRUD_FIELDS],
                                                         fields: [FieldConstants.CRUD_FIELDS], key: [FieldConstants.HSCID])
        1 * mockHscService.list(new QueryProperties(QueryProperties.FilterType.LIST_ALL, new QueryFilter(FieldConstants.HSCID, expectedHscVO.getHscID()))) >> Arrays.asList(new HscServiceVO())
        1 * mockDao.read(getReadProperties(expectedHscVO.getHscID())) >> expectedHscVO
        0 * _
    }*/

    def "Test reopenHscFromPendingCloseAsNeeded"() {
        given:
        HscVO hscVO = new HscVO(hscID: 1 as long, memberID: 1 as long, hscStatusType: HsrReferenceConstants.HSCSTATUSTYPE_PENDING_CLOSE)

        when:
        hsc.reopenHscFromPendingCloseAsNeeded(hscVO)

        then:
        HsrReferenceConstants.HSCSTATUSTYPE_OPEN.equals(hscVO.getHscStatusType())
        HsrReferenceConstants.HSCSTATUSREASONTYPE_OPEN.equals(hscVO.getHscStatusReasonType())
        1 * mockPersistenceHelper.updateSubset(hscVO, [FieldConstants.HSCSTATUSTYPE, FieldConstants.HSCSTATUSREASONTYPE] as String[], true)
        1 * mockCodeXRef.getInboundAttributeToValue(HsrReferenceConstants.SYSTEMTYPE_HSR, CommonConstants.CD_XREF_ACTV_REASON_TO_ACTV_RESOLUTION_REASON, hscVO.getHscStatusReasonType(), null) >> "00"
        1 * mockActivity.add(_ as ActivityVO)
        0 * _
    }

    def "Test reopenLetterRelatedHsc where hscVO is pending closure"() {
        given:
        HscVO hscVO = new HscVO(hscID: 1 as long, memberID: 1 as long, hscStatusType: HsrReferenceConstants.HSCSTATUSTYPE_PENDING_CLOSE)

        when:
        hsc.reopenLetterRelatedHsc(hscVO.getHscID(), "comment")

        then:
        HsrReferenceConstants.HSCSTATUSTYPE_OPEN.equals(hscVO.getHscStatusType())
        HsrReferenceConstants.HSCSTATUSREASONTYPE_OPEN.equals(hscVO.getHscStatusReasonType())
        1 * mockDao.read(getReadProperties(hscVO.getHscID())) >> hscVO
        1 * mockPersistenceHelper.updateSubset(hscVO, [FieldConstants.HSCSTATUSTYPE, FieldConstants.HSCSTATUSREASONTYPE] as String[], true)
        1 * mockCodeXRef.getInboundAttributeToValue(HsrReferenceConstants.SYSTEMTYPE_HSR, CommonConstants.CD_XREF_ACTV_REASON_TO_ACTV_RESOLUTION_REASON, hscVO.getHscStatusReasonType(), null) >> "00"
        1 * mockActivity.add(_ as ActivityVO)
        0 * _
    }

    def "Test reopenLetterRelatedHsc where hscVO is open"() {
        given:
        HscVO hscVO = new HscVO(hscID: 1 as long, memberID: 1 as long, hscStatusType: HsrReferenceConstants.HSCSTATUSTYPE_OPEN)

        when:
        hsc.reopenLetterRelatedHsc(hscVO.getHscID(), "comment")

        then:
        1 * mockDao.read(getReadProperties(hscVO.getHscID())) >> hscVO
        1 * hscAlert.replaceOpenAlertAsNeeded(hscVO.getHscID(), CommonReferenceConstants.ALERTTYPE_LETTER_GENERATION_ERROR, "comment")
        0 * _
    }

    @Unroll
    def "Test searchHscAndUpdateMember #testcase"() {
        given:
        ReadProperties rp = new ReadProperties([FieldConstants.GLOBALID] as String[])
        rp.setKeyValue(FieldConstants.GLOBALID, "00")

        when:
        hsc.searchHscAndUpdateMember("00", idType)

        then:
        thrown(UhgRuntimeException)
        if(idType) 1 * mockDao.read(rp) >> new HscVO(dataSecurityTypeList: Arrays.asList("00"))
        0 * _

        where:
        [testcase, idType] << [["where idType is null", null],
                ["where idType is Global_ID", HscConstants.HscIDTypeEnum.GLOBAL_ID]]
    }

    def "Test setCOBData"() {
        given:
        HscVO hscVO = new HscVO()
        MemberVO memberVO = new MemberVO(cobStartDate: new Date(1, 1, 1), cobEndDate: new Date(2, 2, 2), otherCoverageOrderType: "00")

        when:
        hsc.setCOBData(hscVO, memberVO)

        then:
        hscVO.getCobStartDate().equals(memberVO.getCobStartDate())
        hscVO.getCobEndDate().equals(memberVO.getCobEndDate())
        hscVO.getCobRoleCode().equals(memberVO.getOtherCoverageOrderType())
        hscVO.getCobInd()
        0 * _
    }

    def "Test setMemberPrimaryAddress"() {
        given:
        HscVO hscVO = new HscVO(memberID: 1 as long)
        MemberAddressVO memberAddressVO = new MemberAddressVO()

        when:
        hsc.setMemberPrimaryAddress(hscVO)

        then:
        memberAddressVO.equals(hscVO.getMemberPrimaryAddressVO())
        1 * mockMemberAddress.getActiveMemberAddressForMember(hscVO.getMemberID()) >> memberAddressVO
        0 * _
    }

    def "Test logHscAutomatedActivity"() {
        given:
        HscVO hscVO = new HscVO(hscID: 1 as long, memberID: 1 as long, hscStatusReasonType: "03")
        String activityType = "00", resolutionReasonType = "01", resolutionOutcomeType = "02"

        when:
        hsc.logHscAutomatedActivity(activityType, hscVO, resolutionReasonType, resolutionOutcomeType)

        then:
        1 * mockActivity.add(new ActivityVO(activityType: activityType, hscID: hscVO.getHscID(), activityResolutionReasonType: resolutionReasonType,
                                            activityResolutionOutcomeType: resolutionOutcomeType, memberID: hscVO.getMemberID()))
        0 * _
    }

    def "Test updateMedicareAutoLetter where Exception is thrown"() {
        given:
        HscVO hscVO = new HscVO()

        when:
        hsc.updateMedicareAutoLetter(hscVO)

        then:
        thrown(UhgRuntimeException)
        1 * mockPersistenceHelper.updateSubset(hscVO, [FieldConstants.MEDICAREAUTOLETTERREQUSERID,
                                                       FieldConstants.MEDICAREAUTOLETTERSTATUSTYPE] as String[], true) >> { throw new Exception() }
        0 * _
    }

    def "Test updateHscMemberCoverageSeqNum"() {
        given:
        long hscId = 1 as long
        Date serviceDate = new Date(1, 1, 1)
        HscVO hscVO = new HscVO(memberID: 1 as long, memberCoverageSeqNum: 2 as short)
        HscVO newHscVO = new HscVO(memberID: 1 as long, memberCoverageSeqNum: 3 as short)
        HscMemberCoverageVO hscMemberCoverageVO = new HscMemberCoverageVO(memberCoverageSeqNum: 3 as short)
        List<HscMemberCoverageVO> hscMemberCoverageVOList = Arrays.asList(hscMemberCoverageVO)
        MemberVO memberVO = new MemberVO(origSystemMemberIDType: "00")

        when:
        hsc.updateHscMemberCoverageSeqNum(hscId, serviceDate)

        then:
        0 * _
    }

    @Unroll
    def "Test getHscMemberCoverages #testcase"() {
        given:
        MemberVO memberVO = new MemberVO(recordSourceType: recordSourceType, newbornViaIntake: false, memberCoverageList: new ArrayList<BaseMemberCoverageVO>())

        when:
        List<HscMemberCoverageVO> hscMemberCoverageVOList = hsc.getHscMemberCoverages(memberVO)

        then:
        hscMemberCoverageVOList.size() == 1
        1 * mockHscMemberCoverage.convertMemberCoverageListToHscMemberCoverageList(memberVO.getMemberCoverageList(), 0) >> Arrays.asList(new HscMemberCoverageVO())
        0 * _

        where:
        [testcase, recordSourceType] << [["where recordSourceType equals '2'", HsrReferenceConstants.RECORDSOURCETYPE_MANUAL],
                                         ["where recordSourceType equals '1'", HsrReferenceConstants.RECORDSOURCETYPE_EXTERNAL]]
    }

    @Unroll
    def "Test getServiceDate where hscVO.isFacility equals true and actualAdmissionDate = #actualAdmissionDate"() {
        given:
        HscVO hscVO = new HscVO(hscID: 1 as long, serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT)
        Date expectedDate = new Date(1, 1, 1)

        when:
        Date date = hsc.getServiceDate(hscVO)

        then:
        if(actualAdmissionDate) date == actualAdmissionDate.getSQLDate()
        else date == expectedDate
        1 * mockHscFacility.read(hscVO.getHscID()) >> new HscFacilityVO(actualAdmissionDateTime: actualAdmissionDate, expectedAdmissionDate: expectedDate)
        0 * _

        where:
        [actualAdmissionDate] << [[new UhgCalendar()], [null]]
    }

    def "Test getServiceDate where hscVO.isFacility equals false"() {
        given:
        HscVO hscVO = new HscVO(hscID: 1 as long, serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT)
        Date serviceDate = new Date(1, 1, 1)

        when:
        Date date = hsc.getServiceDate(hscVO)

        then:
        0 * _
    }
    /*

    @Ignore
    def "Test readHscAndRefreshCoverages"() {
        given:
        long tempMemberId = 1 as long
        MemberVO permanentMemberVO = new MemberVO(memberID: 1 as long)
        ValueObject errorVO = new ValueObject()
        boolean batch = false
        HscVO hscVO = createValidHscVO()
        List<HscVO> hscVOList = new ArrayList<HscVO>([hscVO, new HscVO()])
        List<HscMemberCoverageVO> hscMemberCoverageVOList = new ArrayList<>([new HscMemberCoverageVO()])
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL, new QueryFilter(FieldConstants.MEMBERID, tempMemberId),
                                                 new QueryFilter(FieldConstants.HSCSTATUSTYPE, GenericUtilities.convertToCommaDelimitedString(
                                                         [HsrReferenceConstants.HSCSTATUSTYPE_OPEN, HsrReferenceConstants.HSCSTATUSTYPE_AWAITING_ADMISSION] as String[])))
        qp.setOrderByAscFields(FieldConstants.CHANGEDATETIME)

        when:
        hsc.readHscAndRefreshCoverages(tempMemberId, permanentMemberVO, errorVO, batch)

        then:
        1 * mockDao.list(qp) >> hscVOList
        1 * mockHscMemberCoverage.getMedicalMemberCoverages(permanentMemberVO) >> hscMemberCoverageVOList
        1 * mockHscMemberCoverage.deleteCoveragesForHsc(hscVOList.get(0).getHscID())
        1 * mockHscMemberCoverage.addCoveragesForHsc(hscMemberCoverageVOList, hscVOList.get(0))
        1 * mockHscMemberCoverage.listByHscID(hscVO.getHscID()) >> hscMemberCoverageVOList
        1 * mockCoverageSystemCheckHelper.selectMemberCoverageForHsr(hscMemberCoverageVOList, UhgCalendarUtilities.getTodaysDate(), permanentMemberVO.getOrigSystemMemberIDType(),
                                                                     hscVO.isBehavioralServiceCategory()) >> hscMemberCoverageVOList.get(0)
        2 * mockDao.read(getReadProperties(hscVO.getHscID())) >> hscVO
        1 * customerReference.isValidReferenceChildFilter('hscStatusType', '1', 'hscStatusReasonType', '12') >> true
        1 * customerReference.validateReference(hscVO, FieldConstants.SPECIALPROCESSTYPE, hscVO.getSpecialProcessType(), false)
        1 * customerReference.validateReference(hscVO, FieldConstants.SPECIALPROCESSTYPE, hscVO.getSecondarySpecialProcessType(), false)
        1 * mockPersistenceHelper.update(hscVO)
        1 * historyBusinessLogic.addHistoryVO(hscVO)
        4 * _
    }

    @Ignore
    def "Test updateMemberIDInHsc"() {
        given:
        MemberVO tempMemberVO = new MemberVO(memberID: 1 as long)
        MemberVO permMemberVO = new MemberVO(memberID: 1 as long)
        ValueObject errorVO = new ValueObject()
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL, new QueryFilter(FieldConstants.MEMBERID, tempMemberVO.getMemberID()))
        qp.setOrderByAscFields(FieldConstants.CHANGEDATETIME)
        HscVO hscVO = new HscVO(memberID: 1 as long)
        List<HscVO> hscVOList = new ArrayList<HscVO>([hscVO])

        when:
        hsc.updateMemberIDInHsc(tempMemberVO, permMemberVO, errorVO)

        then:
        1 * mockDao.list(qp) >> hscVOList
        1 * mockPersistenceHelper.updateBatch(hscVOList)
        0 * _
    }

    @Ignore
    def "Test batchMergeTempToPermanentMember"() {
        given:
        MemberVO tempMemberVO = new MemberVO(memberID: 1 as long)
        MemberVO permMemberVO = new MemberVO(memberID: 1 as long)
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL, new QueryFilter(FieldConstants.MEMBERID, tempMemberVO.getMemberID()),
                                                 new QueryFilter(FieldConstants.HSCSTATUSTYPE, GenericUtilities.convertToCommaDelimitedString(
                                                         [HsrReferenceConstants.HSCSTATUSTYPE_OPEN, HsrReferenceConstants.HSCSTATUSTYPE_AWAITING_ADMISSION] as String[])))
        qp.setOrderByAscFields(FieldConstants.CHANGEDATETIME)
        QueryProperties qp2 = new QueryProperties(QueryProperties.FilterType.LIST_ALL, new QueryFilter(FieldConstants.MEMBERID, tempMemberVO.getMemberID()),)
        qp2.setOrderByAscFields(FieldConstants.CHANGEDATETIME)

        when:
        hsc.batchMergeTempToPermanentMember(memberMergePartVO)

        then:
        1 * mockMember.isValid(memberMergePartVO.getMemberID()) >> true
        1 * mockMember.readCascading(memberMergePartVO.getMemberID()) >> tempMemberVO
        1 * mockMember.isValid(memberMergePartVO.getMergedToMemberID()) >> true
        1 * mockMember.readCascading(memberMergePartVO.getMergedToMemberID()) >> permMemberVO
        1 * mockDao.list(qp) >> new ArrayList<>()
        1 * temporarySystemSetting.getIntSetting(TemporarySystemSettingType.TEMP_MEMBER_MERGE_MAX_RECORDS.getTempSystemSettingName()) >> 0
        1 * mockDao.list(qp2) >> new ArrayList<>()
        1 * mockPersistenceHelper.updateBatch([])
        0 * _
    }*/

    def "Test isHscFacilityOrServicesLocked"() {
        given:
        long hscId = 1 as long

        when:
        boolean isHscFacilityOrServicesLocked = hsc.isHscFacilityOrServicesLocked(hscId)

        then:
        isHscFacilityOrServicesLocked
        1 * mockDao.read(getReadProperties(hscId)) >> new HscVO(serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT)
        1 * mockHscFacility.read(hscId) >> new HscFacilityVO(hscFacilityLockType: HsrReferenceConstants.HSCFACILITYLOCKTYPE_NO_LOCK)
        1 * mockHscService.listByHscID(hscId, false) >> Arrays.asList(new HscServiceVO(hscServiceLockType: HsrReferenceConstants.HSCSERVICELOCKTYPE_FULL_LOCK))
        0 * _
    }

    def "Test validateCloseStatusReasonType"() {
        given:
        String statusReasonType = ""
        HscVO hscVO = new HscVO()

        when:
        hsc.validateCloseStatusReasonType(statusReasonType, hscVO)

        then:
        hscVO.getGlobalMessages().contains(HsrMessages.ERR_HSC_CLOSE_REASON_REQUIRED)
        0 * _
    }

    @Unroll
    def "Test getBestDateForNetworkStatus where serviceSettingType equals #serviceSettingType"() {
        given:
        long hscId = 1 as long
        short serviceSequenceNum = 2 as short
        Date expectedDate = new Date(1, 1, 1)

        when:
        Date actualDate = hsc.getBestDateForNetworkStatus(hscId, serviceSequenceNum)

        then:
        actualDate.equals(expectedDate)
        1 * mockDao.read(getReadProperties(hscId)) >> new HscVO(hscID: hscId, serviceSettingType: serviceSettingType)
        if(CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT.equals(serviceSettingType))
            1 * mockHscFacility.getBestDateForNetworkStatus(hscId) >> expectedDate
        else 1 * mockHscService.getBestDateForNetworkStatus(hscId, serviceSequenceNum) >> expectedDate
        0 * _

        where:
        [serviceSettingType] << [[CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT], [CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT]]
    }

    def "Test updateReviewPriorityType"() {
        given:
        HscVO hscVO = new HscVO()

        when:
        hsc.updateReviewPriorityType(hscVO, false)

        then:
        1 * mockPersistenceHelper.updateSubset(hscVO, [FieldConstants.REVIEWPRIORITYTYPE] as String[], false)
        0 * _
    }

    def "Test updateSpecialProcessType"() {
        given:
        HscVO hscVO = new HscVO()

        when:
        hsc.updateSpecialProcessType(hscVO)

        then:
        1 * mockPersistenceHelper.updateSubset(hscVO, [FieldConstants.SPECIALPROCESSTYPE] as String[], true)
        0 * _
    }

    def "Test updateDecisionID"() {
        given:
        HscVO hscVO = new HscVO()

        when:
        hsc.updateDecisionID(hscVO)

        then:
        1 * mockPersistenceHelper.updateSubset(hscVO, [FieldConstants.DECISIONID] as String[], true)
        0 * _
    }

    def "Test readHscAndMemberCoverages"() {
        when:
        HscVO hscVO = hsc.readHscAndMemberCoverages(1 as long)

        then:
        hscVO.getHscMemberCoverageVOs().size() == 1
        1 * mockDao.read(getReadProperties(1)) >> new HscVO()
        1 * mockHscMemberCoverage.listByHscID(1) >> Arrays.asList(new HscMemberCoverageVO())
        0 * _
    }

    def "Test validateVendorCaseID where vendorCaseID is blank"() {
        when:
        ValueObject errorVO = hsc.validateVendorCaseID(new HscVO())

        then:
        HsrMessages.ERR_VENDOR_CASE_ID_BLANK.equals(errorVO.getGlobalMessages().getAt(0))
        0 * _
    }

    def "Test validateVendorCaseID where isBeaconLBS"() {
        when:
        ValueObject errorVO = hsc.validateVendorCaseID(new HscVO(hscID: 1 as long, vendorTypeID: CssReferenceConstants.VENDOR_TYPE_BEACONLBS,
                                                                 vendorCaseID: "00", specialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_CARECORE_CSP_FACETS))

        then:
        errorVO.getGlobalMessages().contains(HsrMessages.ERR_DUPLICATE_VENDOR_CASE_ID)
        errorVO.getGlobalMessages().contains(HsrMessages.ERR_VENDOR_CASE_ID_INVALID_LENGTH_BEACONLBS)
        1 * mockDao.isDuplicate(new QueryProperties(QueryProperties.FilterType.LIST_ALL, new QueryFilter(FieldConstants.VENDORCASEID, "00"),
                                                    new QueryFilter(FieldConstants.HSCID, 1 as long, QueryCriteria.NOT_EQUAL),
                                                    new QueryFilter(FieldConstants.HSCSTATUSTYPE, HsrReferenceConstants.HSCSTATUSTYPE_CANCELLED, QueryCriteria.NOT_EQUAL),
                                                    new QueryFilter(FieldConstants.HSCSTATUSTYPE, HsrReferenceConstants.HSCSTATUSTYPE_INCOMPLETE, QueryCriteria.NOT_EQUAL),
                                                    new QueryFilter(FieldConstants.HSCSTATUSTYPE, HsrReferenceConstants.HSCSTATUSTYPE_DISCARDED, QueryCriteria.NOT_EQUAL))) >> true
        0 * _
    }

    def "Test validateVendorCaseID where isCareCoreMandR is true"() {
        when:
        ValueObject errorVO = hsc.validateVendorCaseID(new HscVO(hscID: 1 as long, vendorCaseID: "0", specialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_CARECORE))

        then:
        errorVO.getGlobalMessages().contains(HsrMessages.ERR_VENDOR_CASE_ID_CONTAINS_ALL_NUMERIC_CHARS)
        errorVO.getGlobalMessages().contains(HsrMessages.ERR_DUPLICATE_VENDOR_CASE_ID)
        errorVO.getGlobalMessages().contains(HsrMessages.ERR_VENDOR_CASE_ID_INVALID_LENGTH_CARECORE)
        1 * mockDao.isDuplicate(new QueryProperties(QueryProperties.FilterType.LIST_ALL, new QueryFilter(FieldConstants.VENDORCASEID, "0"),
                                                    new QueryFilter(FieldConstants.SPECIALPROCESSTYPE, HsrReferenceConstants.SPECIALPROCESSTYPE_CARECORE),
                                                    new QueryFilter(FieldConstants.HSCID, 1 as long, QueryCriteria.NOT_EQUAL),
                                                    new QueryFilter(FieldConstants.HSCSTATUSTYPE, HsrReferenceConstants.HSCSTATUSTYPE_CANCELLED, QueryCriteria.NOT_EQUAL),
                                                    new QueryFilter(FieldConstants.HSCSTATUSTYPE, HsrReferenceConstants.HSCSTATUSTYPE_INCOMPLETE, QueryCriteria.NOT_EQUAL),
                                                    new QueryFilter(FieldConstants.HSCSTATUSTYPE, HsrReferenceConstants.HSCSTATUSTYPE_DISCARDED, QueryCriteria.NOT_EQUAL))) >> true
        0 * _
    }

    def "Test validateVendorCaseID where isCareCoreMandR is true and vendorCaseID is not alpha or numeric"() {
        when:
        ValueObject errorVO = hsc.validateVendorCaseID(new HscVO(hscID: 1 as long, vendorCaseID: "^", specialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_CARECORE))

        then:
        errorVO.getGlobalMessages().contains(HsrMessages.ERR_VENDOR_CASE_ID_CONTAINS_NON_ALPHA_NUMERIC_CHARS)
        errorVO.getGlobalMessages().contains(HsrMessages.ERR_DUPLICATE_VENDOR_CASE_ID)
        errorVO.getGlobalMessages().contains(HsrMessages.ERR_VENDOR_CASE_ID_INVALID_LENGTH_CARECORE)
        1 * mockDao.isDuplicate(new QueryProperties(QueryProperties.FilterType.LIST_ALL, new QueryFilter(FieldConstants.VENDORCASEID, "^"),
                                                    new QueryFilter(FieldConstants.SPECIALPROCESSTYPE, HsrReferenceConstants.SPECIALPROCESSTYPE_CARECORE),
                                                    new QueryFilter(FieldConstants.HSCID, 1 as long, QueryCriteria.NOT_EQUAL),
                                                    new QueryFilter(FieldConstants.HSCSTATUSTYPE, HsrReferenceConstants.HSCSTATUSTYPE_CANCELLED, QueryCriteria.NOT_EQUAL),
                                                    new QueryFilter(FieldConstants.HSCSTATUSTYPE, HsrReferenceConstants.HSCSTATUSTYPE_INCOMPLETE, QueryCriteria.NOT_EQUAL),
                                                    new QueryFilter(FieldConstants.HSCSTATUSTYPE, HsrReferenceConstants.HSCSTATUSTYPE_DISCARDED, QueryCriteria.NOT_EQUAL))) >> true
        0 * _
    }

    def "Test readByVendorCaseID"() {
        given:
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.NEW_FILTER, new QueryFilter(FieldConstants.VENDORCASEID, "00"),
                                                 new QueryFilter(FieldConstants.VENDORTYPEID, "1"),
                                                 new QueryFilter(FieldConstants.HSCSTATUSTYPE, GenericUtilities.getDelimitedString(hsc.statusTypesForHscSearchWithCareCore)))
        qp.setOrderByAscFields(FieldConstants.HSCSTATUSTYPE)
        qp.setResultSize(1)

        when:
        HscVO hscVO = hsc.readByVendorCaseID("00", "1")

        then:
        hscVO.getHscID() == 1 as long
        1 * mockDao.list(qp) >> Arrays.asList(new HscVO(hscID: 1 as long))
        0 * _
    }

    def "Test listByMemberAndClinicalTrialSequenceNum"() {
        when:
        List<HscVO> hscVOList = hsc.listByMemberAndMemberClinicalTrialID(1 as long, 2 as long)

        then:
        hscVOList.size() == 1
        1 * mockDao.list(new QueryProperties(QueryProperties.FilterType.LIST_ALL, new QueryFilter(FieldConstants.MEMBERID, 1 as long),
                                             new QueryFilter(FieldConstants.MEMBERCLINICALTRIALID, 2 as long))) >> Arrays.asList(new HscVO())
        0 * _
    }

    def "Test hasHscHistory"() {
        when:
        boolean hasHscHistory = hsc.hasHscHistory(1 as long)

        then:
        hasHscHistory
        1 * mockDao.exists(new QueryProperties(QueryProperties.FilterType.NEW_FILTER, new QueryFilter(FieldConstants.MEMBERID, 1 as long),
                                               new QueryFilter(FieldConstants.HSCSTATUSTYPE, HsrReferenceConstants.HSCSTATUSTYPE_DISCARDED, QueryCriteria.NOT_EQUAL),
                                               new QueryFilter(FieldConstants.HSCSTATUSTYPE, HsrReferenceConstants.HSCSTATUSTYPE_INCOMPLETE, QueryCriteria.NOT_EQUAL))) >> true
        0 * _
    }

    def "Test hasOpenOrAnticipatedCase"() {
        given:
        QueryFilter qf = new QueryFilter()
        qf.addQueryFilter(new QueryFilter(FieldConstants.HSCSTATUSTYPE, HsrReferenceConstants.HSCSTATUSTYPE_OPEN))
        qf.addQueryFilter(new QueryFilter(FieldConstants.HSCSTATUSTYPE, HsrReferenceConstants.HSCSTATUSTYPE_AWAITING_ADMISSION, QueryCriteria.EQUAL, QueryFilter.SqlPredicateKeyword.OR))

        when:
        boolean hasOpenOrAnticipatedCase = hsc.hasOpenOrAnticipatedCase(1 as long)

        then:
        hasOpenOrAnticipatedCase
        1 * mockDao.exists(new QueryProperties(QueryProperties.FilterType.LIST_ALL, new QueryFilter(FieldConstants.MEMBERID, 1 as long), qf)) >> true
        0 * _
    }

    def "Test hasActiveCaseForGPLetters"() {
        when:
        List<HscVO> hscVOList = hsc.hasActiveCaseForGPLetters(1 as long)

        then:
        hscVOList.size() == 1
        1 * mockDao.list(new QueryProperties(QueryProperties.FilterType.LIST_ALL, new QueryFilter(FieldConstants.MEMBERID, 1 as long),
                                             new QueryFilter(QueryFilter.SqlPredicateKeyword.OR,
                                                             new QueryFilter(FieldConstants.MEMBERPROGRAMSTATUSTYPE, HsrReferenceConstants.HSCSTATUSTYPE_OPEN),
                                                             new QueryFilter(FieldConstants.MEMBERPROGRAMSTATUSTYPE, HsrReferenceConstants.HSCSTATUSTYPE_CLOSED),
                                                             new QueryFilter(FieldConstants.MEMBERPROGRAMSTATUSTYPE, HsrReferenceConstants.HSCSTATUSTYPE_AWAITING_ADMISSION),
                                                             new QueryFilter(FieldConstants.MEMBERPROGRAMSTATUSTYPE, HsrReferenceConstants.HSCSTATUSTYPE_PENDING_CLOSE)))) >> Arrays.asList(new HscVO())
        0 * _
    }
/*
    @Ignore
    def "Test getHscFacilityByMember"() {
        given:
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.NEW_FILTER, new QueryFilter(FieldConstants.MEMBERID, 1 as long),
                                                 new QueryFilter(FieldConstants.SERVICESETTINGTYPE, CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT, QueryCriteria.NOT_EQUAL))
        qp.setOrderByDescFields(FieldConstants.CREATEDATETIME)

        when:
        HscFacilityVO hscFacilityVO = hsc.getHscFacilityByMember(1 as long)

        then:
        hscFacilityVO
        1 * mockDao.list(qp) >> new ArrayList<>()
        0 * _
    }*/

    def "Test hasInpatientHscWithNoActualDischargeDate"() {
        given:
        List<HscVO> hscVOs = Arrays.asList(new HscVO(hscID: 1 as long))

        when:
        boolean hasInpatientHscWithNoActualDischargeDate = hsc.hasInpatientHscWithNoActualDischargeDate(1 as long, new UhgCalendar())

        then:
        hasInpatientHscWithNoActualDischargeDate
        1 * mockDao.list(new QueryProperties(QueryProperties.FilterType.LIST_ALL, new QueryFilter(FieldConstants.MEMBERID, 1 as long),
                                             new QueryFilter(FieldConstants.SERVICESETTINGTYPE, CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT),
                                             new QueryFilter(FieldConstants.HSCSTATUSTYPE, [HsrReferenceConstants.HSCSTATUSTYPE_OPEN, HsrReferenceConstants.HSCSTATUSTYPE_NTF_NOT_REQUIRED], QueryCriteria.IN))) >> hscVOs
        1 * mockHscFacility.list(new QueryProperties(QueryProperties.FilterType.LIST_ALL, new QueryFilter(FieldConstants.HSCID, hscVOs.collect { HscVO vo -> vo.hscID }, QueryCriteria.IN),
                                                     new QueryFilter(FieldConstants.ACTUALADMISSIONDATETIME, null, QueryCriteria.IS_NOT_NULL),
                                                     new QueryFilter(FieldConstants.ACTUALDISCHARGEDATETIME, null, QueryCriteria.IS_NULL))) >> Arrays.asList(new HscFacilityVO())
        0 * _
    }

    def "Test readByDecisionID"() {
        given:
        ReadProperties rp = new ReadProperties([FieldConstants.DECISIONID] as String[])
        rp.setKeyValue(FieldConstants.DECISIONID, "00")

        when:
        HscVO hscVO = hsc.readByDecisionID("00")

        then:
        hscVO.getHscID() == 1 as long
        1 * mockDao.read(rp) >> new HscVO(hscID: 1 as long)
        0 * _
    }

    def "Test exists"() {
        when:
        boolean exists = hsc.exists("00")

        then:
        exists
        1 * mockDao.exists(new QueryProperties(QueryProperties.FilterType.LIST_ALL, new QueryFilter(FieldConstants.DECISIONID, "00"))) >> true
        0 * _
    }

    @Unroll
    def "Test validateRulesOverrideDataOnCase where notifyRuleOverrideReason equals #notifyRuleOverrideReason"() {
        given:
        HscVO hscVO = new HscVO()

        when:
        hsc.validateRulesOverrideDataOnCase(notifyRuleOverrideReason, null, hscVO)

        then:
        hscVO.getMessages().size() == 1
        0 * _

        where:
        [notifyRuleOverrideReason] << [[null], [HsrReferenceConstants.NOTIFYRULEOVERRIDEREASONTYPE_OTHER]]
    }

    def "Test isAslocCase"() {
        given:
        HscVO hscVO = new HscVO(serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT)
        HscFacilityVO hscFacilityVO = new HscFacilityVO(placeOfServiceCode: HsrReferenceConstants.PLACEOFSERVICE_ACUTE_HOSPITAL,
                                                        serviceDetailType: HsrReferenceConstants.SERVICEDETAILTYPE_LTAC,
                                                        serviceDescriptionType: HsrReferenceConstants.SERVICEDESCRIPTIONTYPE_SCHEDULED)

        when:
        boolean isAslocCase = hsc.isAslocCase(hscVO, hscFacilityVO)

        then:
        isAslocCase
        0 * _
    }

    def "Test addServiceOrFacilityLineDataNextGen where isInPatient equals true"() {
        given:
        HscInitiateIntakeCompositeVO hscIntakeCompositeVO = new HscInitiateIntakeCompositeVO(
                hscVO: new HscVO(hscID: 1 as long))
        HscFacilityVO hscFacilityVO = new HscFacilityVO(skipValidation: true, serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT)

        when:
        hsc.addServiceOrFacilityLineDataNextGen(hscIntakeCompositeVO)

        then:
        1 * mockDao.read(getReadProperties(1)) >> new HscVO(hscID: 1 as long, memberID: 2 as long)
        1 * mockHscMemberCoverage.listByHscID(1) >> Arrays.asList(new HscMemberCoverageVO())
        0 * _
    }

    def "Test addServiceOrFacilityLineDataNextGen where isOutpatientFacility equals true"() {
        given:
        HscInitiateIntakeCompositeVO hscIntakeCompositeVO = new HscInitiateIntakeCompositeVO(
                hscVO: new HscVO(hscID: 1 as long), serviceStartDate: new Date(1, 1, 1))
        HscFacilityVO hscFacilityVO = new HscFacilityVO(skipValidation: true, serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY,
                                                        expirationDate: new Date(1, 1, 1) + 90)

        when:
        hsc.addServiceOrFacilityLineDataNextGen(hscIntakeCompositeVO)

        then:
        hscIntakeCompositeVO.getHscVO().getMemberID() == 2
        hscIntakeCompositeVO.getHscVO().getHscMemberCoverageVOs().size() == 1
        1 * mockDao.read(getReadProperties(1)) >> new HscVO(hscID: 1 as long, memberID: 2 as long)
        1 * mockHscMemberCoverage.listByHscID(1) >> Arrays.asList(new HscMemberCoverageVO())
        0 * _
    }

    def "Test addServiceOrFacilityLineDataNextGen where isOutpatient equals true"() {
        given:
        HscInitiateIntakeCompositeVO hscIntakeCompositeVO = new HscInitiateIntakeCompositeVO(
                hscVO: new HscVO(hscID: 1 as long), hscServiceVOs: Arrays.asList(new HscServiceVO(hscID: 1 as long, serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT,
                                                                                                  skipValidation: true, hscServiceNonFacilityVO: new HscServiceNonFacilityVO(hscID: 1 as long, serviceStartDate: new Date(1, 1, 1), skipValidation: true))))

        when:
        hsc.addServiceOrFacilityLineDataNextGen(hscIntakeCompositeVO)

        then:
        hscIntakeCompositeVO.getHscServiceVOs().get(0)
        hscIntakeCompositeVO.getHscVO().getMemberID() == 2
        hscIntakeCompositeVO.getHscVO().getHscMemberCoverageVOs().size() == 1
        1 * mockDao.read(getReadProperties(1)) >> new HscVO(hscID: 1 as long, memberID: 2 as long)
        1 * mockHscMemberCoverage.listByHscID(1) >> Arrays.asList(new HscMemberCoverageVO())
        0 * _
    }

    def "Test listMedicalHscByMember"() {
        given:
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL, new QueryFilter(FieldConstants.MEMBERID, 1 as long),
                                                 new QueryFilter(FieldConstants.SERVICECATEGORYTYPE, HsrReferenceConstants.SERVICE_CATEGORY_MEDICAL),
                                                 new QueryFilter(FieldConstants.HSCSTATUSTYPE, GenericUtilities.getDelimitedString(
                                                         (Object[]) [HsrReferenceConstants.HSCSTATUSTYPE_OPEN, HsrReferenceConstants.HSCSTATUSTYPE_CLOSED,
                                                                     HsrReferenceConstants.HSCSTATUSTYPE_AWAITING_ADMISSION, HsrReferenceConstants.HSCSTATUSTYPE_CANCELLED] as String[])))
        qp.setOrderByDescFields(FieldConstants.PRIMARYSERVICEREFERENCENUM)

        when:
        List<HscVO> hscVOList = hsc.listMedicalHscByMember(1 as long)

        then:
        hscVOList.size() == 1
        1 * mockDao.list(qp) >> Arrays.asList(new HscVO())
        0 * _
    }

    //private method tests
    def "Test doBindAltAddress"() {
        given:
        MemberAddressVO updateAddressVO = new MemberAddressVO(addressType: "00")
        MemberVO memberVO = new MemberVO()

        when:
        hsc.doBindAltAddress(updateAddressVO, null, memberVO)

        then:
        HsrReferenceConstants.RECORDSOURCETYPE_MANUAL.equals(updateAddressVO.getRecordSourceType())
        updateAddressVO.equals(memberVO.getMemberAddressVO("00"))
        0 * _
    }

    def "Test bindAltPhone"() {
        given:
        MemberTelephoneVO updateTelephoneVO = new MemberTelephoneVO(phone: "555-555-5555", phoneType: "00")
        MemberVO memberVO = new MemberVO(memberID: 1 as long)

        when:
        hsc.bindAltPhone(updateTelephoneVO, memberVO)

        then:
        HsrReferenceConstants.RECORDSOURCETYPE_MANUAL.equals(updateTelephoneVO.getRecordSourceType())
        updateTelephoneVO.equals(memberVO.getMemberTelephoneVO("00"))
        1 * mockMemberTelephone.read(memberVO.getMemberID(), updateTelephoneVO.getPhoneType())
        0 * _
    }

    def "Test cancelCoverageDecisions"() {
        given:
        HscVO hscVO = new HscVO(serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT)

        when:
        hsc.cancelCoverageDecisions(hscVO)

        then:
        1 * mockHscFacilityDecision.cascadeCancelToFacilityLine(hscVO)
        1 * mockHscServiceDecision.cascadeCancelToAllServiceLines(hscVO)
        0 * _
    }

    def "Test changeHscMemberFromTempToPerm"() {
        given:
        List<HscVO> hscVOs = Arrays.asList(new HscVO())

        when:
        hsc.changeHscMemberFromTempToPerm(hscVOs, 1 as long)

        then:
        hscVOs.get(0).getMemberID() == 1 as long
        0 * _
    }

    def "Test validateBusinessClassificationTypeChange"() {
        given:
        HscVO hscVO = new HscVO()

        when:
        hsc.validateBusinessClassificationTypeChange(hscVO, new HscVO(businessClassificationType: "00"))

        then:
        hscVO.getGlobalMessages().contains(HscMessages.ERR_BUS_CLAS_TYPE_CHANGED)
        0 * _
    }

    def "Test validateSpecialProcessTypeChange"() {
        given:
        HscVO hscVO = new HscVO()

        when:
        hsc.validateSpecialProcessTypeChange(hscVO, new HscVO(specialProcessType: "00"))

        then:
        hscVO.getGlobalMessages().contains(HscMessages.ERR_SPCL_PROC_TYPE_CHANGED)
        0 * _
    }

    def "Test validateNotificationOverrideDecision"() {
        given:
        HscVO hscVO = new HscVO()

        when:
        hsc.validateNotificationOverrideDecision(hscVO, new HscVO(notifyRuleOverrideReasonType: "00"))

        then:
        hscVO.getGlobalMessages().contains(HscMessages.ERR_NOTIFICATION_OVERRIDE_CHANGE_NOT_ALLOWED)
        0 * _
    }

    @Unroll
    def "Test deleteProviderRoles where hscVO is #testcase"() {
        when:
        hsc.deleteProviderRoles(new HscVO(hscID: 1 as long, serviceSettingType: serviceSettingType))

        then:
        1 * hscProviderRole.deleteProviderRole(1, HsrReferenceConstants.PROVIDER_ROLE_ADMITTING)
        if(serviceSettingType.equals(CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT)) {
            1 * hscProviderRole.deleteProviderRole(1, HsrReferenceConstants.PROVIDER_ROLE_ATTENDING)
            1 * hscProviderRole.deleteProviderRole(1, HsrReferenceConstants.PROVIDER_ROLE_FACILITY)
        }
        0 * _

        where:
        [testcase, serviceSettingType] << [["outpatient", CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT],
                                           ["outpatient facility", CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY]]
    }

    def "Test isOutpatientRetrospective"() {
        when:
        boolean isOutpatientRetrospective = hsc.isOutpatientRetrospective(Arrays.asList(new HscServiceVO(hscServiceNonFacilityVO: new HscServiceNonFacilityVO(notifyRetrospectiveInd: true))))

        then:
        isOutpatientRetrospective
        0 * _
    }

    def "Test updateServiceOrFacilityLineDataNextGen"() {
        given:
        HscIntakeCompositeVO hscIntakeCompositeVO = new HscIntakeCompositeVO(hscShortFormVO: new HscShortFormVO(hscID: 1 as long, serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT),
                                                                             hscServiceVOs: Arrays.asList(new HscServiceVO(hscID: 1 as long, hscServiceNonFacilityVO: new HscServiceNonFacilityVO())))

        when:
        hsc.updateServiceOrFacilityLineDataNextGen(hscIntakeCompositeVO)

        then:
        hscIntakeCompositeVO.getHscServiceVOs().get(0).getHscServiceNonFacilityVO().isSkipValidation()
        1 * mockHscService.readHscServiceAndNonFacility(hscIntakeCompositeVO.hscShortFormVO.getHscID()) >> hscIntakeCompositeVO.getHscServiceVOs()
        0 * _
    }

    def "Test copyFacilityServiceDataToAllLinesFromShortForm"() {
        given:
        HscServiceVO hscServiceVO = new HscServiceVO(hscServiceFacilityVO: new HscServiceFacilityVO())
        HscIntakeCompositeVO hscIntakeCompositeVO = new HscIntakeCompositeVO(hscServiceVOs: Arrays.asList(hscServiceVO))
        HscFacilityVO hscFacilityVO = new HscFacilityVO(advanceNotifyTransactionID: 1 as long, expectedAdmissionDate: new Date(1, 1, 1), advanceNotifyDateTime: new UhgCalendar())

        when:
        hsc.copyFacilityServiceDataToAllLinesFromShortForm(hscIntakeCompositeVO, hscFacilityVO)

        then:
        hscServiceVO.getHscServiceFacilityVO().isSkipValidation()
        hscFacilityVO.getExpectedAdmissionDate().equals(hscServiceVO.getHscServiceFacilityVO().getExpectedProcedureDate())
        hscFacilityVO.getAdvanceNotifyTransactionID() == hscServiceVO.getHscServiceFacilityVO().getAdvanceNotifyTransactionID()
        hscFacilityVO.getAdvanceNotifyDateTime().equals(hscServiceVO.getHscServiceFacilityVO().getAdvanceNotifyDateTime())
        0 * _
    }

    def "Test setNonFacilityServiceDataOnFirstServiceLineFromShortForm where memberVO.isCspFacetsMember equals false"() {
        given:
        HscServiceVO primaryHscServiceVO = new HscServiceVO(hscID: 1 as long, hscServiceNonFacilityVO: new HscServiceNonFacilityVO())
        HscIntakeCompositeVO hscIntakeCompositeVO = new HscIntakeCompositeVO(hscShortFormVO: new HscShortFormVO(placeOfServiceCode: "00", serviceDetailType: "01",
                                                                                                                serviceDescriptionType: "02", subcategoryType: "0"))

        when:
        hsc.setNonFacilityServiceDataOnFirstServiceLineFromShortForm(primaryHscServiceVO, hscIntakeCompositeVO, null)

        then:
        hscIntakeCompositeVO.getHscShortFormVO().getPlaceOfServiceCode().equals(primaryHscServiceVO.getHscServiceNonFacilityVO().getPlaceOfServiceCode())
        hscIntakeCompositeVO.getHscShortFormVO().getServiceDetailType().equals(primaryHscServiceVO.hscServiceNonFacilityVO.getServiceDetailType())
        hscIntakeCompositeVO.getHscShortFormVO().getServiceDescriptionType().equals(primaryHscServiceVO.hscServiceNonFacilityVO.getServiceDescriptionType())
        !primaryHscServiceVO.getProcCodeType()
        !primaryHscServiceVO.getProcedureCode()
        !primaryHscServiceVO.getProcedureDescription()
        primaryHscServiceVO.getHscServiceNonFacilityVO().isSkipValidation()
        hscIntakeCompositeVO.hscServiceVOs.equals([primaryHscServiceVO] as List)
        0 * _
    }

    def "Test copyNonFacilityServiceDataToAllLinesFromShortForm"() {
        given:
        HscServiceVO hscServiceVO1 = new HscServiceVO(hscID: 1 as long, hscServiceNonFacilityVO: new HscServiceNonFacilityVO(placeOfServiceCode: "00", serviceDetailType: "01",
                                                                                                                             serviceDescriptionType: "02", hscID: 4 as long,
                                                                                                                             serviceStartDate: new Date(1, 1, 1), serviceEndDate: new Date(2050, 1, 1),
                                                                                                                             advanceNotifyTransactionID: 5 as long, advanceNotifyDateTime: new UhgCalendar()))
        HscServiceVO hscServiceVO2 = new HscServiceVO(hscID: 2 as long, serviceSeqNum: 2 as short, procedureCode: "00", procedureDescription: "01", procedureOtherText: "02")
        HscServiceVO hscServiceVO3 = new HscServiceVO(hscID: 3 as long, serviceSeqNum: 3 as short)
        HscIntakeCompositeVO hscIntakeCompositeVO = new HscIntakeCompositeVO(hscServiceVOs: Arrays.asList(hscServiceVO1, hscServiceVO2, hscServiceVO3))

        when:
        hsc.copyNonFacilityServiceDataToAllLinesFromShortForm(hscIntakeCompositeVO)

        then:
        hscIntakeCompositeVO.getHscServiceVOs().equals([hscServiceVO1, hscServiceVO2, hscServiceVO3] as List)
        1 * mockHscService.read(hscServiceVO2.getHscID(), hscServiceVO2.getServiceSeqNum()) >> hscServiceVO2
        1 * mockHscServiceNonFacility.read(hscServiceVO2.getHscID(), hscServiceVO2.getServiceSeqNum()) >> new HscServiceNonFacilityVO()
        1 * mockHscService.read(hscServiceVO3.getHscID(), hscServiceVO3.getServiceSeqNum())
        0 * _
    }

    def "Test isPlaceOfServiceIPRehab"() {
        when:
        boolean isPlaceOfServiceIPRehab = hsc.isPlaceOfServiceIPRehab(new HscFacilityVO(placeOfServiceCode: HsrReferenceConstants.PLACEOFSERVICE_INPATIENT_REHAB,
                                                                                        serviceDescriptionType: HsrReferenceConstants.SERVICEDESCRIPTIONTYPE_SCHEDULED))

        then:
        isPlaceOfServiceIPRehab
        0 * _
    }

    def "Test isPlaceOfServiceSNF"() {
        when:
        boolean isPlaceOfServiceSNF = hsc.isPlaceOfServiceSNF(new HscFacilityVO(placeOfServiceCode: HsrReferenceConstants.PLACEOFSERVICE_NURSING,
                                                                                serviceDescriptionType: HsrReferenceConstants.SERVICEDESCRIPTIONTYPE_SCHEDULED,
                                                                                serviceDetailType: HsrReferenceConstants.SERVICEDETAILTYPE_HOSPICE))

        then:
        isPlaceOfServiceSNF
        0 * _
    }

    def "Test isConcurrentCase"() {
        when:
        boolean isConcurrentCase = hsc.isConcurrentCase(new HscVO(serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT),
                                                        new HscFacilityVO(actualAdmissionDateTime: new UhgCalendar(), placeOfServiceCode: HsrReferenceConstants.PLACEOFSERVICE_ACUTE_HOSPITAL))

        then:
        isConcurrentCase
        0 * _
    }

    def "Test updateBusClssType"() {
        given:
        HscVO hscVO = new HscVO()

        when:
        hsc.updateBusClssType(hscVO)

        then:
        1 * mockPersistenceHelper.updateSubsetWithoutVersion(hscVO, [FieldConstants.BUSINESSCLASSIFICATIONTYPE] as String[], true)
        0 * _
    }
/*
    @Ignore
    def "Test selectMemberCoverageSeqNum"() {
        given:
        HscMemberCoverageVO hscMemberCoverageVO = new HscMemberCoverageVO(memberCoverageSeqNum: 2 as short)
        MemberVO memberVO = new MemberVO(origSystemMemberIDType: "00")
        HscVO hscVO = new HscVO(hscID: 1 as long, hscMemberCoverageVOs: new ArrayList<HscMemberCoverageVO>([hscMemberCoverageVO]),
                                serviceCategoryType: HsrReferenceConstants.SERVICE_CATEGORY_BEHAVIORAL_TRANSITIONAL, memberCoverageSeqNum: hscMemberCoverageVO.getMemberCoverageSeqNum())

        when:
        hsc.selectMemberCoverageSeqNum(memberVO, voCommTxn, hscVO)

        then:
        1 * mockCoverageSystemCheckHelper.selectMemberCoverageForHsr(hscVO.getHscMemberCoverageVOs(), UhgCalendarUtilities.getTodaysDate(),
                                                                     memberVO.getOrigSystemMemberIDType(), hscVO.isBehavioralServiceCategory()) >> hscMemberCoverageVO
        1 * mockPersistenceHelper.updateSubset(hscVO, [FieldConstants.MEMBERCOVERAGESEQNUM] as String[], true)
        0 * _
    }

    @Ignore
    @Unroll
    def "Test selectMemberCoverageSeqNum where #testcase"() {
        given:
        HscMemberCoverageVO hscMemberCoverageVO = new HscMemberCoverageVO(memberCoverageSeqNum: 2 as short)
        MemberVO memberVO = new MemberVO(origSystemMemberIDType: "00")
        HscVO hscVO = new HscVO(hscID: 1 as long, hscMemberCoverageVOs: new ArrayList<HscMemberCoverageVO>([hscMemberCoverageVO]),
                                serviceCategoryType: HsrReferenceConstants.SERVICE_CATEGORY_BEHAVIORAL_TRANSITIONAL, memberCoverageSeqNum: hscMemberCoverageVO.getMemberCoverageSeqNum())

        when:
        hsc.selectMemberCoverageSeqNum(memberVO, voCommTxn, hscVO)

        then:
        thrown(UhgRuntimeException)
        1 * mockCoverageSystemCheckHelper.selectMemberCoverageForHsr(hscVO.getHscMemberCoverageVOs(), UhgCalendarUtilities.getTodaysDate(),
                                                                     memberVO.getOrigSystemMemberIDType(), hscVO.isBehavioralServiceCategory()) >> hscMemberCoverageVO
        1 * mockPersistenceHelper.updateSubset(hscVO, [FieldConstants.MEMBERCOVERAGESEQNUM] as String[], true) >> { throw exception }
        0 * _

        where:
        [testcase, exception] << [["FinderException is thrown", new FinderException()],
                                  ["RecordStaleException is thrown", new RecordStaleException()]]
    }*/

    @Unroll
    def "Test replaySaveTatForCompleteIntake where hscVO is #testcase"() {
        when:
        hsc.replaySaveTatForCompleteIntake(hscVO)

        then:
        hscVO.getGlobalMessages().size() == size
        1 * transactionInterceptor.setRollbackOnly()
        if(hscVO.getHscID() > 0) {
            1 * mockTatPointHelper.logIntakeCompleteTatPoint(hscVO.getHscID())
        }
        0 * _

        where:
        [testcase, hscVO, size] << [["valid", new HscVO(hscID: 1 as long), 2],
                                    ["invalid", new HscVO(), 1]]
    }/*
    @Ignore
    def "Test changeMemberEligibilityForHsc"() {
        given:
        HscVO hscVO = createValidHscVO()
        hscVO.setSecondarySpecialProcessType("01")
        hscVO.setHscStatusType(HsrReferenceConstants.HSCSTATUSTYPE_INCOMPLETE)
        MemberVO memberVO = new MemberVO(memberID: 1 as long, memberCoverageList: new ArrayList<BaseMemberCoverageVO>())

        when:
        hsc.changeMemberEligibilityForHsc(hscVO, memberHeaderVO)

        then:
        1 * mockMember.read(hscVO.getMemberID()) >> memberVO
        1 * mockHscMemberCoverage.deleteCoveragesForHsc(hscVO.getHscID())
        1 * mockHscMemberCoverage.convertMemberCoverageListToHscMemberCoverageList(memberVO.getMemberCoverageList(), 0) >> Arrays.asList(new HscMemberCoverageVO())
        1 * mockHscMemberCoverage.isSpecialProcessTypeRequiresMedicalNecessityInd(hscVO.getSpecialProcessType(), hscVO.getSecondarySpecialProcessType()) >> true
        2 * mockDao.isDuplicate(new QueryProperties(QueryProperties.FilterType.NEW_FILTER, new QueryFilter(FieldConstants.HSCID, hscVO.getHscID()))) >> true
        4 * mockDao.read(getReadProperties(hscVO.getHscID())) >> hscVO
        2 * customerReference.isValidReferenceChildFilter(FieldConstants.HSCSTATUSTYPE, '5', FieldConstants.HSCSTATUSREASONTYPE, '12') >> true
        2 * customerReference.validateReference(hscVO, FieldConstants.SPECIALPROCESSTYPE, hscVO.getSpecialProcessType(), false)
        2 * customerReference.validateReference(hscVO, FieldConstants.SPECIALPROCESSTYPE, hscVO.getSecondarySpecialProcessType(), false)
        2 * mockPersistenceHelper.update(hscVO)
        2 * historyBusinessLogic.addHistoryVO(hscVO)
        1 * mockHscMemberCoverage.getTableDef() >> new TableDef(table: TableConstants.HSC_MBR_COV, valueObjectClass: HscMemberCoverageVO, listFields: [FieldConstants.CRUD_FIELDS],
                                                                fields: [FieldConstants.CRUD_FIELDS], key: [FieldConstants.HSCID])
        1 * mockHscMemberCoverage.list(_ as QueryProperties) >> Arrays.asList(new HscMemberCoverageVO())
        1 * mockHscMemberCoverage.updateCascading(_ as HscMemberCoverageVO)
        1 * mockCoverageSystemCheckHelper.selectMemberCoverageForHsr(_ as List<HscMemberCoverageVO>, UhgCalendarUtilities.getTodaysDate(), memberVO.getOrigSystemMemberIDType(), false)
        0 * _
    }
*/
    @Unroll
    def "Test setReviewPriorityType where #testcase"() {
        given:
        HscVO hscVO = new HscVO(serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT)

        when:
        hsc.setReviewPriorityType(hscVO, hscFacilityVO, hscServiceVOs)

        then:
        reviewPriorityType.equals(hscVO.getReviewPriorityType())
        0 * _

        where:
        [testcase, hscFacilityVO, hscServiceVOs, reviewPriorityType] <<
        [["hscFacilityVO is not null and notifyRetrospectiveInd is true", new HscFacilityVO(notifyRetrospectiveInd: true), null, HsrReferenceConstants.REVIEWPRIORITYTYPE_RETROSPECTIVE],
         ["hscFacilityVO is not null and notifyRetrospectiveInd is false", new HscFacilityVO(notifyRetrospectiveInd: false, placeOfServiceCode: CommonReferenceConstants.PLACEOFSERVICE_ACUTE_HOSPITAL, serviceDetailType: CommonReferenceConstants.SERVICEDETAILTYPE_PSYCHIATRIC), null, HsrReferenceConstants.REVIEWPRIORITYTYPE_POSTSTABILIZATION],
         ["hscFacilityVO is null and outPatientRetrospective is true", null, Arrays.asList(new HscServiceVO(hscServiceNonFacilityVO: new HscServiceNonFacilityVO(notifyRetrospectiveInd: true))), HsrReferenceConstants.REVIEWPRIORITYTYPE_RETROSPECTIVE],
         ["hscFacilityVO is null and outPatientRetrospective is false", null, null, HsrReferenceConstants.REVIEWPRIORITYTYPE_ROUTINEPROSPECTIVE]]
    }

    def "Test completeValidation"() {
        given:
        HscVO hscVO = new HscVO(serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT, specialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_PACIFICARE,
                                vendorTypeID: CssReferenceConstants.VENDOR_TYPE_BEACONLBS)
        List<HscProviderVO> hscProviderVOs = Arrays.asList(new HscProviderVO())
        ValueObject vo = new ValueObject()
        vo.addGlobalMessage(GlobalMessages.ERR_REQUIRED_VALUE)

        when:
        hsc.completeValidation(hscVO)

        then:
        1 * mockHscDiagnosis.readPrimary(hscVO.getHscID())
        1 * mockHscService.validateForCompleteIntake(hscVO.getHscID(), hscVO.getServiceSettingType()) >> vo
        1 * mockHscProvider.listByHscID(hscVO.getHscID(), _) >> hscProviderVOs
        1 * mockHscProvider.setNonPersistedRoles(hscProviderVOs.get(0))
        0 * _
    }

    def "Test serviceSettingChangeDeletes"() {
        given:
        HscVO hscVO = new HscVO(hscID: 1 as long, serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY)

        when:
        hsc.serviceSettingChangeDeletes(hscVO)

        then:
        1 * mockDao.read(getReadProperties(hscVO.getHscID())) >> new HscVO(hscID: 1 as long, serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT)
        1 * mockHscFacility.deleteFacilityForHSC(hscVO.getHscID())
        1 * mockHscService.deleteServicesForHsc(hscVO.getHscID())
        1 * hscProviderRole.deleteProviderRole(hscVO.getHscID(), HsrReferenceConstants.PROVIDER_ROLE_ADMITTING)
        0 * _
    }

    @Unroll
    def "Test validateHscCob where #testcase"() {
        when:
        hsc.validateHscCob(hscVO)

        then:
        hscVO.getMessages().containsKey(message)
        0 * _

        where:
        [testcase, hscVO, message] << [["start date is null and end date isn't", new HscVO(cobInd: true, cobEndDate: UhgCalendarUtilities.getTodaysDate()), FieldConstants.COBSTARTDATE],
                                       ["start date > end date", new HscVO(cobInd: true, cobStartDate: UhgCalendarUtilities.getTodaysDate(), cobEndDate: UhgCalendarUtilities.getYesterdaysDate()), FieldConstants.COBENDDATE]]
    }

    def "Test validateRequiredFields"() {
        given:
        HscVO hscVO = new HscVO(copiedHscID: 1 as long, hscStatusType: "")

        when:
        hsc.validateRequiredFields(hscVO, false)

        then:
        hscVO.getMessages().containsKey(FieldConstants.SERVICESETTINGTYPE)
        hscVO.getMessages().containsKey(FieldConstants.HSCSTATUSTYPE)
        hscVO.getMessages().containsKey(FieldConstants.MEMBERID)
        hscVO.getMessages().containsKey(FieldConstants.HSCCOPYSCENARIO)
        0 * _
    }

    def "Test calculateMedicalReviewType where isPreDeterminationInd is #isPreDeterminationInd and isMedNecessityApplInd is #isMedNecessityApplInd"() {
        when:
        String actualCaseType = hsc.calculateMedicalReviewType(isMedNecessityApplInd, isPreDeterminationInd)

        then:
        expectedCaseType.equals(actualCaseType)
        0 * _

        where:
        [isPreDeterminationInd, isMedNecessityApplInd, expectedCaseType] << [[true, false, HsrReferenceConstants.COREMEDICALREVIEWTYPE_PREDETERMINATION],
                                                                             [false, true, HsrReferenceConstants.COREMEDICALREVIEWTYPE_PRIOR_AUTH]]
    }
    /*

    @Ignore
    def "Test continueCompletionOfHsc"() {
        given:
        HscVO hscVO = createValidHscVO()
        hscVO.setCopiedHscID(1 as long)
        hscVO.setMemberCoverageSeqNum(2 as short)
        hscVO.setSpecialProcessType(HsrReferenceConstants.SPECIALPROCESSTYPE_PACIFICARE)
        HscFacilityVO hscFacilityVO = new HscFacilityVO(serviceReferenceNum: "01")
        HscMemberCoverageVO hscMemberCoverageVO = new HscMemberCoverageVO()
        MemberVO memberVO = new MemberVO(birthDate: UhgCalendarUtilities.getYesterdaysDate())

        when:
        hsc.continueCompletionOfHsc(1 as long, hscVO)

        then:
        3 * mockHscFacility.read(hscVO.getHscID()) >> hscFacilityVO
        1 * mockHscMemberCoverage.read(hscVO.getHscID(), hscVO.getMemberCoverageSeqNum()) >> hscMemberCoverageVO
        2 * mockDao.read(getReadProperties(hscVO.getHscID())) >> hscVO
        1 * customerReference.isValidReferenceChildFilter(FieldConstants.HSCSTATUSTYPE, '1', FieldConstants.HSCSTATUSREASONTYPE, '12') >> true
        1 * customerReference.validateReference(hscVO, FieldConstants.SPECIALPROCESSTYPE, hscVO.getSpecialProcessType(), false)
        1 * customerReference.validateReference(hscVO, FieldConstants.SPECIALPROCESSTYPE, hscVO.getSecondarySpecialProcessType(), false)
        1 * mockPersistenceHelper.update(hscVO)
        1 * historyBusinessLogic.addHistoryVO(hscVO)
        2 * mockMember.read(hscVO.getMemberID()) >> memberVO
        2 * memberCoverage.getCurrentMemberCoverageVO(memberVO) >> hscMemberCoverageVO
        1 * mockDao.list(_ as QueryProperties) >> Arrays.asList(hscVO)
        1 * mockActivity.add(_ as ActivityVO)
        1 * mockAssignment.isOwnershipAssignmentOpenForHsc(hscVO.getHscID()) >> true
        1 * mockTatPointHelper.logIntakeCompleteTatPoint(hscVO.getHscID())
        1 * mockHscDiagnosis.listByHscID(12345678, false, false)
        0 * _
    }

    @Ignore
    def "Test continueCompletionOfHsc where special Process type equals 15"() {
        given:
        HscVO hscVO = createValidHscVO()
        hscVO.setServiceSettingType(CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT)
        hscVO.setVendorTypeID(CssReferenceConstants.VENDOR_TYPE_BEACONLBS)
        hscVO.setBusinessClassificationType(HsrReferenceConstants.BUS_CLS_TYP_ID_E_AND_I)
        hscVO.setCopiedHscID(1 as long)
        hscVO.setMemberCoverageSeqNum(2 as short)
        hscVO.setSpecialProcessType(HsrReferenceConstants.SPECIALPROCESSTYPE_CARECORE_EI)
        HscFacilityVO hscFacilityVO = new HscFacilityVO(serviceReferenceNum: "01")
        HscMemberCoverageVO hscMemberCoverageVO = new HscMemberCoverageVO()
        MemberVO memberVO = new MemberVO(birthDate: UhgCalendarUtilities.getYesterdaysDate())

        when:
        hsc.continueCompletionOfHsc(1 as long, hscVO)

        then:
        hscVO.getGlobalMessages().contains(HscMessages.WRN_CASE_NOT_CLOSED)
        1 * mockHscFacility.read(hscVO.getHscID()) >> hscFacilityVO
        2 * mockHscService.listByHscID(hscVO.getHscID(), false)
        2 * mockHscFacilityDecision.calculateHscFacilityDecisionBaseOnAllServiceDecisions(null)
        1 * mockHscProvider.listByHscWithRoles(hscVO.getHscID())
        1 * mockHscService.readFirstHscServiceVO(12345678) >> new HscServiceVO(serviceReferenceNum: "01")
        1 * mockHscMemberCoverage.read(hscVO.getHscID(), hscVO.getMemberCoverageSeqNum()) >> hscMemberCoverageVO
        2 * mockDao.read(getReadProperties(hscVO.getHscID())) >> hscVO
        1 * customerReference.isValidReferenceChildFilter(FieldConstants.HSCSTATUSTYPE, '1', FieldConstants.HSCSTATUSREASONTYPE, '12') >> true
        1 * customerReference.validateReference(hscVO, FieldConstants.SPECIALPROCESSTYPE, hscVO.getSpecialProcessType(), false)
        1 * customerReference.validateReference(hscVO, FieldConstants.SPECIALPROCESSTYPE, hscVO.getSecondarySpecialProcessType(), false)
        1 * mockPersistenceHelper.update(hscVO)
        1 * historyBusinessLogic.addHistoryVO(hscVO)
        2 * mockMember.read(hscVO.getMemberID()) >> memberVO
        2 * memberCoverage.getCurrentMemberCoverageVO(memberVO) >> hscMemberCoverageVO
        1 * mockDao.list(_ as QueryProperties) >> Arrays.asList(hscVO)
        1 * mockActivity.add(_ as ActivityVO)
        1 * mockAssignment.isOwnershipAssignmentOpenForHsc(hscVO.getHscID()) >> true
        1 * mockTatPointHelper.logIntakeCompleteTatPoint(hscVO.getHscID())
        1 * mockHscDiagnosis.listByHscID(12345678, false, false)
        0 * _
    }
*/
    @Unroll
    def "Test readByPrimaryServiceRefNum for a valid search parameter: #searchParameter"() {
        when: "User submits a request for a given search parameter"
        hsc.readByPrimaryServiceRefNum(searchParameter)
        then: "Verify that the DAO got an upper case version of the search parameter"
        notThrown(UhgRuntimeException)
        1 * mockDao.read(_ as ReadProperties) >> { ReadProperties rp ->
            assert rp.getKeyValue(FieldConstants.PRIMARYSERVICEREFERENCENUM) == searchParameter.toUpperCase()
        }
        0 * _
        where:
        searchParameter << ["A0000015", "a0000015"]
    }
/*
    @Ignore
    def "create AZ CRS apply with AZCRS in a coverage"(){
        given:
        HscVO hscVO = createValidHscVO()
        hscVO.hscStatusType = HsrReferenceConstants.HSCSTATUSTYPE_OPEN
        MemberVO memberVO = new MemberVO(memberID: hscVO.memberID)
        BaseMemberCoverageVO baseMemberCoverageVO = new BaseMemberCoverageVO(policyNumber: "AZCRS1", productCategoryType: HsrReferenceConstants.PRODUCTCATEGORYTYPE_MEDICAID,
                                                                             policyIssueState: "AZ")
        MemberCoverageVO memberCoverageVO = new MemberCoverageVO(policyNumber: "AZCRS", productCategoryType: HsrReferenceConstants.PRODUCTCATEGORYTYPE_MEDICAID,
                                                                 policyIssueState: "AZ")
        List<MemberCoverageVO> memberCoverageVOs = new ArrayList<>([memberCoverageVO])
        HscDiagnosisVO diagnosisVO = new HscDiagnosisVO(diagnosisCode: "test", )
        List<HscDiagnosisVO> diagnosisVOs = new ArrayList<>([diagnosisVO])

        when:
        hsc.createAZCRSApply(hscVO)

        then:
        1 * mockMember.read(hscVO.memberID) >> memberVO
        1 * memberCoverage.getCurrentMemberCoverageVO(memberVO) >> baseMemberCoverageVO
        1 * mockHscDiagnosis.listByHscID(hscVO.hscID, false, false) >> diagnosisVOs
        1 * memberCoverage.getActiveCoverageListByMemberID(memberVO.memberID) >> memberCoverageVOs
        0 * _
    }
*/
    def "create AZ CRS apply with AZCRS not n a coverage"(){
        given:
        HscVO hscVO = createValidHscVO()
        hscVO.hscStatusType = HsrReferenceConstants.HSCSTATUSTYPE_OPEN
        MemberVO memberVO = new MemberVO(memberID: hscVO.memberID, birthDate: UhgCalendarUtilities.todaysDate)
        BaseMemberCoverageVO baseMemberCoverageVO = new BaseMemberCoverageVO(policyNumber: "AZCRS1", productCategoryType: HsrReferenceConstants.PRODUCTCATEGORYTYPE_MEDICAID,
                                                                             policyIssueState: "AZ")
        MemberCoverageVO memberCoverageVO = new MemberCoverageVO(policyNumber: "test", productCategoryType: HsrReferenceConstants.PRODUCTCATEGORYTYPE_MEDICAID,
                                                                 policyIssueState: "AZ")
        List<MemberCoverageVO> memberCoverageVOs = new ArrayList<>([memberCoverageVO])
        HscDiagnosisVO diagnosisVO = new HscDiagnosisVO(diagnosisCode: "test", )
        List<HscDiagnosisVO> diagnosisVOs = new ArrayList<>([diagnosisVO])

        when:
        hsc.createAZCRSApply(hscVO)

        then:
        1 * mockMember.read(hscVO.memberID) >> memberVO
        0 * _
    }

    private ReadProperties getReadProperties(long hscID, String... readFields) {
        ReadProperties rp = new ReadProperties(hsc.getTableDef().getKey())
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        rp.setFields(readFields)
        rp
    }

    private static HscVO createValidHscVO() {
        new HscVO(hscID: 12345678, memberID: 12345, changeUserID: "AK3", serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT,
                  specialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_LEGACY,
                  hscStatusReasonType: HsrReferenceConstants.HSCSTATUSREASONTYPE_OPEN,
                  hscStatusType: HsrReferenceConstants.HSCSTATUSTYPE_OPEN,
                  serviceCategoryType: HsrReferenceConstants.SERVICE_CATEGORY_MEDICAL)
    }

    def "Test addSkeletalHsc"() {
        given:
        MemberVO memberVO = new MemberVO(memberCoverageList: [ new MemberCoverageVO() ])

        when:
        hsc.addSkeletalHsc(1L, "O", memberVO)

        then:
        1 * mockHscMemberCoverage.convertMemberCoverageListToHscMemberCoverageList(_ as List, _)
        1 * mockPersistenceHelper.add(_ as HscVO)
        1 * historyBusinessLogic.addHistoryVO(_ as HscVO)
        0 * _
    }

    def "Test addSkeletalHscForBehavioral"() {
        given:
        MemberVO memberVO = new MemberVO(memberCoverageList: [ new MemberCoverageVO() ])

        when:
        hsc.addSkeletalHscForBehavioral(1L, "O", memberVO, 2L)

        then:
        1 * mockHscMemberCoverage.convertMemberCoverageListToHscMemberCoverageList(_ as List, _) >> [ new HscMemberCoverageVO() ]
        1 * mockPersistenceHelper.add(_ as HscVO)
        2 * historyBusinessLogic.addHistoryVO(_ as HscVO)
        1 * mockHscFacility.getTableDef() >> new TableDef<HscFacilityVO>(valueObjectClass: HscFacilityVO)
        1 * mockHscMemberCoverage.getTableDef() >> new TableDef<HscMemberCoverageVO>(valueObjectClass: HscMemberCoverageVO)
        1 * mockHscMemberCoverage.addCascading(_ as HscMemberCoverageVO)
        1 * mockHscFacility.addCascading(_ as HscFacilityVO)
        1 * mockDao.read(_ as ReadProperties)
        1 * mockPersistenceHelper.update(_ as HscVO)
        0 * _
    }

    def "Test changeAwaitingAdmissionToOpenStatus"() {
        given:

        when:
        hsc.changeAwaitingAdmissionToOpenStatus(123456L, UhgCalendarUtilities.getLocalCalendar())

        then:
        1 * mockDao.read(_ as ReadProperties) >> new HscVO(hscID: 123456L,
                                                           memberID: 123456789,
                                                           serviceSettingType: HsrReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT,
                                                           hscStatusType: HsrReferenceConstants.HSCSTATUSTYPE_AWAITING_ADMISSION)
        1 * mockDao.isDuplicate(_ as QueryProperties)
        2 * customerReference.validateReference(_ as HscVO, FieldConstants.SPECIALPROCESSTYPE, null, false)
        1 * mockPersistenceHelper.add(_ as HscVO)
        1 * historyBusinessLogic.addHistoryVO(_ as HscVO)
        0 * _
    }

    def "Test discardHsc"() {
        given:

        when:
        hsc.discardHsc(123456L)

        then:
        1 * mockDao.read(_ as ReadProperties) >> new HscVO(hscID: 123456L,
                                                           memberID: 123456789,
                                                           serviceSettingType: HsrReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT,
                                                           hscStatusType: HsrReferenceConstants.HSCSTATUSTYPE_AWAITING_ADMISSION)
        1 * mockDao.isDuplicate(_ as QueryProperties)
        2 * customerReference.validateReference(_ as HscVO, FieldConstants.SPECIALPROCESSTYPE, null, false)
        1 * mockPersistenceHelper.add(_ as HscVO)
        1 * historyBusinessLogic.addHistoryVO(_ as HscVO)
        0 * _
    }

    def "Test logHscDecisionActivity"() {
        given:
        HscVO hscVO = createValidHscVO()

        when:
        hsc.logHscDecisionActivity(ActivityReferenceConstants.ACTIVITYTYPE_CALL_CONTACT, hscVO, 123L, "1")

        then:
        1 * mockActivity.add(_ as ActivityVO)
        0 * _
    }

    def "Test readCascadingSpclCare filling HscVO with HscCgpHistoryVO"() {
        given:
        short serviceSeqNum = 1
        long hscID = 123456L
        hsc = new HscImpl(activity: mockActivity,
                dao: mockDao, hscDiagnosis: mockHscDiagnosis,
                hscFacility: mockHscFacility, hscSpecialtyProcedure: mockHscSpecialtyProcedure, hscFacilityDecision: mockHscFacilityDecision, hscFollowUpContact: mockHscFollowupContact,
                hscMemberCoverage: mockHscMemberCoverage, hscProvider: mockHscProvider, hscService: mockHscService, hscServiceDecision: mockHscServiceDecision,
                hscServiceNonFacility: mockHscServiceNonFacility, member: mockMember,
                memberAddress: mockMemberAddress, memberProgram: mockMemberProgram,
                memberTelephone: mockMemberTelephone, note: mockNote, customerReference: customerReference,
                tatPointHelper: mockTatPointHelper,
                codeXRef: mockCodeXRef,
                hscAlternateIdentifier: mockHscAlternateIdentifier,
                memberCoverage: memberCoverage,
                hscProviderHelper: hscProviderHelper, hscProviderRole: hscProviderRole,
                hscAlert: hscAlert, sendMail: sendMail, systemSettingsEmailGroup: systemSettingsEmailGroup,
                serviceLocator: serviceLocator, hscAttribute: hscAttribute, hscAssessment: hscAssessment, hscMeasurement: hscMeasurement,
                hscAdditionalPlanFeature: hscAdditionalPlanFeature,
                urJurisdiction: urJurisdiction,
                tatPoint: tatPoint,
                federatedConfigService: federatedConfigService, coverageSystemCheckHelper: mockCoverageSystemCheckHelper, hscCgpHistory: hscCgpHistory )
        hsc.setRequiredPersistenceHelper(mockPersistenceHelper)
        hsc.setRequiredTransactionInterceptor(transactionInterceptor)
        hsc.setRequiredHistoryBusinessLogic(historyBusinessLogic)

        when:
        hsc.readCascadingSpclCare(hscID)

        then:
        1 * mockDao.read(_ as ReadProperties) >> new HscVO(hscID: hscID,
                memberID: 123456789,
                serviceSettingType: HsrReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT,
                hscStatusType: HsrReferenceConstants.HSCSTATUSTYPE_AWAITING_ADMISSION)
        2 * mockHscFollowupContact.listByHscID(hscID, null)
        1 * mockHscMemberCoverage.listByHscID(hscID)
        1 * mockHscDiagnosis.listByHscID(hscID, false, false)
        1 * mockHscProvider.listByHscWithRoles(hscID)
        1 * hscProviderRole.listByHscID(hscID)
        1 * mockHscSpecialtyProcedure.read(hscID)
        1 * mockHscService.listServiceAndFacility(hscID, true) >> [ new HscServiceVO(hscID: hscID, serviceSeqNum: serviceSeqNum) ]
        1 * mockHscServiceDecision.getCurrentDecision(hscID, serviceSeqNum, false)
        1 * hscAttribute.listByHscID(hscID)
        1 * hscAssessment.listByHscID(hscID)
        1 * hscMeasurement.listByHscID(hscID)
        1 * hscAdditionalPlanFeature.listByHscID(hscID) >> []
        1 * tatPoint.listByHsc(hscID, serviceSeqNum) >> []
        1 * hscCgpHistory.read(hscID) >> new HscCgpHistoryVO()
        1 * urJurisdiction.listByService(hscID, serviceSeqNum) >> []
        0 * _
    }

    def "Test readCascadingSpclCare with null HscCgpHistory HscVO will not have HscCgpHistoryVO"() {
        given:
        short serviceSeqNum = 1
        long hscID = 123456L
        hsc = new HscImpl(activity: mockActivity,
                dao: mockDao, hscDiagnosis: mockHscDiagnosis,
                hscFacility: mockHscFacility, hscSpecialtyProcedure: mockHscSpecialtyProcedure, hscFacilityDecision: mockHscFacilityDecision, hscFollowUpContact: mockHscFollowupContact,
                hscMemberCoverage: mockHscMemberCoverage, hscProvider: mockHscProvider, hscService: mockHscService, hscServiceDecision: mockHscServiceDecision,
                hscServiceNonFacility: mockHscServiceNonFacility, member: mockMember,
                memberAddress: mockMemberAddress, memberProgram: mockMemberProgram,
                memberTelephone: mockMemberTelephone, note: mockNote, customerReference: customerReference,
                tatPointHelper: mockTatPointHelper,
                codeXRef: mockCodeXRef,
                hscAlternateIdentifier: mockHscAlternateIdentifier,
                memberCoverage: memberCoverage,
                hscProviderHelper: hscProviderHelper, hscProviderRole: hscProviderRole,
                hscAlert: hscAlert, sendMail: sendMail, systemSettingsEmailGroup: systemSettingsEmailGroup,
                serviceLocator: serviceLocator, hscAttribute: hscAttribute, hscAssessment: hscAssessment, hscMeasurement: hscMeasurement,
                hscAdditionalPlanFeature: hscAdditionalPlanFeature,
                urJurisdiction: urJurisdiction,
                tatPoint: tatPoint,
                federatedConfigService: federatedConfigService, coverageSystemCheckHelper: mockCoverageSystemCheckHelper, hscCgpHistory: null )
        hsc.setRequiredPersistenceHelper(mockPersistenceHelper)
        hsc.setRequiredTransactionInterceptor(transactionInterceptor)
        hsc.setRequiredHistoryBusinessLogic(historyBusinessLogic)

        when:
        hsc.readCascadingSpclCare(hscID)

        then:
        1 * mockDao.read(_ as ReadProperties) >> new HscVO(hscID: hscID,
                memberID: 123456789,
                serviceSettingType: HsrReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT,
                hscStatusType: HsrReferenceConstants.HSCSTATUSTYPE_AWAITING_ADMISSION)
        2 * mockHscFollowupContact.listByHscID(hscID, null)
        1 * mockHscMemberCoverage.listByHscID(hscID)
        1 * mockHscDiagnosis.listByHscID(hscID, false, false)
        1 * mockHscProvider.listByHscWithRoles(hscID)
        1 * hscProviderRole.listByHscID(hscID)
        1 * mockHscSpecialtyProcedure.read(hscID)
        1 * mockHscService.listServiceAndFacility(hscID, true) >> [ new HscServiceVO(hscID: hscID, serviceSeqNum: serviceSeqNum) ]
        1 * mockHscServiceDecision.getCurrentDecision(hscID, serviceSeqNum, false)
        1 * hscAttribute.listByHscID(hscID)
        1 * hscAssessment.listByHscID(hscID)
        1 * hscMeasurement.listByHscID(hscID)
        1 * hscAdditionalPlanFeature.listByHscID(hscID) >> []
        1 * tatPoint.listByHsc(hscID, serviceSeqNum) >> []
        0 * hscCgpHistory.read(hscID)
        1 * urJurisdiction.listByService(hscID, serviceSeqNum) >> []
        0 * _
    }

    def "Test readCascadingSpclCare"() {
        given:
        short serviceSeqNum = 1
        long hscID = 123456L

        when:
        hsc.readCascadingSpclCare(hscID)

        then:
        1 * mockDao.read(_ as ReadProperties) >> new HscVO(hscID: hscID,
                                                           memberID: 123456789,
                                                           serviceSettingType: HsrReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT,
                                                           hscStatusType: HsrReferenceConstants.HSCSTATUSTYPE_AWAITING_ADMISSION)
        2 * mockHscFollowupContact.listByHscID(hscID, null)
        1 * mockHscMemberCoverage.listByHscID(hscID)
        1 * mockHscDiagnosis.listByHscID(hscID, false, false)
        1 * mockHscProvider.listByHscWithRoles(hscID)
        1 * hscProviderRole.listByHscID(hscID)
        1 * mockHscSpecialtyProcedure.read(hscID)
        1 * mockHscService.listServiceAndFacility(hscID, true) >> [ new HscServiceVO(hscID: hscID, serviceSeqNum: serviceSeqNum) ]
        1 * mockHscServiceDecision.getCurrentDecision(hscID, serviceSeqNum, false)
        1 * hscAttribute.listByHscID(hscID)
        1 * hscAssessment.listByHscID(hscID)
        1 * hscMeasurement.listByHscID(hscID)
        1 * hscAdditionalPlanFeature.listByHscID(hscID) >> []
        1 * tatPoint.listByHsc(hscID, serviceSeqNum) >> []
        1 * urJurisdiction.listByService(hscID, serviceSeqNum) >> []
        0 * _
    }

    def "Test readHscAndRefreshCoverages"() {
        given:
        MemberVO memberVO = new MemberVO(memberCoverageList: [ new MemberCoverageVO() ])
        ErrorVO errorVO = new ErrorVO()

        when:
        hsc.readHscAndRefreshCoverages(123456789L, memberVO, errorVO, false)

        then:
        1 * mockDao.list(_ as QueryProperties) >> [ createValidHscVO() ]
        1 * mockHscMemberCoverage.getMedicalMemberCoverages(_ as MemberVO)
        0 * _
    }

    @Unroll
    def "Testing savePreferredPathway call for Outpatient Chemotherapy Auth"(){
        given:
        long hscID = 5555L
        HscVO hscVO = new HscVO(hscID: hscID, authTypeID: SpclCareReferenceConstants.AUTH_TYPE_INJECTABLE_CHEMOTHERAPY)
        MemberCoverageVO memberCoverageVO = new MemberCoverageVO(memberCoverageSeqNum: 1 as short, coverageType: 'M', productCategoryType: '2', lineOfBusinessType:'11', coverageEndDate: new UhgCalendar().addYear(1).getSQLDate(), coverageEffectiveDate: new UhgCalendar().addYear(-1).getSQLDate())
        MemberVO memberVO = new MemberVO(memberCoverageVOs: [memberCoverageVO])

        when:
        hsc.savePreferredPathway(hscVO, memberVO, UhgCalendarUtilities.getTodaysDate(), userType)

        then:
        1 * federatedConfigService.getPreferredPathwayByClientAndProduct(_, _) >> preferredPathway
        1 * mockCoverageSystemCheckHelper.selectMemberCoverageForHsr(_, _) >> memberCoverageVO
        1 * hscAttribute.save(_)

        where:
        testCase |                             userType | preferredPathway
        0        |      SpclCareConstants.ROLE_PROVIDER | new PreferredPathway(enabled: true, userRole: SpclCareConstants.ROLE_PROVIDER, supportedPopulationForPreferredPathway: new SupportedPopulationForPreferredPathway(lineOfBusinessType: '_*', productCategoryType: '_*'))
        1        |      SpclCareConstants.ROLE_PROVIDER | new PreferredPathway(enabled: true, userRole: SpclCareConstants.ROLE_ADMINISTRATOR, supportedPopulationForPreferredPathway: new SupportedPopulationForPreferredPathway(lineOfBusinessType: '_*', productCategoryType: '_*'))
        2        |      SpclCareConstants.ROLE_PROVIDER | new PreferredPathway(enabled: true, userRole: SpclCareConstants.ROLE_PROVIDER, supportedPopulationForPreferredPathway: new SupportedPopulationForPreferredPathway(lineOfBusinessType: '11', productCategoryType: '_*'))
        3        |      SpclCareConstants.ROLE_PROVIDER | new PreferredPathway(enabled: true, userRole: SpclCareConstants.ROLE_ADMINISTRATOR, supportedPopulationForPreferredPathway: new SupportedPopulationForPreferredPathway(lineOfBusinessType: '_*', productCategoryType: '2'))
        4        | SpclCareConstants.ROLE_ADMINISTRATOR | new PreferredPathway(enabled: true, userRole: SpclCareConstants.ROLE_PROVIDER, supportedPopulationForPreferredPathway: new SupportedPopulationForPreferredPathway(lineOfBusinessType: '_*', productCategoryType: '_*'))
        5        | SpclCareConstants.ROLE_ADMINISTRATOR | new PreferredPathway(enabled: true, userRole: SpclCareConstants.ROLE_ADMINISTRATOR, supportedPopulationForPreferredPathway: new SupportedPopulationForPreferredPathway(lineOfBusinessType: '_*', productCategoryType: '_*'))
        6        | SpclCareConstants.ROLE_ADMINISTRATOR | new PreferredPathway(enabled: true, userRole: SpclCareConstants.ROLE_PROVIDER, supportedPopulationForPreferredPathway: new SupportedPopulationForPreferredPathway(lineOfBusinessType: '11', productCategoryType: '_*'))
        7        | SpclCareConstants.ROLE_ADMINISTRATOR | new PreferredPathway(enabled: true, userRole: SpclCareConstants.ROLE_ADMINISTRATOR, supportedPopulationForPreferredPathway: new SupportedPopulationForPreferredPathway(lineOfBusinessType: '_*', productCategoryType: '2'))
        8        | SpclCareConstants.ROLE_ADMINISTRATOR | new PreferredPathway(enabled: false)
    }
}
