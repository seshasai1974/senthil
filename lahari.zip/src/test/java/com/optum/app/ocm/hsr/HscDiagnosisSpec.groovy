package com.optum.app.ocm.hsr

import com.optum.rf.common.reference.businesslogic.Icd10
import com.optum.rf.common.reference.businesslogic.util.DiagnosisCode
import com.optum.rf.common.reference.data.Icd10VO
import com.optum.rf.common.settings.businesslogic.SystemSettingsFramework
import com.optum.rf.dao.data.ValueObject
import com.optum.rf.dao.exception.UhgRuntimeException
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.QueryFilter
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.optum.app.common.constants.CommonReferenceConstants
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.Hsc
import com.optum.app.common.hsr.businesslogic.impl.HscDiagnosisImpl
import com.optum.app.common.hsr.data.HscDiagnosisVO
import com.optum.app.common.hsr.data.HscIntakeCompositeVO
import com.optum.app.common.hsr.data.HscIntakeVO
import com.optum.app.common.hsr.data.HscVO
import spock.lang.Unroll

/**
 * Contains tests for com.optum.app.icue.hsr.hsc.businesslogic.impl.HscDiagnosisImpl.
 */
class HscDiagnosisSpec extends HsrReadLogicSpecification {
    private HscDiagnosisImpl hscDiagnosis
    private DataAccessObject<HscDiagnosisVO> mockDao
    private PersistenceHelper mockPersistenceHelper
    private Hsc mockHsc
    private SystemSettingsFramework mockSystemSettingsFramework
    private Icd10 icd10

    def setup() {
        hscDiagnosis = new HscDiagnosisImpl()
        mockDao = Mock(DataAccessObject)
        mockPersistenceHelper = Mock(PersistenceHelper)
        mockHsc = Mock(Hsc)
        mockSystemSettingsFramework = Mock(SystemSettingsFramework)
        icd10 = Mock(Icd10)

        hscDiagnosis.requiredHsc = mockHsc
        hscDiagnosis.setRequiredDao(mockDao)
        hscDiagnosis.requiredPersistenceHelper = mockPersistenceHelper
        hscDiagnosis.icd10 = icd10
    }

    @Unroll
    def "isValid #testCase"() {
        given:
        def hscID = (long) 1
        def diagnosisSequenceNumber = (short) 2
        def rp = new ReadProperties(FieldConstants.HSCID, FieldConstants.DIAGNOSISSEQNUM)
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        rp.setKeyValue(FieldConstants.DIAGNOSISSEQNUM, diagnosisSequenceNumber)
        rp.fields = null

        when:
        boolean retVal = hscDiagnosis.isValid(hscID, diagnosisSequenceNumber)

        then:
        1 * mockDao.isValid(rp) >> expectedVal
        0 * _
        retVal == expectedVal

        where:
        testCase | expectedVal
        "passes" | true
        "fails"  | false
    }

    def "Expected error message returned when more than one primary diagnosis added"() {
        setup:
        def addVO = new HscDiagnosisVO(primaryInd: true)
        def diagnosisType = addVO.getDiagnosisType()
        // Initiate a list with only a primary vo added that the readPrimary method will return when mocked
        def voList = [new HscDiagnosisVO(primaryInd: true)]

        when:
        hscDiagnosis.add(addVO)

        then: "mock only what needs to be mocked"
        1 * mockDao.list(_) >> voList          // This mocks the readPrimary method

        and: "an exception should be thrown and message added to field in vo"
        thrown(UhgRuntimeException)
    }

    def "Expected message returned when an existing diagnosis is updated to an admitting type and another already exists"() {
        setup:
        def updateVO = new HscDiagnosisVO(admitInd: true, diagnosisCode: "567.8")
        // Add an admitting VO to a list that will be returned in the mocked isDuplicate method
        def voList = [new HscDiagnosisVO(admitInd: true, diagnosisCode: "123.4")]
        def lastSavedVO = new HscDiagnosisVO(primaryInd: true, inactiveInd: false)

        when:
        hscDiagnosis.update(updateVO)

        then: "mock only what needs to be mocked"
        1 * mockDao.read(_) >> lastSavedVO     // This mocks a read to get the last saved version of the VO record

        and: "an exception should occur and message added to vo"
        thrown(UhgRuntimeException)
    }

    def "The addDiagnosisList method will set the diagnosis scheme type on any VO if null"() {
        // This test targets the setDiagnosisSchemeTypeOnList method that is called from addDiagnosisList
        setup:
        def voSchemeNotRequired = new HscDiagnosisVO(diagnosisOtherText: "other text", diagnosisCode: null, diagnosisCodeSchemeTypeID: null)
        def voSchemeHasScheme = new HscDiagnosisVO(diagnosisOtherText: null, diagnosisCode: "123", diagnosisCodeSchemeTypeID: CommonReferenceConstants.DIAGNOSIS_CODE_SCHEME_TYPE_ID_ICD10)
        def voSchemeRequired = new HscDiagnosisVO(diagnosisOtherText: null, diagnosisCode: "456", diagnosisCodeSchemeTypeID: null)
        def voList = [voSchemeNotRequired, voSchemeHasScheme, voSchemeRequired]

        when:
        hscDiagnosis.addDiagnosisList(voList)

        then: "mock what is needed in flow of test"
        interaction { // interaction needed when mocking is defined in another local method
            (1.._) * mockPersistenceHelper.add(_)  // Mocks persistenceHelper.add method that is called for each vo in list
        }

        and:
        // Check that VO with null scheme type now has the expected value
        CommonReferenceConstants.DIAGNOSIS_CODE_SCHEME_TYPE_ID_ICD10.equals(voSchemeRequired.getDiagnosisCodeSchemeTypeID())
    }

    @Unroll()
    def "DiagnosisOtherText is required when diagnosis code is generic code #diagnosisCode and scheme type is #schemeType for update method"() {
        setup:
        def updateVO = new HscDiagnosisVO(diagnosisCode: diagnosisCode, diagnosisOtherText: null, diagnosisCodeSchemeTypeID: schemeType)
        def lastSavedVO = new HscDiagnosisVO(primaryInd: true, inactiveInd: false)

        when:
        hscDiagnosis.update(updateVO)

        then: "mock only what is needed for this test path"
        1 * mockDao.read(_) >> lastSavedVO     // This mocks a read to get the last saved version of the VO record

        and: "an exception should be thrown and message added to field in vo"
        thrown(UhgRuntimeException)

        where:
        diagnosisCode << [DiagnosisCode.DIAGNOSISCODE_780_99, DiagnosisCode.DIAGNOSISCODE_R68_8]
        schemeType << [CommonReferenceConstants.DIAGNOSIS_CODE_SCHEME_TYPE_ID_ICD10, CommonReferenceConstants.DIAGNOSIS_CODE_SCHEME_TYPE_ID_ICD10]
    }

    def "Duplicate primary and secondary diagnosis not allowed"() {
        // This targets the checkListForDuplicates method called from addDiagnosisList for duplicate primary and secondary diagnosis
        setup:
        def primaryVO = new HscDiagnosisVO(primaryInd: true, diagnosisCode: "123", diagnosisCodeSchemeTypeID: CommonReferenceConstants.DIAGNOSIS_CODE_SCHEME_TYPE_ID_ICD10)
        def secondaryVO = new HscDiagnosisVO(primaryInd: false, admitInd: false, diagnosisCode: "123", diagnosisCodeSchemeTypeID: CommonReferenceConstants.DIAGNOSIS_CODE_SCHEME_TYPE_ID_ICD10)
        def nonDupVO = new HscDiagnosisVO(primaryInd: false, admitInd: false, diagnosisCode: "456", diagnosisCodeSchemeTypeID: CommonReferenceConstants.DIAGNOSIS_CODE_SCHEME_TYPE_ID_ICD10)
        def voList = [primaryVO, nonDupVO, secondaryVO]

        when:
        hscDiagnosis.addDiagnosisList(voList)

        then: "an exception should be thrown and message added to the primary vo"
        thrown(UhgRuntimeException)
    }

    def "Duplicate admitting and secondary diagnosis not allowed"() {
        // This targets the checkListForDuplicates method called from addDiagnosisList for duplicate admitting and secondary diagnosis
        setup:
        def admittingVO = new HscDiagnosisVO(admitInd: true, diagnosisCode: "123", diagnosisCodeSchemeTypeID: CommonReferenceConstants.DIAGNOSIS_CODE_SCHEME_TYPE_ID_ICD10)
        def secondaryVO = new HscDiagnosisVO(primaryInd: false, admitInd: false, diagnosisCode: "123", diagnosisCodeSchemeTypeID: CommonReferenceConstants.DIAGNOSIS_CODE_SCHEME_TYPE_ID_ICD10)
        def nonDupVO = new HscDiagnosisVO(primaryInd: false, admitInd: false, diagnosisCode: "456", diagnosisCodeSchemeTypeID: CommonReferenceConstants.DIAGNOSIS_CODE_SCHEME_TYPE_ID_ICD10)
        def voList = [admittingVO, nonDupVO, secondaryVO]

        when:
        hscDiagnosis.addDiagnosisList(voList)

        then: "an exception should be thrown and message added to the admitting vo"
        thrown(UhgRuntimeException)
    }

    def "Duplicate secondary diagnosis not allowed"() {
        // This targets the checkListForDuplicates method called from addDiagnosisList for two duplicate secondary diagnosis codes
        setup:
        def secondaryVO1 = new HscDiagnosisVO(primaryInd: false, admitInd: false, diagnosisCode: "123", diagnosisCodeSchemeTypeID: CommonReferenceConstants.DIAGNOSIS_CODE_SCHEME_TYPE_ID_ICD10)
        def secondaryVO2 = new HscDiagnosisVO(primaryInd: false, admitInd: false, diagnosisCode: "123", diagnosisCodeSchemeTypeID: CommonReferenceConstants.DIAGNOSIS_CODE_SCHEME_TYPE_ID_ICD10)
        def nonDupVO = new HscDiagnosisVO(primaryInd: false, admitInd: false, diagnosisCode: "456", diagnosisCodeSchemeTypeID: CommonReferenceConstants.DIAGNOSIS_CODE_SCHEME_TYPE_ID_ICD10)
        def voList = [secondaryVO1, nonDupVO, secondaryVO2]

        when:
        hscDiagnosis.addDiagnosisList(voList)

        then: "an exception should be thrown and message added to first secondary vo"
        thrown(UhgRuntimeException)
    }

    @Unroll()
    def "Duplicate general symptom codes not allowed for primary and secondary diagnosis where diagnosisCode=#diagnosisCode and scheme type=#schemeType"() {
        // This targets the checkListForDuplicates method called from addDiagnosisList for general symptom codes 780.99 and R68.8
        setup:
        def primaryVO = new HscDiagnosisVO(primaryInd: true, diagnosisCode: diagnosisCode, diagnosisOtherText: "same text", diagnosisCodeSchemeTypeID: schemeType)
        def secondaryVO = new HscDiagnosisVO(primaryInd: false, admitInd: false, diagnosisCode: diagnosisCode, diagnosisOtherText: "same text", diagnosisCodeSchemeTypeID: schemeType)
        def voList = [primaryVO, secondaryVO]

        when:
        hscDiagnosis.addDiagnosisList(voList)

        then: "an exception should be thrown and message added to primary vo"
        thrown(UhgRuntimeException)

        where:
        diagnosisCode << [DiagnosisCode.DIAGNOSISCODE_780_99, DiagnosisCode.DIAGNOSISCODE_R68_8]
        schemeType << [CommonReferenceConstants.DIAGNOSIS_CODE_SCHEME_TYPE_ID_ICD10, CommonReferenceConstants.DIAGNOSIS_CODE_SCHEME_TYPE_ID_ICD10]
    }

    def "Test duplicate check logic for diagnosis code"() {
        // This targets the isDuplicateDiagnosis method called from addDiagnosisList for diagnoses with same diagnosis code
        setup:
        def firstDupVO = new HscDiagnosisVO(primaryInd: false, admitInd: false, diagnosisCode: "123", diagnosisCodeSchemeTypeID: CommonReferenceConstants.DIAGNOSIS_CODE_SCHEME_TYPE_ID_ICD10)
        def secondDupVO = new HscDiagnosisVO(primaryInd: false, admitInd: false, diagnosisCode: "123", diagnosisCodeSchemeTypeID: CommonReferenceConstants.DIAGNOSIS_CODE_SCHEME_TYPE_ID_ICD10)
        def nonDupVO = new HscDiagnosisVO(primaryInd: false, admitInd: false, diagnosisCode: "456", diagnosisCodeSchemeTypeID: CommonReferenceConstants.DIAGNOSIS_CODE_SCHEME_TYPE_ID_ICD10)
        def voList = [firstDupVO, nonDupVO, secondDupVO]

        when:
        hscDiagnosis.addDiagnosisList(voList)

        then: "an exception should be thrown and message added to either first vo"
        thrown(UhgRuntimeException)
    }

    def "Test duplicate check logic for diagnosis other text"() {
        // This targets the isDuplicateDiagnosis method called from addDiagnosisList for diagnoses with same "other text"
        setup:
        def firstDupVO = new HscDiagnosisVO(primaryInd: false, admitInd: false, diagnosisCode: null, diagnosisOtherText: "same text", diagnosisCodeSchemeTypeID: CommonReferenceConstants.DIAGNOSIS_CODE_SCHEME_TYPE_ID_ICD10)
        def secondDupVO = new HscDiagnosisVO(primaryInd: false, admitInd: false, diagnosisCode: null, diagnosisOtherText: "same text", diagnosisCodeSchemeTypeID: CommonReferenceConstants.DIAGNOSIS_CODE_SCHEME_TYPE_ID_ICD10)
        def nonDupVO = new HscDiagnosisVO(primaryInd: false, admitInd: false, diagnosisCode: null, diagnosisOtherText: "other text", diagnosisCodeSchemeTypeID: CommonReferenceConstants.DIAGNOSIS_CODE_SCHEME_TYPE_ID_ICD10)
        def voList = [firstDupVO, nonDupVO, secondDupVO]

        when:
        hscDiagnosis.addDiagnosisList(voList)

        then: "an exception should be thrown and message added to either first vo"
        thrown(UhgRuntimeException)
    }

    def "Expected message when both Primary or Other text entered are null on add"() {
        setup:
        def addVO = new HscDiagnosisVO(diagnosisCode: null, diagnosisOtherText: null)

        when:
        hscDiagnosis.add(addVO)

        then: "an exception should occur and message added to vo"
        thrown(UhgRuntimeException)
    }

    def "Expected message when both Primary or Other text entered are null on update"() {
        setup:
        def updateVO = new HscDiagnosisVO(diagnosisCode: null, diagnosisOtherText: null)
        def lastSavedVO = new HscDiagnosisVO(primaryInd: true, inactiveInd: false)

        when:
        hscDiagnosis.update(updateVO)

        then:
        1 * mockDao.read(_) >> lastSavedVO     // This mocks a read to get the last saved version of the VO record

        and: "an exception should occur and message added to vo"
        thrown(UhgRuntimeException)
    }

    @Unroll()
    def "ICD10 diagnosis code original value #origDiagCode formatted to #expectedDiagCode"() {
        when:
        def formattedCode = hscDiagnosis.formatToIcd10Code(origDiagCode)

        then:
        assert (expectedDiagCode.equals(formattedCode))

        where:
        origDiagCode | expectedDiagCode
        "A00"        | "A00"
        "A0B"        | "A0B"
        "AB0"        | "AB0"
        "A001"       | "A00.1"
        "A01B"       | "A01.B"
        "A0010"      | "A00.10"
        "A001B"      | "A00.1B"
        "A00110"     | "A00.110"
        "A0011B"     | "A00.11B"
        "A001110"    | "A00.1110"
        "A00111B"    | "A00.111B"
    }

    def "Expected message when a logically deleted diagnosis is updated."() {
        // This test targets some logic in validateUpdateCompareToSaved
        setup:
        def updateVO = new HscDiagnosisVO(diagnosisCode: "123.4")  // set diagnosisCode to prevent additional unintended validation errors/messages
        def lastSavedVO = new HscDiagnosisVO(inactiveInd: true)

        when:
        hscDiagnosis.update(updateVO)

        then: "mock only what is needed for this test path"
        1 * mockDao.read(_) >> lastSavedVO     // This mocks a read to get the last saved version of the VO record

        and: "an exception should be thrown and message added to field in vo"
        thrown(UhgRuntimeException)
    }

    def "A primary diagnosis cannot be changed to a non-primary diagnosis when updating a diagnosis VO."() {
        // This test targets some logic in validateUpdateCompareToSaved
        setup:
        def updateVO = new HscDiagnosisVO(primaryInd: false, diagnosisCode: "123.4")  // set diagnosisCode to prevent additional unintended validation errors/messages
        def lastSavedVO = new HscDiagnosisVO(primaryInd: true)

        when:
        hscDiagnosis.update(updateVO)

        then: "mock only what is needed for this test path"
        1 * mockDao.read(_) >> lastSavedVO     // This mocks a read to get the last saved version of the VO record

        and: "an exception should be thrown and message added to field in vo"
        thrown(UhgRuntimeException)
    }

    def "Test validateUpdateCompareToSaved method to ensure that a primary diagnosis cannot be changed to a non-primary diagnosis."() {
        setup:
        def updateVO = new HscDiagnosisVO(primaryInd: false)
        def lastSavedVO = new HscDiagnosisVO(primaryInd: true)

        when:
        hscDiagnosis.validateUpdateCompareToSaved(updateVO, lastSavedVO, true)

        then: "an error message added to field in vo"
    }

    def "Test listSecondary"() {
        setup:
        def hscID = (long) 1
        def qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        qp.addQueryFilter(new QueryFilter(com.optum.app.common.constants.spclcare.FieldConstants.HSCID, hscID))
        qp.addQueryFilter(new QueryFilter(com.optum.app.common.constants.spclcare.FieldConstants.PRIMARYIND, false))
        qp.addQueryFilter(new QueryFilter(com.optum.app.common.constants.spclcare.FieldConstants.ADMITIND, false))
        qp.addQueryFilter(new QueryFilter(com.optum.app.common.constants.spclcare.FieldConstants.INACTIVEIND, false))

        when:
        hscDiagnosis.listSecondary(hscID)

        then:
        1 * mockDao.list(qp)
    }

    def "Test listByHscIDWithCodeDescription"() {
        setup:
        def hscID = (long) 1

        when:
        hscDiagnosis.listByHscIDWithCodeDescription(hscID, false, false)

        then:
        1 * mockDao.list(_) >> [new HscDiagnosisVO(hscID: hscID, diagnosisCode: "1", diagnosisCodeSchemeTypeID: CommonReferenceConstants.DIAGNOSIS_CODE_SCHEME_TYPE_ID_ICD10)]
    }

    def "Test validatePrimaryDxRequired"() {
        setup:
        List<HscDiagnosisVO> hscDiagnosisVOList = [ new HscDiagnosisVO(primaryInd: isPrimary) ]

        when:
        ValueObject errorVO = hscDiagnosis.validatePrimaryDxRequired(hscDiagnosisVOList)

        then:
        0 * _._

        if(!isPrimary) {
            assert errorVO.errorMessagesExist()
        }

        where: isPrimary << [ true, false ]
    }

}