package com.optum.app.ocm.hsr

import com.optum.app.common.hsr.businesslogic.HscFacilityDecision
import com.optum.app.common.hsr.businesslogic.HscFacilityDecisionBedDay
import com.optum.app.common.hsr.businesslogic.HscMiscHelper
import com.optum.app.common.hsr.businesslogic.HscServiceDecision
import com.optum.app.common.hsr.businesslogic.impl.HscMiscHelperImpl
import com.optum.app.common.hsr.constants.HsrReferenceConstants
import com.optum.app.common.hsr.data.AbstractHscDecisionVO
import com.optum.app.common.hsr.data.HscVO
import spock.lang.Unroll

class HscMiscHelperSpec extends HsrReadLogicSpecification {

    HscMiscHelper hscMiscHelper

    HscFacilityDecision hscFacilityDecision
    HscFacilityDecisionBedDay hscFacilityDecisionBedDay
    HscServiceDecision hscServiceDecision

    def setup() {
        hscFacilityDecision = Mock(HscFacilityDecision)
        hscFacilityDecisionBedDay = Mock(HscFacilityDecisionBedDay)
        hscServiceDecision = Mock(HscServiceDecision)

        hscMiscHelper = new HscMiscHelperImpl(
                hscFacilityDecision: hscFacilityDecision,
                hscFacilityDecisionBedDay: hscFacilityDecisionBedDay,
                hscServiceDecision: hscServiceDecision
        )
    }

    @Unroll
    def "isCaseUnderAppeal #hscStatusType #hscStatusReasonType"() {
        given:
        HscVO hscVO = new HscVO(hscStatusType: hscStatusType, hscStatusReasonType: hscStatusReasonType, serviceSettingType: serviceSettingType)

        when:
        boolean retVal = hscMiscHelper.isCaseUnderAppeal(hscVO)

        then:
        0 * _
        retVal == expectedVal

        where:
        expectedVal | hscStatusType                                 | hscStatusReasonType                                            | serviceSettingType
        true        | HsrReferenceConstants.HSCSTATUSTYPE_OPEN      | HsrReferenceConstants.HSCSTATUSREASONTYPE_RECONSIDER           | HsrReferenceConstants.SERVICESETTINGTYPE_INPATIENT
        true        | HsrReferenceConstants.HSCSTATUSTYPE_OPEN      | HsrReferenceConstants.HSCSTATUSREASONTYPE_PRESERVICE_APPEAL    | HsrReferenceConstants.SERVICESETTINGTYPE_INPATIENT
        true        | HsrReferenceConstants.HSCSTATUSTYPE_OPEN      | HsrReferenceConstants.HSCSTATUSREASONTYPE_POSTSERVICE_APPEAL   | HsrReferenceConstants.SERVICESETTINGTYPE_INPATIENT
        false       | ""                                            | ""                                                             | HsrReferenceConstants.SERVICESETTINGTYPE_INPATIENT
    }

    @Unroll
    def "isCaseUnderCaseLevelAppeal #decisionSubType #hscStatusReasonType"() {
        given:
        HscVO hscVO = new HscVO(hscStatusType: hscStatusType, hscStatusReasonType: hscStatusReasonType)

        when:
        boolean retVal = hscMiscHelper.isCaseUnderCaseLevelAppeal(hscVO)

        then:
        0 * _
        retVal == expectedVal

        where:
        expectedVal | hscStatusType                                 | hscStatusReasonType
        true        | HsrReferenceConstants.HSCSTATUSTYPE_OPEN      | HsrReferenceConstants.HSCSTATUSREASONTYPE_RECONSIDER
        true        | HsrReferenceConstants.HSCSTATUSTYPE_OPEN      | HsrReferenceConstants.HSCSTATUSREASONTYPE_PRESERVICE_APPEAL
        true        | HsrReferenceConstants.HSCSTATUSTYPE_OPEN      | HsrReferenceConstants.HSCSTATUSREASONTYPE_POSTSERVICE_APPEAL
        false       | HsrReferenceConstants.HSCSTATUSTYPE_CLOSED    | HsrReferenceConstants.HSCSTATUSREASONTYPE_POSTSERVICE_APPEAL
        false       | HsrReferenceConstants.HSCSTATUSTYPE_CANCELLED | HsrReferenceConstants.HSCSTATUSREASONTYPE_POSTSERVICE_APPEAL
        false       | HsrReferenceConstants.HSCSTATUSTYPE_OPEN      | HsrReferenceConstants.HSCSTATUSREASONTYPE_PENDING_AUTO_CLOSURE
        false       | ""                                            | ""
    }

    @Unroll
    def "isServiceUnderAppeal #decisionSubType"() {
        given:
        AbstractHscDecisionVO abstractHscDecisionVO = new AbstractHscDecisionVO() {
            @Override
            List getDecisionSources() {
                throw new UnsupportedOperationException("Not yet implemented")
            }
        }
        abstractHscDecisionVO.decisionSubType = decisionSubType

        when:
        boolean retVal = hscMiscHelper.isServiceUnderAppeal(abstractHscDecisionVO)

        then:
        0 * _
        retVal == expectedVal

        where:
        expectedVal | decisionSubType
        true        | HsrReferenceConstants.DECISIONSUBTYPE_1STAPPEAL
        true        | HsrReferenceConstants.DECISIONSUBTYPE_2NDAPPEAL
        true        | HsrReferenceConstants.DECISIONSUBTYPE_3RDAPPEAL
        true        | HsrReferenceConstants.DECISIONSUBTYPE_STATELEVELAPPEAL
        true        | HsrReferenceConstants.DECISIONSUBTYPE_EXTERNALAPPEAL
        true        | HsrReferenceConstants.DECISIONSUBTYPE_3RDPARTYAPPEAL
        false       | HsrReferenceConstants.DECISIONREASONTYPE_SKILLEDORLICENSED
        false       | ""
    }
}
