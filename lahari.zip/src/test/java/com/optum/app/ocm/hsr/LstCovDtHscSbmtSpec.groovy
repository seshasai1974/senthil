package com.optum.app.ocm.hsr

import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.util.UhgCalendarUtilities
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.optum.rf.test.core.spock.ReadLogicSpecification
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.impl.LstCovDtHscSbmtImpl
import com.optum.app.common.hsr.data.LastCoveredDateSubmitterVO
import com.optum.app.common.hsr.messages.HmsMessages

class LstCovDtHscSbmtSpec extends HsrReadLogicSpecification {
    LstCovDtHscSbmtImpl lastCovdDateHSCSbmt
    DataAccessObject dao
    private PersistenceHelper persistenceHelper

    def setup() {
        dao = Mock(DataAccessObject)
        persistenceHelper = Mock(PersistenceHelper)
        lastCovdDateHSCSbmt = new LstCovDtHscSbmtImpl()
        lastCovdDateHSCSbmt.requiredDao = dao
        lastCovdDateHSCSbmt.requiredDao = dao
        lastCovdDateHSCSbmt.setRequiredPersistenceHelper(persistenceHelper)
    }

    def "test isValid"() {
        when:
        def isValid = lastCovdDateHSCSbmt.isValid("11")

        then: "expect"
        dao.isValid(_ as ReadProperties) >> true

        and: "verify results"
        isValid
    }

    def "test read"() {
        when:
        def readVo = lastCovdDateHSCSbmt.read("11")

        then: "expect"
        dao.read(_ as ReadProperties) >> new LastCoveredDateSubmitterVO()

        and: "verify results"
        readVo
    }

    def "test read property creation"() {
        when:
        def rp = lastCovdDateHSCSbmt.getReadProperties("1")

        then:
        rp
        rp.keys
        rp.keys.size() == 1
        rp.keyMap
        rp.keyMap.size() == 1
        rp.keyMap['submitterId']
        rp.keyMap['submitterId'] == "1"
    }

    def "test Validate Method with different parameters"() {
        setup:
        when:
        lastCovdDateHSCSbmt.validate(lstCoveredDateSubmitterVO, update, override)
        then:
        def errMsgList = lstCoveredDateSubmitterVO.getMessage(variableField)
        errMsgList?.size() == 1
        def errMsg = errMsgList[0]
        errMsg.message.equals(errMessage)

        where:
        update | override | lstCoveredDateSubmitterVO                                                                                                                               | variableField          | errMessage
        false  | false    | new LastCoveredDateSubmitterVO(submitterId: '007', startDate: UhgCalendarUtilities.getTodaysDate(), endDate: UhgCalendarUtilities.getTodaysDate() - 10) | FieldConstants.ENDDATE | HmsMessages.ERR_INVALID_END_DATE
    }
}
