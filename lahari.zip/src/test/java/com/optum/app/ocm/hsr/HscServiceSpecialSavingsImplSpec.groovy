package com.optum.app.ocm.hsr

import com.optum.rf.core.util.UhgCalendar
import com.optum.rf.dao.exception.UhgRuntimeException
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.QueryCriteria
import com.optum.rf.dao.sql.query.QueryFilter
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.optum.app.common.constants.CommonReferenceConstants
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.Hsc
import com.optum.app.common.hsr.businesslogic.HscServiceNonFacility
import com.optum.app.common.hsr.businesslogic.impl.HscServiceSpecialSavingsImpl
import com.optum.app.common.hsr.constants.HsrReferenceConstants
import com.optum.app.common.hsr.data.HscProviderVO
import com.optum.app.common.hsr.data.HscServiceNonFacilityVO
import com.optum.app.common.hsr.data.HscServiceSpecialSavingsVO
import com.optum.app.common.hsr.data.HscVO
import com.optum.app.common.hsr.messages.HscMessages
import spock.lang.Unroll

class HscServiceSpecialSavingsImplSpec extends HsrReadLogicSpecification {

    HscServiceSpecialSavingsImpl hscServiceSpecialSavings
    DataAccessObject dao
    PersistenceHelper persistenceHelper
    HscServiceNonFacility hscServiceNonFacility
    Hsc hsc

    def setup() {
        hscServiceSpecialSavings = new HscServiceSpecialSavingsImpl()
        dao = Mock(DataAccessObject)
        persistenceHelper = Mock(PersistenceHelper)
        hscServiceNonFacility = Mock(HscServiceNonFacility)
        hsc = Mock(Hsc)
        hscServiceSpecialSavings.setRequiredDao(dao)
        hscServiceSpecialSavings.setRequiredPersistenceHelper(persistenceHelper)
        hscServiceSpecialSavings.setRequiredHscServiceNonFacility(hscServiceNonFacility)
        hscServiceSpecialSavings.setRequiredHsc(hsc)
    }

    def "is valid"() {
        given:
        long hscID = 91
        short serviceSeqNum = 3
        int yearNumber = 16
        String monthTypeID = "01"

        when:
        hscServiceSpecialSavings.isValid(hscID, serviceSeqNum, yearNumber, monthTypeID)

        then:
        1 * dao.isValid(_ as ReadProperties) >> { ReadProperties rp ->
            assert rp.getKeyValue(FieldConstants.HSCID) == hscID
            assert rp.getKeyValue(FieldConstants.SERVICESEQNUM) == serviceSeqNum
            assert rp.getKeyValue(FieldConstants.YEARNUMBER) == yearNumber
            assert rp.getKeyValue(FieldConstants.MONTHTYPEID) == monthTypeID
            return true
        }
        0 * _
    }

    def "read"() {
        given:
        long hscID = 1
        short serviceSeqNum = 2
        int yearNumber = 16
        String monthTypeID = "02"
        HscServiceSpecialSavingsVO resultVO = new HscServiceSpecialSavingsVO(
                hscID: hscID, serviceSeqNum: serviceSeqNum, yearNumber: yearNumber, monthTypeID: monthTypeID)
        def dayVisits = resultVO.getNumberOfDaysVisits()

        when:
        HscServiceSpecialSavingsVO readVO = hscServiceSpecialSavings.read(hscID, serviceSeqNum, yearNumber, monthTypeID)

        then:
        1 * dao.read(_ as ReadProperties) >> { ReadProperties rp ->
            assert rp.getKeyValue(FieldConstants.HSCID) == hscID
            assert rp.getKeyValue(FieldConstants.SERVICESEQNUM) == serviceSeqNum
            assert rp.getKeyValue(FieldConstants.YEARNUMBER) == yearNumber
            assert rp.getKeyValue(FieldConstants.MONTHTYPEID) == monthTypeID
            return resultVO
        }
        0 * _
        readVO == resultVO
    }

    def "read properties"() {
        given:
        long hscID = 2
        short serviceSeqNum = 3
        int yearNumber = 16
        String monthTypeID = "03"

        when:
        ReadProperties rp = hscServiceSpecialSavings.getReadProperties(hscID, serviceSeqNum, yearNumber, monthTypeID)

        then:
        0 * _
        rp.getKeyValue(FieldConstants.HSCID) == hscID
        rp.getKeyValue(FieldConstants.SERVICESEQNUM) == serviceSeqNum
        rp.getKeyValue(FieldConstants.YEARNUMBER) == yearNumber
        rp.getKeyValue(FieldConstants.MONTHTYPEID) == monthTypeID
    }

    @Unroll
    def "validate special savings service dates - case #caseNo"() {
        given:
        HscServiceSpecialSavingsVO hscServiceSpecialSavingsVO = new HscServiceSpecialSavingsVO(
                hscID: 1, yearNumber: savingsYear, monthTypeID: savingsMonth
        )
        HscServiceNonFacilityVO hscServiceNonFacilityVO = new HscServiceNonFacilityVO(
                hscID: 1, serviceStartDate: serviceStartDate, serviceEndDate: serviceEndDate
        )

        when:
        hscServiceSpecialSavings.validateSpecialSavingsServiceDates(hscServiceSpecialSavingsVO, hscServiceNonFacilityVO)

        then:
        0 * _
        hscServiceSpecialSavingsVO.getMessages().size() == msgSize
        hscServiceSpecialSavingsVO.errorMessagesExist() == errorMsg
        hscServiceSpecialSavingsVO.getMessage(FieldConstants.MONTHTYPEID)?.get(0)?.message?.messageID == monthErrorId
        hscServiceSpecialSavingsVO.getMessage(FieldConstants.YEARNUMBER)?.get(0)?.message?.messageID == yearErrorId

        where:

        caseNo              | savingsYear | savingsMonth | msgSize | errorMsg | serviceStartDate                           | serviceEndDate                             | monthErrorId | yearErrorId
        "1:invalid month"   | 2016        | "01"         | 1       | true     | new UhgCalendar(2016, 02, 25).getSQLDate() | new UhgCalendar(2016, 03, 25).getSQLDate() | "ERR5421"    | null
        "2:invalid year"    | 2015        | "02"         | 1       | true     | new UhgCalendar(2017, 01, 03).getSQLDate() | new UhgCalendar(2017, 12, 25).getSQLDate() | null         | "ERR5420"
        "3:valid date "     | 2016        | "04"         | 0       | false    | new UhgCalendar(2015, 12, 25).getSQLDate() | new UhgCalendar(2018, 04, 15).getSQLDate() | null         | null
        "4:invalid mo & yr" | 2017        | "05"         | 1       | true     | new UhgCalendar(2018, 06, 25).getSQLDate() | new UhgCalendar(2018, 12, 15).getSQLDate() | null         | "ERR5420"
    }

    @Unroll
    def "validate savings is applicable: check MedicalNecessitySpecialProcessType/specialProcessType - case #id"() {
        given:
        HscVO hscVO = new HscVO(hscID: id, hscStatusType: hscStatusType, specialProcessType: specialProcessType)
        HscServiceNonFacilityVO hscServiceNonFacilityVO = new HscServiceNonFacilityVO(hscID: id, placeOfServiceCode: CommonReferenceConstants.PLACEOFSERVICE_HOME, serviceDetailType: CommonReferenceConstants.SERVICEDETAILTYPE_MEDICAL)
        HscServiceSpecialSavingsVO hscServiceSpecialSavingsVO = new HscServiceSpecialSavingsVO(hscID: id)

        when:
        hscServiceSpecialSavings.validateSavingsIsApplicable(hscVO, hscServiceNonFacilityVO, hscServiceSpecialSavingsVO)

        then: "will only incur ERR_SAVINGS_INVALID_SPECIAL_PROCESS_TYPE if specialProcessType is not SPECIALPROCESSTYPE_CARE_PROGRAMS."
        0 * _
        hscServiceSpecialSavingsVO.errorMessagesExist() == errorMsgExists
        hscServiceSpecialSavingsVO.getGlobalMessages().size() == messageSize
        hscServiceSpecialSavingsVO.getGlobalMessages().contains(HscMessages.ERR_SAVINGS_INVALID_SPECIAL_PROCESS_TYPE) == errorMsgExists

        where: "hscStatusType should only be either OPEN or AWAITING_ADMISSION to avoid ERR_SAVINGS_HSC_INVALID_CASE_STATUS"

        id | hscStatusType                                          | specialProcessType                                           | messageSize | errorMsgExists
        1  | HsrReferenceConstants.HSCSTATUSTYPE_OPEN               | HsrReferenceConstants.SPECIALPROCESSTYPE_LEGACY              | 1           | true
        2  | HsrReferenceConstants.HSCSTATUSTYPE_AWAITING_ADMISSION | HsrReferenceConstants.SPECIALPROCESSTYPE_CARE_PROGRAMS       | 0           | false
        3  | HsrReferenceConstants.HSCSTATUSTYPE_OPEN               | HsrReferenceConstants.SPECIALPROCESSTYPE_NAVIGATE            | 1           | true
        4  | HsrReferenceConstants.HSCSTATUSTYPE_AWAITING_ADMISSION | HsrReferenceConstants.SPECIALPROCESSTYPE_NAVIGATE_BALANCED   | 1           | true
        5  | HsrReferenceConstants.HSCSTATUSTYPE_OPEN               | HsrReferenceConstants.SPECIALPROCESSTYPE_NAVIGATE_PLUS       | 1           | true
        6  | HsrReferenceConstants.HSCSTATUSTYPE_AWAITING_ADMISSION | HsrReferenceConstants.SPECIALPROCESSTYPE_GATED               | 1           | true
        7  | HsrReferenceConstants.HSCSTATUSTYPE_OPEN               | HsrReferenceConstants.SPECIALPROCESSTYPE_MAHP                | 1           | true
        8  | HsrReferenceConstants.HSCSTATUSTYPE_AWAITING_ADMISSION | HsrReferenceConstants.SPECIALPROCESSTYPE_COSMOS              | 1           | true
        9  | HsrReferenceConstants.HSCSTATUSTYPE_OPEN               | HsrReferenceConstants.SPECIALPROCESSTYPE_COMMERCIAL          | 1           | true
        10 | HsrReferenceConstants.HSCSTATUSTYPE_AWAITING_ADMISSION | HsrReferenceConstants.SPECIALPROCESSTYPE_CARECORE            | 1           | true
        11 | HsrReferenceConstants.HSCSTATUSTYPE_OPEN               | HsrReferenceConstants.SPECIALPROCESSTYPE_PACIFICARE          | 1           | true
        12 | HsrReferenceConstants.HSCSTATUSTYPE_AWAITING_ADMISSION | HsrReferenceConstants.SPECIALPROCESSTYPE_CMC_FACETS          | 1           | true
        13 | HsrReferenceConstants.HSCSTATUSTYPE_OPEN               | HsrReferenceConstants.SPECIALPROCESSTYPE_CARECORE_EI         | 1           | true
        14 | HsrReferenceConstants.HSCSTATUSTYPE_AWAITING_ADMISSION | HsrReferenceConstants.SPECIALPROCESSTYPE_CARECORE_CSP_FACETS | 1           | true
    }

    @Unroll
    def "validate savings is applicable: error when hscStatusType is not OPEN or AWAITING_ADMISSION - case #id"() {
        given:
        HscVO hscVO = new HscVO(hscID: id, hscStatusType: hscStatusType, specialProcessType: specialProcessType)
        HscServiceNonFacilityVO hscServiceNonFacilityVO = new HscServiceNonFacilityVO(hscID: id, placeOfServiceCode: CommonReferenceConstants.PLACEOFSERVICE_HOME, serviceDetailType: CommonReferenceConstants.SERVICEDETAILTYPE_SURGICAL)
        HscServiceSpecialSavingsVO hscServiceSpecialSavingsVO = new HscServiceSpecialSavingsVO(hscID: id)

        when:
        hscServiceSpecialSavings.validateSavingsIsApplicable(hscVO, hscServiceNonFacilityVO, hscServiceSpecialSavingsVO)

        then:
        0 * _
        hscServiceSpecialSavingsVO.getGlobalMessages().size() == messageSize
        hscServiceSpecialSavingsVO.errorMessagesExist() == errorMsgExists
        hscServiceSpecialSavingsVO.getGlobalMessages().contains(HscMessages.ERR_SAVINGS_HSC_INVALID_CASE_STATUS) == errorMsgExists

        where: "specialProcessType can only be SPECIALPROCESSTYPE_CARE_PROGRAMS to avoid ERR_SAVINGS_INVALID_SPECIAL_PROCESS_TYPE."
        id | hscStatusType                                          | specialProcessType                                     | messageSize | errorMsgExists
        1  | HsrReferenceConstants.HSCSTATUSTYPE_OPEN               | HsrReferenceConstants.SPECIALPROCESSTYPE_CARE_PROGRAMS | 0           | false
        2  | HsrReferenceConstants.HSCSTATUSTYPE_AWAITING_ADMISSION | HsrReferenceConstants.SPECIALPROCESSTYPE_CARE_PROGRAMS | 0           | false
        3  | HsrReferenceConstants.HSCSTATUSTYPE_CLOSED             | HsrReferenceConstants.SPECIALPROCESSTYPE_CARE_PROGRAMS | 1           | true
        4  | HsrReferenceConstants.HSCSTATUSTYPE_CANCELLED          | HsrReferenceConstants.SPECIALPROCESSTYPE_CARE_PROGRAMS | 1           | true
        5  | HsrReferenceConstants.HSCSTATUSTYPE_INCOMPLETE         | HsrReferenceConstants.SPECIALPROCESSTYPE_CARE_PROGRAMS | 1           | true
        6  | HsrReferenceConstants.HSCSTATUSTYPE_DISCARDED          | HsrReferenceConstants.SPECIALPROCESSTYPE_CARE_PROGRAMS | 1           | true
        7  | HsrReferenceConstants.HSCSTATUSTYPE_NTF_NOT_REQUIRED   | HsrReferenceConstants.SPECIALPROCESSTYPE_CARE_PROGRAMS | 1           | true
        8  | HsrReferenceConstants.HSCSTATUSTYPE_PENDING_CLOSE      | HsrReferenceConstants.SPECIALPROCESSTYPE_CARE_PROGRAMS | 1           | true
    }

    @Unroll
    def "validate savings is applicable: check if invalid non-facility savings - case #id"() {
        given:
        HscVO hscVO = new HscVO(hscID: id, hscStatusType: HsrReferenceConstants.HSCSTATUSTYPE_OPEN, specialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_CARE_PROGRAMS)
        HscServiceNonFacilityVO hscServiceNonFacilityVO = new HscServiceNonFacilityVO(hscID: id,
                placeOfServiceCode: CommonReferenceConstants.PLACEOFSERVICE_HOME, serviceDetailType: serviceDetailType, dmeProcurementType: dmeProcurementType)
        HscServiceSpecialSavingsVO hscServiceSpecialSavingsVO = new HscServiceSpecialSavingsVO(hscID: id)

        when:
        hscServiceSpecialSavings.validateSavingsIsApplicable(hscVO, hscServiceNonFacilityVO, hscServiceSpecialSavingsVO)

        then: "ERROR WHEN ServiceDetailType == SERVICEDETAILTYPE_DME && DmeProcurementType is not blank"
        0 * _
        hscServiceSpecialSavingsVO.getGlobalMessages().size() == messageSize
        hscServiceSpecialSavingsVO.errorMessagesExist() == errorMsgExists
        hscServiceSpecialSavingsVO.getGlobalMessages().contains(HscMessages.ERR_SAVINGS_HSC_BAD_SAVING_CONFIGURATION) == errorMsgExists

        where:
        id | serviceDetailType                                              | dmeProcurementType | messageSize | errorMsgExists
        1  | CommonReferenceConstants.SERVICEDETAILTYPE_MEDICAL             | "1"                | 0           | false
        2  | CommonReferenceConstants.SERVICEDETAILTYPE_SURGICAL            | "2"                | 0           | false
        3  | CommonReferenceConstants.SERVICEDETAILTYPE_MATERNITY           | "1"                | 0           | false
        4  | CommonReferenceConstants.SERVICEDETAILTYPE_TRANSPLANT          | "2"                | 0           | false
        5  | CommonReferenceConstants.SERVICEDETAILTYPE_COSMETIC            | "1"                | 0           | false
        6  | CommonReferenceConstants.SERVICEDETAILTYPE_PSYCHIATRIC         | "2"                | 0           | false
        7  | HsrReferenceConstants.SERVICEDETAILTYPE_MENTALHEALTH           | "1"                | 0           | false
        8  | CommonReferenceConstants.SERVICEDETAILTYPE_CHIROPRACTIC        | "2"                | 0           | false
        9  | CommonReferenceConstants.SERVICEDETAILTYPE_DENTAL              | "1"                | 0           | false
        10 | CommonReferenceConstants.SERVICEDETAILTYPE_DIAGNOSTIIC         | "2"                | 0           | false
        11 | CommonReferenceConstants.SERVICEDETAILTYPE_DME                 | "1"                | 0           | false
        12 | CommonReferenceConstants.SERVICEDETAILTYPE_HOSPICE             | "2"                | 0           | false
        13 | CommonReferenceConstants.SERVICEDETAILTYPE_IMAGING             | "1"                | 0           | false
        14 | CommonReferenceConstants.SERVICEDETAILTYPE_INFERTILITY         | "2"                | 0           | false
        15 | CommonReferenceConstants.SERVICEDETAILTYPE_INFUSION            | "1"                | 0           | false
        16 | CommonReferenceConstants.SERVICEDETAILTYPE_LAB                 | "2"                | 0           | false
        17 | CommonReferenceConstants.SERVICEDETAILTYPE_LTC                 | "1"                | 0           | false
        18 | CommonReferenceConstants.SERVICEDETAILTYPE_MEDICATIONS         | "2"                | 0           | false
        19 | CommonReferenceConstants.SERVICEDETAILTYPE_NICU                | "1"                | 0           | false
        20 | CommonReferenceConstants.SERVICEDETAILTYPE_OT                  | "2"                | 0           | false
        21 | CommonReferenceConstants.SERVICEDETAILTYPE_ORTHOTICS           | "1"                | 0           | false
        22 | CommonReferenceConstants.SERVICEDETAILTYPE_PAIN                | "2"                | 0           | false
        23 | CommonReferenceConstants.SERVICEDETAILTYPE_PHARMACY            | "1"                | 0           | false
        24 | CommonReferenceConstants.SERVICEDETAILTYPE_PT                  | "2"                | 0           | false
        25 | CommonReferenceConstants.SERVICEDETAILTYPE_PRIVATEDUTYNURSING  | "1"                | 0           | false
        26 | CommonReferenceConstants.SERVICEDETAILTYPE_PROSTHETICS         | "2"                | 0           | false
        27 | CommonReferenceConstants.SERVICEDETAILTYPE_RESPIRATORY         | "1"                | 0           | false
        28 | CommonReferenceConstants.SERVICEDETAILTYPE_SKILLEDNURSING      | "2"                | 0           | false
        29 | CommonReferenceConstants.SERVICEDETAILTYPE_SPEECH              | "1"                | 0           | false
        30 | CommonReferenceConstants.SERVICEDETAILTYPE_SUBSTANCEABUSE      | "2"                | 0           | false
        31 | CommonReferenceConstants.SERVICEDETAILTYPE_SUPPLIES            | "1"                | 0           | false
        32 | CommonReferenceConstants.SERVICEDETAILTYPE_THERAPYSVCS         | "2"                | 0           | false
        33 | CommonReferenceConstants.SERVICEDETAILTYPE_TRANSPORT           | "1"                | 0           | false
        34 | CommonReferenceConstants.SERVICEDETAILTYPE_TRANSPLANT_SERVICES | "2"                | 0           | false
        35 | CommonReferenceConstants.SERVICEDETAILTYPE_VISION              | "1"                | 0           | false
        36 | CommonReferenceConstants.SERVICEDETAILTYPE_WELL_BABY           | "2"                | 0           | false
        37 | CommonReferenceConstants.SERVICEDETAILTYPE_HOME_SERVICES       | "1"                | 0           | false
        38 | CommonReferenceConstants.SERVICEDETAILTYPE_LTAC                | "2"                | 0           | false
        39 | CommonReferenceConstants.SERVICEDETAILTYPE_DIALYSIS            | "1"                | 0           | false
        40 | CommonReferenceConstants.SERVICEDETAILTYPE_PAT_SKILLED_NURSING | "2"                | 0           | false
        41 | CommonReferenceConstants.SERVICEDETAILTYPE_MEDICAL             | null               | 0           | false
        42 | CommonReferenceConstants.SERVICEDETAILTYPE_SURGICAL            | ""                 | 0           | false
        43 | CommonReferenceConstants.SERVICEDETAILTYPE_MATERNITY           | null               | 0           | false
        44 | CommonReferenceConstants.SERVICEDETAILTYPE_TRANSPLANT          | ""                 | 0           | false
        45 | CommonReferenceConstants.SERVICEDETAILTYPE_COSMETIC            | null               | 0           | false
        46 | CommonReferenceConstants.SERVICEDETAILTYPE_PSYCHIATRIC         | ""                 | 0           | false
        47 | HsrReferenceConstants.SERVICEDETAILTYPE_MENTALHEALTH           | null               | 0           | false
        48 | CommonReferenceConstants.SERVICEDETAILTYPE_CHIROPRACTIC        | ""                 | 0           | false
        49 | CommonReferenceConstants.SERVICEDETAILTYPE_DENTAL              | null               | 0           | false
        50 | CommonReferenceConstants.SERVICEDETAILTYPE_DIAGNOSTIIC         | ""                 | 0           | false
        51 | CommonReferenceConstants.SERVICEDETAILTYPE_DME                 | null               | 0           | false
        52 | CommonReferenceConstants.SERVICEDETAILTYPE_HOSPICE             | ""                 | 0           | false
        53 | CommonReferenceConstants.SERVICEDETAILTYPE_IMAGING             | null               | 0           | false
        54 | CommonReferenceConstants.SERVICEDETAILTYPE_INFERTILITY         | ""                 | 0           | false
        55 | CommonReferenceConstants.SERVICEDETAILTYPE_INFUSION            | null               | 0           | false
        56 | CommonReferenceConstants.SERVICEDETAILTYPE_LAB                 | ""                 | 0           | false
        57 | CommonReferenceConstants.SERVICEDETAILTYPE_LTC                 | null               | 0           | false
        58 | CommonReferenceConstants.SERVICEDETAILTYPE_MEDICATIONS         | ""                 | 0           | false
        59 | CommonReferenceConstants.SERVICEDETAILTYPE_NICU                | null               | 0           | false
        60 | CommonReferenceConstants.SERVICEDETAILTYPE_OT                  | ""                 | 0           | false
        61 | CommonReferenceConstants.SERVICEDETAILTYPE_ORTHOTICS           | null               | 0           | false
        62 | CommonReferenceConstants.SERVICEDETAILTYPE_PAIN                | ""                 | 0           | false
        63 | CommonReferenceConstants.SERVICEDETAILTYPE_PHARMACY            | null               | 0           | false
        64 | CommonReferenceConstants.SERVICEDETAILTYPE_PT                  | ""                 | 0           | false
        65 | CommonReferenceConstants.SERVICEDETAILTYPE_PRIVATEDUTYNURSING  | null               | 0           | false
        66 | CommonReferenceConstants.SERVICEDETAILTYPE_PROSTHETICS         | ""                 | 0           | false
        67 | CommonReferenceConstants.SERVICEDETAILTYPE_RESPIRATORY         | null               | 0           | false
        68 | CommonReferenceConstants.SERVICEDETAILTYPE_SKILLEDNURSING      | ""                 | 0           | false
        69 | CommonReferenceConstants.SERVICEDETAILTYPE_SPEECH              | null               | 0           | false
        70 | CommonReferenceConstants.SERVICEDETAILTYPE_SUBSTANCEABUSE      | ""                 | 0           | false
        71 | CommonReferenceConstants.SERVICEDETAILTYPE_SUPPLIES            | null               | 0           | false
        72 | CommonReferenceConstants.SERVICEDETAILTYPE_THERAPYSVCS         | ""                 | 0           | false
        73 | CommonReferenceConstants.SERVICEDETAILTYPE_TRANSPORT           | null               | 0           | false
        74 | CommonReferenceConstants.SERVICEDETAILTYPE_TRANSPLANT_SERVICES | ""                 | 0           | false
        75 | CommonReferenceConstants.SERVICEDETAILTYPE_VISION              | null               | 0           | false
        76 | CommonReferenceConstants.SERVICEDETAILTYPE_WELL_BABY           | ""                 | 0           | false
        77 | CommonReferenceConstants.SERVICEDETAILTYPE_HOME_SERVICES       | null               | 0           | false
        78 | CommonReferenceConstants.SERVICEDETAILTYPE_LTAC                | ""                 | 0           | false
        79 | CommonReferenceConstants.SERVICEDETAILTYPE_DIALYSIS            | null               | 0           | false
        80 | CommonReferenceConstants.SERVICEDETAILTYPE_PAT_SKILLED_NURSING | ""                 | 0           | false
    }

    @Unroll
    def "validate unit number less than 1000 - case #id"() {
        given:
        HscServiceSpecialSavingsVO hscServiceSpecialSavingsVO = new HscServiceSpecialSavingsVO(hscID: id, unitNumber: unitNumber)

        when:
        hscServiceSpecialSavings.validateUnitNumberLessThan1000(hscServiceSpecialSavingsVO)

        then:
        0 * _
        hscServiceSpecialSavingsVO.errorMessagesExist() == errorMsgExists
        hscServiceSpecialSavingsVO.getMessages().size() == messageSize
        hscServiceSpecialSavingsVO.getMessage(FieldConstants.UNITNUMBER)?.get(0)?.message?.messageID == fieldError

        where:
        id | unitNumber | messageSize | errorMsgExists | fieldError
        1  | 800        | 0           | false          | null
        2  | 999        | 0           | false          | null
        3  | 1000       | 1           | true           | "ERR5434"
    }

    @Unroll
    def "validate unit number non-negative - case #id"() {
        given:
        HscServiceSpecialSavingsVO hscServiceSpecialSavingsVO = new HscServiceSpecialSavingsVO(hscID: id, unitNumber: unitNumber)

        when:
        hscServiceSpecialSavings.validateUnitNumberNonNegative(hscServiceSpecialSavingsVO)

        then:
        0 * _
        hscServiceSpecialSavingsVO.errorMessagesExist() == errorMsgExists
        hscServiceSpecialSavingsVO.getMessages().size() == messageSize
        hscServiceSpecialSavingsVO.getMessage(FieldConstants.UNITNUMBER)?.get(0)?.message?.messageID == fieldError


        where:
        id | unitNumber | messageSize | errorMsgExists | fieldError
        1  | 800        | 0           | false          | null
        2  | 0          | 0           | false          | null
        3  | -2         | 1           | true           | "ERR5432"
    }

    @Unroll
    def "validate standard sub-acute rate non-negative - case #id"() {
        given:
        HscServiceSpecialSavingsVO hscServiceSpecialSavingsVO = new HscServiceSpecialSavingsVO(
                hscID: id, standardSubAcuteRate: standardSubAcuteRate)

        when:
        hscServiceSpecialSavings.validateStandardSubAcuteRateNonNegative(hscServiceSpecialSavingsVO)

        then:
        0 * _
        hscServiceSpecialSavingsVO.errorMessagesExist() == errorMsgExists
        hscServiceSpecialSavingsVO.getMessages().size() == messageSize
        hscServiceSpecialSavingsVO.getMessage(FieldConstants.STANDARDSUBACUTERATE)?.get(0)?.message?.messageID == fieldError

        where:
        id | standardSubAcuteRate | messageSize | errorMsgExists | fieldError
        1  | 1                    | 0           | false          | null
        2  | 0                    | 0           | false          | null
        3  | -1                   | 1           | true           | "ERR5432"
    }

    @Unroll
    def "validate standard acute care rate non-negative - case #id"() {
        given:
        HscServiceSpecialSavingsVO hscServiceSpecialSavingsVO = new HscServiceSpecialSavingsVO(
                hscID: id, standardAcuteCareRate: standardAcuteCareRate)

        when:
        hscServiceSpecialSavings.validateStandardAcuteCareRateNonNegative(hscServiceSpecialSavingsVO)

        then:
        0 * _
        hscServiceSpecialSavingsVO.errorMessagesExist() == errorMsgExists
        hscServiceSpecialSavingsVO.getMessages().size() == messageSize
        hscServiceSpecialSavingsVO.getMessage(FieldConstants.STANDARDACUTECARERATE)?.get(0)?.message?.messageID == fieldError

        where:
        id | standardAcuteCareRate | messageSize | errorMsgExists | fieldError
        1  | 1                     | 0           | false          | null
        2  | 0                     | 0           | false          | null
        3  | -1                    | 1           | true           | "ERR5432"
    }

    @Unroll
    def "validate negotiated sub-acute rate non-negative - case #id"() {
        given:
        HscServiceSpecialSavingsVO hscServiceSpecialSavingsVO = new HscServiceSpecialSavingsVO(
                hscID: id, negotiatedSubAcuteRate: negotiatedSubAcuteRate)

        when:
        hscServiceSpecialSavings.validateNegotiatedSubAcuteRateNonNegative(hscServiceSpecialSavingsVO)

        then:
        0 * _
        hscServiceSpecialSavingsVO.errorMessagesExist() == errorMsgExists
        hscServiceSpecialSavingsVO.getMessages().size() == messageSize
        hscServiceSpecialSavingsVO.getMessage(FieldConstants.NEGOTIATEDSUBACUTERATE)?.get(0)?.message?.messageID == fieldError

        where:
        id | negotiatedSubAcuteRate | messageSize | errorMsgExists | fieldError
        1  | 1                      | 0           | false          | null
        2  | 0                      | 0           | false          | null
        3  | -1                     | 1           | true           | "ERR5432"
    }

    @Unroll
    def "validate total savings amount - case #id"() {
        given:
        HscServiceSpecialSavingsVO hscServiceSpecialSavingsVO = new HscServiceSpecialSavingsVO(hscID: id, totalSavingsAmount: totalSavingsAmount)

        when:
        hscServiceSpecialSavings.validateTotalSavingsAmount(hscServiceSpecialSavingsVO)

        then:
        0 * _
        hscServiceSpecialSavingsVO.errorMessagesExist() == errorMsgExists
        hscServiceSpecialSavingsVO.getMessages().size() == messageSize
        hscServiceSpecialSavingsVO.getMessage(FieldConstants.TOTALSAVINGSAMOUNT)?.get(0)?.message?.messageID == fieldError

        where:
        id | totalSavingsAmount | messageSize | errorMsgExists | fieldError
        1  | 1                  | 0           | false          | null
        2  | 0                  | 0           | false          | null
        3  | -1                 | 1           | true           | "ERR5433"
    }

    @Unroll
    def "validate step down savings amount non-negative - case #id"() {
        given:
        HscServiceSpecialSavingsVO hscServiceSpecialSavingsVO = new HscServiceSpecialSavingsVO(
                hscID: id, stepDownSavingsAmount: stepDownSavings)

        when:
        hscServiceSpecialSavings.validateStepDownSavingsAmountNonNegative(hscServiceSpecialSavingsVO)

        then:
        0 * _
        hscServiceSpecialSavingsVO.errorMessagesExist() == errorMsgExists
        hscServiceSpecialSavingsVO.getMessages().size() == messageSize
        hscServiceSpecialSavingsVO.getMessage(FieldConstants.STEPDOWNSAVINGSAMOUNT)?.get(0)?.message?.messageID == fieldError

        where:
        id | stepDownSavings | messageSize | errorMsgExists | fieldError
        1  | 1               | 0           | false          | null
        2  | 0               | 0           | false          | null
        3  | -1              | 1           | true           | "ERR5433"
    }

    @Unroll
    def "validate negotiated savings amount non-negative - case #id"() {
        given:
        HscServiceSpecialSavingsVO hscServiceSpecialSavingsVO = new HscServiceSpecialSavingsVO(
                hscID: id, negotiatedSavingsAmount: negotiatedSavings)

        when:
        hscServiceSpecialSavings.validateNegotiatedSavingsAmountNonNegative(hscServiceSpecialSavingsVO)

        then:
        0 * _
        hscServiceSpecialSavingsVO.errorMessagesExist() == errorMsgExists
        hscServiceSpecialSavingsVO.getMessages().size() == messageSize
        hscServiceSpecialSavingsVO.getMessage(FieldConstants.NEGOTIATEDSAVINGSAMOUNT)?.get(0)?.message?.messageID == fieldError

        where:
        id | negotiatedSavings | messageSize | errorMsgExists | fieldError
        1  | 1                 | 0           | false          | null
        2  | 0                 | 0           | false          | null
        3  | -1                | 1           | true           | "ERR5433"
    }

    def "get query properties"() {
        given:
        long hscID = 10

        when:
        QueryProperties retValue = hscServiceSpecialSavings.getQueryProperties(hscID)

        then:
        0 * _
        retValue.getFilterType() == QueryProperties.FilterType.LIST_ALL
        retValue.getQueryFilters().size() == 1
        retValue.getQueryFilter(FieldConstants.HSCID).getFieldValue() == hscID
    }

    def "get special savings list"() {
        given:
        long hscID = 555
        short serviceSeqNum = 111
        HscServiceSpecialSavingsVO hscServiceSpecialSavingsVO = new HscServiceSpecialSavingsVO(hscID: hscID, serviceSeqNum: serviceSeqNum)

        when:
        List returnedList = hscServiceSpecialSavings.getSpecialSavingsList(hscID, serviceSeqNum)

        then:
        1 * dao.list(_ as QueryProperties) >> { QueryProperties qp ->
            assert qp.getFilterType() == QueryProperties.FilterType.LIST_ALL
            assert qp.getQueryFilters().size() == 2
            assert qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == hscID
            assert qp.getQueryFilter(FieldConstants.SERVICESEQNUM).getFieldValue() == serviceSeqNum
            assert qp.getQueryFilter(FieldConstants.SERVICESEQNUM).getCriterion() == QueryCriteria.EQUAL
            return [hscServiceSpecialSavingsVO]
        }
        0 * _
        returnedList.size() == 1
        returnedList[0] == hscServiceSpecialSavingsVO
        returnedList[0].hscID == hscID
        returnedList[0].serviceSeqNum == serviceSeqNum
    }

    def "list by hsc id"() {
        given:
        long hscID = 435436
        HscServiceSpecialSavingsVO hscServiceSpecialSavingsVO = new HscServiceSpecialSavingsVO(hscID: hscID)

        when:
        List returnedList = hscServiceSpecialSavings.listByHscID(hscID)

        then:
        1 * dao.list(_ as QueryProperties) >> { QueryProperties qp ->
            assert qp.getFilterType() == QueryProperties.FilterType.LIST_ALL
            assert qp.getQueryFilters().size() == 1
            assert qp.getQueryFilter(FieldConstants.HSCID).fieldValue == hscID
            return [hscServiceSpecialSavingsVO]
        }
        0 * _
        returnedList.size() == 1
        returnedList[0] == hscServiceSpecialSavingsVO
        returnedList[0].hscID == hscID
    }

    def "delete savings for service"() {
        given:
        long hscId = 2347238
        short serviceSeqNum = 23
        List list = [new HscServiceSpecialSavingsVO(hscID: hscId, serviceSeqNum: serviceSeqNum)]

        when:
        hscServiceSpecialSavings.deleteSavingsForService(hscId, serviceSeqNum)

        then:
        1 * dao.list(_ as QueryProperties) >> { QueryProperties qp ->
            assert qp.getFilterType() == QueryProperties.FilterType.LIST_ALL
            assert qp.getQueryFilters().size() == 2
            assert qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == hscId
            assert qp.getQueryFilter(FieldConstants.SERVICESEQNUM).getFieldValue() == serviceSeqNum
            assert qp.getQueryFilter(FieldConstants.SERVICESEQNUM).getCriterion() == QueryCriteria.EQUAL
            assert qp.getQueryFilter(FieldConstants.SERVICESEQNUM).getPredicateCriterion() == QueryFilter.SqlPredicateKeyword.AND
            return list
        }
        1 * persistenceHelper.deleteBatch(list)
        0 * _
    }

    def "save service special savings"() {
        given:
        long hscID = 5312
        short seqNum = 74
        int yearNumber = 2016
        String month = "02"
        HscServiceSpecialSavingsVO hscServiceSpecialSavingsVO = new HscServiceSpecialSavingsVO(hscID: hscID, serviceSeqNum: seqNum, yearNumber: yearNumber, monthTypeID: month, unitNumber: 1)
        HscServiceNonFacilityVO hscServiceNonFacilityVO = new HscServiceNonFacilityVO(hscID: hscID, serviceSeqNum: seqNum,
                serviceStartDate: new UhgCalendar(2014, 1, 1).getSQLDate(), serviceEndDate: new UhgCalendar(2018, 1, 1).getSQLDate(),
                placeOfServiceCode: CommonReferenceConstants.PLACEOFSERVICE_HOME, serviceDetailType: CommonReferenceConstants.SERVICEDETAILTYPE_DME, dmeProcurementType: HsrReferenceConstants.DME_PROCUREMENT_RENT)
        HscProviderVO hscProviderVO = new HscProviderVO(hscID: hscID)

        when:
        hscServiceSpecialSavings.saveServiceSpecialSavings(hscServiceSpecialSavingsVO, hscServiceNonFacilityVO, hscProviderVO)

        then:
        1 * dao.isDuplicate(_ as QueryProperties) >> { QueryProperties qp ->
            assert qp.getFilterType() == QueryProperties.FilterType.NEW_FILTER
            assert qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == hscID
            assert qp.getQueryFilter(FieldConstants.SERVICESEQNUM).getFieldValue() == seqNum
            assert qp.getQueryFilter(FieldConstants.YEARNUMBER).getFieldValue() == yearNumber
            assert qp.getQueryFilter(FieldConstants.MONTHTYPEID).getFieldValue() == month
            return false
        }
        1 * hsc.readUnhydrated(hscID) >> new HscVO(hscID: hscID, specialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_CARE_PROGRAMS, hscStatusType: HsrReferenceConstants.HSCSTATUSTYPE_OPEN)
        1 * hscServiceNonFacility.read(hscID, seqNum) >> hscServiceNonFacilityVO
        1 * persistenceHelper.add(_ as HscServiceSpecialSavingsVO) >> { HscServiceSpecialSavingsVO vo ->
            assert vo.hscID == hscID
            assert vo.monthTypeID == month
            assert vo.serviceSeqNum == seqNum
            assert vo.yearNumber == yearNumber
        }
        0 * _
    }

    def "save service special savings: exception thrown"() {
        given:
        long hscID = 3434
        short seqNum = 31
        HscServiceSpecialSavingsVO hscServiceSpecialSavingsVO = new HscServiceSpecialSavingsVO(hscID: hscID, serviceSeqNum: seqNum, yearNumber: 2016, monthTypeID: "02")
        HscServiceNonFacilityVO hscServiceNonFacilityVO = new HscServiceNonFacilityVO(hscID: hscID, serviceSeqNum: seqNum,
                serviceStartDate: new UhgCalendar(2014, 1, 1).getSQLDate(), serviceEndDate: new UhgCalendar(2018, 1, 1).getSQLDate(),
                placeOfServiceCode: CommonReferenceConstants.PLACEOFSERVICE_HOME, serviceDetailType: !equals(CommonReferenceConstants.SERVICEDETAILTYPE_DME))
        HscProviderVO hscProviderVO = new HscProviderVO(hscID: hscID)
        when:
        hscServiceSpecialSavings.saveServiceSpecialSavings(hscServiceSpecialSavingsVO, hscServiceNonFacilityVO, hscProviderVO)

        then:
        thrown UhgRuntimeException
        1 * dao.isDuplicate(_ as QueryProperties) >> { QueryProperties qp ->
            assert qp.getFilterType() == QueryProperties.FilterType.NEW_FILTER
            assert qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == hscID
            assert qp.getQueryFilter(FieldConstants.SERVICESEQNUM).getFieldValue() == seqNum
            assert qp.getQueryFilter(FieldConstants.YEARNUMBER).getFieldValue() == 2016
            assert qp.getQueryFilter(FieldConstants.MONTHTYPEID).getFieldValue() == "02"
            return false
        }
        1 * hsc.readUnhydrated(hscID) >> new HscVO(hscID: hscID)
        1 * hscServiceNonFacility.read(hscID, seqNum) >> hscServiceNonFacilityVO
        0 * _
    }

    def "overriden HscServiceSpecialSavingsVO validation"() {
        given:
        long hscID = 74542
        HscServiceSpecialSavingsVO hscServiceSpecialSavingsVO = new HscServiceSpecialSavingsVO(hscID: hscID, serviceSeqNum: 74, yearNumber: 2017, monthTypeID: "03")
        HscServiceNonFacilityVO hscServiceNonFacilityVO = new HscServiceNonFacilityVO(hscID: hscID, serviceSeqNum: 74,
                serviceStartDate: new UhgCalendar(2014, 1, 1).getSQLDate(), serviceEndDate: new UhgCalendar(2018, 1, 1).getSQLDate(),
                placeOfServiceCode: CommonReferenceConstants.PLACEOFSERVICE_HOME, serviceDetailType: CommonReferenceConstants.SERVICEDETAILTYPE_DME, dmeProcurementType: HsrReferenceConstants.DME_PROCUREMENT_PURCHASE)

        when:
        hscServiceSpecialSavings.validate(hscServiceSpecialSavingsVO, false)

        then:
        1 * hsc.readUnhydrated(hscID) >> new HscVO(hscID: hscID, specialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_CARE_PROGRAMS, hscStatusType: HsrReferenceConstants.HSCSTATUSTYPE_OPEN)
        1 * hscServiceNonFacility.read(hscID, 74) >> hscServiceNonFacilityVO
        0 * _
    }

    def "pass non-negative savings validation method for coverage only"() {
        when:
        hscServiceSpecialSavings.validateNonNegativeSavingValues(new HscServiceSpecialSavingsVO(hscID: 27))
        then:
        0 * _
    }
}
