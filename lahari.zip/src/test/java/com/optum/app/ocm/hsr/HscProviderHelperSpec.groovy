package com.optum.app.ocm.hsr

import com.optum.app.ocm.common.provider.ProviderClinicalAddress
import com.optum.app.ocm.common.provider.businesslogic.ProviderClinical
import com.optum.app.ocm.common.provider.businesslogic.ProviderClinicalIdentifier
import com.optum.app.ocm.common.provider.businesslogic.ProviderClinicalTelephone
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.app.common.hsr.businesslogic.Hsc
import com.optum.app.common.hsr.businesslogic.HscProvider
import com.optum.app.common.hsr.businesslogic.NotificationProviderClinicalView
import com.optum.app.common.hsr.businesslogic.impl.HscProviderHelperImpl
import com.optum.app.common.hsr.constants.HsrReferenceConstants
import com.optum.app.common.hsr.data.HscProviderVO
import com.optum.app.common.hsr.data.HscVO
import com.optum.app.common.hsr.data.NotificationProviderClinicalViewVO
import com.optum.app.common.provider.data.ProviderClinicalAddressVO
import com.optum.app.common.provider.data.ProviderClinicalIdentifierVO
import com.optum.app.common.provider.data.ProviderClinicalTelephoneVO
import com.optum.app.common.provider.data.ProviderClinicalVO
import com.optum.app.constants.CommonReferenceConstants
import org.apache.commons.lang.StringUtils
import spock.lang.Unroll

class HscProviderHelperSpec extends HsrReadLogicSpecification {
    private HscProviderHelperImpl hscProviderHelper
    private Hsc hsc
    private HscProvider hscProvider
    private NotificationProviderClinicalView notificationProviderClinicalView
    private ProviderClinical providerClinical
    private ProviderClinicalAddress providerClinicalAddress
    private ProviderClinicalIdentifier providerClinicalIdentifier
    private ProviderClinicalTelephone providerClinicalTelephone

    def setup() {
        hscProviderHelper = new HscProviderHelperImpl()
        hsc = Mock(Hsc)
        hscProvider = Mock(HscProvider)
        notificationProviderClinicalView = Mock(NotificationProviderClinicalView)
        providerClinical = Mock(ProviderClinical)
        providerClinicalAddress = Mock(ProviderClinicalAddress)
        providerClinicalIdentifier = Mock(ProviderClinicalIdentifier)
        providerClinicalTelephone = Mock(ProviderClinicalTelephone)

        hscProviderHelper.hsc = hsc
        hscProviderHelper.hscProvider = hscProvider
        hscProviderHelper.notificationProviderClinicalView = notificationProviderClinicalView
        hscProviderHelper.providerClinical = providerClinical
        hscProviderHelper.providerClinicalAddress = providerClinicalAddress
        hscProviderHelper.providerClinicalIdentifier = providerClinicalIdentifier
        hscProviderHelper.providerClinicalTelephone = providerClinicalTelephone
    }

    @Unroll
    def "Test to read when case is open"() {
        setup:
        def hscID = (long) 1
        def providerSeqNum = (short) 1
        def providerClinicalID = (long) 323
        NotificationProviderClinicalViewVO providerVO = new NotificationProviderClinicalViewVO(hscID: hscID,
                providerSeqNum: providerSeqNum, providerClinicalID: providerClinicalID,
                businessName: businessName, lastName: lastName)
        HscVO hscVO = new HscVO(hscID: hscID, hscStatusType: HsrReferenceConstants.HSCSTATUSTYPE_OPEN)

        when:
        def returnVO = hscProviderHelper.read(hscID, providerSeqNum)

        then:
        1 * hsc.read(hscID) >> hscVO
        1 * notificationProviderClinicalView.read(hscID, providerSeqNum) >> providerVO
        1 * hscProvider.setNonPersistedRoles(_)
        0 * _
        returnVO.providerNameToDisplay == expectedDisplayName

        where:
        expectedDisplayName | businessName      | lastName
        "A"                 | "A"               | StringUtils.EMPTY
        "B"                 | StringUtils.EMPTY | "B"
    }

    @Unroll
    def "Test to read when case is closed"() {
        setup:
        def hscID = (long) 1
        def providerSeqNum = (short) 1
        def providerClinicalID = (long) 323
        HscProviderVO providerVO = new HscProviderVO(hscID: hscID,
                providerSeqNum: providerSeqNum, providerClinicalID: providerClinicalID,
                businessName: businessName, lastName: lastName)
        HscVO hscVO = new HscVO(hscID: hscID, hscStatusType: HsrReferenceConstants.HSCSTATUSTYPE_CLOSED)

        when:
        def returnVO = hscProviderHelper.read(hscID, providerSeqNum)

        then:
        1 * hsc.read(hscID) >> hscVO
        1 * hscProvider.read(hscID, providerSeqNum, _) >> providerVO
        0 * _
        returnVO.providerNameToDisplay == expectedDisplayName

        where:
        expectedDisplayName | businessName      | lastName
        "A"                 | "A"               | StringUtils.EMPTY
        "B"                 | StringUtils.EMPTY | "B"
    }

    @Unroll
    def "Test listByHscWithRoles when case is open"() {
        setup:
        def hscID = (long) 1
        def providerSeqNum = (short) 1
        def providerClinicalID = (long) 323
        def queryProperties = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        NotificationProviderClinicalViewVO providerVO = new NotificationProviderClinicalViewVO(hscID: hscID,
                providerSeqNum: providerSeqNum, providerClinicalID: providerClinicalID,
                businessName: businessName, lastName: lastName, firstName: firstName)
        HscVO hscVO = new HscVO(hscID: hscID, hscStatusType: HsrReferenceConstants.HSCSTATUSTYPE_OPEN)

        when:
        def returnVOs = hscProviderHelper.listByHscWithRoles(hscID, queryProperties)

        then:
        1 * hsc.read(hscID) >> hscVO
        1 * notificationProviderClinicalView.listByHscID(queryProperties, hscID) >> [providerVO]
        1 * hscProvider.setNonPersistedItemsAndDisplayValues(_)
        0 * _
        !returnVOs.isEmpty()

        where:
        expectedDisplayName | businessName      | lastName            | firstName
        "A"                 | "A"               | StringUtils.EMPTY   | StringUtils.EMPTY
        "B, A"              | StringUtils.EMPTY | "B"                 | "A"
        "B"                 | StringUtils.EMPTY | "B"                 | StringUtils.EMPTY
        "A"                 | StringUtils.EMPTY | StringUtils.EMPTY   | "A"
    }

    @Unroll
    def "Test listByHscWithRoles when case is closed"() {
        setup:
        def hscID = (long) 1
        def providerSeqNum = (short) 1
        def providerClinicalID = (long) 323
        def queryProperties = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        HscProviderVO providerVO = new HscProviderVO(hscID: hscID,
                providerSeqNum: providerSeqNum, providerClinicalID: providerClinicalID,
                businessName: businessName, lastName: lastName, firstName: firstName)
        HscVO hscVO = new HscVO(hscID: hscID, hscStatusType: HsrReferenceConstants.HSCSTATUSTYPE_CLOSED)

        when:
        def returnVOs = hscProviderHelper.listByHscWithRoles(hscID, queryProperties)

        then:
        1 * hsc.read(hscID) >> hscVO
        1 * hscProvider.listByHscWithRoles(hscID, queryProperties) >> [providerVO]
        0 * _
        !returnVOs.isEmpty()

        where:
        expectedDisplayName | businessName      | lastName            | firstName
        "A"                 | "A"               | StringUtils.EMPTY   | StringUtils.EMPTY
        "B, A"              | StringUtils.EMPTY | "B"                 | "A"
        "B"                 | StringUtils.EMPTY | "B"                 | StringUtils.EMPTY
        "A"                 | StringUtils.EMPTY | StringUtils.EMPTY   | "A"
    }

    def "Test saveProviderForNonClosedHSC"() {
        setup:
        def hscID = (long) 1
        def providerSeqNum = (short) 1
        def providerClinicalID = (long) 323
        def businessName = "business"
        def address1 = "address1"
        def city = "city"
        def providerNPI = "333"
        def groupNumber = "444"
        def primaryPhone = "primaryPhone"
        HscProviderVO hscProviderVO = new HscProviderVO(hscID: hscID,
                providerSeqNum: providerSeqNum, providerClinicalID: providerClinicalID,
                businessName: businessName, address1: address1, city: city, providerNPI: providerNPI,
                primaryPhone: primaryPhone, providerGroupNumber: groupNumber)
        ProviderClinicalVO providerClinicalVO = new ProviderClinicalVO(providerClinicalID: providerClinicalID,
                businessName: businessName)
        ProviderClinicalAddressVO providerClinicalAddressVO = new ProviderClinicalAddressVO(providerClinicalID: providerClinicalID,
                address1: address1, city: city, addressType: HsrReferenceConstants.ADDRESSTYPE_PERMANENT)
        ProviderClinicalIdentifierVO providerClinicalIdentifierVO1 = new ProviderClinicalIdentifierVO(providerClinicalID: providerClinicalID,
                providerClinicalIDTypeID: CommonReferenceConstants.PROVIDER_ID_TYPE_NPI, providerClinicalIDText: providerNPI)
        ProviderClinicalIdentifierVO providerClinicalIdentifierVO2 = new ProviderClinicalIdentifierVO(providerClinicalID: providerClinicalID,
                providerClinicalIDTypeID: CommonReferenceConstants.PROVIDER_ID_GROUP_NUMBER, providerClinicalIDText: groupNumber)
        ProviderClinicalTelephoneVO providerClinicalTelephoneVO = new ProviderClinicalTelephoneVO(providerClinicalID: providerClinicalID,
                phoneType: CommonReferenceConstants.PROVIDER_ID_TYPE_NPI, phone: primaryPhone)

        when:
        hscProviderHelper.saveProviderForNonClosedHSC(hscProviderVO)

        then:
        1 * providerClinical.isValid(providerClinicalID) >> true
        1 * providerClinical.read(providerClinicalID) >> providerClinicalVO
        1 * providerClinicalAddress.getAllAddressesForProvider(providerClinicalID) >> [providerClinicalAddressVO]
        1 * providerClinicalIdentifier.getAllIdentifiers(providerClinicalID) >> [providerClinicalIdentifierVO1, providerClinicalIdentifierVO2]
        1 * providerClinicalTelephone.getTelephonesForProvider(
                        providerClinicalID, HsrReferenceConstants.PHONE_TYPE_OFFICE) >> providerClinicalTelephoneVO
        1 * providerClinical.save(providerClinicalVO)
        1 * providerClinicalAddress.save(_)
        1 * providerClinicalIdentifier.save(providerClinicalIdentifierVO1)
        1 * providerClinicalIdentifier.save(providerClinicalIdentifierVO2)
        1 * providerClinicalTelephone.save(providerClinicalTelephoneVO)
        1 * hscProvider.saveProviderVO(hscProviderVO)
        0 * _
    }

    @Unroll
    def "Test saveProviderForClosedHSC"() {
        setup:
        def hscID = (long) 1
        def providerSeqNum = (short) 1
        def providerClinicalID = (long) 323
        NotificationProviderClinicalViewVO notificationProviderClinicalViewVO = new NotificationProviderClinicalViewVO(hscID: hscID,
                providerSeqNum: providerSeqNum, providerClinicalID: providerClinicalID,
                businessName: businessName, lastName: lastName, firstName: firstName)
        HscProviderVO hscProviderVO = new HscProviderVO(hscID: hscID,
                providerSeqNum: providerSeqNum, providerClinicalID: providerClinicalID,
                businessName: businessName, lastName: lastName, firstName: firstName)

        when:
        hscProviderHelper.saveProviderForClosedHSC(hscID)

        then:
        1 * notificationProviderClinicalView.listByHscID(null, hscID) >> [notificationProviderClinicalViewVO]
        1 * hscProvider.setNonPersistedItemsAndDisplayValues(hscProviderVO)
        1 * hscProvider.saveProviderVO(hscProviderVO)
        0 * _

        where:
        expectedDisplayName | businessName      | lastName            | firstName
        "A"                 | "A"               | StringUtils.EMPTY   | StringUtils.EMPTY
        "B, A"              | StringUtils.EMPTY | "B"                 | "A"
        "B"                 | StringUtils.EMPTY | "B"                 | StringUtils.EMPTY
        "A"                 | StringUtils.EMPTY | StringUtils.EMPTY   | "A"
    }
}
