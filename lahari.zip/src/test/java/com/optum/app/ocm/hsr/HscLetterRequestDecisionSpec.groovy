package com.optum.app.ocm.hsr

import com.optum.rf.bl.spring.TransactionInterceptor
import com.optum.rf.core.locator.ServiceLocator
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.HscLetterRequestDecision
import com.optum.app.common.hsr.businesslogic.impl.HscLetterRequestDecisionImpl
import com.optum.app.common.hsr.data.HscLetterRequestDecisionVO
import spock.lang.Unroll

class HscLetterRequestDecisionSpec extends HsrReadLogicSpecification {

    HscLetterRequestDecision hscLetterRequestDecision

    DataAccessObject dao
    PersistenceHelper persistenceHelper
    ServiceLocator serviceLocator
    TransactionInterceptor transactionInterceptor

    def setup() {
        dao = Mock(DataAccessObject)
        persistenceHelper = Mock(PersistenceHelper)
        serviceLocator = Mock(ServiceLocator)
        transactionInterceptor = Mock(TransactionInterceptor)

        hscLetterRequestDecision = new HscLetterRequestDecisionImpl(
                requiredDao: dao,
                requiredPersistenceHelper: persistenceHelper,
                requiredServiceLocator: serviceLocator,
                requiredTransactionInterceptor: transactionInterceptor
        )
    }

    @Unroll
    def "isValid #testCase"() {
        given:
        def hscID = (long) 1
        def letterRequestSeqNum = 2
        def letterRequestDecisionSeqNum = 3
        def rp = new ReadProperties(FieldConstants.HSCID, FieldConstants.LETTERREQUESTSEQNUM, FieldConstants.LETTERREQUESTDECISIONSEQNUM)
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        rp.setKeyValue(FieldConstants.LETTERREQUESTSEQNUM, letterRequestSeqNum)
        rp.setKeyValue(FieldConstants.LETTERREQUESTDECISIONSEQNUM, letterRequestDecisionSeqNum)
        rp.fields = null

        when:
        boolean retVal = hscLetterRequestDecision.isValid(hscID, letterRequestSeqNum, letterRequestDecisionSeqNum)

        then:
        1 * dao.isValid(rp) >> expectedVal
        0 * _
        retVal == expectedVal

        where:
        testCase | expectedVal
        "passes" | true
        "fails"  | false
    }

    def "Test to read HscLetterRequestDecisionVO"() {
        setup:
        def hscID = (long) 1
        def letterRequestSeqNum = 2
        def letterRequestDecisionSeqNum = 3
        HscLetterRequestDecisionVO hscLetterRequestDecisionVO = new HscLetterRequestDecisionVO(hscID: hscID, letterRequestSeqNum: letterRequestSeqNum, letterRequestDecisionSeqNum: letterRequestDecisionSeqNum)
        def rp = new ReadProperties(FieldConstants.HSCID, FieldConstants.LETTERREQUESTSEQNUM, FieldConstants.LETTERREQUESTDECISIONSEQNUM)
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        rp.setKeyValue(FieldConstants.LETTERREQUESTSEQNUM, letterRequestSeqNum)
        rp.setKeyValue(FieldConstants.LETTERREQUESTDECISIONSEQNUM, letterRequestDecisionSeqNum)
        rp.fields = null

        when:
        hscLetterRequestDecision.read(hscID, letterRequestSeqNum, letterRequestDecisionSeqNum)

        then:
        1 * dao.read(rp) >> hscLetterRequestDecisionVO
        0 * _
    }
}
