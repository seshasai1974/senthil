package com.optum.app.ocm.hsr

import com.optum.rf.bl.spring.TransactionInterceptor
import com.optum.rf.core.locator.ServiceLocator
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.HscProviderContractAmendmentClause
import com.optum.app.common.hsr.businesslogic.impl.HscProviderContractAmendmentClauseImpl
import com.optum.app.common.hsr.data.HscProviderContractAmendmentClauseVO
import com.optum.app.common.hsr.data.HscProviderContractAmendmentVO
import spock.lang.Unroll

class HscProviderContractAmendmentClauseSpec extends HsrReadLogicSpecification {

    HscProviderContractAmendmentClause hscProviderContractAmendment

    DataAccessObject dao
    PersistenceHelper persistenceHelper
    ServiceLocator serviceLocator
    TransactionInterceptor transactionInterceptor

    def setup() {
        dao = Mock(DataAccessObject)
        persistenceHelper = Mock(PersistenceHelper)
        serviceLocator = Mock(ServiceLocator)
        transactionInterceptor = Mock(TransactionInterceptor)

        hscProviderContractAmendment = new HscProviderContractAmendmentClauseImpl(
                dao: dao,
                requiredPersistenceHelper: persistenceHelper,
                requiredServiceLocator: serviceLocator,
                requiredTransactionInterceptor: transactionInterceptor
        )
    }

    @Unroll
    def "isValid #testCase"() {
        given:
        def hscID = (long) 1
        def providerSeqNum = (short) 2
        def contractAmendmentSeqNum = 3
        def providerContractClauseTypeID = "4"
        def rp = new ReadProperties(FieldConstants.HSCID, FieldConstants.PROVIDERSEQNUM, FieldConstants.CONTRACTAMENDMENTSEQNUM, FieldConstants.PROVIDERCONTRACTCLAUSETYPEID)
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        rp.setKeyValue(FieldConstants.PROVIDERSEQNUM, providerSeqNum)
        rp.setKeyValue(FieldConstants.CONTRACTAMENDMENTSEQNUM, contractAmendmentSeqNum)
        rp.setKeyValue(FieldConstants.PROVIDERCONTRACTCLAUSETYPEID, providerContractClauseTypeID)
        rp.fields = null

        when:
        boolean retVal = hscProviderContractAmendment.isValid(hscID, providerSeqNum, contractAmendmentSeqNum, providerContractClauseTypeID)

        then:
        1 * dao.isValid(rp) >> expectedVal
        0 * _
        retVal == expectedVal

        where:
        testCase | expectedVal
        "passes" | true
        "fails"  | false
    }

    def "Test to read HscProviderContractAmendmentClauseVO"() {
        setup:
        def hscID = (long) 1
        def providerSeqNum = (short) 2
        def contractAmendmentSeqNum = 3
        def providerContractClauseTypeID = "4"
        HscProviderContractAmendmentClauseVO hscProviderContractAmendmentClauseVO = new HscProviderContractAmendmentClauseVO(hscID: hscID, providerSeqNum: providerSeqNum, contractAmendmentSeqNum: contractAmendmentSeqNum, providerContractClauseTypeID: providerContractClauseTypeID)
        def rp = new ReadProperties(FieldConstants.HSCID, FieldConstants.PROVIDERSEQNUM, FieldConstants.CONTRACTAMENDMENTSEQNUM, FieldConstants.PROVIDERCONTRACTCLAUSETYPEID)
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        rp.setKeyValue(FieldConstants.PROVIDERSEQNUM, providerSeqNum)
        rp.setKeyValue(FieldConstants.CONTRACTAMENDMENTSEQNUM, contractAmendmentSeqNum)
        rp.setKeyValue(FieldConstants.PROVIDERCONTRACTCLAUSETYPEID, providerContractClauseTypeID)
        rp.fields = null

        when:
        hscProviderContractAmendment.read(hscID, providerSeqNum, contractAmendmentSeqNum, providerContractClauseTypeID)

        then:
        1 * dao.read(rp) >> hscProviderContractAmendmentClauseVO
        0 * _
    }

    def "Test copyProviderContractAmendmentClause"() {
        setup:
        def hscID = (long) 1
        def newHscID = (long) 2
        def providerSeqNum = (short) 2
        def contractAmendmentSeqNum = 3
        HscProviderContractAmendmentVO hscProviderContractAmendmentVO = new HscProviderContractAmendmentVO(hscID: hscID, providerSeqNum: providerSeqNum, contractAmendmentSeqNum: contractAmendmentSeqNum)

        when:
        hscProviderContractAmendment.copyProviderContractAmendmentClause(hscProviderContractAmendmentVO, hscID, newHscID, providerSeqNum)

        then:
        1 * dao.list(_ as QueryProperties) >> [ new HscProviderContractAmendmentClauseVO() ]
        0 * _
    }

    def "Test deleteContractAmendmentClauses"() {
        setup:
        def hscID = (long) 1
        def providerSeqNum = (short) 2
        def contractAmendmentSeqNum = 3
        HscProviderContractAmendmentVO hscProviderContractAmendmentVO = new HscProviderContractAmendmentVO(hscID: hscID, providerSeqNum: providerSeqNum, contractAmendmentSeqNum: contractAmendmentSeqNum)

        when:
        hscProviderContractAmendment.deleteContractAmendmentClauses(hscProviderContractAmendmentVO)

        then:
        1 * dao.list(_ as QueryProperties) >> [ new HscProviderContractAmendmentClauseVO() ]
        1 * persistenceHelper.delete(_ as HscProviderContractAmendmentClauseVO)
        0 * _
    }

    def "Test validate"() {
        setup:
        def hscID = (long) 1
        def providerSeqNum = (short) 2
        def contractAmendmentSeqNum = 3
        HscProviderContractAmendmentClauseVO hscProviderContractAmendmentClauseVO = new HscProviderContractAmendmentClauseVO(hscID: hscID, providerSeqNum: providerSeqNum, contractAmendmentSeqNum: contractAmendmentSeqNum, providerContractClauseTypeID: clauseType)

        when:
        hscProviderContractAmendment.validate(hscProviderContractAmendmentClauseVO, false)

        then:
        0 * _

        and:
        if(!clauseType) {
            assert hscProviderContractAmendmentClauseVO.errorMessagesExist()
        }

        where: clauseType << [ null, '4' ]
    }

}
