package com.optum.app.ocm.hsr

import com.optum.rf.bl.spring.TransactionInterceptor
import com.optum.rf.core.locator.ServiceLocator
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.HscProviderInfoRequestCriteria
import com.optum.app.common.hsr.businesslogic.impl.HscProviderInfoRequestCriteriaImpl
import com.optum.app.common.hsr.data.HscProviderInfoRequestCriteriaVO
import spock.lang.Unroll

class HscProviderInfoRequestCriteriaSpec extends HsrReadLogicSpecification {

    HscProviderInfoRequestCriteria hscProviderInfoRequestCriteria

    DataAccessObject dao
    PersistenceHelper persistenceHelper
    ServiceLocator serviceLocator
    TransactionInterceptor transactionInterceptor

    def setup() {
        dao = Mock(DataAccessObject)
        persistenceHelper = Mock(PersistenceHelper)
        serviceLocator = Mock(ServiceLocator)
        transactionInterceptor = Mock(TransactionInterceptor)

        hscProviderInfoRequestCriteria = new HscProviderInfoRequestCriteriaImpl(
                dao: dao,
                requiredPersistenceHelper: persistenceHelper,
                requiredServiceLocator: serviceLocator,
                requiredTransactionInterceptor: transactionInterceptor
        )
    }

    @Unroll
    def "isValid #testCase"() {
        given:
        def hscID = (long) 1
        def providerSeqNum = (short) 2
        def infoRequestSeqNum = (short) 3
        def rp = new ReadProperties(FieldConstants.HSCID, FieldConstants.PROVIDERSEQNUM, FieldConstants.INFOREQUESTSEQNUM, FieldConstants.DEFAULTTEXTCRITERIAID)
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        rp.setKeyValue(FieldConstants.PROVIDERSEQNUM, providerSeqNum)
        rp.setKeyValue(FieldConstants.INFOREQUESTSEQNUM, infoRequestSeqNum)
        rp.fields = null

        when:
        boolean retVal = hscProviderInfoRequestCriteria.isValid(hscID, providerSeqNum, infoRequestSeqNum)

        then:
        1 * dao.isValid(rp) >> expectedVal
        0 * _
        retVal == expectedVal

        where:
        testCase | expectedVal
        "passes" | true
        "fails"  | false
    }

    def "Test to read HscProviderInfoRequestCriteriaVO"() {
        setup:
        def hscID = (long) 1
        def providerSeqNum = (short) 2
        def infoRequestSeqNum = (short) 3
        HscProviderInfoRequestCriteriaVO hscProviderInfoRequestCriteriaVO = new HscProviderInfoRequestCriteriaVO(hscID: hscID, providerSeqNum: providerSeqNum, infoRequestSeqNum: infoRequestSeqNum)
        def rp = new ReadProperties(FieldConstants.HSCID, FieldConstants.PROVIDERSEQNUM, FieldConstants.INFOREQUESTSEQNUM, FieldConstants.DEFAULTTEXTCRITERIAID)
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        rp.setKeyValue(FieldConstants.PROVIDERSEQNUM, providerSeqNum)
        rp.setKeyValue(FieldConstants.INFOREQUESTSEQNUM, infoRequestSeqNum)
        rp.fields = null

        when:
        hscProviderInfoRequestCriteria.read(hscID, providerSeqNum, infoRequestSeqNum)

        then:
        1 * dao.read(rp) >> hscProviderInfoRequestCriteriaVO
        0 * _
    }
}
