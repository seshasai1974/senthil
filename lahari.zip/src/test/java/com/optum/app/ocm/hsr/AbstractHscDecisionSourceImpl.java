package com.optum.app.ocm.hsr;


import com.uhg.app.common.constants.spclcare.TableConstants;
import com.optum.app.common.hsr.businesslogic.impl.AbstractHscDecisionSource;
import com.optum.app.common.hsr.data.HscServiceDecisionSourceVO;

/*
Dummy Impl class for  AbstractHscDecisionSource
 */
public class AbstractHscDecisionSourceImpl extends AbstractHscDecisionSource<HscServiceDecisionSourceVO> {

    protected AbstractHscDecisionSourceImpl(String tableName) {
        super(TableConstants.HSC_SRVC_DECN_SRC);
    }

}
