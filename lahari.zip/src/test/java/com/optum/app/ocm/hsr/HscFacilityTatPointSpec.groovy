package com.optum.app.ocm.hsr

import com.optum.rf.bl.spring.TransactionInterceptor
import com.optum.rf.core.locator.ServiceLocator
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.HscFacilityTatPoint
import com.optum.app.common.hsr.businesslogic.impl.HscFacilityTatPointImpl
import com.optum.app.common.hsr.data.HscFacilityTatPointVO
import spock.lang.Unroll

class HscFacilityTatPointSpec extends HsrReadLogicSpecification {

    HscFacilityTatPoint hscFacilityTatPoint

    DataAccessObject dao
    PersistenceHelper persistenceHelper
    ServiceLocator serviceLocator
    TransactionInterceptor transactionInterceptor

    def setup() {
        dao = Mock(DataAccessObject)
        persistenceHelper = Mock(PersistenceHelper)
        serviceLocator = Mock(ServiceLocator)
        transactionInterceptor = Mock(TransactionInterceptor)

        hscFacilityTatPoint = new HscFacilityTatPointImpl(
                requiredDao: dao,
                requiredPersistenceHelper: persistenceHelper,
                requiredServiceLocator: serviceLocator,
                requiredTransactionInterceptor: transactionInterceptor
        )
    }

    @Unroll
    def "isValid #testCase"() {
        given:
        def hscID = (long) 1
        def tatPointType = "2"
        def rp = new ReadProperties(FieldConstants.HSCID, FieldConstants.TATPOINTTYPE)
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        rp.setKeyValue(FieldConstants.TATPOINTTYPE, tatPointType)
        rp.fields = null

        when:
        boolean retVal = hscFacilityTatPoint.isValid(hscID, tatPointType)

        then:
        1 * dao.isValid(rp) >> expectedVal
        0 * _
        retVal == expectedVal

        where:
        testCase | expectedVal
        "passes" | true
        "fails"  | false
    }

    def "Test to read HscFacilityTatPointVO"() {
        setup:
        def hscID = (long) 1
        def tatPointType = "2"
        HscFacilityTatPointVO hscFacilityTatPointVO = new HscFacilityTatPointVO(hscID: hscID, tatPointType: tatPointType)
        def rp = new ReadProperties(FieldConstants.HSCID, FieldConstants.TATPOINTTYPE)
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        rp.setKeyValue(FieldConstants.TATPOINTTYPE, tatPointType)
        rp.fields = null

        when:
        hscFacilityTatPoint.read(hscID, tatPointType)

        then:
        1 * dao.read(rp) >> hscFacilityTatPointVO
        0 * _
    }
}
