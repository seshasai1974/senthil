package com.optum.app.ocm.hsr

import com.optum.app.ocm.common.activity.businesslogic.Activity
import com.optum.app.ocm.common.member.businesslogic.Member
import com.optum.app.ocm.common.member.businesslogic.MemberAddress
import com.optum.app.ocm.common.provider.ProviderClinicalAddress
import com.optum.app.ocm.ref.businesslogic.CustomerReference
import com.optum.rf.bl.factory.LogicTypeFactory
import com.optum.rf.common.messages.GlobalMessages
import com.optum.rf.common.settings.businesslogic.TemporarySystemSetting
import com.optum.rf.core.util.UhgCalendar
import com.optum.rf.dao.data.message.ConditionalErrorMessage
import com.optum.rf.dao.data.message.ErrorMessage
import com.optum.rf.dao.data.message.FieldMessage
import com.optum.rf.dao.exception.UhgRuntimeException
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.util.UhgCalendarUtilities
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.optum.app.common.constants.CommonReferenceConstants
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.Hsc
import com.optum.app.common.hsr.businesslogic.HscDiagnosis
import com.optum.app.common.hsr.businesslogic.HscFacilityDecision
import com.optum.app.common.hsr.businesslogic.HscFacilityHistory
import com.optum.app.common.hsr.businesslogic.HscFacilitySpecialSavings
import com.optum.app.common.hsr.businesslogic.HscMemberCoverage
import com.optum.app.common.hsr.businesslogic.HscProvider
import com.optum.app.common.hsr.businesslogic.HscProviderSearch
import com.optum.app.common.hsr.businesslogic.HscServiceLineTatHelper
import com.optum.app.common.hsr.businesslogic.UrJurisdiction
import com.optum.app.common.hsr.businesslogic.impl.HscFacilityImpl
import com.optum.app.common.hsr.constants.CssReferenceConstants
import com.optum.app.common.hsr.constants.HsrReferenceConstants
import com.optum.app.common.hsr.data.HscFacilityDecisionVO
import com.optum.app.common.hsr.data.HscFacilityTatSummaryVO
import com.optum.app.common.hsr.data.HscFacilityUrJurisdictionVO
import com.optum.app.common.hsr.data.HscFacilityVO
import com.optum.app.common.hsr.data.HscMemberCoverageVO
import com.optum.app.common.hsr.data.HscVO
import com.optum.app.common.hsr.messages.HscMessages
import com.optum.app.common.member.core.data.MemberAddressVO
import com.optum.app.ocm.constants.SecurityConstants
import spock.lang.Unroll

import java.sql.Date

class HscFacilityImplSpec extends HsrReadLogicSpecification {
    HscFacilityImpl hscFacility

    DataAccessObject dao
    PersistenceHelper persistenceHelper
    Hsc hsc
    TemporarySystemSetting temporarySystemSetting
    Activity activity
    HscDiagnosis hscDiagnosis
    HscFacilityDecision hscFacilityDecision
    HscFacilityHistory hscFacilityHistory
    HscFacilitySpecialSavings hscFacilitySpecialSavings
    HscMemberCoverage hscMemberCoverage
    HscProvider hscProvider
    HscProviderSearch hscProviderSearch
    HscServiceLineTatHelper hscServiceLineTatHelper
    Member member
    MemberAddress memberAddress
    ProviderClinicalAddress providerClinicalAddress
    UrJurisdiction urJurisdiction

    def setup() {
        hscFacility = new HscFacilityImpl()

        dao = Mock(DataAccessObject)
        persistenceHelper = Mock(PersistenceHelper)
        hsc = Mock(Hsc)
        temporarySystemSetting = Mock(TemporarySystemSetting)
        activity = Mock(Activity)
        hscDiagnosis = Mock(HscDiagnosis)
        hscFacilityDecision = Mock(HscFacilityDecision)
        hscFacilityHistory = Mock(HscFacilityHistory)
        hscFacilitySpecialSavings = Mock(HscFacilitySpecialSavings)
        hscMemberCoverage = Mock(HscMemberCoverage)
        hscProvider = Mock(HscProvider)
        hscProviderSearch = Mock(HscProviderSearch)
        hscServiceLineTatHelper = Mock(HscServiceLineTatHelper)
        member = Mock(Member)
        memberAddress = Mock(MemberAddress)
        providerClinicalAddress = Mock(ProviderClinicalAddress)
        urJurisdiction = Mock(UrJurisdiction)

        hscFacility.dao = dao
        hscFacility.setRequiredPersistenceHelper(persistenceHelper)
        hscFacility.hsc = hsc
        hscFacility.hscMemberCoverage = hscMemberCoverage
        hscFacility.memberAddress = memberAddress
        hscFacility.hscProvider = hscProvider
        hscFacility.urJurisdiction = urJurisdiction
        hscFacility.providerClinicalAddress = providerClinicalAddress
        LogicTypeFactory.putInstance(HscFacilityDecisionVO.class, hscFacilityDecision)
    }

    def "readByServiceReferenceNumber: with successful read"() {
        given:
        HscFacilityVO vo = new HscFacilityVO(hscID: 1L)

        when:
        HscFacilityVO result = hscFacility.readByServiceReferenceNumber("10")

        then:
        1 * dao.list(_) >> { QueryProperties qp ->
            assert qp.filterType == QueryProperties.FilterType.NEW_FILTER
            assert qp.getQueryFilter(FieldConstants.SERVICEREFERENCENUM).getFieldValue() == "10"
            return [vo]
        }
        result == vo
        0 * _
    }

    def "updateNotifyRetrospectiveIndicator: with updateSubset called successfully"(){
        given:
        HscFacilityVO vo = new HscFacilityVO(hscID:1)

        when:
        hscFacility.updateNotifyRetrospectiveIndicator(vo)

        then:
        1 * persistenceHelper.updateSubset(vo, [FieldConstants.NOTIFYRETROSPECTIVEIND] as String[], true)
        0 * _
    }

    def "validateDischargeLocationWarning: with error message"() {
        given:
        HscFacilityVO vo = new HscFacilityVO(hscID:1,
                actualDischargeDateTime: new UhgCalendar(2016, 1, 1))

        when:
        hscFacility.validateDischargeLocationWarning(vo)

        then:
        vo.messages.size() == 1
        vo.getMessage(FieldConstants.DISCHARGEDISPOSITIONTYPE).first().message.messageID == HscMessages.WRN_MSGID_DISCHARGE_LOCATION_REQUIRED.messageID
        vo.getMessage(FieldConstants.DISCHARGEDISPOSITIONTYPE).first().message.messageArgs.size() == 0
        0 * _
    }

    @Unroll
    def "beforeExecuteAdd: with and without IPCM type ID and decision VOs #ipcmTypeIDInput"(){
        given:
        HscFacilityVO vo = new HscFacilityVO(hscID: 1L, ipcmTypeID: ipcmTypeIDInput)

        when:
        hscFacility.beforeExecuteAdd(vo)

        then:
        vo.hscFacilityDecisionVOs == []
        vo.ipcmTypeID == ipcmTypeIDResult
        0 * _

        where:
        ipcmTypeIDInput                        | ipcmTypeIDResult
        null                                   | CssReferenceConstants.IPCM_TYPE_ID_NA
        CssReferenceConstants.IPCM_TYPE_ID_YES | CssReferenceConstants.IPCM_TYPE_ID_YES
    }

    def "updateIpcmTypeID: with successful update"() {
        given:
        List<HscFacilityDecisionVO> decisionVOs = [new HscFacilityDecisionVO()]
        HscFacilityVO vo = new HscFacilityVO(hscID: 1L,
                hscFacilityDecisionVOs: decisionVOs
        )

        when:
        hscFacility.updateIpcmTypeID(vo)

        then:
        vo.hscFacilityDecisionVOs == decisionVOs
        0 * _
    }

    def "updateIpcmTypeID: with no update"() {
        given:
        List<HscFacilityDecisionVO> decisionVOs = [new HscFacilityDecisionVO()]
        HscFacilityVO vo = new HscFacilityVO(hscID: 1L,
                hscFacilityDecisionVOs: decisionVOs
        )

        when:
        hscFacility.updateIpcmTypeID(vo)

        then:
        vo.hscFacilityDecisionVOs == decisionVOs
        0 * _
    }

    def "beforeAdd: inpatient with actual dates and no discharge dates" () {
        given:
        UhgCalendar actualAdmissionDate = new UhgCalendar(2016, 1, 1)
        UhgCalendar actualDischargeDate = new UhgCalendar(2016, 3, 3)
        HscFacilityVO vo = new HscFacilityVO(
                hscID: 1L,
                serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT,
                actualAdmissionDateTime: actualAdmissionDate.getSQLDate(),
                actualDischargeDateTime: actualDischargeDate.getSQLDate()
        )

        when:
        hscFacility.beforeAdd(vo)

        then:
        0 * _
    }

    def "beforeAdd: outpatient facility with expected admission date" () {
        given:
        UhgCalendar expectedAdmissionDate = new UhgCalendar(2016, 1, 1)
        HscFacilityVO vo = new HscFacilityVO(
                hscID: 1L,
                serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY,
                placeOfServiceCode: CommonReferenceConstants.PLACEOFSERVICE_OUTPATIENT_FACILITY,
                expectedAdmissionDate: expectedAdmissionDate.getSQLDate()
        )

        when:
        hscFacility.beforeAdd(vo)

        then:
        !vo.expectedDischargeDate
        0 * _
    }

    def "getLatestActualHospitalizationForMember: with actualDischargeDateTime not null"() {
        given:
        UhgCalendar old = new UhgCalendar(2016, 1, 1)
        UhgCalendar latest = new UhgCalendar(2016, 3, 3)
        HscFacilityVO vo1 = new HscFacilityVO(
                hscID: 1L,
                actualDischargeDateTime: latest
        )
        HscFacilityVO vo2 = new HscFacilityVO(
                hscID: 2L,
                actualDischargeDateTime: old
        )
        HscVO hscVO1 = new HscVO(
                hscID: 1L
        )
        HscVO hscVO2 = new HscVO(
                hscID: 2L
        )
        ReadProperties rp1 = new ReadProperties([FieldConstants.HSCID] as String[])
        rp1.setKeyValue(FieldConstants.HSCID, 1L)
        ReadProperties rp2 = new ReadProperties([FieldConstants.HSCID] as String[])
        rp2.setKeyValue(FieldConstants.HSCID, 2L)

        when:
        HscFacilityVO resultVO = hscFacility.getLatestActualHospitalizationForMember(100L)

        then:
        1 * dao.read(rp1) >> vo1
        1 * dao.read(rp2) >> vo2
        1 * hsc.listHscByMember(100L, false) >> [hscVO1, hscVO2]
        resultVO == vo1
        0 * _
    }

    def "getLatestActualHospitalizationForMember: with actualAdmissionDateTime not null" () {
        given:
        UhgCalendar old = new UhgCalendar(2016, 1, 1)
        UhgCalendar latest = new UhgCalendar(2016, 3, 3)
        HscFacilityVO vo1 = new HscFacilityVO(
                hscID: 1L,
                actualAdmissionDateTime: latest
        )
        HscFacilityVO vo2 = new HscFacilityVO(
                hscID: 2L,
                actualAdmissionDateTime: old
        )
        HscVO hscVO1 = new HscVO(
                hscID: 1L
        )
        HscVO hscVO2 = new HscVO(
                hscID: 2L
        )
        ReadProperties rp1 = new ReadProperties([FieldConstants.HSCID] as String[])
        rp1.setKeyValue(FieldConstants.HSCID, 1L)
        ReadProperties rp2 = new ReadProperties([FieldConstants.HSCID] as String[])
        rp2.setKeyValue(FieldConstants.HSCID, 2L)

        when:
        HscFacilityVO resultVO = hscFacility.getLatestActualHospitalizationForMember(100L)

        then:
        1 * dao.read(rp1) >> vo1
        1 * dao.read(rp2) >> vo2
        1 * hsc.listHscByMember(100L, false) >> [hscVO1, hscVO2]
        resultVO == vo1
        0 * _
    }

    def "getLatestActualHospitalizationForMember: with actualAdmissionDateTime and actualDischargeDateTime" () {
        given:
        UhgCalendar old = new UhgCalendar(2016, 1, 1)
        UhgCalendar latest = new UhgCalendar(2016, 3, 3)
        HscFacilityVO vo1 = new HscFacilityVO(
                hscID: 1L,
                actualAdmissionDateTime: latest,
                actualDischargeDateTime: old
        )
        HscFacilityVO vo2 = new HscFacilityVO(
                hscID: 2L,
                actualAdmissionDateTime: old,
                actualDischargeDateTime: latest
        )
        HscVO hscVO1 = new HscVO(
                hscID: 1L
        )
        HscVO hscVO2 = new HscVO(
                hscID: 2L
        )
        ReadProperties rp1 = new ReadProperties([FieldConstants.HSCID] as String[])
        rp1.setKeyValue(FieldConstants.HSCID, 1L)
        ReadProperties rp2 = new ReadProperties([FieldConstants.HSCID] as String[])
        rp2.setKeyValue(FieldConstants.HSCID, 2L)

        when:
        HscFacilityVO resultVO = hscFacility.getLatestActualHospitalizationForMember(100L)

        then:
        1 * dao.read(rp1) >> vo1
        1 * dao.read(rp2) >> vo2
        1 * hsc.listHscByMember(100L, false) >> [hscVO1, hscVO2]
        resultVO == vo2
        0 * _
    }

    def "calcMaxCoverageDateForSkilledNursingFacility: with remainingSNFDays and actual admission date" () {
        given:
        HscFacilityVO vo = new HscFacilityVO(
                hscID: 1L,
                remainingSNFDaysCount: 3 as short,
                actualAdmissionDateTime: new UhgCalendar(2016, 3, 3)
        )

        when:
        hscFacility.calcMaxCoverageDateForSkilledNursingFacility(vo)

        then:
        vo.maxCoverageDate == new UhgCalendar(2016, 3, 3).addDay(3).getSQLDate()
        0 * _
    }

    def "calcMaxCoverageDateForSkilledNursingFacility: with remainingSNFDays and expected admission date" () {
        given:
        HscFacilityVO vo = new HscFacilityVO(
                hscID: 1L,
                remainingSNFDaysCount: 3 as short,
                expectedAdmissionDate: new UhgCalendar(2016, 3, 3).getSQLDate()
        )

        when:
        hscFacility.calcMaxCoverageDateForSkilledNursingFacility(vo)

        then:
        vo.maxCoverageDate == new UhgCalendar(2016, 3, 3).addDay(3).getSQLDate()
        0 * _
    }

    def "calcMaxCoverageDateForSkilledNursingFacility: with 0 remainingSNFDays" () {
        given:
        HscFacilityVO vo = new HscFacilityVO()

        when:
        hscFacility.calcMaxCoverageDateForSkilledNursingFacility(vo)

        then:
        vo.maxCoverageDate == null
        0 * _
    }

    def "setNotificationRetrospectiveIndicator: inpatient with dates null" () {
        given:
        HscFacilityVO vo = new HscFacilityVO(
                hscID: 1L,
                serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT,
        )

        when:
        hscFacility.setNotificationRetrospectiveIndicator(vo)

        then:
        !vo.notifyRetrospectiveInd
        0 * _
    }

    def "setNotificationRetrospectiveIndicator: inpatient with service date before communication date" () {
        given:
        HscFacilityVO vo = new HscFacilityVO(
                hscID: 1L,
                serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT,
                dischargeNotifyDateTime: new UhgCalendar(2000, 3, 15),
                actualDischargeDateTime: new UhgCalendar(2000, 3, 14)
        )

        when:
        hscFacility.setNotificationRetrospectiveIndicator(vo)

        then:
        vo.notifyRetrospectiveInd
        0 * _
    }

    def "setNotificationRetrospectiveIndicator: outpatient with service date before communication date" () {
        given:
        HscFacilityVO vo = new HscFacilityVO(
                hscID: 1L,
                serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY,
                advanceNotifyDateTime: new UhgCalendar(2000, 3, 15),
                expectedDischargeDate: new UhgCalendar(2000, 3, 14).getSQLDate()
        )

        when:
        hscFacility.setNotificationRetrospectiveIndicator(vo)

        then:
        vo.notifyRetrospectiveInd
        0 * _
    }

    def "setNotificationRetrospectiveIndicator: outpatient with communication date null" () {
        given:
        HscFacilityVO vo = new HscFacilityVO(
                hscID: 1L,
                serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY,
                expectedDischargeDate: new UhgCalendar(2000, 3, 14).getSQLDate()
        )

        when:
        hscFacility.setNotificationRetrospectiveIndicator(vo)

        then:
        !vo.notifyRetrospectiveInd
        0 * _
    }

    def "setNotificationRetrospectiveIndicator: not an inpatient or an outpatient" () {
        given:
        HscFacilityVO vo = new HscFacilityVO(
                hscID: 1L,
                serviceSettingType: "10",
        )

        when:
        hscFacility.setNotificationRetrospectiveIndicator(vo)

        then:
        !vo.notifyRetrospectiveInd
        0 * _
    }

    def "update: Test valid update with Pos service detail change" () {
        given:
        HscFacilityVO vo = new HscFacilityVO(
                hscID: 1L,
                serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT,
                actualAdmissionDateTime: new UhgCalendar(2016, 1, 1),
                actualDischargeDateTime: new UhgCalendar(2016, 2, 1),
                dischargeDispositionType: "1",
                expectedAdmissionDate: new UhgCalendar(2016, 2, 3).getSQLDate(),
                expectedDischargeDate: new UhgCalendar(2016, 3, 3).getSQLDate(),

                placeOfServiceCode: CommonReferenceConstants.PLACEOFSERVICE_ACUTE_HOSPITAL,
                serviceDetailType: CommonReferenceConstants.SERVICEDETAILTYPE_MEDICAL,
                serviceDescriptionType: HsrReferenceConstants.SERVICEDESCRIPTIONTYPE_EMERGENCY,
                hasICMRReviewsOrNotes: true,
                hscStatusType: HsrReferenceConstants.HSCSTATUSTYPE_INCOMPLETE
        )
        HscFacilityVO readVO = new HscFacilityVO(
                hscID: 2L,
                serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT,
                actualAdmissionDateTime: new UhgCalendar(2016, 1, 1),
                actualDischargeDateTime: new UhgCalendar(2016, 2, 1),
                dischargeDispositionType: "1",
                expectedAdmissionDate: new UhgCalendar(2016, 2, 3).getSQLDate(),
                expectedDischargeDate: new UhgCalendar(2016, 3, 3).getSQLDate(),

                placeOfServiceCode: CommonReferenceConstants.PLACEOFSERVICE_HOSPICE,
                serviceDetailType: CommonReferenceConstants.SERVICEDETAILTYPE_HOSPICE
        )
        HscVO hscVO = new HscVO()

        when:
        hscFacility.update(vo)

        then:
        notThrown(UhgRuntimeException)
        !vo.errorMessagesExist()
        _ * hsc.read(_, _) >> hscVO
        _ * hsc.readUnhydrated(_, _) >> hscVO
        1 * persistenceHelper.update(vo)
        0 *_
    }

    def "update: Test valid update to remove Admission Date with hsc status open" () {
        given:
        HscFacilityVO vo = new HscFacilityVO(
                hscID: 1L,
                serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT,
                actualAdmissionDateTime: null,
                actualDischargeDateTime: null,
                dischargeDispositionType: "1",
                expectedAdmissionDate: new UhgCalendar(2016, 2, 3).getSQLDate(),
                expectedDischargeDate: new UhgCalendar(2016, 3, 3).getSQLDate(),

                placeOfServiceCode: CommonReferenceConstants.PLACEOFSERVICE_ACUTE_HOSPITAL,
                serviceDetailType: CommonReferenceConstants.SERVICEDETAILTYPE_PSYCHIATRIC,
                serviceDescriptionType: HsrReferenceConstants.SERVICEDESCRIPTIONTYPE_EMERGENCY
        )
        HscFacilityVO readVO = new HscFacilityVO(
                hscID: 2L,
                serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT,
                actualAdmissionDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone(),
                actualDischargeDateTime: null,
                dischargeDispositionType: "2",
                expectedAdmissionDate: new UhgCalendar(2016, 2, 3).getSQLDate(),
                expectedDischargeDate: new UhgCalendar(2016, 3, 3).getSQLDate()
        )

        HscVO hscVO = new HscVO(
                hscStatusType: HsrReferenceConstants.HSCSTATUSTYPE_OPEN,
                serviceSettingType: HsrReferenceConstants.SERVICESETTINGTYPE_INPATIENT,
                reviewPriorityType: HsrReferenceConstants.REVIEWPRIORITYTYPE_CONCURRENTROUTINE,
                specialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_PACIFICARE
        )

        when:
        hscFacility.update(vo)

        then:
        notThrown(UhgRuntimeException)
        !vo.errorMessagesExist()
        _ * hsc.read(_, _) >> hscVO
        _ * hsc.readUnhydrated(_, _) >> hscVO
        1 * persistenceHelper.update(vo)
        0 *_
    }

    def "update: Test valid update to remove Admission Date with hsc status incomplete" () {
        given:
        HscFacilityVO vo = new HscFacilityVO(
                hscID: 1L,
                serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT,
                actualAdmissionDateTime: null,
                actualDischargeDateTime: null,
                dischargeDispositionType: "1",
                expectedAdmissionDate: new UhgCalendar(2016, 2, 3).getSQLDate(),
                expectedDischargeDate: new UhgCalendar(2016, 3, 3).getSQLDate(),

                placeOfServiceCode: CommonReferenceConstants.PLACEOFSERVICE_ACUTE_HOSPITAL,
                serviceDetailType: CommonReferenceConstants.SERVICEDETAILTYPE_PSYCHIATRIC,
                serviceDescriptionType: HsrReferenceConstants.SERVICEDESCRIPTIONTYPE_EMERGENCY
        )
        HscFacilityVO readVO = new HscFacilityVO(
                hscID: 2L,
                serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT,
                actualAdmissionDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone(),
                actualDischargeDateTime: null,
                dischargeDispositionType: "2",
                expectedAdmissionDate: new UhgCalendar(2016, 2, 3).getSQLDate(),
                expectedDischargeDate: new UhgCalendar(2016, 3, 3).getSQLDate()
        )

        HscVO hscVO = new HscVO(
                hscStatusType: HsrReferenceConstants.HSCSTATUSTYPE_INCOMPLETE,
                reviewPriorityType: HsrReferenceConstants.REVIEWPRIORITYTYPE_CONCURRENTROUTINE
        )

        when:
        hscFacility.update(vo)

        then:
        notThrown(UhgRuntimeException)
        !vo.errorMessagesExist()
        _ * hsc.read(_, _) >> hscVO
        _ * hsc.readUnhydrated(_, _) >> hscVO
        1 * persistenceHelper.update(vo)
        0 *_
    }

    def "update: Test valid update" () {
        given:
        HscFacilityVO vo = new HscFacilityVO(
                hscID: 1L,
                placeOfServiceCode: CommonReferenceConstants.PLACEOFSERVICE_ACUTE_HOSPITAL,
                serviceDetailType: CommonReferenceConstants.SERVICEDETAILTYPE_PSYCHIATRIC,
                serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT,
                serviceDescriptionType: HsrReferenceConstants.SERVICEDESCRIPTIONTYPE_EMERGENCY,
                actualAdmissionDateTime: new UhgCalendar(2016, 1, 1),
                actualDischargeDateTime: new UhgCalendar(2016, 2, 1),
                dischargeDispositionType: "1",
                expectedAdmissionDate: new UhgCalendar(2016, 2, 3).getSQLDate(),
                expectedDischargeDate: new UhgCalendar(2016, 3, 3).getSQLDate()
        )
        HscFacilityVO readVO = new HscFacilityVO(
                hscID: 2L,
                placeOfServiceCode: CommonReferenceConstants.PLACEOFSERVICE_ACUTE_HOSPITAL,
                serviceDetailType: CommonReferenceConstants.SERVICEDETAILTYPE_PSYCHIATRIC,
                serviceDescriptionType: HsrReferenceConstants.SERVICEDESCRIPTIONTYPE_SCHEDULED,
                serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT,
                actualAdmissionDateTime: vo.getActualAdmissionDateTime(),
                actualDischargeDateTime: vo.getActualDischargeDateTime(),
                dischargeDispositionType: "2",
                expectedAdmissionDate: vo.getExpectedAdmissionDate(),
                expectedDischargeDate: vo.getExpectedDischargeDate()
        )

        HscVO hscVO = new HscVO(
                hscStatusType: HsrReferenceConstants.HSCSTATUSTYPE_OPEN,
                serviceSettingType: vo.getServiceSettingType()
        )

        when:
        hscFacility.update(vo)

        then:
        notThrown(UhgRuntimeException)
        !vo.errorMessagesExist()
        _ * hsc.read(_, _) >> hscVO
        _ * hsc.readUnhydrated(_, _) >> hscVO
        1 * persistenceHelper.update(vo)
        0 *_
    }

    def "delete: Test valid delete" () {
        given:
        HscFacilityVO vo = new HscFacilityVO(
                placeOfServiceCode: CommonReferenceConstants.PLACEOFSERVICE_ACUTE_HOSPITAL,
                serviceDetailType: CommonReferenceConstants.SERVICEDETAILTYPE_PSYCHIATRIC,
                serviceDescriptionType: HsrReferenceConstants.SERVICEDESCRIPTIONTYPE_EMERGENCY
        )

        when:
        hscFacility.delete(vo)

        then:
        notThrown(UhgRuntimeException)
        1 * persistenceHelper.delete(vo)
        !vo.errorMessagesExist()
        0 *_
    }

    def "delete: Test valid delete by Hsc ID" () {
        given:
        HscFacilityVO vo = new HscFacilityVO(
                placeOfServiceCode: CommonReferenceConstants.PLACEOFSERVICE_ACUTE_HOSPITAL,
                serviceDetailType: CommonReferenceConstants.SERVICEDETAILTYPE_PSYCHIATRIC,
                serviceDescriptionType: HsrReferenceConstants.SERVICEDESCRIPTIONTYPE_EMERGENCY
        )

        when:
        hscFacility.deleteFacilityForHSC(100L)

        then:
        notThrown(UhgRuntimeException)
        !vo.errorMessagesExist()
        0 *_
    }

    def "getTempHscFacilityVO: Test temporary vo creation with defaultServiceInformation true" () {
        given:
        HscFacilityVO vo = new HscFacilityVO(
                serviceDescriptionType: HsrReferenceConstants.SERVICEDESCRIPTIONTYPE_SCHEDULED,
                placeOfServiceCode: CommonReferenceConstants.PLACEOFSERVICE_HOME,
                serviceDetailType: CommonReferenceConstants.SERVICEDETAILTYPE_MEDICAL,
                hscFacilityLockType: HsrReferenceConstants.HSCSERVICELOCKTYPE_FULL_LOCK
        )
        ReadProperties rp = new ReadProperties([FieldConstants.HSCID] as String[])
        rp.setKeyValue(FieldConstants.HSCID, 1L)

        when:
        HscFacilityVO resultVo = hscFacility.getTempHscFacilityVO(1L, true)

        then:
        1 * dao.read(rp) >> vo
        resultVo.getServiceDescriptionType().equals(HsrReferenceConstants.SERVICEDESCRIPTIONTYPE_SCHEDULED)
        resultVo.getPlaceOfServiceCode().equals(CommonReferenceConstants.PLACEOFSERVICE_HOME)
        resultVo.getServiceDetailType().equals(CommonReferenceConstants.SERVICEDETAILTYPE_MEDICAL)
        resultVo.hscFacilityLockType == HsrReferenceConstants.HSCSERVICELOCKTYPE_FULL_LOCK
        0 * _
    }

    def "getTempHscFacilityVO: Test temporary vo creation with defaultServiceInformation false" () {
        given:
        HscFacilityVO vo = new HscFacilityVO(
                serviceDescriptionType: HsrReferenceConstants.SERVICEDESCRIPTIONTYPE_SCHEDULED,
                placeOfServiceCode: CommonReferenceConstants.PLACEOFSERVICE_HOME,
                serviceDetailType: CommonReferenceConstants.SERVICEDETAILTYPE_MEDICAL,
                goalLOSDayCount: 11 as short,
                notifyLateIndicator: true
        )
        ReadProperties rp = new ReadProperties([FieldConstants.HSCID] as String[])
        rp.setKeyValue(FieldConstants.HSCID, 1L)

        when:
        HscFacilityVO resultVo = hscFacility.getTempHscFacilityVO(1L, false)

        then:
        1 * dao.read(rp) >> vo
        resultVo.getServiceDescriptionType() == null
        resultVo.getPlaceOfServiceCode() == null
        resultVo.getServiceDetailType() == null
        resultVo.getGoalLOSDayCount() == 11
        resultVo.isNotifyLateIndicator()
        0 * _
    }

    @Unroll()
    def "setFacilityLineLock: Test Facility Line Lock is not modified TestCase=#testCaseNumber" () {
        given:
        HscFacilityVO vo = new HscFacilityVO(hscID: 1L,
                serviceDescriptionType: HsrReferenceConstants.SERVICEDESCRIPTIONTYPE_SCHEDULED,
                placeOfServiceCode: CommonReferenceConstants.PLACEOFSERVICE_HOME,
                serviceDetailType: CommonReferenceConstants.SERVICEDETAILTYPE_MEDICAL,
                hscFacilityLockType: currentLockType
        )

        when:
        hscFacility.setFacilityLineLock(1L, lockType)

        then:
        1 * dao.read(_) >> { ReadProperties rp ->
            assert rp.getKeyValue(FieldConstants.HSCID) == vo.getHscID()
            return vo
        }
        _ * hsc.readUnhydrated(_, _)
        vo.hscFacilityLockType == currentLockType
        !vo.errorMessagesExist()
        0 * _

        where:
        testCaseNumber | lockType                                              | currentLockType
        1              | HsrReferenceConstants.HSCSERVICELOCKTYPE_NO_LOCK      | HsrReferenceConstants.HSCSERVICELOCKTYPE_FULL_LOCK
        2              | HsrReferenceConstants.HSCSERVICELOCKTYPE_FULL_LOCK    | HsrReferenceConstants.HSCSERVICELOCKTYPE_FULL_LOCK
        3              | HsrReferenceConstants.HSCSERVICELOCKTYPE_PARTIAL_LOCK | HsrReferenceConstants.HSCSERVICELOCKTYPE_FULL_LOCK
        4              | HsrReferenceConstants.HSCSERVICELOCKTYPE_NO_LOCK      | HsrReferenceConstants.HSCSERVICELOCKTYPE_PARTIAL_LOCK
        5              | HsrReferenceConstants.HSCSERVICELOCKTYPE_PARTIAL_LOCK | HsrReferenceConstants.HSCSERVICELOCKTYPE_PARTIAL_LOCK
        6              | ""                                                    | ""
    }

    @Unroll()
    def "setFacilityLineLock: Test Facility Line Lock is modified Testcase #testCaseNumber" () {
        given:
        HscFacilityVO vo = new HscFacilityVO(hscID: 1L,
                serviceDescriptionType: HsrReferenceConstants.SERVICEDESCRIPTIONTYPE_SCHEDULED,
                placeOfServiceCode: CommonReferenceConstants.PLACEOFSERVICE_HOME,
                serviceDetailType: CommonReferenceConstants.SERVICEDETAILTYPE_MEDICAL,
                hscFacilityLockType: currentLockType,
                serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT,
                actualAdmissionDateTime: new UhgCalendar(UhgCalendarUtilities.getYesterdaysDate()),
                actualDischargeDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone(),
                dischargeDispositionType: "1",
                expectedAdmissionDate: UhgCalendarUtilities.getYesterdaysDate(),
                expectedDischargeDate: UhgCalendarUtilities.getTodaysDate()
        )

        HscVO hscVO = new HscVO(
                hscStatusType: HsrReferenceConstants.HSCSTATUSTYPE_OPEN,
                serviceSettingType: vo.getServiceSettingType()
        )

        when:
        hscFacility.setFacilityLineLock(1L, lockType)

        then:
        _ * hsc.read(vo.getHscID(), []) >> hscVO
        1 * dao.read(_) >> { ReadProperties rp ->
            assert rp.getKeyValue(FieldConstants.HSCID) == vo.getHscID()
            return vo
        }
        vo.hscFacilityLockType == lockType
        !vo.errorMessagesExist()
        1 * persistenceHelper.update(vo)
        _ * hsc.readUnhydrated(_, _)
        0 * _

        where:
        testCaseNumber | lockType                                           | currentLockType
        1              | ""                                                 | HsrReferenceConstants.HSCSERVICELOCKTYPE_NO_LOCK
        2              | HsrReferenceConstants.HSCSERVICELOCKTYPE_FULL_LOCK | HsrReferenceConstants.HSCSERVICELOCKTYPE_PARTIAL_LOCK
    }

    def "validateDischargeLocation: without Discharge Disposition Type"() {
        given:
        HscFacilityVO vo = new HscFacilityVO(hscID: 1L,
                serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT,
                actualDischargeDateTime: new UhgCalendar(2016, 2, 1)
        )

        when:
        hscFacility.validateDischargeLocation(vo)

        then:
        vo.messages.size() == 1
        ConditionalErrorMessage message = vo.getMessage(FieldConstants.DISCHARGEDISPOSITIONTYPE).first().message
        message.conditionalField == FieldConstants.ACTUALDISCHARGEDATETIME
        message.conditionState == GlobalMessages.POPULATED
        0 * _
    }

    @Unroll
    def "validateDischargeLocation: no error message TestCase=#testCaseNumber"() {
        given:
        HscFacilityVO vo = new HscFacilityVO(hscID: 1L,
                serviceSettingType: serviceSettingType,
                dischargeDispositionType: dischargeDispositionType,
                changeUserID: changeUserID,
                actualDischargeDateTime: actualDischargeTime
        )

        when:
        hscFacility.validateDischargeLocation(vo)

        then:
        !vo.errorMessagesExist()
        0 * _

        where:
        testCaseNumber | changeUserID                       | actualDischargeTime         | dischargeDispositionType | serviceSettingType
        1              | "SYSTEM"                           | new UhgCalendar(2016, 2, 1) | "1" | CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT
        2              | "SYSTEM"                           | null                        | ""  | CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT
        3              | "SYSTEM"                           | new UhgCalendar(2016, 2, 1) | ""  | CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT
        4              | SecurityConstants.SYSTEM_DATA_PROP | new UhgCalendar(2016, 2, 1) | ""  | CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT
    }

    def "validateRequiredActualDates: with no actual dates"() {
        given:
        HscFacilityVO vo = new HscFacilityVO(hscID: 1L)

        when:
        hscFacility.validateRequiredActualDates(vo)

        then:
        vo.getMessages().size() == 2
        vo.getMessage(FieldConstants.ACTUALADMISSIONDATETIME).first().message.messageID == GlobalMessages.ERR_REQUIRED_VALUE.messageID
        vo.getMessage(FieldConstants.ACTUALADMISSIONDATETIME).first().message.messageArgs.size() == 0
        vo.getMessage(FieldConstants.ACTUALDISCHARGEDATETIME).first().message.messageID == GlobalMessages.ERR_REQUIRED_VALUE.messageID
        vo.getMessage(FieldConstants.ACTUALDISCHARGEDATETIME).first().message.messageArgs.size() == 0
        0 * _
    }

    def "validateRequiredActualDates: with actual dates"() {
        given:
        HscFacilityVO vo = new HscFacilityVO(hscID: 1L,
                actualAdmissionDateTime: new UhgCalendar(2016, 1, 1),
                actualDischargeDateTime: new UhgCalendar(2016, 2, 1))

        when:
        hscFacility.validateRequiredActualDates(vo)

        then:
        !vo.errorMessagesExist()
        0 * _
    }

    def "validateserviceDates: inpatient with Admission dates null"() {
        given:
        HscFacilityVO vo = new HscFacilityVO(hscID: 1L,
                serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT)

        ReadProperties rp = new ReadProperties([FieldConstants.HSCID] as String[])
        rp.setKeyValue(FieldConstants.HSCID, 1L)

        when:
        hscFacility.validateServiceDates(vo)

        then:
        1 * dao.read(rp)
        vo.getMessages().size() == 2
        vo.getMessage(FieldConstants.EXPECTEDADMISSIONDATE).first().message.messageID == GlobalMessages.ERR_REQUIRED_VALUE.messageID
        vo.getMessage(FieldConstants.EXPECTEDADMISSIONDATE).first().message.messageArgs.size() == 0
        vo.getMessage(FieldConstants.EXPECTEDDISCHARGEDATE).first().message.messageID == GlobalMessages.ERR_REQUIRED_VALUE.messageID
        vo.getMessage(FieldConstants.EXPECTEDDISCHARGEDATE).first().message.messageArgs.size() == 0
        0 * _
    }

    def "validateserviceDates: Test Validation of service dates for outpatient and dates null"() {
        given:
        HscFacilityVO vo = new HscFacilityVO(hscID: 1L,
                serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT)

        ReadProperties rp = new ReadProperties([FieldConstants.HSCID] as String[])
        rp.setKeyValue(FieldConstants.HSCID, 1L)

        when:
        hscFacility.validateServiceDates(vo)

        then:
        1 * dao.read(rp)
        vo.getMessages().size() == 2
        vo.getMessage(FieldConstants.SERVICESTARTDATE).first().message.messageID == GlobalMessages.ERR_REQUIRED_VALUE.messageID
        vo.getMessage(FieldConstants.SERVICESTARTDATE).first().message.messageArgs.size() == 0
        vo.getMessage(FieldConstants.SERVICEENDDATE).first().message.messageID == GlobalMessages.ERR_REQUIRED_VALUE.messageID
        vo.getMessage(FieldConstants.SERVICEENDDATE).first().message.messageArgs.size() == 0
        0 * _
    }

    def "validateserviceDates: Outpatient and expected admission date before expected discharge date"() {
        given:
        HscFacilityVO vo = new HscFacilityVO(hscID: 1L,
                serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT,
                expectedAdmissionDate: UhgCalendarUtilities.getTodaysDate(),
                expectedDischargeDate: UhgCalendarUtilities.getYesterdaysDate()
        )

        ReadProperties rp = new ReadProperties([FieldConstants.HSCID] as String[])
        rp.setKeyValue(FieldConstants.HSCID, 1L)

        when:
        hscFacility.validateServiceDates(vo)

        then:
        1 * dao.read(rp)
        vo.getMessages().size() == 1
        vo.getMessage(FieldConstants.SERVICEENDDATE).first().message.messageID == HscMessages.ERR_HSC_SERVICE_END_DATE_B4_START.messageID
        vo.getMessage(FieldConstants.SERVICEENDDATE).first().message.messageArgs.size() == 0
        0 * _
    }

    def "validateserviceDates: Inpatient with complete future admission date before future complete discharge date and with improper expected dates"() {
        given:
        HscFacilityVO vo = new HscFacilityVO(hscID: 1L,
                serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT,
                actualAdmissionDateTime: new UhgCalendar(UhgCalendarUtilities.getSqlDateWithDayOffset(3)),
                actualDischargeDateTime: new UhgCalendar(UhgCalendarUtilities.getSqlDateWithDayOffset(2)),
                expectedAdmissionDate: UhgCalendarUtilities.getTodaysDate(),
                expectedDischargeDate: UhgCalendarUtilities.getYesterdaysDate())
        ReadProperties rp = new ReadProperties([FieldConstants.HSCID] as String[])
        rp.setKeyValue(FieldConstants.HSCID, 1L)

        when:
        hscFacility.validateServiceDates(vo)

        then:
        1 * dao.read(rp)
        vo.getMessages().size() == 3
        vo.getMessages().get(FieldConstants.ACTUALDISCHARGEDATETIME).size() == 2
        vo.getMessage(FieldConstants.ACTUALDISCHARGEDATETIME).first().message.messageID == HscMessages.ERR_HSC_ACTUAL_DISCHARGE_DATE_B4_ADMISSION.messageID
        vo.getMessage(FieldConstants.ACTUALDISCHARGEDATETIME).first().message.messageArgs.size() == 0
        vo.getMessage(FieldConstants.ACTUALDISCHARGEDATETIME).get(1).message.messageID == HscMessages.ERR_HSC_ACTUAL_DISCHARGE_DATE_FUTURE.messageID
        vo.getMessage(FieldConstants.ACTUALDISCHARGEDATETIME).get(1).message.messageArgs.size() == 0
        vo.getMessages().get(FieldConstants.ACTUALADMISSIONDATETIME).size() == 1
        vo.getMessage(FieldConstants.ACTUALADMISSIONDATETIME).first().message.messageID == HscMessages.ERR_HSC_ACTUAL_ADMISSION_DATE_FUTURE.messageID
        vo.getMessage(FieldConstants.ACTUALADMISSIONDATETIME).first().message.messageArgs.size() == 0
        vo.getMessages().get(FieldConstants.EXPECTEDDISCHARGEDATE).size() == 1
        vo.getMessage(FieldConstants.EXPECTEDDISCHARGEDATE).first().message.messageID == HscMessages.ERR_HSC_EXPECTED_DISCHARGE_DATE_B4_ADMISSION.messageID
        vo.getMessage(FieldConstants.EXPECTEDDISCHARGEDATE).first().message.messageArgs.size() == 0
        0 * _
    }

    def "validatePartialActualDates: with partial dates"() {
        given:
        UhgCalendar actualAdmissionDateTime = new UhgCalendar(2016, 1, 1)
        actualAdmissionDateTime.setHasTimestampTimeComponent(false)
        UhgCalendar actualDischargeDateTime = new UhgCalendar(2016, 2, 1)
        actualDischargeDateTime.setHasTimestampTimeComponent(false)
        HscFacilityVO vo = new HscFacilityVO(
                actualAdmissionDateTime: actualAdmissionDateTime,
                actualDischargeDateTime: actualDischargeDateTime
        )

        when:
        hscFacility.validatePartialActualDates(vo)

        then:
        vo.errorMessagesExist()
        vo.getMessages().size() == 2
        vo.getMessage(FieldConstants.ACTUALADMISSIONDATETIME).first().message.messageID == GlobalMessages.ERR_REQUIRED_VALUE.messageID
        vo.getMessage(FieldConstants.ACTUALADMISSIONDATETIME).first().message.messageArgs.size() == 0
        vo.getMessage(FieldConstants.ACTUALDISCHARGEDATETIME).first().message.messageID == GlobalMessages.ERR_REQUIRED_VALUE.messageID
        vo.getMessage(FieldConstants.ACTUALDISCHARGEDATETIME).first().message.messageArgs.size() == 0
        0 * _
    }

    def "validatePartialActualDates: with Discharge Date entered without entering the Admission Date"() {
        given:
        UhgCalendar actualDischargeDateTime = new UhgCalendar(2016, 2, 1)
        HscFacilityVO vo = new HscFacilityVO(
                actualAdmissionDateTime: null,
                actualDischargeDateTime: actualDischargeDateTime
        )

        when:
        hscFacility.validatePartialActualDates(vo)

        then:
        vo.errorMessagesExist()
        vo.getMessages().size() == 1
        vo.getMessage(FieldConstants.ACTUALADMISSIONDATETIME).first().message.messageID == GlobalMessages.ERR_REQUIRED_VALUE.messageID
        vo.getMessage(FieldConstants.ACTUALADMISSIONDATETIME).first().message.messageArgs.size() == 0
        0 * _
    }

    def "validateNotificationDates: with user entered notify dates null and existing bean notify dates not null"() {
        given:
        HscFacilityVO vo = new HscFacilityVO()

        HscFacilityVO readVO = new HscFacilityVO(advanceNotifyDateTime: new UhgCalendar(2016, 3, 3),
                admissionNotifyDateTime: new UhgCalendar(2016, 2, 3),
                dischargeNotifyDateTime: new UhgCalendar(2016, 4, 3)
        )

        when:
        hscFacility.validateNotificationDates(vo)

        then:
        1 * dao.read(_) >> { ReadProperties rp ->
            assert rp.getKeyValue(FieldConstants.HSCID) == vo.getHscID()
            return readVO
        }
        vo.errorMessagesExist()
        vo.getMessages().size() == 2
        vo.getMessage(FieldConstants.ADMISSIONNOTIFYDATETIME).first().message.messageID == GlobalMessages.ERR_REQUIRED_VALUE.messageID
        vo.getMessage(FieldConstants.ADMISSIONNOTIFYDATETIME).first().message.messageArgs.size() == 0
        vo.getMessage(FieldConstants.DISCHARGENOTIFYDATETIME).first().message.messageID == GlobalMessages.ERR_REQUIRED_VALUE.messageID
        vo.getMessage(FieldConstants.DISCHARGENOTIFYDATETIME).first().message.messageArgs.size() == 0
        vo.advanceNotifyDateTime == new UhgCalendar(2016, 3, 3)
        vo.admissionNotifyDateTime == new UhgCalendar(2016, 2, 3)
        vo.dischargeNotifyDateTime == new UhgCalendar(2016, 4, 3)
        0 * _
    }

    def "validateNotificationDates: with user entered notify dates partial and existing bean notify dates not null"() {
        given:
        UhgCalendar advanceNotifyDateTime = new UhgCalendar(2016, 1, 1)
        advanceNotifyDateTime.setHasTimestampTimeComponent(false)
        UhgCalendar admissionNotifyDateTime = new UhgCalendar(2016, 2, 1)
        admissionNotifyDateTime.setHasTimestampTimeComponent(false)
        UhgCalendar dischargeNotifyDateTime = new UhgCalendar(2016, 3, 1)
        dischargeNotifyDateTime.setHasTimestampTimeComponent(false)
        HscFacilityVO vo = new HscFacilityVO(advanceNotifyDateTime: advanceNotifyDateTime,
                admissionNotifyDateTime: admissionNotifyDateTime,
                dischargeNotifyDateTime: dischargeNotifyDateTime)

        HscFacilityVO readVO = new HscFacilityVO(advanceNotifyDateTime: new UhgCalendar(2016, 1, 3),
                admissionNotifyDateTime: new UhgCalendar(2016, 2, 3),
                dischargeNotifyDateTime: new UhgCalendar(2016, 3, 3)
        )

        when:
        hscFacility.validateNotificationDates(vo)

        then:
        1 * dao.read(_) >> { ReadProperties rp ->
            assert rp.getKeyValue(FieldConstants.HSCID) == vo.getHscID()
            return readVO
        }
        vo.errorMessagesExist()
        vo.getMessages().size() == 2
        vo.getMessage(FieldConstants.ADMISSIONNOTIFYDATETIME).first().message.messageID == GlobalMessages.ERR_REQUIRED_VALUE.messageID
        vo.getMessage(FieldConstants.ADMISSIONNOTIFYDATETIME).first().message.messageArgs.size() == 0
        vo.getMessage(FieldConstants.DISCHARGENOTIFYDATETIME).first().message.messageID == GlobalMessages.ERR_REQUIRED_VALUE.messageID
        vo.getMessage(FieldConstants.DISCHARGENOTIFYDATETIME).first().message.messageArgs.size() == 0
        vo.advanceNotifyDateTime == new UhgCalendar(2016, 1, 3)
        vo.admissionNotifyDateTime == new UhgCalendar(2016, 2, 3)
        vo.dischargeNotifyDateTime == new UhgCalendar(2016, 3, 3)
        0 * _
    }

    def "validateNotificationDates: with user entered notify dates valid and existing bean notify dates not null"() {
        given:
        HscFacilityVO vo = new HscFacilityVO(advanceNotifyDateTime: new UhgCalendar(2016, 1, 1),
                admissionNotifyDateTime: new UhgCalendar(2016, 2, 1),
                dischargeNotifyDateTime: new UhgCalendar(2016, 3, 1)
        )

        HscFacilityVO readVO = new HscFacilityVO(advanceNotifyDateTime: new UhgCalendar(2016, 1, 3),
                admissionNotifyDateTime: new UhgCalendar(2016, 2, 3),
                dischargeNotifyDateTime: new UhgCalendar(2016, 3, 3)
        )

        when:
        hscFacility.validateNotificationDates(vo)

        then:
        1 * dao.read(_) >> { ReadProperties rp ->
            assert rp.getKeyValue(FieldConstants.HSCID) == vo.getHscID()
            return readVO
        }
        !vo.errorMessagesExist()
        vo.advanceNotifyDateTime == new UhgCalendar(2016, 1, 1)
        vo.admissionNotifyDateTime == new UhgCalendar(2016, 2, 1)
        vo.dischargeNotifyDateTime == new UhgCalendar(2016, 3, 1)
        0 * _
    }

    def "isValid: with true"() {
        given:
        HscFacilityVO vo = new HscFacilityVO(hscID: 1L)

        when:
        boolean result = hscFacility.isValid(1)

        then:
        result
        1 * dao.isValid(_) >> { ReadProperties rp ->
            assert rp.getKeyValue(FieldConstants.HSCID) == vo.getHscID()
            return true
        }
        0 * _
    }

    @Unroll
    def "setHscManagedInHsr: with successful update Testcase=#testCaseNumber"() {
        given:
        HscFacilityVO vo = new HscFacilityVO(
                hscID: 1L,
                placeOfServiceCode: CommonReferenceConstants.PLACEOFSERVICE_ACUTE_HOSPITAL,
                serviceDetailType: CommonReferenceConstants.SERVICEDETAILTYPE_PSYCHIATRIC,
                serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT,
                serviceDescriptionType: HsrReferenceConstants.SERVICEDESCRIPTIONTYPE_EMERGENCY,
                actualAdmissionDateTime: new UhgCalendar(2016, 1, 1),
                actualDischargeDateTime: new UhgCalendar(2016, 2, 1),
                dischargeDispositionType: "1",
                expectedAdmissionDate: new UhgCalendar(2016, 2, 3).getSQLDate(),
                expectedDischargeDate: new UhgCalendar(2016, 3, 3).getSQLDate(),
                icmSystemType: icmSystemType
        )
        HscVO hscVO = new HscVO(
                hscStatusType: HsrReferenceConstants.HSCSTATUSTYPE_OPEN,
                serviceSettingType: vo.getServiceSettingType()
        )

        when:
        hscFacility.setHscManagedInHsr(1)

        then:
        _ * hsc.readUnhydrated(_, _) >> hscVO
        _ * hsc.read(_, _) >> hscVO
        notThrown(UhgRuntimeException)
        !vo.errorMessagesExist()
        1 * dao.read(_) >> { ReadProperties rp ->
            assert rp.getKeyValue(FieldConstants.HSCID) == vo.getHscID()
            return vo
        }
        1 * persistenceHelper.update(vo)
        vo.icmSystemType == HsrReferenceConstants.ICMSYSTEMTYPE_MANAGED_IN_HSR
        0 * _

        where:
        testCaseNumber | icmSystemType
        1              | ""
        2              | HsrReferenceConstants.ICMSYSTEMTYPE_NOMINATED_TO_ICM
    }

    def "setHscManagedInHsr: with execute update false"() {
        given:
        HscFacilityVO vo = new HscFacilityVO(hscID: 1L)

        when:
        hscFacility.setHscManagedInHsr(vo, false)

        then:
        vo.icmSystemType == HsrReferenceConstants.ICMSYSTEMTYPE_MANAGED_IN_HSR
        0 * _
    }

    def "getHsc: successful read"() {
        given:
        HscFacilityVO vo = new HscFacilityVO(hscID: 1L)
        HscVO hscVO = new HscVO(hscID: 1L)

        when:
        HscVO result = hscFacility.getHsc(vo)

        then:
        1 * hsc.read(1,[]) >> hscVO
        result == hscVO
        0 * _
    }

    def "getPotentialUrJurisdictions: successful read"() {
        given:
        HscFacilityVO vo = new HscFacilityVO(hscID: 1L)
        Collection<HscFacilityUrJurisdictionVO> returnList = [new HscFacilityUrJurisdictionVO()]

        when:
        Collection<HscFacilityUrJurisdictionVO> result = hscFacility.getPotentialUrJurisdictions(vo)

        then:
        _ * hsc.readUnhydrated(_, _)
        0 * _
    }

    def "createUrJurisdictionAssignmentVO: successful read"() {
        when:
        HscFacilityUrJurisdictionVO result = hscFacility.createUrJurisdictionAssignmentVO()

        then:
        result == new HscFacilityUrJurisdictionVO()
        0 * _
    }

    @Unroll
    def "getWrittenNoticeOverrideDueDate: with and without override Written Notice Due Date"() {
        when:
        UhgCalendar result = hscFacility.getWrittenNoticeOverrideDueDate(1)

        then:
        1 * dao.read(_) >> { ReadProperties rp ->
            assert rp.getKeyValue(FieldConstants.HSCID) == 1
            assert rp.fields.length == 1
            assert rp.fields.first() == FieldConstants.OVERRIDEWRITTENNOTICEDUEDTTM
            return vo
        }
        result == returnValue
        0 * _

        where:
        testCaseNumber | vo                                                                                      | returnValue
        1              | new HscFacilityVO(hscID: 1L, overrideWrittenNoticeDueDttm: new UhgCalendar(2016, 1, 1)) | new UhgCalendar(2016, 1, 1)
        2              | null                                                                                    | null
    }

    @Unroll
    def "getBestDateForNetworkStatus: with different Admission Dates"() {
        when:
        Date result = hscFacility.getBestDateForNetworkStatus(1)

        then:
        1 * dao.read(_) >> { ReadProperties rp ->
            assert rp.getKeyValue(FieldConstants.HSCID) == 1
            return vo
        }
        result == returnValue
        0 * _

        where:
        testCaseNumber | vo                                                                                            | returnValue
        1              | new HscFacilityVO(hscID: 1L, actualAdmissionDateTime: new UhgCalendar(2016, 1, 1))            | new UhgCalendar(2016, 1, 1).getSQLDate()
        2              | new HscFacilityVO(hscID: 1L, expectedAdmissionDate: new UhgCalendar(2016, 2, 2).getSQLDate()) | new UhgCalendar(2016, 2, 2).getSQLDate()
        3              | null                                                                                          | UhgCalendarUtilities.getTodaysDate()
    }

    @Unroll
    def "isReadmissionWithin30DaysOfDischargeDate: with valid date found true and false Testcase=#testCaseNumber"() {
        given:
        HscFacilityVO vo = new HscFacilityVO(hscID: 1L,
                actualAdmissionDateTime: actualAdmissionDateTime)
        List<HscVO> hscVOs = [new HscVO(hscID: 1L), new HscVO(hscID: 2L)]
        ReadProperties rp1 = new ReadProperties([FieldConstants.HSCID] as String[])
        rp1.setKeyValue(FieldConstants.HSCID, 1L)
        ReadProperties rp2 = new ReadProperties([FieldConstants.HSCID] as String[])
        rp2.setKeyValue(FieldConstants.HSCID, 2L)

        when:
        boolean result = hscFacility.isReadmissionWithin30DaysOfDischargeDate(CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT, 100, vo)

        then:
        1 * hsc.listHscByMemberHscStatusServiceSettingType(CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT, 100,
                HsrReferenceConstants.HSCSTATUSTYPE_OPEN, HsrReferenceConstants.HSCSTATUSTYPE_AWAITING_ADMISSION, HsrReferenceConstants.HSCSTATUSTYPE_CLOSED) >> hscVOs
        1 * dao.read(rp1) >> new HscFacilityVO(hscID: 1)
        1 * dao.read(rp2) >> new HscFacilityVO(hscID: 2, actualDischargeDateTime: actualDischargeDateTime)
        result == resultValue
        0 * _

        where:
        testCaseNumber | actualAdmissionDateTime     | actualDischargeDateTime     | resultValue
        1              | new UhgCalendar(2016, 1, 5) | new UhgCalendar(2016, 1, 1) | true
        2              | new UhgCalendar(2016, 3, 3) | new UhgCalendar(2016, 1, 1) | false
    }

    @Unroll
    def "isReadmissionWithin30DaysOfDischargeDateIndicator: with true and false Testcase=#testCaseNumber"() {
        given:
        HscFacilityVO vo = new HscFacilityVO(hscID: 1L,
                actualAdmissionDateTime: actualAdmissionDateTime,
                placeOfServiceCode: CommonReferenceConstants.PLACEOFSERVICE_ACUTE_HOSPITAL)
        List<HscVO> hscVOs = [new HscVO(hscID: 1L), new HscVO(hscID: 2L)]
        ReadProperties rp1 = new ReadProperties([FieldConstants.HSCID] as String[])
        rp1.setKeyValue(FieldConstants.HSCID, 1L)
        ReadProperties rp2 = new ReadProperties([FieldConstants.HSCID] as String[])
        rp2.setKeyValue(FieldConstants.HSCID, 2L)

        when:
        boolean result = hscFacility.isReadmissionWithin30DaysOfDischargeDateIndicator(CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT, 100, vo)

        then:
        1 * hsc.listHscByMemberHscStatusServiceSettingType(CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT, 100,
                HsrReferenceConstants.HSCSTATUSTYPE_OPEN, HsrReferenceConstants.HSCSTATUSTYPE_CLOSED, HsrReferenceConstants.HSCSTATUSTYPE_AWAITING_ADMISSION) >> hscVOs
        1 * dao.read(rp1) >> new HscFacilityVO(hscID: 1)
        1 * dao.read(rp2) >> new HscFacilityVO(hscID: 2, actualDischargeDateTime: actualDischargeDateTime, placeOfServiceCode: placeOfServiceCode)
        result == resultValue
        0 * _

        where:
        testCaseNumber | actualAdmissionDateTime     | actualDischargeDateTime     | placeOfServiceCode                                   | resultValue
        1              | new UhgCalendar(2016, 1, 5) | new UhgCalendar(2016, 1, 1) | HsrReferenceConstants.PLACEOFSERVICE_ACUTE_HOSPITAL  | true
        2              | new UhgCalendar(2016, 1, 5) | new UhgCalendar(2016, 1, 1) | HsrReferenceConstants.PLACEOFSERVICE_INPATIENT_REHAB | true
        3              | new UhgCalendar(2016, 1, 5) | new UhgCalendar(2016, 1, 1) | HsrReferenceConstants.PLACEOFSERVICE_HOSPICE         | true
        4              | new UhgCalendar(2016, 1, 5) | new UhgCalendar(2016, 1, 1) | HsrReferenceConstants.PLACEOFSERVICE_NURSING         | true
        5              | new UhgCalendar(2016, 1, 5) | new UhgCalendar(2016, 1, 1) | HsrReferenceConstants.PLACEOFSERVICE_OUTPATIENT      | false
        6              | new UhgCalendar(2016, 3, 3) | new UhgCalendar(2016, 1, 1) | HsrReferenceConstants.PLACEOFSERVICE_INPATIENT_REHAB | false
    }

    @Unroll
    def "getIpcmTypeIDByHscId: with return value default and IPCM type ID in VO Testcase=#testCaseNumber"() {
        when:
        String result = hscFacility.getIpcmTypeIDByHscId(1)

        then:
        1 * dao.read(_) >> { ReadProperties rp ->
            assert rp.getKeyValue(FieldConstants.HSCID) == 1
            return vo
        }
        result == returnValue
        0 * _

        where:
        testCaseNumber | vo                                    | returnValue
        1              | new HscFacilityVO(ipcmTypeID: "Test") | "Test"
        2              | null                                  | CssReferenceConstants.IPCM_TYPE_ID_NA
    }

    @Unroll
    def "isActualAdmissionAndDischargeDatePopulated: with return value #returnValue"() {
        when:
        boolean result = hscFacility.isActualAdmissionAndDischargeDatePopulated(vo)

        then:
        result == returnValue
        0 * _

        where:
        vo                                                                                                                            | returnValue
        new HscFacilityVO(actualAdmissionDateTime: new UhgCalendar(2016, 1, 1), actualDischargeDateTime: new UhgCalendar(2016, 3, 3)) | true
        new HscFacilityVO()                                                                                                           | false
    }

    def "derivePotentialUrJurisdictions: with successful save"() {
        given:
        HscFacilityVO vo = new HscFacilityVO(hscID: 1L)
        HscVO hscVO = new HscVO(hscID: 1L, memberCoverageSeqNum: 10)
        HscMemberCoverageVO memberCoverageVO = hscMemberCoverage.read(hscVO.getHscID(), hscVO.getMemberCoverageSeqNum())

        when:
        hscFacility.derivePotentialUrJurisdictions(vo)

        then:
        _ * hsc.read(_, _) >> hscVO
        1 * hscMemberCoverage.read(1, 10) >> new HscMemberCoverageVO(productCategoryType: "testProductCategoryType")
        _ * memberCoverageVO.productCategoryType("testProductCategoryType") >> true
        _ * urJurisdiction.read('MC', []) >> null
        0 * _
    }

    def "populateStates: with all state details populated"() {
        given:
        HscFacilityVO vo = new HscFacilityVO(hscID: 1L)
        HscFacilityTatSummaryVO tatSummaryVO = new HscFacilityTatSummaryVO()
        HscVO hscVO = new HscVO(hscID: 1L, memberCoverageSeqNum: 10 as short, memberID: 5L)

        when:
        hscFacility.populateStates(tatSummaryVO, vo)

        then:
        1 * hsc.read(1, _) >> hscVO
        1 * memberAddress.getActiveMemberAddressForMember(5) >> new MemberAddressVO(state: "Minnesota")
        1 * hscMemberCoverage.read(1, 10) >> new HscMemberCoverageVO(policyIssueState: "Connecticut")
        tatSummaryVO.memberStateOfResidence == "Minnesota"
        tatSummaryVO.policyIssueState == "Connecticut"
        0 * _
    }

    def "validate: skip validation"() {
        given:
        HscFacilityVO vo = new HscFacilityVO(skipValidation: true)

        when:
        hscFacility.validate(vo, false)

        then:
        !vo.errorMessagesExist()
        0 * _
    }

    @Unroll
    def "validate: validateAdmissionAndDischargeDates"() {
        given:
        HscFacilityVO vo = new HscFacilityVO()
        vo.setExpectedAdmissionDate(expectedAdmitDate)
        vo.setExpectedDischargeDate(expectedDischargeDate)
        vo.setActualAdmissionDateTime(actualAdmitDate)
        vo.setActualDischargeDateTime(actualDischargeDate)

        when:
        hscFacility.validateAdmissionAndDischargeDates(vo)

        then:
        vo.getMessage(errorField).contains(new FieldMessage(errorField, errorMessage)) == result
        0 * _

        where:
        expectedAdmitDate                   | expectedDischargeDate         | actualAdmitDate                                                           | actualDischargeDate                                                       | errorField                                    | errorMessage                                                  | result
        null                                | null                          | null                                                                      | new UhgCalendar()                                                         | FieldConstants.ACTUALADMISSIONDATETIME        | new ErrorMessage("ERR0010")                           | true
        null                                | new Date(1,1,2015)    | null                                                                      | null                                                                      | FieldConstants.EXPECTEDADMISSIONDATE          | new ErrorMessage("ERR0010")                           | true
        new Date(1,2,2015)          | new Date(1,1,2015)    | null                                                                      | null                                                                      | FieldConstants.EXPECTEDDISCHARGEDATE          | HscMessages.ERR_EXPECTED_DISCHARGE_BEFORE_EXPECTED_ADMISSION  | true
        null                                | null                          | new UhgCalendar(new Date(1,2,2015))                               | new UhgCalendar(new Date(1,1,2015))                               | FieldConstants.ACTUALDISCHARGEDATETIME        | HscMessages.ERR_ACTUAL_DISCHARGE_BEFORE_ACTUAL_ADMISSION      | true
        null                                | null                          | null                                                                      | new UhgCalendar(UhgCalendarUtilities.getSqlDateWithDayOffset(5))      | FieldConstants.ACTUALDISCHARGEDATETIME    | HscMessages.ERR_DISCHARGE_CANNOT_BE_FUTURE_DATE                   | true
        null                                | null                          | new UhgCalendar(UhgCalendarUtilities.getSqlDateWithDayOffset(5))      | null                                                                      | FieldConstants.ACTUALADMISSIONDATETIME    | HscMessages.ERR_ADMISSION_CANNOT_BE_FUTURE_DATE                   | true
    }
}