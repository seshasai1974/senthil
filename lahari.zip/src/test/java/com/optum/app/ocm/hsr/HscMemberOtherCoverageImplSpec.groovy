package com.optum.app.ocm.hsr

import com.optum.rf.common.messages.GlobalMessages
import com.optum.rf.dao.data.message.ErrorMessage
import com.optum.rf.dao.data.message.MessageFactory
import com.optum.rf.dao.exception.UhgRuntimeException
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.optum.rf.test.core.mock.spring.MockTransactionInterceptor
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.Hsc
import com.optum.app.common.hsr.businesslogic.impl.HscMemberOtherCoverageImpl
import com.optum.app.common.hsr.constants.HsrReferenceConstants
import com.optum.app.common.hsr.data.HscMemberOtherCoverageVO
import com.optum.app.common.hsr.data.HscVO

import java.sql.Date

class HscMemberOtherCoverageImplSpec extends HsrReadLogicSpecification{
    HscMemberOtherCoverageImpl hscMemberOtherCoverage
    DataAccessObject dao
    PersistenceHelper persistenceHelper
    Hsc hsc
    
    def setup(){
        hscMemberOtherCoverage = new HscMemberOtherCoverageImpl()
        dao = Mock(DataAccessObject)
        persistenceHelper = Mock(PersistenceHelper)
        hsc = Mock(Hsc)
        hscMemberOtherCoverage.setRequiredDao(dao)
        hscMemberOtherCoverage.setRequiredPersistenceHelper(persistenceHelper)
        hscMemberOtherCoverage.setRequiredTransactionInterceptor(new MockTransactionInterceptor())
        hscMemberOtherCoverage.setRequiredHsc(hsc)
    }
    
    def "test isValid"(){
        given:
        HscMemberOtherCoverageVO vo=  new HscMemberOtherCoverageVO(hscID: 34567,memberOtherCoverageSeqNum: 2 )
        
        when:
        hscMemberOtherCoverage.isValid(vo.hscID,vo.memberOtherCoverageSeqNum)
        
        then:
        1*dao.isValid(_) >> { ReadProperties rp->
            assert rp.getKeyValue(FieldConstants.HSCID) == vo.hscID
            assert rp.getKeyValue(FieldConstants.MEMBEROTHERCOVERAGESEQNUM) == vo.memberOtherCoverageSeqNum
            return true
        }
        0*_
    }
    
    def "test read method"(){
        given:
        HscMemberOtherCoverageVO vo=  new HscMemberOtherCoverageVO(hscID: 34567,memberOtherCoverageSeqNum: 2 )
        
        when:
        hscMemberOtherCoverage.read(vo.hscID,vo.memberOtherCoverageSeqNum)
        
        then:
        1*dao.read(_) >> { ReadProperties rp ->
            assert rp.getKeyValue(FieldConstants.HSCID) == vo.hscID
            assert rp.getKeyValue(FieldConstants.MEMBEROTHERCOVERAGESEQNUM) == vo.memberOtherCoverageSeqNum
        }
        0*_
    }
    
    def "listOtherCoverageByHscID method returns valid list when a valid HscID is passed"(){
        given:
        HscMemberOtherCoverageVO vo = createHscMemberOtherCoverageVO()
        
        when:
        hscMemberOtherCoverage.listOtherCoverageByHscID(vo.hscID)
        
        then:
        1*dao.list(_) >> { QueryProperties qp ->
           assert qp.filterType == QueryProperties.FilterType.NEW_FILTER
           assert qp.orderByAscFields == [FieldConstants.COBROLECODE]
           assert qp.getQueryFilter(FieldConstants.HSCID).fieldValue == vo.hscID 
            return new ArrayList<HscMemberOtherCoverageVO>()
        }
        0*_
        !vo.errorMessagesExist()
    }

    def "hasCoverageRole method should return true for valid role code"(){
        given:
        HscMemberOtherCoverageVO vo=  createHscMemberOtherCoverageVO()
        
        when:
        hscMemberOtherCoverage.hasCoverageRole(vo.hscID, vo.cobRoleCode)
        
        then:
        1*dao.exists(_) >> { QueryProperties qp->
            assert qp.filterType == QueryProperties.FilterType.LIST_ALL
            assert qp.getQueryFilter(FieldConstants.HSCID).fieldValue == vo.hscID
            assert qp.getQueryFilter(FieldConstants.COBROLECODE).fieldValue == vo.cobRoleCode
            return true
        }
        0*_
        !vo.errorMessagesExist()
    }


    def "Valid delete should not produce a UhgruntimeException and error messages"(){
        given:
        HscMemberOtherCoverageVO vo= createHscMemberOtherCoverageVO()

        when:
        hscMemberOtherCoverage.delete(vo)

        then:
        1*persistenceHelper.delete(vo)
        0*_
        !vo.errorMessagesExist()
        notThrown UhgRuntimeException
    }


    private HscMemberOtherCoverageVO createHscMemberOtherCoverageVO() {
        HscMemberOtherCoverageVO hscMemberOtherCoverageVO = new HscMemberOtherCoverageVO(hscID: 34567,cobRoleCode: HsrReferenceConstants.COB_ROLE_CODE_SECONDARY )
        return hscMemberOtherCoverageVO
    }

    private void assertVO(HscMemberOtherCoverageVO vo)    {
        assert vo.getOtherCoverageCompanyName() == null
        assert vo.getOtherCoverageEndDate() == null
        assert vo.getOtherCoveragePolicyNbr() == null
        assert vo.getOtherCoverageReasonType() == null
        assert vo.getOtherCoverageStartDate() == null
        assert vo.getInactiveInd() == false
    }
}
