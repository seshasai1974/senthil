package com.optum.app.ocm.hsr

import com.optum.rf.bl.spring.TransactionInterceptor
import com.optum.rf.core.locator.ServiceLocator
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.HscAutoLetterQueue
import com.optum.app.common.hsr.businesslogic.impl.HscAutoLetterQueueImpl
import com.optum.app.common.hsr.data.HscAutoLetterQueueVO
import spock.lang.Unroll

class HscAutoLetterQueueSpec extends HsrReadLogicSpecification {

    HscAutoLetterQueue hscAutoLetterQueue

    DataAccessObject dao
    PersistenceHelper persistenceHelper
    ServiceLocator serviceLocator
    TransactionInterceptor transactionInterceptor

    def setup() {
        dao = Mock(DataAccessObject)
        persistenceHelper = Mock(PersistenceHelper)
        serviceLocator = Mock(ServiceLocator)
        transactionInterceptor = Mock(TransactionInterceptor)

        hscAutoLetterQueue = new HscAutoLetterQueueImpl(
                requiredPersistenceHelper: persistenceHelper,
                requiredServiceLocator: serviceLocator,
                requiredTransactionInterceptor: transactionInterceptor
        )
        hscAutoLetterQueue.setRequiredDao(dao)
    }

    @Unroll
    def "isValid #testCase"() {
        given:
        def hscAutoLetterQueueID = (long) 1
        def rp = new ReadProperties(FieldConstants.HSCAUTOLETTERQUEUEID)
        rp.setKeyValue(com.optum.app.common.constants.spclcare.FieldConstants.HSCAUTOLETTERQUEUEID, hscAutoLetterQueueID)
        rp.fields = null

        when:
        boolean retVal = hscAutoLetterQueue.isValid(hscAutoLetterQueueID)

        then:
        1 * dao.isValid(rp) >> expectedVal
        0 * _
        retVal == expectedVal

        where:
        testCase | expectedVal
        "passes" | true
        "fails"  | false
    }

    def "Test to read HscAutoLetterQueueVO"() {
        setup:
        def hscAutoLetterQueueID = (long) 1
        HscAutoLetterQueueVO hscAutoLetterQueueVO = new HscAutoLetterQueueVO(hscAutoLetterQueueID: hscAutoLetterQueueID)
        def compareResults = hscAutoLetterQueueVO.compareTo(new HscAutoLetterQueueVO(hscAutoLetterQueueID: hscAutoLetterQueueID))
        def rp = new ReadProperties(FieldConstants.HSCAUTOLETTERQUEUEID)
        rp.setKeyValue(com.optum.app.common.constants.spclcare.FieldConstants.HSCAUTOLETTERQUEUEID, hscAutoLetterQueueID)
        rp.fields = null

        when:
        hscAutoLetterQueue.read(hscAutoLetterQueueID)

        then:
        !compareResults
        1 * dao.read(rp) >> hscAutoLetterQueueVO
        0 * _
    }

    def "Test getByHscID"() {
        setup:

        when:
        hscAutoLetterQueue.getByHscID(123456L)

        then:
        1 * dao.list(_ as QueryProperties)
        0 * _
    }

    def "Test add"() {
        setup:
        HscAutoLetterQueueVO hscAutoLetterQueueVO = new HscAutoLetterQueueVO(hscID: hscId)

        when:
        hscAutoLetterQueue.add(hscAutoLetterQueueVO)

        then:
        1 * dao.list(_ as QueryProperties) >> [ new HscAutoLetterQueueVO() ]
        0 * _

        and:
        if(hscId > 0) {
            1 * persistenceHelper.add(_ as HscAutoLetterQueueVO)
        }

        where: hscId << [ 0L, 123456L ]
    }

}