package com.optum.app.ocm.hsr

import com.optum.rf.bl.spring.TransactionInterceptor
import com.optum.rf.core.locator.ServiceLocator
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.HscDecisionReasonDerivation
import com.optum.app.common.hsr.businesslogic.impl.HscDecisionReasonDerivationImpl
import com.optum.app.common.hsr.data.HscDecisionReasonDerivationVO
import spock.lang.Unroll

class HscDecisionReasonDerivationSpec extends HsrReadLogicSpecification {

    HscDecisionReasonDerivation hscDecisionReasonDerivation

    DataAccessObject dao
    PersistenceHelper persistenceHelper
    ServiceLocator serviceLocator
    TransactionInterceptor transactionInterceptor

    def setup() {
        dao = Mock(DataAccessObject)
        persistenceHelper = Mock(PersistenceHelper)
        serviceLocator = Mock(ServiceLocator)
        transactionInterceptor = Mock(TransactionInterceptor)

        hscDecisionReasonDerivation = new HscDecisionReasonDerivationImpl(
                requiredDao: dao,
                requiredPersistenceHelper: persistenceHelper,
                requiredServiceLocator: serviceLocator,
                requiredTransactionInterceptor: transactionInterceptor
        )
    }

    @Unroll
    def "isValid #testCase"() {
        given:
        def serviceSettingType = "1"
        def decisionOutcomeType = "2"
        def decisionSubType = "3"
        def specialServiceType = "4"
        def decisionReasonType = "5"
        def decisionReasonSpecialProcess = "6"
        def rp = new ReadProperties(FieldConstants.SERVICESETTINGTYPE, FieldConstants.DECISIONOUTCOMETYPE, FieldConstants.DECISIONSUBTYPE, FieldConstants.SPECIALSERVICETYPE,
                FieldConstants.DECISIONREASONTYPE, FieldConstants.DECISIONREASONSPECIALPROCESS)
        rp.setKeyValue(FieldConstants.SERVICESETTINGTYPE, serviceSettingType)
        rp.setKeyValue(FieldConstants.DECISIONOUTCOMETYPE, decisionOutcomeType)
        rp.setKeyValue(FieldConstants.DECISIONSUBTYPE, decisionSubType)
        rp.setKeyValue(FieldConstants.SPECIALSERVICETYPE, specialServiceType)
        rp.setKeyValue(FieldConstants.DECISIONREASONTYPE, decisionReasonType)
        rp.setKeyValue(FieldConstants.DECISIONREASONSPECIALPROCESS, decisionReasonSpecialProcess)
        rp.fields = null

        when:
        boolean retVal = hscDecisionReasonDerivation.isValid(serviceSettingType, decisionOutcomeType, decisionSubType, specialServiceType, decisionReasonType, decisionReasonSpecialProcess)

        then:
        1 * dao.isValid(rp) >> expectedVal
        0 * _
        retVal == expectedVal

        where:
        testCase | expectedVal
        "passes" | true
        "fails"  | false
    }

    def "Test to read HscDecisionReasonDerivationVO"() {
        setup:
        def serviceSettingType = "1"
        def decisionOutcomeType = "2"
        def decisionSubType = "3"
        def specialServiceType = "4"
        def decisionReasonType = "5"
        def decisionReasonSpecialProcess = "6"
        HscDecisionReasonDerivationVO hscDecisionReasonDerivationVO = new HscDecisionReasonDerivationVO(serviceSettingType: serviceSettingType, decisionOutcomeType: decisionOutcomeType,
                decisionSubType: decisionSubType, specialServiceType: specialServiceType, decisionReasonType: decisionReasonType, decisionReasonSpecialProcess: decisionReasonSpecialProcess)
        def rp = new ReadProperties(FieldConstants.SERVICESETTINGTYPE, FieldConstants.DECISIONOUTCOMETYPE, FieldConstants.DECISIONSUBTYPE, FieldConstants.SPECIALSERVICETYPE,
                FieldConstants.DECISIONREASONTYPE, FieldConstants.DECISIONREASONSPECIALPROCESS)
        rp.setKeyValue(FieldConstants.SERVICESETTINGTYPE, serviceSettingType)
        rp.setKeyValue(FieldConstants.DECISIONOUTCOMETYPE, decisionOutcomeType)
        rp.setKeyValue(FieldConstants.DECISIONSUBTYPE, decisionSubType)
        rp.setKeyValue(FieldConstants.SPECIALSERVICETYPE, specialServiceType)
        rp.setKeyValue(FieldConstants.DECISIONREASONTYPE, decisionReasonType)
        rp.setKeyValue(FieldConstants.DECISIONREASONSPECIALPROCESS, decisionReasonSpecialProcess)
        rp.fields = null

        when:
        hscDecisionReasonDerivation.read(serviceSettingType, decisionOutcomeType, decisionSubType, specialServiceType, decisionReasonType, decisionReasonSpecialProcess, "")

        then:
        1 * dao.read(rp) >> hscDecisionReasonDerivationVO
        0 * _
    }
}
