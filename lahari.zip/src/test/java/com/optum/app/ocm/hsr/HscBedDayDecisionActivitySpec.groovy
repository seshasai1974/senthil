package com.optum.app.ocm.hsr

import com.optum.rf.bl.spring.TransactionInterceptor
import com.optum.rf.core.locator.ServiceLocator
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.HscBedDayDecisionActivity
import com.optum.app.common.hsr.businesslogic.impl.HscBedDayDecisionActivityImpl
import com.optum.app.common.hsr.data.HscBedDayDecisionActivityVO
import spock.lang.Unroll

class HscBedDayDecisionActivitySpec extends HsrReadLogicSpecification {

    HscBedDayDecisionActivity hscBedDayDecisionActivity

    DataAccessObject dao
    PersistenceHelper persistenceHelper
    ServiceLocator serviceLocator
    TransactionInterceptor transactionInterceptor

    def setup() {
        dao = Mock(DataAccessObject)
        persistenceHelper = Mock(PersistenceHelper)
        serviceLocator = Mock(ServiceLocator)
        transactionInterceptor = Mock(TransactionInterceptor)

        hscBedDayDecisionActivity = new HscBedDayDecisionActivityImpl(
                requiredDao: dao,
                requiredPersistenceHelper: persistenceHelper,
                requiredServiceLocator: serviceLocator,
                requiredTransactionInterceptor: transactionInterceptor
        )
    }

    @Unroll
    def "isValid #testCase"() {
        given:
        def hscID = (long) 1
        def bedDate = new java.sql.Date(1111111)
        def bedDayDecisionSeqNum =  (short) 3
        def activityID = (long) 4
        def rp = new ReadProperties(FieldConstants.HSCID, FieldConstants.BEDDATE, FieldConstants.BEDDAYDECISIONSEQNUM, FieldConstants.ACTIVITYID)
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        rp.setKeyValue(FieldConstants.BEDDATE, bedDate)
        rp.setKeyValue(FieldConstants.BEDDAYDECISIONSEQNUM, bedDayDecisionSeqNum)
        rp.setKeyValue(FieldConstants.ACTIVITYID, activityID)
        rp.fields = null

        when:
        boolean retVal = hscBedDayDecisionActivity.isValid(hscID, bedDate, bedDayDecisionSeqNum, activityID)

        then:
        1 * dao.isValid(rp) >> expectedVal
        0 * _
        retVal == expectedVal

        where:
        testCase | expectedVal
        "passes" | true
        "fails"  | false
    }

    def "Test to read HscBedDayDecisionActivityVO"() {
        setup:
        def hscID = (long) 1
        def bedDate = new java.sql.Date(1111111)
        def bedDayDecisionSeqNum =  (short) 3
        def activityID = (long) 4
        HscBedDayDecisionActivityVO programHscAlertTypeVO = new HscBedDayDecisionActivityVO(hscID: hscID, bedDate: bedDate, bedDayDecisionSeqNum: bedDayDecisionSeqNum, activityID: activityID)
        def rp = new ReadProperties(FieldConstants.HSCID, FieldConstants.BEDDATE, FieldConstants.BEDDAYDECISIONSEQNUM, FieldConstants.ACTIVITYID)
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        rp.setKeyValue(FieldConstants.BEDDATE, bedDate)
        rp.setKeyValue(FieldConstants.BEDDAYDECISIONSEQNUM, bedDayDecisionSeqNum)
        rp.setKeyValue(FieldConstants.ACTIVITYID, activityID)
        rp.fields = null

        when:
        hscBedDayDecisionActivity.read(hscID, bedDate, bedDayDecisionSeqNum, activityID)

        then:
        1 * dao.read(rp) >> programHscAlertTypeVO
        0 * _
    }
}
