package com.optum.app.ocm.hsr

import com.optum.rf.dao.tabledef.TableDefFactory
import com.optum.rf.test.core.spock.BaseReadLogicSpecification
import com.uhg.tabledef.spclcare.TableDefFactoryLoaderImpl

class HsrReadLogicSpecification extends BaseReadLogicSpecification {
    // specify the Rules built tabledef
    static {
        tableDefFactory = new TableDefFactory(TableDefFactoryLoaderImpl.newInstance())
    }
}
