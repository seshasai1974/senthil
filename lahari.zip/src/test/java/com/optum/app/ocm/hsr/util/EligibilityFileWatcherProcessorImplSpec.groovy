package com.optum.app.ocm.hsr.util

import com.optum.app.ocm.hsr.util.impl.EligibilityFileWatcherProcessorImpl
import com.optum.rf.common.settings.businesslogic.SystemSettingsFileSystem
import com.optum.app.common.edi.businesslogic.EdiProcessor
import com.optum.app.common.edi.data.EdiVO
import spock.lang.Specification

class EligibilityFileWatcherProcessorImplSpec extends Specification{

    EligibilityFileWatcherProcessorImpl eligibilityFileWatcherProcessor
    EdiProcessor ediProcessor
    SystemSettingsFileSystem settingsFileSystem

    def setup() {
        eligibilityFileWatcherProcessor = new EligibilityFileWatcherProcessorImpl()
        ediProcessor = Mock(EdiProcessor)
        settingsFileSystem = Mock(SystemSettingsFileSystem)

        eligibilityFileWatcherProcessor.ediProcessor = ediProcessor
        eligibilityFileWatcherProcessor.settingsFileSystem = settingsFileSystem
    }

    def "test processEligibilityForCompletion"() {
        setup:
            File eligibilityTextFile = new File("testFile")
            PrintWriter printWriter = new PrintWriter(eligibilityTextFile)
            printWriter.println("First line")
            printWriter.println("Second line")
            printWriter.close()
            List<File> filesToProcess = new ArrayList<File>()
            filesToProcess.add(eligibilityTextFile)
            EdiVO ediVO = new EdiVO()
            ediVO.setMessagePayload("First line")
            EdiVO ediVO2 = new EdiVO()
            ediVO2.setMessagePayload("Second line")
        when:
            eligibilityFileWatcherProcessor.processEligibilityForCompletion(filesToProcess)

        then:
            1 * ediProcessor.processWithNewTransaction(ediVO, "testFile") >> ediVO
        1 * ediProcessor.processWithNewTransaction(ediVO2, "testFile") >> ediVO2
    }
}
