package com.optum.app.ocm.common

import com.optum.rf.dao.tabledef.TableDefFactory
import com.optum.rf.test.core.spock.BaseReadLogicSpecification
import com.uhg.tabledef.spclcare.TableDefFactoryLoaderImpl

class CommonReadLogicSpecification extends BaseReadLogicSpecification {
    // specify the Rules built tabledef
    static {
        tableDefFactory = new TableDefFactory(TableDefFactoryLoaderImpl.newInstance())
    }
}
