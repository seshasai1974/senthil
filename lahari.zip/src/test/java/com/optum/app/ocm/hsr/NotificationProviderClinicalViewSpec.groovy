package com.optum.app.ocm.hsr

import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.QueryFilter
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.rf.dao.sql.query.ReadProperties
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.NotificationProviderClinicalView
import com.optum.app.common.hsr.businesslogic.impl.NotificationProviderClinicalViewImpl
import com.optum.app.common.hsr.data.NotificationProviderClinicalViewVO

class NotificationProviderClinicalViewSpec extends HsrReadLogicSpecification {

    NotificationProviderClinicalView notificationProviderClinicalView

    DataAccessObject dao

    def setup() {
        dao = Mock(DataAccessObject)

        notificationProviderClinicalView = new NotificationProviderClinicalViewImpl(
                dao: dao)
    }
    
    def "Test to read NotificationProviderClinicalViewVO"() {
        setup:
        def hscID = (long) 1
        def providerSeqNum = (short) 2
        NotificationProviderClinicalViewVO notificationProviderClinicalViewVO = new NotificationProviderClinicalViewVO(hscID: hscID, providerSeqNum: providerSeqNum)
        def rp = new ReadProperties(FieldConstants.HSCID, FieldConstants.PROVIDERSEQNUM)
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        rp.setKeyValue(FieldConstants.PROVIDERSEQNUM, providerSeqNum)

        when:
        notificationProviderClinicalView.read(hscID, providerSeqNum)

        then:
        1 * dao.list(_) >> [notificationProviderClinicalViewVO]
        0 * _
    }

    def "Test listByHscID"() {
        setup:
        def hscID = (long) 1
        NotificationProviderClinicalViewVO notificationProviderClinicalViewVO = new NotificationProviderClinicalViewVO(hscID: hscID)
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        qp.addQueryFilter(new QueryFilter(FieldConstants.HSCID, hscID))

        when:
        notificationProviderClinicalView.listByHscID(qp, hscID)

        then:
        1 * dao.list(qp) >> [notificationProviderClinicalViewVO]
        0 * _
    }
}
