package com.optum.app.ocm.hsr

import com.optum.rf.bl.spring.TransactionInterceptor
import com.optum.rf.core.locator.ServiceLocator
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.QueryFilter
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.MemberProgramHscSrvcDiag
import com.optum.app.common.hsr.businesslogic.impl.MemberProgramHscSrvcDiagImpl

class MemberProgramHscSrvcDiagSpec extends HsrReadLogicSpecification {

    MemberProgramHscSrvcDiag memberProgramHscSrvcDiag

    DataAccessObject dao
    PersistenceHelper persistenceHelper
    ServiceLocator serviceLocator
    TransactionInterceptor transactionInterceptor

    def setup() {
        dao = Mock(DataAccessObject)
        persistenceHelper = Mock(PersistenceHelper)
        serviceLocator = Mock(ServiceLocator)
        transactionInterceptor = Mock(TransactionInterceptor)

        memberProgramHscSrvcDiag = new MemberProgramHscSrvcDiagImpl(
                dao: dao,
                requiredPersistenceHelper: persistenceHelper,
                requiredServiceLocator: serviceLocator,
                requiredTransactionInterceptor: transactionInterceptor
        )
    }

    def "Test listByMemberProgram"() {
        setup:
        def memberProgramId = (long) 1
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        qp.addQueryFilter(new QueryFilter(FieldConstants.MEMBERPROGRAMID, memberProgramId))

        when:
        memberProgramHscSrvcDiag.listByMemberProgram(memberProgramId)

        then:
        1 * dao.list(qp) >> new ArrayList<>()
        0 * _
    }
}
