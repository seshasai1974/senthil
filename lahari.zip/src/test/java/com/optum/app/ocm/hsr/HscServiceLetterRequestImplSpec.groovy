package com.optum.app.ocm.hsr

import com.optum.rf.common.reference.businesslogic.util.ProcedureCode
import com.optum.rf.core.util.UhgCalendar
import com.optum.rf.dao.util.UhgCalendarUtilities
import com.optum.app.common.constants.CommonReferenceConstants
import com.optum.app.common.hsr.businesslogic.*
import com.optum.app.common.hsr.businesslogic.impl.HscServiceLetterRequestImpl
import com.optum.app.common.hsr.constants.HsrReferenceConstants
import com.optum.app.common.hsr.data.*
import spock.lang.Unroll

class HscServiceLetterRequestImplSpec extends HsrReadLogicSpecification {

    HscServiceLetterRequestImpl hscServiceLetterRequest
    HscFacility hscFacility
    HscFacilityDecision hscFacilityDecision
    HscServiceDecision hscServiceDecision
    ProcedureCode procedureCode
    HscProvider hscProvider
    HscLetterRequestDecision hscLetterRequestDecision
    HscLetterRequest hscLetterRequest
    HscFacilityDecisionBedDay hscFacilityDecisionBedDay

    def setup() {
        hscFacility = Mock(HscFacility)
        hscFacilityDecision = Mock(HscFacilityDecision)
        hscServiceDecision = Mock(HscServiceDecision)
        procedureCode = Mock(ProcedureCode)
        hscProvider = Mock(HscProvider)
        hscLetterRequestDecision = Mock(HscLetterRequestDecision)
        hscLetterRequest = Mock(HscLetterRequest)
        hscFacilityDecisionBedDay = Mock(HscFacilityDecisionBedDay)

        hscServiceLetterRequest = new HscServiceLetterRequestImpl(
                requiredHscFacility: hscFacility,
                requiredHscFacilityDecision: hscFacilityDecision,
                requiredHscLetterRequestDecision: hscLetterRequestDecision,
                requiredHscLetterRequest: hscLetterRequest
        )
    }

    def "Validate that the HscLetterRequestVO returned from the CreateLetterRequest is populated as expected."() {
        given:
        def hscVO = new HscVO(hscID: 1, primaryServiceReferenceNum: "1", memberCoverageSeqNum: new Short("1"), specialProcessType: '00')
        def serviceLetterRequestList = [
                getDefaultServiceLetterRequestVO(true, HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED, true),
                getDefaultServiceLetterRequestVO(false, HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED, true),
                getDefaultServiceLetterRequestVO(false, HsrReferenceConstants.DECISIONOUTCOMETYPE_DENIED, false)]

        when:
        def letterRequestVO = hscServiceLetterRequest.createLetterRequest(hscVO, serviceLetterRequestList)

        then:
        1 * hscLetterRequest.saveCascading(_)
        0 * _

        and:
        letterRequestVO.getHscID() == 1
        letterRequestVO.getServiceReferenceNum() == "1"
        letterRequestVO.getHscLetterRequestDecisionVOs()
        // HscLetterRequestDecisionVOs list should only contain HscLetterRequestDecisionVO for HscServiceLetterRequestVO that have LetterRequestedInd equal to true.
        letterRequestVO.getHscLetterRequestDecisionVOs().size() == 2
    }

    private HscServiceLetterRequestVO getDefaultServiceLetterRequestVO(boolean isFacility, String outcomeType, boolean selectedForLetter) {
        new HscServiceLetterRequestVO(
                decisionOutcomeType: outcomeType,
                decisionSeqNum: 1,
                facilityLine: isFacility,
                letterRequestedInd: selectedForLetter,
                serviceLine: isFacility ? "FAC" : "1",
                serviceReferenceNum: "1",
                serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT,
                serviceSeqNum: isFacility ? 1 : 0)

    }

    @Unroll
    def "getLetterRequestServiceList: serviceSetting = #serviceSettingType, hasDecisionOutcome = #hasDecisionOutcome"() {
        given:
        long hscID = 1

        when:
        def list = hscServiceLetterRequest.getLetterRequestServiceList(hscID, serviceSettingType, hasDecisionOutcome)

        then:
        1 * hscFacilityDecision.getLastDecisionRendered(hscID, _) >> new HscFacilityDecisionVO()
        1 * hscFacility.read(hscID) >> new HscFacilityVO()
        0 * _

        and:
        list.size() == 1

        where:
        serviceSettingType                                              | hasDecisionOutcome
        CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT           | true
        CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY | false
    }

    def "getLetterRequestDecisionList:"() {
        given:
        long hscID = 1
        String serviceSettingType = "serviceSettingType"
        when:
        def list = hscServiceLetterRequest.getLetterRequestDecisionList(hscID, serviceSettingType)

        then:
        0 * _
    }

    def "getHscServiceLetterRequestVOsMatchingDecisionsSnapshot:"() {
        given:
        long hscID = 1
        int letterRequestSeqNum = 1
        def serviceSettingType = CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT
        HscLetterRequestDecisionVO hscLetterRequestDecisionVO = new HscLetterRequestDecisionVO(
                letterRequestSeqNum: 1,
                facilityDecisionSeqNum: 1
        )
        when:
        def list = hscServiceLetterRequest.getHscServiceLetterRequestVOsMatchingDecisionsSnapshot(hscID,letterRequestSeqNum, serviceSettingType)

        then:
        1 * hscLetterRequestDecision.getLetterRequestDecisions(_, _) >> [hscLetterRequestDecisionVO]

    }


    def "getHscServiceLetterRequestVOsMatchingDecisionsSnapshotForLetterRequest:"() {
        given:
        long hscID = 1
        int letterRequestSeqNum = 1
        def serviceSettingType = CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT
        HscLetterRequestDecisionVO hscLetterRequestDecisionVO = new HscLetterRequestDecisionVO(
                letterRequestSeqNum: 1,
                facilityDecisionSeqNum: 1
        )
        when:
        def list = hscServiceLetterRequest.getHscServiceLetterRequestVOsMatchingDecisionsSnapshotForLetterRequest(hscID,letterRequestSeqNum, serviceSettingType)

        then:
        1 * hscLetterRequestDecision.getLetterRequestDecisions(_, _) >> [hscLetterRequestDecisionVO]

    }

    @Unroll
    def "getLetterRequestServiceList: hasDecisionOutcome = #hasDecisionOutcome"() {
        given:
        long hscID = 1
        def serviceSettingType = CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT

        when:
        def list = hscServiceLetterRequest.getLetterRequestServiceList(hscID, serviceSettingType, hasDecisionOutcome)

        then:
        0 * _

        and:
        list.size() == 0

        where:
        hasDecisionOutcome << [true | false]
    }

    def "test written communication date time from letterEntryTimeInMS"() {
        given:
        HscLetterRequestVO hscLetterRequestVO = new HscLetterRequestVO(
                templateID: "DOER",
                letterRequestSeqNum: 1,
                letterEntryTimeInMS: 1374774989315
        )

        when:
        UhgCalendar localCal = UhgCalendarUtilities.getLocalCalendar(hscLetterRequestVO.getLetterEntryTimeInMS())

        then:
        String sqlDateFromCal  = localCal.getSQLDate()  //07-25-2013 1:56:29:315 PM EDT

        and:
        sqlDateFromCal ==  "2013-07-25"
    }
}
