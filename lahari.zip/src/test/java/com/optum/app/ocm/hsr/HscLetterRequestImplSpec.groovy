package com.optum.app.ocm.hsr

import com.optum.rf.bl.businesslogic.ReadLogic
import com.optum.rf.bl.factory.LogicTypeFactory
import com.optum.rf.dao.data.ValueObject
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.QueryFilter
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.tabledef.TableDefFactory
import com.optum.rf.dao.util.UhgCalendarUtilities
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.optum.app.common.constants.HsrConstants
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.uhg.app.common.constants.spclcare.TableConstants
import com.optum.app.common.hsr.businesslogic.*
import com.optum.app.common.hsr.businesslogic.impl.HscLetterRequestImpl
import com.optum.app.common.hsr.constants.HsrReferenceConstants
import com.optum.app.common.hsr.data.*
import com.optum.app.common.hsr.util.ReadabilityUtils
import spock.lang.Unroll

class HscLetterRequestImplSpec extends HsrReadLogicSpecification {

    Hsc hsc
    HscLetterRequest hscLetterRequest
    DataAccessObject dao
    PersistenceHelper persistenceHelper
    HscDiagnosis hscDiagnosis
    HscTatPointHelper hscTatPointHelper
    HscServiceLetterRequest hscServiceLetterRequest
    HscLetterRequestAttribute hscLetterRequestAttribute
//    HscLetterRequestWSQueue hscLetterRequestWSQueue
    HscLetterRequestDecision hscLetterRequestDecision
    HscLetterRequestDiagnosis hscLetterRequestDiagnosis
    private static final long HSC_ID = 1
    private static final int LETTER_SEQ_NUM = 2
    private static final String SERVICE_REF_NUM = "3"
    private static final String PRIMARY_SERVICE_REF_NUM = "4"

    def setup() {
        dao = Mock(DataAccessObject)
        persistenceHelper = Mock(PersistenceHelper)
        hsc = Mock(Hsc)
        hscDiagnosis = Mock(HscDiagnosis)
        hscTatPointHelper = Mock(HscTatPointHelper)
        hscServiceLetterRequest = Mock(HscServiceLetterRequest)
        hscLetterRequestAttribute = Mock(HscLetterRequestAttribute)
//        hscLetterRequestWSQueue = Mock(HscLetterRequestWSQueue)
        hscLetterRequestDecision = Mock(HscLetterRequestDecision)
        hscLetterRequestDiagnosis = Mock(HscLetterRequestDiagnosis)
        hscLetterRequest = new HscLetterRequestImpl(
                requiredDao: dao,
                requiredPersistenceHelper: persistenceHelper,
                requiredTatPointHelper: hscTatPointHelper,
                requiredHscServiceLetterRequest: hscServiceLetterRequest,
                requiredHscLetterRequestAttribute: hscLetterRequestAttribute,
//                requiredHscLetterRequestWSQueue: hscLetterRequestWSQueue,
                requiredHscDiagnosis: hscDiagnosis,
                requiredHscLetterRequestDiagnosis: hscLetterRequestDiagnosis,
                requiredHsc: hsc
        )
        LogicTypeFactory.putInstance(TableConstants.HSC_LTR_REQ_ATR, hscLetterRequestAttribute)
        LogicTypeFactory.putInstance(TableConstants.HSC_LTR_REQ_DECN, hscLetterRequestDecision)
    }

    def "test updateStatus"() {
        given:
        String letterRequestStatusType = HsrReferenceConstants.HSCLETTERREQUEST_TEMPLATECOMPLETE
        HscLetterRequestVO hscLetterRequestVO = getRequestVO()

        // READ PROPERTIES
        ReadProperties rp = getReadProperties()

        when:
        hscLetterRequest.updateStatus(HSC_ID, LETTER_SEQ_NUM, letterRequestStatusType)

        then:
        1 * dao.read(rp) >> hscLetterRequestVO
        1 * persistenceHelper.update(hscLetterRequestVO)
        1 * hsc.read(HSC_ID, FieldConstants.PRIMARYSERVICEREFERENCENUM) >> new HscVO(primaryServiceReferenceNum: PRIMARY_SERVICE_REF_NUM)
        0 * _

        expect:
        hscLetterRequestVO.letterRequestStatusType == letterRequestStatusType
    }

    def "Creates a letter template when errors are not present"() {
        given:
        // QUERY PROPERTIES
        QueryProperties qp = getHscLetterRequestQueryProperties()

        when:
        hscLetterRequest.createLetterTemplate(hscLetterRequestVO)

        then:
        1 * hscLetterRequestAttribute.validateList(hscLetterRequestVO.hscLetterRequestAttributeVOs)
        1 * dao.isDuplicate(qp) >> false
        1 * persistenceHelper.add(hscLetterRequestVO)
        1 * hscLetterRequestAttribute.getTableDef() >> TableDefFactory.getTableDef(TableConstants.HSC_LTR_REQ_ATR)
        1 * hscLetterRequestAttribute.addCascading(hscLetterRequestVO.getHscLetterRequestAttributeVOs().first())
        1 * hscLetterRequestDecision.getTableDef() >> TableDefFactory.getTableDef(TableConstants.HSC_LTR_REQ_DECN)
        1 * hscLetterRequestDecision.addCascading(hscLetterRequestVO.getHscLetterRequestDecisionVOs().first())
        1 * hscDiagnosis.readPrimary(HSC_ID)
//        1 * hscLetterRequestWSQueue.addHscLetterRequestToQueue(hscLetterRequestVO)
        1 * hsc.read(HSC_ID, FieldConstants.PRIMARYSERVICEREFERENCENUM) >> new HscVO(primaryServiceReferenceNum: "23")
        0 * _
        !hscLetterRequestVO.errorMessagesExist()
        
        where:
        hscLetterRequestVO << [new HscLetterRequestVO(hscID: HSC_ID, letterRequestSeqNum: LETTER_SEQ_NUM, hscLetterRequestDecisionVOs: [new HscLetterRequestDecisionVO()], hscLetterRequestAttributeVOs: [new HscLetterRequestAttributeVO()], specialtyOperations: true, ooaNursePhoneNumber: "123-123-1234"),
                               new HscLetterRequestVO(hscID: HSC_ID, letterRequestSeqNum: LETTER_SEQ_NUM, hscLetterRequestDecisionVOs: [new HscLetterRequestDecisionVO()], hscLetterRequestAttributeVOs: [new HscLetterRequestAttributeVO()], specialtyOperations: false, ooaNursePhoneNumber: ""),
                               new HscLetterRequestVO(hscID: HSC_ID, letterRequestSeqNum: LETTER_SEQ_NUM, hscLetterRequestDecisionVOs: [new HscLetterRequestDecisionVO()],
                                                       hscLetterRequestAttributeVOs: [new HscLetterRequestAttributeVO()], specialtyOperations: true, ooaNursePhoneNumber: "")]
        
        
    }

//    def "Creates a letter template when errors are present"() {
//        given:
//        HscLetterRequestVO hscLetterRequestVO = new HscLetterRequestVO()
//
//        when:
//        hscLetterRequest.createLetterTemplate(hscLetterRequestVO)
//
//        then:
//        1 * hscLetterRequestAttribute.validateList(hscLetterRequestVO.hscLetterRequestAttributeVOs)
//        0 * _
//        hscLetterRequestVO.errorMessagesExist()
//    }

    def "Retrieve list of completed hsc letter requests"() {
        given:
        HscServiceLetterRequestVO hscServiceLetterRequestVO = new HscServiceLetterRequestVO(
                serviceSeqNum: 5 as short, serviceReferenceNum: "22")
        def serviceReferenceNumZeroPadded = hscServiceLetterRequestVO.getServiceReferenceNumZeroPadded()
        List<HscLetterRequestVO> completedLetterVOs = [getRequestVO()]
        completedLetterVOs.first().setLetterRequestStatusType(HsrReferenceConstants.HSCLETTERREQUEST_COMPLETE)
        completedLetterVOs.first().hscLetterRequestDiagnosisVOs = [new HscLetterRequestDiagnosisVO(hscID: HSC_ID)]
        completedLetterVOs.first().hscServiceLetterRequestVOs = [hscServiceLetterRequestVO]
        String serviceSetting = ""

        // QUERY PROPERTIES
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        qp.addQueryFilter(new QueryFilter(FieldConstants.HSCID, HSC_ID))
        qp.addQueryFilter(new QueryFilter(FieldConstants.LETTERREQUESTSTATUSTYPE, HsrReferenceConstants.HSCLETTERREQUEST_COMPLETE))
        qp.setOrderByDescFields(FieldConstants.LETTERENTRYTIMEINMS, FieldConstants.SERVICEREFERENCENUM, FieldConstants.LETTERREQUESTSEQNUM)

        when:
        List<HscLetterRequestVO> vos = hscLetterRequest.getHscLetterRequestVOsCompleted(HSC_ID, serviceSetting)

        then:
        for (HscLetterRequestVO completedLetter : completedLetterVOs) {
            1 * hscLetterRequestDiagnosis.getHscLetterRequestDiagnosisVOs(completedLetter.hscID, completedLetter.letterRequestSeqNum) >> completedLetterVOs.first().hscLetterRequestDiagnosisVOs
            1 * hscServiceLetterRequest.getHscServiceLetterRequestVOsMatchingDecisionsSnapshot(completedLetter.hscID, completedLetter.letterRequestSeqNum, serviceSetting) >> completedLetterVOs.first().hscServiceLetterRequestVOs
        }
        1 * dao.list(qp) >> completedLetterVOs
        0 * _

        expect: "value object has diagnosis and service objects and more details set"
        HscLetterRequestVO vo = vos.first()
        vo == completedLetterVOs.first()
        vo.hscLetterRequestDiagnosisVOs.size() == 1
        vo.hscServiceLetterRequestVOs.size() == 1
        vo.hscLetterRequestDiagnosisVOs.first().hscID == HSC_ID
        vo.hscServiceLetterRequestVOs.first().serviceSeqNum == 5 as short
        serviceReferenceNumZeroPadded == "0000000022"
        vo.moreDetails
    }

    def "Retrieve list of completed hsc letter requests with empty diagnosis VOs or service request VOs"() {
        given:
        List<HscLetterRequestVO> completedLetterRequestVOs = [new HscLetterRequestVO(hscID: HSC_ID, letterRequestStatusType: HsrReferenceConstants.HSCLETTERREQUEST_COMPLETE)]
        String serviceSetting = ""

        // QUERY PROPERTIES
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        qp.addQueryFilter(new QueryFilter(FieldConstants.HSCID, HSC_ID))
        qp.addQueryFilter(new QueryFilter(FieldConstants.LETTERREQUESTSTATUSTYPE, HsrReferenceConstants.HSCLETTERREQUEST_COMPLETE))
        qp.setOrderByDescFields(FieldConstants.LETTERENTRYTIMEINMS, FieldConstants.SERVICEREFERENCENUM, FieldConstants.LETTERREQUESTSEQNUM);

        when:
        List<HscLetterRequestVO> returnCompletedLetterRequestVOs = hscLetterRequest.getHscLetterRequestVOsCompleted(HSC_ID, serviceSetting)

        then:
        1 * dao.list(qp) >> completedLetterRequestVOs
        1 * hscLetterRequestDiagnosis.getHscLetterRequestDiagnosisVOs(completedLetterRequestVOs.first().hscID, completedLetterRequestVOs.first().letterRequestSeqNum) >> []
        1 * hscServiceLetterRequest.getHscServiceLetterRequestVOsMatchingDecisionsSnapshot(completedLetterRequestVOs.first().hscID, completedLetterRequestVOs.first().letterRequestSeqNum, serviceSetting) >> []
        0 * _

        expect: "Value object should not have more details"
        returnCompletedLetterRequestVOs == completedLetterRequestVOs
        returnCompletedLetterRequestVOs.size() == 1
        returnCompletedLetterRequestVOs.first().hscID == HSC_ID
        returnCompletedLetterRequestVOs.first().letterRequestStatusType == HsrReferenceConstants.HSCLETTERREQUEST_COMPLETE
        !returnCompletedLetterRequestVOs.first().getMoreDetails()
    }

    def "test read"() {
        given:
        String[] readFields = []

        when:
        HscLetterRequestVO hscLetterRequestVO = hscLetterRequest.read(HSC_ID, LETTER_SEQ_NUM, readFields)

        then:
        1 * dao.read(_ as ReadProperties) >> { ReadProperties rp ->
            rp.getKeyValue(FieldConstants.HSCID) == HSC_ID
            rp.getKeyValue(FieldConstants.LETTERREQUESTSEQNUM) == LETTER_SEQ_NUM
            new HscLetterRequestVO(hscID: HSC_ID)
        }
        0 * _

        expect:
        hscLetterRequestVO.hscID == HSC_ID
    }

    def "test delete"() {
        given:
        HscLetterRequestVO vo = getRequestVO()
        HscLetterRequestVO deletedVO

        when:
        deletedVO = hscLetterRequest.delete(vo)

        then:
        1 * persistenceHelper.delete(vo)
        0 * _

        expect:
        deletedVO.hscID == 0
    }

    def "test update"() {
        given:
        HscLetterRequestVO vo = getRequestVO()

        when:
        hscLetterRequest.update(vo)

        then:
        1 * hsc.read(vo.getHscID(), FieldConstants.PRIMARYSERVICEREFERENCENUM) >> new HscVO()
        1 * persistenceHelper.update(vo)
        0 * _
    }

    def "forceValues: will set a service reference number from hscVO if current is zero or null"() {
        given:
        HscLetterRequestVO vo = getRequestVO()
        vo.setServiceReferenceNum(ReadabilityUtils.ZERO)

        when:
        hscLetterRequest.forceValues(vo)

        then:
        1 * hsc.read(HSC_ID, [FieldConstants.PRIMARYSERVICEREFERENCENUM]) >> new HscVO(primaryServiceReferenceNum: SERVICE_REF_NUM)
        vo.getServiceReferenceNum() == SERVICE_REF_NUM
        0 * _
    }

    def "forceValues: Letter entry time should exists if letter request status type is set"() {
        given:
        HscLetterRequestVO vo = getRequestVO()
        vo.setServiceReferenceNum(SERVICE_REF_NUM)
        vo.setLetterRequestStatusType(HsrReferenceConstants.HSCLETTERREQUEST_TEMPLATENEW)

        when:
        hscLetterRequest.forceValues(vo)

        then:
        vo.getLetterEntryTimeInMS() != null
        0 * _
    }

    def "forceValues: Grace period is set to true for template ID"() {
        given:
        HscLetterRequestVO vo = getRequestVO()
        vo.setServiceReferenceNum(SERVICE_REF_NUM)
        vo.setTemplateID(HsrConstants.LETTER_TEMPLATE_TYPE_GRACE_PERIOD)

        when:
        hscLetterRequest.forceValues(vo)

        then:
        vo.getGracePeriodInd()
        0 * _
    }

    @Unroll()
    def "getEarliestLetterSentByTemplateUsing: passing #stateOfTemplate template(s) to get the earliest letter that was sent"() {
        when:
        HscLetterRequestVO hscLetterRequestVO = hscLetterRequest.getEarliestLetterSentByTemplate(HSC_ID, templates)

        then:
        1 * dao.list(_ as QueryProperties) >> { QueryProperties qp ->
            assert qp.filterType == QueryProperties.FilterType.NEW_FILTER
            assert qp.getQueryFilter(FieldConstants.HSCID).fieldValue == HSC_ID
            assert qp.queryFilters.size() == 2
            [new HscLetterRequestVO(hscID: HSC_ID)]
        }
        0 * _

        expect:
        hscLetterRequestVO.hscID == HSC_ID

        where:
        templates      | stateOfTemplate
        ["templates1"] | "one"
        []             | "empty"
    }

    @Unroll()
    def "Using #argument to get latest letter request"() {
        given:
        HscLetterRequestVO hscLetterRequestVO = new HscLetterRequestVO(hscID: HSC_ID)
        HscLetterRequestVO returnedHscLetter

        when:
        returnedHscLetter = hscLetterRequest.getLatestLetterPreRequestByTemplate(HSC_ID, templateID)

        then:
        1 * dao.list(_ as QueryProperties) >> { QueryProperties qp ->
            assert qp.filterType == QueryProperties.FilterType.NEW_FILTER
            assert qp.getQueryFilter(FieldConstants.HSCID).fieldValue == HSC_ID
            assert qp.getQueryFilter(FieldConstants.TEMPLATEID).fieldValue == templateID
            assert qp.getQueryFilter(FieldConstants.LETTERREQUESTSTATUSTYPE).fieldValue ==  HsrReferenceConstants.HSCLETTERREQUEST_TEMPLATEPREREQUEST
            [hscLetterRequestVO]
        }
        0 * _

        expect:
        hscLetterRequestVO.equals(returnedHscLetter)

        where:
        templateID | _
        "1"        | _
        ""         | _

        argument = templateID ?: "nothing"
    }

    def "test readCascading"() {
        given:
        HscLetterRequestDecisionVO hscLetterRequestDecisionVO = new HscLetterRequestDecisionVO(hscID: HSC_ID)
        def isBedDayDecision = hscLetterRequestDecisionVO.isBedDayDecision()
        HscLetterRequestVO cascadeVOs = getRequestVO()
        cascadeVOs.hscLetterRequestDiagnosisVOs = [new HscLetterRequestDiagnosisVO(hscID: HSC_ID)]
        cascadeVOs.hscLetterRequestAttributeVOs = [new HscLetterRequestAttributeVO(hscID: HSC_ID)]
        cascadeVOs.hscLetterRequestDecisionVOs = [hscLetterRequestDecisionVO]

        // TABLE DEFINITION(S)
        LogicTypeFactory.putInstance(TableConstants.HSC_LTR_REQ_DIAG, hscLetterRequestDiagnosis as ReadLogic<? extends ValueObject>)

        // QUERY PROPERTIES
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        qp.addQueryFilter(new QueryFilter(FieldConstants.HSCID, HSC_ID))
        qp.addQueryFilter(new QueryFilter(FieldConstants.LETTERREQUESTSEQNUM, LETTER_SEQ_NUM))

        // READ PROPERTIES
        ReadProperties rp = getReadProperties()

        when:
        HscLetterRequestVO hscLetterRequestVO = hscLetterRequest.readCascading(HSC_ID, LETTER_SEQ_NUM)

        then:
        1 * dao.read(rp) >> cascadeVOs
        // cascade read(s)
        1 * hscLetterRequestDiagnosis.getTableDef() >> TableDefFactory.getTableDef(HscLetterRequestDiagnosisVO)
        1 * hscLetterRequestDiagnosis.list(qp) >> cascadeVOs.hscLetterRequestDiagnosisVOs
        1 * hscLetterRequestAttribute.getTableDef() >> TableDefFactory.getTableDef(HscLetterRequestAttributeVO)
        1 * hscLetterRequestAttribute.list(qp) >> cascadeVOs.hscLetterRequestAttributeVOs
        1 * hscLetterRequestDecision.getTableDef() >> TableDefFactory.getTableDef(HscLetterRequestDecisionVO)
        1 * hscLetterRequestDecision.list(qp) >> cascadeVOs.hscLetterRequestDecisionVOs
        0 * _

        expect:
        hscLetterRequestVO == cascadeVOs
        hscLetterRequestVO.hscID == HSC_ID && hscLetterRequestVO.letterRequestSeqNum == LETTER_SEQ_NUM
        hscLetterRequestVO.hscLetterRequestDiagnosisVOs.size() == 1
        hscLetterRequestVO.hscLetterRequestAttributeVOs.size() == 1
        hscLetterRequestVO.hscLetterRequestDecisionVOs.size() == 1
        hscLetterRequestVO.hscLetterRequestDiagnosisVOs.first().hscID == HSC_ID
        hscLetterRequestVO.hscLetterRequestAttributeVOs.first().hscID == HSC_ID
        hscLetterRequestVO.hscLetterRequestDecisionVOs.first().hscID == HSC_ID
    }

    def "getReadProperties: return read property object using HSC ID"() {
        when:
        ReadProperties rp = hscLetterRequest.getReadProperties(HSC_ID, LETTER_SEQ_NUM, "")

        then:
        rp.keyMap[key] == value
        0 * _

        where:
        key                                | value
        FieldConstants.HSCID               | HSC_ID
        FieldConstants.LETTERREQUESTSEQNUM | LETTER_SEQ_NUM
    }

    def "isValid"() {
        when:
        Boolean valid = hscLetterRequest.isValid(HSC_ID, LETTER_SEQ_NUM)

        then:
        1 * dao.isValid(_ as ReadProperties) >> { ReadProperties rp ->
            assert rp.getKeyValue(FieldConstants.HSCID) == HSC_ID
            assert rp.getKeyValue(FieldConstants.LETTERREQUESTSEQNUM) == LETTER_SEQ_NUM
            true
        }
        0 * _

        expect:
        valid == true
    }

    def "Attach primary diagnosis to letter request"() {
        given:
        HscLetterRequestVO vo = getRequestVO()
        HscDiagnosisVO hscDiagnosisVO = new HscDiagnosisVO(hscID: HSC_ID, diagnosisCode: "W58.01XA")

        when:
        hscLetterRequest.attachPrimaryDiagnosis(HSC_ID, vo)

        then:
        1 * hscDiagnosis.readPrimary(HSC_ID) >> hscDiagnosisVO
        0 * _

        expect:
        hscDiagnosisVO
        vo.getHscLetterRequestDiagnosisVOs().size() == 1
        vo.getHscLetterRequestDiagnosisVOs().first() in HscLetterRequestDiagnosisVO
        vo.getHscLetterRequestDiagnosisVOs().first().diagnosisCode == "W58.01XA"

    }

    def "Log tat point if complete"() {
        given:
        HscLetterRequestVO vo = new HscLetterRequestVO(letterRequestStatusType: HsrReferenceConstants.HSCLETTERREQUEST_COMPLETE)

        when:
        hscLetterRequest.logTatPointIfComplete(vo)

        then:
        1 * hscTatPointHelper.logWrittenNotificationTatPoint(vo)
        0 * _
    }

    def "Reading oldest waiting letter request using Service Reference Number"() {
        when:
        HscLetterRequestVO hscLetterRequestVO = hscLetterRequest.readOldestWaitingForSRN(SERVICE_REF_NUM)

        then:
        1 * dao.list(_ as QueryProperties) >> { QueryProperties qp ->
            assert qp.getQueryFilter(FieldConstants.SERVICEREFERENCENUM).fieldValue == SERVICE_REF_NUM
            assert qp.getQueryFilter(FieldConstants.LETTERREQUESTSTATUSTYPE).fieldValue == HsrReferenceConstants.HSCLETTERREQUEST_WAITINGFORCOMPLETE
            [new HscLetterRequestVO(letterRequestSeqNum: SERVICE_REF_NUM, letterRequestStatusType: HsrReferenceConstants.HSCLETTERREQUEST_WAITINGFORCOMPLETE)]
        }
        0 * _

        expect:
        hscLetterRequestVO.letterRequestSeqNum == SERVICE_REF_NUM
        hscLetterRequestVO.letterRequestStatusType == HsrReferenceConstants.HSCLETTERREQUEST_WAITINGFORCOMPLETE
    }

    def "hasSentGracePeriodNotification"() {
        when:
        Boolean notificationSent = hscLetterRequest.hasSentGracePeriodNotification(HSC_ID)

        then:
        1 * dao.exists(_ as QueryProperties) >> { QueryProperties qp ->
            assert qp.getQueryFilter(FieldConstants.HSCID).fieldValue == HSC_ID
            assert qp.getQueryFilter(FieldConstants.TEMPLATEID).fieldValue == HsrConstants.LETTER_TEMPLATE_TYPE_GRACE_PERIOD
            assert qp.getQueryFilter(FieldConstants.LETTERREQUESTSTATUSTYPE).fieldValue == HsrReferenceConstants.HSCLETTERREQUEST_COMPLETE
            assert qp.filterType == QueryProperties.FilterType.LIST_ALL
            true
        }
        0 * _

        expect:
        notificationSent
    }

    def "getLatestLetterByTemplate: get latest letter using HSD ID and Template ID"() {
        given:
        String templateID = HsrConstants.LETTER_TEMPLATE_TYPE_GRACE_PERIOD

        when:
        HscLetterRequestVO hscLetterRequestVO = hscLetterRequest.getLatestLetterByTemplate(HSC_ID, templateID)

        then:
        1 * dao.list(_ as QueryProperties) >> { QueryProperties qp ->
            assert qp.getQueryFilter(FieldConstants.HSCID).fieldValue == HSC_ID
            assert qp.getQueryFilter(FieldConstants.TEMPLATEID).fieldValue == templateID
            assert qp.filterType == QueryProperties.FilterType.NEW_FILTER
            [new HscLetterRequestVO(hscID: HSC_ID, templateID: templateID)]
        }
        0 * _

        expect:
        hscLetterRequestVO.hscID == HSC_ID
        hscLetterRequestVO.templateID == templateID
    }

    private HscLetterRequestVO getRequestVO() {
        HscLetterRequestVO valueObject = new HscLetterRequestVO()
        valueObject.setHscID(HSC_ID)
        valueObject.setLetterRequestSeqNum(LETTER_SEQ_NUM)
        valueObject.setCreateDateTime(UhgCalendarUtilities.getTodaysCalendarInUserTimeZone())

        return valueObject
    }

    private ReadProperties getReadProperties(String... readFields) {
        ReadProperties rp = new ReadProperties(hscLetterRequest.getTableDef().getKey());
        rp.setKeyValue(FieldConstants.HSCID, HSC_ID);
        rp.setKeyValue(FieldConstants.LETTERREQUESTSEQNUM, LETTER_SEQ_NUM);
        rp.setFields(readFields);
        return rp;
    }

    private QueryProperties getHscLetterRequestQueryProperties() {
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.NEW_FILTER)
        qp.addQueryFilter(new QueryFilter(FieldConstants.HSCID, HSC_ID))
        qp.addQueryFilter(new QueryFilter(FieldConstants.LETTERREQUESTSEQNUM, LETTER_SEQ_NUM))
        return qp
    }
}
