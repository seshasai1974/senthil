package com.optum.app.ocm.hsr

import com.optum.app.ocm.common.activity.businesslogic.Activity
import com.optum.app.ocm.common.member.businesslogic.Member
import com.optum.app.ocm.ref.businesslogic.CustomerReference
import com.optum.rf.bl.businesslogic.HistoryBusinessLogic
import com.optum.rf.bl.spring.TransactionInterceptor
import com.optum.rf.common.settings.businesslogic.SystemSettingsFramework
import com.optum.rf.core.locator.ServiceLocator
import com.optum.rf.core.util.UhgCalendar
import com.optum.rf.dao.controller.session.SessionThreadLocal
import com.optum.rf.dao.data.ValueObject
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.util.UhgCalendarUtilities
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.optum.app.common.activity.data.ActivityVO
import com.optum.app.common.constants.ActivityReferenceConstants
import com.optum.app.common.constants.ReferenceCustomFilterConstants
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.*
import com.optum.app.common.hsr.businesslogic.impl.HscServiceNonFacilityImpl
import com.optum.app.common.hsr.constants.HsrReferenceConstants
import com.optum.app.common.hsr.data.HscServiceNonFacilityVO
import com.optum.app.common.hsr.data.HscServiceVO
import com.optum.app.common.hsr.data.HscVO
import com.optum.app.constants.HscConstants

class HscServiceNonFacilitySpec extends HsrReadLogicSpecification {

	HscServiceNonFacilityImpl hscServiceNonFacility

	Activity activity
	DataAccessObject dao
	HistoryBusinessLogic historyBusinessLogic
	Hsc hsc
	HscDiagnosis hscDiagnosis
	HscService hscService
	HscServiceFacility hscServiceFacility
	HscServiceSpecialSavings hscServiceSpecialSavings
	PersistenceHelper persistenceHelper
	CustomerReference customerReference
	ServiceLocator serviceLocator
	SystemSettingsFramework systemSettingsFramework
	HscTatPointHelper tatPointHelper
	TransactionInterceptor transactionInterceptor
    Member member
    HscAlternateIdentifier hscAlternateIdentifier;

	def setup() {
        SessionThreadLocal.removeSession()
        
		hscServiceNonFacility = new HscServiceNonFacilityImpl()


		activity = Mock(Activity)
		dao = Mock(DataAccessObject)
		historyBusinessLogic = Mock(HistoryBusinessLogic)
		hsc = Mock(Hsc)
		hscDiagnosis = Mock(HscDiagnosis)
		hscService = Mock(HscService)
		hscServiceFacility = Mock(HscServiceFacility)
        hscAlternateIdentifier = Mock(HscAlternateIdentifier)
		hscServiceSpecialSavings = Mock(HscServiceSpecialSavings)
		persistenceHelper = Mock(PersistenceHelper)
        customerReference = Mock(CustomerReference)
		serviceLocator = Mock(ServiceLocator)
		systemSettingsFramework = Mock(SystemSettingsFramework)
		tatPointHelper = Mock(HscTatPointHelper)
		transactionInterceptor = Mock(TransactionInterceptor)
        member = Mock(Member)

		hscServiceNonFacility.setRequiredActivity(activity)
		hscServiceNonFacility.setRequiredDao(dao)
		hscServiceNonFacility.setRequiredHistoryBusinessLogic(historyBusinessLogic)
		hscServiceNonFacility.setRequiredHsc(hsc)
		hscServiceNonFacility.setRequiredHscService(hscService)
		hscServiceNonFacility.setRequiredPersistenceHelper(persistenceHelper)
		hscServiceNonFacility.setRequiredCustomerReference(customerReference)
		hscServiceNonFacility.setRequiredServiceLocator(serviceLocator)
		hscServiceNonFacility.setRequiredTatPointHelper(tatPointHelper)
		hscServiceNonFacility.setRequiredTransactionInterceptor(transactionInterceptor)
        hscServiceNonFacility.setRequiredHscAlternateIdentifier(hscAlternateIdentifier)
	}

	def "Test Valid Add"() {
		setup:
		def hscServiceNonFacilityVO = createValidVO()

		when:
		hscServiceNonFacility.add(hscServiceNonFacilityVO)

        then:
        1 * hscService.read(5000000, 1, [])
        1 * hscService.readFirstNonFullLockHscServiceVO(5000000)
        2 * hsc.readUnhydrated(hscServiceNonFacilityVO.getHscID()) >> new HscVO(hscID: hscServiceNonFacilityVO.getHscID(), specialProcessType: 06)
        1 * dao.read(_ as ReadProperties) >> hscServiceNonFacilityVO
        1 * customerReference.validateReferenceChildFilter(hscServiceNonFacilityVO, FieldConstants.PLACEOFSERVICECODE, hscServiceNonFacilityVO.getPlaceOfServiceCode(), FieldConstants.SERVICEDETAILTYPE, hscServiceNonFacilityVO.getServiceDetailType())
        1 * persistenceHelper.add(hscServiceNonFacilityVO)
        1 * historyBusinessLogic.addHistoryVO(_ as ValueObject)
        1 * hscAlternateIdentifier.read(hscServiceNonFacilityVO.getHscID(), HsrReferenceConstants.HSCALTERNATEIDTYPE_CAREONE_CASE_NUMBER)
        0 * _

        expect:
        !hscServiceNonFacilityVO.errorMessagesExist()
	}

    def "Test Valid Update"() {
        setup:
        def hscServiceNonFacilityVO = createValidVO()

        when:
        hscServiceNonFacility.update(hscServiceNonFacilityVO)

        then:
        2 * hsc.readUnhydrated(hscServiceNonFacilityVO.getHscID()) >> new HscVO(hscID: hscServiceNonFacilityVO.getHscID(), specialProcessType: 06)
        1 * hscService.read(5000000, 1, [])
        1 * hscService.readFirstNonFullLockHscServiceVO(5000000)
        1 * dao.read(_ as ReadProperties) >> hscServiceNonFacilityVO
        1 * customerReference.validateReferenceChildFilter(hscServiceNonFacilityVO, FieldConstants.PLACEOFSERVICECODE, hscServiceNonFacilityVO.getPlaceOfServiceCode(), FieldConstants.SERVICEDETAILTYPE, hscServiceNonFacilityVO.getServiceDetailType())
        1 * persistenceHelper.update(hscServiceNonFacilityVO)
        1 * historyBusinessLogic.addHistoryVO(_ as ValueObject)
        1 * hscAlternateIdentifier.read(hscServiceNonFacilityVO.getHscID(), HsrReferenceConstants.HSCALTERNATEIDTYPE_CAREONE_CASE_NUMBER)
        0 * _

        expect:
        !hscServiceNonFacilityVO.errorMessagesExist()
    }

    def "Test is it valid"(){
        when:
        hscServiceNonFacility.isValid((long) 1, (short) 2)

        then:
        1 * dao.isValid(_ as ReadProperties)
        0 * _
    }

    def "Test Valid Delete"() {
        setup:
        def vo = createValidVO()

        when:
        hscServiceNonFacility.delete(vo)

        then:
        1 * persistenceHelper.delete(_ as HscServiceNonFacilityVO)
        0 * _

        expect:
        !vo.errorMessagesExist()
    }

    def "Test for read functionality"(){
        setup:
        HscServiceNonFacilityVO vo = new HscServiceNonFacilityVO(hscID: 123456789, serviceSeqNum: 1)

        when:
        hscServiceNonFacility.read(123456789, (short) 2)

        then:
        1 * dao.read(_)
        0 * _
    }

    def "Test for outpatient primary service"(){
        given:
        long hscId = 1234
        HscServiceNonFacilityVO hscServiceNonFacilityVO = new HscServiceNonFacilityVO()
        HscVO hscVO = new HscVO(serviceSettingType: "2")
        List<HscServiceVO> serviceList = [new HscServiceVO(serviceSeqNum: 1)]

        when:
        hscServiceNonFacilityVO = hscServiceNonFacility.getOutpatientPrimaryService(hscId)

        then:
        1 * hsc.readUnhydrated(hscId) >> hscVO
        1 * hscService.list(_) >> serviceList
        1 * dao.read(_ as ReadProperties) >> hscServiceNonFacilityVO
        0 * _
    }

    def "Test to get service start date"(){
        given:
        long hscId = 1234
        short serviceSeqNumber = 1
        HscServiceNonFacilityVO hscServiceNonFacilityVO = new HscServiceNonFacilityVO(serviceStartDate: UhgCalendarUtilities.getTodaysDate())
        Date serviceStartDate = UhgCalendarUtilities.getTodaysDate()

        when:
        hscServiceNonFacility.getServiceStartDate(hscId, serviceSeqNumber)

        then:
        1 * dao.read(_ as ReadProperties) >> hscServiceNonFacilityVO
        0 * _
        serviceStartDate == hscServiceNonFacilityVO.getServiceStartDate()
    }

    def "Test to set the notification retrospective Indicator"(){
        given:
        HscServiceNonFacilityVO vo = new HscServiceNonFacilityVO(advanceNotifyTransactionID: 1234,serviceEndDate: UhgCalendarUtilities.getTodaysDate(), advanceNotifyDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone())
        Date communicationDtTime = new Date()

        when:
        hscServiceNonFacility.setNotificationRetrospectiveIndicator(vo)

        then:
        0 * _
    }

    def "Test to get the list of advanced notification"(){
        given:
        long hscID = 1234
        long advanceNotifyTransactionID = 2345
        short i = 1

        when:
        hscServiceNonFacility.listByAdvancedNotification(hscID, advanceNotifyTransactionID,i)

        then:
        1 * dao.list(_)
        0 * _
    }

    def "Test to get list by hscID"() {
        when:
        hscServiceNonFacility.listByHscID(123456789)

        then:
        1 * dao.list(_)  >> new ArrayList<HscServiceNonFacilityVO>()
        0 * _
    }

    def "Test to validate Procedure Type UOM Combination"(){
        given:
        String procCodeType = "4"
        String procCode = "T1000"
        HscVO hscVO = new HscVO()
        HscServiceNonFacilityVO hscServiceNonFacilityVO = new HscServiceNonFacilityVO()

        when:
        hscServiceNonFacility.validateProcTypeUOMCombination(hscServiceNonFacilityVO, procCodeType, procCode )

        then:
        1 * hsc.readUnhydrated(_) >> hscVO
        1 * customerReference.isValidReferenceCustomFilter(_,_,_)
        0 * _
    }

    def "Test to validate Procedure Type UOM Combination : if procCode = T1000"(){
        given:
        String procCodeType = "123"
        String procCode = "456"
        HscVO hscVO = new HscVO()
        HscServiceNonFacilityVO hscServiceNonFacilityVO = new HscServiceNonFacilityVO()

        when:
        hscServiceNonFacility.validateProcTypeUOMCombination(hscServiceNonFacilityVO, procCodeType, procCode )

        then:
        1 * hsc.readUnhydrated(_) >> hscVO
        1 * customerReference.isValidReferenceCustomFilter(_,_,_)
        0 * _
    }

    def "Test of validations for complete intake"() {
        setup:
        def hscServiceNonFacilityVO = createValidVO()
        def hscVO = new HscVO(hscID: hscServiceNonFacilityVO.getHscID(), specialProcessType: 06)

        when:
        hscServiceNonFacility.validateForCompleteIntake(hscServiceNonFacilityVO.getHscID(), hscServiceNonFacilityVO.getServiceSeqNum(), HsrReferenceConstants.PROCCODETYPE_CPT, HscConstants.HSCSERVICE_SUFFIX)

        then:
        2 * dao.read(_ as ReadProperties) >> hscServiceNonFacilityVO
        2 * hsc.readUnhydrated(hscServiceNonFacilityVO.getHscID()) >> hscVO
        1 * customerReference.isValidReferenceCustomFilter(ReferenceCustomFilterConstants.PROC_UOM_OTHER, FieldConstants.PROCEDUREUNITOFMEASURETYPE, hscServiceNonFacilityVO.getProcedureUnitOfMeasureType()) >> true
        0 * _

        expect:
        !hscServiceNonFacilityVO.errorMessagesExist()
    }

    def "Test to validate the required fields"() {
        setup:
        def hscServiceNonFacilityVO = new HscServiceNonFacilityVO(hscID: 5000000,
                serviceSeqNum: 1,
                placeOfServiceCode: HsrReferenceConstants.PLACEOFSERVICE_OFFICE,
                serviceDetailType: HsrReferenceConstants.SERVICEDETAILTYPE_MEDICATIONS,
                serviceDescriptionType: "Medications",
                expandedIntake: true,
                procedureUnitCount: 1,
                procedureUnitOfMeasureType: procedureUnitOfMeasureType,
                unitPerFrequencyCount: unitPerFrequencyCount,
                procedureFrequencyType: procedureFrequencyType,
                skipDatesValidation: true,
                serviceStartDate: UhgCalendar.getSQLDate("04-11-2013"),
                serviceEndDate: UhgCalendar.getSQLDate("04-11-2013"),
        )

        def hscVO = new HscVO(hscID: hscServiceNonFacilityVO.getHscID(), specialProcessType: specialProcessType, umResponsibilityType: umResponsibilityType)

        when:
        hscServiceNonFacility.validateRequiredFields(hscServiceNonFacilityVO)

        then:
        1 * hsc.readUnhydrated(hscServiceNonFacilityVO.getHscID()) >> hscVO
        validationErrors == hscServiceNonFacilityVO.errorMessagesExist()

        where:
        specialProcessType                                           |  umResponsibilityType                                         | procedureUnitOfMeasureType | unitPerFrequencyCount |  procedureFrequencyType | placeOfService                              | serviceDetailType                               | serviceDescriptionType                                 | validationErrors
        HsrReferenceConstants.SPECIALPROCESSTYPE_PACIFICARE          |  HsrReferenceConstants.UMRESPONSIBILITYTYPE_PMG_CASE          |         null               |            0          |          null           | HsrReferenceConstants.PLACEOFSERVICE_OFFICE | HsrReferenceConstants.SERVICEDETAILTYPE_MEDICAL | HsrReferenceConstants.SERVICEDESCRIPTIONTYPE_SCHEDULED |  false
        HsrReferenceConstants.SPECIALPROCESSTYPE_PACIFICARE          |  !equals(HsrReferenceConstants.UMRESPONSIBILITYTYPE_PMG_CASE) |         null               |            0          |          null           | HsrReferenceConstants.PLACEOFSERVICE_OFFICE | HsrReferenceConstants.SERVICEDETAILTYPE_MEDICAL | HsrReferenceConstants.SERVICEDESCRIPTIONTYPE_SCHEDULED |  true
        !equals(HsrReferenceConstants.SPECIALPROCESSTYPE_PACIFICARE) |  null                                                         |         null               |            0          |          null           | HsrReferenceConstants.PLACEOFSERVICE_OFFICE | HsrReferenceConstants.SERVICEDETAILTYPE_MEDICAL | HsrReferenceConstants.SERVICEDESCRIPTIONTYPE_SCHEDULED |  true
        !equals(HsrReferenceConstants.SPECIALPROCESSTYPE_PACIFICARE) |  null                                                         |         !null              |            1          |         !null           | HsrReferenceConstants.PLACEOFSERVICE_OFFICE | HsrReferenceConstants.SERVICEDETAILTYPE_MEDICAL | HsrReferenceConstants.SERVICEDESCRIPTIONTYPE_SCHEDULED |  false
        !equals(HsrReferenceConstants.SPECIALPROCESSTYPE_PACIFICARE) |  null                                                         |         !null              |            1          |         !null           | HsrReferenceConstants.PLACEOFSERVICE_OFFICE | HsrReferenceConstants.SERVICEDETAILTYPE_MEDICAL | HsrReferenceConstants.SERVICEDESCRIPTIONTYPE_SCHEDULED |  false
        !equals(HsrReferenceConstants.SPECIALPROCESSTYPE_PACIFICARE) |  null                                                         |         !null              |            1          |         !null           | HsrReferenceConstants.PLACEOFSERVICE_OFFICE | HsrReferenceConstants.SERVICEDETAILTYPE_MEDICAL | HsrReferenceConstants.SERVICEDESCRIPTIONTYPE_SCHEDULED |  false
        !equals(HsrReferenceConstants.SPECIALPROCESSTYPE_PACIFICARE) |  null                                                         |         null               |            1          |         !null           | HsrReferenceConstants.PLACEOFSERVICE_OFFICE | HsrReferenceConstants.SERVICEDETAILTYPE_MEDICAL | HsrReferenceConstants.SERVICEDESCRIPTIONTYPE_SCHEDULED |  true
        !equals(HsrReferenceConstants.SPECIALPROCESSTYPE_PACIFICARE) |  null                                                         |         !null              |            0          |         !null           | HsrReferenceConstants.PLACEOFSERVICE_OFFICE | HsrReferenceConstants.SERVICEDETAILTYPE_MEDICAL | HsrReferenceConstants.SERVICEDESCRIPTIONTYPE_SCHEDULED |  true
        !equals(HsrReferenceConstants.SPECIALPROCESSTYPE_PACIFICARE) |  null                                                         |         !null              |            1          |          null           | HsrReferenceConstants.PLACEOFSERVICE_OFFICE | HsrReferenceConstants.SERVICEDETAILTYPE_MEDICAL | HsrReferenceConstants.SERVICEDESCRIPTIONTYPE_SCHEDULED |  true
        !equals(HsrReferenceConstants.SPECIALPROCESSTYPE_PACIFICARE) |  null                                                         |         !null              |            1          |          null           | HsrReferenceConstants.PLACEOFSERVICE_OFFICE | HsrReferenceConstants.SERVICEDETAILTYPE_MEDICAL | HsrReferenceConstants.SERVICEDESCRIPTIONTYPE_SCHEDULED |  true
    }

    def "Test to validate required fields"(){
        given:
        HscServiceNonFacilityVO vo = new HscServiceNonFacilityVO(placeOfServiceCode: "", serviceDetailType: "", serviceDescriptionType: "", procedureUnitCount: 2)

        when:
        hscServiceNonFacility.validateRequiredFields(vo)

        then:
        0 * _
    }

    def "Test to validate service start and end dates"(){
        given:
        HscServiceNonFacilityVO vo = new HscServiceNonFacilityVO(serviceStartDate: UhgCalendarUtilities.getTodaysDate(), serviceEndDate: UhgCalendarUtilities.getYesterdaysDate() )

        when:
        hscServiceNonFacility.validateServiceDates(vo)

        then:
        0 * _
    }

    def "Test to validate service start and end dates : if start and end dates are null"(){
        given:
        HscServiceNonFacilityVO vo = new HscServiceNonFacilityVO(serviceStartDate: null, serviceEndDate: null )

        when:
        hscServiceNonFacility.validateServiceDates(vo)

        then:
        0 * _
    }

    def "Test to validate the years"(){
        given:
        HscServiceNonFacilityVO vo = new HscServiceNonFacilityVO()

        when:
        hscServiceNonFacility.validateYears(vo)

        then:
        0 * _
    }

    def "Test to validate notification data"(){
        given:
        HscServiceNonFacilityVO vo = new HscServiceNonFacilityVO()
        HscServiceNonFacilityVO oldHscServiceNonFacilityVO = new HscServiceNonFacilityVO (advanceNotifyDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone() )

        when:
        hscServiceNonFacility.validateNotificationData(vo)

        then:
        1 * dao.read(_ as ReadProperties) >> oldHscServiceNonFacilityVO
        0 * _
    }

    def "Test to validate notification data if HscServiceNonFacilityVO is null "(){
        given:
        HscServiceNonFacilityVO vo = new HscServiceNonFacilityVO(advanceNotifyDateTime: UhgCalendarUtilities.getLocalCalendar(UhgCalendarUtilities.getNextDay(UhgCalendarUtilities.getTodaysDate())) )
        HscServiceNonFacilityVO oldHscServiceNonFacilityVO = new HscServiceNonFacilityVO ()

        when:
        hscServiceNonFacility.validateNotificationData(vo)

        then:
        1 * dao.read(_ as ReadProperties) >> oldHscServiceNonFacilityVO
        0 * _
    }

    def "Test to execute Add"(){
        given:
        HscServiceNonFacilityVO vo = new HscServiceNonFacilityVO(advanceNotifyTransactionID: 1234)
        HscVO hscVO = new HscVO(hscStatusType: "1")

        when:
        hscServiceNonFacility.executeAdd(vo)

        then:
        1 * hsc.readUnhydrated(_) >> hscVO
        1 * persistenceHelper.add(_ as HscServiceNonFacilityVO)
        1 * historyBusinessLogic.addHistoryVO(_ as ValueObject)
        1 * activity.add(_)
        1 * hscService.read(_,_)
        1 * hscService.derivePotentialUrJurisdictions(_)
        1 * tatPointHelper.logIntakeCompleteTatPointForService(_,_)
        0 * _
    }

    def "Test to execute Update"(){
        given:
        HscServiceNonFacilityVO vo = new HscServiceNonFacilityVO(serviceStartDate: UhgCalendarUtilities.getTodaysDate())
        HscServiceVO hscServiceVO = new HscServiceVO(serviceSeqNum: 1)
        HscServiceVO hscServicePrimaryVO = new HscServiceVO(serviceSeqNum: 1)
        HscServiceNonFacilityVO currentVO = new HscServiceNonFacilityVO(serviceStartDate: null)
        HscVO hscVO = new HscVO(specialProcessType: "01")

        when:
        hscServiceNonFacility.executeUpdate(vo)

        then:
        1 * persistenceHelper.update(_ as HscServiceNonFacilityVO)
        1 * historyBusinessLogic.addHistoryVO(_ as ValueObject)
        1 * hscService.read(_,_) >> hscServiceVO
        1 * hscService.readFirstNonFullLockHscServiceVO(_) >> hscServicePrimaryVO
        1 * dao.read(_ as ReadProperties) >> currentVO
        1 * hsc.updateHscMemberCoverageSeqNum(_,_)
        0 * _
    }

    def "Test to log notifying activity"(){
        given:
        HscServiceNonFacilityVO hscServiceNonFacilityVO = new HscServiceNonFacilityVO()
        ActivityVO ntfyActivityVO = new ActivityVO(ActivityReferenceConstants.ACTIVITYTYPE_NOTIFICATION)

        when:
        hscServiceNonFacility.logNtfyActivity(hscServiceNonFacilityVO)

        then:
        1 * activity.add(ntfyActivityVO)
        0 * _
    }

    def "Test to track the changes on update"(){
        given:
        HscServiceNonFacilityVO updateVO = new HscServiceNonFacilityVO()
        HscServiceNonFacilityVO existingVO = new HscServiceNonFacilityVO()

        when:
        hscServiceNonFacility.trackChangesOnUpdate(updateVO, existingVO)

        then:
        0 * _
    }

    def "Test to update retrospective indicator"() {
        setup:
        def hscSrvcNonFacility = new HscServiceNonFacilityVO()

        when:
        hscServiceNonFacility.updateRetrospectiveIndicator(hscSrvcNonFacility)

        then:
        1 * persistenceHelper.updateSubset(_,_,_)
        0 * _
    }

    def "Test hasServiceDatesSpaningICDCutover"() {
        setup:
        def hscSrvcNonFacility = new HscServiceNonFacilityVO()

        when:
        hscServiceNonFacility.hasServiceDatesSpaningICDCutover(hscSrvcNonFacility)

        then:
        0 * _
    }

    def "Test checkRetrospectiveOnMultipleServices"() {
        setup:
        def hscVO = new HscVO()

        when:
        hscServiceNonFacility.checkRetrospectiveOnMultipleServices(hscVO)

        then:
        1 * dao.exists(_ as QueryProperties)
        0 * _
    }

    def "Test validateSpclCareFields"() {
        setup:
        def hscServiceNonFacilityVO = new HscServiceNonFacilityVO()

        when:
        hscServiceNonFacility.validateSpclCareFields(hscServiceNonFacilityVO)

        then:
        0 * _

        assert hscServiceNonFacilityVO.errorMessagesExist()
    }

    HscServiceNonFacilityVO createValidVO() {
        new HscServiceNonFacilityVO(hscID: 5000000,
                serviceSeqNum: 1,
                placeOfServiceCode: HsrReferenceConstants.PLACEOFSERVICE_OFFICE,
                serviceDetailType: HsrReferenceConstants.SERVICEDETAILTYPE_MEDICATIONS,
                serviceDescriptionType: "Medications",
                expandedIntake: true,
                procedureUnitCount: 1,
                procedureUnitOfMeasureType: HsrReferenceConstants.PROCEDUREUNITOFMEASURETYPE_DAYS,
                unitPerFrequencyCount: 1,
                procedureFrequencyType: HsrReferenceConstants.PROCEDUREFREQUENCY_TIMES,
                skipDatesValidation: true,
                serviceStartDate: UhgCalendar.getSQLDate("04-11-2013"),
                serviceEndDate: UhgCalendar.getSQLDate("04-11-2013")
        )
    }
}
