package com.optum.app.ocm.organization.controller

import com.optum.app.ocm.controller.support.CommonResponse
import com.optum.app.ocm.organization.businesslogic.OrganizationHelper
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.app.common.organization.data.OrganizationVO
import spock.lang.Specification

class OrganizationControllerSpec extends Specification {

    OrganizationController controller = new OrganizationController()
    OrganizationHelper organizationHelper = Mock(OrganizationHelper)

    def setup() {
        controller.organizationHelper = organizationHelper
    }

    def "get"() {

        given:
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        List<OrganizationVO> list = [new OrganizationVO(organizationID: 1, organizationShortName: 'BCBSC')]

        when:
        CommonResponse response = controller.get(qp)
        Map<String, Object> responseMap = response.getEmbedded()
        ArrayList responseVOs = (ArrayList) responseMap.get("_embedded")
        then:
        1 * organizationHelper.list(qp) >> list
        responseVOs == list
    }

    def "save"() {

        given:
        List<OrganizationVO> list = [new OrganizationVO(organizationID: 1, organizationShortName: 'BCBSC')]

        when:
        CommonResponse response = controller.save(list)
        Map<String, Object> responseMap = response.getEmbedded()
        ArrayList responseVOs = (ArrayList) responseMap.get("_embedded")

        then:
        1 * organizationHelper.save(_)
        responseVOs == list
    }

    def "getOrganizationByID"() {

        given:
        int organizationID = 1;
        OrganizationVO organizationVO = new OrganizationVO(organizationID: organizationID, organizationShortName: 'BCBSC')

        when:
        CommonResponse response = controller.getOrganizationByID(organizationID)
        Map<String, Object> responseMap = response.getEmbedded()
        OrganizationVO responseVO = (OrganizationVO) responseMap.get("_embedded")
        then:
        1 * organizationHelper.read(organizationID) >> organizationVO
        responseVO == organizationVO
    }
}
