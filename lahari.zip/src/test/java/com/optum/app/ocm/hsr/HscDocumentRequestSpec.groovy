package com.optum.app.ocm.hsr

import com.optum.app.ocm.ref.businesslogic.CustomerReference
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.optum.rf.ref.core.businesslogic.Reference
import com.optum.app.common.hsr.businesslogic.HscDocumentRequest
import com.optum.app.common.hsr.businesslogic.HscDocumentRequestAttachment
import com.optum.app.common.hsr.businesslogic.impl.HscDocumentRequestImpl
import com.optum.app.common.hsr.data.HscDocumentRequestAttachmentVO
import com.optum.app.common.hsr.data.HscDocumentRequestVO

class HscDocumentRequestSpec extends HsrReadLogicSpecification {

    HscDocumentRequest hscDocumentRequest

    DataAccessObject dao
    PersistenceHelper persistenceHelper
    CustomerReference customerReference
    HscDocumentRequestAttachment hscDocumentRequestAttachment

    def setup() {
        dao = Mock(DataAccessObject)
        persistenceHelper = Mock(PersistenceHelper)
        customerReference = Mock(CustomerReference)
        hscDocumentRequestAttachment = Mock(HscDocumentRequestAttachment)

        hscDocumentRequest = new HscDocumentRequestImpl()

        hscDocumentRequest.dao = dao
        hscDocumentRequest.setRequiredPersistenceHelper(persistenceHelper)
        hscDocumentRequest.customerReference = customerReference
        hscDocumentRequest.hscDocumentRequestAttachment = hscDocumentRequestAttachment
    }

    def "test isValid"() {
        setup:

        when:
        hscDocumentRequest.isValid(123456L)

        then:
        1 * dao.isValid(_ as ReadProperties)
        0 * _._
    }

    def "test read"() {
        setup:

        when:
        hscDocumentRequest.read(123456L)

        then:
        1 * dao.read(_ as ReadProperties)
        0 * _._
    }

    def "test saveDocument"() {
        setup:

        when:
        hscDocumentRequest.saveDocument(123456L, 123456789L, 'status', 'docID')

        then:
        1 * dao.isDuplicate(_ as QueryProperties)
        1 * persistenceHelper.add(_ as HscDocumentRequestVO)
        0 * _._
    }

    def "test updateDocument"() {
        setup:

        when:
        hscDocumentRequest.updateDocument(123L, 123456L, 123456789L, 'status', 'docID')

        then:
        1 * dao.isDuplicate(_ as QueryProperties)
        1 * persistenceHelper.add(_ as HscDocumentRequestVO)
        0 * _._
    }

    def "test deleteAll"() {
        setup:

        when:
        hscDocumentRequest.deleteAll(123L)

        then:
        1 * dao.read(_ as ReadProperties) >> new HscDocumentRequestVO()
        1 * persistenceHelper.delete(_ as HscDocumentRequestVO)
        1 * dao.read(_ as ReadProperties)
        0 * _._
    }

    def "test listByHsc"() {
        setup:

        when:
        hscDocumentRequest.listByHsc(123456L)

        then:
        1 * dao.list(_ as QueryProperties) >> [new HscDocumentRequestVO()]
        1 * hscDocumentRequestAttachment.listByDoc(0) >> [
                new HscDocumentRequestAttachmentVO(hscDocumentRequestAttachmentID: 1, originalFileFDSAttachmentID: '1'),
                new HscDocumentRequestAttachmentVO(hscDocumentRequestAttachmentID: 2)]
        0 * _._
    }

    def "test getStatusList"() {
        setup:

        when:
        hscDocumentRequest.getStatusList()

        then:
        1 * customerReference.listCachedByReferenceName( 'documentStatusType')
        0 * _._
    }

}
