package com.optum.app.ocm.cache.impl

import com.optum.app.ocm.messaging.BaseMessageNotifier
import com.optum.rf.common.cache.data.CacheRefreshVO
import spock.lang.Specification

class OcmCacheRefreshImplSpec extends Specification {

    OcmCacheRefreshImpl ocmCacheRefreshImpl = new OcmCacheRefreshImpl()

    BaseMessageNotifier baseMessageNotifier = Mock(BaseMessageNotifier)

    def setup() {
        ocmCacheRefreshImpl.baseMessageNotifier = baseMessageNotifier
    }

    def 'clearAppCaches'() {
        given:
        CacheRefreshVO cacheRefreshVO = new CacheRefreshVO(flushReferenceCache: true)

        when:
        ocmCacheRefreshImpl.clearAppCaches(cacheRefreshVO)

        then:
        1 * baseMessageNotifier.clearCustomerReferenceCache()
        1 * baseMessageNotifier.clearLocalStorageReferenceCache(_ as Date)
        0 * _
    }
}
