package com.optum.app.ocm.hsr

import com.optum.rf.bl.spring.TransactionInterceptor
import com.optum.rf.core.locator.ServiceLocator
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.HscFacilitySpecialSavings
import com.optum.app.common.hsr.businesslogic.impl.HscFacilitySpecialSavingsImpl
import com.optum.app.common.hsr.data.HscFacilitySpecialSavingsVO
import spock.lang.Unroll

class HscFacilitySpecialSavingsSpec extends HsrReadLogicSpecification {

    HscFacilitySpecialSavings hscFacilitySpecialSavings

    DataAccessObject dao
    PersistenceHelper persistenceHelper
    ServiceLocator serviceLocator
    TransactionInterceptor transactionInterceptor

    def setup() {
        dao = Mock(DataAccessObject)
        persistenceHelper = Mock(PersistenceHelper)
        serviceLocator = Mock(ServiceLocator)
        transactionInterceptor = Mock(TransactionInterceptor)

        hscFacilitySpecialSavings = new HscFacilitySpecialSavingsImpl(
                requiredDao: dao,
                requiredPersistenceHelper: persistenceHelper,
                requiredServiceLocator: serviceLocator,
                requiredTransactionInterceptor: transactionInterceptor
        )
    }

    @Unroll
    def "isValid #testCase"() {
        given:
        def hscID = (long) 1
        def yearNumber = 2
        def monthTypeID = "3"
        def rp = new ReadProperties(FieldConstants.HSCID, FieldConstants.YEARNUMBER, FieldConstants.MONTHTYPEID)
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        rp.setKeyValue(FieldConstants.YEARNUMBER, yearNumber)
        rp.setKeyValue(FieldConstants.MONTHTYPEID, monthTypeID)
        rp.fields = null

        when:
        boolean retVal = hscFacilitySpecialSavings.isValid(hscID, yearNumber, monthTypeID)

        then:
        1 * dao.isValid(rp) >> expectedVal
        0 * _
        retVal == expectedVal

        where:
        testCase | expectedVal
        "passes" | true
        "fails"  | false
    }

    def "Test to read HscFacilitySpecialSavingsVO"() {
        setup:
        def hscID = (long) 1
        def yearNumber = 2
        def monthTypeID = "3"
        HscFacilitySpecialSavingsVO hscFacilitySpecialSavingsVO = new HscFacilitySpecialSavingsVO(hscID: hscID,
                yearNumber: yearNumber, monthTypeID: monthTypeID)
        hscFacilitySpecialSavingsVO.setNumberOfDaysVisits("1")
        def rp = new ReadProperties(FieldConstants.HSCID, FieldConstants.YEARNUMBER, FieldConstants.MONTHTYPEID)
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        rp.setKeyValue(FieldConstants.YEARNUMBER, yearNumber)
        rp.setKeyValue(FieldConstants.MONTHTYPEID, monthTypeID)
        rp.fields = null

        when:
        hscFacilitySpecialSavings.read(hscID, yearNumber, monthTypeID)

        then:
        1 * dao.read(rp) >> hscFacilitySpecialSavingsVO
        0 * _
    }
}
