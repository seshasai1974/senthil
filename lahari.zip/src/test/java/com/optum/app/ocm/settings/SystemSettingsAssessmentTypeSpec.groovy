package com.optum.app.ocm.settings

import com.optum.rf.core.util.Environment
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.optum.rf.test.core.spock.BaseReadLogicSpecification
import com.optum.app.ocm.common.settings.SystemSettingsAssessmentTypeImpl
import com.optum.app.ocm.common.settings.data.SystemSettingsAssessmentTypeVO

class SystemSettingsAssessmentTypeSpec extends BaseReadLogicSpecification {

    SystemSettingsAssessmentTypeImpl systemSettingsAssessmentType
    Environment environment
    DataAccessObject dao
    PersistenceHelper persistenceHelper

    def setup() {
        environment = Mock(Environment)
        dao = Mock(DataAccessObject)
        persistenceHelper = Mock(PersistenceHelper)

        systemSettingsAssessmentType = new SystemSettingsAssessmentTypeImpl()

        systemSettingsAssessmentType.environment = environment
        systemSettingsAssessmentType.dao = dao
        systemSettingsAssessmentType.setRequiredPersistenceHelper(persistenceHelper)
    }

    /**
     * Test valid add.
     */
    def "Test Valid Add"() {
        setup:
        def vo = new SystemSettingsAssessmentTypeVO(systemSettingID: 1, environmentID: 'A', assessmentType: '123', builderAssessmentID: '456')

        when:
        systemSettingsAssessmentType.add(vo)

        then:
        1 * persistenceHelper.add(_ as SystemSettingsAssessmentTypeVO)
        0 * _

        expect:
        !vo.errorMessagesExist()
    }

    /**
     * Test valid delete.
     */
    def "Test Valid Delete"() {
        setup:
        def vo = new SystemSettingsAssessmentTypeVO()

        when:
        systemSettingsAssessmentType.delete(vo)

        then:
        1 * persistenceHelper.delete(_ as SystemSettingsAssessmentTypeVO)
        0 * _

        expect:
        !vo.errorMessagesExist()
    }

    /**
     * Test valid update.
     */
    def "Test Valid Update"() {
        setup:
        def vo = new SystemSettingsAssessmentTypeVO(systemSettingID: 1, environmentID: 'A', assessmentType: '123', builderAssessmentID: '456')

        when:
        systemSettingsAssessmentType.update(vo)

        then:
        1 * persistenceHelper.update(_ as SystemSettingsAssessmentTypeVO)
        0 * _

        expect:
        !vo.errorMessagesExist()
    }
}
