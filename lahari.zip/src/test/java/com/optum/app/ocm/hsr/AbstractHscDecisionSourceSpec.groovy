package com.optum.app.ocm.hsr

import com.optum.app.ocm.ref.businesslogic.CustomerReference
import com.optum.rf.common.messages.GlobalMessages
import com.optum.rf.dao.data.message.ConditionalErrorMessage
import com.optum.rf.dao.exception.UhgRuntimeException
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.optum.rf.test.core.mock.spring.MockTransactionInterceptor
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.Hsc
import com.optum.app.common.hsr.constants.HsrReferenceConstants
import com.optum.app.common.hsr.data.HscServiceDecisionSourceVO
import com.optum.app.common.hsr.data.HscVO
import com.optum.app.common.hsr.messages.HscDecisionMessages

class AbstractHscDecisionSourceSpec extends HsrReadLogicSpecification {
    AbstractHscDecisionSourceImpl hscServiceDecisionSource
    PersistenceHelper persistenceHelper
    CustomerReference customerReference
    Hsc hsc

    def setup() {
        hscServiceDecisionSource = new AbstractHscDecisionSourceImpl()
        persistenceHelper = Mock(PersistenceHelper)
        customerReference = Mock(CustomerReference)
        hsc = Mock(Hsc)
        hscServiceDecisionSource.setRequiredPersistenceHelper(persistenceHelper)
        hscServiceDecisionSource.setRequiredCustomerReference(customerReference)
        hscServiceDecisionSource.setRequiredTransactionInterceptor(new MockTransactionInterceptor())
        hscServiceDecisionSource.setRequiredHsc(hsc)
    }

    def "Valid Delete should not produce RuntimeException, Error Messages"(){
        given:
        HscServiceDecisionSourceVO vo = createHscServiceDecisionSourceVO("1", "1")

        when:
        hscServiceDecisionSource.delete(vo)

        then:
        1*persistenceHelper.delete(vo)
        0*_
        !vo.errorMessagesExist()
        notThrown UhgRuntimeException
    }

    private HscServiceDecisionSourceVO createHscServiceDecisionSourceVO(String decisionSourceType, String criteriaID) {
        HscServiceDecisionSourceVO hscServiceDecisionSourceVO = new HscServiceDecisionSourceVO(criteriaID: criteriaID,decisionSourceType:decisionSourceType,
                decisionSeqNum: 1,hscID: 34567)
        return hscServiceDecisionSourceVO
    }
}