package com.optum.app.ocm.common

import com.optum.app.ocm.common.common.businesslogic.impl.ControllerHelperImpl
import com.optum.rf.dao.sql.query.QueryCriteria
import com.optum.rf.dao.sql.query.QueryFilter
import com.optum.rf.dao.sql.query.QueryProperties
import com.uhg.app.common.constants.spclcare.FieldConstants

import java.text.SimpleDateFormat

class ControllerHelperSpec extends CommonReadLogicSpecification {
    private ControllerHelperImpl helper

    def setup() {
        helper = new ControllerHelperImpl ()
    }

    def "covertStringToDate"() {
        given:
        def dateTimeString = "2000-01-01T12:00:00.000Z"
        Date dateTime = new SimpleDateFormat("yyyy-MM-dd").parse(dateTimeString)

        when:
        def returnDate = helper.covertStringToDate(dateTimeString)

        then:
        returnDate == new java.sql.Date(dateTime.time)
        0 * _
    }

    def "covertStringToDate empty string"() {
        given:
        def dateTimeString = ""

        when:
        def returnDate = helper.covertStringToDate(dateTimeString)

        then:
        returnDate == null
        0 * _
    }

    def "getQueryProperties no properties"() {
        given:
        QueryProperties qp = null

        when:
        def qpReturn = helper.getQueryProperties(qp)

        then:
        qpReturn
        0 * _
    }

    def "getQueryProperties"() {
        given:
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        qp.addQueryFilter(new QueryFilter(FieldConstants.CREATEDATETIME, "2000-01-01 12:00:00"))

        when:
        def qpReturn = helper.getQueryProperties(qp)

        then:
        qpReturn
        0 * _
    }

    def "getQueryProperties filter GREATER_THAN_EQUAL"() {
        given:
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        qp.addQueryFilter(new QueryFilter(FieldConstants.CREATEDATETIME, "2000-01-01 12:00:00", QueryCriteria.GREATER_THAN_EQUAL))

        when:
        def qpReturn = helper.getQueryProperties(qp)

        then:
        qpReturn
        0 * _
    }

    def "getQueryProperties filter LESS_THAN_EQUAL"() {
        given:
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        qp.addQueryFilter(new QueryFilter(FieldConstants.CREATEDATETIME, "2000-01-01 12:00:00", QueryCriteria.LESS_THAN_EQUAL))

        when:
        def qpReturn = helper.getQueryProperties(qp)

        then:
        qpReturn
        0 * _
    }

    def "getQueryProperties filter EQUAL"() {
        given:
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        qp.addQueryFilter(new QueryFilter(FieldConstants.CREATEDATETIME, "2000-01-01 12:00:00", QueryCriteria.EQUAL))

        when:
        def qpReturn = helper.getQueryProperties(qp)

        then:
        qpReturn
        0 * _
    }
}
