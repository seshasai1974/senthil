package com.optum.app.ocm.hsr

import com.optum.app.common.hsr.businesslogic.HscServiceDetail
import com.optum.app.common.hsr.businesslogic.impl.HscServiceDetailImpl
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.ReadProperties

class HscServiceDetailSpec extends HsrReadLogicSpecification {

    HscServiceDetail hscServiceDetail

    DataAccessObject dao

    def setup() {
        hscServiceDetail = new HscServiceDetailImpl()

        dao = Mock(DataAccessObject)

        hscServiceDetail.dao = dao
    }

    def "Test is it valid"(){
        when:
        hscServiceDetail.isValid((long) 1, (short) 2)

        then:
        1 * dao.isValid(_ as ReadProperties)
        0 * _
    }

    def "Test for read functionality"(){
        when:
        hscServiceDetail.read(123456789, (short) 2)

        then:
        1 * dao.read(_)
        0 * _
    }

}
