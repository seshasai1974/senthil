package com.optum.app.ocm.hsr

import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.optum.app.ocm.ref.businesslogic.CustomerReference
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.impl.HscAlternateIdentifierImpl
import com.optum.app.common.hsr.constants.HsrReferenceConstants
import com.optum.app.common.hsr.data.HscAlternateIdentifierVO
import com.optum.app.common.hsr.messages.HscMessages

class HscAlternateIdentifierSpec extends HsrReadLogicSpecification {

    HscAlternateIdentifierImpl hscAlternateIdentifierImpl

    PersistenceHelper persistenceHelper
    DataAccessObject dao
    CustomerReference customerReference

    def setup() {
        persistenceHelper = Mock(PersistenceHelper)
        dao = Mock(DataAccessObject)
        customerReference = Mock(CustomerReference)
        hscAlternateIdentifierImpl = new HscAlternateIdentifierImpl(
                requiredPersistenceHelper: persistenceHelper,
                requiredDao: dao,
                requiredCustomerReference: customerReference)
    }

    def "test listByHscSortByIdType"() {
        given:
        long hscID = 1
        List<HscAlternateIdentifierVO> unsortedList = [
                new HscAlternateIdentifierVO(hscAlternateIDType: HsrReferenceConstants.HSCALTERNATEIDTYPE_STARSAPPEALSNUMBER, hscAlternateID: 'A'),
                new HscAlternateIdentifierVO(hscAlternateIDType: HsrReferenceConstants.HSCALTERNATEIDTYPE_CAREPLANNERCASENUMBER, hscAlternateID: 'B'),
                new HscAlternateIdentifierVO(hscAlternateIDType: HsrReferenceConstants.HSCALTERNATEIDTYPE_EXTERNALPMGCASENUMBER, hscAlternateID: 'C')
        ]
        QueryProperties qp = null

        when:
        List<HscAlternateIdentifierVO> sortedList = hscAlternateIdentifierImpl.listByHscSortByIdType(hscID)

        then:
        1 * dao.list({qp = it}) >> unsortedList.collect {it} // collect a new list so the original doesn't change (need it to compare order at the end)
        with(customerReference) {
            1 * getReferenceDisplay(FieldConstants.HSCALTERNATEIDTYPE, HsrReferenceConstants.HSCALTERNATEIDTYPE_STARSAPPEALSNUMBER) >> 'STARS Appeals Num'
            1 * getReferenceDisplay(FieldConstants.HSCALTERNATEIDTYPE, HsrReferenceConstants.HSCALTERNATEIDTYPE_CAREPLANNERCASENUMBER) >> 'CarePlanner Case Num'
            1 * getReferenceDisplay(FieldConstants.HSCALTERNATEIDTYPE, HsrReferenceConstants.HSCALTERNATEIDTYPE_EXTERNALPMGCASENUMBER) >> 'ExternalPMG Case Num'
        }
        0 * _._
        sortedList.size() == unsortedList.size()

        sortedList[0] == unsortedList[1]
        sortedList[1] == unsortedList[2]
        sortedList[2] == unsortedList[0]
        qp.getQueryFilter(FieldConstants.HSCID).fieldValue == hscID
    }

    def "test loadDefaultValueObject"() {
        given:
        HscAlternateIdentifierVO hscAlternateIdentifierVO = new HscAlternateIdentifierVO()

        when:
        hscAlternateIdentifierImpl.loadDefaultValueObject(hscAlternateIdentifierVO)

        then:
        0 * _._
        hscAlternateIdentifierVO.newInd
    }

    def "test sortIdentifiers"() {
        given:
        List<HscAlternateIdentifierVO> hscAlternateIdentifierList = [
                new HscAlternateIdentifierVO(newInd: true), // should be added
                new HscAlternateIdentifierVO(), // should remain persisted
                new HscAlternateIdentifierVO(deleteIndicator: true), // should be deleted
                new HscAlternateIdentifierVO(newInd: true, deleteIndicator: true) // nothing should happen
        ]
        List<HscAlternateIdentifierVO> persistedIdentifierList = []
        List<HscAlternateIdentifierVO> deleteIdentifierList = []
        List<HscAlternateIdentifierVO> newIdentifierList = []

        when:
        hscAlternateIdentifierImpl.sortIdentifiers(hscAlternateIdentifierList, persistedIdentifierList, deleteIdentifierList, newIdentifierList)

        then:
        0 * _._
        persistedIdentifierList == [hscAlternateIdentifierList[1]]
        deleteIdentifierList == [hscAlternateIdentifierList[2]]
        newIdentifierList == [hscAlternateIdentifierList[0]]
    }

    def "test delete list"() {
        given:
        List<HscAlternateIdentifierVO> hscAlternateIdentifierList = [
                new HscAlternateIdentifierVO(hscID: 1, hscAlternateIDType: '1'),
                new HscAlternateIdentifierVO(hscID: 1, hscAlternateIDType: '2')
        ]

        when:
        hscAlternateIdentifierImpl.delete(hscAlternateIdentifierList)

        then:
        1 * persistenceHelper.delete(hscAlternateIdentifierList[0])
        1 * persistenceHelper.delete(hscAlternateIdentifierList[1])
        0 * _._
    }

    def "test add list"() {
        given:
        List<HscAlternateIdentifierVO> hscAlternateIdentifierList = [
                new HscAlternateIdentifierVO(hscID: 1, hscAlternateID: '1', hscAlternateIDType: '1'),
                new HscAlternateIdentifierVO(hscID: 1, hscAlternateID: '2', hscAlternateIDType: '2')
        ]

        when:
        hscAlternateIdentifierImpl.add(hscAlternateIdentifierList)

        then:
        2 * dao.exists(_) >> false
        1 * persistenceHelper.add(hscAlternateIdentifierList[0])
        1 * persistenceHelper.add(hscAlternateIdentifierList[1])
        0 * _._
    }

    def "test new ID types are allowed to be added"() {
        given:
        List<HscAlternateIdentifierVO> persistedIdentifierList = [
                new HscAlternateIdentifierVO(hscAlternateIDType: '1'),
                new HscAlternateIdentifierVO(hscAlternateIDType: '2')
        ]
        List<HscAlternateIdentifierVO> newIdentifierList = [
                new HscAlternateIdentifierVO(hscAlternateIDType: '3'),
                new HscAlternateIdentifierVO(hscAlternateIDType: '4')
        ]

        when:
        hscAlternateIdentifierImpl.validate(persistedIdentifierList, newIdentifierList)

        then:
        0 * _._
        !persistedIdentifierList.any {it.errorMessagesExist()}
        !newIdentifierList.any {it.errorMessagesExist()}
    }

    def "test new ID can't have the same type as an existing ID"() {
        given:
        List<HscAlternateIdentifierVO> persistedIdentifierList = [
                new HscAlternateIdentifierVO(hscAlternateIDType: '1'),
                new HscAlternateIdentifierVO(hscAlternateIDType: '2')
        ]
        List<HscAlternateIdentifierVO> newIdentifierList = [
                new HscAlternateIdentifierVO(hscAlternateIDType: '3'),
                new HscAlternateIdentifierVO(hscAlternateIDType: '1')
        ]

        when:
        hscAlternateIdentifierImpl.validate(persistedIdentifierList, newIdentifierList)

        then:
        0 * _._
        !persistedIdentifierList.any {it.errorMessagesExist()}
        newIdentifierList[1].getMessage(FieldConstants.HSCALTERNATEIDTYPE).first().message == HscMessages.ERR_HSC_ALT_ID_ALREADY_EXISTS
    }

    def "test two new IDs with the same type can't be added"() {
        given:
        List<HscAlternateIdentifierVO> persistedIdentifierList = [
                new HscAlternateIdentifierVO(hscAlternateIDType: '1'),
                new HscAlternateIdentifierVO(hscAlternateIDType: '2')
        ]
        List<HscAlternateIdentifierVO> newIdentifierList = [
                new HscAlternateIdentifierVO(hscAlternateIDType: '3'),
                new HscAlternateIdentifierVO(hscAlternateIDType: '3')
        ]

        when:
        hscAlternateIdentifierImpl.validate(persistedIdentifierList, newIdentifierList)

        then:
        0 * _._
        !persistedIdentifierList.any {it.errorMessagesExist()}
        newIdentifierList[1].getMessage(FieldConstants.HSCALTERNATEIDTYPE).first().message == HscMessages.ERR_MAX_ONE_HSC_ALT_ID_PER_TYPE
    }
}
