package com.optum.app.ocm.hsr

import com.optum.app.ocm.common.member.businesslogic.CoverageSystemCheckHelper
import com.optum.rf.core.util.GenericUtilities
import com.optum.rf.core.util.UhgCalendar
import com.optum.rf.dao.data.ValueObject
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.QueryCriteria
import com.optum.rf.dao.sql.query.QueryFilter
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.util.UhgCalendarUtilities
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.optum.app.ocm.ref.businesslogic.CustomerReference
import com.optum.app.common.constants.CommonReferenceConstants
import com.optum.app.common.constants.ReferenceCustomFilterConstants
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.Hsc
import com.optum.app.common.hsr.businesslogic.HscFacility
import com.optum.app.common.hsr.businesslogic.HscService
import com.optum.app.common.hsr.businesslogic.HscServiceNonFacility
import com.optum.app.common.hsr.businesslogic.impl.HscMemberCoverageImpl
import com.optum.app.common.hsr.constants.HsrReferenceConstants
import com.optum.app.common.hsr.data.HscFacilityVO
import com.optum.app.common.hsr.data.HscMemberCoverageVO
import com.optum.app.common.hsr.data.HscServiceNonFacilityVO
import com.optum.app.common.hsr.data.HscServiceVO
import com.optum.app.common.hsr.data.HscVO
import com.optum.app.common.member.core.data.BaseMemberCoverageVO
import com.optum.app.common.member.core.data.MemberVO
import spock.lang.Unroll

import java.sql.Date

class HscMemberCoverageImplSpec extends HsrReadLogicSpecification {

    short memberCoverageSeqNum
    long hscID

    HscMemberCoverageImpl hscMemberCoverageImpl
    DataAccessObject<HscMemberCoverageVO> mockDao
    CustomerReference customerReference
    CoverageSystemCheckHelper mockCoverageSystemCheckHelper
    Hsc mockHsc
    HscService mockHscService
    HscFacility mockHscFacility
    HscServiceNonFacility mockHscServiceNonfacility
    PersistenceHelper mockPersistenceHelper

    def setup() {

        memberCoverageSeqNum = 1
        hscID = 1

        hscMemberCoverageImpl = new HscMemberCoverageImpl()
        mockDao = Mock(DataAccessObject)
        customerReference = Mock(CustomerReference)
        mockCoverageSystemCheckHelper = Mock(CoverageSystemCheckHelper)
        mockHsc = Mock(Hsc)
        mockHscService = Mock(HscService)
        mockHscFacility = Mock(HscFacility)
        mockHscServiceNonfacility = Mock(HscServiceNonFacility)
        mockPersistenceHelper = Mock(PersistenceHelper)

        hscMemberCoverageImpl.setRequiredPersistenceHelper(mockPersistenceHelper)
        hscMemberCoverageImpl.dao = mockDao
        hscMemberCoverageImpl.customerReference = customerReference
        hscMemberCoverageImpl.hsc = mockHsc
        hscMemberCoverageImpl.hscService = mockHscService
        hscMemberCoverageImpl.hscFacility = mockHscFacility
        hscMemberCoverageImpl.hscServiceNonFacility = mockHscServiceNonfacility
    }

    private HscVO getHscVO() {
        HscVO hscVO = new HscVO(hscID: 361L,
                memberCoverageSeqNum: 54 as short,
                specialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_CARECORE,
                secondarySpecialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_COMMERCIAL,
                serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT,
                hscStatusType: HsrReferenceConstants.HSCSTATUSTYPE_CLOSED)
        hscVO
    }

    private HscMemberCoverageVO getHscMemberCoverageVO() {
        HscMemberCoverageVO hscMemberCoverageVO = new HscMemberCoverageVO(hscID: 12345L,
                productCategoryType: HsrReferenceConstants.ORIGSYSTEMMEMBERIDTYPE_COSMOS)
        hscMemberCoverageVO
    }

    private QueryProperties getIsDuplicateQueryProperties(ValueObject vo) {
        QueryProperties queryProperties = new QueryProperties(QueryProperties.FilterType.NEW_FILTER)
        String[] arr$ = hscMemberCoverageImpl.getTableDef().getKey()
        int len$ = arr$.length

        for (int i$ = 0; i$ < len$; ++i$) {
            String keyField = arr$[i$]
            Object keyValue = hscMemberCoverageImpl.getVoIntrospector().invokeRead(vo, keyField)
            if (keyValue == null) {
                break
            }

            queryProperties.addQueryFilter(new QueryFilter(keyField, keyValue))
        }
        queryProperties
    }

    private ReadProperties getReadProperties(long hscID, short memberCoverageSeqNum, String... readFields) {
        ReadProperties readProperties = new ReadProperties(hscMemberCoverageImpl.getTableDef().getKey())
        readProperties.setKeyValue(FieldConstants.HSCID, hscID)
        readProperties.setKeyValue(FieldConstants.MEMBERCOVERAGESEQNUM, memberCoverageSeqNum)
        readProperties.setFields(readFields)
        readProperties
    }


    private QueryProperties getQueryPropertiesFilterHscID(long hscID) {
        QueryProperties queryProperties = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        queryProperties.addQueryFilter(new QueryFilter(FieldConstants.HSCID, hscID))
        queryProperties
    }

    private QueryProperties getQueryPropertiesFilterListHscID(List<Long> hscIDs) {
        QueryProperties queryProperties = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        queryProperties.addQueryFilter(new QueryFilter(FieldConstants.HSCID, GenericUtilities.getDelimitedString(hscIDs)))
        queryProperties
    }

    def "test isValid(long hscID, short memberCoverageSeqNum)"() {
        when:
        boolean isValid = hscMemberCoverageImpl.isValid(hscID, memberCoverageSeqNum)

        then:
        1 * mockDao.isValid(getReadProperties(hscID, memberCoverageSeqNum)) >> true
        0 * _

        expect:
        isValid
    }

    def "test coveragesExistForHsc(long hscID)"() {
        given:
        QueryProperties queryProperties = getQueryPropertiesFilterHscID(hscID)
        queryProperties.setFilterType(QueryProperties.FilterType.NEW_FILTER)
        queryProperties.setResultSize(1)

        when:
        boolean coveragesExistForHsc = hscMemberCoverageImpl.coveragesExistForHsc(hscID)

        then:
        1 * mockDao.list(queryProperties) >> [getHscMemberCoverageVO()]
        0 * _

        expect:
        coveragesExistForHsc
    }

    def "test read(long hscID, short memberCoverageSeqNum, String... readFields)"() {
        when:
        HscMemberCoverageVO resultVO = hscMemberCoverageImpl.read(hscID, memberCoverageSeqNum)

        then:
        1 * mockDao.read(getReadProperties(hscID, memberCoverageSeqNum)) >> new HscMemberCoverageVO()
        0 * _

        expect:
        resultVO
    }

    def "test listByHscID(long hscID)"() {
        when:
        List<HscMemberCoverageVO> VOs = hscMemberCoverageImpl.listByHscID(hscID)

        then:
        1 * mockDao.list(getQueryPropertiesFilterHscID(hscID)) >> [getHscMemberCoverageVO()]
        VOs.size() > 0
        0 * _
    }

    def "test isOxfordMember(long hscID)"() {
        given:
        QueryProperties queryProperties = getQueryPropertiesFilterHscID(hscID)
        queryProperties.addQueryFilter(new QueryFilter(QueryFilter.SqlPredicateKeyword.OR,
                new QueryFilter(FieldConstants.LINEOFBUSINESSTYPE, CommonReferenceConstants.LINEOFBUSINESSTYPE_OXFORD_MANDR),
                new QueryFilter(FieldConstants.LINEOFBUSINESSTYPE, CommonReferenceConstants.LINEOFBUSINESSTYPE_OXFORD_MANDR_MOSAIC)))

        when:
        boolean isOxfordMember = hscMemberCoverageImpl.isOxfordMember(hscID)

        then:
        1 * mockDao.exists(queryProperties) >> true
        0 * _

        expect:
        isOxfordMember
    }

    def "test listByHscIDWithPolicyNumber(List<Long> hscIDs)"() {
        given:
        List<Long> hscIDs = [hscID, 100]
        QueryProperties queryProperties = getQueryPropertiesFilterListHscID(hscIDs)
        queryProperties.addQueryFilter(new QueryFilter(FieldConstants.POLICYNUMBER, 0, QueryCriteria.NOT_EQUAL))
        List<HscMemberCoverageVO> VOs = [getHscMemberCoverageVO()]

        when:
        List<HscMemberCoverageVO> resultVOs = hscMemberCoverageImpl.listByHscIDWithPolicyNumber(hscIDs)

        then:
        1 * mockDao.list(queryProperties) >> VOs
        VOs.get(0).getHscID() == 12345L
        resultVOs.size() == VOs.size()
        0 * _
    }

    def "test listByCreateDateRangeForHsc(long hscID, Date(SQL) date)"() {
        given:
        Date date = Date.valueOf("9999-10-12")

        UhgCalendar startDate = UhgCalendarUtilities.getLocalCalendar(date)
        startDate.clearTime()
        UhgCalendar endDate = UhgCalendarUtilities.getLocalCalendar(date)
        UhgCalendarUtilities.setTimeOnCalendar(endDate, 23, 59, 59, 999)

        QueryProperties queryProperties = getQueryPropertiesFilterHscID(hscID)
        queryProperties.addQueryFilter(new QueryFilter().fieldBetweenValues(FieldConstants.CREATEDATETIME, startDate, endDate))

        when:
        List<HscMemberCoverageVO> VOs = hscMemberCoverageImpl.listByCreateDateRangeForHsc(hscID, date)

        then:
        1 * mockDao.list(queryProperties) >> [getHscMemberCoverageVO()]
        VOs
        0 * _
    }

    def "test deleteCoveragesForSc(long hscID)"() {
        given:
        QueryProperties queryProperties = getQueryPropertiesFilterHscID(hscID)

        when:
        int returnInt = hscMemberCoverageImpl.deleteCoveragesForHsc(hscID)

        then:
        1 * mockDao.list(queryProperties) >> [getHscMemberCoverageVO()]
        1 * mockPersistenceHelper.deleteBatch([getHscMemberCoverageVO()])
        0 * _

        expect:
        returnInt == 0
    }

    def "test isProductCategoryTypeMedicare(String productCategory)"() {
        given:
        String productCategory = "medicare"

        when:
        boolean isProductCategoryTypeMedicare = hscMemberCoverageImpl.isProductCategoryTypeMedicare(productCategory)

        then:
        1 * customerReference.isValidReferenceCustomFilter(ReferenceCustomFilterConstants.PRODUCTCATEGORYTYPE_MEDICARE, FieldConstants.PRODUCTCATEGORYTYPE, productCategory) >> true

        expect:
        isProductCategoryTypeMedicare
    }

    def "test isProductCategoryTypeCosmos(String productCategory)"() {
        given:
        String productCategory = "cosmos"

        when:
        boolean isProductCategoryTypeCosmos = hscMemberCoverageImpl.isProductCategoryTypeCosmos(productCategory)

        then:
        1 * customerReference.isValidReferenceCustomFilter(ReferenceCustomFilterConstants.PRODUCTCATEGORYTYPE_COSMOS, FieldConstants.PRODUCTCATEGORYTYPE, productCategory) >> true

        expect:
        isProductCategoryTypeCosmos
    }

    def "test getMedicalMembeCoverages(MemberVO memberVO)"() {
        given:
        MemberVO memberVO = new MemberVO(sourceMemberIDType: HsrReferenceConstants.SOURCEMEMBERIDTYPE_SYS,
                origSystemMemberIDType: HsrReferenceConstants.ORIGSYSTEMMEMBERIDTYPE_COSMOS,
                memberCoverageList: [new BaseMemberCoverageVO(groupNumber: "10", legacyBenefitPlanID: "12"),
                                     new BaseMemberCoverageVO(groupNumber: "5", legacyBenefitPlanID: "6")])

        List<HscMemberCoverageVO> translatedList = [new HscMemberCoverageVO(hscID: 0, groupNumber: "10", legacyBenefitPlanID: "12"),
                                                    new HscMemberCoverageVO(hscID: 0, groupNumber: "5", legacyBenefitPlanID: "6")]

        when:
        List<HscMemberCoverageVO> resultVOs = hscMemberCoverageImpl.getMedicalMemberCoverages(memberVO)

        then:
        0 * _
    }

    def "test getCoveragesForTempMember(long memberID) list is empty"() {
        given:
        long memberID = 12345L

        when:
        List<HscMemberCoverageVO> resultVOs = hscMemberCoverageImpl.getCoveragesForTempMember(memberID)

        then:
        0 * _

        expect:
        resultVOs.size() == 1
    }

    def "test getCoveragesForTempMember(long memberID) list is not empty"() {
        given:
        long memberID = 12345L

        when:
        List<HscMemberCoverageVO> resultVOs = hscMemberCoverageImpl.getCoveragesForTempMember(memberID)

        then:
        0 * _

        expect:
        resultVOs.size() == 1
    }

    def "test getCoveragesForTempMember(long memberID) list is not empty with mednecApplIndicator"() {
        given:
        long memberID = 12345L

        when:
        List<HscMemberCoverageVO> resultVOs = hscMemberCoverageImpl.getCoveragesForTempMember(memberID)

        then:
        0 * _

        expect:
        resultVOs.size() == 1
    }

    def "test getPrimaryMemberCoverage(long hscID, short memberCoverageSeqNum)"() {
        given:

        when:
        HscMemberCoverageVO resultVO = hscMemberCoverageImpl.getPrimaryMemberCoverage(hscID, memberCoverageSeqNum)

        then:
        1 * mockDao.read(getReadProperties(hscID, memberCoverageSeqNum)) >> getHscMemberCoverageVO()
        0 * _
        resultVO
    }

    @Unroll
    def "test getHscMedicalCoverage(HscVO hscVO, list<HscMemberCoverageVO> hscMemberCoverageVOs)"() {
        given:
        HscMemberCoverageVO vo1 = new HscMemberCoverageVO(hscID: 3162L, coverageType: HsrReferenceConstants.COVERAGETYPE_MEDICAL)
        HscMemberCoverageVO vo2 = new HscMemberCoverageVO(hscID: 9381L)
        HscVO hscVO = new HscVO(hscID: 112L, memberCoverageSeqNum: seqNum as short)
        List<HscMemberCoverageVO> list = [vo1, vo2]

        when:
        HscMemberCoverageVO resultVO = hscMemberCoverageImpl.getHscMedicalCoverage(hscVO, list)

        then:
        count * mockDao.read(getReadProperties(hscVO.getHscID(), hscVO.getMemberCoverageSeqNum())) >> vo1

        expect:
        resultVO == vo1

        where:
        seqNum | count
        1      | 1
        0      | 0
    }

    def "test covertHscMemberCoverageListToMemberCoverageList(List<HscMemberCoverageVO> hscMemberCoverageList)"() {
        given:
        HscMemberCoverageVO vo1 = new HscMemberCoverageVO(hscID: 3162L, coverageType: HsrReferenceConstants.COVERAGETYPE_MEDICAL)
        HscMemberCoverageVO vo2 = new HscMemberCoverageVO(hscID: 9381L)
        List<HscMemberCoverageVO> list = [vo1, vo2]

        when:
        List<BaseMemberCoverageVO> resultVOs = hscMemberCoverageImpl.convertHscMemberCoverageListToMemberCoverageList(list)

        then:
        list.size() == resultVOs.size()
        list.get(0).getCoverageType() == resultVOs.get(0).getCoverageType()
        list.get(1).getCoverageType() == resultVOs.get(1).getCoverageType()
        0 * _
    }

    @Unroll("test the productCategoryType as #productCategoryType of the HscMemberCoverageVO from read() if it is a Medicare type")
    def "test isMedicare(HscVO hscVO)"() {
        given:
        HscVO hscVO = getHscVO()

        when:
        boolean isMedicare = hscMemberCoverageImpl.isMedicare(hscVO)

        then:
        1 * mockDao.read(getReadProperties(hscVO.getHscID(), hscVO.getMemberCoverageSeqNum(), FieldConstants.PRODUCTCATEGORYTYPE)) >> new HscMemberCoverageVO(productCategoryType: productCategoryType)
        isMedicare == isSameProductCategoryType
        0 * _

        where:
        productCategoryType                                  | isSameProductCategoryType
        HsrReferenceConstants.PRODUCTCATEGORYTYPE_MEDICARE   | true
        HsrReferenceConstants.PRODUCTCATEGORYTYPE_COMMERCIAL | false
    }

    def "test shallowCopyHScMemberCoerageVO(HscMemberCoverageVO hscMemberCoverageVO)"() {
        given:
        HscMemberCoverageVO originalHscMemberCoverageVO = getHscMemberCoverageVO()
        HscMemberCoverageVO toCopyHscMemberCoverageVO = new HscMemberCoverageVO(
                hscID: 2151L,
                memberCoverageSeqNum: 2 as short,
                productCategoryType: HsrReferenceConstants.PRODUCT_TYPE_POS,
                divID: 213L)

        when:
        hscMemberCoverageImpl.shallowCopyHscMemberCoverageVO(toCopyHscMemberCoverageVO)

        then:
        1 * mockDao.read(getReadProperties(toCopyHscMemberCoverageVO.getHscID(), toCopyHscMemberCoverageVO.getMemberCoverageSeqNum())) >> originalHscMemberCoverageVO
        0 * _
    }

    @Unroll("validate hscVO serviceSettingType as #hscValueObject.serviceSettingType and check coverage line as #actualAdmissionDate.toString() as startDate or #expectedAdmissionDate.toString() as expectedAdmissionDate")
    def "test hasDualCoverage(HscVO hscVO)"() {
        given:
        HscVO hscVO = hscValueObject

        HscServiceVO hscServiceVO = new HscServiceVO(hscID: 513L, serviceSeqNum: 2 as short)
        Date admissionDate = (null != actualAdmissionDate) ? actualAdmissionDate.getSQLDate() : null

        HscServiceNonFacilityVO hscServiceNonFacilityVO = new HscServiceNonFacilityVO(hscID: 215L, serviceSeqNum: 12 as short, serviceStartDate: admissionDate)
        HscFacilityVO facilityVO = new HscFacilityVO(hscID: 513L, actualAdmissionDateTime: actualAdmissionDate, expectedAdmissionDate: expectedAdmissionDate)

        Date coverageDate = hscVO.getHscID() != 11L ? (admissionDate ?: expectedAdmissionDate) : UhgCalendarUtilities.getTodaysDate()

        QueryProperties queryProperties = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        queryProperties.addQueryFilter(new QueryFilter(FieldConstants.HSCID, hscVO.getHscID()))
        queryProperties.addQueryFilter(new QueryFilter().valueBetweenFields(coverageDate,
                FieldConstants.COVERAGEEFFECTIVEDATE, FieldConstants.COVERAGEENDDATE));
        queryProperties.addQueryFilter(new QueryFilter(FieldConstants.PRODUCTCATEGORYCODE,
                [HsrReferenceConstants.PRODUCTCATEGORYTYPE_MEDICARE_MEDICAID,
                 HsrReferenceConstants.PRODUCTCATEGORYTYPE_MEDICAID,
                 HsrReferenceConstants.PRODUCTCATEGORYTYPE_MEDICARE] as ArrayList, QueryCriteria.IN));

        when:
        boolean hasDualCoverage = hscMemberCoverageImpl.hasDualCoverage(hscVO)

        then:
        countHscService * mockHscService.readFirstHscServiceVO(hscVO.getHscID()) >> hscServiceVO
        countHscService * mockHscServiceNonfacility.read(hscServiceVO.getHscID(), hscServiceVO.getServiceSeqNum()) >> hscServiceNonFacilityVO
        countHscFacility * mockHscFacility.read(hscVO.getHscID()) >> facilityVO
        1 * mockDao.list(queryProperties) >> [new HscMemberCoverageVO(productCategoryType: HsrReferenceConstants.PRODUCTCATEGORYTYPE_MEDICAID)]
        0 * _

        expect:
        !hasDualCoverage

        where:
        hscValueObject                                                                       | countHscService | countHscFacility | actualAdmissionDate                 | expectedAdmissionDate
        getHscVO()                                                                           | 1               | 0                | new UhgCalendar().setDate(20160101) | null
        new HscVO(serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT) | 0               | 1                | null                                | Date.valueOf("2016-02-02")
        new HscVO(hscID: 11L)                                                                | 0               | 0                | null                                | null
    }

    def "test getMedNecAplIndValue(hscVO) if medNecessityApplInd is false"() {
        given:
        HscVO hscVO = getHscVO()

        HscMemberCoverageVO vo = new HscMemberCoverageVO(medNecessityApplInd: new Boolean(false))

        when:
        boolean aplIndValue = hscMemberCoverageImpl.getMedNecAplIndValue(hscVO)

        then:
        1 * mockDao.read(getReadProperties(hscVO.getHscID(), hscVO.getMemberCoverageSeqNum())) >> vo
        0 * _

        expect:
        !aplIndValue
    }

    def "list active by hscID - MMP"() {
        given:
        long hscID = 213L
        String indicator = "MMP"
        QueryProperties qp = null

        when:
        List<HscMemberCoverageVO> voList = hscMemberCoverageImpl.listActiveByHscID(hscID, indicator)

        then:
        1 * mockDao.list(_)
        0 * _
    }

    def "list active by hscID - LTC"() {
        given:
        long hscID = 213L
        String indicator = "LTC"
        QueryProperties qp = null

        when:
        List<HscMemberCoverageVO> voList = hscMemberCoverageImpl.listActiveByHscID(hscID, indicator)

        then:
        1 * mockDao.list(_)
        0 * _
    }
}