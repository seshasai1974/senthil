package com.optum.app.ocm.hsr

import com.optum.rf.bl.spring.TransactionInterceptor
import com.optum.rf.core.locator.ServiceLocator
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.HscEvv
import com.optum.app.common.hsr.businesslogic.impl.HscEvvImpl
import com.optum.app.common.hsr.data.HscEvvVO
import spock.lang.Unroll

class HscEvvSpec extends HsrReadLogicSpecification {

    HscEvv hscEvv

    DataAccessObject dao
    PersistenceHelper persistenceHelper
    ServiceLocator serviceLocator
    TransactionInterceptor transactionInterceptor

    def setup() {
        dao = Mock(DataAccessObject)
        persistenceHelper = Mock(PersistenceHelper)
        serviceLocator = Mock(ServiceLocator)
        transactionInterceptor = Mock(TransactionInterceptor)

        hscEvv = new HscEvvImpl(
                requiredDao: dao,
                requiredPersistenceHelper: persistenceHelper,
                requiredServiceLocator: serviceLocator,
                requiredTransactionInterceptor: transactionInterceptor
        )
    }

    @Unroll
    def "isValid #testCase"() {
        given:
        def hscID = (long) 1
        def hscComponentType = "2"
        def hscComponentID = "3"
        def rp = new ReadProperties(FieldConstants.HSCID, FieldConstants.HSCCOMPONENTTYPE, FieldConstants.HSCCOMPONENTID)
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        rp.setKeyValue(FieldConstants.HSCCOMPONENTTYPE, hscComponentType)
        rp.setKeyValue(FieldConstants.HSCCOMPONENTID, hscComponentID)
        rp.fields = null

        when:
        boolean retVal = hscEvv.isValid(hscID, hscComponentType, hscComponentID)

        then:
        1 * dao.isValid(rp) >> expectedVal
        0 * _
        retVal == expectedVal

        where:
        testCase | expectedVal
        "passes" | true
        "fails"  | false
    }

    def "Test to read HscEvvVO"() {
        setup:
        def hscID = (long) 1
        def hscComponentType = "2"
        def hscComponentID = "3"
        HscEvvVO hscEvvVO = new HscEvvVO(hscID: hscID, hscComponentType: hscComponentType, hscComponentID: hscComponentID)
        def rp = new ReadProperties(FieldConstants.HSCID, FieldConstants.HSCCOMPONENTTYPE, FieldConstants.HSCCOMPONENTID)
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        rp.setKeyValue(FieldConstants.HSCCOMPONENTTYPE, hscComponentType)
        rp.setKeyValue(FieldConstants.HSCCOMPONENTID, hscComponentID)
        rp.fields = null

        when:
        hscEvv.read(hscID, hscComponentType, hscComponentID)

        then:
        1 * dao.read(rp) >> hscEvvVO
        0 * _
    }
}
