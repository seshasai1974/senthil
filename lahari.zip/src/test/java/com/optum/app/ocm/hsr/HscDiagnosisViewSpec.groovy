package com.optum.app.ocm.hsr

import com.optum.rf.bl.spring.TransactionInterceptor
import com.optum.rf.core.locator.ServiceLocator
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.QueryFilter
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.HscDiagnosisView
import com.optum.app.common.hsr.businesslogic.impl.HscDiagnosisViewImpl
import com.optum.app.common.hsr.data.HscDiagnosisViewVO

class HscDiagnosisViewSpec extends HsrReadLogicSpecification {

    HscDiagnosisView hscDiagnosisView

    DataAccessObject dao
    PersistenceHelper persistenceHelper
    ServiceLocator serviceLocator
    TransactionInterceptor transactionInterceptor

    def setup() {
        dao = Mock(DataAccessObject)
        persistenceHelper = Mock(PersistenceHelper)
        serviceLocator = Mock(ServiceLocator)
        transactionInterceptor = Mock(TransactionInterceptor)

        hscDiagnosisView = new HscDiagnosisViewImpl(
                dao: dao,
                requiredServiceLocator: serviceLocator
        )
    }

    def "Test listByHscID"() {
        setup:
        def hscID = (long) 1
        HscDiagnosisViewVO hscDiagnosisViewVO = new HscDiagnosisViewVO(hscID: hscID)
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        qp.addQueryFilter(new QueryFilter(FieldConstants.HSCID, hscID))
        qp.setOrderByAscFields(FieldConstants.DIAGNOSISSEQNUM)

        when:
        hscDiagnosisView.listByHscID(qp, hscID)

        then:
        1 * dao.list(qp) >> [hscDiagnosisViewVO]
        0 * _
    }
}
