package com.optum.app.ocm.interceptor

import com.optum.app.ocm.cache.OcmCacheRefresh
import com.optum.app.ocm.customer.businesslogic.CustomerUser
import com.optum.rf.common.security.data.UserSecurityVO
import com.optum.rf.core.controller.cache.ControllerRequestCache
import com.optum.rf.core.util.Environment
import com.optum.rf.dao.constants.SystemSecurityConstants
import com.optum.rf.web.security.PermissionCache
import org.slf4j.Logger
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.method.HandlerMethod
import org.springframework.web.servlet.mvc.ParameterizableViewController
import spock.lang.Specification

import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse
import javax.servlet.http.HttpSession

import static com.optum.app.ocm.interceptor.ControllerSecurityInterceptor.AJAX_HEADER
import static com.optum.app.ocm.interceptor.ControllerSecurityInterceptor.AJAX_VALUE
import static com.optum.app.ocm.interceptor.ControllerSecurityInterceptor.ALLOW_PERMISSIONGROUP
import static com.optum.app.ocm.interceptor.ControllerSecurityInterceptor.DENY
import static com.optum.app.ocm.interceptor.ControllerSecurityInterceptor.DENY_NOMATCH
import static com.optum.app.ocm.interceptor.ControllerSecurityInterceptor.DENY_NOPERMISSIONLIST
import static com.optum.app.ocm.interceptor.ControllerSecurityInterceptor.DENY_NULLSESSION
import static com.optum.app.ocm.interceptor.ControllerSecurityInterceptor.DENY_NULLUSERSEC
import static com.optum.app.ocm.interceptor.ControllerSecurityInterceptor.HANDLER_MAPPING

/**
 * Created by skohl on 7/26/2016.
 */
class ControllerSecurityInterceptorSpec extends Specification {
    ControllerSecurityInterceptor underTest = new ControllerSecurityInterceptor()
    Environment mockEnvironment = Mock(Environment)
    PermissionCache mockPermissionCache = Mock(PermissionCache)
    ArrayList<String> permissionList = new ArrayList()
    ArrayList<String> userPermissionGroups = new ArrayList<>()
    ControllerRequestCache mockControllerRequestCache = Mock(ControllerRequestCache)
    OcmCacheRefresh mockCacheRefresh = Mock(OcmCacheRefresh)

    //mockRequest variables
    HttpServletRequest mockRequest = Mock(HttpServletRequest)
    HttpServletResponse mockResponse = Mock(HttpServletResponse)
    HandlerMethod mockHandler = Mock(HandlerMethod) //this is the handler you get for requests to a Controller
    ParameterizableViewController mockAppHandler = Mock(ParameterizableViewController)//this is the handler you get for /app requests
    HttpSession mockSession = Mock(HttpSession)
    UserSecurityVO mockUserSecurity = Mock(UserSecurityVO)
    CustomerUser customerUser = Mock(CustomerUser)
    RequestMapping mockRequestMapping = Mock(RequestMapping)
    Logger mockLogger = Mock(Logger)

    String method = "GET"
    String contextPath = "context"
    String webXmlPrefix = "webXmlPrefix"
    String service = "service"
    String version = "v0987654321"
    String entity = "entity"
    String entityPathVar = "{entity}"
    String entityId = "entityId"
    String subEntity = "subEntity"
    String subEntityPathVar = "{subEntity}"
    String subEntityId = "subEntityId"
    String user = "user"

    //these are set as part of standardConfiguration, if they are still null, to override, set them before calling it.
    String permissionUri = null
    String permissionId = null
    String requestUri = null
    String action = null

    boolean showVars = false

    def setup() {
        underTest.environment = mockEnvironment
        underTest.permissionCache = mockPermissionCache
        underTest.controllerRequestCache = mockControllerRequestCache
        underTest.logger = mockLogger
        underTest.cacheRefresh = mockCacheRefresh
        underTest.customerUser = customerUser
    }

    private standardConfiguration() {
        if (!permissionUri) {
            permissionUri = buildUri(webXmlPrefix, service, version, entity, entityPathVar, subEntity, subEntityPathVar)
        }
        if (!permissionId) {
            permissionId = method + " " + permissionUri
        }
        if (!requestUri) {
            requestUri = buildUri(contextPath, webXmlPrefix, service, version, entity, entityId, subEntity, subEntityId)
        }
        if (!action) {
            action = buildUri(service, version, entity, entityPathVar, subEntity, subEntityPathVar)
        }
        mockEnvironment.getEnvironment() >> Environment.Env.DEVELOPMENT

        //request setup
        mockRequest.getRequestURI() >> requestUri
        mockRequest.getMethod() >> method
        mockRequest.getSession(_) >> mockSession
        mockRequest.getContextPath() >> "/" + contextPath
        mockRequest.getAttribute(HANDLER_MAPPING) >> action

        //session setup
        mockSession.getAttribute(SystemSecurityConstants.SECURITY_OBJECT) >> mockUserSecurity
        mockHandler.getMethodAnnotation(RequestMapping.class) >> mockRequestMapping
        mockRequestMapping.path() >> [requestUri]//TODO: is this correct?
        mockUserSecurity.getUserID() >> user

        //permissions setup
        permissionList.add(permissionId)
        mockUserSecurity.getPermissionGroups() >> userPermissionGroups
        userPermissionGroups.add(permissionId)
        if (showVars) {
            System.out.println("requestUri: " + requestUri)
            System.out.println("permissionID: " + permissionId)
            System.out.println("action: " + action)
            System.out.println("----")
        }
        mockPermissionCache.getPermissionGroups(permissionId) >> permissionList
    }

    def "Allowed GET"() {
        setup:
        standardConfiguration()
        when:
        boolean continueEx = underTest.preHandle(mockRequest, mockResponse, mockHandler)

        then:
        1 * mockLogger.debug(ALLOW_PERMISSIONGROUP, user, permissionId, permissionId)
        1 * mockRequest.setAttribute(SystemSecurityConstants.PERMISSION_STRING, permissionId)

        and:
        continueEx
    }

    def "Allowed POST"() {
        setup:
        method = "POST"
        standardConfiguration()

        when:
        boolean continueEx = underTest.preHandle(mockRequest, mockResponse, mockHandler)

        then:
        1 * mockLogger.debug(ALLOW_PERMISSIONGROUP, user, permissionId, permissionId)
        1 * mockRequest.setAttribute(SystemSecurityConstants.PERMISSION_STRING, permissionId)

        and:
        continueEx
    }

    def "Allowed PUT"() {
        setup:
        method = "PUT"
        standardConfiguration()

        when:
        boolean continueEx = underTest.preHandle(mockRequest, mockResponse, mockHandler)

        then:
        1 * mockLogger.debug(ALLOW_PERMISSIONGROUP, user, permissionId, permissionId)
        1 * mockRequest.setAttribute(SystemSecurityConstants.PERMISSION_STRING, permissionId)

        and:
        continueEx
    }

    def "Allowed DELETE"() {
        setup:
        method = "DELETE"
        standardConfiguration()

        when:
        boolean continueEx = underTest.preHandle(mockRequest, mockResponse, mockHandler)

        then:
        1 * mockLogger.debug(ALLOW_PERMISSIONGROUP, user, permissionId, permissionId)
        1 * mockRequest.setAttribute(SystemSecurityConstants.PERMISSION_STRING, permissionId)

        and:
        continueEx
    }

    def "Allowed OPTIONS"() {
        setup:
        method = "OPTIONS"
        standardConfiguration()

        when:
        boolean continueEx = underTest.preHandle(mockRequest, mockResponse, mockHandler)

        then:
        1 * mockLogger.debug(ALLOW_PERMISSIONGROUP, user, permissionId, permissionId)
        1 * mockRequest.setAttribute(SystemSecurityConstants.PERMISSION_STRING, permissionId)

        and:
        continueEx
    }

    def "Allowed HEAD"() {
        setup:
        method = "HEAD"
        standardConfiguration()

        when:
        boolean continueEx = underTest.preHandle(mockRequest, mockResponse, mockHandler)

        then:
        1 * mockLogger.debug(ALLOW_PERMISSIONGROUP, user, permissionId, permissionId)
        1 * mockRequest.setAttribute(SystemSecurityConstants.PERMISSION_STRING, permissionId)

        and:
        continueEx
    }

    def "Allowed PATCH"() {
        setup:
        method = "PATCH"
        standardConfiguration()

        when:
        boolean continueEx = underTest.preHandle(mockRequest, mockResponse, mockHandler)

        then:
        1 * mockLogger.debug(ALLOW_PERMISSIONGROUP, user, permissionId, permissionId)
        1 * mockRequest.setAttribute(SystemSecurityConstants.PERMISSION_STRING, permissionId)

        and:
        continueEx
    }

    def "Allowed TRACE"() {
        setup:
        method = "TRACE"
        standardConfiguration()

        when:
        boolean continueEx = underTest.preHandle(mockRequest, mockResponse, mockHandler)

        then:
        1 * mockLogger.debug(ALLOW_PERMISSIONGROUP, user, permissionId, permissionId)
        1 * mockRequest.setAttribute(SystemSecurityConstants.PERMISSION_STRING, permissionId)

        and:
        continueEx
    }

    def "Allowed CONNECT"() {
        setup:
        method = "CONNECT"
        standardConfiguration()

        when:
        boolean continueEx = underTest.preHandle(mockRequest, mockResponse, mockHandler)

        then:
        1 * mockLogger.debug(ALLOW_PERMISSIONGROUP, user, permissionId, permissionId)
        1 * mockRequest.setAttribute(SystemSecurityConstants.PERMISSION_STRING, permissionId)

        and:
        continueEx
    }

    def "Allowed XHR GET"() {
        setup:
        mockRequest.getHeader(AJAX_HEADER) >> AJAX_VALUE
        standardConfiguration()

        when:
        boolean continueEx = underTest.preHandle(mockRequest, mockResponse, mockHandler)

        then:
        1 * mockLogger.debug(ALLOW_PERMISSIONGROUP, user, permissionId, permissionId)
        1 * mockRequest.setAttribute(SystemSecurityConstants.PERMISSION_STRING, permissionId)

        and:
        continueEx
    }

    def "GET Forbidden"() {
        setup:
        standardConfiguration()
        permissionList.clear()
        permissionList.add("GET " + buildUri(webXmlPrefix, service, version, entity))
        permissionList.add("POST " + requestUri)

        when:
        boolean continueEx = underTest.preHandle(mockRequest, mockResponse, mockHandler)

        then:
        1 * mockLogger.debug(DENY, user, permissionId)
        1 * mockRequest.setAttribute(SystemSecurityConstants.PERMISSION_STRING, permissionId)
        1 * mockResponse.sendError(HttpServletResponse.SC_FORBIDDEN, "forbidden")

        and:
        !continueEx
    }

    def "GET XHR Forbidden"() {
        setup:
        mockRequest.getHeader(AJAX_HEADER) >> AJAX_VALUE
        standardConfiguration()
        permissionList.clear()
        permissionList.add("GET " + buildUri(webXmlPrefix, service, version, entity))
        permissionList.add("POST " + requestUri)

        when:
        boolean continueEx = underTest.preHandle(mockRequest, mockResponse, mockHandler)

        then:
        1 * mockLogger.debug(DENY, user, permissionId)
        1 * mockRequest.setAttribute(SystemSecurityConstants.PERMISSION_STRING, permissionId)
        1 * mockResponse.sendError(HttpServletResponse.SC_FORBIDDEN, "forbidden")

        and:
        !continueEx
    }

    def "GET Unauthorized"() {
        setup:
        mockRequest.getSession(_) >> null
        standardConfiguration()

        when:
        boolean continueEx = underTest.preHandle(mockRequest, mockResponse, mockHandler)

        then:
        1 * mockLogger.error(DENY_NULLSESSION, method, _)

        and:
        !continueEx
    }

    def "GET XHR Unauthorized"() {
        setup:
        mockRequest.getHeader(AJAX_HEADER) >> AJAX_VALUE
        mockRequest.getSession(_) >> null
        standardConfiguration()

        when:
        boolean continueEx = underTest.preHandle(mockRequest, mockResponse, mockHandler)

        then:
        2 * mockRequest.getAttribute(_ as String)
        2 * mockRequest.getHeader(_ as String)
        1 * mockLogger.debug(_ as String, null)
        1 * mockRequest.getSession(false)
        2 * mockRequest.getMethod()
        2 * mockRequest.getRequestURI()
        1 * mockLogger.error(_ as String, _)
        1 * mockLogger.error(_ as String, _, _)
        1 * mockResponse.sendError(_, _)
        0 * _

        and:
        !continueEx
    }

    def "GET Unauthorized Null User Security"() {
        setup:
        mockSession.getAttribute(SystemSecurityConstants.SECURITY_OBJECT) >> null
        standardConfiguration()

        when:
        boolean continueEx = underTest.preHandle(mockRequest, mockResponse, mockHandler)

        then:
        1 * mockLogger.error(DENY_NULLUSERSEC, method, _)

        and:
        !continueEx
    }

    def "GET XHR Unauthorized Null User Security"() {
        setup:
        mockRequest.getHeader(AJAX_HEADER) >> AJAX_VALUE
        mockSession.getAttribute(SystemSecurityConstants.SECURITY_OBJECT) >> null
        standardConfiguration()

        when:
        boolean continueEx = underTest.preHandle(mockRequest, mockResponse, mockHandler)

        then:
        1 * mockLogger.error(DENY_NULLUSERSEC, method, _)

        and:
        !continueEx
    }

    def "POST Unauthorized Null User Security"() {
        setup:
        method = "POST"
        mockSession.getAttribute(SystemSecurityConstants.SECURITY_OBJECT) >> null
        standardConfiguration()

        when:
        boolean continueEx = underTest.preHandle(mockRequest, mockResponse, mockHandler)

        then:
        1 * mockLogger.error(DENY_NULLUSERSEC, 'POST', _)

        and:
        !continueEx
    }

    def "POST XHR Unauthorized Null User Security"() {
        setup:
        method = "POST"
        mockRequest.getHeader(AJAX_HEADER) >> AJAX_VALUE
        mockSession.getAttribute(SystemSecurityConstants.SECURITY_OBJECT) >> null
        standardConfiguration()

        when:
        boolean continueEx = underTest.preHandle(mockRequest, mockResponse, mockHandler)

        then:
        1 * mockLogger.error(DENY_NULLUSERSEC, 'POST', _)
        1 * mockResponse.sendError(HttpServletResponse.SC_UNAUTHORIZED, "timeout")

        and:
        !continueEx
    }

    def "GET service name same as entity name"() {
        setup:
        method = "GET"
        service = entity
        standardConfiguration()

        when:
        boolean continueEx = underTest.preHandle(mockRequest, mockResponse, mockHandler)

        then:
        1 * mockLogger.debug(ALLOW_PERMISSIONGROUP, user, permissionId, permissionId)
        1 * mockRequest.setAttribute(SystemSecurityConstants.PERMISSION_STRING, permissionId)

        and:
        continueEx
    }

    def "GET no path vars"() {
        setup:
        method = "GET"
        entityPathVar = null
        entityId = null
        subEntityPathVar = null
        subEntity = null
        subEntityId = null
        standardConfiguration()

        when:
        boolean continueEx = underTest.preHandle(mockRequest, mockResponse, mockHandler)

        then:
        1 * mockLogger.debug(ALLOW_PERMISSIONGROUP, user, permissionId, permissionId)
        1 * mockRequest.setAttribute(SystemSecurityConstants.PERMISSION_STRING, permissionId)

        and:
        continueEx
    }

    def "full lifecycle including postHandle"() {
        setup:
        standardConfiguration()

        when:
        boolean continueEx = underTest.preHandle(mockRequest, mockResponse, mockHandler)
        underTest.postHandle(mockRequest, mockResponse, mockHandler, null)

        then:
        1 * mockLogger.debug(ALLOW_PERMISSIONGROUP, user, permissionId, permissionId)
        1 * mockRequest.setAttribute(SystemSecurityConstants.PERMISSION_STRING, permissionId)
        1 * mockLogger.trace(_, method, _)

        and:
        continueEx
    }

    def "context remove false works"() {
        setup:
        underTest.stripContext = false
        permissionUri = buildUri(contextPath, webXmlPrefix, service, version, entity, entityPathVar, subEntity, subEntityPathVar)
        standardConfiguration()

        when:
        boolean continueEx = underTest.preHandle(mockRequest, mockResponse, mockHandler)

        then:
        1 * mockLogger.debug(ALLOW_PERMISSIONGROUP, user, permissionId, permissionId)
        1 * mockRequest.setAttribute(SystemSecurityConstants.PERMISSION_STRING, permissionId)

        and:
        continueEx
    }

    def "app routing with id"() {
        setup:
        webXmlPrefix = "app"
        service = null
        version = null
        entity = "patientDetail"
        entityPathVar = "*"
        entityId = "42"
        subEntity = null
        subEntityId = null
        subEntityPathVar = null
        standardConfiguration()

        when:
        boolean continueEx = underTest.preHandle(mockRequest, mockResponse, mockAppHandler)

        then:
        1 * mockLogger.debug(ALLOW_PERMISSIONGROUP, user, permissionId, permissionId)
        1 * mockRequest.setAttribute(SystemSecurityConstants.PERMISSION_STRING, permissionId)

        and:
        continueEx
    }

    def "app routing no asterisk"() {
        setup:
        webXmlPrefix = "app"
        service = null
        version = null
        entity = "patientDetail"
        entityPathVar = null
        entityId = null
        subEntity = null
        subEntityId = null
        subEntityPathVar = null
        standardConfiguration()

        when:
        boolean continueEx = underTest.preHandle(mockRequest, mockResponse, mockAppHandler)

        then:
        1 * mockLogger.debug(ALLOW_PERMISSIONGROUP, user, permissionId, permissionId)
        1 * mockRequest.setAttribute(SystemSecurityConstants.PERMISSION_STRING, permissionId)

        and:
        continueEx
    }

    def "app routing with asterisk - no match"() {
        setup:
        webXmlPrefix = "app"
        service = null
        version = null
        entity = "patientDetail"
        entityPathVar = "*"
        entityId = "42"
        subEntity = null
        subEntityId = null
        subEntityPathVar = null
        requestUri = buildUri(contextPath, webXmlPrefix, service, version, entity, entityId, "not", "allowed")
        standardConfiguration()

        when:
        boolean continueEx = underTest.preHandle(mockRequest, mockResponse, mockAppHandler)

        then:
        1 * mockLogger.error(DENY_NOMATCH, user, _, action)
        1 * mockRequest.setAttribute(SystemSecurityConstants.PERMISSION_STRING, null)
        1 * mockResponse.sendError(HttpServletResponse.SC_FORBIDDEN, "forbidden")

        and:
        !continueEx
    }

    def "prevent false DENY logging"() {
        setup:
        standardConfiguration()

        when:
        boolean continueEx = underTest.preHandle(mockRequest, mockResponse, mockAppHandler)

        then:
        0 * mockLogger.error(DENY_NOMATCH, user, _, action)
        0 * mockLogger.error(DENY_NULLUSERSEC, user, _, action)
        0 * mockLogger.error(DENY_NOPERMISSIONLIST, user, _, action)
        0 * mockLogger.error(DENY_NULLSESSION, user, _, action)
        1 * mockLogger.debug(ALLOW_PERMISSIONGROUP, user, permissionId, permissionId)

        and:
        continueEx
    }

    def "prevent false ALLOW logging"() {
        setup:
        showVars = true
        standardConfiguration()
        permissionList.remove(permissionId)
        String jediPermission = "GET /not/the/permission/you/were/looking/for"
        permissionList.add(jediPermission)

        when:
        boolean continueEx = underTest.preHandle(mockRequest, mockResponse, mockAppHandler)

        then:
        1 * mockLogger.error(DENY_NOMATCH, user, _, action)
        0 * mockLogger.debug(ALLOW_PERMISSIONGROUP, user, permissionId, permissionId)

        and:
        !continueEx
    }

    /*
         Need following tests:
            - Test multiple request (path vars) match same permission
            - Test right request, wrong method
            - Test too long request
            - security bypass
            - turn off security

      */

    private String buildUri(String... section) {
        StringBuilder uri = new StringBuilder()
        for (int i = 0; i < section.length; i++) {
            String value = section[i]
            if (value == null) {
                continue
            }
            uri.append("/")
            uri.append(value)
        }
        return uri.toString()
    }

}
