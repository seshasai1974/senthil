package com.optum.app.ocm.hsr

import com.optum.rf.bl.businesslogic.HistoryBusinessLogic
import com.optum.rf.bl.spring.TransactionInterceptor
import com.optum.rf.common.security.data.UserSecurityVO
import com.optum.rf.core.locator.ServiceLocator
import com.optum.rf.dao.controller.session.Session
import com.optum.rf.dao.controller.session.SessionThreadLocal
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.exception.FinderException
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.optum.rf.web.controller.session.HttpUserSession
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.impl.UserHscHistoryImpl
import com.optum.app.common.hsr.data.UserHscHistoryVO
import spock.lang.Unroll

/**
 * Contains tests for com.optum.app.icue.hsr.user.businesslogic.impl.UserHscHistoryImpl
 */
class UserHscHistoryImplSpec extends HsrReadLogicSpecification {
    UserHscHistoryImpl userHscHistory
    DataAccessObject dao
    ServiceLocator serviceLocator
    PersistenceHelper persistenceHelper
    HistoryBusinessLogic historyBusinessLogic
    TransactionInterceptor transactionInterceptor
    Session session

    final static String DEFAULT_USERID = "user ID"

    def setup() {
        userHscHistory = new UserHscHistoryImpl()

        historyBusinessLogic = Mock(HistoryBusinessLogic)
        transactionInterceptor = Mock(TransactionInterceptor)
        persistenceHelper = Mock(PersistenceHelper)
        serviceLocator = Mock(ServiceLocator)
        dao = Mock(DataAccessObject)

        userHscHistory.setRequiredHistoryBusinessLogic(historyBusinessLogic)
        userHscHistory.setRequiredTransactionInterceptor(transactionInterceptor)
        userHscHistory.setRequiredPersistenceHelper(persistenceHelper)
        userHscHistory.setRequiredServiceLocator(serviceLocator)
        userHscHistory.setRequiredDao(dao)

        session = new HttpUserSession()
        UserSecurityVO securityVO = new UserSecurityVO()
        securityVO.setUserID(DEFAULT_USERID)
        session.setUserSecurity(securityVO)
        SessionThreadLocal.setSession(session)
    }

    def cleanup(){
        SessionThreadLocal.removeSession()
    }

    @Unroll
    def "is valid #testCase"() {
        given:
        long hscID = 1
        String userID = DEFAULT_USERID
        ReadProperties rp = getReadProperties(hscID, userID)

        when:
        boolean retVal = userHscHistory.isValid(hscID, userID)

        then:
        1 * dao.isValid(rp) >> expectedVal
        0 * _
        retVal == expectedVal

        where:
        testCase | expectedVal
        "passes" | true
        "fails"  | false
    }

    def "valid read"(){
        given:
        UserHscHistoryVO userHscHistoryVO = new UserHscHistoryVO(hscID: 1, userID: DEFAULT_USERID)
        ReadProperties rp = getReadProperties(userHscHistoryVO.getHscID(), userHscHistoryVO.getUserID())

        when:
        UserHscHistoryVO retVO = userHscHistory.read(userHscHistoryVO.getHscID(), userHscHistoryVO.getUserID())

        then:
        1 * dao.read(rp) >> userHscHistoryVO
        0 * _
        retVO == userHscHistoryVO
    }

    def "invalid read - VO is null"(){
        given:
        long hscID = 1
        String userID = DEFAULT_USERID
        ReadProperties rp = getReadProperties(hscID, userID)

        when:
        UserHscHistoryVO retVO = userHscHistory.read(hscID, userID)

        then: "VO is null, dao throws FinderException which is caught. Return value is null."
        1 * dao.read(rp) >> {throw new FinderException()}
        0 * _
        notThrown FinderException
        !retVO
    }

    def "save user hsc history where VO already exists"() {
        given:
        long hscID = 1
        UserHscHistoryVO vo = new UserHscHistoryVO(hscID: hscID, userID: DEFAULT_USERID)
        ReadProperties rp = getReadProperties(hscID, DEFAULT_USERID)

        when:
        userHscHistory.saveUserHscHistory(hscID)
        dao.read(_) >> new UserHscHistoryVO()

        then: "VO is found; VO is updated"
        1 * dao.read(_)
    }

    def "save user hsc history where VO does not exist"() {
        given:
        long hscID = 1
        UserHscHistoryVO vo = new UserHscHistoryVO(hscID: hscID, userID: DEFAULT_USERID)
        ReadProperties rp = getReadProperties(hscID, DEFAULT_USERID)

        when:
        userHscHistory.saveUserHscHistory(hscID)

        then: "VO is not found; new VO is added"
        1 * dao.read(_)
    }

    def "get userID"(){
        when:
        String retStr = userHscHistory.getUserID()

        then:
        0 * _
        retStr.equals(session.getUserSecurity().getUserID())
    }


    private ReadProperties getReadProperties(long hscID, String userID) {
        ReadProperties rp = new ReadProperties([FieldConstants.HSCID, FieldConstants.USERID] as String[])
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        rp.setKeyValue(FieldConstants.USERID, userID)
        return rp
    }
}
