package com.optum.app.ocm.hsr

import com.optum.app.ocm.ref.businesslogic.CustomerReference
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.app.common.hsr.businesslogic.impl.HscComponentStatusImpl
import com.optum.app.common.hsr.data.HscComponentStatusVO

class HscComponentStatusSpec extends HsrReadLogicSpecification {

    HscComponentStatusImpl hscComponentStatusImpl = new HscComponentStatusImpl()

    DataAccessObject dao
    CustomerReference customerReference

    def setup() {
        dao = Mock(DataAccessObject)
        customerReference = Mock(CustomerReference)

        hscComponentStatusImpl.dao = dao
        hscComponentStatusImpl.customerReference = customerReference
    }

    def "test read"() {
        setup:

        when:
        hscComponentStatusImpl.read(123456L, "abc")

        then:
        1 * dao.read(_ as ReadProperties)
        0 * _._
    }

    def "test listByHscID"() {
        setup:

        when:
        hscComponentStatusImpl.listByHscID(123456L)

        then:
        1 * dao.list(_ as QueryProperties)
        0 * _._
    }

    def "test validate"() {
        setup:
        HscComponentStatusVO hscComponentStatusVO = new HscComponentStatusVO(hscID: 123456L, hscComponentType: componentType, hscComponentStatusType: componentStatusType)

        when:
        hscComponentStatusImpl.validate(hscComponentStatusVO, false)

        then:
        if(componentType != null) {
            1 * customerReference.validateReference(_ as HscComponentStatusVO, 'stepperLocation', 'abc', true)
        } else {
            assert hscComponentStatusVO.errorMessagesExist()
        }
        if(componentStatusType) {
            1 * customerReference.validateReference(_ as HscComponentStatusVO, 'stepperStatus', 'def', true)
        } else {
            assert hscComponentStatusVO.messages
        }
        0 * _._

        where:
        componentType | componentStatusType
        'abc'         | 'def'
//        null          | 'def'
//        'abc'         | null
    }

}
