package com.optum.app.ocm.hsr

import com.optum.app.ocm.common.activity.businesslogic.Activity
import com.optum.app.ocm.common.member.businesslogic.Member
import com.optum.app.ocm.ref.businesslogic.CustomerReference
import com.optum.rf.core.spring.ApplicationContextHolder
import com.optum.rf.core.util.UhgCalendar
import com.optum.rf.dao.exception.UhgRuntimeException
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.QueryCriteria
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.util.UhgCalendarUtilities
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.optum.rf.test.core.assertion.ValueObjectAsserter
import com.optum.rf.test.core.mock.spring.MockWebApplicationContext
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.*
import com.optum.app.common.hsr.businesslogic.impl.HscFacilityDecisionImpl
import com.optum.app.common.hsr.constants.HsrReferenceConstants
import com.optum.app.common.hsr.data.*
import com.optum.app.common.hsr.messages.HscDecisionMessages
import com.optum.app.common.member.core.data.MemberVO
import com.optum.app.ocm.common.security.businesslogic.AppUser
import com.optum.app.ocm.constants.SecurityConstants
import org.apache.commons.lang.StringUtils
import spock.lang.Unroll

/**
 * Contains tests for com.uhg.app.icue.hsr.hsc.businesslogic.impl.HscFacilityDecisionImpl.*/
class HscFacilityDecisionImplSpec extends HsrReadLogicSpecification {

    HscFacilityDecisionImpl hscFacilityDecision
    HscServiceDecision hscServiceDecision
    DataAccessObject dao
    Hsc hsc
    HscAlternateIdentifier hscAlternateIdentifier
    HscDiagnosis hscDiagnosis
    HscFacility hscFacility
    HscMemberCoverage hscMemberCoverage
    HscDecisionMemberCoverage hscDecisionMemberCoverage
    HscProvider hscProvider
    HscProviderRole hscProviderRole
    HscServiceLineTatHelper hscServiceLineTatHelper
    Member member
    CustomerReference customerReference
    HscDecisionProvider hscDecisionProvider
    PersistenceHelper persistenceHelper
    AbstractHscDecisionHelper abstractHscDecisionHelper
    AppUser appUser
    HscTatPointHelper tatPointHelper
    Activity activity

    protected def setup() {
        hscFacilityDecision = new HscFacilityDecisionImpl()

        hscServiceDecision = Mock(HscServiceDecision)
        dao = Mock(DataAccessObject)
        hsc = Mock(Hsc)
        hscAlternateIdentifier = Mock(HscAlternateIdentifier)
        hscDiagnosis = Mock(HscDiagnosis)
        hscFacility = Mock(HscFacility)
        hscMemberCoverage = Mock(HscMemberCoverage)
        hscDecisionMemberCoverage = Mock(HscDecisionMemberCoverage)
        hscProvider = Mock(HscProvider)
        hscProviderRole = Mock(HscProviderRole)
        hscServiceLineTatHelper = Mock(HscServiceLineTatHelper)
        member = Mock(Member)
        customerReference = Mock(CustomerReference)
        hscDecisionProvider = Mock(HscDecisionProvider)
        persistenceHelper = Mock(PersistenceHelper)
        abstractHscDecisionHelper = Mock(AbstractHscDecisionHelper)
        appUser = Mock(AppUser)
        tatPointHelper = Mock(HscTatPointHelper)
        activity = Mock(Activity)

        hscFacilityDecision.setRequiredDao(dao)
        hscFacilityDecision.setRequiredHscServiceDecision(hscServiceDecision)
        hscFacilityDecision.setRequiredDao(dao)
        hscFacilityDecision.setRequiredHsc(hsc)
        hscFacilityDecision.setRequiredHscAlternateIdentifier(hscAlternateIdentifier)
        hscFacilityDecision.setRequiredHscDiagnosis(hscDiagnosis)
        hscFacilityDecision.setRequiredHscFacility(hscFacility)
        hscFacilityDecision.setRequiredHscMemberCoverage(hscMemberCoverage)
        hscFacilityDecision.setRequiredHscDecisionMemberCoverage(hscDecisionMemberCoverage)
        hscFacilityDecision.setRequiredHscProvider(hscProvider)
        hscFacilityDecision.setRequiredHscProviderRole(hscProviderRole)
        hscFacilityDecision.setRequiredHscServiceLineTatHelper(hscServiceLineTatHelper)
        hscFacilityDecision.setRequiredMember(member)
        hscFacilityDecision.setRequiredCustomerReference(customerReference)
        hscFacilityDecision.setRequiredHscDecisionProvider(hscDecisionProvider)
        hscFacilityDecision.setRequiredPersistenceHelper(persistenceHelper)
        hscFacilityDecision.setRequiredAbstractHscDecisionHelper(abstractHscDecisionHelper)
        hscFacilityDecision.setRequiredAppUser(appUser)
        hscFacilityDecision.setRequiredTatPointHelper(tatPointHelper)
        hscFacilityDecision.setRequiredActivity(activity)

        MockWebApplicationContext applicationContext = (MockWebApplicationContext) ApplicationContextHolder.getApplicationContext()
    }

    @Unroll
    def "isValid #testCase"() {
        given:
        long hscID = 1
        short decisionSequenceNum = 2
        ReadProperties rp = new ReadProperties([FieldConstants.HSCID, FieldConstants.DECISIONSEQNUM] as String[])
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        rp.setKeyValue(FieldConstants.DECISIONSEQNUM, decisionSequenceNum)

        when:
        boolean retVal = hscFacilityDecision.isValid(hscID, decisionSequenceNum)

        then:
        1 * dao.isValid(rp) >> expectedVal
        0 * _
        retVal == expectedVal

        where:
        testCase | expectedVal
        "passes" | true
        "fails"  | false
    }

    def "read"() {
        given:
        HscFacilityDecisionVO vo = new HscFacilityDecisionVO(hscID: 1 as Long, decisionSeqNum: 2 as Short)

        ReadProperties rp = new ReadProperties([FieldConstants.HSCID, FieldConstants.DECISIONSEQNUM] as String[])
        rp.setKeyValue(FieldConstants.HSCID, vo.getHscID())
        rp.setKeyValue(FieldConstants.DECISIONSEQNUM, vo.getDecisionSeqNum())

        when:
        HscFacilityDecisionVO retVO = hscFacilityDecision.read(vo.getHscID(), vo.getDecisionSeqNum())

        then:
        1 * dao.read(rp) >> vo
        0 * _
        retVO == vo
    }

    def "after execute add - decision outcome type is cancelled"() {
        given:
        HscFacilityDecisionVO vo = new HscFacilityDecisionVO(hscID: 1 as Long, decisionOutcomeType: HsrReferenceConstants.DECISIONOUTCOMETYPE_CANCELED)

        when:
        hscFacilityDecision.afterExecuteAdd(vo)

        then:
        1 * hscServiceLineTatHelper.performUrJurisdictionForFacilityLine(vo.getHscID())
        0 * _
    }

    def "after execute update - decision outcome type is cancelled"() {
        given:
        HscFacilityDecisionVO vo = new HscFacilityDecisionVO(hscID: 1 as Long, decisionOutcomeType: HsrReferenceConstants.DECISIONOUTCOMETYPE_CANCELED)

        when:
        hscFacilityDecision.afterExecuteUpdate(vo)

        then:
        1 * hscServiceLineTatHelper.performUrJurisdictionForFacilityLine(vo.getHscID())
        0 * _
    }

    def "get current decision - hydrated"() {
        long hscID = 1
        HscFacilityDecisionVO vo = new HscFacilityDecisionVO(hscID: hscID)
        HscVO hscVO = new HscVO(hscID: hscID, specialProcessType: "test special process type", secondarySpecialProcessType: "test secondary special process type")

        when: "call made to getCurrentDecision which sets hydrated to true"
        HscFacilityDecisionVO returnVO = hscFacilityDecision.getCurrentDecision(vo);

        then: "VO has specialProcessType set to equal HscVO's specialProcessType"
        1 * dao.list(_) >> { QueryProperties qp ->
            assert qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == hscID
            assert qp.getQueryFilter(FieldConstants.INACTIVEIND).getFieldValue() == false
            assert qp.getQueryFilters().size() == 2
            return [vo]
        }
        1 * hsc.read(hscID, ['specialProcessType', 'secondarySpecialProcessType']) >> hscVO
        0 * _
        returnVO.specialProcessType.equals(hscVO.getMedicalNecessitySpecialProcessType())
    }

    def "get current decision - unhydrated"() {
        HscFacilityDecisionVO vo = new HscFacilityDecisionVO(hscID: 1 as Long)

        when: "call made to getCurrentDecisionUnhydrated runs getCurrentDecision with hydrated set to false"
        HscFacilityDecisionVO returnVO = hscFacilityDecision.getCurrentDecisionUnhydrated(vo);

        then:
        1 * dao.list(_) >> { QueryProperties qp ->
            assert qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == vo.getHscID()
            assert qp.getQueryFilter(FieldConstants.INACTIVEIND).getFieldValue() == false
            assert qp.getQueryFilters().size() == 2
            return [vo]
        }
        0 * _
        returnVO == vo
    }

    def "vo has existing facility decisions"() {
        HscFacilityDecisionVO vo = new HscFacilityDecisionVO(hscID: 1 as Long)
        vo.setHscFacilityDecisionSourceVOs([new HscFacilityDecisionSourceVO()])
        HscServiceDecisionVO hscServiceDecisionVO = vo.convertToServiceDecision()

        when:
        boolean returnVal = hscFacilityDecision.isDecisionSourceExist(vo)

        then:
        0 * _
        returnVal == true
    }

    def "vo has no existing facility decisions"() {
        HscFacilityDecisionVO vo = new HscFacilityDecisionVO(hscID: 1 as Long, decisionSeqNum: 2 as Short)

        when:
        boolean returnVal = hscFacilityDecision.isDecisionSourceExist(vo)

        then:
        0 * _
        returnVal == false
    }

    def "list of new facility decision source VOs contains the list of prior VOs"() {
        given:
        HscFacilityDecisionSourceVO vo = new HscFacilityDecisionSourceVO(hscID: 1 as Long)
        List<HscFacilityDecisionSourceVO> priorSources = [vo]
        List<HscFacilityDecisionSourceVO> newSources = [vo]

        when: "newSources contains priorSources"
        boolean returnVal = hscFacilityDecision.priorSourcesOnRenderedDecisionModified(priorSources, newSources)

        then:
        0 * _
        returnVal == false
    }

    def "list of new facility decision source VOs does not contain the list of prior VOs"() {
        given:
        HscFacilityDecisionSourceVO vo = new HscFacilityDecisionSourceVO(hscID: 1 as Long)
        List<HscFacilityDecisionSourceVO> priorSources = [vo]
        List<HscFacilityDecisionSourceVO> newSources = new ArrayList<HscFacilityDecisionSourceVO>()

        when: "newSources does not contain priorSources"
        boolean returnVal = hscFacilityDecision.priorSourcesOnRenderedDecisionModified(priorSources, newSources)

        then:
        0 * _
        returnVal == true
    }

    @Unroll()
    def "validate service details when admit date is in range of member coverage: admit date=#admitDate; coverage date from #covEffectDate to #covEndDate"() {
        given:
        long hscID = 1
        HscFacilityDecisionVO voToValidate = new HscFacilityDecisionVO(hscID: hscID)
        HscMemberCoverageVO coverageVO = new HscMemberCoverageVO(hscID: hscID, coverageEffectiveDate: covEffectDate, coverageEndDate: covEndDate)
        HscFacilityVO facilityVO = new HscFacilityVO(hscID: hscID, actualAdmissionDateTime: admitDate)
        HscVO hscVO = new HscVO(hscID: hscID)

        when:
        hscFacilityDecision.validateServiceDetails(hscVO, voToValidate, coverageVO, false)

        then:
        1 * hscFacility.read(hscID, []) >> facilityVO
        0 * _
        ValueObjectAsserter.assertMessageExists(voToValidate, HscDecisionMessages.ERR_ADMIT_DATE_OUTSIDE_COVERAGE)
        notThrown(UhgRuntimeException)

        where:
        admitDate                                                         | covEffectDate                        | covEndDate
        UhgCalendarUtilities.getTodaysCalendarInUserTimeZone().addDay(-1) | UhgCalendarUtilities.getTodaysDate() | null
        UhgCalendarUtilities.getTodaysCalendarInUserTimeZone().addDay(3)  | UhgCalendarUtilities.getTodaysDate() | new UhgCalendar().addDay(1).getSQLDate()
    }

    def "validate service details when admit date is same day as coverage end date"() {
        given:
        long hscID = 1
        HscFacilityDecisionVO voToValidate = new HscFacilityDecisionVO(hscID: hscID)
        UhgCalendar calendarTomorrowNoon = new UhgCalendar().addDay(1).clearTime()
        calendarTomorrowNoon.add(Calendar.HOUR_OF_DAY, 12) // This needs to be executed on separate line - not part of declaration above
        // Test where coverage is from today at midnight to tomorrow at midnight and admit date is tomorrow at noon
        HscMemberCoverageVO coverageVO = new HscMemberCoverageVO(coverageEffectiveDate: UhgCalendarUtilities.getTodaysDate().clearTime(), coverageEndDate: new UhgCalendar().addDay(1).clearTime().getSQLDate())
        HscFacilityVO facilityVO = new HscFacilityVO(hscID: hscID, actualAdmissionDateTime: calendarTomorrowNoon)
        HscVO hscVO = new HscVO(hscID: hscID)

        when:
        hscFacilityDecision.validateServiceDetails(hscVO, voToValidate, coverageVO, false)

        then:
        1 * hscFacility.read(hscID, []) >> facilityVO
        0 * _
        ValueObjectAsserter.assertErrorMessagesDoNotExist(voToValidate)
        notThrown(UhgRuntimeException)
    }

    def "cascade cancel to facility line"() {
        given:
        long hscID = 1
        long memberID = 2
        short memberCovSeqNum = 3
        short decisionSeqNum = 4
        HscFacilityDecisionVO facilityDecisionVO = new HscFacilityDecisionVO(hscID: hscID, decisionSeqNum: decisionSeqNum, inactiveInd: false, decisionOutcomeType: "test decision", memberCoverageSeqNum: memberCovSeqNum, decisionRenderedDateTime: new UhgCalendar(2016, 5, 13), overrideClaimRemarkCode: "0", hscFacilityDecisionSourceVOs: new ArrayList<HscFacilityDecisionSourceVO>(), hscFacilityDecisionActivityVOs: new ArrayList<HscFacilityDecisionActivityVO>())
        HscVO hscVO = new HscVO(hscID: hscID, memberID: memberID, memberCoverageSeqNum: memberCovSeqNum, createUserID: SecurityConstants.SYSTEM_USER_ID_PREFIX, specialProcessType: "test special type")
        HscMemberCoverageVO memberCoverageVO = new HscMemberCoverageVO(hscID: hscID, memberCoverageSeqNum: memberCovSeqNum, policyNumber: 123456)
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: hscID)

        MemberVO memberVO = new MemberVO(memberID: memberID)

        when:
        hscFacilityDecision.cascadeCancelToFacilityLine(hscVO)

        then: "because inactiveInd is set to true immediately before an update is called, the cancel fails, errors on VO, runtimeException is thrown"
        1 * dao.list(_) >> { QueryProperties qp ->
            assert qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == hscID
            assert qp.getQueryFilter(FieldConstants.INACTIVEIND).getFieldValue() == false
            assert qp.getQueryFilters().size() == 2
            return [facilityDecisionVO]
        }
        1 * hscFacility.setFacilityLineLock(1, '3')
        1 * hsc.read(hscID, ['specialProcessType', 'secondarySpecialProcessType']) >> hscVO
        0 * _
    }

    def "cascade cancel to facility line where decisionOutcomeType=CANCELLED"() {
        given:
        long hscID = 1
        long memberID = 2
        short memberCovSeqNum = 3
        short decisionSeqNum = 4
        HscFacilityDecisionVO facilityDecisionVO = new HscFacilityDecisionVO(hscID: hscID, decisionSeqNum: decisionSeqNum, inactiveInd: false, decisionOutcomeType: HsrReferenceConstants.DECISIONOUTCOMETYPE_CANCELED, memberCoverageSeqNum: memberCovSeqNum, decisionRenderedDateTime: new UhgCalendar(2016, 5, 13), overrideClaimRemarkCode: "0", hscFacilityDecisionSourceVOs: new ArrayList<HscFacilityDecisionSourceVO>(), hscFacilityDecisionActivityVOs: new ArrayList<HscFacilityDecisionActivityVO>())
        HscVO hscVO = new HscVO(hscID: hscID, memberID: memberID, memberCoverageSeqNum: memberCovSeqNum, createUserID: SecurityConstants.SYSTEM_USER_ID_PREFIX, specialProcessType: "test special type")
        MemberVO memberVO = new MemberVO(memberID: memberID)

        when:
        hscFacilityDecision.cascadeCancelToFacilityLine(hscVO)

        then:
        1 * dao.list(_) >> { QueryProperties qp ->
            assert qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == hscID
            assert qp.getQueryFilter(FieldConstants.INACTIVEIND).getFieldValue() == false
            assert qp.getQueryFilters().size() == 2
            return [facilityDecisionVO]
        }
        1 * hsc.read(hscID, ['specialProcessType', 'secondarySpecialProcessType']) >> hscVO
    }

    def "get hsc facility decision history list"() {
        given:
        long hscID = 1
        short decisionMemberCovSeqNum = 2
        HscFacilityDecisionVO provVO = new HscFacilityDecisionVO(hscID: hscID, decisionMemberCoverageSeqNum: decisionMemberCovSeqNum, decisionProviderSeqNum: 3)
        HscFacilityDecisionVO nonProvVO = new HscFacilityDecisionVO(hscID: hscID, decisionMemberCoverageSeqNum: decisionMemberCovSeqNum)

        when:
        List<HscFacilityDecisionVO> hscFacilityDecisionHistoryList = hscFacilityDecision.getHscFacilityDecisionHistoryList(hscID)

        then:
        1 * dao.list(_) >> { QueryProperties qp ->
            assert qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == hscID
            assert qp.getQueryFilter(FieldConstants.DECISIONOUTCOMETYPE).getCriterion().equals(QueryCriteria.IS_NOT_NULL)
            assert qp.getQueryFilters().size() == 2
            return [provVO, nonProvVO]
        }
        0 * _
    }

    def "update letter request properties"() {
        given:
        HscFacilityDecisionVO hscFacilityDecisionVO = new HscFacilityDecisionVO(hscID: 1 as Long)

        when:
        hscFacilityDecision.updateLetterRequestProperties(hscFacilityDecisionVO)

        then:
        1 * persistenceHelper.updateSubset(hscFacilityDecisionVO,
                                           (String[]) {
                                               FieldConstants.POLICYDOCUMENTTYPE; FieldConstants.MEDICALPOLICYNAMEORGUIDELINE;
                                               FieldConstants.LANGUAGESOURCEANDSECTIONNAME; FieldConstants.STATEOFJURISDICTION;
                                               FieldConstants.STATESPECIFICPLANINFOFORKYHMO; FieldConstants.OHIOPLANS; FieldConstants.RECIPIENTFAXNUMBER;
                                               FieldConstants.RECIPIENTFAXINTERNATIONALIND; FieldConstants.LANGUAGE; FieldConstants.LETTERRATIONALE
                                           },
                                           true
        )
        0 * _
    }

    def "update letter request properties: update subset fails"() {
        given:
        HscFacilityDecisionVO hscFacilityDecisionVO = new HscFacilityDecisionVO(hscID: 1 as Long)

        when:
        hscFacilityDecision.updateLetterRequestProperties(hscFacilityDecisionVO)

        then: "updateSubset throws exception; update fails"
        1 * persistenceHelper.updateSubset(hscFacilityDecisionVO,
                                           (String[]) {
                                               FieldConstants.POLICYDOCUMENTTYPE; FieldConstants.MEDICALPOLICYNAMEORGUIDELINE;
                                               FieldConstants.LANGUAGESOURCEANDSECTIONNAME; FieldConstants.STATEOFJURISDICTION;
                                               FieldConstants.STATESPECIFICPLANINFOFORKYHMO; FieldConstants.OHIOPLANS; FieldConstants.RECIPIENTFAXNUMBER;
                                               FieldConstants.RECIPIENTFAXINTERNATIONALIND; FieldConstants.LANGUAGE; FieldConstants.LETTERRATIONALE
                                           },
                                           true
        ) >> { throw new UhgRuntimeException() }
        0 * _
        thrown UhgRuntimeException
    }

    def "valid updateBatchFacilityDecisions"() {
        given:
        HscFacilityDecisionVO vo = new HscFacilityDecisionVO(hscID: 1 as Long)

        when:
        hscFacilityDecision.updateBatchFacilityDecisions([vo])

        then:
        1 * dao.updateBatch([vo])
        0 * _
    }

    def "valid updateDecisionMemberCoverageSeqNum"() {
        given:
        HscFacilityDecisionVO hscFacilityDecisionVO = new HscFacilityDecisionVO(hscID: 1 as Long)

        when:
        hscFacilityDecision.updateDecisionMemberCoverageSeqNum(hscFacilityDecisionVO)

        then:
        1 * persistenceHelper.updateSubset(hscFacilityDecisionVO,
                                           (String[]) { FieldConstants.DECISIONMEMBERCOVERAGESEQNUM },
                                           true
        )
        0 * _
    }

    def "updateDecisionMemberCoverageSeqNum: updateSubset fails"() {
        given:
        HscFacilityDecisionVO hscFacilityDecisionVO = new HscFacilityDecisionVO(hscID: 1 as Long)

        when:
        hscFacilityDecision.updateDecisionMemberCoverageSeqNum(hscFacilityDecisionVO)

        then:
        1 * persistenceHelper.updateSubset(hscFacilityDecisionVO,
                                           (String[]) { FieldConstants.DECISIONMEMBERCOVERAGESEQNUM },
                                           true
        ) >> { throw new UhgRuntimeException() }
        0 * _
        thrown UhgRuntimeException
    }

    def "validate number of extended days for a pre-service case with createUserID containing System User Prefix"() {
        long hscID = 1
        HscFacilityDecisionVO hscFacilityDecisionVO = new HscFacilityDecisionVO(hscID: hscID)
        HscVO hscVO = new HscVO(hscID: hscID, createUserID: SecurityConstants.SYSTEM_USER_ID_PREFIX)
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: hscID)

        when:
        hscFacilityDecision.validateNumberOfExtendedDays(hscVO, hscFacilityDecisionVO)

        then:
        1 * hscFacility.read(hscID, []) >> hscFacilityVO
        1 * hsc.isPreServiceCase(hscVO, hscFacilityVO) >> true
        0 * _
        hscFacilityDecisionVO.approvedBedDayCount == 1
    }

    def "get last decision rendered"() {
        given:
        HscFacilityDecisionVO vo = hscFacilityDecision.newDecisionVO()
        HscFacilityDecisionVO vo2 = new HscFacilityDecisionVO(hscID: vo.getHscID(), decisionOutcomeType: "2")

        when:
        HscFacilityDecisionVO retVO = hscFacilityDecision.getLastDecisionRendered(vo, true)

        then:
        1 * dao.list(_) >> { QueryProperties qp ->
            assert qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == vo.getHscID()
            assert qp.getQueryFilter(FieldConstants.DECISIONOUTCOMETYPE).getCriterion().equals(QueryCriteria.IS_NOT_NULL)
            assert qp.getQueryFilters().size() == 2
            return [vo2]
        }
        0 * _
        retVO == vo2
    }

    def "get matching service sequence nums"() {
        given:
        HscFacilityDecisionVO vo = new HscFacilityDecisionVO(hscID: 1 as Long)

        when:
        List retList = hscFacilityDecision.getMatchingServiceSeqNums(vo)

        then:
        0 * _
        retList == new ArrayList<Short>()
    }

    def "get provider for decision"() {
        given:
        HscFacilityDecisionVO vo = new HscFacilityDecisionVO(hscID: 1 as Long)
        HscProviderVO provVO = new HscProviderVO(hscID: vo.getHscID())

        when:
        HscProviderVO retVO = hscFacilityDecision.getProviderForDecision(vo)

        then:
        1 * hscProvider.getFacilityRoleProvider(vo.getHscID()) >> provVO
        0 * _
        retVO == provVO
    }

    def "validate number of extended days where copiedVO==0 and decision is rendered"() {
        given:
        HscFacilityDecisionVO vo = new HscFacilityDecisionVO(hscID: 1 as Long, decisionOutcomeType: HsrReferenceConstants.DECISIONOUTCOMETYPE_CANCELED, decisionRenderedDateTime: new UhgCalendar(2015, 2, 3))
        HscVO hscVO = new HscVO(hscID: vo.getHscID(), copiedHscID: 0, createUserID: "testUser")
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: vo.getHscID())

        when:
        hscFacilityDecision.validateNumberOfExtendedDays(hscVO, vo)

        then:
        1 * hscFacility.read(vo.getHscID(), []) >> hscFacilityVO
        1 * hsc.isPreServiceCase(hscVO, hscFacilityVO) >> true
        0 * _
        vo.getApprovedBedDayCount() == 1
    }

    def "update written decision communication date time"() {
        given:
        HscFacilityDecisionVO hscFacilityDecisionVO = new HscFacilityDecisionVO(hscID: 1 as Long)

        when:
        hscFacilityDecision.updateWrittenDecnCommDateTime(hscFacilityDecisionVO)

        then:
        1 * persistenceHelper.updateSubset(hscFacilityDecisionVO, { FieldConstants.WRITTENDECNCOMMDATETIME } as String[], true)
        0 * _
    }

    def "set full name on user ids for facility"() {
        given:
        HscFacilityDecisionVO vo = new HscFacilityDecisionVO(hscID: 1 as Long)

        when:
        hscFacilityDecision.setFullNameOnUserIdsForFacility(vo)

        then:
        0 * _
    }

    def "update decision member coverage sequence number"() {
        given:
        HscFacilityDecisionVO hscFacilityDecisionVO = new HscFacilityDecisionVO(hscID: 1 as Long, decisionMemberCoverageSeqNum: 2 as Short)

        when:
        hscFacilityDecision.updateDecisionMemberCoverageSeqNum(hscFacilityDecisionVO)

        then:
        1 * persistenceHelper.updateSubset(hscFacilityDecisionVO, { FieldConstants.DECISIONMEMBERCOVERAGESEQNUM } as String[], true)
        0 * _
    }

    def "update decision member coverage sequence number fails"() {
        given:
        HscFacilityDecisionVO hscFacilityDecisionVO = new HscFacilityDecisionVO(hscID: 1 as Long, decisionMemberCoverageSeqNum: 2 as Short)

        when:
        hscFacilityDecision.updateDecisionMemberCoverageSeqNum(hscFacilityDecisionVO)

        then:
        1 * persistenceHelper.updateSubset(hscFacilityDecisionVO, { FieldConstants.DECISIONMEMBERCOVERAGESEQNUM } as String[], true) >> { throw new Exception() }
        0 * _
        thrown UhgRuntimeException
    }

    @Unroll
    def "has an approved first decision"() {
        given:
        long hscID = 1

        when:
        boolean retVal = hscFacilityDecision.hasAnApprovedFirstDecision(hscID)

        then:
        1 * dao.exists(_) >> { QueryProperties qp ->
            assert qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == hscID
            assert qp.getQueryFilter(FieldConstants.DECISIONSEQNUM).getFieldValue() == (short) 1
            assert qp.getQueryFilter(FieldConstants.DECISIONOUTCOMETYPE).getFieldValue().equals(HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED)
            return expectedVal
        }
        0 * _
        retVal == expectedVal

        where:
        seq | expectedVal
        1   | true
        2   | false
    }

    def "list current approved by HscID"() {
        given:
        long hscID = 1
        List<HscFacilityDecisionVO> voList = [new HscFacilityDecisionVO(hscID: hscID, inactiveInd: false, decisionOutcomeType: HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED)]

        when:
        List<HscFacilityDecisionVO> retList = hscFacilityDecision.listCurrentApprovedByHscID(hscID)

        then:
        1 * dao.list(_) >> { QueryProperties qp ->
            assert qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == hscID
            assert qp.getQueryFilter(FieldConstants.INACTIVEIND).getFieldValue() == false
            assert qp.getQueryFilter(FieldConstants.DECISIONOUTCOMETYPE).getFieldValue().equals(HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED)
            return voList
        }
        0 * _
        retList == voList
    }

    def "list current by HscID"() {
        given:
        long hscID = 1
        List<HscFacilityDecisionVO> voList = [new HscFacilityDecisionVO(hscID: hscID, inactiveInd: false, decisionOutcomeType: HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED)]

        when:
        List<HscFacilityDecisionVO> retList = hscFacilityDecision.listCurrentByHscID(hscID)

        then:
        1 * dao.list(_) >> { QueryProperties qp ->
            assert qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == hscID
            assert qp.getQueryFilter(FieldConstants.INACTIVEIND).getFieldValue() == false
            return voList
        }
        0 * _
        retList == voList
    }

    def "update letter request properties where VO has errors"() {
        given:
        HscFacilityDecisionVO hscFacilityDecisionVO = new HscFacilityDecisionVO(hscID: 1 as Long, recipientFaxNumber: "a")

        when: "recipientFaxNumber is invalid format, errors are set on VO"
        hscFacilityDecision.updateLetterRequestProperties(hscFacilityDecisionVO)

        then:
        0 * _
        thrown UhgRuntimeException
    }

    def "log coverage decision TAT points where decnMbrCommunicatedDateTime is not null"() {
        given:
        HscFacilityDecisionVO vo = new HscFacilityDecisionVO(hscID: 1 as Long, decnMbrCommunicatedDateTime: new UhgCalendar(2016, 5, 13))

        when:
        hscFacilityDecision.logCoverageDecisionTatPoints(vo)

        then:
        0 * _
    }

    def "log coverage decision TAT points where decnProvCommunicatedDateTime is not null"() {
        given:
        HscFacilityDecisionVO vo = new HscFacilityDecisionVO(hscID: 1 as Long, decnProvCommunicatedDateTime: new UhgCalendar(2016, 5, 13))

        when:
        hscFacilityDecision.logCoverageDecisionTatPoints(vo)

        then:
        0 * _
    }
}
