package com.optum.app.ocm.hsr

import com.optum.rf.bl.spring.TransactionInterceptor
import com.optum.rf.core.locator.ServiceLocator
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.HscLetterRequestElgsTaskVar
import com.optum.app.common.hsr.businesslogic.impl.HscLetterRequestElgsTaskVarImpl
import com.optum.app.common.hsr.data.HscLetterRequestElgsTaskVarVO
import spock.lang.Unroll

class HscLetterRequestElgsTaskVarSpec extends HsrReadLogicSpecification {

    HscLetterRequestElgsTaskVar hscLetterRequestElgsTask

    DataAccessObject dao
    PersistenceHelper persistenceHelper
    ServiceLocator serviceLocator
    TransactionInterceptor transactionInterceptor

    def setup() {
        dao = Mock(DataAccessObject)
        persistenceHelper = Mock(PersistenceHelper)
        serviceLocator = Mock(ServiceLocator)
        transactionInterceptor = Mock(TransactionInterceptor)

        hscLetterRequestElgsTask = new HscLetterRequestElgsTaskVarImpl(
                requiredPersistenceHelper: persistenceHelper,
                requiredServiceLocator: serviceLocator,
                requiredTransactionInterceptor: transactionInterceptor
        )
        hscLetterRequestElgsTask.setRequiredDao(dao)
    }

    @Unroll
    def "isValid #testCase"() {
        given:
        def hscID = (long) 1
        def letterRequestSeqNum = 2
        def letterRequestLetterGenID = "3"
        def elgsTaskCode = "4"
        def elgsVariableName = "5"
        def rp = new ReadProperties(FieldConstants.HSCID, FieldConstants.LETTERREQUESTSEQNUM, FieldConstants.LETTERREQUESTLETTERGENID, FieldConstants.ELGSTASKCODE, FieldConstants.ELGSVARIABLENAME)
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        rp.setKeyValue(FieldConstants.LETTERREQUESTSEQNUM, letterRequestSeqNum)
        rp.setKeyValue(FieldConstants.LETTERREQUESTLETTERGENID, letterRequestLetterGenID)
        rp.setKeyValue(FieldConstants.ELGSTASKCODE, elgsTaskCode)
        rp.setKeyValue(FieldConstants.ELGSVARIABLENAME, elgsVariableName)
        rp.fields = null

        when:
        boolean retVal = hscLetterRequestElgsTask.isValid(hscID, letterRequestSeqNum, letterRequestLetterGenID, elgsTaskCode, elgsVariableName)

        then:
        1 * dao.isValid(rp) >> expectedVal
        0 * _
        retVal == expectedVal

        where:
        testCase | expectedVal
        "passes" | true
        "fails"  | false
    }

    def "Test to read HscLetterRequestElgsTaskVarVO"() {
        setup:
        def hscID = (long) 1
        def letterRequestSeqNum = 2
        def letterRequestLetterGenID = "3"
        def elgsTaskCode = "4"
        def elgsVariableName = "5"
        HscLetterRequestElgsTaskVarVO hscLetterRequestElgsTaskVarVO = new HscLetterRequestElgsTaskVarVO(hscID: hscID, letterRequestSeqNum: letterRequestSeqNum, letterRequestLetterGenID: letterRequestLetterGenID, elgsTaskCode: elgsTaskCode, elgsVariableName: elgsVariableName)
        def rp = new ReadProperties(FieldConstants.HSCID, FieldConstants.LETTERREQUESTSEQNUM, FieldConstants.LETTERREQUESTLETTERGENID, FieldConstants.ELGSTASKCODE, FieldConstants.ELGSVARIABLENAME)
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        rp.setKeyValue(FieldConstants.LETTERREQUESTSEQNUM, letterRequestSeqNum)
        rp.setKeyValue(FieldConstants.LETTERREQUESTLETTERGENID, letterRequestLetterGenID)
        rp.setKeyValue(FieldConstants.ELGSTASKCODE, elgsTaskCode)
        rp.setKeyValue(FieldConstants.ELGSVARIABLENAME, elgsVariableName)
        rp.fields = null

        when:
        hscLetterRequestElgsTask.read(hscID, letterRequestSeqNum, letterRequestLetterGenID, elgsTaskCode, elgsVariableName)

        then:
        1 * dao.read(rp) >> hscLetterRequestElgsTaskVarVO
        0 * _
    }

    def "Test readOrCreate"() {
        setup:
        def hscID = (long) 1
        def letterRequestSeqNum = 2
        def letterRequestLetterGenID = "3"
        def elgsTaskCode = "4"
        def elgsVariableName = "5"
        def rp = new ReadProperties(FieldConstants.HSCID, FieldConstants.LETTERREQUESTSEQNUM, FieldConstants.LETTERREQUESTLETTERGENID, FieldConstants.ELGSTASKCODE, FieldConstants.ELGSVARIABLENAME)
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        rp.setKeyValue(FieldConstants.LETTERREQUESTSEQNUM, letterRequestSeqNum)
        rp.setKeyValue(FieldConstants.LETTERREQUESTLETTERGENID, letterRequestLetterGenID)
        rp.setKeyValue(FieldConstants.ELGSTASKCODE, elgsTaskCode)
        rp.setKeyValue(FieldConstants.ELGSVARIABLENAME, elgsVariableName)
        rp.fields = null

        when:
        hscLetterRequestElgsTask.readOrCreate(hscID, letterRequestSeqNum, letterRequestLetterGenID, elgsTaskCode, elgsVariableName)

        then:
        1 * dao.read(rp)
        0 * _
    }

    def "Test listDetails"() {
        setup:
        def hscID = (long) 1
        def letterRequestSeqNum = 2
        def letterRequestLetterGenID = "3"

        when:
        hscLetterRequestElgsTask.listDetails(hscID, letterRequestSeqNum, letterRequestLetterGenID)

        then:
        1 * dao.list(_ as QueryProperties)
        0 * _
    }

}
