package com.optum.app.ocm.hsr

import com.optum.app.ocm.common.activity.businesslogic.Activity
import com.optum.rf.core.util.UhgCalendar
import com.optum.rf.dao.util.UhgCalendarUtilities
import com.optum.app.common.activity.data.ActivityVO
import com.optum.app.common.constants.ActivityReferenceConstants
import com.optum.app.common.constants.CommonReferenceConstants
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.*
import com.optum.app.common.hsr.businesslogic.impl.HscTatPointHelperImpl
import com.optum.app.common.hsr.constants.HsrReferenceConstants
import com.optum.app.common.hsr.data.*
import spock.lang.Unroll
import com.optum.app.shared.tat.businesslogic.TatHelper

class HscTatPointHelperImplSpec extends HsrReadLogicSpecification {
    private HscTatPointHelperImpl tatPointHelper
    private HscServiceTatPoint hscServiceTatPoint
    private HscLetterRequest hscLetterRequest
    private HscService hscService
    private HscServiceNonFacility hscServiceNonFacility
    private Activity activity
    private Hsc hsc
    private HscAlternateIdentifier hscAlternateIdentifier
    private HscFacilityDecision hscFacilityDecision
    private HscServiceDecision hscServiceDecision
    private HscFacility hscFacility
    private HscServiceFacility hscServiceFacility
    private TatHelper tatHelper
    private static final long HSC_ID = 123
    private static final long ACTIVITY_ID = 456
    private static final short SERVICE_SEQ_NUM = 1
    private static final short DECISION_SEQ_NUM = 2

    public void setup() {
        hscServiceTatPoint = Mock(HscServiceTatPoint)
        hscService = Mock(HscService)
        hscServiceNonFacility = Mock(HscServiceNonFacility)
        activity = Mock(Activity)
        hsc = Mock(Hsc)
        hscLetterRequest = Mock(HscLetterRequest)
        hscAlternateIdentifier = Mock(HscAlternateIdentifier)
        hscFacilityDecision = Mock(HscFacilityDecision)
        hscServiceDecision = Mock(HscServiceDecision)
        hscFacility = Mock(HscFacility)
        hscServiceFacility = Mock(HscServiceFacility)
        tatHelper = Mock(TatHelper)

        tatPointHelper = new HscTatPointHelperImpl()
        tatPointHelper.setRequiredHscServiceTatPt(hscServiceTatPoint)
        tatPointHelper.setRequiredHscService(hscService)
        tatPointHelper.setRequiredHscServiceNonFacility(hscServiceNonFacility)
        tatPointHelper.setRequiredHsc(hsc)
        tatPointHelper.setRequiredHscAlternateIdentifier(hscAlternateIdentifier)
        tatPointHelper.setRequiredHscServiceDecision(hscServiceDecision)
        tatPointHelper.setRequiredHscServiceFacility(hscServiceFacility)
        tatPointHelper.setRequiredTatHelper(tatHelper)
    }

    def "checkAndLogInfoReceiptTatPointForService: TATPOINT REQ_MORE_INFO Does not exist and RECP_ALL_INFO exists"() {
        given:
        ActivityVO activityVO = new ActivityVO(hscID: HSC_ID)

        when:
        tatPointHelper.checkAndLogInfoReceiptTatPointForService(activityVO, SERVICE_SEQ_NUM)

        then:
        1 * hscServiceTatPoint.isValid(HSC_ID, SERVICE_SEQ_NUM, HsrReferenceConstants.TATPOINTTYPE_REQ_MORE_INFO) >> false
        0 * _
    }

    def "checkAndLogInfoReceiptTatPointForService: TATPOINT REQ_MORE_INFO exists and RECP_ALL_INFO Does not exist"() {
        given:
        ActivityVO activityVO = new ActivityVO(hscID: HSC_ID)
        HscVO hscVO = new HscVO(hscID: HSC_ID)
        HscServiceTatPointVO addTatPointVO = new HscServiceTatPointVO()
        addTatPointVO.hscID = HSC_ID
        addTatPointVO.serviceSeqNum = SERVICE_SEQ_NUM
        addTatPointVO.tatPointType = HsrReferenceConstants.TATPOINTTYPE_RECP_ALL_INFO
        addTatPointVO.tatPointDateTime = activityVO.getCreateDateTime()
        addTatPointVO.activityID = activityVO.getActivityID()

        when:
        tatPointHelper.checkAndLogInfoReceiptTatPointForService(activityVO, SERVICE_SEQ_NUM)

        then:
        1 * hscServiceTatPoint.isValid(HSC_ID, SERVICE_SEQ_NUM, HsrReferenceConstants.TATPOINTTYPE_REQ_MORE_INFO) >> true
        1 * hscServiceTatPoint.isValid(HSC_ID, SERVICE_SEQ_NUM, HsrReferenceConstants.TATPOINTTYPE_RECP_ALL_INFO) >> false
        1 * hsc.read(HSC_ID) >> hscVO
        1 * hscAlternateIdentifier.read(HSC_ID, HsrReferenceConstants.HSCALTERNATEIDTYPE_STARSAPPEALSNUMBER) >> null
        1 * hscServiceTatPoint.add(addTatPointVO)
        0 * _
    }

    def "logCNSTatActivitiesForFacility: Not a TAT activity"() {
        given:
        ActivityVO activityVO = new ActivityVO(activityType: ActivityReferenceConstants.ACTIVITYTYPE_LOI_LETTER, hscID: HSC_ID, createDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone())

        when:
        tatPointHelper.logCNSTatActivitiesForFacility(activityVO)

        then:
        0 * _
    }

    def "logCNSTatActivitiesForFacility: INTAKE_COMPLETE TAT activity"() {
        given:
        ActivityVO activityVO = new ActivityVO(activityType: ActivityReferenceConstants.ACTIVITYTYPE_INTAKE_COMPLETE, activityID: ACTIVITY_ID, hscID: HSC_ID, createDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone())

        when:
        tatPointHelper.logCNSTatActivitiesForFacility(activityVO)

        then:
        0 * _
    }

    def "logCNSTatActivitiesForFacility: REQUEST_CLIN_INFO TAT activity"() {
        given:
        ActivityVO activityVO = new ActivityVO(activityType: ActivityReferenceConstants.ACTIVITYTYPE_REQUEST_CLIN_INFO, activityID: ACTIVITY_ID, hscID: HSC_ID, createDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone())

        when:
        tatPointHelper.logCNSTatActivitiesForFacility(activityVO)

        then:
        0 * _
    }

    def "logCNSTatActivitiesForFacility: RECP_ALL_INFO TAT activity"() {
        given:
        ActivityVO activityVO = new ActivityVO(activityType: ActivityReferenceConstants.ACTIVITYTYPE_RECEIVED_COMPLETE_CLIN_INFO, activityID: ACTIVITY_ID, hscID: HSC_ID, createDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone())

        when:
        tatPointHelper.logCNSTatActivitiesForFacility(activityVO)

        then:
        0 * _
    }

    def "logCNSTatActivitiesForFacility: MANUAL_LETTER_SENT TAT activity"() {
        given:
        ActivityVO activityVO = new ActivityVO(activityType: ActivityReferenceConstants.ACTIVITYTYPE_MANUAL_LETTER_SENT, activityID: ACTIVITY_ID, hscID: HSC_ID, createDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone())

        when:
        tatPointHelper.logCNSTatActivitiesForFacility(activityVO)

        then:
        0 * _
    }

    def "logCNSTatActivitiesForFacility: DECISION_COMMUNICATION TAT activity, no current Decision"() {
        given:
        ActivityVO activityVO = new ActivityVO(activityType: ActivityReferenceConstants.ACTIVITYTYPE_DECISION_COMMUNICATION, activityID: ACTIVITY_ID, hscID: HSC_ID, createDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone())

        when:
        tatPointHelper.logCNSTatActivitiesForFacility(activityVO)

        then:
        0 * _
    }

    def "logCNSTatActivitiesForFacility: DECISION_COMMUNICATION TAT activity, has current Decision"() {
        given:
        ActivityVO activityVO = new ActivityVO(activityType: ActivityReferenceConstants.ACTIVITYTYPE_DECISION_COMMUNICATION, activityID: ACTIVITY_ID, hscID: HSC_ID, createDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone())

        when:
        tatPointHelper.logCNSTatActivitiesForFacility(activityVO)

        then:
        0 * _
    }

    def "logCNSTatActivitiesForFacility: RECP_ALL_INFO TAT activity, TatPoint already Exists"() {
        given:
        ActivityVO activityVO = new ActivityVO(activityType: ActivityReferenceConstants.ACTIVITYTYPE_RECEIVED_COMPLETE_CLIN_INFO, activityID: ACTIVITY_ID, hscID: HSC_ID, createDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone())

        when:
        tatPointHelper.logCNSTatActivitiesForFacility(activityVO)

        then:
        0 * _
    }

    def "logCNSTatActivitiesForFacility: RECP_ALL_INFO TAT activity, TatPoint does not exist"() {
        given:
        ActivityVO activityVO = new ActivityVO(activityType: ActivityReferenceConstants.ACTIVITYTYPE_RECEIVED_COMPLETE_CLIN_INFO, activityID: ACTIVITY_ID, hscID: HSC_ID, createDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone())

        when:
        tatPointHelper.logCNSTatActivitiesForFacility(activityVO)

        then:
        0 * _
    }

    def "logCNSTatActivitiesForFacility: hscStatus Case ReOpen ReasonType is RECONSIDER"() {
        given:
        ActivityVO activityVO = new ActivityVO(activityType: ActivityReferenceConstants.ACTIVITYTYPE_RECEIVED_COMPLETE_CLIN_INFO, activityID: ACTIVITY_ID, hscID: HSC_ID, createDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone())

        when:
        tatPointHelper.logCNSTatActivitiesForFacility(activityVO)

        then:
        0 * _
    }

    def "logCNSTatActivitiesForFacility: hscStatus Case ReOpen ReasonType is APPEAL"() {
        given:
        ActivityVO activityVO = new ActivityVO(activityType: ActivityReferenceConstants.ACTIVITYTYPE_RECEIVED_COMPLETE_CLIN_INFO, activityID: ACTIVITY_ID, hscID: HSC_ID, createDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone())

        when:
        tatPointHelper.logCNSTatActivitiesForFacility(activityVO)

        then:
        0 * _
    }

    def "logCNSTatActivitiesForFacility: hscStatus Case ReOpen  ReasonType is PRESERVICE_APPEAL"() {
        given:
        ActivityVO activityVO = new ActivityVO(activityType: ActivityReferenceConstants.ACTIVITYTYPE_RECEIVED_COMPLETE_CLIN_INFO, activityID: ACTIVITY_ID, hscID: HSC_ID, createDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone())

        when:
        tatPointHelper.logCNSTatActivitiesForFacility(activityVO)

        then:
        0 * _
    }

    def "logCNSTatActivitiesForFacility: hscStatus Case ReOpen ReasonType is POSTSERVICE_APPEAL"() {
        given:
        ActivityVO activityVO = new ActivityVO(activityType: ActivityReferenceConstants.ACTIVITYTYPE_RECEIVED_COMPLETE_CLIN_INFO, activityID: ACTIVITY_ID, hscID: HSC_ID, createDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone())

        when:
        tatPointHelper.logCNSTatActivitiesForFacility(activityVO)

        then:
        0 * _
    }

    def "logCNSTatActivitiesForFacility: hscAlternateIdentifierVO is not null"() {
        given:
        ActivityVO activityVO = new ActivityVO(activityType: ActivityReferenceConstants.ACTIVITYTYPE_RECEIVED_COMPLETE_CLIN_INFO, activityID: ACTIVITY_ID, hscID: HSC_ID, createDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone())

        when:
        tatPointHelper.logCNSTatActivitiesForFacility(activityVO)

        then:
        0 * _
    }

    def "logCNSTatActivitiesForService: Not a TAT activity"() {
        given:
        ActivityVO activityVO = new ActivityVO(activityType: ActivityReferenceConstants.ACTIVITYTYPE_LOI_LETTER, hscID: HSC_ID, createDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone())

        when:
        tatPointHelper.logCNSTatActivitiesForService(activityVO, SERVICE_SEQ_NUM)

        then:
        0 * _
    }

    def "logCNSTatActivitiesForService: INTAKE_COMPLETE TAT activity"() {
        given:
        ActivityVO activityVO = new ActivityVO(activityType: ActivityReferenceConstants.ACTIVITYTYPE_INTAKE_COMPLETE, activityID: ACTIVITY_ID, hscID: HSC_ID, createDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone())
        HscServiceTatPointVO addTatPointVO = new HscServiceTatPointVO(hscID: activityVO.hscID, serviceSeqNum: SERVICE_SEQ_NUM, tatPointType: HsrReferenceConstants.TATPOINTTYPE_NOTIFICATION, activityID: activityVO.getActivityID(), tatPointDateTime: activityVO.getCreateDateTime())

        when:
        tatPointHelper.logCNSTatActivitiesForService(activityVO, SERVICE_SEQ_NUM)

        then:
        1 * hscServiceTatPoint.read(activityVO.getHscID(), SERVICE_SEQ_NUM, HsrReferenceConstants.TATPOINTTYPE_NOTIFICATION) >> null
        1 * hsc.read(activityVO.getHscID()) >> new HscVO(hscID: HSC_ID)
        1 * hscAlternateIdentifier.read(activityVO.getHscID(), HsrReferenceConstants.HSCALTERNATEIDTYPE_STARSAPPEALSNUMBER) >> null
        1 * hscServiceTatPoint.save(addTatPointVO)
        0 * _
    }

    def "logCNSTatActivitiesForService: REQUEST_CLIN_INFO TAT activity"() {
        given:
        ActivityVO activityVO = new ActivityVO(activityType: ActivityReferenceConstants.ACTIVITYTYPE_REQUEST_CLIN_INFO, activityID: ACTIVITY_ID, hscID: HSC_ID, createDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone())
        HscServiceTatPointVO addTatPointVO = new HscServiceTatPointVO(hscID: activityVO.hscID, serviceSeqNum: SERVICE_SEQ_NUM, tatPointType: HsrReferenceConstants.TATPOINTTYPE_REQ_MORE_INFO, activityID: activityVO.getActivityID(), tatPointDateTime: activityVO.getCreateDateTime())

        when:
        tatPointHelper.logCNSTatActivitiesForService(activityVO, SERVICE_SEQ_NUM)

        then:
        1 * hscServiceTatPoint.read(activityVO.getHscID(), SERVICE_SEQ_NUM, HsrReferenceConstants.TATPOINTTYPE_REQ_MORE_INFO) >> null
        1 * hsc.read(activityVO.getHscID()) >> new HscVO(hscID: HSC_ID)
        1 * hscAlternateIdentifier.read(activityVO.getHscID(), HsrReferenceConstants.HSCALTERNATEIDTYPE_STARSAPPEALSNUMBER) >> null
        1 * hscServiceTatPoint.save(addTatPointVO)
        0 * _
    }

    def "logCNSTatActivitiesForService: RECP_ALL_INFO TAT activity"() {
        given:
        ActivityVO activityVO = new ActivityVO(activityType: ActivityReferenceConstants.ACTIVITYTYPE_RECEIVED_COMPLETE_CLIN_INFO, activityID: ACTIVITY_ID, hscID: HSC_ID, createDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone())
        HscServiceTatPointVO addTatPointVO = new HscServiceTatPointVO(hscID: activityVO.hscID, serviceSeqNum: SERVICE_SEQ_NUM, tatPointType: HsrReferenceConstants.TATPOINTTYPE_RECP_ALL_INFO, activityID: activityVO.getActivityID(), tatPointDateTime: activityVO.getCreateDateTime())

        when:
        tatPointHelper.logCNSTatActivitiesForService(activityVO, SERVICE_SEQ_NUM)

        then:
        1 * hscServiceTatPoint.read(activityVO.getHscID(), SERVICE_SEQ_NUM, HsrReferenceConstants.TATPOINTTYPE_RECP_ALL_INFO) >> null
        1 * hsc.read(activityVO.getHscID()) >> new HscVO(hscID: HSC_ID)
        1 * hscAlternateIdentifier.read(activityVO.getHscID(), HsrReferenceConstants.HSCALTERNATEIDTYPE_STARSAPPEALSNUMBER) >> null
        1 * hscServiceTatPoint.save(addTatPointVO)
        0 * _
    }

    def "logCNSTatActivitiesForService: MANUAL_LETTER_SENT TAT activity"() {
        given:
        ActivityVO activityVO = new ActivityVO(activityType: ActivityReferenceConstants.ACTIVITYTYPE_MANUAL_LETTER_SENT, activityID: ACTIVITY_ID, hscID: HSC_ID, createDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone())
        HscServiceTatPointVO addTatPointVO = new HscServiceTatPointVO(hscID: activityVO.hscID, serviceSeqNum: SERVICE_SEQ_NUM, tatPointType: HsrReferenceConstants.TATPOINTTYPE_WRITTEN_NOTICE, activityID: activityVO.getActivityID(), tatPointDateTime: activityVO.getCreateDateTime())

        when:
        tatPointHelper.logCNSTatActivitiesForService(activityVO, SERVICE_SEQ_NUM)

        then:
        1 * hscServiceTatPoint.read(activityVO.getHscID(), SERVICE_SEQ_NUM, HsrReferenceConstants.TATPOINTTYPE_WRITTEN_NOTICE) >> null
        1 * hsc.read(activityVO.getHscID()) >> new HscVO(hscID: HSC_ID)
        1 * hscAlternateIdentifier.read(activityVO.getHscID(), HsrReferenceConstants.HSCALTERNATEIDTYPE_STARSAPPEALSNUMBER) >> null
        1 * hscServiceTatPoint.save(addTatPointVO)
        0 * _
    }

    def "logCNSTatActivitiesForService: DECISION_COMMUNICATION TAT activity, no current Decision"() {
        given:
        ActivityVO activityVO = new ActivityVO(activityType: ActivityReferenceConstants.ACTIVITYTYPE_DECISION_COMMUNICATION, activityID: ACTIVITY_ID, hscID: HSC_ID, createDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone())
        HscServiceTatPointVO addTatPointVO = new HscServiceTatPointVO(hscID: activityVO.hscID, serviceSeqNum: SERVICE_SEQ_NUM, tatPointType: HsrReferenceConstants.TATPOINTTYPE_PROV_VERBAL_NOTICE, activityID: activityVO.getActivityID(), tatPointDateTime: activityVO.getCreateDateTime())

        when:
        tatPointHelper.logCNSTatActivitiesForService(activityVO, SERVICE_SEQ_NUM)

        then:
        1 * hscServiceTatPoint.read(activityVO.getHscID(), SERVICE_SEQ_NUM, HsrReferenceConstants.TATPOINTTYPE_PROV_VERBAL_NOTICE) >> null
        1 * hsc.read(activityVO.getHscID()) >> new HscVO(hscID: HSC_ID)
        1 * hscServiceDecision.getCurrentDecision(HSC_ID, SERVICE_SEQ_NUM, false) >> null
        1 * hscAlternateIdentifier.read(activityVO.getHscID(), HsrReferenceConstants.HSCALTERNATEIDTYPE_STARSAPPEALSNUMBER) >> null
        1 * hscServiceTatPoint.save(addTatPointVO)
        0 * _
    }

    def "logCNSTatActivitiesForService: DECISION_COMMUNICATION TAT activity, has current Decision"() {
        given:
        ActivityVO activityVO = new ActivityVO(activityType: ActivityReferenceConstants.ACTIVITYTYPE_DECISION_COMMUNICATION, activityID: ACTIVITY_ID, hscID: HSC_ID, createDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone())
        HscServiceTatPointVO addTatPointVO = new HscServiceTatPointVO(hscID: activityVO.hscID, serviceSeqNum: SERVICE_SEQ_NUM, tatPointType: HsrReferenceConstants.TATPOINTTYPE_PROV_VERBAL_NOTICE, activityID: activityVO.getActivityID(), tatPointDateTime: activityVO.getCreateDateTime(), decisionSeqNum: DECISION_SEQ_NUM)

        when:
        tatPointHelper.logCNSTatActivitiesForService(activityVO, SERVICE_SEQ_NUM)

        then:
        1 * hscServiceTatPoint.read(activityVO.getHscID(), SERVICE_SEQ_NUM, HsrReferenceConstants.TATPOINTTYPE_PROV_VERBAL_NOTICE) >> null
        1 * hsc.read(activityVO.getHscID()) >> new HscVO(hscID: HSC_ID)
        1 * hscServiceDecision.getCurrentDecision(HSC_ID, SERVICE_SEQ_NUM, false) >> new HscServiceDecisionVO(hscID: HSC_ID, serviceSeqNum: SERVICE_SEQ_NUM, decisionSeqNum: DECISION_SEQ_NUM)
        1 * hscAlternateIdentifier.read(activityVO.getHscID(), HsrReferenceConstants.HSCALTERNATEIDTYPE_STARSAPPEALSNUMBER) >> null
        1 * hscServiceTatPoint.save(addTatPointVO)
        0 * _
    }

    def "logCNSTatActivitiesForService: RECP_ALL_INFO TAT activity, TatPoint already Exists"() {
        given:
        ActivityVO activityVO = new ActivityVO(activityType: ActivityReferenceConstants.ACTIVITYTYPE_RECEIVED_COMPLETE_CLIN_INFO, activityID: ACTIVITY_ID, hscID: HSC_ID, createDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone())
        HscServiceTatPointVO tatPointVO = new HscServiceTatPointVO(hscID: activityVO.hscID, serviceSeqNum: SERVICE_SEQ_NUM, tatPointType: HsrReferenceConstants.TATPOINTTYPE_RECP_ALL_INFO, activityID: activityVO.getActivityID(), tatPointDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone().addDay(1));
        HscServiceTatPointVO updatedTatPointVO = new HscServiceTatPointVO(hscID: activityVO.hscID, serviceSeqNum: SERVICE_SEQ_NUM, tatPointType: HsrReferenceConstants.TATPOINTTYPE_RECP_ALL_INFO, activityID: activityVO.getActivityID(), tatPointDateTime: activityVO.createDateTime);

        when:
        tatPointHelper.logCNSTatActivitiesForService(activityVO, SERVICE_SEQ_NUM)

        then:
        1 * hscServiceTatPoint.read(activityVO.getHscID(), SERVICE_SEQ_NUM, HsrReferenceConstants.TATPOINTTYPE_RECP_ALL_INFO) >> tatPointVO
        1 * hsc.read(activityVO.getHscID()) >> new HscVO(hscID: HSC_ID)
        1 * hscAlternateIdentifier.read(activityVO.getHscID(), HsrReferenceConstants.HSCALTERNATEIDTYPE_STARSAPPEALSNUMBER) >> null
        1 * hscServiceTatPoint.update(updatedTatPointVO)
        0 * _
    }

    def "logCNSTatActivitiesForService: RECP_ALL_INFO TAT activity, TatPoint does not exist"() {
        given:
        ActivityVO activityVO = new ActivityVO(activityType: ActivityReferenceConstants.ACTIVITYTYPE_RECEIVED_COMPLETE_CLIN_INFO, activityID: ACTIVITY_ID, hscID: HSC_ID, createDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone())
        HscServiceTatPointVO tatPointVO = new HscServiceTatPointVO(hscID: activityVO.hscID, serviceSeqNum: SERVICE_SEQ_NUM, tatPointType: HsrReferenceConstants.TATPOINTTYPE_RECP_ALL_INFO, activityID: activityVO.getActivityID(), tatPointDateTime: activityVO.getCreateDateTime())

        when:
        tatPointHelper.logCNSTatActivitiesForService(activityVO, SERVICE_SEQ_NUM)

        then:
        1 * hscServiceTatPoint.read(activityVO.getHscID(), SERVICE_SEQ_NUM, HsrReferenceConstants.TATPOINTTYPE_RECP_ALL_INFO) >> null
        1 * hsc.read(activityVO.getHscID()) >> new HscVO(hscID: HSC_ID)
        1 * hscAlternateIdentifier.read(activityVO.getHscID(), HsrReferenceConstants.HSCALTERNATEIDTYPE_STARSAPPEALSNUMBER) >> null
        1 * hscServiceTatPoint.save(tatPointVO)
        0 * _
    }

    def "logCNSTatActivitiesForService: hscStatus ReasonType is RECONSIDER"() {
        given:
        ActivityVO activityVO = new ActivityVO(activityType: ActivityReferenceConstants.ACTIVITYTYPE_RECEIVED_COMPLETE_CLIN_INFO, activityID: ACTIVITY_ID, hscID: HSC_ID, createDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone())

        when:
        tatPointHelper.logCNSTatActivitiesForService(activityVO, SERVICE_SEQ_NUM)

        then:
        1 * hscServiceTatPoint.read(activityVO.getHscID(), SERVICE_SEQ_NUM, HsrReferenceConstants.TATPOINTTYPE_RECP_ALL_INFO) >> null
        1 * hsc.read(activityVO.getHscID()) >> new HscVO(hscID: HSC_ID, hscStatusReasonType: HsrReferenceConstants.HSCSTATUSREASONTYPE_RECONSIDER)
        1 * hscAlternateIdentifier.read(activityVO.getHscID(), HsrReferenceConstants.HSCALTERNATEIDTYPE_STARSAPPEALSNUMBER) >> null
        0 * _
    }

    def "logCNSTatActivitiesForService: hscStatus ReasonType is APPEAL"() {
        given:
        ActivityVO activityVO = new ActivityVO(activityType: ActivityReferenceConstants.ACTIVITYTYPE_RECEIVED_COMPLETE_CLIN_INFO, activityID: ACTIVITY_ID, hscID: HSC_ID, createDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone())

        when:
        tatPointHelper.logCNSTatActivitiesForService(activityVO, SERVICE_SEQ_NUM)

        then:
        1 * hscServiceTatPoint.read(activityVO.getHscID(), SERVICE_SEQ_NUM, HsrReferenceConstants.TATPOINTTYPE_RECP_ALL_INFO) >> null
        1 * hsc.read(activityVO.getHscID()) >> new HscVO(hscID: HSC_ID, hscStatusReasonType: HsrReferenceConstants.HSCSTATUSREASONTYPE_APPEAL)
        1 * hscAlternateIdentifier.read(activityVO.getHscID(), HsrReferenceConstants.HSCALTERNATEIDTYPE_STARSAPPEALSNUMBER) >> null
        0 * _
    }

    def "logCNSTatActivitiesForService: hscStatus ReasonType is PRESERVICE_APPEAL"() {
        given:
        ActivityVO activityVO = new ActivityVO(activityType: ActivityReferenceConstants.ACTIVITYTYPE_RECEIVED_COMPLETE_CLIN_INFO, activityID: ACTIVITY_ID, hscID: HSC_ID, createDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone())

        when:
        tatPointHelper.logCNSTatActivitiesForService(activityVO, SERVICE_SEQ_NUM)

        then:
        1 * hscServiceTatPoint.read(activityVO.getHscID(), SERVICE_SEQ_NUM, HsrReferenceConstants.TATPOINTTYPE_RECP_ALL_INFO) >> null
        1 * hsc.read(activityVO.getHscID()) >> new HscVO(hscID: HSC_ID, hscStatusReasonType: HsrReferenceConstants.HSCSTATUSREASONTYPE_PRESERVICE_APPEAL)
        1 * hscAlternateIdentifier.read(activityVO.getHscID(), HsrReferenceConstants.HSCALTERNATEIDTYPE_STARSAPPEALSNUMBER) >> null
        0 * _
    }

    def "logCNSTatActivitiesForService: hscStatus ReasonType is POSTSERVICE_APPEAL"() {
        given:
        ActivityVO activityVO = new ActivityVO(activityType: ActivityReferenceConstants.ACTIVITYTYPE_RECEIVED_COMPLETE_CLIN_INFO, activityID: ACTIVITY_ID, hscID: HSC_ID, createDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone())

        when:
        tatPointHelper.logCNSTatActivitiesForService(activityVO, SERVICE_SEQ_NUM)

        then:
        1 * hscServiceTatPoint.read(activityVO.getHscID(), SERVICE_SEQ_NUM, HsrReferenceConstants.TATPOINTTYPE_RECP_ALL_INFO) >> null
        1 * hsc.read(activityVO.getHscID()) >> new HscVO(hscID: HSC_ID, hscStatusReasonType: HsrReferenceConstants.HSCSTATUSREASONTYPE_POSTSERVICE_APPEAL)
        1 * hscAlternateIdentifier.read(activityVO.getHscID(), HsrReferenceConstants.HSCALTERNATEIDTYPE_STARSAPPEALSNUMBER) >> null
        0 * _
    }

    def "logCNSTatActivitiesForService: hscAlternateIdentifierVO is not null"() {
        given:
        ActivityVO activityVO = new ActivityVO(activityType: ActivityReferenceConstants.ACTIVITYTYPE_RECEIVED_COMPLETE_CLIN_INFO, activityID: ACTIVITY_ID, hscID: HSC_ID, createDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone())

        when:
        tatPointHelper.logCNSTatActivitiesForService(activityVO, SERVICE_SEQ_NUM)

        then:
        1 * hscServiceTatPoint.read(activityVO.getHscID(), SERVICE_SEQ_NUM, HsrReferenceConstants.TATPOINTTYPE_RECP_ALL_INFO) >> null
        1 * hsc.read(activityVO.getHscID()) >> new HscVO(hscID: HSC_ID)
        1 * hscAlternateIdentifier.read(activityVO.getHscID(), HsrReferenceConstants.HSCALTERNATEIDTYPE_STARSAPPEALSNUMBER) >> new HscAlternateIdentifierVO()
        0 * _
    }

    def "logIntakeCompleteTatPoint - HscVO is not facility; advanceNotifyDateTime is null"() {
        given:
        HscVO hscVO = new HscVO(hscID: HSC_ID)
        List<HscServiceNonFacilityVO> serviceNonFacilityVOs = [new HscServiceNonFacilityVO(hscID: HSC_ID, serviceSeqNum: SERVICE_SEQ_NUM)]

        when:
        tatPointHelper.logIntakeCompleteTatPoint(HSC_ID)

        then:
        0 * _
    }

    def "logIntakeCompleteTatPoint - HscVO is not facility; advanceNotifyDateTime is not null"() {
        given:
        HscVO hscVO = new HscVO(hscID: HSC_ID)
        List<HscServiceNonFacilityVO> serviceNonFacilityVOs = [new HscServiceNonFacilityVO(hscID: HSC_ID, serviceSeqNum: SERVICE_SEQ_NUM, advanceNotifyDateTime: new UhgCalendar(2010, 2, 3))]

        when:
        tatPointHelper.logIntakeCompleteTatPoint(HSC_ID)

        then:
        0 * _
    }

    def "logIntakeCompleteTatPoint - HscVO is facility, advanceNotifyDateTime is null"() {
        given:
        HscVO hscVO = new HscVO(hscID: HSC_ID, serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT)
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: HSC_ID)
        List<HscServiceFacilityVO> serviceFacilityVOs = [new HscServiceFacilityVO(hscID: HSC_ID, serviceSeqNum: SERVICE_SEQ_NUM)]

        when:
        tatPointHelper.logIntakeCompleteTatPoint(HSC_ID)

        then:
        0 * _
    }

    def "logIntakeCompleteTatPoint - HscVO is facility, advanceNotifyDateTime is not null"() {
        given:
        HscVO hscVO = new HscVO(hscID: HSC_ID, serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT)
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: HSC_ID, advanceNotifyDateTime: new UhgCalendar(2010, 2, 3))
        List<HscServiceFacilityVO> serviceFacilityVOs = [new HscServiceFacilityVO(hscID: HSC_ID, serviceSeqNum: SERVICE_SEQ_NUM, advanceNotifyDateTime: new UhgCalendar(2010, 4, 5))]

        when:
        tatPointHelper.logIntakeCompleteTatPoint(HSC_ID)

        then:
        0 * _
    }

    def "updateTatPointForServiceNtfDtTm - serviceSettingType is facility"() {
        given:
        HscServiceFacilityVO hscServiceFacilityVO = new HscServiceFacilityVO(hscID: HSC_ID, serviceSeqNum: SERVICE_SEQ_NUM)

        when:
        tatPointHelper.updateTatPointForServiceNtfDtTm(HSC_ID, SERVICE_SEQ_NUM, CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT)

        then:
        1 * hscServiceFacility.read(HSC_ID, SERVICE_SEQ_NUM, []) >> hscServiceFacilityVO
        0 * _
    }

    def "updateTatPointForServiceNtfDtTm - serviceSettingType is not facility, advanceNotifyDateTime is not null"() {
        given:
        HscServiceNonFacilityVO hscServiceNonFacilityVO = new HscServiceNonFacilityVO(hscID: HSC_ID, serviceSeqNum: SERVICE_SEQ_NUM, advanceNotifyDateTime: new UhgCalendar(2010, 2, 3))
        HscVO hscVO = new HscVO(hscID: HSC_ID)

        when:
        tatPointHelper.updateTatPointForServiceNtfDtTm(HSC_ID, SERVICE_SEQ_NUM, "non facility type")

        then:
        1 * hscServiceNonFacility.read(HSC_ID, SERVICE_SEQ_NUM, []) >> hscServiceNonFacilityVO
        1 * hscServiceTatPoint.read(HSC_ID, SERVICE_SEQ_NUM, HsrReferenceConstants.TATPOINTTYPE_NOTIFICATION, []) >> null
        1 * hsc.read(HSC_ID, []) >> hscVO
        1 * hscAlternateIdentifier.read(HSC_ID, HsrReferenceConstants.HSCALTERNATEIDTYPE_STARSAPPEALSNUMBER, []) >> null
        1 * hscServiceTatPoint.save(_) >> { HscServiceTatPointVO vo ->
            assert vo.getHscID() == HSC_ID
            assert vo.getServiceSeqNum() == SERVICE_SEQ_NUM
        }
        0 * _
    }

    def "updateTatPointForFacilityNtfDtTm"() {
        given:
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: HSC_ID, advanceNotifyDateTime: new UhgCalendar(2010, 2, 3))
        HscVO hscVO = new HscVO(hscID: HSC_ID)

        when:
        tatPointHelper.updateTatPointForFacilityNtfDtTm(HSC_ID)

        then:
        0 * _
    }

    def "logIntakeCompleteTatPointForService"() {
        given:
        HscVO hscVO = new HscVO(hscID: HSC_ID)

        when:
        tatPointHelper.logIntakeCompleteTatPointForService(HSC_ID, SERVICE_SEQ_NUM)

        then:
        0 * _
    }

    def "logVerbalNoticeTatPointForService"() {
        given:
        HscServiceDecisionVO serviceDecisionVO = new HscServiceDecisionVO(hscID: HSC_ID, serviceSeqNum: SERVICE_SEQ_NUM, decisionSeqNum: DECISION_SEQ_NUM)
        String tatPointType = "tat pt type"
        UhgCalendar verbalNoticeDateTime = new UhgCalendar(2010, 2, 3)
        HscServiceTatPointVO tatPointVO = new HscServiceTatPointVO(hscID: HSC_ID, serviceSeqNum: SERVICE_SEQ_NUM, tatPointType: tatPointType, tatPointDateTime: verbalNoticeDateTime, decisionSeqNum: DECISION_SEQ_NUM)
        HscVO hscVO = new HscVO(hscID: HSC_ID)

        when:
        tatPointHelper.logVerbalNoticeTatPointForService(serviceDecisionVO, tatPointType, verbalNoticeDateTime)

        then:
        1 * hscServiceTatPoint.read(HSC_ID, SERVICE_SEQ_NUM, tatPointType, []) >> null
        1 * hsc.read(HSC_ID, []) >> hscVO
        1 * hscAlternateIdentifier.read(HSC_ID, HsrReferenceConstants.HSCALTERNATEIDTYPE_STARSAPPEALSNUMBER, []) >> null
        1 * hscServiceTatPoint.save(tatPointVO)
        0 * _
    }

    def "logVerbalNoticeTatPointForFacility"() {
        given:
        HscFacilityDecisionVO facilityDecisionVO = new HscFacilityDecisionVO(hscID: HSC_ID, decisionSeqNum: DECISION_SEQ_NUM)
        String tatPointType = "tat pt type"
        UhgCalendar verbalNoticeDateTime = new UhgCalendar(2010, 2, 3)
//        HscFacilityTatPointVO tatPointVO = new HscFacilityTatPointVO(hscID: HSC_ID, tatPointType: tatPointType, tatPointDateTime: verbalNoticeDateTime, decisionSeqNum: DECISION_SEQ_NUM)
        HscVO hscVO = new HscVO(hscID: HSC_ID)

        when:
        tatPointHelper.logVerbalNoticeTatPointForFacility(facilityDecisionVO, tatPointType, verbalNoticeDateTime)

        then:
        0 * _
    }

    def "logCoverageDecisionMadeTatPointForService"() {
        given:
        HscServiceDecisionVO serviceDecisionVO = new HscServiceDecisionVO(hscID: HSC_ID, serviceSeqNum: SERVICE_SEQ_NUM, decisionSeqNum: DECISION_SEQ_NUM, decisionRenderedDateTime: new UhgCalendar(2010, 2, 3))
        HscServiceTatPointVO tatPointVO = new HscServiceTatPointVO(hscID: HSC_ID, serviceSeqNum: SERVICE_SEQ_NUM, tatPointType: HsrReferenceConstants.TATPOINTTYPE_DECISION, tatPointDateTime: serviceDecisionVO.getDecisionRenderedDateTime(), decisionSeqNum: DECISION_SEQ_NUM)
        HscVO hscVO = new HscVO(hscID: HSC_ID)
        when:
        tatPointHelper.logCoverageDecisionMadeTatPointForService(serviceDecisionVO)
        then:
        1 * tatHelper.isByPassTatPoint(hscVO) >> false
        1 * hscServiceTatPoint.read(HSC_ID, SERVICE_SEQ_NUM, HsrReferenceConstants.TATPOINTTYPE_DECISION, []) >> null
        2 * hsc.read(HSC_ID, []) >> hscVO
        1 * hscAlternateIdentifier.read(HSC_ID, HsrReferenceConstants.HSCALTERNATEIDTYPE_STARSAPPEALSNUMBER, []) >> null
        1 * hscServiceTatPoint.save(tatPointVO)
        0 * _
    }
    def "logCoverageDecisionMadeTatPointForFacility"() {
        given:
        HscFacilityDecisionVO facilityDecisionVO = new HscFacilityDecisionVO(hscID: HSC_ID, decisionSeqNum: DECISION_SEQ_NUM, decisionRenderedDateTime: new UhgCalendar(2010, 2, 3))
//        HscFacilityTatPointVO tatPointVO = new HscFacilityTatPointVO(hscID: HSC_ID, tatPointType: HsrReferenceConstants.TATPOINTTYPE_DECISION, tatPointDateTime: facilityDecisionVO.getDecisionRenderedDateTime(), decisionSeqNum: DECISION_SEQ_NUM)
        HscVO hscVO = new HscVO(hscID: HSC_ID)

        when:
        tatPointHelper.logCoverageDecisionMadeTatPointForFacility(facilityDecisionVO)

        then:
        0 * _
    }

    def "checkAndLogRequestForInfoTatPointForLetters"() {
        given:
        HscVO hscVO = new HscVO(hscID: HSC_ID, serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT)
        HscLetterRequestVO letterRequestVO = new HscLetterRequestVO(hscID: HSC_ID, createDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone().addDay(1))
        ActivityVO activityVO = new ActivityVO(hscID: HSC_ID, createDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone())
        List<HscServiceVO> hscServiceVOs = [new HscServiceVO(hscID: HSC_ID, serviceSeqNum: SERVICE_SEQ_NUM)]

        when:
        tatPointHelper.checkAndLogRequestForInfoTatPointForLetters(HSC_ID)

        then:
        1 * hsc.readUnhydrated(HSC_ID, FieldConstants.SERVICESETTINGTYPE) >> hscVO
        1 * hscService.listByHscID(HSC_ID, false) >> hscServiceVOs
        0 * _
    }

    def "log written notification tat point"() {
        given:
        HscLetterRequestVO letterRequestVO = new HscLetterRequestVO(hscID: HSC_ID, templateID: "template ID")
        List<HscServiceVO> serviceVOs = [new HscServiceVO(hscID: HSC_ID, serviceSeqNum: SERVICE_SEQ_NUM)]
        HscServiceTatPointVO serviceTatPointVO = new HscServiceTatPointVO(hscID: HSC_ID, serviceSeqNum: SERVICE_SEQ_NUM, tatPointType: HsrReferenceConstants.TATPOINTTYPE_WRITTEN_NOTICE)
        HscVO hscVO = new HscVO(hscID: HSC_ID, serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT)

        when:
        tatPointHelper.logWrittenNotificationTatPoint(letterRequestVO)

        then:
        0 * _
    }

    @Unroll
    def "get TAT point Type by Activity #testCase"() {
        given:
        ActivityVO activityVO = new ActivityVO(activityType: activityType,
                activityResolutionOutcomeType: resolutionOutcomeType)

        when:
        String actual = tatPointHelper.getTatPointTypeByActivity(activityVO)

        then:
        0 * (_)

        and:
        expect.equals(actual)

        where:
        testCase | activityType                                                        | resolutionOutcomeType | expect
        1        | ActivityReferenceConstants.ACTIVITYTYPE_INTAKE_COMPLETE             | null                  | HsrReferenceConstants.TATPOINTTYPE_NOTIFICATION
        2        | ActivityReferenceConstants.ACTIVITYTYPE_REQUEST_CLIN_INFO           | null                  | HsrReferenceConstants.TATPOINTTYPE_REQ_MORE_INFO
        3        | ActivityReferenceConstants.ACTIVITYTYPE_RECEIVED_COMPLETE_CLIN_INFO | null                  | HsrReferenceConstants.TATPOINTTYPE_RECP_ALL_INFO
        4        | ActivityReferenceConstants.ACTIVITYTYPE_DECISION_COMMUNICATION      | null                  | HsrReferenceConstants.TATPOINTTYPE_PROV_VERBAL_NOTICE
        5        | ActivityReferenceConstants.ACTIVITYTYPE_MANUAL_LETTER_SENT          | "1"                   | HsrReferenceConstants.TATPOINTTYPE_WRITTEN_NOTICE
        6        | ActivityReferenceConstants.ACTIVITYTYPE_MANUAL_LETTER_SENT          | null                  | HsrReferenceConstants.TATPOINTTYPE_WRITTEN_NOTICE
        7        | ActivityReferenceConstants.ACTIVITYTYPE_MANUAL_LETTER_SENT          | "1725"                | HsrReferenceConstants.TATPOINTTYPE_WRITTEN_NOTICE
        8        | "52"                                                                | null                  | null

    }
}
