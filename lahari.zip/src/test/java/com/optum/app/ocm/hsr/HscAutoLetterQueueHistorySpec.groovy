package com.optum.app.ocm.hsr

import com.optum.rf.bl.spring.TransactionInterceptor
import com.optum.rf.core.locator.ServiceLocator
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.impl.HscAutoLetterQueueHistoryImpl
import com.optum.app.common.hsr.data.HscAutoLetterQueueHistoryVO
import com.optum.app.common.hsr.data.HscAutoLetterQueueVO
import spock.lang.Unroll

class HscAutoLetterQueueHistorySpec extends HsrReadLogicSpecification {

    HscAutoLetterQueueHistoryImpl hscAutoLetterQueueHistory

    DataAccessObject dao
    PersistenceHelper persistenceHelper
    ServiceLocator serviceLocator
    TransactionInterceptor transactionInterceptor

    def setup() {
        dao = Mock(DataAccessObject)
        persistenceHelper = Mock(PersistenceHelper)
        serviceLocator = Mock(ServiceLocator)
        transactionInterceptor = Mock(TransactionInterceptor)

        hscAutoLetterQueueHistory = new HscAutoLetterQueueHistoryImpl(
                requiredDao: dao,
                requiredPersistenceHelper: persistenceHelper,
                requiredServiceLocator: serviceLocator,
                requiredTransactionInterceptor: transactionInterceptor
        )
    }

    @Unroll
    def "isValid #testCase"() {
        given:
        def hscAutoLetterQueueID = (long) 1
        def rp = new ReadProperties(FieldConstants.HSCAUTOLETTERQUEUEID)
        rp.setKeyValue(FieldConstants.HSCAUTOLETTERQUEUEID, hscAutoLetterQueueID)
        rp.fields = null

        when:
        boolean retVal = hscAutoLetterQueueHistory.isValid(hscAutoLetterQueueID)

        then:
        1 * dao.isValid(rp) >> expectedVal
        0 * _
        retVal == expectedVal

        where:
        testCase | expectedVal
        "passes" | true
        "fails"  | false
    }

    def "Test to read HscAutoLetterQueueHistoryVO"() {
        setup:
        def hscAutoLetterQueueID = (long) 1
        HscAutoLetterQueueHistoryVO hscAutoLetterQueueHistoryVO = new HscAutoLetterQueueHistoryVO(
                new HscAutoLetterQueueVO(hscAutoLetterQueueID: hscAutoLetterQueueID))
        def rp = new ReadProperties(FieldConstants.HSCAUTOLETTERQUEUEID)
        rp.setKeyValue(FieldConstants.HSCAUTOLETTERQUEUEID, hscAutoLetterQueueID)
        rp.fields = null

        when:
        hscAutoLetterQueueHistory.read(hscAutoLetterQueueID)

        then:
        1 * dao.read(rp) >> hscAutoLetterQueueHistoryVO
        0 * _
    }
}
