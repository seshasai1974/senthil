package com.optum.app.ocm.hsr

import com.optum.app.ocm.ref.businesslogic.CustomerReference
import com.optum.rf.bl.spring.TransactionInterceptor
import com.optum.rf.core.locator.ServiceLocator
import com.optum.rf.dao.exception.UhgRuntimeException
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.optum.app.common.hsr.businesslogic.Hsc
import com.optum.app.common.hsr.businesslogic.HscFacility
import com.optum.app.common.hsr.businesslogic.HscProvider
import com.optum.app.common.hsr.businesslogic.HscServiceNonFacility
import com.optum.app.common.hsr.businesslogic.impl.HscLetterRequestAttributeImpl
import com.optum.app.common.hsr.constants.HsrReferenceConstants
import com.optum.app.common.hsr.data.HscLetterRequestAttributeVO
import com.optum.app.common.hsr.data.HscLetterRequestVO
import com.optum.app.ocm.common.security.businesslogic.AppUser
import org.apache.commons.lang.StringUtils

class HscLetterRequestAttributeSpec extends HsrReadLogicSpecification {

    HscLetterRequestAttributeImpl hscLetterRequestAttribute

    DataAccessObject dao
    Hsc hsc
    HscFacility hscFacility
    HscProvider hscProvider
    HscServiceNonFacility hscServiceNonFacility
    PersistenceHelper persistenceHelper
    CustomerReference customerReference
    ServiceLocator serviceLocator
    TransactionInterceptor transactionInterceptor
    AppUser appUser

    def setup() {
        hscLetterRequestAttribute = new HscLetterRequestAttributeImpl()

        dao = Mock(DataAccessObject)
        hsc = Mock(Hsc)
        hscFacility = Mock(HscFacility)
        hscProvider = Mock(HscProvider)
        hscServiceNonFacility = Mock(HscServiceNonFacility)
        persistenceHelper = Mock(PersistenceHelper)
        customerReference = Mock(CustomerReference)
        serviceLocator = Mock(ServiceLocator)
        transactionInterceptor = Mock(TransactionInterceptor)
        appUser = Mock(AppUser)

        hscLetterRequestAttribute.setRequiredDao(dao)
        hscLetterRequestAttribute.setRequiredPersistenceHelper(persistenceHelper)
        hscLetterRequestAttribute.setRequiredCustomerReference(customerReference)
        hscLetterRequestAttribute.setRequiredServiceLocator(serviceLocator)
        hscLetterRequestAttribute.setRequiredTransactionInterceptor(transactionInterceptor)
    }

    /**
     * Test valid add.
     */
    def "Test Valid Add"() {
        setup:
        def vo = new HscLetterRequestAttributeVO()

        when:
        hscLetterRequestAttribute.add(vo)

        then:
        1 * persistenceHelper.add(_ as HscLetterRequestAttributeVO)
        0 * _

        expect:
        !vo.errorMessagesExist()
    }

    /**
     * Test valid delete.
     */
    def "Test Valid Delete"() {
        setup:
        def vo = new HscLetterRequestAttributeVO()

        when:
        hscLetterRequestAttribute.delete(vo)

        then:
        1 * persistenceHelper.delete(_ as HscLetterRequestAttributeVO)
        0 * _

        expect:
        !vo.errorMessagesExist()
    }

    /**
     * Test valid update.
     */
    def "Test Valid Update"() {
        setup:
        def vo = new HscLetterRequestAttributeVO()

        when:
        hscLetterRequestAttribute.update(vo)

        then:
        1 * persistenceHelper.update(_ as HscLetterRequestAttributeVO)
        0 * _

        expect:
        !vo.errorMessagesExist()
    }

    def "getHscLetterAttributesForRequest"() {
        setup:
        def hscLetterRequestVO = new HscLetterRequestVO(
                hscID: 12345,
                letterRequestSeqNum: 1,
                templateID: HsrReferenceConstants.TEMPLATEID_ABD001)

        when:
        def attributes = hscLetterRequestAttribute.getHscLetterAttributesForRequest(hscLetterRequestVO, isNew)

        then:
        if (!isNew) {
            1 * dao.list(_) >> savedAttributes
        }
        if (savedAttributes == null || savedAttributes.isEmpty()) {
        }
        0 * _

        and:
        if (savedAttributes != null) {
            attributes.size() == 1
        }

        where:
        isNew | savedAttributes
        true  | null
        false | []
        false | [new HscLetterRequestAttributeVO()]
    }

    def "saveHscLetterRequestAttributeList"() {
        setup:
        def list = [
                new HscLetterRequestAttributeVO(hscID: 1, letterRequestSeqNum: 1, letterAttributeType: "1"),
                new HscLetterRequestAttributeVO(hscID: 1, letterRequestSeqNum: 1, letterAttributeType: "2")]

        when:
        hscLetterRequestAttribute.saveHscLetterRequestAttributeList(list)

        then:
        2 * dao.isDuplicate(_) >>> [true, false]
        1 * persistenceHelper.update(_)
        1 * persistenceHelper.add(_)
        0 * _
    }

    def "saveHscLetterRequestAttributeList: handle exception"() {
        setup:
        def list = [new HscLetterRequestAttributeVO(hscID: 1, letterRequestSeqNum: 1, letterAttributeType: "1")]

        when:
        hscLetterRequestAttribute.saveHscLetterRequestAttributeList(list)

        then:
        1 * dao.isDuplicate(_) >> true
        1 * persistenceHelper.update(_) >> {throw new UhgRuntimeException()}
        0 * _
        thrown(UhgRuntimeException.class)
    }

    def "validate: max length"() {
        setup:
        def vo = new HscLetterRequestAttributeVO(hscLetterAttributeValue: StringUtils.leftPad('', HscLetterRequestAttributeImpl.MAX_LENGTH + 1, '123456789 '))

        when:
        hscLetterRequestAttribute.validate(vo, true)

        then:
        vo.errorMessagesExist()
    }

    def "validate: date"() {
        setup:
        def vo = new HscLetterRequestAttributeVO(
                letterAttributeType: HsrReferenceConstants.LETTERATTRIBUTETYPE_CORR_PROV_LTR_SENDDATE,
                hscLetterAttributeValue: '02-31-2000')

        when:
        hscLetterRequestAttribute.validate(vo, true)

        then:
        vo.errorMessagesExist()
    }

    def "validate: date range/list"() {
        setup:
        def vo = new HscLetterRequestAttributeVO(
                letterAttributeType: HsrReferenceConstants.LETTERATTRIBUTETYPE_DATE_DETERMINED_TO_NOT_BE_MEDICALLY_NECESSARY,
                hscLetterAttributeValue: '01-01-2000;')

        when:
        hscLetterRequestAttribute.validate(vo, true)

        then:
        vo.errorMessagesExist()
    }

    def "validateList: letter correction indicator"() {
        setup:
        def letterCorrInd = new HscLetterRequestAttributeVO(
                letterAttributeType: HsrReferenceConstants.LETTERATTRIBUTETYPE_LETTER_CORR_IND,
                hscLetterAttributeValue: 'true')
        def corrProvLtrSendDate = new HscLetterRequestAttributeVO(
                letterAttributeType: HsrReferenceConstants.LETTERATTRIBUTETYPE_CORR_PROV_LTR_SENDDATE)

        when:
        hscLetterRequestAttribute.validateList([letterCorrInd, corrProvLtrSendDate])

        then:
        corrProvLtrSendDate.errorMessagesExist() // validate conditionally required
    }

    def "validateList: medical policies or guidelines"() {
        setup:
        def medPolOrGuidelines = new HscLetterRequestAttributeVO(
                letterAttributeType: HsrReferenceConstants.LETTERATTRIBUTETYPE_MED_POL_OR_GUIDELINES_USED_FOR_REVW,
                templateID: HsrReferenceConstants.TEMPLATEID_ABD002)

        when:
        hscLetterRequestAttribute.validateList([medPolOrGuidelines])

        then:
        medPolOrGuidelines.errorMessagesExist() // validate conditionally required
    }

    def "validateList: resources used to make decision"() {
        setup:
        def resourcesUsed = new HscLetterRequestAttributeVO(
                letterAttributeType: HsrReferenceConstants.LETTERATTRIBUTETYPE_RESOURCE_USED_TO_MAKE_DECISION,
                hscLetterAttributeValue: 'COC')
        def coverageLanguage = new HscLetterRequestAttributeVO(
                letterAttributeType: HsrReferenceConstants.LETTERATTRIBUTETYPE_COVERAGE_LANGUAGE_TO_SUPPORT_DECISION)

        when:
        hscLetterRequestAttribute.validateList([resourcesUsed, coverageLanguage])

        then:
        coverageLanguage.errorMessagesExist() // validate conditionally required
    }

    def "validateList: denial rationale"() {
        setup:
        def denialRationale = new HscLetterRequestAttributeVO(
                letterAttributeType: HsrReferenceConstants.LETTERATTRIBUTETYPE_DENIAL_RATIONALE,
                templateID: templateID)
        def parent = new HscLetterRequestAttributeVO(
                letterAttributeType: parentType,
                hscLetterAttributeValue: parentValue)

        when:
        hscLetterRequestAttribute.validateList([denialRationale, parent])

        then:
        denialRationale.errorMessagesExist()

        where:
        templateID                               | parentType                                                                            | parentValue
        HsrReferenceConstants.TEMPLATEID_FACDOBS | HsrReferenceConstants.LETTERATTRIBUTETYPE_PARTIAL_OR_OBS_APPROVED_OR_TOTAL_DENIAL_IND | HsrReferenceConstants.HSCLETTERATTRIBUTEVALUE_DENIALIND_TOTALIPDENIAL
        HsrReferenceConstants.TEMPLATEID_ABD009  | HsrReferenceConstants.LETTERATTRIBUTETYPE_DENIAL_REASON_PARAGRAPH_IND                 | HsrReferenceConstants.HSCLETTERATTRIBUTEVALUE_DENIALREASONTYPE_MEDNEC
        HsrReferenceConstants.TEMPLATEID_ABD001  | null                                                                                  | null
    }

    def "validateList: denial based on"() {
        setup:
        def denialBasedOn1 = new HscLetterRequestAttributeVO(
                letterAttributeType: HsrReferenceConstants.LETTERATTRIBUTETYPE_DENIAL_BASED_ON,
                hscLetterAttributeValue: HsrReferenceConstants.HSCLETTERATTRIBUTEVALUE_DENIALBASEDON_DELAYINDISCHARGESERVICE)
        def basedOnInformationProvided = new HscLetterRequestAttributeVO(
                letterAttributeType: HsrReferenceConstants.LETTERATTRIBUTETYPE_BASED_ON_INFORMATION_PROVIDED)
        def denialBasedOn2 = new HscLetterRequestAttributeVO(
                letterAttributeType: HsrReferenceConstants.LETTERATTRIBUTETYPE_DENIAL_BASED_ON,
                hscLetterAttributeValue: HsrReferenceConstants.HSCLETTERATTRIBUTEVALUE_DENIALBASEDON_COMFORTCARE)
        def dateOfComfortCare = new HscLetterRequestAttributeVO(
                letterAttributeType: HsrReferenceConstants.LETTERATTRIBUTETYPE_DATE_OF_COMFORTCARE)

        when:
        hscLetterRequestAttribute.validateList([denialBasedOn1, basedOnInformationProvided, denialBasedOn2, dateOfComfortCare])

        then:
        basedOnInformationProvided.errorMessagesExist() // validate conditionally required
        dateOfComfortCare.errorMessagesExist() // validate conditionally required
    }

    def "validateList: signer's credentials"() {
        setup:
        def signersCredentials = new HscLetterRequestAttributeVO(
                letterAttributeType: HsrReferenceConstants.LETTERATTRIBUTETYPE_SIGNERS_CREDENTIALS,
                templateID: HsrReferenceConstants.TEMPLATEID_ABD001)

        when:
        hscLetterRequestAttribute.validateList([signersCredentials])

        then:
        signersCredentials.errorMessagesExist() // validate conditionally required
    }

    def "validateList: required and optional"() {
        setup:
        def required = new HscLetterRequestAttributeVO(letterAttributeType: HsrReferenceConstants.LETTERATTRIBUTETYPE_PROV_STAFF_MEMBERNAME)
        def optional = new HscLetterRequestAttributeVO(letterAttributeType: HsrReferenceConstants.LETTERATTRIBUTETYPE_FIRST_NAME)

        when:
        hscLetterRequestAttribute.validateList([required, optional])

        then:
        // validate required
        required.errorMessagesExist()
        // validate optional
        !optional.errorMessagesExist()
    }

    def "validateMedicareCoverageOptions: none checked"() {
        setup:
        def option1 = new HscLetterRequestAttributeVO(letterAttributeType: HsrReferenceConstants.LETTERATTRIBUTETYPE_MEDICARE_COVERAGE_POLICIES_OPTION1);
        def option2 = new HscLetterRequestAttributeVO(letterAttributeType: HsrReferenceConstants.LETTERATTRIBUTETYPE_MEDICARE_COVERAGE_POLICIES_OPTION2);
        def option3 = new HscLetterRequestAttributeVO(letterAttributeType: HsrReferenceConstants.LETTERATTRIBUTETYPE_MEDICARE_COVERAGE_POLICIES_OPTION3);

        when:
        hscLetterRequestAttribute.validateList([option1, option2, option3])

        then:
        option1.errorMessagesExist()
    }

    def "validateMedicareCoverageOptions: dependents"() {
        setup:
        def option1 = new HscLetterRequestAttributeVO(letterAttributeType: HsrReferenceConstants.LETTERATTRIBUTETYPE_MEDICARE_COVERAGE_POLICIES_OPTION1);
        def option2 = new HscLetterRequestAttributeVO(letterAttributeType: HsrReferenceConstants.LETTERATTRIBUTETYPE_MEDICARE_COVERAGE_POLICIES_OPTION2, hscLetterAttributeValue: "true");
        def option3 = new HscLetterRequestAttributeVO(letterAttributeType: HsrReferenceConstants.LETTERATTRIBUTETYPE_MEDICARE_COVERAGE_POLICIES_OPTION3, hscLetterAttributeValue: "true");
        def medicareManagedPolicies = new HscLetterRequestAttributeVO(letterAttributeType: HsrReferenceConstants.LETTERATTRIBUTETYPE_SPECIFIC_MEDICARE_MANAGED_CARE_POLICIES);
        def otherApplicablePolicies = new HscLetterRequestAttributeVO(letterAttributeType: HsrReferenceConstants.LETTERATTRIBUTETYPE_OTHER_APPLICABLE_POLICIES);

        when:
        hscLetterRequestAttribute.validateList([option1, option2, option3, medicareManagedPolicies, otherApplicablePolicies])

        then:
        medicareManagedPolicies.errorMessagesExist()
        otherApplicablePolicies.errorMessagesExist()
    }

    def "isValidDate"() {
        when:
        def result = hscLetterRequestAttribute.isValidDate(date)

        then:
        result == isValid

        where:
        date           | isValid
        "01/01/2001"   | false
        "01-01-2001"   | true
        "13-13-2001"   | false
        "01-40-2001"   | false
        "01-01-1800"   | false
        "01-01-20000"  | false
        "01- 01- 2001" | false
        "02-31-2001"   | false
        null           | true
    }

    def "isValidDateList"() {
        when:
        def result = hscLetterRequestAttribute.isValidDateList(dateListRange)

        then:
        result == isValid

        where:
        dateListRange                            | isValid
        null                                     | true
        "01/01/2001"                             | false
        "01-01-2001"                             | true
        "13-13-2001"                             | false
        "01-40-2001"                             | false
        "01-01-1800"                             | false
        "01-01-20000"                            | false
        "01- 01- 2001"                           | false
        "01-01-2001,"                            | false
        "01-01-2001,01-01-2001"                  | true
        "01-01-2001 ,01-01-2001"                 | true
        "01-01-2001,,01-01-2001"                 | false
        "01-01-2001:01-01-2001"                  | true
        "01-01-2001: 01-01-2001"                 | true
        "01-01-2001:,01-01-2001"                 | false
        "01-01-2001,01-01-2001:01-01-2001"       | true
        "01-01-2001  , 01-01-2001 :  01-01-2001" | true
    }
}
