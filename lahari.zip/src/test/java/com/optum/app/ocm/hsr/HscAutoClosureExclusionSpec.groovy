package com.optum.app.ocm.hsr

import com.optum.rf.bl.spring.TransactionInterceptor
import com.optum.rf.core.ejb.ServiceLocator
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.HscAutoClosureExclusion
import com.optum.app.common.hsr.businesslogic.impl.HscAutoClosureExclusionImpl
import com.optum.app.common.hsr.data.HscAutoClosureExclusionVO
import spock.lang.Unroll

class HscAutoClosureExclusionSpec extends HsrReadLogicSpecification {

    HscAutoClosureExclusion hscAutoClosureExclusion

    DataAccessObject<HscAutoClosureExclusionVO> dao
    PersistenceHelper persistenceHelper
    ServiceLocator serviceLocator
    TransactionInterceptor transactionInterceptor

    def setup() {
        dao = Mock(DataAccessObject)
        persistenceHelper = Mock(PersistenceHelper)
        serviceLocator = Mock(ServiceLocator)
        transactionInterceptor = Mock(TransactionInterceptor)

        hscAutoClosureExclusion = new HscAutoClosureExclusionImpl(
                dao: dao
        )
    }

    @Unroll
    def "isValid #testCase"() {
        given:
        def fundingArrangementID = "1"
        def urJurisCode = "2"
        def rp = new ReadProperties(FieldConstants.FUNDINGARRANGEMENTID, FieldConstants.URJURISCODE)
        rp.setKeyValue(FieldConstants.FUNDINGARRANGEMENTID, fundingArrangementID)
        rp.setKeyValue(FieldConstants.URJURISCODE, urJurisCode)
        rp.fields = null

        when:
        boolean retVal = hscAutoClosureExclusion.isValid(fundingArrangementID, urJurisCode)

        then:
        1 * dao.isValid(rp) >> expectedVal
        0 * _
        retVal == expectedVal

        where:
        testCase | expectedVal
        "passes" | true
        "fails"  | false
    }

    def "Test to read HscAutoClosureExclusionVO"() {
        setup:
        def fundingArrangementID = "1"
        def urJurisCode = "2"
        HscAutoClosureExclusionVO hscAutoClosureExclusionVO = new HscAutoClosureExclusionVO(fundingArrangementID: fundingArrangementID, urJurisCode: urJurisCode)
        def rp = new ReadProperties(FieldConstants.FUNDINGARRANGEMENTID, FieldConstants.URJURISCODE)
        rp.setKeyValue(FieldConstants.FUNDINGARRANGEMENTID, fundingArrangementID)
        rp.setKeyValue(FieldConstants.URJURISCODE, urJurisCode)
        rp.fields = null

        when:
        hscAutoClosureExclusion.read(fundingArrangementID, urJurisCode)

        then:
        1 * dao.read(rp) >> hscAutoClosureExclusionVO
        0 * _
    }
}
