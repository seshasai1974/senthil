package com.optum.app.ocm.hsr

import com.optum.rf.bl.spring.TransactionInterceptor
import com.optum.rf.core.locator.ServiceLocator
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.optum.app.common.hsr.businesslogic.impl.HscLetterRequestDiagnosisImpl
import com.optum.app.common.hsr.data.HscLetterRequestDiagnosisVO

class HscLetterRequestDiagnosisSpec extends HsrReadLogicSpecification {

    HscLetterRequestDiagnosisImpl hscLetterRequestDiagnosis

    DataAccessObject dao
    PersistenceHelper persistenceHelper
    ServiceLocator serviceLocator
    TransactionInterceptor transactionInterceptor

    def setup() {
        hscLetterRequestDiagnosis = new HscLetterRequestDiagnosisImpl()


        dao = Mock(DataAccessObject)
        persistenceHelper = Mock(PersistenceHelper)
        serviceLocator = Mock(ServiceLocator)
        transactionInterceptor = Mock(TransactionInterceptor)

        hscLetterRequestDiagnosis.setRequiredDao(dao)
        hscLetterRequestDiagnosis.setRequiredPersistenceHelper(persistenceHelper)
        hscLetterRequestDiagnosis.setRequiredServiceLocator(serviceLocator)
        hscLetterRequestDiagnosis.setRequiredTransactionInterceptor(transactionInterceptor)
    }

    /**
     * Test valid add.
     */
    def "Test Valid Add"() {
        setup:
        def vo = new HscLetterRequestDiagnosisVO()

        when:
        hscLetterRequestDiagnosis.add(vo)

        then:
        1 * persistenceHelper.add(_ as HscLetterRequestDiagnosisVO)
        //TODO Add any other expectations or use 'thrown UnsupportedOperationException'
        0 * _

        expect:
        !vo.errorMessagesExist()
    }

    /**
     * Test valid delete.
     */
    def "Test Valid Delete"() {
        setup:
        def vo = new HscLetterRequestDiagnosisVO()

        when:
        hscLetterRequestDiagnosis.delete(vo)

        then:
        1 * persistenceHelper.delete(_ as HscLetterRequestDiagnosisVO)
        //TODO Add any other expectations or use 'thrown UnsupportedOperationException'
        0 * _

        expect:
        !vo.errorMessagesExist()
    }

    /**
     * Test valid update.
     */
    def "Test Valid Update"() {
        setup:
        def vo = new HscLetterRequestDiagnosisVO()

        when:
        hscLetterRequestDiagnosis.update(vo)

        then:
        1 * persistenceHelper.update(_ as HscLetterRequestDiagnosisVO)
        //TODO Add any other expectations or use 'thrown UnsupportedOperationException'
        0 * _

        expect:
        !vo.errorMessagesExist()
    }

    def "Test isValid"() {
        setup:

        when:
        hscLetterRequestDiagnosis.isValid(123456L, 1, (short)1)

        then:
        1 * dao.isValid(_ as ReadProperties)
        0 * _
    }

    def "Test read"() {
        setup:

        when:
        hscLetterRequestDiagnosis.read(123456L, 1, (short)1)

        then:
        1 * dao.read(_ as ReadProperties)
        0 * _
    }

    def "Test getHscLetterRequestDiagnosisVOs"() {
        setup:

        when:
        hscLetterRequestDiagnosis.getHscLetterRequestDiagnosisVOs(123456L, 1)

        then:
        1 * dao.list(_ as QueryProperties)
        0 * _
    }

}
