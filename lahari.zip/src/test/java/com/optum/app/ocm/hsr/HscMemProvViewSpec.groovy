package com.optum.app.ocm.hsr

import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.exception.DAOException
import com.optum.rf.dao.sql.query.QueryCriteria
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.rf.dao.sql.query.ReadProperties
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.dao.PreparedStatementProperties
import com.optum.app.common.dao.PreparedStatementQueryProperties
import com.optum.app.common.hsr.businesslogic.HscMemProvView
import com.optum.app.common.hsr.businesslogic.impl.HscMemProvViewImpl
import com.optum.app.common.hsr.constants.HscMemProvConstants

class HscMemProvViewSpec extends HsrReadLogicSpecification {

    HscMemProvView hscMemProvView
    DataAccessObject dao

    def setup() {
        dao = Mock(DataAccessObject)

        hscMemProvView = new HscMemProvViewImpl()

        hscMemProvView.dao = dao
    }

    def "test callStoredProc"() {
        setup:
        HashMap<String, String> orderByHashMap = new LinkedHashMap<>()
        orderByHashMap.put(FieldConstants.HSCID, "123456")
        orderByHashMap.put(FieldConstants.LASTNAME, "SMITH")
        PreparedStatementProperties preparedStatementProperties = new PreparedStatementProperties(
                whereClauseParams: [new PreparedStatementQueryProperties(column: HscMemProvConstants.COLUMN_HSC_ID,
                                                                         parameters: [ '123456', '654321' ],
                                                                         criteria: QueryCriteria.EQUAL,
                                                                         orConditionIncluded: orConditionIncluded,
                                                                         orConditions: [ new PreparedStatementQueryProperties(column: HscMemProvConstants.COLUMN_MBR_ID,
                                                                                                                              criteria: QueryCriteria.EQUAL) ]),
                                    new PreparedStatementQueryProperties(column: HscMemProvConstants.COLUMN_LST_NM,
                                                                         parameters: [ 'SMITH', 'JONES' ],
                                                                         criteria: QueryCriteria.EQUAL,
                                                                         orConditionIncluded: orConditionIncluded,
                                                                         orConditions: [ new PreparedStatementQueryProperties(column: HscMemProvConstants.COLUMN_FST_NM,
                                                                                                                              criteria: QueryCriteria.EQUAL) ]) ],
                havingClauseParams: [new PreparedStatementQueryProperties(column: HscMemProvConstants.COLUMN_MBR_ID,
                                                                          parameters: [ '123456789', '987654321',  ],
                                                                          criteria: QueryCriteria.EQUAL,
                                                                          orConditionIncluded: orConditionIncluded, orConditions: [ new PreparedStatementQueryProperties(column: HscMemProvConstants.COLUMN_FST_NM,
                                                                                                                                                                         criteria: QueryCriteria.EQUAL) ]) ],
                orderByColumns: orderByHashMap)

        when:
        hscMemProvView.callStoredProc(preparedStatementProperties, 'userTypeABC', 1, 1, 1)

        then:
        0 * _._

        thrown(DAOException)

        where: orConditionIncluded << [ false, true ]
    }

    def "test callCountStoredProc"() {
        setup:
        PreparedStatementProperties preparedStatementProperties = new PreparedStatementProperties()

        when:
        hscMemProvView.callCountStoredProc(preparedStatementProperties, 'userTypeABC', 1)

        then:
        0 * _._

        thrown(DAOException)
    }

    def "test read"() {
        setup:

        when:
        hscMemProvView.read(123456L)

        then:
        1 * dao.read(_ as ReadProperties)
        0 * _._
    }

    def "test listByHscID"() {
        setup:
        QueryProperties queryProperties = new QueryProperties(QueryProperties.FilterType.LIST_ALL)

        when:
        hscMemProvView.listByHscID(queryProperties, 123456L)

        then:
        1 * dao.list(_ as QueryProperties)
        0 * _._
    }

}
