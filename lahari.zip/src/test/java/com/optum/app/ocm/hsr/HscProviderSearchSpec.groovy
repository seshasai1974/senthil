package com.optum.app.ocm.hsr

import com.optum.app.ocm.common.member.businesslogic.MemberIdentifier
import com.optum.rf.bl.spring.TransactionInterceptor
import com.optum.rf.core.locator.ServiceLocator
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.util.UhgCalendarUtilities
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.uhg.app.common.constants.spclcare.TableConstants
import com.optum.app.common.hsr.businesslogic.Hsc
import com.optum.app.common.hsr.businesslogic.HscProviderSearch
import com.optum.app.common.hsr.businesslogic.HscServiceDecision
import com.optum.app.common.hsr.businesslogic.HscServiceNonFacility
import com.optum.app.common.hsr.businesslogic.impl.HscProviderSearchImpl
import com.optum.app.common.hsr.constants.HsrReferenceConstants
import com.optum.app.common.hsr.data.HscFacilityVO
import com.optum.app.common.hsr.data.HscProviderSearchVO
import com.optum.app.common.hsr.data.HscServiceDecisionVO
import com.optum.app.common.hsr.data.HscServiceNonFacilityVO
import com.optum.app.common.hsr.data.HscVO
import com.optum.app.common.member.core.data.MemberVO
import spock.lang.Unroll

class HscProviderSearchSpec extends HsrReadLogicSpecification {

    HscProviderSearch hscProviderSearch

    DataAccessObject dao
    PersistenceHelper persistenceHelper
    ServiceLocator serviceLocator
    TransactionInterceptor transactionInterceptor
    HscServiceNonFacility hscServiceNonFacility
    HscServiceDecision hscServiceDecision
    Hsc hsc
    MemberIdentifier memberIdentifier

    def setup() {
        dao = Mock(DataAccessObject)
        persistenceHelper = Mock(PersistenceHelper)
        serviceLocator = Mock(ServiceLocator)
        transactionInterceptor = Mock(TransactionInterceptor)
        hscServiceNonFacility = Mock(HscServiceNonFacility)
        hscServiceDecision = Mock(HscServiceDecision)
        hsc = Mock(Hsc)
        memberIdentifier = Mock(MemberIdentifier)

        hscProviderSearch = new HscProviderSearchImpl(
                requiredDao: dao,
                requiredPersistenceHelper: persistenceHelper,
                requiredServiceLocator: serviceLocator,
                requiredTransactionInterceptor: transactionInterceptor,
                requiredHscServiceNonFacility: hscServiceNonFacility,
                hscServiceDecision: hscServiceDecision,
                hsc: hsc,
                memberIdentifier: memberIdentifier
        )
    }

    @Unroll
    def "isValid #testCase"() {
        given:
        def hscID = (long) 1
        def providerSeqNum = (short) 2
        def serviceSeqNum = (short) 3
        def rp = new ReadProperties(FieldConstants.HSCID, FieldConstants.PROVIDERSEQNUM, FieldConstants.SERVICESEQNUM)
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        rp.setKeyValue(FieldConstants.PROVIDERSEQNUM, providerSeqNum)
        rp.setKeyValue(FieldConstants.SERVICESEQNUM, serviceSeqNum)
        rp.fields = null

        when:
        boolean retVal = hscProviderSearch.isValid(hscID, providerSeqNum, serviceSeqNum)

        then:
        1 * dao.isValid(rp) >> expectedVal
        0 * _
        retVal == expectedVal

        where:
        testCase | expectedVal
        "passes" | true
        "fails"  | false
    }

    def "Test to read HscProviderSearchVO"() {
        setup:
        def hscID = (long) 1
        def providerSeqNum = (short) 2
        def serviceSeqNum = (short) 3
        HscProviderSearchVO hscProviderSearchVO = new HscProviderSearchVO(hscID: hscID, providerSeqNum: providerSeqNum, serviceSeqNum: serviceSeqNum)
        def rp = new ReadProperties(FieldConstants.HSCID, FieldConstants.PROVIDERSEQNUM, FieldConstants.SERVICESEQNUM)
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        rp.setKeyValue(FieldConstants.PROVIDERSEQNUM, providerSeqNum)
        rp.setKeyValue(FieldConstants.SERVICESEQNUM, serviceSeqNum)
        rp.fields = null

        when:
        hscProviderSearch.read(hscID, providerSeqNum, serviceSeqNum)

        then:
        1 * dao.read(rp) >> hscProviderSearchVO
        0 * _
    }

    def "Test updateHscProviderSearch"() {
        setup:
        HscVO hscVO = new HscVO(hscStatusType: hscStatus)

        when:
        hscProviderSearch.updateHscProviderSearch(hscVO)

        then:
        if(hscStatus == HsrReferenceConstants.HSCSTATUSTYPE_OPEN) {
            1 * dao.list(_ as QueryProperties) >> [ new HscProviderSearchVO() ]
            1 * persistenceHelper.update(_ as HscProviderSearchVO)
        } else if(hscStatus == HsrReferenceConstants.HSCSTATUSTYPE_DISCARDED) {
            1 * persistenceHelper.deleteCascading(_ as ReadProperties, TableConstants.HSC_PROV_SRCH)
        }
        0 * _

        where: hscStatus << [ HsrReferenceConstants.HSCSTATUSTYPE_OPEN, HsrReferenceConstants.HSCSTATUSTYPE_DISCARDED ]
    }

    def "Test updateHscProviderSearch with HscFacilityVO"() {
        setup:
        Date expectedAdmissionDate = UhgCalendarUtilities.todaysDate
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscStatusType: hscStatus, expectedAdmissionDate: expectedAdmissionDate)

        when:
        hscProviderSearch.updateHscProviderSearch(hscFacilityVO)

        then:
        1 * dao.list(_ as QueryProperties) >> [ new HscProviderSearchVO(expectedAdmissionDate: expectedAdmissionDate - 1) ]
        1 * persistenceHelper.update(_ as HscProviderSearchVO)
        0 * _

        where: hscStatus << [ HsrReferenceConstants.HSCSTATUSTYPE_OPEN, HsrReferenceConstants.HSCSTATUSTYPE_DISCARDED ]
    }


    def "Test updateHscProviderSearch with HscServiceDecisionVO"() {
        setup:
        HscServiceDecisionVO hscServiceDecisionVO = new HscServiceDecisionVO(decisionOutcomeType: decisionOutcome, changeInDecisionOutcomeType: true)

        when:
        hscProviderSearch.updateHscProviderSearch(hscServiceDecisionVO)

        then:
        1 * hsc.readUnhydrated(0) >> new HscVO(hscStatusType: HsrReferenceConstants.HSCSTATUSTYPE_OPEN,
                                               serviceSettingType: HsrReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT)
        if(decisionOutcome == HsrReferenceConstants.DECISIONOUTCOMETYPE_CANCELED) {
            2 * dao.list(_ as QueryProperties) >> [ new HscProviderSearchVO() ]
            1 * persistenceHelper.delete(_ as HscProviderSearchVO)
            1 * hscServiceNonFacility.listByHscID(0) >> [ new HscServiceNonFacilityVO() ]
            1 * hscServiceDecision.getCurrentDecision(0, 0, false)
            1 * persistenceHelper.update(_ as HscProviderSearchVO)
        } else {
            1 * dao.list(_ as QueryProperties) >> [ new HscProviderSearchVO() ]
            1 * persistenceHelper.update(_ as HscProviderSearchVO)
        }
        0 * _

        where: decisionOutcome << [ HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED, HsrReferenceConstants.DECISIONOUTCOMETYPE_CANCELED ]
    }

}
