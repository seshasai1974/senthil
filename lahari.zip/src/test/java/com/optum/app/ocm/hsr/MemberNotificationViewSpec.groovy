package com.optum.app.ocm.hsr

import com.optum.app.ocm.common.assignment.businesslogic.Assignment
import com.optum.app.ocm.common.member.businesslogic.MemberAlert
import com.optum.app.ocm.common.provider.businesslogic.ProviderClinical
import com.optum.rf.bl.spring.TransactionInterceptor
import com.optum.rf.core.ejb.ServiceLocator
import com.optum.rf.core.util.UhgCalendar
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.QueryCriteria
import com.optum.rf.dao.sql.query.QueryFilter
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.optum.app.common.assignment.data.AssignmentVO
import com.optum.app.common.constants.CommonReferenceConstants
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.Hsc
import com.optum.app.common.hsr.businesslogic.HscFacility
import com.optum.app.common.hsr.businesslogic.HscProvider
import com.optum.app.common.hsr.businesslogic.MemberNotificationView
import com.optum.app.common.hsr.businesslogic.impl.MemberNotificationViewImpl
import com.optum.app.common.hsr.constants.HsrReferenceConstants
import com.optum.app.common.hsr.data.HscFacilityVO
import com.optum.app.common.hsr.data.HscProviderVO
import com.optum.app.common.hsr.data.HscVO
import com.optum.app.common.hsr.data.MemberNotificationViewVO
import com.optum.app.common.member.core.data.MemberAlertVO

class MemberNotificationViewSpec extends HsrReadLogicSpecification {

    MemberNotificationView memberNotificationView

    DataAccessObject dao
    PersistenceHelper persistenceHelper
    ServiceLocator serviceLocator
    TransactionInterceptor transactionInterceptor
    Hsc hsc
    HscFacility hscFacility
    MemberAlert memberAlert
    HscProvider hscProvider
    ProviderClinical providerClinical
    Assignment assignment

    private static final long HSCID = 7654321
    private static final long MEMBERID = 123

    def setup() {
        dao = Mock(DataAccessObject)
        persistenceHelper = Mock(PersistenceHelper)
        serviceLocator = Mock(ServiceLocator)
        transactionInterceptor = Mock(TransactionInterceptor)
        hsc = Mock(Hsc)
        hscFacility = Mock(HscFacility)
        memberAlert = Mock(MemberAlert)
        hscProvider = Mock(HscProvider)
        providerClinical = Mock(ProviderClinical)
        assignment = Mock(Assignment)

        memberNotificationView = new MemberNotificationViewImpl(
                dao: dao,
                hsc: hsc,
                hscFacility: hscFacility,
                memberAlert: memberAlert,
                hscProvider: hscProvider,
                providerClinical: providerClinical,
                assignment: assignment
        )
    }

    def "Test to read MemberNotificationViewVO"() {
        setup:
        def hscID = (long) 1
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.NEW_FILTER)
        qp.addQueryFilter(new QueryFilter(FieldConstants.HSCID, hscID))
        qp.setResultSize(1);

        when:
        memberNotificationView.read(hscID)

        then:
        1 * dao.list(qp) >> new ArrayList<>()
        0 * _
    }

    def "Test listByMemberID"() {
        setup:
        def memberID = (long) 1
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        qp.addQueryFilter(new QueryFilter(com.optum.app.common.constants.spclcare.FieldConstants.MEMBERID, memberID))
        qp.setOrderByAscFields(com.optum.app.common.constants.spclcare.FieldConstants.CREATEDATETIME)

        when:
        memberNotificationView.listByMemberID(qp, memberID)

        then:
        1 * dao.list(qp) >> [ new MemberNotificationViewVO() ]
        1 * hscProvider.readFacility(0L) >> new HscProviderVO(lastName: 'SMITH', firstName: 'SAM')
        1 * providerClinical.read(0L)
        0 * _
    }

    def "Test updateMemberCaseInfo"() {
        setup:
        MemberNotificationViewVO memberNotificationViewVO = new MemberNotificationViewVO(memberID: 123456789L, hscID: 123456L, hscStatusType: hscStatus)
        HscVO hscVO = buildHscVO(memberNotificationViewVO)
        HscFacilityVO hscFacilityVO = buildHscFacilityVO(hscVO, memberNotificationViewVO)

        when:
        memberNotificationView.updateMemberCaseInfo(memberNotificationViewVO)

        then:
        1 * hsc.read(memberNotificationViewVO.getHscID()) >> hscVO
        1 * hsc.save(hscVO)
        1 * hscFacility.read(memberNotificationViewVO.getHscID()) >> null
        1 * hscFacility.saveWithUpdatedVersion(hscFacilityVO)
        if(hscStatus == HsrReferenceConstants.HSCSTATUSTYPE_CLOSED) {
            1 * assignment.list(_ as QueryProperties) >> [ new AssignmentVO() ]
            1 * memberAlert.list(_ as QueryProperties) >> [ new MemberAlertVO() ]
        }
        0 * _

        where: hscStatus << [ HsrReferenceConstants.HSCSTATUSTYPE_OPEN, HsrReferenceConstants.HSCSTATUSTYPE_CLOSED ]
    }

    def "Test createAdmissionAndDischargeAlerts"() {
        setup:
        MemberNotificationViewVO memberNotificationViewVO = buildMemberNotificationViewVO()
        HscVO hscVO = buildHscVO(memberNotificationViewVO)
        HscFacilityVO hscFacilityVO = buildHscFacilityVO(hscVO, memberNotificationViewVO)
        List<MemberNotificationViewVO> currentVOList = Arrays.asList(new MemberNotificationViewVO())

        QueryProperties admissionDateQueryProperties = getAdmissionDateQueryProperties(memberNotificationViewVO)
        MemberAlertVO admissionDateAlert = getAdmissionDateAlert(memberNotificationViewVO)

        QueryProperties dischargeDateQueryProperties = getDischargeDateQueryProperties(memberNotificationViewVO)
        MemberAlertVO dischargeDateAlert = getDischargeDateAlert(memberNotificationViewVO)

        when:
        memberNotificationView.createAdmissionAndDischargeAlerts(memberNotificationViewVO)

        then:
        1 * dao.list(getReadQueryProperties()) >> currentVOList
        1 * hscFacility.validateAdmissionAndDischargeDates(hscFacilityVO)
        1 * memberAlert.list(dischargeDateQueryProperties) >> new ArrayList<>()
        1 * memberAlert.add(dischargeDateAlert)
        1 * memberAlert.list(admissionDateQueryProperties) >> new ArrayList<>()
        1 * memberAlert.add(admissionDateAlert)
        0 * _
    }
    
    /************************************************************************************************/
    /************************************** HELPER METHODS ******************************************/
    /************************************************************************************************/
    private MemberNotificationViewVO buildMemberNotificationViewVO() {
        MemberNotificationViewVO vo = new MemberNotificationViewVO()
        vo.setHscID(HSCID)
        vo.setHscStatusType(HsrReferenceConstants.HSCSTATUSTYPE_OPEN)
        vo.setMemberID(MEMBERID)
        vo.setExpectedAdmissionDate(new UhgCalendar().getSQLDate())
        vo.setActualAdmissionDateTime(new Date())
        vo.setExpectedDischargeDate(new UhgCalendar().getSQLDate())
        vo.setActualDischargeDateTime(new Date())
        return vo
    }

    private HscVO buildHscVO(MemberNotificationViewVO memberNotificationViewVO) {
        HscVO vo = new HscVO()
        vo.setHscStatusType(memberNotificationViewVO.getHscStatusType())
        return vo
    }

    private HscFacilityVO buildHscFacilityVO(HscVO hscVO, MemberNotificationViewVO memberNotificationViewVO) {
        HscFacilityVO vo = new HscFacilityVO()
        vo.setHscID(hscVO.getHscID())
        vo.setExpectedAdmissionDate(memberNotificationViewVO.getExpectedAdmissionDate())
        vo.setActualAdmissionDateTime(memberNotificationViewVO.getActualAdmissionDateTime())
        vo.setExpectedDischargeDate(memberNotificationViewVO.getExpectedDischargeDate())
        vo.setActualDischargeDateTime(memberNotificationViewVO.getActualDischargeDateTime())
        return vo
    }

    private QueryProperties getReadQueryProperties() {
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.NEW_FILTER)
        qp.addQueryFilter(new QueryFilter(FieldConstants.HSCID, HSCID))
        qp.setResultSize(1)
        return qp
    }

    private QueryProperties getAdmissionDateQueryProperties(MemberNotificationViewVO memberNotificationViewVO) {
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        qp.addQueryFilter(new QueryFilter(com.optum.app.common.constants.spclcare.FieldConstants.MEMBERID, memberNotificationViewVO.getMemberID(), QueryCriteria.EQUAL))
        qp.addQueryFilter(new QueryFilter(com.optum.app.common.constants.spclcare.FieldConstants.ALERTTYPE, CommonReferenceConstants.ALERTTYPE_HOSPITAL_ADMISSION, QueryCriteria.EQUAL))
        qp.addQueryFilter(new QueryFilter(com.optum.app.common.constants.spclcare.FieldConstants.ALERTSTATUSTYPE, CommonReferenceConstants.ALERT_STATUS_OPEN, QueryCriteria.EQUAL))
        return qp
    }

    private QueryProperties getDischargeDateQueryProperties(MemberNotificationViewVO memberNotificationViewVO) {
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        qp.addQueryFilter(new QueryFilter(com.optum.app.common.constants.spclcare.FieldConstants.MEMBERID, memberNotificationViewVO.getMemberID(), QueryCriteria.EQUAL))
        qp.addQueryFilter(new QueryFilter(com.optum.app.common.constants.spclcare.FieldConstants.ALERTTYPE, CommonReferenceConstants.ALERTTYPE_INPATIENT_DISCHARGE, QueryCriteria.EQUAL))
        qp.addQueryFilter(new QueryFilter(com.optum.app.common.constants.spclcare.FieldConstants.ALERTSTATUSTYPE, CommonReferenceConstants.ALERT_STATUS_OPEN, QueryCriteria.EQUAL))
        return qp
    }

    private MemberAlertVO getAdmissionDateAlert(MemberNotificationViewVO memberNotificationViewVO) {
        MemberAlertVO alertVO = new MemberAlertVO()
        alertVO.setMemberID(memberNotificationViewVO.getMemberID())
        alertVO.setAlertType(CommonReferenceConstants.ALERTTYPE_HOSPITAL_ADMISSION)
        alertVO.setAlertStatusType(CommonReferenceConstants.ALERT_STATUS_OPEN)
        return alertVO
    }

    private MemberAlertVO getDischargeDateAlert(MemberNotificationViewVO memberNotificationViewVO) {
        MemberAlertVO alertVO = new MemberAlertVO()
        alertVO.setMemberID(memberNotificationViewVO.getMemberID())
        alertVO.setAlertType(CommonReferenceConstants.ALERTTYPE_INPATIENT_DISCHARGE)
        alertVO.setAlertStatusType(CommonReferenceConstants.ALERT_STATUS_OPEN)
        return alertVO
    }

}
