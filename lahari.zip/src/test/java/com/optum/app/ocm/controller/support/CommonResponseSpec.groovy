package com.optum.app.ocm.controller.support

import com.optum.rf.dao.data.ValueObject
import com.optum.rf.dao.data.message.FieldMessage
import com.optum.rf.dao.data.message.Message
import spock.lang.Specification

/**
 * Created by skohl on 7/19/2016.
 */
class CommonResponseSpec extends Specification {
    private class TestMessage extends Message {
        private static int count;
        public TestMessage(){
            this( Integer.toString( count++ ));
        }
        public TestMessage( String id ){
            super( Message.Type.ERROR, id );
        }
    }
    CommonResponse underTest = new CommonResponse();
    def "copyMessages - copies global messages"() {
        setup:
            ValueObject vo = new ValueObject();
            Message global1 = new TestMessage( "global1");
            Message global2 = new TestMessage( "global2");
            vo.addGlobalMessage( global1 )
            vo.addGlobalMessage( global2 )
        when:
            underTest.copyMessages( vo )
        then:
            underTest.getGlobalMessages().size() == 2
            underTest.getErrorExists() == true
            underTest.getGlobalMessages().contains( global2 )
            underTest.getGlobalMessages().contains( global1 )

    }
    def "copyMessages - copies field messages"() {
        setup:
        ValueObject vo = new ValueObject();
        TestMessage fm1 = new TestMessage();
        TestMessage fm2 = new TestMessage();
        TestMessage fm3 = new TestMessage();
        vo.addMessage( "fm1", fm1 );
        vo.addMessage( "fm2", fm2, fm3 )
        when:
        underTest.copyMessages( vo )
        then:
        underTest.getGlobalMessages().size() == 0
        underTest.getErrorExists() == true
        !underTest.getGlobalMessages().contains( fm1 )
        underTest.getFieldMessages().size() == 2
        underTest.getFieldMessages().get( "fm1").size() == 1
        underTest.getFieldMessages().get( "fm2").size() == 2
        underTest.getFieldMessages().get( "fm1").get(0).message ==  fm1;
        underTest.getFieldMessages().get( "fm2").get(0).message ==  fm2;
        underTest.getFieldMessages().get( "fm2").get(1).message ==  fm3;
        underTest.getFieldMessages().get( "fm2").get(0).message !=  fm1;
        underTest.getFieldMessages().get( "fm2").get(1).message !=  fm1;
        underTest.errorExists == true;
    }

    def "addGlobalMessages"(){
        setup:
            TestMessage gm1 = new TestMessage()
            TestMessage gm2 = new TestMessage()
            TestMessage gm3 = new TestMessage()
        when:
            underTest.addGlobalMessages( gm1, gm2, gm3 )
        then:
            underTest.getGlobalMessages().contains( gm1 )
            underTest.getGlobalMessages().contains( gm2 )
            underTest.getGlobalMessages().contains( gm3 )
    }

    def "addFieldMessages"(){
        setup:
            String field = "field"
            TestMessage fm1 = new TestMessage()
            TestMessage fm2 = new TestMessage()
            TestMessage fm3 = new TestMessage()
        when:
            underTest.addFieldMessages( field, fm1, fm2, fm3 )
        then:
            underTest.getFieldMessages().get( field ).contains( toFieldMessage( field, fm1 ))
            underTest.getFieldMessages().get( field ).contains( toFieldMessage( field, fm2 ))
            underTest.getFieldMessages().get( field ).contains( toFieldMessage( field, fm3 ))
    }
    private FieldMessage toFieldMessage( String field, Message message ){
        return new FieldMessage( field, message );
    }

}
