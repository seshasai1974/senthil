package com.optum.app.ocm.hsr

import com.optum.rf.bl.spring.TransactionInterceptor
import com.optum.rf.core.locator.ServiceLocator
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.HscServiceUrJurisdiction
import com.optum.app.common.hsr.businesslogic.impl.HscServiceUrJurisdictionImpl
import com.optum.app.common.hsr.data.HscServiceUrJurisdictionVO
import spock.lang.Unroll

class HscServiceUrJurisdictionSpec extends HsrReadLogicSpecification {

    HscServiceUrJurisdiction hscServiceUrJurisdiction

    DataAccessObject dao
    PersistenceHelper persistenceHelper
    ServiceLocator serviceLocator
    TransactionInterceptor transactionInterceptor

    def setup() {
        dao = Mock(DataAccessObject)
        persistenceHelper = Mock(PersistenceHelper)
        serviceLocator = Mock(ServiceLocator)
        transactionInterceptor = Mock(TransactionInterceptor)

        hscServiceUrJurisdiction = new HscServiceUrJurisdictionImpl(
                requiredDao: dao,
                requiredPersistenceHelper: persistenceHelper,
                requiredServiceLocator: serviceLocator,
                requiredTransactionInterceptor: transactionInterceptor
        )
    }

    @Unroll
    def "isValid #testCase"() {
        given:
        def hscID = (long) 1
        def urJurisCode = "2"
        def serviceSeqNum = (short) 3
        def rp = new ReadProperties(FieldConstants.HSCID, FieldConstants.SERVICESEQNUM, FieldConstants.URJURISCODE)
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        rp.setKeyValue(FieldConstants.URJURISCODE, urJurisCode)
        rp.setKeyValue(FieldConstants.SERVICESEQNUM, serviceSeqNum)
        rp.fields = null

        when:
        boolean retVal = hscServiceUrJurisdiction.isValid(hscID, urJurisCode, serviceSeqNum)

        then:
        1 * dao.isValid(rp) >> expectedVal
        0 * _
        retVal == expectedVal

        where:
        testCase | expectedVal
        "passes" | true
        "fails"  | false
    }

    def "Test to read HscServiceUrJurisdictionVO"() {
        setup:
        def hscID = (long) 1
        def urJurisCode = "2"
        def serviceSeqNum = (short) 3
        HscServiceUrJurisdictionVO hscServiceUrJurisdictionVO = new HscServiceUrJurisdictionVO(hscID: hscID, urJurisCode: urJurisCode, serviceSeqNum: serviceSeqNum)
        def rp = new ReadProperties(FieldConstants.HSCID, FieldConstants.SERVICESEQNUM, FieldConstants.URJURISCODE)
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        rp.setKeyValue(FieldConstants.URJURISCODE, urJurisCode)
        rp.setKeyValue(FieldConstants.SERVICESEQNUM, serviceSeqNum)
        rp.fields = null

        when:
        hscServiceUrJurisdiction.read(hscID, urJurisCode, serviceSeqNum)

        then:
        1 * dao.read(rp) >> hscServiceUrJurisdictionVO
        0 * _
    }
}
