package com.optum.app.ocm.hsr

import com.optum.rf.bl.spring.TransactionInterceptor
import com.optum.rf.core.locator.ServiceLocator
import com.optum.rf.core.util.UhgCalendar
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.HscProviderContractAmendment
import com.optum.app.common.hsr.businesslogic.HscProviderContractAmendmentClause
import com.optum.app.common.hsr.businesslogic.impl.HscProviderContractAmendmentImpl
import com.optum.app.common.hsr.data.HscProviderContractAmendmentVO
import com.optum.app.common.hsr.data.HscProviderVO
import spock.lang.Unroll

class HscProviderContractAmendmentSpec extends HsrReadLogicSpecification {

    HscProviderContractAmendment hscProviderContractAmendment

    DataAccessObject dao
    PersistenceHelper persistenceHelper
    ServiceLocator serviceLocator
    TransactionInterceptor transactionInterceptor
    HscProviderContractAmendmentClause hscProviderContractAmendmentClause

    def setup() {
        dao = Mock(DataAccessObject)
        persistenceHelper = Mock(PersistenceHelper)
        serviceLocator = Mock(ServiceLocator)
        transactionInterceptor = Mock(TransactionInterceptor)
        hscProviderContractAmendmentClause = Mock(HscProviderContractAmendmentClause)

        hscProviderContractAmendment = new HscProviderContractAmendmentImpl(
                dao: dao,
                requiredPersistenceHelper: persistenceHelper,
                requiredServiceLocator: serviceLocator,
                requiredTransactionInterceptor: transactionInterceptor,
                hscProviderContractAmendmentClause: hscProviderContractAmendmentClause
        )
    }

    @Unroll
    def "isValid #testCase"() {
        given:
        def hscID = (long) 1
        def providerSeqNum = (long) 2
        def contractAmendmentSeqNum = 3
        def rp = new ReadProperties(FieldConstants.HSCID, FieldConstants.PROVIDERSEQNUM, FieldConstants.CONTRACTAMENDMENTSEQNUM)
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        rp.setKeyValue(FieldConstants.PROVIDERSEQNUM, providerSeqNum)
        rp.setKeyValue(FieldConstants.CONTRACTAMENDMENTSEQNUM, contractAmendmentSeqNum)
        rp.fields = null

        when:
        boolean retVal = hscProviderContractAmendment.isValid(hscID, providerSeqNum, contractAmendmentSeqNum)

        then:
        1 * dao.isValid(rp) >> expectedVal
        0 * _
        retVal == expectedVal

        where:
        testCase | expectedVal
        "passes" | true
        "fails"  | false
    }

    def "Test to read HscProviderContractAmendmentVO"() {
        setup:
        def hscID = (long) 1
        def providerSeqNum = (long) 2
        def contractAmendmentSeqNum = 3
        HscProviderContractAmendmentVO hscProviderContractAmendmentVO = new HscProviderContractAmendmentVO(hscID: hscID, providerSeqNum: providerSeqNum, contractAmendmentSeqNum: contractAmendmentSeqNum)
        def rp = new ReadProperties(FieldConstants.HSCID, FieldConstants.PROVIDERSEQNUM, FieldConstants.CONTRACTAMENDMENTSEQNUM)
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        rp.setKeyValue(FieldConstants.PROVIDERSEQNUM, providerSeqNum)
        rp.setKeyValue(FieldConstants.CONTRACTAMENDMENTSEQNUM, contractAmendmentSeqNum)
        rp.fields = null

        when:
        hscProviderContractAmendment.read(hscID, providerSeqNum, contractAmendmentSeqNum)

        then:
        1 * dao.read(rp) >> hscProviderContractAmendmentVO
        0 * _
    }

    def "Test add"() {
        setup:
        HscProviderContractAmendmentVO hscProviderContractAmendmentVO = new HscProviderContractAmendmentVO(hscID: 123456L, providerSeqNum: 1, contractAmendmentSeqNum: 2)

        when:
        hscProviderContractAmendment.add(hscProviderContractAmendmentVO, false)

        then:
        1 * persistenceHelper.add(_ as HscProviderContractAmendmentVO)
        0 * _
    }

    def "Test update"() {
        setup:
        HscProviderContractAmendmentVO hscProviderContractAmendmentVO = new HscProviderContractAmendmentVO(hscID: 123456L, providerSeqNum: 1, contractAmendmentSeqNum: 2)

        when:
        hscProviderContractAmendment.update(hscProviderContractAmendmentVO, false)

        then:
        1 * persistenceHelper.update(_ as HscProviderContractAmendmentVO)
        0 * _
    }

    def "Test listMedicalNecessityContracts"() {
        setup:

        when:
        hscProviderContractAmendment.listMedicalNecessityContracts(123456L, (short)1)

        then:
        1 * dao.list(_ as QueryProperties)
        0 * _
    }

    def "Test listAllContractsForProvider"() {
        setup:

        when:
        hscProviderContractAmendment.listAllContractsForProvider(123456L, (short)1)

        then:
        1 * dao.list(_ as QueryProperties)
        0 * _
    }

    def "Test listEffectiveContractsForProvider"() {
        setup:

        when:
        hscProviderContractAmendment.listEffectiveContractsForProvider(123456L, (short)1, UhgCalendar.getSQLDate('2018-12-31'))

        then:
        1 * dao.list(_ as QueryProperties)
        0 * _
    }

    def "Test copyProviderContractAmendment"() {
        setup:
        HscProviderVO hscProviderVO = new HscProviderVO()

        when:
        hscProviderContractAmendment.copyProviderContractAmendment(hscProviderVO, 123456L, 987654L, (short)1)

        then:
        1 * dao.list(_ as QueryProperties) >> [ new HscProviderContractAmendmentVO(providerSeqNum: 5) ]
        1 * hscProviderContractAmendmentClause.copyProviderContractAmendmentClause(_ as HscProviderContractAmendmentVO, 123456, 987654, _)
        0 * _
    }

}
