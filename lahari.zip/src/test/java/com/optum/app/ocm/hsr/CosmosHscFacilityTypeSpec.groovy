package com.optum.app.ocm.hsr

import com.optum.rf.bl.spring.TransactionInterceptor
import com.optum.rf.core.locator.ServiceLocator
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.QueryFilter
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.CosmosHscFacilityType
import com.optum.app.common.hsr.businesslogic.impl.CosmosHscFacilityTypeImpl
import com.optum.app.common.hsr.data.CosmosHscFacilityTypeVO

class CosmosHscFacilityTypeSpec extends HsrReadLogicSpecification {

    CosmosHscFacilityType cosmosHscFacilityType

    DataAccessObject dao
    PersistenceHelper persistenceHelper
    ServiceLocator serviceLocator
    TransactionInterceptor transactionInterceptor

    def setup() {
        dao = Mock(DataAccessObject)
        persistenceHelper = Mock(PersistenceHelper)
        serviceLocator = Mock(ServiceLocator)
        transactionInterceptor = Mock(TransactionInterceptor)

        cosmosHscFacilityType = new CosmosHscFacilityTypeImpl(
                dao: dao,
                requiredServiceLocator: serviceLocator
        )
    }

    def "Test listByDivID"() {
        setup:
        def divID = "1"
        CosmosHscFacilityTypeVO cosmosHscFacilityTypeVO = new CosmosHscFacilityTypeVO(divID: divID)
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        qp.addQueryFilter(new QueryFilter(FieldConstants.DIVID, divID))

        when:
        cosmosHscFacilityType.listByDivID(divID)

        then:
        1 * dao.list(qp) >> [cosmosHscFacilityTypeVO]
        0 * _
    }
}
