package com.optum.app.ocm.hsr

import com.optum.app.common.hsr.businesslogic.HscServiceDetail
import com.optum.app.common.hsr.data.HscServiceDetailVO
import com.optum.app.ocm.common.member.businesslogic.Member
import com.optum.app.ocm.common.member.businesslogic.MemberAddress
import com.optum.app.ocm.ref.businesslogic.CustomerReference
import com.optum.app.shared.constants.SpclCareFeatureFlagConstants
import com.optum.app.shared.constants.SpclCareReferenceConstants
import com.optum.app.shared.customlog.LogFactory
import com.optum.rf.bl.businesslogic.ReadLogic
import com.optum.rf.bl.factory.LogicTypeFactory
import com.optum.rf.common.featureflag.util.FeatureFlagManager
import com.optum.rf.common.featureflag.util.FeatureFlagUtility
import com.optum.rf.common.messages.GlobalMessages
import com.optum.rf.common.reference.businesslogic.Cpt4
import com.optum.rf.common.reference.businesslogic.Hcpcs
import com.optum.rf.common.reference.businesslogic.ProcedureRangeCategoryRule
import com.optum.rf.common.reference.data.Cpt4VO
import com.optum.rf.common.reference.data.HcpcsVO
import com.optum.rf.common.reference.data.ProcedureCodeVO
import com.optum.rf.common.settings.businesslogic.TemporarySystemSetting
import com.optum.rf.core.util.UhgCalendar
import com.optum.rf.dao.data.ValueObject
import com.optum.rf.dao.exception.UhgRuntimeException
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.QueryBuilder
import com.optum.rf.dao.sql.query.QueryCriteria
import com.optum.rf.dao.sql.query.QueryFilter
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.tabledef.TableDefFactory
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.optum.app.common.constants.CommonReferenceConstants
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.uhg.app.common.constants.spclcare.TableConstants
import com.optum.app.common.hsr.businesslogic.Hsc
import com.optum.app.common.hsr.businesslogic.HscFacility
import com.optum.app.common.hsr.businesslogic.HscFacilityDecision
import com.optum.app.common.hsr.businesslogic.HscFacilityDecisionBedDay
import com.optum.app.common.hsr.businesslogic.HscMemberCoverage
import com.optum.app.common.hsr.businesslogic.HscProvider
import com.optum.app.common.hsr.businesslogic.HscServiceDecision
import com.optum.app.common.hsr.businesslogic.HscServiceFacility
import com.optum.app.common.hsr.businesslogic.HscServiceLineProgramTypeHelper
import com.optum.app.common.hsr.businesslogic.HscServiceLineTatHelper
import com.optum.app.common.hsr.businesslogic.HscServiceNonFacility
import com.optum.app.common.hsr.businesslogic.HscServiceNonFacilityHistory
import com.optum.app.common.hsr.businesslogic.HscServiceNonFacilitySchedule
import com.optum.app.common.hsr.businesslogic.HscServiceUrJurisdiction
import com.optum.app.common.hsr.businesslogic.HscTatPointHelper
import com.optum.app.common.hsr.businesslogic.impl.HscServiceImpl
import com.optum.app.common.hsr.constants.HsrReferenceConstants
import com.optum.app.common.hsr.data.HscIntakeCompositeVO
import com.optum.app.common.hsr.data.HscIntakeVO
import com.optum.app.common.hsr.data.HscMemberCoverageVO
import com.optum.app.common.hsr.data.HscProviderRoleVO
import com.optum.app.common.hsr.data.HscProviderVO
import com.optum.app.common.hsr.data.HscServiceDecisionSourceVO
import com.optum.app.common.hsr.data.HscServiceDecisionVO
import com.optum.app.common.hsr.data.HscServiceFacilityVO
import com.optum.app.common.hsr.data.HscServiceNonFacilityHistoryVO
import com.optum.app.common.hsr.data.HscServiceNonFacilityScheduleVO
import com.optum.app.common.hsr.data.HscServiceNonFacilityVO
import com.optum.app.common.hsr.data.HscServiceTatSummaryVO
import com.optum.app.common.hsr.data.HscServiceUrJurisdictionVO
import com.optum.app.common.hsr.data.HscServiceVO
import com.optum.app.common.hsr.data.HscVO
import com.optum.app.common.hsr.messages.HscDecisionMessages
import com.optum.app.common.hsr.messages.HscMessages
import com.optum.app.common.member.core.data.MemberAddressVO
import com.optum.app.common.member.core.data.MemberVO
import com.optum.app.constants.HscConstants
import com.optum.app.ocm.constants.SecurityConstants
import spock.lang.Unroll

class HscServiceImplSpec extends HsrReadLogicSpecification {

    private HscServiceImpl hscService
    private DataAccessObject<HscServiceVO> dao
    private PersistenceHelper persistenceHelper
    private HscServiceDecision hscServiceDecision
    private HscFacilityDecision hscFacilityDecision
    private HscFacilityDecisionBedDay hscFacilityDecisionBedDay
    private HscProvider hscProvider
    private HscServiceNonFacility hscServiceNonFacility
    private Hsc hsc
    private Member member
    private CustomerReference customerReference
    private HscFacility hscFacility
    private HscServiceFacility hscServiceFacility
    private ProcedureRangeCategoryRule procedureRangeCategoryRule
    private HscServiceLineProgramTypeHelper hscServiceLineProgramTypeHelper
    private HscTatPointHelper hscTatPointHelper
    private TemporarySystemSetting temporarySystemSetting
    private HscServiceNonFacilitySchedule hscServiceNonFacilitySchedule
    private HscServiceUrJurisdiction hscServiceUrJurisdiction
    private HscServiceLineTatHelper hscServiceLineTatHelper
    private HscMemberCoverage hscMemberCoverage
    private MemberAddress memberAddress
    private HscServiceNonFacilityHistory hscServiceNonFacilityHistory
    private Cpt4 cpt4
    private Hcpcs hcpcs
    private HscServiceDetail hscServiceDetail
    private FeatureFlagManager featureFlagManager

    private static final long HSC_ID = 1
    private static final short SERVICE_SEQ_NUM = 2
    private static final String SERVICE_REF_NUM = "3"
    private static final long MEMBER_ID = 4
    private static final short SERVICE_PROD_SEQ_NUM = 5
    private static final short PROVIDER_SEQ_NUM = 6
    private static final String PROCCODETYPE = "C"
    private static final String PROCEDURE_CODE = "D"

    def setup() {
        hscService = new HscServiceImpl()
        member = Mock(Member)
        customerReference = Mock(CustomerReference)
        hscFacility = Mock(HscFacility)
        hscServiceFacility = Mock(HscServiceFacility)
        dao = Mock(DataAccessObject)
        persistenceHelper = Mock(PersistenceHelper)
        hscServiceDecision = Mock(HscServiceDecision)
        hscFacilityDecision = Mock(HscFacilityDecision)
        hscFacilityDecisionBedDay = Mock(HscFacilityDecisionBedDay)
        hscProvider = Mock(HscProvider)
        hscServiceNonFacility = Mock(HscServiceNonFacility)
        hsc = Mock(Hsc)
        procedureRangeCategoryRule = Mock(ProcedureRangeCategoryRule)
        hscServiceLineProgramTypeHelper = Mock(HscServiceLineProgramTypeHelper)
        hscTatPointHelper = Mock(HscTatPointHelper)
        temporarySystemSetting = Mock(TemporarySystemSetting)
        hscServiceNonFacilitySchedule = Mock(HscServiceNonFacilitySchedule)
        hscServiceNonFacilityHistory = Mock(HscServiceNonFacilityHistory)
        hscServiceUrJurisdiction = Mock(HscServiceUrJurisdiction)
        hscServiceLineTatHelper = Mock(HscServiceLineTatHelper)
        hscMemberCoverage = Mock(HscMemberCoverage)
        memberAddress = Mock(MemberAddress)
        cpt4 = Mock(Cpt4)
        hcpcs = Mock(Hcpcs)
        hscServiceDetail = Mock(HscServiceDetail)
        featureFlagManager = Mock(FeatureFlagManager)

        FeatureFlagUtility.featureFlagManager = featureFlagManager

        hscService.setRequiredDao(dao)
        hscService.setRequiredPersistenceHelper(persistenceHelper)
        hscService.setRequiredHscServiceDecision(hscServiceDecision)
        hscService.setRequiredHscFacilityDecision(hscFacilityDecision)
        hscService.setRequiredHscFacilityDecisionBedDay(hscFacilityDecisionBedDay)
        hscService.setRequiredHscProvider(hscProvider)
        hscService.setRequiredHscServiceNonFacility(hscServiceNonFacility)
        hscService.setRequiredHsc(hsc)
        hscService.setRequiredCustomerReference(customerReference)
        hscService.setRequiredHscServiceFacility(hscServiceFacility)
        hscService.setRequiredHscServiceLineProgramTypeHelper(hscServiceLineProgramTypeHelper)
        hscService.setRequiredHscTatPointHelper(hscTatPointHelper)
        hscService.setRequiredHscServiceNonFacilitySchedule(hscServiceNonFacilitySchedule)
        hscService.setRequiredHscServiceNonFacilityHistory(hscServiceNonFacilityHistory)
        hscService.setRequiredHscServiceUrJurisdiction(hscServiceUrJurisdiction)
        hscService.setRequiredHscServiceLineTatHelper(hscServiceLineTatHelper)
        hscService.setRequiredHscMemberCoverage(hscMemberCoverage)
        hscService.setRequiredMemberAddress(memberAddress)
        hscService.setRequiredCpt4(cpt4)
        hscService.setRequiredHcpcs(hcpcs)
        hscService.setRequiredHscServiceDetail(hscServiceDetail)
        hscService.setTemporarySystemSetting(temporarySystemSetting)
    }

    @Unroll()
    def "test overlay on save"() {
        given:
        HscProviderVO providerVO = new HscProviderVO(providerUpdated: true, servicingProviderInd: true, ssoProviderInd: true, attendingProviderInd: true)
        HscServiceVO hscServiceVO = new HscServiceVO(hscServiceFacilityVO: new HscServiceFacilityVO())

        when:
        hscService.saveProvider(providerVO, hscServiceVO, isSso)

        then:
        1 * hscProvider.saveCascading(providerVO)
        0 * _

        and:
        !providerVO.attendingProviderInd
        providerVO.servicingProviderInd != isSso
        providerVO.ssoProviderInd == isSso

        where:
        isSso << [true, false]
    }

    def "test cascade provider: overlay"() {
        given:
        HscVO hscVO = new HscVO(specialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_PACIFICARE)
        HscProviderVO servicingProviderVO = new HscProviderVO(providerUpdated: true, servicingProviderInd: true)
        HscServiceVO decisionServiceVO = new HscServiceVO(hscServiceLockType: HsrReferenceConstants.HSCSERVICELOCKTYPE_PARTIAL_LOCK)
        HscServiceVO canceledServiceVO = new HscServiceVO(hscServiceLockType: HsrReferenceConstants.HSCSERVICELOCKTYPE_FULL_LOCK)

        when:
        hscService.cascadeProviderUpdateToServices(hscVO, servicingProviderVO)

        then:
        1 * dao.list(_) >> { QueryProperties qp ->
            assert qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == 0
            return [decisionServiceVO, canceledServiceVO]
        }
        1 * hscServiceDecision.cascadeProviderUpdateToDecisions(servicingProviderVO, [decisionServiceVO], hscVO.isPhsSpecialProcessType())
        0 * _
    }

    def "test cascade provider: update"() {
        given:
        HscVO hscVO = new HscVO(specialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_PACIFICARE)
        HscProviderVO servicingProviderVO = new HscProviderVO(servicingProviderInd: true)
        HscServiceVO serviceVO = new HscServiceVO(hscServiceLockType: HsrReferenceConstants.HSCSERVICELOCKTYPE_NO_LOCK, serviceSeqNum: 2)
        HscServiceVO currentServiceVO = new HscServiceVO(hscServiceLockType: HsrReferenceConstants.HSCSERVICELOCKTYPE_NO_LOCK, serviceSeqNum: 3)
        HscServiceVO canceledServiceVO = new HscServiceVO(hscServiceLockType: HsrReferenceConstants.HSCSERVICELOCKTYPE_FULL_LOCK, serviceSeqNum: 4)

        when:
        hscService.cascadeProviderUpdate(hscVO, servicingProviderVO, (short) 1, (short) 3)

        then:
        1 * dao.list(_) >> { QueryProperties qp ->
            assert qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == 0
            assert qp.getQueryFilter(FieldConstants.SERVICEPROVIDERSEQNUM).getFieldValue() == 1
            return [serviceVO, currentServiceVO, canceledServiceVO]
        }
        1 * persistenceHelper.updateBatch([serviceVO])
        0 * _
    }

    def "test cascade provider: facility"() {
        given:
        HscVO hscVO = new HscVO(specialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_PACIFICARE, serviceSettingType: HsrReferenceConstants.SERVICESETTINGTYPE_INPATIENT)
        HscProviderVO servicingProviderVO = new HscProviderVO(providerUpdated: true, facilityProviderInd: true, servicingProviderInd: true)

        when:
        hscService.cascadeProviderUpdateToServices(hscVO, servicingProviderVO)

        then:
        1 * dao.list(_) >> { QueryProperties qp ->
            assert qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == 0
            return []
        }
        1 * hscFacilityDecision.cascadeProviderUpdateToDecision(servicingProviderVO, hscVO.isPhsSpecialProcessType())
        1 * hscFacilityDecisionBedDay.updateFacilityProviderForBedDays(servicingProviderVO)
        0 * _
    }

    @Unroll("TestCase = #testCaseNumber ")
    def "test getServiceReviewType"() {
        when:
        String result = hscService.getServiceReviewType(hscServiceDecisionVO)

        then:
        1 * dao.read(_) >> { ReadProperties rp ->
            assert rp.getKeyValue(FieldConstants.HSCID) == 1234
            assert rp.getKeyValue(FieldConstants.SERVICESEQNUM) == 1
            return hscServiceVO
        }
        0 * _

        and:
        assert expectedValue.equals(result)

        where:
        testCaseNumber | hscServiceDecisionVO | hscServiceVO | expectedValue
        1              | getSDvo()            | getSvo("MN") | "MN"
        2              | getSDvo()            | getSvo("AB") | "AB"
        3              | getSDvo()            | null         | ""
        4              | getSDvo()            | null         | ""
    }

    def getSDvo() {
        return new HscServiceDecisionVO(hscID: 1234L, serviceSeqNum: 1)
    }

    def getSvo(String serviceReviewType) {
        return new HscServiceVO(serviceReviewType: serviceReviewType)
    }

    def "test invalid validateForCompleteIntake"() {
        given:
        String serviceSettingType = CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT
        List hscServiceVOs = [new HscServiceVO(serviceSeqNum: 1, serviceProviderSeqNum: 1, procedureCode: '1'), new HscServiceVO(serviceSeqNum: SERVICE_SEQ_NUM, serviceProviderSeqNum: 1, procedureCode: '1')]
        MemberVO memberVO = new MemberVO()
        HscVO hscVO = new HscVO()
        hscVO.setServiceSettingType(serviceSettingType)
        hscVO.setHscID(HSC_ID)

        // QUERY PROPERTIES
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL, new QueryFilter(FieldConstants.HSCID, HSC_ID))
        qp.setOrderByAscFields(FieldConstants.SERVICESEQNUM)

        // INVALID VALUEOBJECT(s)
        ValueObject errorVO1 = new ValueObject()
        errorVO1.addMessage(FieldConstants.SERVICESTARTDATE, GlobalMessages.ERR_REQUIRED_VALUE)
        ValueObject errorVO2 = new ValueObject()
        errorVO2.addMessage(FieldConstants.SERVICEENDDATE, GlobalMessages.ERR_REQUIRED_VALUE)

        when:
        ValueObject returnedErrorVO = hscService.validateForCompleteIntake(HSC_ID, serviceSettingType)

        then:
        1 * hsc.read(HSC_ID) >> hscVO
        1 * dao.list(qp) >> hscServiceVOs
        1 * hscServiceNonFacility.validateForCompleteIntake(HSC_ID, hscServiceVOs[0].getServiceSeqNum(), hscServiceVOs[0].getProcCodeType(), hscServiceVOs[0].getProcedureCode()) >> errorVO1
        1 * hscServiceNonFacility.validateForCompleteIntake(HSC_ID, hscServiceVOs[1].getServiceSeqNum(), hscServiceVOs[1].getProcCodeType(), hscServiceVOs[1].getProcedureCode()) >> errorVO2
        0 * _

        expect:
        returnedErrorVO.messages.size() == 2
        returnedErrorVO.getMessage(FieldConstants.SERVICESTARTDATE).message.messageID.first() == GlobalMessages.ERR_REQUIRED_VALUE.messageID
        returnedErrorVO.getMessage(FieldConstants.SERVICEENDDATE).message.messageID.first() == GlobalMessages.ERR_REQUIRED_VALUE.messageID
    }

    def "test validateForCompleteIntake for CSP Facet member, outpatient Hsc with more than one services"() {
        given:
        long hscID = HSC_ID
        String serviceSettingType = CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT
        List hscServiceVOs = [new HscServiceVO(serviceSeqNum: 1, serviceProviderSeqNum: 1, procedureCode: '1'), new HscServiceVO(serviceSeqNum: 2, serviceProviderSeqNum: 1, procedureCode: '1')]
        ValueObject errorVO1 = new ValueObject()
        HscVO hscVO = new HscVO(hscID: hscID, subcategoryType: "9")
        MemberVO memberVO = new MemberVO(memberID: 123, origSystemMemberIDType: "AP")
        List subcategoryOPServiceLineList = ["1", "4", "3", "9"]
        hscVO.setServiceSettingType(serviceSettingType)
        hscVO.setHscID(hscID)
        QueryProperties qpAscFields = getValidationQueryProperties(false, QueryProperties.FilterType.LIST_ALL)
        QueryProperties qpDescFields = getValidationQueryProperties(true, QueryProperties.FilterType.LIST_ALL)

        when:
        ValueObject returnedErrorVO = hscService.validateForCompleteIntake(hscID, serviceSettingType)

        then:
        1 * hsc.read(hscID) >> hscVO
        with(dao) {
            1 * list(qpAscFields) >> hscServiceVOs
        }
        1 * hscServiceNonFacility.validateForCompleteIntake(hscID, hscServiceVOs[0].getServiceSeqNum(), hscServiceVOs[0].getProcCodeType(), hscServiceVOs[0].getProcedureCode()) >> errorVO1
        1 * hscServiceNonFacility.validateForCompleteIntake(hscID, hscServiceVOs[1].getServiceSeqNum(), hscServiceVOs[1].getProcCodeType(), hscServiceVOs[1].getProcedureCode()) >> errorVO1
        0 * _

        expect:
        returnedErrorVO.globalMessages.size() == 1
    }

    def "test validateForCompleteIntake for CSP Facet member, outpatient Hsc with one service, subCategoryType Hemodialysis with wrong procedure code"() {
        given:
        long hscID = 123
        String serviceSettingType = CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT
        List hscServiceVOs = [new HscServiceVO(serviceSeqNum: 1, serviceProviderSeqNum: 1, procedureCode: '1', procCodeType: "2")]
        ValueObject errorVO1 = new ValueObject()
        HscVO hscVO = new HscVO(hscID: hscID, subcategoryType: "9")
        MemberVO memberVO = new MemberVO(memberID: 123, origSystemMemberIDType: "AP")
        List subcategoryOPServiceLineList = ["1", "4", "3", "9"]
        hscVO.setServiceSettingType(serviceSettingType)
        hscVO.setHscID(hscID)

        when:
        ValueObject returnedErrorVO = hscService.validateForCompleteIntake(hscID, serviceSettingType)

        then:
        1 * hsc.read(hscID) >> hscVO
        1 * dao.list(_ as QueryProperties) >> hscServiceVOs
        1 * hscServiceNonFacility.validateForCompleteIntake(hscID, hscServiceVOs[0].getServiceSeqNum(), hscServiceVOs[0].getProcCodeType(), hscServiceVOs[0].getProcedureCode()) >> errorVO1
        0 * _
    }

    def "test validateForCompleteIntake, validations on PlaceOfService and serviceDetailType if subcatrgoryType Hemodialysis"() {
        given:
        long hscID = 123
        String serviceSettingType = CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT
        List hscServiceVOs = [new HscServiceVO(serviceSeqNum: 1, serviceProviderSeqNum: 1, procedureCode: '1', procCodeType: "2")]
        ValueObject errorVO1 = new ValueObject()
        HscVO hscVO = new HscVO(hscID: hscID, subcategoryType: "9")
        MemberVO memberVO = new MemberVO(memberID: 123, origSystemMemberIDType: "AP")
        List subcategoryOPServiceLineList = ["1", "4", "3", "9"]
        hscVO.setServiceSettingType(serviceSettingType)
        hscVO.setHscID(hscID)

        when:
        def returnedErrorVO = hscService.validateForCompleteIntake(hscID, serviceSettingType)

        then:
        1 * hsc.read(hscID) >> hscVO
        1 * dao.list(_ as QueryProperties) >> hscServiceVOs
        1 * hscServiceNonFacility.validateForCompleteIntake(hscID, hscServiceVOs[0].getServiceSeqNum(), hscServiceVOs[0].getProcCodeType(), hscServiceVOs[0].getProcedureCode()) >> errorVO1
        0 * _
    }

    def "test validateForCompleteIntake for CSP Facet member, outpatient Hsc with one service, subCategoryType Chemo with wrong procedure code"() {
        given:
        long hscID = 123
        String serviceSettingType = CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT
        List hscServiceVOs = [new HscServiceVO(serviceSeqNum: 1, serviceProviderSeqNum: 1, procedureCode: '1', procCodeType: "2")]
        ValueObject errorVO1 = new ValueObject()
        HscVO hscVO = new HscVO(hscID: hscID, subcategoryType: "1")
        MemberVO memberVO = new MemberVO(memberID: 123, origSystemMemberIDType: "AP")
        List subcategoryOPServiceLineList = ["1", "4", "3", "9"]
        hscVO.setServiceSettingType(serviceSettingType)
        hscVO.setHscID(hscID)
        when:
        ValueObject returnedErrorVO = hscService.validateForCompleteIntake(hscID, serviceSettingType)

        then:
        1 * hsc.read(hscID) >> hscVO
        1 * dao.list(_ as QueryProperties) >> hscServiceVOs
        1 * hscServiceNonFacility.validateForCompleteIntake(hscID, hscServiceVOs[0].getServiceSeqNum(), hscServiceVOs[0].getProcCodeType(), hscServiceVOs[0].getProcedureCode()) >> errorVO1
        0 * _
    }

    def "test validateForCompleteIntake for CSP Facet member, outpatient Facility Hsc with more than one services"() {
        given:
        long hscID = 123
        String serviceSettingType = CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY
        List hscServiceVOs = [new HscServiceVO(serviceSeqNum: 1, serviceProviderSeqNum: 1, procedureCode: '1'), new HscServiceVO(serviceSeqNum: 2, serviceProviderSeqNum: 1, procedureCode: '1')]
        ValueObject errorVO1 = new ValueObject()
        HscVO hscVO = new HscVO(hscID: hscID, subcategoryType: "1")
        MemberVO memberVO = new MemberVO(memberID: 123, origSystemMemberIDType: "AP")
        List subcategoryOPFServiceLineList = ["1", "4", "3", "29"]
        hscVO.setServiceSettingType(serviceSettingType)
        hscVO.setHscID(hscID)
        when:
        ValueObject returnedErrorVO = hscService.validateForCompleteIntake(hscID, serviceSettingType)

        then:
        1 * hsc.read(hscID) >> hscVO
        1 * dao.list(_ as QueryProperties) >> hscServiceVOs
        1 * hscServiceFacility.validateForCompleteIntake(hscID, hscServiceVOs[0].getServiceSeqNum(), serviceSettingType) >> errorVO1
        1 * hscServiceFacility.validateForCompleteIntake(hscID, hscServiceVOs[1].getServiceSeqNum(), serviceSettingType) >> errorVO1
        0 * _
    }

    def "test validateForCompleteIntake for CSP Facet member, outpatient Facility Hsc - one service with incorrect Procedure code "() {
        given:
        long hscID = 123
        String serviceSettingType = CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY
        List hscServiceVOs = [new HscServiceVO(serviceSeqNum: 1, serviceProviderSeqNum: 1, procedureCode: '1', procCodeType: "2")]
        ValueObject errorVO1 = new ValueObject()
        HscVO hscVO = new HscVO(hscID: hscID, subcategoryType: "1")
        MemberVO memberVO = new MemberVO(memberID: 123, origSystemMemberIDType: "AP")
        List subcategoryOPFServiceLineList = ["1", "4", "3", "29"]
        hscVO.setServiceSettingType(serviceSettingType)
        hscVO.setHscID(hscID)
        when:
        ValueObject returnedErrorVO = hscService.validateForCompleteIntake(hscID, serviceSettingType)

        then:
        1 * hsc.read(hscID) >> hscVO
        1 * dao.list(_ as QueryProperties) >> hscServiceVOs
        1 * hscServiceFacility.validateForCompleteIntake(hscID, hscServiceVOs[0].getServiceSeqNum(), serviceSettingType) >> errorVO1
        0 * _
    }

    def "saveHscServiceProviders: saving provider services when cleanup is true"() {
        given: "the service objects"
        // SERVICES
        HscServiceVO hscServiceVO = new HscServiceVO(
                hscID: HSC_ID,
                serviceSeqNum: SERVICE_SEQ_NUM,
                procedureCode: PROCEDURE_CODE,
                procCodeType: PROCCODETYPE,
                procedureOtherText: "procOtherTxt",
                hscServiceFacilityVO: new HscServiceFacilityVO(hscID: HSC_ID, serviceSeqNum: SERVICE_SEQ_NUM),
                serviceProviderSeqNum: SERVICE_PROD_SEQ_NUM,
                serviceReferenceNum: SERVICE_REF_NUM,
                serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT,
                hscServiceNonFacilityVO: new HscServiceNonFacilityVO(hscID: HSC_ID, serviceDetailType: "noBehavioral", serviceSeqNum: SERVICE_SEQ_NUM),
                hscServiceNonFacilityHistoryVO: new HscServiceNonFacilityHistoryVO(hscID: HSC_ID, serviceDetailType: "noBehavioral", serviceSeqNum: SERVICE_SEQ_NUM)
        )
        HscProviderVO servicingProviderVO = new HscProviderVO(hscID: HSC_ID, providerUpdated: false)
        HscProviderVO ssoProviderVO = new HscProviderVO(hscID: HSC_ID)
        HscVO hscVO = new HscVO(hscID: HSC_ID, memberID: MEMBER_ID, reviewPriorityType: "5", serviceCategoryType: HsrReferenceConstants.SERVICE_CATEGORY_BEHAVIORAL_TRANSITIONAL)
        ProcedureCodeVO procedureCodeVO = new ProcedureCodeVO(procedureCode: PROCEDURE_CODE, procedureCodeType: PROCCODETYPE)
        // TABLE DEFINITIONS
        LogicTypeFactory.putInstance(TableConstants.HSC_SRVC_FACL, hscServiceFacility as ReadLogic<? extends ValueObject>)
        LogicTypeFactory.putInstance(TableConstants.HSC_SRVC_NON_FACL, hscServiceNonFacility as ReadLogic<? extends ValueObject>)

        // QUERY PROPERTIES
        QueryProperties qp = getQueryProperties()
        QueryProperties providerQP = getProviderQueryProperties()
        QueryProperties serviceFacilityQP = getHscServiceFacilityQueryProperties()

        // READ PROPERTIES
        ReadProperties rpReadField = getHscReadProperties(FieldConstants.SERVICEPROVIDERSEQNUM)
        ReadProperties rpNoReadField = getHscReadProperties()

        when: "saving service providers"
        hscService.saveHscServiceProviders(hscServiceVO, servicingProviderVO, ssoProviderVO, hscVO, true)

        then: "read, validate and save provider services"
        with(dao) {
            2 * isDuplicate(qp) >> true
            1 * read(_) >> hscServiceVO
        }
        2 * hsc.readUnhydrated(HSC_ID) >> hscVO
        1 * hscServiceNonFacilitySchedule.deleteList(HSC_ID, SERVICE_SEQ_NUM)

        // save providers
        with(hscProvider) {
            1 * setNonPersistedRoles(servicingProviderVO)
            1 * setNonPersistedRoles(ssoProviderVO)
            1 * validate(servicingProviderVO)
            1 * validate(ssoProviderVO)
            1 * saveCascading(servicingProviderVO)
            1 * saveCascading(ssoProviderVO)
        }

        1 * hscServiceFacility.validate(hscServiceVO.hscServiceFacilityVO, _ as Boolean)
        1 * hscServiceLineProgramTypeHelper.getServiceReviewTypeCode(hscServiceVO) >> ""
        1 * persistenceHelper.update(hscServiceVO)
        2 * customerReference.isValid(FieldConstants.PROCCODETYPE, PROCCODETYPE) >> true

        // cascade update on hscServiceNonFacility
        1 * hscServiceNonFacility.tableDef >> TableDefFactory.getTableDef(HscServiceNonFacilityVO)
        1 * hscServiceNonFacility.list(providerQP) >> [new HscServiceNonFacilityVO(hscID: HSC_ID)]
        1 * hscServiceNonFacility.updateCascading(hscServiceVO.hscServiceNonFacilityVO)

        // cascade update on hscServiceFacility
        1 * hscServiceFacility.tableDef >> TableDefFactory.getTableDef(HscServiceFacilityVO)
        1 * hscServiceFacility.list(providerQP) >> [new HscServiceFacilityVO(hscID: HSC_ID)]
        1 * hscServiceFacility.updateCascading(hscServiceVO.hscServiceFacilityVO)

        1 * dao.list(serviceFacilityQP) >> [new HscServiceVO(hscID: HSC_ID, serviceSeqNum: 6 as short, procedureCode: PROCEDURE_CODE, procCodeType: PROCCODETYPE)]
        1 * hscServiceNonFacility.read(HSC_ID, 6) >> new HscServiceNonFacilityVO(hscID: HSC_ID, notifyRetrospectiveInd: true)
        1 * hscServiceNonFacilityHistory.readListCustom(1, 6)
        1 * hcpcs.read(PROCEDURE_CODE) >> new HcpcsVO()
        1 * hsc.read(hscServiceVO.hscID) >> hscVO
        1 * hscServiceNonFacility.getOutpatientPrimaryService(hscVO.hscID) >> new HscServiceNonFacilityVO(hscID: HSC_ID, serviceSeqNum: SERVICE_SEQ_NUM)

        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_HSC_SERVICE_DETAIL_UPDATES) >> featureFlag
        if (featureFlag) {
            1 * hscServiceDetail.read(_,_) >> new HscServiceDetailVO(hscID: HSC_ID)
        }
        0 * _

        where:
        featureFlag << [false, true]
    }

    def "saveHscServiceProviders: when cleanup is false and retrospective false"() {
        given: "the service objects"
        // SERVICES
        HscServiceVO hscServiceVO = new HscServiceVO(
                hscID: HSC_ID,
                serviceSeqNum: SERVICE_SEQ_NUM,
                procedureCode: PROCEDURE_CODE,
                procCodeType: PROCCODETYPE,
                procedureOtherText: "procOtherTxt",
                hscServiceFacilityVO: new HscServiceFacilityVO(hscID: HSC_ID, serviceSeqNum: SERVICE_SEQ_NUM),
                serviceProviderSeqNum: SERVICE_PROD_SEQ_NUM,
                serviceReferenceNum: SERVICE_REF_NUM,
                serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT,
                hscServiceNonFacilityVO: new HscServiceNonFacilityVO(hscID: HSC_ID, serviceDetailType: "noBehavioral", serviceSeqNum: SERVICE_SEQ_NUM)
        )
        HscProviderVO servicingProviderVO = new HscProviderVO(hscID: HSC_ID, providerUpdated: false)
        HscProviderVO ssoProviderVO = new HscProviderVO(hscID: HSC_ID)
        HscVO hscVO = new HscVO(hscID: HSC_ID, memberID: MEMBER_ID, reviewPriorityType: "5", serviceCategoryType: HsrReferenceConstants.SERVICE_CATEGORY_BEHAVIORAL_TRANSITIONAL)
        ProcedureCodeVO procedureCodeVO = new ProcedureCodeVO(procedureCode: PROCEDURE_CODE, procedureCodeType: PROCCODETYPE)
        // TABLE DEFINITIONS
        LogicTypeFactory.putInstance(TableConstants.HSC_SRVC_FACL, hscServiceFacility as ReadLogic<? extends ValueObject>)
        LogicTypeFactory.putInstance(TableConstants.HSC_SRVC_NON_FACL, hscServiceNonFacility as ReadLogic<? extends ValueObject>)

        // QUERY PROPERTIES
        QueryProperties qp = getQueryProperties()
        QueryProperties providerQP = getProviderQueryProperties()
        QueryProperties serviceFacilityQP = getHscServiceFacilityQueryProperties()

        // READ PROPERTIES
        ReadProperties rpReadField = getHscReadProperties(FieldConstants.SERVICEPROVIDERSEQNUM)
        ReadProperties rpNoReadField = getHscReadProperties()

        when: "saving service providers"
        hscService.saveHscServiceProviders(hscServiceVO, servicingProviderVO, ssoProviderVO, hscVO, false)

        then: "read, validate and save provider services"
        with(dao) {
            2 * isDuplicate(qp) >> true
        }
        2 * hsc.readUnhydrated(HSC_ID) >> hscVO
        1 * hscServiceNonFacilitySchedule.deleteList(HSC_ID, SERVICE_SEQ_NUM)

        // save providers
        with(hscProvider) {
            1 * setNonPersistedRoles(servicingProviderVO)
            1 * setNonPersistedRoles(ssoProviderVO)
            1 * validate(servicingProviderVO)
            1 * validate(ssoProviderVO)
            1 * saveCascading(servicingProviderVO)
            1 * saveCascading(ssoProviderVO)
        }

        1 * hscServiceFacility.validate(hscServiceVO.hscServiceFacilityVO, _ as Boolean)
        2 * customerReference.isValid(FieldConstants.PROCCODETYPE, PROCCODETYPE) >> true
        0 * _

        and: "an exception should be thrown and message added to field in vo"
        thrown(UhgRuntimeException)
    }

    def "isServiceAndProvidersValid: validate provider services when update is true"() {
        given:
        HscServiceVO hscServiceVO = getValidHscServiceVO()
        hscServiceVO.hscServiceFacilityVO = new HscServiceFacilityVO(hscID: HSC_ID, serviceSeqNum: SERVICE_SEQ_NUM)
        HscProviderVO servicingProviderVO = new HscProviderVO(hscID: HSC_ID, providerUpdated: false)
        HscProviderVO ssoProviderVO = new HscProviderVO(hscID: HSC_ID)
        HscVO hscVO = new HscVO(hscID: HSC_ID, memberID: MEMBER_ID)
        ProcedureCodeVO procedureCodeVO = new ProcedureCodeVO(procedureCode: PROCEDURE_CODE, procedureCodeType: PROCCODETYPE)
        Boolean isUpdate = true

        when:
        Boolean isValid = hscService.isServiceAndProvidersValid(hscServiceVO, servicingProviderVO, ssoProviderVO, isUpdate)

        then:
        1 * hsc.readUnhydrated(HSC_ID, []) >> hscVO
        1 * customerReference.isValid(FieldConstants.PROCCODETYPE, PROCCODETYPE) >> true
        1 * hscServiceFacility.validate(hscServiceVO.hscServiceFacilityVO, isUpdate)

        // validate hscProvider
        with(hscProvider) {
            1 * validate(servicingProviderVO)
            1 * validate(ssoProviderVO)
        }
        0 * _

        expect:
        isValid
    }

    def "isServiceAndProvidersValid: validate provider services when update is false"() {
        given:
        HscServiceVO hscServiceVO = getValidHscServiceVO()
        hscServiceVO.hscServiceNonFacilityVO = new HscServiceNonFacilityVO(serviceSeqNum: SERVICE_SEQ_NUM)
        HscProviderVO servicingProviderVO = new HscProviderVO(hscID: HSC_ID, providerUpdated: false)
        HscProviderVO ssoProviderVO = new HscProviderVO(hscID: HSC_ID)
        HscVO hscVO = new HscVO(hscID: HSC_ID, memberID: MEMBER_ID)
        ProcedureCodeVO procedureCodeVO = new ProcedureCodeVO(procedureCode: PROCEDURE_CODE, procedureCodeType: PROCCODETYPE)
        Boolean isUpdate = false
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        qp.addQueryFilter(new QueryFilter(FieldConstants.HSCID, HSC_ID))
        qp.setOrderByDescFields(FieldConstants.SERVICESEQNUM)


        when:
        Boolean isValid = hscService.isServiceAndProvidersValid(hscServiceVO, servicingProviderVO, ssoProviderVO, isUpdate)

        then:
        1 * hsc.readUnhydrated(hscServiceVO.hscID, []) >> hscVO
        1 * customerReference.isValid(FieldConstants.PROCCODETYPE, PROCCODETYPE) >> false
        1 * dao.list(qp) >> [new HscServiceVO()]
        with(hscServiceNonFacility) {
            1 * setNotificationRetrospectiveIndicator(hscServiceVO.hscServiceNonFacilityVO)
            1 * validate(hscServiceVO.hscServiceNonFacilityVO, isUpdate)
            1 * validateProcTypeUOMCombination(hscServiceVO.getHscServiceNonFacilityVO(), hscServiceVO.getProcCodeType(), hscServiceVO.getProcedureCode())
        }

        // validate hscProvider services
        with(hscProvider) {
            1 * validate(servicingProviderVO)
            1 * validate(ssoProviderVO)
        }
        0 * _

        expect:
        !isValid
    }

    def "deleteServicesForHsc: delete all services by hsc_id"() {
        given:
        ReadProperties rp = new ReadProperties(FieldConstants.HSCID)
        rp.setKeyValue(FieldConstants.HSCID, HSC_ID)

        when:
        hscService.deleteServicesForHsc(HSC_ID)

        then:
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_HSC_SERVICE_DETAIL_UPDATES) >> true
        1 * temporarySystemSetting.getStringSetting('logHscServiceAdds') >> 'no'
        1 * persistenceHelper.deleteCascading(rp, HscServiceImpl.CASCADE_DELETE_TABLES_WITH_SRVC_DTL)
        0 * _

    }

    def "deleteServicesForHsc: delete all services by hsc_id with logging"() {
        given:
        ReadProperties rp = new ReadProperties(FieldConstants.HSCID)
        rp.setKeyValue(FieldConstants.HSCID, HSC_ID)

        when:
        hscService.deleteServicesForHsc(HSC_ID)

        then:
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_HSC_SERVICE_DETAIL_UPDATES) >> true
        1 * temporarySystemSetting.getStringSetting('logHscServiceAdds') >> 'yes'
        1 * hsc.read(HSC_ID) >> new HscVO (authTypeID:  SpclCareReferenceConstants.AUTH_TYPE_SPECIALTY_PHARMACY)
        1 * persistenceHelper.deleteCascading(rp, HscServiceImpl.CASCADE_DELETE_TABLES_WITH_SRVC_DTL)
        0 * _

    }

    def "beforeDelete: test with logging"() {
        given:
        HscServiceVO vo = new HscServiceVO(hscID: HSC_ID)

        when:
        hscService.beforeDelete(vo)

        then:
        1 * temporarySystemSetting.getStringSetting('logHscServiceAdds') >> 'yes'
        1 * hsc.read(vo.hscID) >> new HscVO (authTypeID:  SpclCareReferenceConstants.AUTH_TYPE_SPECIALTY_PHARMACY)
        0 * _

    }


    def "isValid"() {
        given:
        ReadProperties rp = getHscReadProperties()

        when:
        Boolean valid = hscService.isValid(HSC_ID, SERVICE_SEQ_NUM)

        then:
        1 * dao.isValid(rp) >> true
        0 * _

        expect:
        valid
    }

    def "readByServiceReferenceNumber"() {
        given:
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        qp.addQueryFilter(new QueryFilter(FieldConstants.SERVICEREFERENCENUM, SERVICE_REF_NUM))
        qp.setFilterType(QueryProperties.FilterType.NEW_FILTER)
        qp.setResultSize(1)

        when:
        HscServiceVO hscServiceVO = hscService.readByServiceReferenceNumber(SERVICE_REF_NUM)

        then:
        1 * dao.list(qp) >> [new HscServiceVO(serviceReferenceNum: SERVICE_REF_NUM)]
        0 * _

        expect:
        hscServiceVO.serviceReferenceNum == SERVICE_REF_NUM
    }

    def "setServiceLineLock: update service if lock required"() {
        given:
        ReadProperties rp = getHscReadProperties()
        HscServiceVO hscServiceVO = getValidHscServiceVO()
        hscServiceVO.hscServiceLockType = "1"
        hscServiceVO.procedureCode = PROCEDURE_CODE
        ProcedureCodeVO procedureCodeVO = new ProcedureCodeVO(procedureCode: PROCEDURE_CODE, procedureCodeType: PROCCODETYPE)
        when:
        hscService.setServiceLineLock(HSC_ID, SERVICE_SEQ_NUM, "1")

        then:
        2 * dao.read(rp) >> hscServiceVO
        1 * hsc.readUnhydrated(HSC_ID, []) >> new HscVO(hscID: HSC_ID, memberID: MEMBER_ID)
        1 * customerReference.isValid(FieldConstants.PROCCODETYPE, PROCCODETYPE) >> true
        1 * hscServiceLineProgramTypeHelper.getServiceReviewTypeCode(hscServiceVO)
        1 * persistenceHelper.update(hscServiceVO)
        0 * _
    }

    def "readCascading"() {
        given:
        ReadProperties rp = getHscReadProperties()
        QueryProperties qp = getQueryProperties()
        qp.setFilterType(QueryProperties.FilterType.LIST_ALL)
        HscServiceVO hscServiceVO = getValidHscServiceVO()

        // TABLE DEFINITION(S)
        LogicTypeFactory.putInstance(TableConstants.HSC_SRVC_NON_FACL, hscServiceNonFacility as ReadLogic<? extends ValueObject>)
        LogicTypeFactory.putInstance(TableConstants.HSC_SRVC_FACL, hscServiceFacility as ReadLogic<? extends ValueObject>)
        LogicTypeFactory.putInstance(TableConstants.HSC_SRVC_DECN, hscServiceDecision as ReadLogic<? extends ValueObject>)
        LogicTypeFactory.putInstance(TableConstants.HSC_SRVC_NON_FACL_SCHED, hscServiceNonFacilitySchedule as ReadLogic<? extends ValueObject>)
        LogicTypeFactory.putInstance(TableConstants.HSC_SRVC_DTL, hscServiceDetail as ReadLogic<? extends ValueObject>)

        when:
        HscServiceVO hscServiceVO1 = hscService.readCascading(HSC_ID, SERVICE_SEQ_NUM)

        then:
        1 * dao.read(rp) >> new HscServiceVO(hscID: HSC_ID, serviceSeqNum: SERVICE_SEQ_NUM, hscServiceNonFacilityVO: new HscServiceNonFacilityVO(hscID: HSC_ID, serviceSeqNum: SERVICE_SEQ_NUM))
        1 * hscServiceNonFacility.getTableDef() >> TableDefFactory.getTableDef(HscServiceNonFacilityVO)
        1 * hscServiceNonFacility.list(qp) >> [new HscServiceNonFacilityVO(hscID: HSC_ID, serviceSeqNum: SERVICE_SEQ_NUM)]
        1 * hscServiceFacility.getTableDef() >> TableDefFactory.getTableDef(HscServiceFacilityVO)
        1 * hscServiceFacility.list(qp) >> [new HscServiceFacilityVO()]
        1 * hscServiceDecision.getTableDef() >> TableDefFactory.getTableDef(HscServiceDecisionVO)
        1 * hscServiceDecision.list(qp) >> [new HscServiceDecisionVO()]
        1 * hscServiceNonFacilitySchedule.getTableDef() >> TableDefFactory.getTableDef(HscServiceNonFacilityScheduleVO)
        1 * hscServiceNonFacilitySchedule.list(qp) >> [new HscServiceNonFacilityScheduleVO(hscID: HSC_ID, serviceSeqNum: SERVICE_SEQ_NUM)]
        1 * hscServiceDetail.getTableDef() >> TableDefFactory.getTableDef(HscServiceDetailVO)
        1 * hscServiceDetail.list(qp) >> [new HscServiceDetailVO(hscID: HSC_ID, serviceSeqNum: SERVICE_SEQ_NUM)]

        0 * _

        expect:
        hscServiceVO1.hscID == HSC_ID
        hscServiceVO1.serviceSeqNum == SERVICE_SEQ_NUM
        hscServiceVO1.hscServiceNonFacilityVO.hscID == HSC_ID
        hscServiceVO1.hscServiceNonFacilityVO.serviceSeqNum == SERVICE_SEQ_NUM
    }

    def "deleteCascading"() {
        given:
        ReadProperties rp = new ReadProperties([FieldConstants.HSCID, FieldConstants.SERVICESEQNUM] as String[])
        rp.setKeyValue(FieldConstants.HSCID, HSC_ID)
        rp.setKeyValue(FieldConstants.SERVICESEQNUM, SERVICE_SEQ_NUM)

        when:
        hscService.deleteCascading(HSC_ID, SERVICE_SEQ_NUM)

        then:
        1 * persistenceHelper.deleteCascading(rp, hscService.CASCADE_DELETE_TABLES)
        0 * _
    }

    def "readFirstHscServiceVO"() {
        given:
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.NEW_FILTER)
        qp.addQueryFilter(new QueryFilter(FieldConstants.HSCID, HSC_ID))
        qp.setOrderByAscFields(FieldConstants.SERVICESEQNUM)
        qp.setResultSize(1)

        when:
        HscServiceVO hscServiceVO = hscService.readFirstHscServiceVO(HSC_ID)

        then:
        1 * dao.list(qp) >> [new HscServiceVO(hscID: HSC_ID)]
        0 * _

        expect:
        hscServiceVO.hscID == HSC_ID
    }

    def "readLatestHscServiceVO"() {
        given:
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.NEW_FILTER)
        qp.addQueryFilter(new QueryFilter(FieldConstants.HSCID, HSC_ID))
        qp.setOrderByDescFields(FieldConstants.SERVICESEQNUM)
        qp.setResultSize(1)

        when:
        HscServiceVO hscServiceVO = hscService.readLatestHscServiceVO(HSC_ID)

        then:
        1 * dao.list(qp) >> [new HscServiceVO(hscID: HSC_ID)]
        0 * _

        expect:
        hscServiceVO.hscID == HSC_ID
    }

    def "readFirstNonFullLockHscServiceVO"() {
        given:
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.NEW_FILTER)
        qp.addQueryFilter(new QueryFilter(FieldConstants.HSCID, HSC_ID))
        qp.addQueryFilter(new QueryFilter(FieldConstants.HSCSERVICELOCKTYPE, HsrReferenceConstants.HSCSERVICELOCKTYPE_FULL_LOCK, QueryCriteria.NOT_EQUAL))
        qp.setOrderByAscFields(FieldConstants.SERVICESEQNUM)
        qp.setResultSize(1)

        when:
        HscServiceVO hscServiceVO = hscService.readFirstNonFullLockHscServiceVO(HSC_ID)

        then:
        1 * dao.list(qp) >> [new HscServiceVO(hscServiceLockType: HsrReferenceConstants.HSCSERVICELOCKTYPE_FULL_LOCK)]
        0 * _

        expect:
        hscServiceVO.hscServiceLockType == HsrReferenceConstants.HSCSERVICELOCKTYPE_FULL_LOCK
    }

    def "validate: when hscVO is Out Patient and this is an update"() {
        given:
        HscServiceVO hscServiceVO = getValidHscServiceVO()
        hscServiceVO.setServiceProviderSeqNum(0 as short)
        hscServiceVO.providerAssociated = true
        HscProviderVO hscProviderVO = new HscProviderVO(hscID: HSC_ID)
        HscVO hscVO = new HscVO(hscID: HSC_ID, memberID: MEMBER_ID, hscStatusType: HsrReferenceConstants.HSCSTATUSTYPE_OPEN, serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT)
        MemberVO memberVO = new MemberVO(origSystemMemberIDType: HsrReferenceConstants.ORIGSYSTEMMEMBERIDTYPE_AP)
        ProcedureCodeVO procedureCodeVO = new ProcedureCodeVO(procedureCode: PROCEDURE_CODE, procedureCodeType: PROCCODETYPE)
        // QUERY PROPERTIES
        QueryProperties qp = getValidationQueryProperties(true, QueryProperties.FilterType.LIST_ALL)

        when:
        hscService.validate(hscServiceVO, true)

        then:
        1 * hsc.readUnhydrated(hscServiceVO.hscID) >> hscVO
        1 * customerReference.isValid(FieldConstants.PROCCODETYPE, PROCCODETYPE)
        0 * _
    }

    def "validate: when hscVO is Out Patient Facility and this is an update"() {
        given:
        HscServiceVO hscServiceVO = getValidHscServiceVO()
        hscServiceVO.providerAssociated = true
        HscProviderVO hscProviderVO = new HscProviderVO(hscID: HSC_ID)
        HscVO hscVO = new HscVO(hscID: HSC_ID, memberID: MEMBER_ID, hscStatusType: HsrReferenceConstants.HSCSTATUSTYPE_OPEN, serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY)
        MemberVO memberVO = new MemberVO(memberID: MEMBER_ID, origSystemMemberIDType: HsrReferenceConstants.ORIGSYSTEMMEMBERIDTYPE_AP)
        ProcedureCodeVO procedureCodeVO = new ProcedureCodeVO(procedureCode: PROCEDURE_CODE, procedureCodeType: PROCCODETYPE)
        // QUERY PROPERTIES
        QueryProperties qp = getValidationQueryProperties(true, QueryProperties.FilterType.LIST_ALL)

        when:
        hscService.validate(hscServiceVO, true)

        then:
        1 * hsc.readUnhydrated(hscServiceVO.hscID) >> hscVO
        1 * customerReference.isValid(FieldConstants.PROCCODETYPE, PROCCODETYPE)
        0 * _
    }

    def "validateFacilityProvider: is an update and provider is facility"() {
        given:
        HscServiceVO hscServiceVO = getValidHscServiceVO()
        hscServiceVO.facilityProviderRequiresConfirmation = true
        HscProviderVO hscProviderVO = new HscProviderVO(facilityProviderInd: true)
        HscServiceVO previousServiceVO = new HscServiceVO(hscID: 2, serviceProviderSeqNum: PROVIDER_SEQ_NUM)
        previousServiceVO.facilityProviderRequiresConfirmation = true
        HscProviderVO secondProviderVO = new HscProviderVO(hscID: 2, facilityProviderInd: true)
        ReadProperties readProperties = getHscReadProperties()

        when:
        hscService.validateFacilityProvider(hscServiceVO, true)

        then:
        with(hscProvider) {
            1 * read(hscServiceVO.hscID, hscServiceVO.serviceProviderSeqNum) >> hscProviderVO
            1 * setNonPersistedRoles(hscProviderVO)
            1 * read(previousServiceVO.hscID, PROVIDER_SEQ_NUM) >> secondProviderVO
            1 * setNonPersistedRoles(secondProviderVO)
        }
        1 * dao.read(readProperties) >> previousServiceVO
        0 * _

        expect:
        !hscServiceVO.globalMessages
    }

    def "validateFacilityProvider: is an update and provider is not a facility"() {
        given:
        HscServiceVO hscServiceVO = getValidHscServiceVO()
        hscServiceVO.facilityProviderRequiresConfirmation = true
        HscProviderVO hscProviderVO = new HscProviderVO(hscID: HSC_ID, facilityProviderInd: true)
        HscServiceVO previousServiceVO = new HscServiceVO(hscID: 2, serviceProviderSeqNum: PROVIDER_SEQ_NUM)
        previousServiceVO.facilityProviderRequiresConfirmation = true
        HscProviderVO secondProviderVO = new HscProviderVO(hscID: 2, facilityProviderInd: false)

        ReadProperties readProperties = getHscReadProperties()

        when:
        hscService.validateFacilityProvider(hscServiceVO, true)

        then:
        with(hscProvider) {
            1 * read(hscServiceVO.hscID, hscServiceVO.serviceProviderSeqNum) >> hscProviderVO
            1 * setNonPersistedRoles(hscProviderVO)
            1 * read(previousServiceVO.hscID, PROVIDER_SEQ_NUM) >> secondProviderVO
            1 * setNonPersistedRoles(secondProviderVO)
        }
        1 * dao.read(readProperties) >> previousServiceVO
        0 * _

        expect:
        hscServiceVO.globalMessages.size() == 1
        hscServiceVO.globalMessages.first().messageID == HscMessages.CONF_FACILITY_PROVIDER_FOR_SERVICE.messageID
    }

    def "validateFacilityProvider: is not an update and provider is a facility"() {
        given:
        HscServiceVO hscServiceVO = getValidHscServiceVO()
        hscServiceVO.facilityProviderRequiresConfirmation = true
        HscProviderVO hscProviderVO = new HscProviderVO(hscID: HSC_ID, facilityProviderInd: true)
        HscServiceVO previousServiceVO = new HscServiceVO(hscID: 2, serviceProviderSeqNum: SERVICE_PROD_SEQ_NUM)
        previousServiceVO.facilityProviderRequiresConfirmation = true
        HscProviderVO secondProviderVO = new HscProviderVO(hscID: 2, facilityProviderInd: true)

        ReadProperties readProperties = getHscReadProperties()

        when:
        hscService.validateFacilityProvider(hscServiceVO, false)

        then:
        with(hscProvider) {
            1 * read(hscServiceVO.hscID, hscServiceVO.serviceProviderSeqNum) >> hscProviderVO
            1 * setNonPersistedRoles(hscProviderVO)
        }
        0 * _

        expect:
        hscServiceVO.globalMessages.first().messageID == HscMessages.CONF_FACILITY_PROVIDER_FOR_SERVICE.messageID
    }

    def "validateFacilityProvider: is not an update and provider is not a facility"() {
        given:
        HscServiceVO hscServiceVO = getValidHscServiceVO()
        hscServiceVO.facilityProviderRequiresConfirmation = true
        HscProviderVO hscProviderVO = new HscProviderVO(hscID: HSC_ID, facilityProviderInd: true)
        HscServiceVO previousServiceVO = new HscServiceVO(hscID: 2, serviceProviderSeqNum: SERVICE_PROD_SEQ_NUM)
        previousServiceVO.facilityProviderRequiresConfirmation = true
        HscProviderVO secondProviderVO = new HscProviderVO(hscID: 2, facilityProviderInd: false)

        ReadProperties readProperties = getHscReadProperties()

        when:
        hscService.validateFacilityProvider(hscServiceVO, false)

        then:
        with(hscProvider) {
            1 * read(hscServiceVO.hscID, hscServiceVO.serviceProviderSeqNum) >> hscProviderVO
            1 * setNonPersistedRoles(hscProviderVO)
        }
        0 * _

        expect:
        hscServiceVO.globalMessages.first().messageID == HscMessages.CONF_FACILITY_PROVIDER_FOR_SERVICE.messageID
    }

    def "add: no cascade"() {
        given:
        HscServiceVO hscServiceVO = getValidHscServiceVO()
        hscServiceVO.procedureOtherText = "otherText"
        hscServiceVO.hscServiceDecisionVOs = [new HscServiceDecisionVO(hscServiceDecisionSourceVOs: [new HscServiceDecisionSourceVO()])]
        HscVO hscVO = new HscVO(hscID: HSC_ID, memberID: MEMBER_ID)
        MemberVO memberVO = new MemberVO()
        ProcedureCodeVO procedureCodeVO = new ProcedureCodeVO(procedureCode: PROCEDURE_CODE, procedureCodeType: PROCCODETYPE)
        // QUERY PROPERTIES
        QueryProperties qp = getValidationQueryProperties(true, QueryProperties.FilterType.LIST_ALL)

        // TABLE DEFINTITION(S)
        LogicTypeFactory.putInstance(TableConstants.HSC_SRVC_DECN, hscServiceDecision as ReadLogic<? extends ValueObject>)

        when:
        hscService.add(hscServiceVO, false)

        then:
        1 * hsc.readUnhydrated(hscServiceVO.hscID) >> hscVO
        1 * customerReference.isValid(FieldConstants.PROCCODETYPE, PROCCODETYPE) >> true
//        1 * procedureCode.getProcedureCode(PROCCODETYPE, PROCEDURE_CODE) >> procedureCodeVO
        1 * dao.list(qp) >> [new HscServiceVO(hscID: 2), new HscServiceDecisionVO()]
        1 * hscServiceLineProgramTypeHelper.getServiceReviewTypeCode(hscServiceVO)
        1 * persistenceHelper.add(hscServiceVO)
        2 * temporarySystemSetting.getStringSetting('logHscServiceAdds')
        0 * _

        expect:
        !hscServiceVO.errorMessagesExist()
        hscServiceVO.globalMessages.size() == 1 && hscServiceVO.globalMessages.first().messageID == 'STS0001'
    }

    @Unroll()
    def "update: with cascade set to #cascade"() {
        given:
        ProcedureCodeVO procedureCodeVO = new ProcedureCodeVO(procedureCode: PROCEDURE_CODE, procedureCodeType: PROCCODETYPE)
        HscServiceVO hscServiceVO = getValidHscServiceVO()
        HscVO hscVO = new HscVO(hscID: HSC_ID, memberID: MEMBER_ID)
        MemberVO memberVO = new MemberVO()

        // READ PROPERTIES
        ReadProperties rp = getHscReadProperties()

        when:
        hscService.update(hscServiceVO, cascade)

        then:
        1 * hsc.readUnhydrated(hscServiceVO.hscID) >> hscVO
        1 * customerReference.isValid(FieldConstants.PROCCODETYPE, PROCCODETYPE) >> true
        1 * dao.read(rp) >> hscServiceVO
        1 * hscServiceLineProgramTypeHelper.getServiceReviewTypeCode(hscServiceVO) >> "serviceReview"
        1 * persistenceHelper.update(hscServiceVO)
        0 * _

        expect:
        !hscServiceVO.errorMessagesExist()
        hscServiceVO.globalMessages.size() == 1 && hscServiceVO.globalMessages.first().messageID == 'STS0003'

        where:
        cascade << [true, false]
    }

    def "validateMaxServiceLines: when update is true"() {
        given:
        HscServiceVO hscServiceVO = getValidHscServiceVO()
        HscVO hscVO = new HscVO(hscID: HSC_ID)

        when:
        hscService.validateMaxServiceLines(hscServiceVO, true, hscVO)

        then:
        0 * _

        expect:
        !hscServiceVO.errorMessagesExist()
        !hscServiceVO.globalMessages
    }

    def "validateMaxServiceLines: when update is false"() {
        given:
        HscServiceVO hscServiceVO = getValidHscServiceVO()
        HscVO hscVO = new HscVO(hscID: HSC_ID, specialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_PACIFICARE, serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT)
        // list that exceeds max lines of service
        List<HscServiceVO> vos = []
        HscConstants.MAX_PHS_FAC_SERVICE_LINES.times { vos << new HscServiceVO(hscID: it + 1) }

        // QUERY PROPERTIES
        QueryProperties qp = getValidationQueryProperties(true, QueryProperties.FilterType.LIST_ALL)

        when:
        hscService.validateMaxServiceLines(hscServiceVO, false, hscVO)

        then:
        1 * dao.list(qp) >> vos
        0 * _

        expect:
        hscServiceVO.globalMessages.size() == 1 && hscServiceVO.globalMessages.first().messageID == HscMessages.ERR_MAX_SERVICES_REACHED.messageID
    }

    @Unroll()
    def "validateForCompleteIntake: #condition"() {
        given:
        String serviceSettingType = CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT
        HscVO hscVO = new HscVO(hscID: HSC_ID, serviceSettingType: serviceSettingType, memberID: MEMBER_ID)
        HscServiceVO hscServiceVO = new HscServiceVO(hscID: HSC_ID, serviceSeqNum: SERVICE_SEQ_NUM, procedureCode: PROCEDURE_CODE, procCodeType: PROCCODETYPE, *: properties)

        // QUERY PROPERTIES
        QueryProperties qp = getValidationQueryProperties(false, QueryProperties.FilterType.LIST_ALL)

        when:
        ValueObject vo = hscService.validateForCompleteIntake(HSC_ID, serviceSettingType)

        then:
        1 * dao.list(qp) >> [hscServiceVO]
        1 * hsc.read(HSC_ID) >> hscVO
        1 * hscServiceNonFacility.validateForCompleteIntake(HSC_ID, hscServiceVO.serviceSeqNum, hscServiceVO.procCodeType, hscServiceVO.procedureCode) >> new HscServiceNonFacilityVO(hscID: HSC_ID, serviceSeqNum: SERVICE_SEQ_NUM)
        0 * _

        where:
        condition                                                     | properties                                                               | globalMessage                                                                                                                                                                          | messageSize
        "Service Provider valid"                                      | [serviceProviderSeqNum: SERVICE_PROD_SEQ_NUM]                            | [HscDecisionMessages.WRN_MSGID_PROVCAT_MUST_FAC_ASSTION_SLPSTD_PROC]                                                                                                                   | 1
        "Service Provider Sequence Number less than or equal to zero" | [serviceProviderSeqNum: 0]                                               | [HscMessages.ERR_MSGID_SERVICE_PROVIDER_REQUIRED, HscDecisionMessages.WRN_MSGID_PROVCAT_MUST_FAC_ASSTION_SLPSTD_PROC]                                                                  | 2
        "No service procedure code & procedure other text"            | [procedureCode: null, procedureOtherText: null]                          | [HscMessages.ERR_MSGID_SERVICE_PROVIDER_REQUIRED, HscMessages.ERR_MSGID_PROCEDURE_REQUIRED, HscDecisionMessages.WRN_MSGID_PROVCAT_MUST_FAC_ASSTION_SLPSTD_PROC]                        | 3
        "Service locktype full lock"                                  | [hscServiceLockType: HsrReferenceConstants.HSCSERVICELOCKTYPE_FULL_LOCK] | [HscMessages.ERR_ONE_PRIMARY_PROCEDURE_RECORD_REQUIRED.messageID, HscMessages.ERR_MSGID_SERVICE_PROVIDER_REQUIRED, HscDecisionMessages.WRN_MSGID_PROVCAT_MUST_FAC_ASSTION_SLPSTD_PROC] | 3
    }

    def "Test validateProcedureTypeCode"() {
        given:
        HscServiceVO vo = new HscServiceVO(procedureCode: PROCEDURE_CODE, procCodeType: PROCCODETYPE, procedureOtherText: "")
        ProcedureCodeVO procedureCodeVO = new ProcedureCodeVO(procedureCode: PROCEDURE_CODE, procedureCodeType: PROCCODETYPE)
        when:
        hscService.validateProcedureTypeCode(vo)
        then:
        1 * customerReference.isValid(FieldConstants.PROCCODETYPE, PROCCODETYPE) >> false
        0 * _
    }

    def "Test validateProcedureTypeCode Inactive"() {
        given:
        HscServiceVO vo = new HscServiceVO(procedureCode: PROCEDURE_CODE, procCodeType: PROCCODETYPE, procedureOtherText: "", isFromIntake: true)
        ProcedureCodeVO procedureCodeVO = new ProcedureCodeVO(procedureCode: PROCEDURE_CODE, procedureCodeType: PROCCODETYPE, codeStatusType: "1")
        when:
        hscService.validateProcedureTypeCode(vo)
        then:
        1 * customerReference.isValid(FieldConstants.PROCCODETYPE, PROCCODETYPE) >> false
        0 * _
    }

    @Unroll
    def "Test allServiceLinesHaveProcedureCodes where hscServiceList has a size of #list.size()"() {
        given:
        QueryProperties qp1 = new QueryProperties(QueryProperties.FilterType.LIST_ALL, new QueryFilter(FieldConstants.HSCID, HSC_ID))
        qp1.setOrderByAscFields(FieldConstants.SERVICESEQNUM)

        when:
        boolean gotProcedureCodes = hscService.allServiceLinesHaveProcedureCodes(HSC_ID, HsrReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT)
        then:
        1 * dao.list(qp1) >> list
        0 * _

        where:
        list << [new ArrayList<HscServiceVO>(), Arrays.asList(new HscServiceVO())]
    }

    def "Test isDuplicateServiceRefNum"() {
        given:
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL, new QueryFilter(FieldConstants.SERVICEREFERENCENUM, 1 as long))
        when:
        boolean isDuplicate = hscService.isDuplicateServiceRefNum(1 as long)
        then:
        isDuplicate
        1 * dao.isDuplicate(qp) >> true
        0 * _
    }

    def "Test deleteService"() {
        given:
        QueryProperties qp1 = new QueryProperties(QueryProperties.FilterType.LIST_ALL, new QueryFilter(FieldConstants.HSCID, HSC_ID))
        qp1.setOrderByDescFields(FieldConstants.SERVICESEQNUM)
        QueryProperties qp2 = new QueryProperties(QueryProperties.FilterType.NEW_FILTER, new QueryFilter(FieldConstants.HSCID, HSC_ID), new QueryFilter(FieldConstants.HSCSERVICELOCKTYPE, HsrReferenceConstants.HSCSERVICELOCKTYPE_FULL_LOCK, QueryCriteria.NOT_EQUAL))
        qp2.setOrderByAscFields(FieldConstants.SERVICESEQNUM)
        qp2.resultSize = 1

        when:
        HscServiceVO vo = hscService.deleteService(HSC_ID, SERVICE_SEQ_NUM, HsrReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT)
        then:
        vo
        1 * dao.list(qp1) >> Arrays.asList(new HscServiceVO())
        1 * persistenceHelper.deleteCascading(getHscReadProperties(), hscService.CASCADE_DELETE_TABLES)
        1 * dao.list(qp2) >> Arrays.asList(new HscServiceVO(serviceSeqNum: SERVICE_SEQ_NUM + 1))
        0 * _
    }

    def "Test deleteService with a hscServiceLockType"() {
        given:
        QueryProperties qp1 = new QueryProperties(QueryProperties.FilterType.LIST_ALL, new QueryFilter(FieldConstants.HSCID, HSC_ID))
        qp1.setOrderByDescFields(FieldConstants.SERVICESEQNUM)
        QueryProperties qp2 = new QueryProperties(QueryProperties.FilterType.NEW_FILTER, new QueryFilter(FieldConstants.HSCID, HSC_ID), new QueryFilter(FieldConstants.HSCSERVICELOCKTYPE, HsrReferenceConstants.HSCSERVICELOCKTYPE_FULL_LOCK, QueryCriteria.NOT_EQUAL))
        qp2.setOrderByAscFields(FieldConstants.SERVICESEQNUM)
        qp2.resultSize = 1

        when:
        HscServiceVO vo = hscService.deleteService(HSC_ID, SERVICE_SEQ_NUM, HsrReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT)
        then:
        vo
        1 * dao.list(qp1) >> Arrays.asList(new HscServiceVO(hscServiceLockType: HsrReferenceConstants.HSCSERVICELOCKTYPE_NO_LOCK))
        1 * dao.read(getHscReadProperties()) >> new HscServiceVO()
        0 * _
    }

    def "Test savePotentialUrJurisdictions"() {
        given:
        HscServiceUrJurisdictionVO hscServiceUrJurisdictionVO = new HscServiceUrJurisdictionVO(serviceSeqNum: SERVICE_SEQ_NUM)
        when:
        Collection<HscServiceUrJurisdictionVO> collection = hscService.savePotentialUrJurisdictions(Arrays.asList(hscServiceUrJurisdictionVO), new HscServiceVO(serviceSeqNum: SERVICE_SEQ_NUM))
        then:
        collection
        1 * hscServiceUrJurisdiction.save(hscServiceUrJurisdictionVO)
        0 * _
    }

    def "Test updateOverrideDueDate"() {
        given:
        HscServiceVO hscServiceVO = new HscServiceVO()
        UhgCalendar uhgCalendar = new UhgCalendar()
        when:
        ValueObject messageVO = hscService.updateOverrideDueDate(HSC_ID, Arrays.asList(SERVICE_SEQ_NUM), uhgCalendar)
        then:
        messageVO
        1 * dao.read(getHscReadProperties()) >> hscServiceVO
        1 * persistenceHelper.updateBatch(Arrays.asList(hscServiceVO))
        1 * hscServiceLineTatHelper.performUrJurisdictionForServiceLine(0, 0)
        0 * _
    }

    def "Test updateOverrideDueDate where override due date = null"() {
        given:
        HscServiceVO hscServiceVO = new HscServiceVO()
        when:
        ValueObject messageVO = hscService.updateOverrideDueDate(HSC_ID, Arrays.asList(SERVICE_SEQ_NUM), null)
        then:
        messageVO
        1 * dao.read(getHscReadProperties()) >> hscServiceVO
        0 * _
    }

    def "Test listHscServiceByHscIDProcedureCode"() {
        when:
        List<HscServiceVO> voList = hscService.listHscServiceByHscIDProcedureCode(HSC_ID, PROCEDURE_CODE)
        then:
        voList.size() == 1
        1 * dao.list(new QueryProperties(QueryProperties.FilterType.LIST_ALL, new QueryFilter(FieldConstants.HSCID, HSC_ID), new QueryFilter(FieldConstants.PROCEDURECODE, PROCEDURE_CODE))) >> Arrays.asList(new HscServiceVO())
        0 * _
    }

    def "Test getWrittenNoticeOverrideDueDate"() {
        when:
        UhgCalendar dueDate = hscService.getWrittenNoticeOverrideDueDate(HSC_ID, SERVICE_SEQ_NUM)
        then:
        dueDate
        1 * dao.read(getHscReadProperties(FieldConstants.OVERRIDEWRITTENNOTICEDUEDTTM)) >> new HscServiceVO(overrideWrittenNoticeDueDttm: new UhgCalendar())
        0 * _
    }

    def "Test getBestDateForNetworkStatus"() {
        when:
        java.sql.Date date = hscService.getBestDateForNetworkStatus(HSC_ID, SERVICE_SEQ_NUM)
        then:
        date.getYear() == 100
        date.getMonth() == 0
        1 * dao.read(getHscReadProperties()) >> new HscServiceVO()
        1 * hscServiceNonFacility.getServiceStartDate(HSC_ID, 0) >> new java.sql.Date(100, 0, 1)
        0 * _
    }

    def "Test getBestDateForNetworkStatus where serviceSeqNum = 0"() {
        given:
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.NEW_FILTER, new QueryFilter(FieldConstants.HSCID, HSC_ID), new QueryFilter(FieldConstants.HSCSERVICELOCKTYPE, HsrReferenceConstants.HSCSERVICELOCKTYPE_FULL_LOCK, QueryCriteria.NOT_EQUAL))
        qp.setOrderByAscFields(FieldConstants.SERVICESEQNUM)
        qp.resultSize = 1
        when:
        java.sql.Date date = hscService.getBestDateForNetworkStatus(HSC_ID, 0 as short)
        then:
        date.getYear() == 100
        date.getMonth() == 0
        1 * hscServiceNonFacility.getServiceStartDate(HSC_ID, 0) >> new java.sql.Date(100, 0, 1)
        1 * dao.list(qp) >> Arrays.asList(new HscServiceVO())
        0 * _
    }

    def "Test isProviderInUse"() {
        when:
        boolean inUse = hscService.isProviderInUse(HSC_ID, SERVICE_SEQ_NUM)
        then:
        inUse
        1 * dao.exists(new QueryProperties(QueryProperties.FilterType.NEW_FILTER, new QueryFilter(FieldConstants.HSCID, HSC_ID), new QueryFilter(FieldConstants.SERVICEPROVIDERSEQNUM, SERVICE_SEQ_NUM))) >> true
        0 * _
    }

    def "Test getPrimaryHscService"() {
        given:
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.NEW_FILTER, new QueryFilter(FieldConstants.HSCID, HSC_ID), new QueryFilter(FieldConstants.HSCSERVICELOCKTYPE, HsrReferenceConstants.HSCSERVICELOCKTYPE_FULL_LOCK, QueryCriteria.NOT_EQUAL))
        qp.setOrderByAscFields(FieldConstants.SERVICESEQNUM)
        qp.resultSize = 1
        when:
        HscServiceVO vo = hscService.getPrimaryHscService(HSC_ID)
        then:
        vo
        1 * dao.list(qp) >> Arrays.asList(new HscServiceVO())
        0 * _
    }

    def "Test readHscServiceAndNonFacility"() {
        given:
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.NEW_FILTER, new QueryFilter(FieldConstants.HSCID, HSC_ID))
        qp.setOrderByAscFields(FieldConstants.SERVICESEQNUM)
        qp.resultSize = 1
        when:
        List<HscServiceVO> voList = hscService.readHscServiceAndNonFacility(HSC_ID)
        then:
        voList
        1 * dao.list(qp) >> Arrays.asList(new HscServiceVO())
        1 * hscServiceNonFacility.read(HSC_ID, 0) >> new HscServiceNonFacilityVO()
        0 * _
    }

    def "Test hasActiveService"() {
        given:
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.NEW_FILTER, new QueryFilter(FieldConstants.HSCID, HSC_ID), new QueryFilter(FieldConstants.HSCSERVICELOCKTYPE, HsrReferenceConstants.HSCSERVICELOCKTYPE_FULL_LOCK, QueryCriteria.NOT_EQUAL))
        when:
        boolean isActive = hscService.hasActiveService(HSC_ID)
        then:
        isActive
        1 * dao.exists(qp) >> true
        0 * _
    }

    def "Test derivePotentialUrJurisdictions"() {
        given:
        HscServiceVO hscServiceVO = new HscServiceVO()
        when:
        Collection<HscServiceUrJurisdictionVO> collection = hscService.derivePotentialUrJurisdictions(hscServiceVO)
        then:
        collection == []
        1 * hscServiceUrJurisdiction.listByService(0, 0) >> Arrays.asList(new HscServiceUrJurisdictionVO())
        0 * _
    }

    def "Test validateForCleanUp"() {
        given:
        HscServiceVO hscServiceVO = new HscServiceVO(hscServiceFacilityVO: new HscServiceFacilityVO(), hscServiceNonFacilityVO: new HscServiceNonFacilityVO(), procedureCode: PROCEDURE_CODE)
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL, new QueryFilter(FieldConstants.HSCID, 0 as long))
        qp.setOrderByDescFields(FieldConstants.SERVICESEQNUM)
        when:
        hscService.validateForCleanUp(hscServiceVO)
        then:
        hscServiceVO.hscServiceNonFacilityVO.getExpandedIntake()
        !hscServiceVO.hscServiceFacilityVO.isSkipValidation()
        3 * dao.isDuplicate(new QueryProperties(QueryProperties.FilterType.NEW_FILTER, new QueryFilter(FieldConstants.HSCID, 0 as long), new QueryFilter(FieldConstants.SERVICESEQNUM, 0 as short))) >> false
        1 * hsc.readUnhydrated(0) >> new HscVO()
        1 * dao.list(qp) >> Arrays.asList(new HscServiceVO())
        1 * hscServiceNonFacility.validate(hscServiceVO.hscServiceNonFacilityVO, false)
        1 * hscServiceFacility.validate(hscServiceVO.hscServiceFacilityVO, false)
        0 * _
    }

    def "Test populateStates"() {
        given:
        HscServiceTatSummaryVO hscServiceTatSummaryVO = new HscServiceTatSummaryVO()
        HscServiceVO hscServiceVO = new HscServiceVO()
        when:
        hscService.populateStates(hscServiceTatSummaryVO, hscServiceVO)
        then:
        1 * hsc.read(0) >> new HscVO()
        1 * memberAddress.getActiveMemberAddressForMember(0) >> new MemberAddressVO()
        1 * hscMemberCoverage.read(0, 0) >> new HscMemberCoverageVO()
        0 * _
    }

    def "Test validateForShortForm"() {
        HscServiceVO vo = new HscServiceVO(procedureCode: PROCEDURE_CODE, procCodeType: PROCCODETYPE)
        when:
        hscService.validateForShortForm(vo)
        then:
        0 * _
    }

    def "Test updateSubset"() {
        given:
        HscServiceVO vo = new HscServiceVO()
        String[] stringArray = Arrays.asList("Hi").toArray() as String[]
        when:
        hscService.updateSubset(vo, stringArray)
        then:
        1 * persistenceHelper.updateSubset(vo, stringArray, true)
        0 * _
    }

    def "Test listServiceAndFacility"() {
        given:
        HscServiceVO vo = new HscServiceVO(procedureCode: PROCEDURE_CODE, procCodeType: SpclCareReferenceConstants.PROCCODETYPE_CPT4, hscServiceNonFacilityVO: new HscServiceNonFacilityVO())
        QueryProperties qp = new QueryBuilder().queryProperties {
            filter(FieldConstants.HSCID, HSC_ID)
            setOrderByAscFields(FieldConstants.SERVICESEQNUM)
        }
        when:
        hscService.listServiceAndFacility(HSC_ID, isOutpatient)

        then:
        1 * dao.list(qp) >> Arrays.asList(vo)
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_HSC_SERVICE_DETAIL_UPDATES) >> featureFlag
        if(isOutpatient) {
            1 * hscServiceNonFacility.read(HSC_ID, 0) >> new HscServiceNonFacilityVO(hscID: HSC_ID)
            1 * hscServiceNonFacilityHistory.readListCustom(HSC_ID, 0)
            1 * cpt4.read(PROCEDURE_CODE) >> new Cpt4VO()
        } else {
            1 * hscServiceFacility.read(HSC_ID, 0) >> new HscServiceFacilityVO()
            vo.getHscServiceFacilityVO().equals(new HscServiceFacilityVO())
        }
        if (featureFlag) {
            1 * hscServiceDetail.read(_,_) >> new HscServiceDetailVO(hscID: HSC_ID)
        }
        0 * _

        where:
        isOutpatient    | featureFlag
        false           | false
        false           | true
        true            | false
        true            | true
    }

    def "Test exists"() {
        when:
        boolean exists = hscService.exists(HSC_ID, SERVICE_SEQ_NUM, PROCEDURE_CODE)
        then:
        exists
        1 * dao.exists(new QueryProperties(QueryProperties.FilterType.LIST_ALL, new QueryFilter(FieldConstants.HSCID, HSC_ID), new QueryFilter(FieldConstants.SERVICESEQNUM, SERVICE_SEQ_NUM), new QueryFilter(FieldConstants.PROCEDURECODE, PROCEDURE_CODE))) >> true
        0 * _
    }

    def "Test saveShortFormData"() {
        given:
        HscIntakeVO hscIntakeVO = new HscIntakeVO(serviceSettingType: HsrReferenceConstants.SERVICESETTINGTYPE_INPATIENT)
        def hasHscID = hscIntakeVO.hasHscID()
        HscIntakeCompositeVO hscIntakeCompositeVO = new HscIntakeCompositeVO(hscIntakeVO: hscIntakeVO,
                hscServiceVOs: Arrays.asList(),
                hscProviderVOs: Arrays.asList(new HscProviderVO(roleList: Arrays.asList("SJ"),
                        hscProviderRoleVOs: new ArrayList<HscProviderRoleVO>())))
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL, new QueryFilter(FieldConstants.HSCID, 0 as long))
        qp.setOrderByDescFields(FieldConstants.SERVICESEQNUM)
        when:
        hscService.saveShortFormData(hscIntakeCompositeVO)
        then:
        !hasHscID
        1 * dao.list(qp) >> Arrays.asList(new HscServiceVO(hscID: HSC_ID, serviceSeqNum: SERVICE_SEQ_NUM))
        1 * persistenceHelper.deleteCascading(getHscReadProperties(), hscService.CASCADE_DELETE_TABLES)
        0 * _
    }

    @Unroll
    def "Test setNonPersistedItems with a #testCase"() {
        when:
        hscService.setNonPersistedItems(conditions)
        then:
        0 * _

        where:
        [testCase, conditions] << [["single HscServiceVO", new HscServiceVO(procCodeType: PROCCODETYPE, procedureCode: PROCEDURE_CODE)],
                                   ["list of HscServiceVOs", Arrays.asList(new HscServiceVO(procCodeType: PROCCODETYPE, procedureCode: PROCEDURE_CODE))]]
    }

    def "Test validateServiceHasProvider"() {
        given:
        HscServiceVO vo = new HscServiceVO()
        when:
        hscService.validateServiceHasProvider(vo)
        then:
        HscDecisionMessages.WRN_SERVICING_PROVIDER_REQUIRED.equals(vo.getGlobalMessages().getAt(0))
        0 * _
    }

    def "Test beforeExecuteAdd - verify service is not locked, and skeleton decision is created"() {
        given:
        HscServiceVO vo = new HscServiceVO(hscID: 123, serviceSeqNum: 1, hscServiceDecisionVOs: new ArrayList<HscServiceDecisionVO>())
        when:
        hscService.beforeExecuteAdd(vo)
        then:
        HsrReferenceConstants.HSCSERVICELOCKTYPE_NO_LOCK.equals(vo.getHscServiceLockType())
        1 * hscServiceLineProgramTypeHelper.getServiceReviewTypeCode(vo) >> ""
        1 * temporarySystemSetting.getStringSetting('logHscServiceAdds')
        0 * _
        vo.getHscServiceDecisionVOs().size() == 1
        HscServiceDecisionVO decisionVO = vo.getHscServiceDecisionVOs().first()
        decisionVO.hscID == vo.hscID
        decisionVO.serviceSeqNum == vo.serviceSeqNum
    }

    def "Test afterExecuteAdd"() {
        given:
        HscVO hscVO = new HscVO()
        HscServiceVO hscServiceVO = new HscServiceVO(serviceReferenceNum: "1", changeUserID: SecurityConstants.SYSTEM_DATA_PROP)
        when:
        hscService.afterExecuteAdd(hscServiceVO)
        then:
        1 * temporarySystemSetting.getStringSetting('logHscServiceAdds')
        0 * _
    }

    def "Test createUrJurisdictionAssignmentVO"() {
        when:
        HscServiceUrJurisdictionVO vo = hscService.createUrJurisdictionAssignmentVO()
        then:
        vo.equals(new HscServiceUrJurisdictionVO())
        0 * _
    }

    @Unroll
    def "isFundingArrangementRelevant: #fundingArrangement"() {
        given:

        when:
        boolean isFundingArrangementRelevant = hscService.isFundingArrangementRelevant(fundingArrangement, isErisa)

        then:
        isFundingArrangementRelevant == expected

        where:
        fundingArrangement                                              | isErisa | expected
        CommonReferenceConstants.FUNDING_ARRANGEMENT_FULLY_INSURED      | false   | true
        CommonReferenceConstants.FUNDING_ARRANGEMENT_EXCESSIVE_RISK     | false   | true
        CommonReferenceConstants.FUNDING_ARRANGEMENT_ASO                | false   | true
        CommonReferenceConstants.FUNDING_ARRANGEMENT_ASO                | true    | false
        CommonReferenceConstants.FUNDING_ARRANGEMENT_ASO_NON_ERISA      | false   | true
        CommonReferenceConstants.FUNDING_ARRANGEMENT_ASO_UNKNOWN_ERISA  | false   | false
    }

    def getHscReadProperties(String... readFields = []) {
        ReadProperties rp = new ReadProperties(hscService.tableDef.getKey())
        rp.setKeyValue(FieldConstants.HSCID, HSC_ID)
        rp.setKeyValue(FieldConstants.SERVICESEQNUM, SERVICE_SEQ_NUM)
        rp.setFields(readFields)
        return rp
    }

    private QueryProperties getQueryProperties() {
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.NEW_FILTER)
        qp.addQueryFilter(new QueryFilter(FieldConstants.HSCID, HSC_ID))
        qp.addQueryFilter(new QueryFilter(FieldConstants.SERVICESEQNUM, SERVICE_SEQ_NUM))
        return qp
    }

    private QueryProperties getValidationQueryProperties(Boolean descOrder, QueryProperties.FilterType filterType) {
        QueryProperties qp = new QueryProperties(filterType)
        qp.addQueryFilter(new QueryFilter(FieldConstants.HSCID, HSC_ID))
        if (descOrder) {
            qp.setOrderByDescFields(FieldConstants.SERVICESEQNUM)
        } else {
            qp.setOrderByAscFields(FieldConstants.SERVICESEQNUM)
        }
        return qp
    }

    private QueryProperties getProviderQueryProperties() {
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.NEW_FILTER)
        qp.setResultSize(1)
        qp.setListFields("hscID")
        qp.addQueryFilter(new QueryFilter(FieldConstants.HSCID, HSC_ID))
        qp.addQueryFilter(new QueryFilter(FieldConstants.SERVICESEQNUM, SERVICE_SEQ_NUM))
        return qp
    }

    private QueryProperties getHscServiceFacilityQueryProperties() {
        QueryProperties qp = new QueryBuilder().queryProperties {
            filter(FieldConstants.HSCID, HSC_ID)
            setOrderByAscFields(FieldConstants.SERVICESEQNUM)
        }
        return qp
    }

    private HscServiceVO getValidHscServiceVO() {
        return new HscServiceVO(
                hscID: HSC_ID,
                serviceSeqNum: SERVICE_SEQ_NUM,
                serviceProviderSeqNum: SERVICE_PROD_SEQ_NUM,
                procCodeType: PROCCODETYPE,
                procedureCode: PROCEDURE_CODE
        )
    }
}
