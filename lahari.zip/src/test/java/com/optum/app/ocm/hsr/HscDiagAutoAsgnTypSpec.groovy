package com.optum.app.ocm.hsr

import com.optum.rf.bl.spring.TransactionInterceptor
import com.optum.rf.core.locator.ServiceLocator
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.HscDiagAutoAsgnTyp
import com.optum.app.common.hsr.businesslogic.impl.HscDiagAutoAsgnTypImpl
import com.optum.app.common.hsr.data.HscDiagnosisAutoAssignmentTypeVO
import spock.lang.Unroll

class HscDiagAutoAsgnTypSpec extends HsrReadLogicSpecification {

    HscDiagAutoAsgnTyp hscDiagAutoAsgnTyp

    DataAccessObject dao
    PersistenceHelper persistenceHelper
    ServiceLocator serviceLocator
    TransactionInterceptor transactionInterceptor

    def setup() {
        dao = Mock(DataAccessObject)
        persistenceHelper = Mock(PersistenceHelper)
        serviceLocator = Mock(ServiceLocator)
        transactionInterceptor = Mock(TransactionInterceptor)

        hscDiagAutoAsgnTyp = new HscDiagAutoAsgnTypImpl(
                requiredDao: dao,
                requiredPersistenceHelper: persistenceHelper,
                requiredServiceLocator: serviceLocator,
                requiredTransactionInterceptor: transactionInterceptor
        )
    }

    @Unroll
    def "isValid #testCase"() {
        given:
        def stateOfResidence = "1"
        def diagnosisCode = "2"
        def diagnosisCodeSchemeTypeID = "3"
        def memberAgeGroup = "4"
        def rp = new ReadProperties(FieldConstants.STATEOFRESIDENCE, FieldConstants.DIAGNOSISCODE, FieldConstants.DIAGNOSISCODESCHEMETYPEID, FieldConstants.MEMBERAGEGROUP)
        rp.setKeyValue(FieldConstants.STATEOFRESIDENCE, stateOfResidence)
        rp.setKeyValue(FieldConstants.DIAGNOSISCODE, diagnosisCode)
        rp.setKeyValue(FieldConstants.DIAGNOSISCODESCHEMETYPEID, diagnosisCodeSchemeTypeID)
        rp.setKeyValue(FieldConstants.MEMBERAGEGROUP, memberAgeGroup)
        rp.fields = null

        when:
        boolean retVal = hscDiagAutoAsgnTyp.isValid(stateOfResidence, diagnosisCode, diagnosisCodeSchemeTypeID, memberAgeGroup)

        then:
        1 * dao.isValid(rp) >> expectedVal
        0 * _
        retVal == expectedVal

        where:
        testCase | expectedVal
        "passes" | true
        "fails"  | false
    }

    def "Test to read HscDiagnosisAutoAssignmentTypeVO"() {
        setup:
        def stateOfResidence = "1"
        def diagnosisCode = "2"
        def diagnosisCodeSchemeTypeID = "3"
        def memberAgeGroup = "4"
        HscDiagnosisAutoAssignmentTypeVO hscDiagnosisAutoAssignmentTypeVO = new HscDiagnosisAutoAssignmentTypeVO(stateOfResidence: stateOfResidence, diagnosisCode: diagnosisCode, diagnosisCodeSchemeTypeID: diagnosisCodeSchemeTypeID, memberAgeGroup: memberAgeGroup)
        def rp = new ReadProperties(FieldConstants.STATEOFRESIDENCE, FieldConstants.DIAGNOSISCODE, FieldConstants.DIAGNOSISCODESCHEMETYPEID, FieldConstants.MEMBERAGEGROUP)
        rp.setKeyValue(FieldConstants.STATEOFRESIDENCE, stateOfResidence)
        rp.setKeyValue(FieldConstants.DIAGNOSISCODE, diagnosisCode)
        rp.setKeyValue(FieldConstants.DIAGNOSISCODESCHEMETYPEID, diagnosisCodeSchemeTypeID)
        rp.setKeyValue(FieldConstants.MEMBERAGEGROUP, memberAgeGroup)
        rp.fields = null

        when:
        hscDiagAutoAsgnTyp.read(stateOfResidence, diagnosisCode, diagnosisCodeSchemeTypeID, memberAgeGroup)

        then:
        1 * dao.read(rp) >> hscDiagnosisAutoAssignmentTypeVO
        0 * _
    }
}
