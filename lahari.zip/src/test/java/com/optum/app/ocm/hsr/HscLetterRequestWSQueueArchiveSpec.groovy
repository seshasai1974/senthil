package com.optum.app.ocm.hsr

import com.optum.rf.bl.spring.TransactionInterceptor
import com.optum.rf.core.locator.ServiceLocator
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.HscLetterRequestWSQueueArchive
import com.optum.app.common.hsr.businesslogic.impl.HscLetterRequestWSQueueArchiveImpl
import com.optum.app.common.hsr.data.HscLetterRequestWSQueueArchiveVO
import spock.lang.Unroll

class HscLetterRequestWSQueueArchiveSpec extends HsrReadLogicSpecification {

    HscLetterRequestWSQueueArchive hscLetterRequestWSQueue

    DataAccessObject dao
    PersistenceHelper persistenceHelper
    ServiceLocator serviceLocator
    TransactionInterceptor transactionInterceptor

    def setup() {
        dao = Mock(DataAccessObject)
        persistenceHelper = Mock(PersistenceHelper)
        serviceLocator = Mock(ServiceLocator)
        transactionInterceptor = Mock(TransactionInterceptor)

        hscLetterRequestWSQueue = new HscLetterRequestWSQueueArchiveImpl(
                dao: dao,
                requiredPersistenceHelper: persistenceHelper,
                requiredServiceLocator: serviceLocator,
                requiredTransactionInterceptor: transactionInterceptor
        )
    }

    @Unroll
    def "isValid #testCase"() {
        given:
        def hscID = (long) 1
        def letterRequestSeqNum = 2
        def rp = new ReadProperties(FieldConstants.HSCID, FieldConstants.LETTERREQUESTSEQNUM)
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        rp.setKeyValue(FieldConstants.LETTERREQUESTSEQNUM, letterRequestSeqNum)
        rp.fields = null

        when:
        boolean retVal = hscLetterRequestWSQueue.isValid(hscID, letterRequestSeqNum)

        then:
        1 * dao.isValid(rp) >> expectedVal
        0 * _
        retVal == expectedVal

        where:
        testCase | expectedVal
        "passes" | true
        "fails"  | false
    }

    def "Test to read HscLetterRequestWSQueueArchiveVO"() {
        setup:
        def hscID = (long) 1
        def letterRequestSeqNum = 2
        HscLetterRequestWSQueueArchiveVO hscLetterRequestWSQueueVO = new HscLetterRequestWSQueueArchiveVO(hscID: hscID, letterRequestSeqNum: letterRequestSeqNum)
        def rp = new ReadProperties(FieldConstants.HSCID, FieldConstants.LETTERREQUESTSEQNUM)
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        rp.setKeyValue(FieldConstants.LETTERREQUESTSEQNUM, letterRequestSeqNum)
        rp.fields = null

        when:
        hscLetterRequestWSQueue.read(hscID, letterRequestSeqNum)

        then:
        1 * dao.read(rp) >> hscLetterRequestWSQueueVO
        0 * _
    }

    def "Test archiveManualLetterRequestAsNeeded"() {
        setup:
        def hscID = (long) 1
        def letterRequestSeqNum = 2

        when:
        hscLetterRequestWSQueue.archiveManualLetterRequestAsNeeded(hscID, letterRequestSeqNum, 'postXML', 'responseXML')

        then:
        1 * dao.read(_ as ReadProperties) >> archiveVO
        if(archiveVO) {
            1 * persistenceHelper.update(_ as HscLetterRequestWSQueueArchiveVO)
        } else {
            1 * persistenceHelper.add(_ as HscLetterRequestWSQueueArchiveVO)
        }
        0 * _

        where: archiveVO << [ null, new HscLetterRequestWSQueueArchiveVO() ]
    }

}
