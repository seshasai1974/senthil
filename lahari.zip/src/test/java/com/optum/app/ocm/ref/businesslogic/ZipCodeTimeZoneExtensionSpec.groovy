package com.optum.app.ocm.ref.businesslogic

import com.optum.app.ocm.OcmBaseReadLogicSpecification
import com.optum.app.ocm.ref.businesslogic.impl.ZipCodeTimeZoneExtensionImpl
import com.optum.rf.common.reference.data.ZipCodeTimeZoneVO
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.QueryCriteria
import com.optum.rf.dao.sql.query.QueryFilter
import com.optum.rf.dao.sql.query.QueryProperties
import com.uhg.app.common.constants.spclcare.FieldConstants
import spock.lang.Unroll

class ZipCodeTimeZoneExtensionSpec extends OcmBaseReadLogicSpecification {
    
    ZipCodeTimeZoneExtensionImpl zipCodeTimeZoneExtension = new ZipCodeTimeZoneExtensionImpl()
    DataAccessObject dao = Mock(DataAccessObject)
    
    def setup() {
        zipCodeTimeZoneExtension.setRequiredDao(dao)
    }
    
    def 'test getDao'() {
        when:
        DataAccessObject result = zipCodeTimeZoneExtension.getDao()
        
        then:
        0 * _
        result
    }
    
    @Unroll
    def 'test getByZipCodesCountyNames - empty params'() {
        when:
        List<ZipCodeTimeZoneVO> result = zipCodeTimeZoneExtension.getByZipCodesCountyNames(zipCodes, countyNames)
        
        then:
        0 * _
        result.empty

        where:
        zipCodes                           | countyNames
        null                               | null
        new TreeSet<String>()              | null
        new TreeSet<String>(['placeholder']) | null
        new TreeSet<String>(['placeholder']) | new TreeSet<String>()
    }
    
    def 'test getByZipCodesCountyNames - good params'() {
        given:
        Set<String> zipCodes = ['zipCode']
        Set<String> countyNames = ['countyName']
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        qp.addQueryFilter(new QueryFilter(FieldConstants.ZIP, zipCodes, QueryCriteria.IN))
        qp.addQueryFilter(new QueryFilter(FieldConstants.COUNTYNAME, countyNames, QueryCriteria.IN))
        
        when:
        List<ZipCodeTimeZoneVO> result = zipCodeTimeZoneExtension.getByZipCodesCountyNames(zipCodes, countyNames)
        
        then:
        1 * dao.list(qp) >> [new ZipCodeTimeZoneVO()]
        0 * _
        result
    }
    
    def 'test getByZipCodeTexts - empty param'() {
        when:
        List<ZipCodeTimeZoneVO> result = zipCodeTimeZoneExtension.getByZipCodeTexts(zipCodeTexts)
        
        then:
        0 * _
        result.empty

        where:
        testCase      | zipCodeTexts
        'null param'  | null
        'empty param' | new TreeSet<>()
    }
    
    def 'test getByZipCodeTexts - good param'() {
        given:
        Set<String> zipCodeTexts = ['zipCode']
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        qp.addQueryFilter(new QueryFilter(FieldConstants.ZIP, zipCodeTexts, QueryCriteria.IN))
        
        when:
        List<ZipCodeTimeZoneVO> result = zipCodeTimeZoneExtension.getByZipCodeTexts(zipCodeTexts)
        
        then:
        1 * dao.list(qp) >> [new ZipCodeTimeZoneVO()]
        0 * _
        result
    }
    
    
}
