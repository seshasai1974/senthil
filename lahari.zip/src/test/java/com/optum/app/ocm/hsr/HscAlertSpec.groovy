package com.optum.app.ocm.hsr

import com.optum.rf.bl.spring.TransactionInterceptor
import com.optum.rf.core.locator.ServiceLocator
import com.optum.rf.core.util.GenericUtilities
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.QueryFilter
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.optum.app.ocm.ref.businesslogic.CustomerReference
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.impl.HscAlertImpl
import com.optum.app.common.hsr.data.HscAlertVO

class HscAlertSpec extends HsrReadLogicSpecification {

	HscAlertImpl hscAlert
    CustomerReference customerReference
	DataAccessObject dao
	PersistenceHelper persistenceHelper
	ServiceLocator serviceLocator
	TransactionInterceptor transactionInterceptor

	def setup() {
		hscAlert = new HscAlertImpl()
		dao = Mock(DataAccessObject)
		customerReference = Mock(CustomerReference)
		persistenceHelper = Mock(PersistenceHelper)
		serviceLocator = Mock(ServiceLocator)
		transactionInterceptor = Mock(TransactionInterceptor)

		hscAlert.dao = dao
		hscAlert.setRequiredPersistenceHelper(persistenceHelper)
		hscAlert.setRequiredServiceLocator(serviceLocator)
		hscAlert.setRequiredTransactionInterceptor(transactionInterceptor)
        hscAlert.customerReference = customerReference
	}

	/**
	 * Test valid add.
	 */
	def "Test Valid Add"() {
		setup:
        def vo = new HscAlertVO(hscID: 52078503, alertType: '10', alertStatusType: '1')

		when:
		hscAlert.add(vo, false)

		then:
		1 * persistenceHelper.add(_ as HscAlertVO)
		//TODO Add any other expectations or use 'thrown UnsupportedOperationException'

		expect:
		!vo.errorMessagesExist()
	}
	
	/**
     * Test valid delete.
     */
    def "Test Valid Delete"() {
        setup:
        def vo = new HscAlertVO(hscID: 52078503, alertType: '10', alertStatusType: '1')

        when:
        hscAlert.delete(vo)

		then:
		1 * persistenceHelper.delete(_ as HscAlertVO)
		//TODO Add any other expectations or use 'thrown UnsupportedOperationException'

        expect:
		!vo.errorMessagesExist()
	}
	
	/**
	 * Test valid update.
	 */
	def "Test Valid Update"() {
		setup:
        def vo = new HscAlertVO(hscID: 52078503, alertType: '10', alertStatusType: '1')

		when:
		hscAlert.update(vo, false)

		then:
		1 * persistenceHelper.update(_ as HscAlertVO)
		//TODO Add any other expectations or use 'thrown UnsupportedOperationException'

        expect:
		!vo.errorMessagesExist()
	}

    def "Test getAlertListByHscId"(){
        setup:
        long hscID = 52078503 //A sample HSC ID with alerts attached to it in Dev
        def qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        qp.addQueryFilter(new QueryFilter(FieldConstants.HSCID, hscID))

        when:
        List<HscAlertVO> alertVOList = hscAlert.getAlertListByHscId(hscID, true, qp)

        then:
        1 * dao.list(qp) >> [new HscAlertVO()]

        expect:
        assert (!GenericUtilities.isEmptyOrNull(alertVOList))
    }

    def "Test validate with update"(){
        setup:
        def vo = new HscAlertVO(hscID: 52078503, alertType: '10', alertStatusType: '1')

        when:
        hscAlert.validate(vo, true)

        then:
        1 * customerReference.validateReference(vo, FieldConstants.ALERTTYPE, vo.getAlertType(), true)
        1 * customerReference.validateReference(vo, FieldConstants.ALERTSTATUSTYPE, vo.getAlertStatusType(), false)

        expect:
        !vo.errorMessagesExist()
    }

    def "Test validate without update"(){
        setup:
        def vo = new HscAlertVO(hscID: 52078503, alertType: '10', alertStatusType: '1')

        when:
        hscAlert.validate(vo, false)

        then:
        1 * customerReference.validateReference(vo, FieldConstants.ALERTTYPE, vo.getAlertType(), true)
        1 * customerReference.validateReference(vo, FieldConstants.ALERTSTATUSTYPE, vo.getAlertStatusType(), false)
        1 * dao.exists(_ as QueryProperties) >> exists

        expect:
        if(exists) {
	        vo.errorMessagesExist()
        } else {
	        !vo.errorMessagesExist()
        }

	    where: exists << [ false, true ]
    }

    def "Test hasAlertBySourceID - existing record"() {
        given:
        long hscID = 123
        short providerSeqNum = 2

        when:
        boolean hasAlertBySourceID = hscAlert.hasAlertBySourceID(hscID, (int)providerSeqNum)

        then:
        1 * dao.exists(_ as QueryProperties) >> { QueryProperties qp ->
            assert qp.queryFilters.get(0).fieldValue == hscID
            assert qp.queryFilters.get(1).fieldValue == providerSeqNum
            true
        }
        0 * _

        and:
        hasAlertBySourceID
    }

	def "Test isValid"() {
		given:
		long hscID = 123
		short alertSeqNum = 2

		when:
		boolean isValid = hscAlert.isValid(hscID, (int)alertSeqNum)

		then:
		1 * dao.isValid(_ as ReadProperties)
		0 * _
	}

	def "Test read"() {
		given:
		long hscID = 123
		short alertSeqNum = 2

		when:
		HscAlertVO hscAlertVO = hscAlert.read(hscID, (int)alertSeqNum)

		then:
		1 * dao.read(_ as ReadProperties)
		0 * _
	}

	def "Test getActiveAlertCount"() {
		given:
		long hscID = 123

		when:
		int count = hscAlert.getActiveAlertCount(hscID)

		then:
		1 * dao.getCount(_ as QueryProperties)
		0 * _
	}

	def "Test getOpenAlertByAlertType"() {
		given:
		long hscID = 123

		when:
		HscAlertVO hscAlertVO = hscAlert.getOpenAlertByAlertType(hscID, '1')

		then:
		1 * dao.list(_ as QueryProperties) >> [ new HscAlertVO() ]
		0 * _
	}

	def "Test getActiveAlertList"() {
		given:
		long hscID = 123

		when:
		List <HscAlertVO> hscAlertVOs = hscAlert.getActiveAlertList(hscID)

		then:
		1 * dao.list(_ as QueryProperties) >> [ new HscAlertVO() ]
		0 * _
	}

	def "Test clearActiveAlerts"() {
		given:

		when:
		hscAlert.clearActiveAlerts([ new HscAlertVO() ])

		then:
		1 * persistenceHelper.updateBatchSubset(_ as List<HscAlertVO>, [FieldConstants.ALERTSTATUSTYPE, FieldConstants.CLEARBYUSERID, FieldConstants.CLEARDATETIME] as String[], true)
		0 * _
	}

	def "Test hasNoActiveQuestionnaireAlerts"() {
		given:
		long hscID = 123

		when:
		boolean result = hscAlert.hasNoActiveQuestionnaireAlerts(hscID, 1)

		then:
		1 * dao.exists(_ as QueryProperties)
		0 * _
	}

	def "Test hasAlertByType"() {
		given:
		long hscID = 123

		when:
		boolean result = hscAlert.hasAlertByType(hscID, '1')

		then:
		1 * dao.exists(_ as QueryProperties)
		0 * _
	}

	def "Test hasAlertByTypeAndStatus"() {
		given:
		long hscID = 123

		when:
		boolean result = hscAlert.hasAlertByTypeAndStatus(hscID, '1', '2')

		then:
		1 * dao.exists(_ as QueryProperties)
		0 * _
	}

	def "Test hasAlertByTypeStatusComment"() {
		given:
		long hscID = 123

		when:
		boolean result = hscAlert.hasAlertByTypeStatusComment(hscID, '1', '2', 'comment')

		then:
		1 * dao.exists(_ as QueryProperties)
		0 * _
	}

	def "Test clearOpenAlert"() {
		given:
		long hscID = 123

		when:
		hscAlert.clearOpenAlert(hscID, '1')

		then:
		1 * dao.list(_ as QueryProperties) >> [ new HscAlertVO() ]
		1 * customerReference.validateReference(_ as HscAlertVO, FieldConstants.ALERTTYPE, null, true)
		1 * customerReference.validateReference(_ as HscAlertVO, FieldConstants.ALERTSTATUSTYPE, null, false)
		1 * persistenceHelper.update(_ as HscAlertVO)
		0 * _
	}

	def "Test createNewAlert"() {
		given:
		long hscID = 123

		when:
		hscAlert.createNewAlert(hscID, '1', 'comment')

		then:
		1 * customerReference.validateReference(_ as HscAlertVO, FieldConstants.ALERTTYPE, '1', true)
		1 * customerReference.validateReference(_ as HscAlertVO, FieldConstants.ALERTSTATUSTYPE, '0', false)
		1 * dao.exists(_ as QueryProperties)
		1 * persistenceHelper.add(_ as HscAlertVO)
		0 * _
	}

	def "Test replaceOpenAlertAsNeeded"() {
		given:
		long hscID = 123

		when:
		hscAlert.replaceOpenAlertAsNeeded(hscID, '1', 'comment')

		then:
		1 * dao.list(_ as QueryProperties) >> [ alert ]
		if(alert) {
			1 * dao.list(_ as QueryProperties)
		}
		1 * customerReference.validateReference(_ as HscAlertVO, FieldConstants.ALERTTYPE, '1', true)
		1 * customerReference.validateReference(_ as HscAlertVO, FieldConstants.ALERTSTATUSTYPE, '0', false)
		1 * dao.exists(_ as QueryProperties)
		1 * persistenceHelper.add(_ as HscAlertVO)
		0 * _

		where: alert << [ null, new HscAlertVO() ]
	}

	def "Test updateAlertComments"() {
		given:
		long hscID = 123

		when:
		hscAlert.updateAlertComments(hscID, '1', 'comment')

		then:
		1 * dao.list(_ as QueryProperties) >> [ new HscAlertVO() ]
		1 * customerReference.validateReference(_ as HscAlertVO, FieldConstants.ALERTTYPE, null, true)
		1 * customerReference.validateReference(_ as HscAlertVO, FieldConstants.ALERTSTATUSTYPE, null, false)
		1 * persistenceHelper.update(_ as HscAlertVO)
		0 * _
	}

	def "Test getOpenAlertsForHsc"() {
		given:
		List<String> hscIDs = ['123', '456']

		when:
		List <HscAlertVO> hscAlertVOs = hscAlert.getOpenAlertsForHsc(hscIDs)

		then:
		1 * dao.list(_ as QueryProperties) >> [ new HscAlertVO() ]
		0 * _
	}

	/**
	 * Create a valid Value Object.
	 */
	HscAlertVO createValidVO() {
		new HscAlertVO()
	}
}

