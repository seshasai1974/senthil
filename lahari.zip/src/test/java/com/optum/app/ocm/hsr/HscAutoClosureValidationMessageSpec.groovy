package com.optum.app.ocm.hsr

import com.optum.rf.bl.spring.TransactionInterceptor
import com.optum.rf.core.locator.ServiceLocator
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.HscAutoClosureValidationMessage
import com.optum.app.common.hsr.businesslogic.impl.HscAutoClosureValidationMessageImpl
import com.optum.app.common.hsr.data.HscAutoClosureValidationMessageVO
import spock.lang.Unroll



class HscAutoClosureValidationMessageSpec extends HsrReadLogicSpecification {

    HscAutoClosureValidationMessage hscAutoClosureValidationMessage

    DataAccessObject dao
    PersistenceHelper persistenceHelper
    ServiceLocator serviceLocator
    TransactionInterceptor transactionInterceptor

    def setup() {
        dao = Mock(DataAccessObject)
        persistenceHelper = Mock(PersistenceHelper)
        serviceLocator = Mock(ServiceLocator)
        transactionInterceptor = Mock(TransactionInterceptor)

        hscAutoClosureValidationMessage = new HscAutoClosureValidationMessageImpl(
                dao: dao,
                requiredPersistenceHelper: persistenceHelper,
                requiredServiceLocator: serviceLocator,
                requiredTransactionInterceptor: transactionInterceptor
        )
    }

    @Unroll
    def "isValid #testCase"() {
        given:
        def hscID = (long) 1
        def autoClosureSeqNum = (short) 2
        def validationMsgSeqNum = (short) 3
        def rp = new ReadProperties(FieldConstants.HSCID, FieldConstants.AUTOCLOSURESEQNUM, FieldConstants.VALIDATIONMSGSEQNUM)
        rp.setKeyValue(com.optum.app.common.constants.spclcare.FieldConstants.HSCID, hscID)
        rp.setKeyValue(com.optum.app.common.constants.spclcare.FieldConstants.AUTOCLOSURESEQNUM, autoClosureSeqNum)
        rp.setKeyValue(com.optum.app.common.constants.spclcare.FieldConstants.VALIDATIONMSGSEQNUM, validationMsgSeqNum)
        rp.fields = null

        when:
        boolean retVal = hscAutoClosureValidationMessage.isValid(hscID, autoClosureSeqNum, validationMsgSeqNum)

        then:
        1 * dao.isValid(rp) >> expectedVal
        0 * _
        retVal == expectedVal

        where:
        testCase | expectedVal
        "passes" | true
        "fails"  | false
    }

    def "Test to read HscAutoClosureValidationMessageVO"() {
        setup:
        def hscID = (long) 1
        def autoClosureSeqNum = (short) 2
        def validationMsgSeqNum = (short) 3
        HscAutoClosureValidationMessageVO hscAutoClosureValidationMessageVO = new HscAutoClosureValidationMessageVO(hscID: hscID, autoClosureSeqNum: autoClosureSeqNum, validationMsgSeqNum: validationMsgSeqNum)
        def rp = new ReadProperties(FieldConstants.HSCID, FieldConstants.AUTOCLOSURESEQNUM, FieldConstants.VALIDATIONMSGSEQNUM)
        rp.setKeyValue(com.optum.app.common.constants.spclcare.FieldConstants.HSCID, hscID)
        rp.setKeyValue(com.optum.app.common.constants.spclcare.FieldConstants.AUTOCLOSURESEQNUM, autoClosureSeqNum)
        rp.setKeyValue(com.optum.app.common.constants.spclcare.FieldConstants.VALIDATIONMSGSEQNUM, validationMsgSeqNum)
        rp.fields = null

        when:
        hscAutoClosureValidationMessage.read(hscID, autoClosureSeqNum, validationMsgSeqNum)

        then:
        1 * dao.read(rp) >> hscAutoClosureValidationMessageVO
        0 * _
    }

    def "Test getNextAutoClosureSeqNum"() {
        setup:

        when:
        hscAutoClosureValidationMessage.getNextAutoClosureSeqNum(123456L)

        then:
        1 * dao.list(_ as QueryProperties) >> [ new HscAutoClosureValidationMessageVO() ]
        0 * _
    }

    def "Test getAutoClosureValidationFailures"() {
        setup:

        when:
        hscAutoClosureValidationMessage.getAutoClosureValidationFailures(123456L)

        then:
        1 * dao.list(_ as QueryProperties) >> [ new HscAutoClosureValidationMessageVO() ]
        0 * _
    }

}