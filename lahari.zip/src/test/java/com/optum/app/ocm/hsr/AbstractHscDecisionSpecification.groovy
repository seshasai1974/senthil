package com.optum.app.ocm.hsr

import com.optum.app.ocm.common.member.businesslogic.Member
import com.optum.app.ocm.ref.businesslogic.CustomerReference
import com.optum.rf.common.messages.GlobalMessages
import com.optum.rf.dao.data.ValueObject
import com.optum.rf.dao.data.message.Message
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.rf.dao.tabledef.FieldDef
import com.optum.rf.dao.tabledef.FieldPropertyFactory
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.optum.rf.test.core.assertion.ValueObjectAsserter
import com.optum.app.common.constants.CommonReferenceConstants
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.AbstractHscDecisionHelper
import com.optum.app.common.hsr.businesslogic.Hsc
import com.optum.app.common.hsr.businesslogic.HscAlternateIdentifier
import com.optum.app.common.hsr.businesslogic.HscDecisionMemberCoverage
import com.optum.app.common.hsr.businesslogic.HscDecisionProvider
import com.optum.app.common.hsr.businesslogic.HscDiagnosis
import com.optum.app.common.hsr.businesslogic.HscFacility
import com.optum.app.common.hsr.businesslogic.HscMemberCoverage
import com.optum.app.common.hsr.businesslogic.HscProvider
import com.optum.app.common.hsr.businesslogic.HscProviderRole
import com.optum.app.common.hsr.businesslogic.HscServiceLineTatHelper
import com.optum.app.common.hsr.businesslogic.HscTatPointHelper
import com.optum.app.common.hsr.businesslogic.impl.AbstractHscDecision
import com.optum.app.common.hsr.constants.HsrNonPersistedFieldConstants
import com.optum.app.common.hsr.constants.HsrReferenceConstants
import com.optum.app.common.hsr.data.AbstractHscDecisionSourceVO
import com.optum.app.common.hsr.data.AbstractHscDecisionVO
import com.optum.app.common.hsr.data.HscAlternateIdentifierVO
import com.optum.app.common.hsr.data.HscDecisionMemberCoverageVO
import com.optum.app.common.hsr.data.HscDecisionProviderVO
import com.optum.app.common.hsr.data.HscFacilityDecisionSourceVO
import com.optum.app.common.hsr.data.HscFacilityDecisionVO
import com.optum.app.common.hsr.data.HscFacilityVO
import com.optum.app.common.hsr.data.HscMemberCoverageVO
import com.optum.app.common.hsr.data.HscProviderVO
import com.optum.app.common.hsr.data.HscServiceDecisionVO
import com.optum.app.common.hsr.data.HscVO
import com.optum.app.common.hsr.messages.HscDecisionMessages
import com.optum.app.common.hsr.messages.HscMessages
import com.optum.app.common.member.core.data.MemberVO
import com.optum.app.ocm.common.security.businesslogic.AppUser
import com.optum.app.ocm.common.security.data.AppUserVO
import groovy.transform.CompileStatic
import org.apache.commons.lang.StringUtils
import spock.lang.Unroll

/**
 * Abstract decision test class that contains helper methods and injection references that are common to the extended decision test classes.
 * Also contains common tests for methods that exist in AbstractHscDecision that the decision business classes extend so that they are always run
 * for each type of decision that the business classes represent (ex. HscServiceDecisionImpl and HscFacilityDecisionImpl). This eliminates the need
 * for duplication of tests in each extended decision test class for common code such as core validation and ensures coverage for all decision types.
 *
 * NOTE: This class is intentionally named ending with Specification instead of Spec so that the tests build does not attempt
 *       to run this as a stand-alone test.
 *
 * @param <S>     generic placeholder for a specific type of AbstractHscDecisionSourceVO
 * @param <V>     generic placeholder for a specific type of AbstractHscDecisionVO
 */
abstract class AbstractHscDecisionSpecification<S extends AbstractHscDecisionSourceVO, V extends AbstractHscDecisionVO<S>> extends HsrReadLogicSpecification {

    // end user used to indicate the decision is not a skeleton
    protected final END_USER_ID = "END_USER"

    protected abstract V newHscDecisionVO(String... changeUserID)

    protected abstract S newDecisionSourceVO();

    protected abstract void setDecisionSourceVOList(V vo)

    protected abstract void mockGetDecisionSourceList(List<S> sourceList)   // Extended class needs to create mock for specific business class references such as hscFacilityDecisionSource
    protected abstract HscProviderVO mockGetProviderForDecision(HscProviderVO providerVO)   // Extended class needs to create mock(s) for the decision provider since they use different business class references

    private AbstractHscDecision abstractHscDecision  // reference to instance of the decision business class that the extended test class is testing

    // Definitions of injected business classes referenced in the abstract and extended decision business classes
    protected DataAccessObject<V> dao
    protected Hsc hsc
    protected HscDiagnosis hscDiagnosis
    protected HscFacility hscFacility
    protected HscMemberCoverage hscMemberCoverage
    protected HscDecisionMemberCoverage hscDecisionMemberCoverage
    protected HscProvider hscProvider
    protected HscProviderRole hscProviderRole
    protected Member member
    protected CustomerReference customerReference
    protected HscDecisionProvider hscDecisionProvider
    protected PersistenceHelper persistenceHelper
    protected AbstractHscDecisionHelper abstractHscDecisionHelper
    protected AppUser appUser
    protected HscTatPointHelper tatPointHelper
    private HscAlternateIdentifier hscAlternateIdentifier
    private HscServiceLineTatHelper hscServiceLineTatHelper

    protected def setup() {
        // Create mock objects of injections for the abstract and extended decision business classes
        dao = Mock(DataAccessObject)
        hsc = Mock(Hsc)
        hscDiagnosis = Mock(HscDiagnosis)
        hscFacility = Mock(HscFacility)
        hscMemberCoverage = Mock(HscMemberCoverage)
        hscDecisionMemberCoverage = Mock(HscDecisionMemberCoverage)
        hscProvider = Mock(HscProvider)
        hscProviderRole = Mock(HscProviderRole)
        member = Mock(Member)
        customerReference = Mock(CustomerReference)
        hscDecisionProvider = Mock(HscDecisionProvider)
        persistenceHelper = Mock(PersistenceHelper)
        abstractHscDecisionHelper = Mock(AbstractHscDecisionHelper)
        appUser = Mock(AppUser)
        tatPointHelper = Mock(HscTatPointHelper)
        hscAlternateIdentifier = Mock(HscAlternateIdentifier)
        hscServiceLineTatHelper = Mock(HscServiceLineTatHelper)
    }

    /**
     * Do additional setup including setting required injection initialization on instance of decision business class being tested.
     *
     * @param abstractHscDecision Reference to the instance of the decision business class that extended test class is testing (ex. HscFacilityDecisionImpl)
     */
    protected def doSetup(AbstractHscDecision abstractHscDecision) {

        // Assign a reference to the decision business class targeted for testing that can be referenced throughout this abstract class
        this.abstractHscDecision = abstractHscDecision

        // Set the required injections in the abstract and extended decision business classes
        abstractHscDecision.setRequiredHsc(hsc)
        abstractHscDecision.setRequiredHscDiagnosis(hscDiagnosis)
        abstractHscDecision.setRequiredHscFacility(hscFacility)
        abstractHscDecision.setRequiredHscMemberCoverage(hscMemberCoverage)
        abstractHscDecision.setRequiredHscDecisionMemberCoverage(hscDecisionMemberCoverage)
        abstractHscDecision.setRequiredHscProvider(hscProvider)
        abstractHscDecision.setRequiredHscProviderRole(hscProviderRole)
        abstractHscDecision.setRequiredMember(member)
        abstractHscDecision.setRequiredCustomerReference(customerReference)
        abstractHscDecision.setRequiredHscDecisionProvider(hscDecisionProvider)
        abstractHscDecision.setRequiredPersistenceHelper(persistenceHelper)
        abstractHscDecision.setRequiredAbstractHscDecisionHelper(abstractHscDecisionHelper)
        abstractHscDecision.setRequiredAppUser(appUser)
        abstractHscDecision.setRequiredTatPointHelper(tatPointHelper)
        abstractHscDecision.setRequiredHscAlternateIdentifier(hscAlternateIdentifier)
        abstractHscDecision.setRequiredHscServiceLineTatHelper(hscServiceLineTatHelper)
    }

    /**
     *  Test that the expected error message is added to the decision VO during the validate method for the nursing facility SNF days count check.
     */
    @Unroll()
    protected def "validateRemainingSkilledNursingFacilityCount: expected error message added to VO when remaining SNF Days count = 0 for nursing place of service where isUpdate = #isUpdate"() {
        setup:
        // Intentionally set only properties needed for test to ensure that expected path is executed through all the validation
        def decisionVO = newHscDecisionVO(END_USER_ID)
        HscVO hscVO = new HscVO(serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT,
                                specialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_COSMOS,
                                hscID: 1)
        HscFacilityVO facilityVO = new HscFacilityVO(placeOfServiceCode: CommonReferenceConstants.PLACEOFSERVICE_NURSING, remainingSNFDaysCount: 0, changeUserID: "unittest")

        when:
        abstractHscDecision.validate(decisionVO, isUpdate)

        then: "mock what is needed for test"
        interaction { // interaction needed when mocking is defined in another local method
            defineCommonValidateMocks(decisionVO, getNewDecisionSourceList(), hscVO)
        }
        if(decisionVO.isFacilityLine()) {
            2 * hscFacility.read(_) >> facilityVO   // Called from validateRemainingSkilledNursingFacilityCount
        } else {
            1 * hscFacility.read(_) >> facilityVO   // Called from validateRemainingSkilledNursingFacilityCount
        }
        (0.._) * hsc.readUnhydrated(_, FieldConstants.SPECIALPROCESSTYPE, FieldConstants.SECONDARYSPECIALPROCESSTYPE) >> hscVO

        where:
        // Test both add and update paths
        isUpdate << [false, true]
    }

    /**
     * Test that the required fields for a rendered decision are populated in a decision VO.
     */
    @Unroll()
    protected def "validateDecisionRenderedDependentFields: validate that the #nullField VO property is not blank where isUpdate = #isUpdate and decision outcome type = #outcomeType"() {
        setup:
        // Intentionally set only properties needed for test to ensure that expected path is executed through all the validation
        def decisionVO = getNewRenderedHscDecisionVO(outcomeType, true, reasonType, subType)
        def currentDecisionVO = getNewRenderedHscDecisionVO("anyValue", true)
        HscVO hscVO = new HscVO()

        when:
        abstractHscDecision.validate(decisionVO, isUpdate)

        then: "mock what is needed for test"
        1 * hscAlternateIdentifier.read(hscVO.hscID, HsrReferenceConstants.HSCALTERNATEIDTYPE_CAREONE_CASE_NUMBER)
        interaction { // interaction needed when mocking is defined in another local method
            defineCommonValidateMocks(currentDecisionVO, getNewDecisionSourceList(), hscVO)
        }

        and: "check expected results"
        ValueObjectAsserter.assertMessageExists(decisionVO, nullField, expectedMessage)

        where: "various test path combinations"
        // Test both add and update paths for approved and denied decisions for each required field
        reasonType | subType    | madeByUserID | isUpdate | nullField                           | expectedMessage                   | outcomeType
        null       | "anyValue" | "unittest"   | false    | FieldConstants.DECISIONREASONTYPE   | GlobalMessages.ERR_REQUIRED_VALUE | HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED
        null       | "anyValue" | "unittest"   | true     | FieldConstants.DECISIONREASONTYPE   | GlobalMessages.ERR_REQUIRED_VALUE | HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED
        null       | "anyValue" | "unittest"   | false    | FieldConstants.DECISIONREASONTYPE   | GlobalMessages.ERR_REQUIRED_VALUE | HsrReferenceConstants.DECISIONOUTCOMETYPE_DENIED
        null       | "anyValue" | "unittest"   | true     | FieldConstants.DECISIONREASONTYPE   | GlobalMessages.ERR_REQUIRED_VALUE | HsrReferenceConstants.DECISIONOUTCOMETYPE_DENIED
        "anyValue" | null       | "unittest"   | false    | FieldConstants.DECISIONSUBTYPE      | GlobalMessages.ERR_REQUIRED_VALUE | HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED
        "anyValue" | null       | "unittest"   | true     | FieldConstants.DECISIONSUBTYPE      | GlobalMessages.ERR_REQUIRED_VALUE | HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED
        "anyValue" | null       | "unittest"   | false    | FieldConstants.DECISIONSUBTYPE      | GlobalMessages.ERR_REQUIRED_VALUE | HsrReferenceConstants.DECISIONOUTCOMETYPE_DENIED
        "anyValue" | null       | "unittest"   | true     | FieldConstants.DECISIONSUBTYPE      | GlobalMessages.ERR_REQUIRED_VALUE | HsrReferenceConstants.DECISIONOUTCOMETYPE_DENIED
        "anyValue" | "anyValue" | null         | false    | FieldConstants.DECISIONMADEBYUSERID | GlobalMessages.ERR_REQUIRED_VALUE | HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED
        "anyValue" | "anyValue" | null         | true     | FieldConstants.DECISIONMADEBYUSERID | GlobalMessages.ERR_REQUIRED_VALUE | HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED
        "anyValue" | "anyValue" | null         | false    | FieldConstants.DECISIONMADEBYUSERID | GlobalMessages.ERR_REQUIRED_VALUE | HsrReferenceConstants.DECISIONOUTCOMETYPE_DENIED
        "anyValue" | "anyValue" | null         | true     | FieldConstants.DECISIONMADEBYUSERID | GlobalMessages.ERR_REQUIRED_VALUE | HsrReferenceConstants.DECISIONOUTCOMETYPE_DENIED
    }

    /**
     * Test that the decision source list for a rendered decision is populated in a decision VO.
     */
    @Unroll()
    protected def "validateDecisionRenderedDependentFields: validate that the decision VO has at least one decision source VO where isUpdate = #isUpdate and decision outcome type = #outcomeType"() {
        setup:
        def decisionVO = getNewRenderedHscDecisionVO(outcomeType, false)
        def currentDecisionVO = getNewRenderedHscDecisionVO("anyValue", true)
        HscVO hscVO = new HscVO()

        when:
        abstractHscDecision.validate(decisionVO, isUpdate)

        then: "mock what is needed for test"
        1 * hscAlternateIdentifier.read(hscVO.hscID, HsrReferenceConstants.HSCALTERNATEIDTYPE_CAREONE_CASE_NUMBER)
        interaction { // interaction needed when mocking is defined in another local method
            defineCommonValidateMocks(currentDecisionVO, getNewDecisionSourceList(), hscVO)
        }

        and: "check expected results"
        ValueObjectAsserter.assertMessageExists(decisionVO, HscDecisionMessages.ERR_MEMBER_NOT_ASSOCIATED)

        where: "various test path combinations"
        // Test both add and update paths for approved and denied decisions
        isUpdate | outcomeType
        false    | HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED
        true     | HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED
        false    | HsrReferenceConstants.DECISIONOUTCOMETYPE_DENIED
        true     | HsrReferenceConstants.DECISIONOUTCOMETYPE_DENIED
    }

    /**
     * Test that the gap review outcome field for a rendered decision is populated in a decision VO for an out of network provider.
     */
    @Unroll()
    protected def "validateDecisionRenderedDependentFields: validate that the GapReviewOutcome field in a rendered decision VO is not null for an out of network provider where isUpdate = #isUpdate and decision outcome type = #outcomeType"() {
        setup:
        def decisionVO = getNewRenderedHscDecisionVO(outcomeType, true)
        decisionVO.setGapReviewOutcome(null)
        def currentDecisionVO = getNewRenderedHscDecisionVO("anyValue", true)
        HscProviderVO oonProviderVO = new HscProviderVO(networkStatusType: CommonReferenceConstants.NETWORK_STATUS_OUT_OF_NETWORK)
        HscVO hscVO = new HscVO()

        when:
        abstractHscDecision.validate(decisionVO, isUpdate)

        then: "mock what is needed for test"
        1 * hscAlternateIdentifier.read(hscVO.hscID, HsrReferenceConstants.HSCALTERNATEIDTYPE_CAREONE_CASE_NUMBER)
        interaction { // interaction needed when mocking is defined in another local method
            defineCommonValidateMocks(currentDecisionVO, getNewDecisionSourceList(), hscVO, oonProviderVO, new MemberVO())
        }

        where: "various test path combinations"
        // Test both add and update paths for approved and denied decisions
        isUpdate | outcomeType
        false    | HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED
        true     | HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED
        false    | HsrReferenceConstants.DECISIONOUTCOMETYPE_DENIED
        true     | HsrReferenceConstants.DECISIONOUTCOMETYPE_DENIED
    }

    /**
     * Test that a provider is associated for a rendered decision.
     */
    @Unroll()
    protected def "validateDecisionRenderedDependentFields: validate that a provider is associated for a rendered decision VO where isUpdate = #isUpdate and decision outcome type = #outcomeType"() {
        setup:
        def decisionVO = getNewRenderedHscDecisionVO(outcomeType, true)
        def currentDecisionVO = getNewRenderedHscDecisionVO("anyValue", true)
        HscVO hscVO = new HscVO()

        when:
        abstractHscDecision.validate(decisionVO, isUpdate)

        then: "mock what is needed for test"
        1 * hscAlternateIdentifier.read(hscVO.hscID, HsrReferenceConstants.HSCALTERNATEIDTYPE_CAREONE_CASE_NUMBER)
        interaction { // interaction needed when mocking is defined in another local method
            defineCommonValidateMocks(currentDecisionVO, getNewDecisionSourceList(), hscVO, null, new MemberVO())
        }

        and: "check expected results"
        ValueObjectAsserter.assertMessageExists(decisionVO, HscDecisionMessages.ERR_PROVIDER_NOT_ASSOCIATED)

        where: "various test path combinations"
        // Test both add and update paths for approved and denied decisions
        isUpdate | outcomeType
        false    | HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED
        true     | HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED
        false    | HsrReferenceConstants.DECISIONOUTCOMETYPE_DENIED
        true     | HsrReferenceConstants.DECISIONOUTCOMETYPE_DENIED
    }

    /**
     * Test that the decision source comment field is populated for a denied decision.
     */
    @Unroll()
    protected def "validateDecisionSourceComment: validate that the decision source comment field is populated for a denied decision where isUpdate = #isUpdate"() {
        setup:
        def decisionVO = getNewRenderedHscDecisionVO(HsrReferenceConstants.DECISIONOUTCOMETYPE_DENIED, true)
        decisionVO.setDecisionSourceComment(decSourceComment)
        decisionVO.setDecisionReasonType(decisionReason)
        decisionVO.setDecisionOutcomeType(decOutcomeType)
        def currentDecisionVO = getNewRenderedHscDecisionVO("anyValue", true)
        HscVO hscVO = new HscVO(umResponsibilityType: umResponsibility,
                                hscID: 1)

        when:
        abstractHscDecision.validate(decisionVO, isUpdate)

        then: "mock what is needed for test"
        interaction { // interaction needed when mocking is defined in another local method
            defineCommonValidateMocks(currentDecisionVO, getNewDecisionSourceList(), hscVO)
        }

        and: "check expected results"
        if(isErrorExpected) {
            ValueObjectAsserter.assertMessageExists(decisionVO, FieldConstants.DECISIONSOURCECOMMENT, GlobalMessages.ERR_REQUIRED_VALUE)
        }

        where: "various test path combinations"
        // Test both add and update paths for null and empty string
        isUpdate | decOutcomeType                                     | decSourceComment  | specialProcessType                                  | umResponsibility                                    | decisionReason                                                 | isErrorExpected
        false    | HsrReferenceConstants.DECISIONOUTCOMETYPE_DENIED   | null              | HsrReferenceConstants.SPECIALPROCESSTYPE_CARECORE   | HsrReferenceConstants.UMRESPONSIBILITYTYPE_UHG_CASE | HsrReferenceConstants.DECISIONREASONTYPE_ADMINISTRATIVE_NO_REF | true
        true     | HsrReferenceConstants.DECISIONOUTCOMETYPE_DENIED   | null              | HsrReferenceConstants.SPECIALPROCESSTYPE_CARECORE   | HsrReferenceConstants.UMRESPONSIBILITYTYPE_UHG_CASE | HsrReferenceConstants.DECISIONREASONTYPE_ADMINISTRATIVE_NO_REF | true
        false    | HsrReferenceConstants.DECISIONOUTCOMETYPE_DENIED   | StringUtils.EMPTY | HsrReferenceConstants.SPECIALPROCESSTYPE_CARECORE   | HsrReferenceConstants.UMRESPONSIBILITYTYPE_UHG_CASE | HsrReferenceConstants.DECISIONREASONTYPE_ADMINISTRATIVE_NO_REF | true
        true     | HsrReferenceConstants.DECISIONOUTCOMETYPE_DENIED   | StringUtils.EMPTY | HsrReferenceConstants.SPECIALPROCESSTYPE_CARECORE   | HsrReferenceConstants.UMRESPONSIBILITYTYPE_UHG_CASE | HsrReferenceConstants.DECISIONREASONTYPE_ADMINISTRATIVE_NO_REF | true
        // Test conditions when decision source comment is not required
        false    | HsrReferenceConstants.DECISIONOUTCOMETYPE_DENIED   | null              | HsrReferenceConstants.SPECIALPROCESSTYPE_PACIFICARE | HsrReferenceConstants.UMRESPONSIBILITYTYPE_PMG_CASE | HsrReferenceConstants.DECISIONREASONTYPE_ADMINISTRATIVE_NO_REF | true
        false    | HsrReferenceConstants.DECISIONOUTCOMETYPE_DENIED   | null              | HsrReferenceConstants.SPECIALPROCESSTYPE_PACIFICARE | HsrReferenceConstants.UMRESPONSIBILITYTYPE_UHG_CASE | HsrReferenceConstants.DECISIONREASONTYPE_NOT_COVERED_PMG_RISK  | false
        false    | HsrReferenceConstants.DECISIONOUTCOMETYPE_DENIED   | null              | HsrReferenceConstants.SPECIALPROCESSTYPE_PACIFICARE | HsrReferenceConstants.UMRESPONSIBILITYTYPE_UHG_CASE | HsrReferenceConstants.DECISIONREASONTYPE_PMG_IPA_NOT_APPROVED  | false
        false    | HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED | null              | HsrReferenceConstants.SPECIALPROCESSTYPE_PACIFICARE | HsrReferenceConstants.UMRESPONSIBILITYTYPE_UHG_CASE | HsrReferenceConstants.DECISIONREASONTYPE_PMG_IPA_APPROVED      | false
    }

    /**
     * Test that the decision source comment field is populated for a denied decision.
     */
    @Unroll()
    protected def "validateDecisionCancelled: validate that the decision reason and sub type is populated for a canceled rendered decision where isUpdate = #isUpdate"() {
        setup:
        def decisionVO = getNewRenderedHscDecisionVO(HsrReferenceConstants.DECISIONOUTCOMETYPE_CANCELED, true, reasonType, subType)
        def currentDecisionVO = getNewRenderedHscDecisionVO("anyValue", true)
        HscVO hscVO = new HscVO()

        when:
        abstractHscDecision.validate(decisionVO, isUpdate)

        then: "mock what is needed for test"
        1 * hscAlternateIdentifier.read(hscVO.hscID, HsrReferenceConstants.HSCALTERNATEIDTYPE_CAREONE_CASE_NUMBER)
        interaction { // interaction needed when mocking is defined in another local method
            defineCommonValidateMocks(currentDecisionVO, getNewDecisionSourceList(), hscVO)
        }

        and: "check expected results"
        ValueObjectAsserter.assertMessageExists(decisionVO, FieldConstants.DECISIONREASONTYPE, GlobalMessages.ERR_REQUIRED_VALUE)
        ValueObjectAsserter.assertMessageExists(decisionVO, FieldConstants.DECISIONSUBTYPE, GlobalMessages.ERR_REQUIRED_VALUE)

        where: "various test path combinations"
        // Test both add and update paths for null and empty string
        isUpdate | reasonType        | subType
        false    | null              | null
        true     | null              | null
        false    | StringUtils.EMPTY | StringUtils.EMPTY
        true     | StringUtils.EMPTY | StringUtils.EMPTY
    }

    /**
     * Test that the expected error message is added to the decision VO for a canceled decision if a prior canceled decision exists for the same service or facility.
     */
    @Unroll()
    protected def "validateDecisionCancelled: validate that a canceled decision cannot be saved if a prior canceled decision exists for the same service or facility where isUpdate = #isUpdate"() {
        setup:
        def decisionVO = getNewRenderedHscDecisionVO(HsrReferenceConstants.DECISIONOUTCOMETYPE_CANCELED, true)
        def currentDecisionVO = getNewRenderedHscDecisionVO(HsrReferenceConstants.DECISIONOUTCOMETYPE_CANCELED, true)
        HscVO hscVO = new HscVO()

        when:
        abstractHscDecision.validate(decisionVO, isUpdate)

        then: "mock what is needed for test"
        1 * hscAlternateIdentifier.read(hscVO.hscID, HsrReferenceConstants.HSCALTERNATEIDTYPE_CAREONE_CASE_NUMBER)
        interaction { // interaction needed when mocking is defined in another local method
            defineCommonValidateMocks(currentDecisionVO, getNewDecisionSourceList(), hscVO)
        }

        and: "check expected results"
        ValueObjectAsserter.assertMessageExists(decisionVO, FieldConstants.DECISIONOUTCOMETYPE, HscDecisionMessages.ERR_COVERAGE_REVIEW_ALREADY_CANCELLED)

        where: "various test path combinations"
        // Test both add and update paths for null and empty string
        isUpdate << [false, true]
    }

    /**
     * Test that the claim note field for a decision does not exceed the maximum allowed length.
     */
    @Unroll()
    protected def "validateClaimComments: validate that the claim note field for a decision does not exceed the maximum allowed length where isUpdate = #isUpdate"() {
        setup:
        def decisionVO = newHscDecisionVO()
        // Set claim note to max length
        decisionVO.setClaimNote(buildClaimNoteLimitString())
        // Combined claim note will be one character too long when new claim comment note appended to the claim note
        decisionVO.setNewClaimComments("x")
        def currentDecisionVO = getNewRenderedHscDecisionVO("anyValue", false)
        HscVO hscVO = new HscVO()

        when:
        abstractHscDecision.validate(decisionVO, isUpdate)

        then: "mock what is needed for test"
        1 * hscAlternateIdentifier.read(hscVO.hscID, HsrReferenceConstants.HSCALTERNATEIDTYPE_CAREONE_CASE_NUMBER)
        interaction { // interaction needed when mocking is defined in another local method
            defineCommonValidateMocks(currentDecisionVO, getNewDecisionSourceList(), hscVO)
        }

        and: "check expected results"
        ValueObjectAsserter.assertMessageExists(decisionVO, FieldConstants.CLAIMNOTE, HscDecisionMessages.ERR_COVERAGE_REVIEW_CLAIM_NOTE_TOO_LONG)

        where: "various test path combinations"
        // Test both add and update paths for null and empty string
        isUpdate << [false, true]
    }

    /**
     * Test that the decision VO has the ClaimCommentsFailure field set to true if the override claim remark code is SS and the claim note field is not populated.
     */
    @Unroll()
    protected def "validateClaimComments: validate that the decision VO has the ClaimCommentsFailure field set to true if the override claim remark code is SS and the claim note field is not populated where isUpdate = #isUpdate"() {
        setup:
        def decisionVO = newHscDecisionVO()
        decisionVO.setOverrideClaimRemarkCode(HsrReferenceConstants.CLAIMREMARKCODE_SPECIAL_SITUATION)
        decisionVO.setClaimNote(claimNote)
        def currentDecisionVO = getNewRenderedHscDecisionVO("anyValue", false)
        HscVO hscVO = new HscVO()

        when:
        abstractHscDecision.validate(decisionVO, isUpdate)

        then: "mock what is needed for test"
        1 * hscAlternateIdentifier.read(hscVO.hscID, HsrReferenceConstants.HSCALTERNATEIDTYPE_CAREONE_CASE_NUMBER)
        interaction { // interaction needed when mocking is defined in another local method
            defineCommonValidateMocks(currentDecisionVO, getNewDecisionSourceList(), hscVO)
        }

        and: "check expected results"
        decisionVO.isClaimCommentsFailure()

        where: "various test path combinations"
        // Test both add and update paths for null and empty string
        isUpdate | claimNote
        false    | null
        true     | null
        false    | StringUtils.EMPTY
        true     | StringUtils.EMPTY
    }

    /**
     * Test for claim comments not allowed for a decision VO that has a special proc type other than COSMOS and an override claim remark code other than SS.
     */
    @Unroll()
    protected def "validateClaimComments: validate that claim comments not allowed for a decision VO that has a special proc type other than COSMOS and an override claim remark code other than SS where isUpdate = #isUpdate"() {
        setup:
        def decisionVO = newHscDecisionVO()
        decisionVO.setSpecialProcessType("AnyValueOtherThanCOSMOS")
        decisionVO.setOverrideClaimRemarkCode("AnyValueOtherThanSS")
        decisionVO.setClaimNote(buildClaimNoteLimitString())
        def currentDecisionVO = getNewRenderedHscDecisionVO("anyValue", false)
        HscVO hscVO = new HscVO()

        when:
        abstractHscDecision.validate(decisionVO, isUpdate)

        then: "mock what is needed for test"
        1 * hscAlternateIdentifier.read(hscVO.hscID, HsrReferenceConstants.HSCALTERNATEIDTYPE_CAREONE_CASE_NUMBER)
        interaction { // interaction needed when mocking is defined in another local method
            defineCommonValidateMocks(currentDecisionVO, getNewDecisionSourceList(), hscVO)
        }

        and: "check expected results"
        ValueObjectAsserter.assertMessageExists(decisionVO, HscDecisionMessages.ERR_MSGID_CLAIM_COMMENTS_ALLOWED_WHEN_SS_OVERRIDE_CODE)

        where: "various test path combinations"
        // Test both add and update paths
        isUpdate << [false, true]
    }

    /**
     *     Story Name : PHS 1432 – Valid Override Claim Remark Codes for PHS cases test
     */

    protected def "validateoverrideClaimComments: validate that override Claim remark codes drop down options are- AN and DC when the HSC special process ID=13"() {
        setup:

        def AbstractHscDecisionVO decisionVO = new HscServiceDecisionVO()
        decisionVO.setOverrideClaimRemarkCode("AnyValue")
        def hscVO = new HscVO()
        String[] retval = [HsrReferenceConstants.CLAIMREMARKCODE_AN, HsrReferenceConstants.CLAIMREMARKCODE_DENIED]


        when:

        abstractHscDecision.determineValidOverrideClaimRemarkCodes(hscVO)

        then:
        1 * hscMemberCoverage.read(0, 0, [])
    }

    protected def "validateoverrideClaimComments: validate that override Claim remark codes drop down options are- AN and DC when the HSC special process ID!=13"() {
        setup:

        def AbstractHscDecisionVO decisionVO = new HscServiceDecisionVO()
        decisionVO.setOverrideClaimRemarkCode("AnyValue")
        def hscVO = new HscVO()
        String[] retval = [HsrReferenceConstants.CLAIMREMARKCODE_AN, HsrReferenceConstants.CLAIMPLATFORMID_EXTERNAL]


        when:

        abstractHscDecision.determineValidOverrideClaimRemarkCodes(hscVO)

        then:
        1 * hscMemberCoverage.read(0, 0, []) >> new HscMemberCoverageVO()
    }

    @Unroll()
    protected def "handleDecisionProviderLogic: #desc"() {
        setup:
        def decisionVO = newHscDecisionVO(END_USER_ID)
        decisionVO.setDecisionOutcomeType(decisionOutcomeType)
        decisionVO.setDecisionProviderSeqNum(decisionProviderSeqNum)

        when:
        abstractHscDecision.handleDecisionProviderLogic(hscProviderVO, decisionVO, paramSeqNum)

        then: "mock what is needed for test"
        if(hscProviderVO != null) {
            1 * hscDecisionProvider.createAndSaveDecisionProviderFromHscProvider(_) >> new HscDecisionProviderVO(decisionProviderSeqNum: 1)
        }
        0 * _._

        and: "check expected results"
        decisionVO.decisionProviderSeqNum == expectedSeqNum

        where:
        desc                     | decisionOutcomeType | decisionProviderSeqNum | hscProviderVO | paramSeqNum | expectedSeqNum
        "no decision"            | null                | (short) 0 | null | (short) 0 | (short) 0
        "decision has provider"  | "1"                 | (short) 1 | null | (short) 0 | (short) 1
        "decision set provider"  | "1"                 | (short) 0 | null | (short) 1 | (short) 1
        "decision read provider" | "1"                 | (short) 0 | new HscProviderVO() | (short) 0 | (short) 1
        "decision null provider" | "1"                 | (short) 0 | null | (short) 0 | (short) 0
    }

    protected def "setValuesForProviderUpdate"() {
        setup:
        def decisionVO = newHscDecisionVO(END_USER_ID)
        def decisionProviderSeqNum = (short) 1

        when:
        abstractHscDecision.setValuesForProviderUpdate(decisionVO, decisionProviderSeqNum, true)

        then: "check expected results"
        0 * _._
        !decisionVO.inactiveInd
        decisionVO.decisionSeqNum == 0
        decisionVO.decisionProviderSeqNum == decisionProviderSeqNum
        !decisionVO.writtenDecnCommDateTime
        decisionVO.decisionEnteredReasonType == HsrReferenceConstants.DECISIONENTEREDREASONTYPE_UPDATEPROVIDER
    }

    protected def "test listApprovedByHSC"() {
        given:
        long hscID = 1
        List<V> approvedDecisionList = [getNewRenderedHscDecisionVO(HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED, false)]
        QueryProperties qp = null

        when:
        List<V> decisionList = abstractHscDecision.listApprovedByHSC(hscID)

        then:
        1 * dao.list({ qp = it }) >> approvedDecisionList
        0 * _._
        qp.getQueryFilter(FieldConstants.HSCID).fieldValue == hscID
        qp.getQueryFilter(FieldConstants.DECISIONOUTCOMETYPE).fieldValue == HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED
        decisionList == approvedDecisionList
    }

    @Unroll()
    protected def "test validateRequestingProviderForPhsCases: #desc"() {
        setup:
        def decisionVO = getNewRenderedHscDecisionVO(HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED, false)
        HscVO hscVO = new HscVO(serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT,
                                specialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_PACIFICARE,
                                hscID: 1)

        when:
        abstractHscDecision.validate(decisionVO, isUpdate)

        then: "mock what is needed for test"
        interaction { // interaction needed when mocking is defined in another local method
            defineCommonValidateMocks(decisionVO, getNewDecisionSourceList(), hscVO, providerVO, new MemberVO())
        }

        and: "check expected results"
        if(providerVO == null) {
            ValueObjectAsserter.assertMessageExists(decisionVO, HscMessages.ERR_OUTPATIENT_REQUIRED_ROLES)
        }

        where:
        desc                                          | providerVO                                     | isUpdate
        "No requesting provider, isUpdate false"      | null                                           | false
        "No requesting provider, isUpdate true"       | null                                           | true
        "Requesting provider present, isUpdate false" | new HscProviderVO(requestingProviderInd: true) | false
        "Requesting provider present, isUpdate true"  | new HscProviderVO(requestingProviderInd: true) | true
    }

    protected def "test copyFacilityDecisionIntoServiceDecisionVO"() {
        given:
        HscFacilityDecisionVO hscFacilityDecisionVO = new HscFacilityDecisionVO(hscFacilityDecisionSourceVOs: [ new HscFacilityDecisionSourceVO() ])

        when:
        HscServiceDecisionVO hscServiceDecisionVO = abstractHscDecision.copyFacilityDecisionIntoServiceDecisionVO(hscFacilityDecisionVO)

        then:
        0 * _._
    }

    protected def "test handleDecisionCoverageLogic"() {
        given:
        HscMemberCoverageVO hscMemberCoverageVO = new HscMemberCoverageVO()
        HscFacilityDecisionVO hscFacilityDecisionVO = new HscFacilityDecisionVO(decisionOutcomeType: HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED)

        when:
        abstractHscDecision.handleDecisionCoverageLogic(hscMemberCoverageVO, hscFacilityDecisionVO, seqNbr)

        then:
        if(seqNbr == 0) {
            1 * hscDecisionMemberCoverage.add(_ as HscDecisionMemberCoverageVO)
        }
        0 * _._

        where: seqNbr << [ (short)0, (short)1 ]
    }

    protected def "test setPartialDecisionToCancelled"() {
        given:
        HscServiceDecisionVO hscServiceDecisionVO = new HscServiceDecisionVO(decisionOutcomeType: HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED)
        HscVO hscVO = new HscVO()

        when:
        abstractHscDecision.setPartialDecisionToCancelled(hscServiceDecisionVO, hscVO)

        then:
        1 * hsc.getDecisionReasonForHscStatusReason(HsrReferenceConstants.HSCSTATUSREASONTYPE_OPEN) >> HsrReferenceConstants.DECISIONREASONTYPE_BENEFITEXCLUSION
        1 * hsc.read(0) >> new HscVO()
        1 * hscAlternateIdentifier.read(0, '4') >> new HscAlternateIdentifierVO(hscAlternateID: "TEST")
        1 * dao.list(_ as QueryProperties)
        1 * customerReference.validateReference(_ as HscServiceDecisionVO, FieldConstants.DECISIONOUTCOMETYPE, '4', false)
        1 * customerReference.validateReference(_ as HscServiceDecisionVO, FieldConstants.DECISIONREASONTYPE, HsrReferenceConstants.DECISIONREASONTYPE_BENEFITEXCLUSION, false)
        1 * customerReference.validateReference(_ as HscServiceDecisionVO, FieldConstants.BENEFITEXCEPTIONTYPE, null, false)
        1 * customerReference.validateReference(_ as HscServiceDecisionVO, FieldConstants.DERIVEDCLAIMREMARKCODE, 'ZZ', false)
        1 * customerReference.validateReference(_ as HscServiceDecisionVO, FieldConstants.OVERRIDECLAIMREMARKCODE, null, false)
        1 * customerReference.validateReference(_ as HscServiceDecisionVO, FieldConstants.DECISIONEXTENSIONTYPE, null, false)
        2 * customerReference.validateReference(_ as HscServiceDecisionVO, FieldConstants.CONTACTROLETYPE, null, false)
        1 * persistenceHelper.update(_ as HscServiceDecisionVO)
        1 * hscServiceLineTatHelper.performUrJurisdictionForServiceLine(0L, _, true)
        0 * _._
    }

    protected def "test inactivateCurrentCreateNewCancelledDecision"() {
        given:
        HscServiceDecisionVO hscServiceDecisionVO = new HscServiceDecisionVO(decisionOutcomeType: HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED)
        HscVO hscVO = new HscVO()

        when:
        abstractHscDecision.inactivateCurrentCreateNewCancelledDecision(hscServiceDecisionVO, hscVO, HsrReferenceConstants.DECISIONREASONTYPE_MANDATE)

        then:
        1 * hsc.read(0) >> new HscVO()
        1 * hscAlternateIdentifier.read(0, '4') >> new HscAlternateIdentifierVO(hscAlternateID: "TEST")
        1 * customerReference.validateReference(_ as HscServiceDecisionVO, FieldConstants.DECISIONOUTCOMETYPE, HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED, false)
        1 * customerReference.validateReference(_ as HscServiceDecisionVO, FieldConstants.DECISIONREASONTYPE, null, false)
        1 * customerReference.validateReference(_ as HscServiceDecisionVO, FieldConstants.BENEFITEXCEPTIONTYPE, null, false)
        1 * customerReference.validateReference(_ as HscServiceDecisionVO, FieldConstants.DERIVEDCLAIMREMARKCODE, null, false)
        1 * customerReference.validateReference(_ as HscServiceDecisionVO, FieldConstants.OVERRIDECLAIMREMARKCODE, null, false)
        1 * customerReference.validateReference(_ as HscServiceDecisionVO, FieldConstants.DECISIONEXTENSIONTYPE, null, false)
        2 * customerReference.validateReference(_ as HscServiceDecisionVO, FieldConstants.CONTACTROLETYPE, null, false)
        2 * dao.list(_ as QueryProperties) >> [ new HscServiceDecisionVO() ]
        1 * persistenceHelper.update(_ as HscServiceDecisionVO)
        1 * hsc.readUnhydrated(0) >> new HscVO()
        0 * _._
    }

    protected def "test inactivateCurrentCreateNewCancelledDecision with HscFacilityDecisionVO"() {
        given:
        HscServiceDecisionVO hscServiceDecisionVO = new HscServiceDecisionVO(decisionOutcomeType: HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED)
        HscFacilityDecisionVO hscFacilityDecisionVO = new HscFacilityDecisionVO()

        when:
        abstractHscDecision.inactivateCurrentCreateNewCancelledDecision(hscServiceDecisionVO, hscFacilityDecisionVO)

        then:
        1 * hsc.read(0) >> new HscVO()
        1 * hscAlternateIdentifier.read(0, '4') >> new HscAlternateIdentifierVO(hscAlternateID: "TEST")
        1 * customerReference.validateReference(_ as HscServiceDecisionVO, FieldConstants.DECISIONOUTCOMETYPE, HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED, false)
        1 * customerReference.validateReference(_ as HscServiceDecisionVO, FieldConstants.DECISIONREASONTYPE, null, false)
        1 * customerReference.validateReference(_ as HscServiceDecisionVO, FieldConstants.BENEFITEXCEPTIONTYPE, null, false)
        1 * customerReference.validateReference(_ as HscServiceDecisionVO, FieldConstants.DERIVEDCLAIMREMARKCODE, null, false)
        1 * customerReference.validateReference(_ as HscServiceDecisionVO, FieldConstants.OVERRIDECLAIMREMARKCODE, null, false)
        1 * customerReference.validateReference(_ as HscServiceDecisionVO, FieldConstants.DECISIONEXTENSIONTYPE, null, false)
        2 * customerReference.validateReference(_ as HscServiceDecisionVO, FieldConstants.CONTACTROLETYPE, null, false)
        2 * dao.list(_ as QueryProperties) >> [ new HscServiceDecisionVO() ]
        1 * persistenceHelper.update(_ as HscServiceDecisionVO)
        1 * hsc.readUnhydrated(0) >> new HscVO()
        0 * _._
    }

    protected def "test hasOnlyApprovedDecisions"() {
        given:

        when:
        abstractHscDecision.hasOnlyApprovedDecisions(123456L)

        then:
        1 * dao.exists(_ as QueryProperties)
        0 * _._
    }

    protected def "test hasOnlyApprovedDeniedDecisions"() {
        given:

        when:
        abstractHscDecision.hasOnlyApprovedDeniedDecisions(123456L)

        then:
        1 * dao.exists(_ as QueryProperties)
        0 * _._
    }

    protected def "test hasOnlyDecisions"() {
        given:

        when:
        abstractHscDecision.hasOnlyDecisions(123456L)

        then:
        1 * dao.exists(_ as QueryProperties)
        0 * _._
    }

    protected def "test setFullNameOnUserIds"() {
        given:
        HscServiceDecisionVO hscServiceDecisionVO = new HscServiceDecisionVO(decisionOutcomeType: HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED,
                                                                             decisionMadeByUserID: decisionMadeByUser,
                                                                             decisionEnteredByUserID: decisionEnteredByUser)

        when:
        abstractHscDecision.setFullNameOnUserIds(hscServiceDecisionVO)

        then:
        1 * appUser.read('userID') >> madeByUserVO
        if(decisionMadeByUser != decisionEnteredByUser) {
            1 * appUser.read('enteredID') >> enteredByUserVO
        }
        0 * _._

        where:
        decisionMadeByUser | decisionEnteredByUser | madeByUserVO                        | enteredByUserVO
        'userID'           | 'enteredID'           | new AppUserVO(userID: 'userID')     | new AppUserVO(userID: 'enteredID')
        'userID'           | 'enteredID'           | new AppUserVO(userID: 'SYSTEM_ABC') | new AppUserVO(userID: 'enteredID')
        'userID'           | 'enteredID'           | new AppUserVO(userID: 'userID')     | new AppUserVO(userID: 'userID')
        'userID'           | 'enteredID'           | new AppUserVO(userID: 'userID')     | new AppUserVO(userID: 'SYSTEM_ABC')
        'userID'           | 'userID'              | new AppUserVO(userID: 'userID')     | new AppUserVO(userID: 'enteredID')
    }

    protected def "test executeAdd"() {
        given:
        HscServiceDecisionVO hscServiceDecisionVO = new HscServiceDecisionVO(decisionOutcomeType: HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED,
                                                                             claimCommentType: 'typeA')

        when:
        abstractHscDecision.executeAdd(hscServiceDecisionVO)

        then:
        1 * customerReference.getReferenceDescription(HsrNonPersistedFieldConstants.CLAIMCOMMENTTYPE, 'typeA')
        1 * persistenceHelper.add(_ as HscServiceDecisionVO)
        1 * tatPointHelper.logCoverageDecisionMadeTatPointForService(_ as HscServiceDecisionVO)
        0 * _._
    }

    /********* Protected helper methods **************/

    /**
     * Return a new instance of the extended AbstractHscDecisionSourceVO populated with default values.
     *
     * @return the new VO
     */
    protected S getNewDecisionSourceVO() {
        S decisionSourceVO = newDecisionSourceVO()
        decisionSourceVO.setCriteriaID("anyValue")
        decisionSourceVO.setDecisionSeqNum((short) 1)
        decisionSourceVO.setSourceSeqNum((short) 1)
        decisionSourceVO.setDecisionSourceType("anyValue")
        decisionSourceVO
    }

    /**
     * Return a new instance of a List containing a new extended AbstractHscDecisionSourceVO populated with default values.
     *
     * @return the new list containing the source VO
     */
    protected List<S> getNewDecisionSourceList() {
        [getNewDecisionSourceVO()]
    }

    /**
     * Return a new instance of the extended AbstractHscDecisionVO populated with specified values set.
     *
     * @param decisionOutcomeType the decision outcome type to set on the new VO
     * @param addPopulatedSourceList if true, set a populated decision source list on the new VO
     * @return the new populated decision VO
     */
    protected def V getNewRenderedHscDecisionVO(String decisionOutcomeType, boolean addPopulatedSourceList) {
        getNewRenderedHscDecisionVO(decisionOutcomeType, addPopulatedSourceList, "anyValue", "anyValue")
    }

    /**
     * Return a new instance of the extended AbstractHscDecisionVO populated with specified values that does not have a decision source list set.
     *
     * @param decisionOutcomeType the decision outcome type to set on the new VO
     * @param addPopulatedSourceList if true, set a populated decision source list on the new VO
     * @param decisionReasonType the decision reason type to set on the new VO
     * @param decisionSubType the decision sub type to set on the new VO
     * @return the new populated decision VO
     */
    protected def V getNewRenderedHscDecisionVO(String decisionOutcomeType, boolean addPopulatedSourceList, String decisionReasonType, String decisionSubType) {
        def vo = newHscDecisionVO()
        vo.setDecisionSeqNum((short) 1)
        vo.setDecisionOutcomeType(decisionOutcomeType)
        vo.setDecisionReasonType(decisionReasonType)
        vo.setDecisionSubType(decisionSubType)
        if(addPopulatedSourceList) {
            setDecisionSourceVOList(vo)
        }
        vo
    }

    /**
     * Create and return a ValueObject with error or warning message added as global message.
     * Will return a ValueObject with no message added if Message parameter is null.
     *
     * @param messageToAdd the error or warning message to add to the new VO - can be null
     * @return the new ValueObject with message added if one is passed in
     */
    protected def ValueObject getErrorVOWithGlobalMessage(Message messageToAdd) {
        def errorVO = new ValueObject()
        if(messageToAdd != null) {
            errorVO.addGlobalMessage(messageToAdd)
        }
        errorVO
    }

    /**
     * Define the minimum common mocks required for unit tests that call the main validate method in the abstract decision business class.
     * Sets a default empty HscProviderVO and MemberVO.
     *
     * @param currentDecisionVO the instance of the extended AbstractHscDecisionVO that will be mocked as the return value of the getCurrentDecision call
     * @param currentDecisionSourceList the List of AbstractHscDecisionSourceVO to set on the current decision VO
     * @param hscVO the HscVO that may be mocked in the read call in the getCurrentDecision method
     */
    protected def void defineCommonValidateMocks(V currentDecisionVO, List<S> currentDecisionSourceList, HscVO hscVO) {
        defineCommonValidateMocks(currentDecisionVO, currentDecisionSourceList, hscVO, new HscProviderVO(), new MemberVO())
    }

    /**
     * Define the minimum common mocks required for unit tests that call the main validate method in the abstract decision business class.
     *
     * @param currentDecisionVO the instance of the extended AbstractHscDecisionVO that will be mocked as the return value of the getCurrentDecision call
     * @param currentDecisionSourceList the List of AbstractHscDecisionSourceVO to set on the current decision VO
     * @param hscVO the HscVO that may be mocked in the read call in the getCurrentDecision method
     * @param providerVO the provider VO associated with decision that may be mocked in the validate flow
     * @param memberVO the member VO associated with the HSC that may be mocked in the validate flow
     */
    protected def void defineCommonValidateMocks(V currentDecisionVO, List<S> currentDecisionSourceList, HscVO hscVO, HscProviderVO providerVO, MemberVO memberVO) {
        1 * hsc.read(_) >> hscVO
        mockGetCurrentDecision(currentDecisionVO, currentDecisionSourceList, hscVO)
        mockReferences()
        mockGetProviderForDecision(providerVO)
        (0.._) * member.read(_) >> memberVO
    }

    /**
     * Define all mocks needed for the getCurrentDecision which is a common abstract method in the decision business class that is called in several of the test paths.
     *
     * @param currentDecisionVO the instance of the extended AbstractHscDecisionVO that will be mocked as the return value of the getCurrentDecision call.
     * @param decisionSourceList the List of AbstractHscDecisionSourceVO to set on the current decision VO
     * @param hscVO the HscVO that may be mocked in the read call in the getCurrentDecision method
     */
    protected def void mockGetCurrentDecision(V currentDecisionVO, List<S> decisionSourceList, HscVO hscVO) {
        def currentDecisionList = [currentDecisionVO]   // Add the mocked current decision VO to a list that will be mocked as the return from the mocked read
        (0.._) * dao.list(_) >> currentDecisionList     // This mocks the read in the getCurrentDecision method that is a read to get the current active decision for the case
        mockGetDecisionSourceList(decisionSourceList)   // This mocks the extended class specific business class method to get a list of decision sources
        (0.._) * hsc.read(_, _) >> hscVO
        (0.._) * hsc.readUnhydrated(_, _) >> hscVO
    }

    /**
     * Define all Reference.validateReference mocks for any of the unit test paths
     */
    protected def void mockReferences() {
        (1.._) * customerReference.validateReference(_, _, _, _)
    }

    /**
     * Return a string that equals the max length allowed for a claim note
     *
     * @return the populated string
     */
    protected String buildClaimNoteLimitString() {
        FieldDef fieldDef = FieldPropertyFactory.getInstance().getFieldDef(FieldConstants.CLAIMNOTE)
        int maxLength = fieldDef.getMaxlength()
        StringBuffer sbf = new StringBuffer(maxLength)
        while(sbf.length() < maxLength) {
            sbf.append("x")
        }

        return sbf.toString()
    }
}
