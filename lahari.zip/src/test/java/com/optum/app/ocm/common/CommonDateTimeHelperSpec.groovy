package com.optum.app.ocm.common

import com.optum.app.ocm.common.common.businesslogic.impl.CommonDateTimeHelperImpl
import com.optum.rf.core.util.UhgCalendar

import java.text.SimpleDateFormat

class CommonDateTimeHelperSpec extends CommonReadLogicSpecification {
    private CommonDateTimeHelperImpl helper

    def setup() {
        helper = new CommonDateTimeHelperImpl()
    }

    def "getOCMDateTime"() {
        given:
        def dateTimeString = "2000-01-01"
        Date dateTime = new SimpleDateFormat("yyyy-MM-dd").parse(dateTimeString)
        UhgCalendar uhgCalendar = new UhgCalendar(dateTime.time)

        when:
        def returnString = helper.getOCMDateTime(uhgCalendar)

        then:
        returnString == "01-01-2000 12:00:00"
        0 * _
    }
}
