package com.optum.app.ocm.hsr

import com.optum.rf.bl.spring.TransactionInterceptor
import com.optum.rf.core.locator.ServiceLocator
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.optum.app.common.hsr.businesslogic.impl.MemberProgramHscAssociationImpl
import com.optum.app.common.hsr.data.MemberProgramHscAssociationVO

class MemberProgramHscAssociationSpec extends HsrReadLogicSpecification {

    MemberProgramHscAssociationImpl memberProgramHscAssociation

    DataAccessObject dao
    PersistenceHelper persistenceHelper
    ServiceLocator serviceLocator
    TransactionInterceptor transactionInterceptor

    def setup() {
        dao = Mock(DataAccessObject)
        persistenceHelper = Mock(PersistenceHelper)
        serviceLocator = Mock(ServiceLocator)
        transactionInterceptor = Mock(TransactionInterceptor)

        memberProgramHscAssociation = new MemberProgramHscAssociationImpl(
                dao: dao,
                requiredPersistenceHelper: persistenceHelper,
                requiredServiceLocator: serviceLocator,
                requiredTransactionInterceptor: transactionInterceptor
        )
    }

    def "testValidAdd()"() {
        setup:
        MemberProgramHscAssociationVO vo = new MemberProgramHscAssociationVO()
        when:
        memberProgramHscAssociation.add(vo)
        then:
        1 * persistenceHelper.add(vo)
        0 * _._
    }

    def "testValidDelete()"() {
        setup:
        MemberProgramHscAssociationVO vo = new MemberProgramHscAssociationVO()
        when:
        memberProgramHscAssociation.delete(vo)
        then:
        1 * persistenceHelper.delete(vo)
        0 * _._
    }

    def "test isMemberProgramHscAssociation()"() {
        setup:

        when:
        memberProgramHscAssociation.isMemberProgramHscAssociation(12345L)

        then:
        1 * dao.exists(_ as QueryProperties)
        0 * _._
    }

    def "test listMemberProgramAssociationVO()"() {
        setup:

        when:
        memberProgramHscAssociation.listMemberProgramAssociationVO(12345L)

        then:
        1 * dao.list(_ as QueryProperties)
        0 * _._
    }

    def "test listAlreadyAssociatedMemberProgramHscAssociationVOS()"() {
        setup:

        when:
        memberProgramHscAssociation.listAlreadyAssociatedMemberProgramHscAssociationVOS(12345L)

        then:
        1 * dao.list(_ as QueryProperties)
        0 * _._
    }

    def "test getMemberProgramHscAssociationVOForDeletion()"() {
        setup:

        when:
        memberProgramHscAssociation.getMemberProgramHscAssociationVOForDeletion(1234L, 123456789L, 123456L)

        then:
        1 * dao.read(_ as ReadProperties)
        0 * _._
    }

    def "test getAssociatedHscIds()"() {
        setup:

        when:
        memberProgramHscAssociation.getAssociatedHscIds(1234L)

        then:
        1 * dao.list(_ as QueryProperties)
        0 * _._
    }

    def "test getListForHSCAndMemberPgmAssociation()"() {
        setup:

        when:
        memberProgramHscAssociation.getListForHSCAndMemberPgmAssociation(1234L)

        then:
        1 * dao.list(_ as QueryProperties)
        0 * _._
    }

    def "test isNotMemberProgramHscAssociation()"() {
        setup:

        when:
        memberProgramHscAssociation.isNotMemberProgramHscAssociation(123456L, 1234L, 123456789L)

        then:
        1 * dao.exists(_ as QueryProperties)
        0 * _._
    }

    def "test isMemberProgramAssociated()"() {
        setup:

        when:
        memberProgramHscAssociation.isMemberProgramAssociated(1234L)

        then:
        1 * dao.exists(_ as QueryProperties)
        0 * _._
    }

}
