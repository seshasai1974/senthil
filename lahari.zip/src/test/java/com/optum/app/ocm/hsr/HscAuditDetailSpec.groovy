package com.optum.app.ocm.hsr

import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.optum.app.common.hsr.businesslogic.impl.HscAuditDetailImpl
import com.optum.app.common.hsr.data.HscAuditDetailVO

class HscAuditDetailSpec extends HsrReadLogicSpecification {
    private HscAuditDetailImpl hscAuditDetail
    private PersistenceHelper persistenceHelper

    def setup() {
        hscAuditDetail = new HscAuditDetailImpl()
        persistenceHelper = Mock(PersistenceHelper)
        hscAuditDetail.requiredPersistenceHelper = persistenceHelper
    }

    def "testValidAdd()"() {
        setup:
        HscAuditDetailVO vo = new HscAuditDetailVO()
        when:
        hscAuditDetail.add(vo)
        then:
        1 * persistenceHelper.add(vo)
        0 * _._
    }

    def "testValidDelete()"() {
        setup:
        HscAuditDetailVO vo = new HscAuditDetailVO()
        when:
        hscAuditDetail.delete(vo)
        then:
        1 * persistenceHelper.delete(vo)
        0 * _._
    }    
}
