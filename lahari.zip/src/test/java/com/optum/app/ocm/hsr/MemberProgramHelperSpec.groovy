package com.optum.app.ocm.hsr

import com.optum.app.ocm.common.memberprogram.businesslogic.MemberProgram
import com.optum.app.common.hsr.businesslogic.impl.MemberProgramHelperImpl
import com.optum.app.common.memberprogram.constants.CpmReferenceConstants
import com.optum.app.common.memberprogram.data.MemberProgramVO
import com.optum.app.common.memberprogram.data.MemberProgramViewVO

class MemberProgramHelperSpec extends HsrReadLogicSpecification {

    MemberProgramHelperImpl memberProgramHelper

    MemberProgram memberProgram

    def setup() {
        memberProgram = Mock(MemberProgram)

        memberProgramHelper = new MemberProgramHelperImpl(
                memberProgram: memberProgram)
    }

    def "save closed"() {
        setup:
        long memberProgramID = (long) 1
        String memberProgramStatusType = CpmReferenceConstants.MEMBER_PROGRAM_CLOSED
        String memberProgramStatusReasonType = "2"
        String nominationSourceApplType = "3"
        String nominatingDepartmentType = "4"
        String nominationReasonType = "5"
        MemberProgramViewVO vo = new MemberProgramViewVO(memberProgramID: memberProgramID,
                memberProgramStatusType: memberProgramStatusType, memberProgramStatusReasonType: memberProgramStatusReasonType,
                nominationSourceApplType: nominationSourceApplType, nominatingDepartmentType: nominatingDepartmentType,
                nominationReasonType: nominationReasonType)
        MemberProgramVO memberProgramVO = new MemberProgramVO(memberProgramID: memberProgramID)

        when:
        memberProgramHelper.save(vo)

        then:
        1 * memberProgram.read(memberProgramID) >> memberProgramVO
        1 * memberProgram.save(_)
        memberProgramVO.memberProgramStatusType == memberProgramStatusType
        memberProgramVO.memberProgramStatusReasonType == memberProgramStatusReasonType
        memberProgramVO.nominationSourceApplType == nominationSourceApplType
        memberProgramVO.nominatingDepartmentType == nominatingDepartmentType
        memberProgramVO.nominationReasonType == nominationReasonType
        memberProgramVO.endDate != null
        0 * _._
    }

    def "save referral"() {
        setup:
        long memberProgramID = (long) 1
        String memberProgramStatusType = CpmReferenceConstants.MEMBER_PROGRAM_REFERRAL
        String memberProgramStatusReasonType = "2"
        String nominationSourceApplType = "3"
        String nominatingDepartmentType = "4"
        String nominationReasonType = "5"
        MemberProgramViewVO vo = new MemberProgramViewVO(memberProgramID: memberProgramID,
                memberProgramStatusType: memberProgramStatusType, memberProgramStatusReasonType: memberProgramStatusReasonType,
                nominationSourceApplType: nominationSourceApplType, nominatingDepartmentType: nominatingDepartmentType,
                nominationReasonType: nominationReasonType)
        MemberProgramVO memberProgramVO = new MemberProgramVO(memberProgramID: memberProgramID)

        when:
        memberProgramHelper.save(vo)

        then:
        1 * memberProgram.read(memberProgramID) >> memberProgramVO
        1 * memberProgram.save(_)
        memberProgramVO.memberProgramStatusType == memberProgramStatusType
        memberProgramVO.memberProgramStatusReasonType == memberProgramStatusReasonType
        memberProgramVO.nominationSourceApplType == nominationSourceApplType
        memberProgramVO.nominatingDepartmentType == nominatingDepartmentType
        memberProgramVO.nominationReasonType == nominationReasonType
        memberProgramVO.endDate == null
        0 * _._
    }
}
