package com.optum.app.ocm.hsr

import com.optum.rf.bl.spring.TransactionInterceptor
import com.optum.rf.core.locator.ServiceLocator
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.HscLetterRequestWSQueue
import com.optum.app.common.hsr.businesslogic.impl.HscLetterRequestWSQueueImpl
import com.optum.app.common.hsr.data.HscLetterRequestWSQueueVO
import spock.lang.Unroll

class HscLetterRequestWSQueueSpec extends HsrReadLogicSpecification {

    HscLetterRequestWSQueue hscLetterRequestWSQueue

    DataAccessObject dao
    PersistenceHelper persistenceHelper
    ServiceLocator serviceLocator
    TransactionInterceptor transactionInterceptor

    def setup() {
        dao = Mock(DataAccessObject)
        persistenceHelper = Mock(PersistenceHelper)
        serviceLocator = Mock(ServiceLocator)
        transactionInterceptor = Mock(TransactionInterceptor)

        hscLetterRequestWSQueue = new HscLetterRequestWSQueueImpl(
                dao: dao,
                requiredPersistenceHelper: persistenceHelper,
                requiredServiceLocator: serviceLocator,
                requiredTransactionInterceptor: transactionInterceptor
        )
    }

    @Unroll
    def "isValid #testCase"() {
        given:
        def hscID = (long) 1
        def letterRequestSeqNum = 2
        def rp = new ReadProperties(FieldConstants.HSCID, FieldConstants.LETTERREQUESTSEQNUM)
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        rp.setKeyValue(FieldConstants.LETTERREQUESTSEQNUM, letterRequestSeqNum)
        rp.fields = null

        when:
        boolean retVal = hscLetterRequestWSQueue.isValid(hscID, letterRequestSeqNum)

        then:
        1 * dao.isValid(rp) >> expectedVal
        0 * _
        retVal == expectedVal

        where:
        testCase | expectedVal
        "passes" | true
        "fails"  | false
    }

    def "Test to read HscLetterRequestWSQueueVO"() {
        setup:
        def hscID = (long) 1
        def letterRequestSeqNum = 2
        HscLetterRequestWSQueueVO hscLetterRequestWSQueueVO = new HscLetterRequestWSQueueVO(hscID: hscID, letterRequestSeqNum: letterRequestSeqNum)
        hscLetterRequestWSQueueVO.incrementRetryCount()
        def rp = new ReadProperties(FieldConstants.HSCID, FieldConstants.LETTERREQUESTSEQNUM)
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        rp.setKeyValue(FieldConstants.LETTERREQUESTSEQNUM, letterRequestSeqNum)
        rp.fields = null

        when:
        hscLetterRequestWSQueue.read(hscID, letterRequestSeqNum)

        then:
        1 * dao.read(rp) >> hscLetterRequestWSQueueVO
        0 * _
    }
}
