package com.optum.app.ocm.hsr

import com.optum.rf.bl.spring.TransactionInterceptor
import com.optum.rf.core.locator.ServiceLocator
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.HscLetterRequestElgsTask
import com.optum.app.common.hsr.businesslogic.HscLetterRequestElgsTaskVar
import com.optum.app.common.hsr.businesslogic.impl.HscLetterRequestElgsTaskImpl
import com.optum.app.common.hsr.data.HscLetterRequestElgsTaskVO
import com.optum.app.common.hsr.data.HscLetterRequestVO
import spock.lang.Unroll

class HscLetterRequestElgsTaskSpec extends HsrReadLogicSpecification {

    HscLetterRequestElgsTask hscLetterRequestElgsTask

    DataAccessObject dao
    PersistenceHelper persistenceHelper
    ServiceLocator serviceLocator
    TransactionInterceptor transactionInterceptor
    HscLetterRequestElgsTaskVar hscLetterRequestElgsTaskVar

    def setup() {
        dao = Mock(DataAccessObject)
        persistenceHelper = Mock(PersistenceHelper)
        serviceLocator = Mock(ServiceLocator)
        transactionInterceptor = Mock(TransactionInterceptor)
        hscLetterRequestElgsTaskVar = Mock(HscLetterRequestElgsTaskVar)

        hscLetterRequestElgsTask = new HscLetterRequestElgsTaskImpl(
                dao: dao,
                requiredPersistenceHelper: persistenceHelper,
                requiredServiceLocator: serviceLocator,
                requiredTransactionInterceptor: transactionInterceptor,
                hscLetterRequestElgsTaskVar: hscLetterRequestElgsTaskVar
        )
    }

    @Unroll
    def "isValid #testCase"() {
        given:
        def hscID = (long) 1
        def letterRequestSeqNum = 2
        def letterRequestLetterGenID = "3"
        def elgsTaskCode = "4"
        def rp = new ReadProperties(FieldConstants.HSCID, FieldConstants.LETTERREQUESTSEQNUM, FieldConstants.LETTERREQUESTLETTERGENID, FieldConstants.ELGSTASKCODE)
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        rp.setKeyValue(FieldConstants.LETTERREQUESTSEQNUM, letterRequestSeqNum)
        rp.setKeyValue(FieldConstants.LETTERREQUESTLETTERGENID, letterRequestLetterGenID)
        rp.setKeyValue(FieldConstants.ELGSTASKCODE, elgsTaskCode)
        rp.fields = null

        when:
        boolean retVal = hscLetterRequestElgsTask.isValid(hscID, letterRequestSeqNum, letterRequestLetterGenID, elgsTaskCode)

        then:
        1 * dao.isValid(rp) >> expectedVal
        0 * _
        retVal == expectedVal

        where:
        testCase | expectedVal
        "passes" | true
        "fails"  | false
    }

    def "Test to read HscLetterRequestElgsTaskVO"() {
        setup:
        def hscID = (long) 1
        def letterRequestSeqNum = 2
        def letterRequestLetterGenID = "3"
        def elgsTaskCode = "4"
        HscLetterRequestElgsTaskVO hscLetterRequestElgsTaskVO = new HscLetterRequestElgsTaskVO(hscID: hscID, letterRequestSeqNum: letterRequestSeqNum, letterRequestLetterGenID: letterRequestLetterGenID, elgsTaskCode: elgsTaskCode)
        def rp = new ReadProperties(FieldConstants.HSCID, FieldConstants.LETTERREQUESTSEQNUM, FieldConstants.LETTERREQUESTLETTERGENID, FieldConstants.ELGSTASKCODE)
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        rp.setKeyValue(FieldConstants.LETTERREQUESTSEQNUM, letterRequestSeqNum)
        rp.setKeyValue(FieldConstants.LETTERREQUESTLETTERGENID, letterRequestLetterGenID)
        rp.setKeyValue(FieldConstants.ELGSTASKCODE, elgsTaskCode)
        rp.fields = null

        when:
        hscLetterRequestElgsTask.read(hscID, letterRequestSeqNum, letterRequestLetterGenID, elgsTaskCode)

        then:
        1 * dao.read(rp) >> hscLetterRequestElgsTaskVO
        0 * _
    }

    def "Test readOrCreate"() {
        setup:
        def hscID = (long) 1
        def letterRequestSeqNum = 2
        def letterRequestLetterGenID = "3"
        def elgsTaskCode = "4"
        def rp = new ReadProperties(FieldConstants.HSCID, FieldConstants.LETTERREQUESTSEQNUM, FieldConstants.LETTERREQUESTLETTERGENID, FieldConstants.ELGSTASKCODE)
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        rp.setKeyValue(FieldConstants.LETTERREQUESTSEQNUM, letterRequestSeqNum)
        rp.setKeyValue(FieldConstants.LETTERREQUESTLETTERGENID, letterRequestLetterGenID)
        rp.setKeyValue(FieldConstants.ELGSTASKCODE, elgsTaskCode)
        rp.fields = null

        when:
        hscLetterRequestElgsTask.readOrCreate(hscID, letterRequestSeqNum, letterRequestLetterGenID, elgsTaskCode)

        then:
        1 * dao.read(rp)
        0 * _
    }

    def "Test hydrateHscLetterRequestVOs"() {
        setup:
        List<HscLetterRequestVO> hscLetterRequestVOList = [ new HscLetterRequestVO(hscID: 123456L) ]

        when:
        hscLetterRequestElgsTask.hydrateHscLetterRequestVOs(hscLetterRequestVOList)

        then:
        1 * dao.list(_ as QueryProperties) >> [ new HscLetterRequestElgsTaskVO() ]
        1 * hscLetterRequestElgsTaskVar.listDetails(123456, 0, null)
        0 * _
    }

}
