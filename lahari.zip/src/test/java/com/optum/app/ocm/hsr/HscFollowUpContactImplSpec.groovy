package com.optum.app.ocm.hsr

import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.Hsc
import com.optum.app.common.hsr.businesslogic.impl.HscFollowUpContactImpl
import com.optum.app.common.hsr.data.HscFollowUpContactVO
import com.optum.app.common.hsr.data.HscVO
import com.optum.app.ocm.constants.SecurityConstants

/**
 * Contains tests for com.optum.app.icue.hsr.hsc.businesslogic.impl.HscFollowUpContactImpl
 */

class HscFollowUpContactImplSpec extends HsrReadLogicSpecification {
    HscFollowUpContactImpl hscFollowUpContact

    DataAccessObject dao
    PersistenceHelper persistenceHelper
    Hsc hsc

    def setup() {
        hscFollowUpContact = new HscFollowUpContactImpl()
        dao = Mock(DataAccessObject)
        persistenceHelper = Mock(PersistenceHelper)
        hsc = Mock(Hsc)

        hscFollowUpContact.setRequiredDao(dao)
        hscFollowUpContact.setRequiredPersistenceHelper(persistenceHelper)
        hscFollowUpContact.setRequiredHsc(hsc)
    }

    def "Test isvalid hscId"() {
        when:
        hscFollowUpContact.isValid((long)1, (short)1)

        then:
        1 * dao.isValid(_)
        0 * _
    }

    def "Test valid delete"() {
        setup:
        HscFollowUpContactVO vo = new HscFollowUpContactVO(hscID: 34567, contactRoleType: "2")

        when:
        hscFollowUpContact.delete(vo)

        then:
        1 * persistenceHelper.delete(vo)
        0 * _
        !vo.errorMessagesExist()
    }
}