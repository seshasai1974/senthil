package com.optum.app.ocm.hsr

import com.optum.app.shared.constants.SpclCareReferenceConstants
import com.optum.rf.common.messages.GlobalMessages
import com.optum.rf.common.reference.businesslogic.util.ProcedureCode
import com.optum.rf.core.spring.ApplicationContextHolder
import com.optum.rf.core.util.UhgCalendar
import com.optum.rf.dao.exception.UhgRuntimeException
import com.optum.rf.dao.sql.query.QueryFilter
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.rf.dao.util.UhgCalendarUtilities
import com.optum.rf.test.core.assertion.ValueObjectAsserter
import com.optum.rf.test.core.mock.spring.MockWebApplicationContext
import com.optum.app.common.constants.CommonReferenceConstants
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.*
import com.optum.app.common.hsr.businesslogic.impl.HscServiceDecisionImpl
import com.optum.app.common.hsr.constants.HsrReferenceConstants
import com.optum.app.common.hsr.data.*
import com.optum.app.common.hsr.messages.HscDecisionMessages
import net.jawr.web.util.StringUtils
import spock.lang.Unroll

/**
 * Contains tests for com.optum.app.icue.hsr.hsc.businesslogic.impl.HscServiceDecisionImpl.
 */
class HscServiceDecisionImplSpec extends AbstractHscDecisionSpecification<HscServiceDecisionSourceVO, HscServiceDecisionVO>  {
    private HscServiceDecisionImpl hscServiceDecision
    private ProcedureCode procedureCode
    private HscServiceDecisionSource hscServiceDecisionSource
    private HscService hscService
    private HscServiceFacility hscServiceFacility
    private HscServiceNonFacility hscServiceNonFacility
    private HscAlternateIdentifier hscAlternateIdentifier
    private HscFacilityDecision hscFacilityDecision

    @Override
    protected HscServiceDecisionVO newHscDecisionVO(String... changeUserID) {
        def hscServiceDecisionVO = new HscServiceDecisionVO();
        hscServiceDecisionVO.changeUserID = changeUserID ?: hscServiceDecisionVO.changeUserID
        hscServiceDecisionVO
    }

    @Override
    protected HscServiceDecisionSourceVO newDecisionSourceVO() {
        new HscServiceDecisionSourceVO();
    }

    @Override
    protected void setDecisionSourceVOList(HscServiceDecisionVO vo) {
        vo.setHscServiceDecisionSourceVOs(getNewDecisionSourceList())
    }

    @Override
    protected void mockGetDecisionSourceList(List<HscServiceDecisionSourceVO> sourceList) {
        (0.._) * hscServiceDecisionSource.getHscServiceDecisionSourceList(_, _, _) >> sourceList
    }

    @Override
    protected HscProviderVO mockGetProviderForDecision(HscProviderVO providerVO) {
        (0..1) * hscService.read(_, _) >> new HscServiceVO(serviceProviderSeqNum: new Short("1"))
//        (0..1) * hscProvider.read(_, _) >> providerVO
//        (0..1) * hscProvider.readByRole(_, _) >> providerVO
    }

    @Override
    protected def setup() {
        hscServiceDecision = new HscServiceDecisionImpl()

        hscService = Mock(HscService)
        hscServiceDecisionSource = Mock(HscServiceDecisionSource)
        hscServiceFacility = Mock(HscServiceFacility)
        hscAlternateIdentifier = Mock(HscAlternateIdentifier)
        procedureCode = Mock(ProcedureCode)
        hscServiceNonFacility = Mock(HscServiceNonFacility)
        hscFacilityDecision = Mock(HscFacilityDecision)
        hscServiceDecision.setRequiredDao(dao)
        hscServiceDecision.setRequiredHscService(hscService)
        hscServiceDecision.setRequiredHscServiceFacility(hscServiceFacility)
        hscServiceDecision.setRequiredHscAlternateIdentifier(hscAlternateIdentifier)
        hscServiceDecision.setRequiredHscServiceNonFacility(hscServiceNonFacility)
        hscServiceDecision.setRequiredHscFacilityDecision(hscFacilityDecision)
        MockWebApplicationContext applicationContext = (MockWebApplicationContext) ApplicationContextHolder.getApplicationContext()
        applicationContext.setBean(HscServiceDecisionSource.class.name, hscServiceDecisionSource)

        // Do additional setup in abstract that requires a reference to this extended test class
        doSetup(hscServiceDecision)
    }

    /**
     *
     * Test that the expected error message is added to the decision VO when the service date for a non facility HSC service is outside of the member coverage*/
    @Unroll()
    def "validateServiceDetails: required coverage date for the decision service is within the member coverage for a non facility where service start date = #servStartDate and coverage date from #covEffectDate to #covEndDate"() {
        setup:
        def hscVO = new HscVO(serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT)
        def voToValidate = new HscServiceDecisionVO()
        def coverageVO = new HscMemberCoverageVO(coverageEffectiveDate: covEffectDate, coverageEndDate: covEndDate)
        def otherMemberCoverages = [coverageVO]
        // Put same coverage VO in mocked other coverage list to get same result as check on HSC coverage
        when:
        hscServiceDecision.validateServiceDetails(hscVO, voToValidate, coverageVO, false)

        then: "mock what is needed for test"

        where:
        servStartDate                             | covEffectDate                        | covEndDate
        new UhgCalendar().addDay(-1).getSQLDate() | UhgCalendarUtilities.getTodaysDate() | null
        new UhgCalendar().addDay(3).getSQLDate()  | UhgCalendarUtilities.getTodaysDate() | new UhgCalendar().addDay(1).getSQLDate()
    }

    /**
     *
     * Test that the expected error message is added to the decision VO when the expected procedure date for a facility HSC service is outside of the member coverage*/
    @Unroll()
    def "validateServiceDetails: required coverage date for the decision service is within the member coverage for a facility where expected procedure date = #expProcDate and coverage date from #covEffectDate to #covEndDate"() {
        setup:
        def hscVO = new HscVO(serviceSettingType: servSetType)
        def voToValidate = new HscServiceDecisionVO()
        def coverageVO = new HscMemberCoverageVO(coverageEffectiveDate: covEffectDate, coverageEndDate: covEndDate)
        def otherMemberCoverages = [coverageVO]
        // Put same coverage VO in mocked other coverage list to get same result as check on HSC coverage
        when:
        hscServiceDecision.validateServiceDetails(hscVO, voToValidate, coverageVO, false)

        then: "mock what is needed for test"

        where:
        expProcDate                               | covEffectDate                        | covEndDate                               | servSetType
        new UhgCalendar().addDay(-1).getSQLDate() | UhgCalendarUtilities.getTodaysDate() | null                                     | CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT
        new UhgCalendar().addDay(3).getSQLDate()  | UhgCalendarUtilities.getTodaysDate() | new UhgCalendar().addDay(1).getSQLDate() | CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT
        new UhgCalendar().addDay(-1).getSQLDate() | UhgCalendarUtilities.getTodaysDate() | null                                     | CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY
        new UhgCalendar().addDay(3).getSQLDate()  | UhgCalendarUtilities.getTodaysDate() | new UhgCalendar().addDay(1).getSQLDate() | CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY
    }

    /**
     *
     * Test that the expected error message is added to the decision VO when the service start date for a non facility HSC service is null*/
    def "validateServiceDetails: service start date for the decision service is not null for a non facility"() {
        setup:
        def hscVO = new HscVO(serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT)
        def voToValidate = new HscServiceDecisionVO()
        def coverageVO = new HscMemberCoverageVO(coverageEffectiveDate: UhgCalendarUtilities.getTodaysDate(), coverageEndDate: new UhgCalendar().addDay(1).getSQLDate())

        when:
        hscServiceDecision.validateServiceDetails(hscVO, voToValidate, coverageVO, false)

        then: "mock what is needed for test"

        and: "check expected results"
        notThrown(UhgRuntimeException)
    }

    def "getHscServiceDecisionHistoryList"() {
        setup:
        long hscID = 1
        HscServiceDecisionVO hscServiceDecisionVO = new HscServiceDecisionVO(hscID: hscID, decisionMemberCoverageSeqNum: 2, decisionProviderSeqNum: 3)

        when:
        def hscServiceDecisionHistoryList = hscServiceDecision.getHscServiceDecisionHistoryList(hscID, 1)

        then:
        1 * dao.list(_) >> [hscServiceDecisionVO, new HscServiceDecisionVO(hscID: hscID, decisionMemberCoverageSeqNum: 2)]
        0 * _._

        and:
        hscServiceDecisionHistoryList
    }

    def "validateDecisionSubtype non-PHS"() {
        setup:
        HscServiceDecisionVO hscServiceDecisionVO = new HscServiceDecisionVO(hscID: 40019403,
                decisionSubType: HsrReferenceConstants.DECISIONSUBTYPE_NOTIFICATIONONLY,
                decisionReasonType: HsrReferenceConstants.DECISIONREASONTYPE_BENEFITEXCLUSION,
                decisionOutcomeType: outcomeType,
                decisionSeqNum: 2,
                changeUserID: 'TEST',
                createDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone(),
                changeDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone(),
                specialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_LEGACY)
        HscVO hscVO = new HscVO(specialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_CARE_PROGRAMS)

        when:
        hscServiceDecision.validateDecisionSubtype(hscServiceDecisionVO, hscVO)

        then:
        if (hasErrorMessage) {
            ValueObjectAsserter.assertMessageExists(hscServiceDecisionVO,
                    FieldConstants.DECISIONSOURCETYPE,
                    HscDecisionMessages.ERR_MSGID_DECISION_SUBTYPE_NOTIFICATION_REQUIRES_BENEFIT_DOC_RESOURCE)
        } else {
            ValueObjectAsserter.assertErrorMessagesDoNotExist(hscServiceDecisionVO)
        }

        where:
        outcomeType                                        | hasErrorMessage
        HsrReferenceConstants.DECISIONOUTCOMETYPE_DENIED   | true
        HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED | true
        HsrReferenceConstants.DECISIONOUTCOMETYPE_CANCELED | false
    }

    def "validateDecisionSubtype PHS"() {
        setup:
        HscServiceDecisionVO hscServiceDecisionVO = new HscServiceDecisionVO(hscID: 40019403,
                decisionSubType: HsrReferenceConstants.DECISIONSUBTYPE_NOTIFICATIONONLY,
                decisionReasonType: decisionReasonType,
                decisionOutcomeType: outcomeType,
                decisionSeqNum: 2,
                changeUserID: 'TEST',
                createDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone(),
                changeDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone(),
                specialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_PACIFICARE)
        HscVO hscVO = new HscVO(specialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_PACIFICARE,
                umResponsibilityType: umResponsibility)

        when:
        hscServiceDecision.validateDecisionSubtype(hscServiceDecisionVO, hscVO)

        then:
        if (hasErrorMessage) {
            ValueObjectAsserter.assertMessageExists(hscServiceDecisionVO,
                    FieldConstants.DECISIONSOURCETYPE,
                    GlobalMessages.ERR_REQUIRED_VALUE)
        } else {
            ValueObjectAsserter.assertErrorMessagesDoNotExist(hscServiceDecisionVO)
        }

        where:
        umResponsibility                                    | outcomeType                                        | decisionReasonType                                             | hasErrorMessage
        HsrReferenceConstants.UMRESPONSIBILITYTYPE_PMG_CASE | null                                               | null                                                           | false

        HsrReferenceConstants.UMRESPONSIBILITYTYPE_UHG_CASE | HsrReferenceConstants.DECISIONOUTCOMETYPE_DENIED   | HsrReferenceConstants.DECISIONREASONTYPE_NOT_COVERED_PMG_RISK  | false
        HsrReferenceConstants.UMRESPONSIBILITYTYPE_UHG_CASE | HsrReferenceConstants.DECISIONOUTCOMETYPE_DENIED   | HsrReferenceConstants.DECISIONREASONTYPE_PMG_IPA_NOT_APPROVED  | false
        HsrReferenceConstants.UMRESPONSIBILITYTYPE_UHG_CASE | HsrReferenceConstants.DECISIONOUTCOMETYPE_DENIED   | HsrReferenceConstants.DECISIONREASONTYPE_ADMINISTRATIVE_NO_REF | true

        HsrReferenceConstants.UMRESPONSIBILITYTYPE_UHG_CASE | HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED | HsrReferenceConstants.DECISIONREASONTYPE_PMG_IPA_APPROVED      | false
        HsrReferenceConstants.UMRESPONSIBILITYTYPE_UHG_CASE | HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED | HsrReferenceConstants.DECISIONREASONTYPE_ADMINISTRATIVE_NO_REF | true

        HsrReferenceConstants.UMRESPONSIBILITYTYPE_UHG_CASE | HsrReferenceConstants.DECISIONOUTCOMETYPE_CANCELED | HsrReferenceConstants.DECISIONREASONTYPE_ADMINISTRATIVE_NO_REF | false
    }

    def "validateDecisionResources"() {
        setup:
        HscServiceDecisionVO hscServiceDecisionVO = new HscServiceDecisionVO(hscID: 40019403,
                decisionSubType: HsrReferenceConstants.DECISIONSUBTYPE_NOTIFICATIONONLY,
                decisionReasonType: HsrReferenceConstants.DECISIONREASONTYPE_BENEFITEXCLUSION,
                decisionSeqNum: 2,
                changeUserID: 'TEST',
                createDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone(),
                changeDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone(),
                specialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_LEGACY,
                hscServiceDecisionSourceVOs: decisionSourcesA)
        HscServiceDecisionVO currentHscServiceDecisionVO = new HscServiceDecisionVO(hscID: 40019403,
                decisionSubType: HsrReferenceConstants.DECISIONSUBTYPE_NOTIFICATIONONLY,
                decisionReasonType: HsrReferenceConstants.DECISIONREASONTYPE_BENEFITEXCLUSION,
                decisionOutcomeType: HsrReferenceConstants.DECISIONOUTCOMETYPE_DENIED,
                decisionSeqNum: 2,
                changeUserID: 'TEST',
                createDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone(),
                changeDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone(),
                specialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_LEGACY,
                hscServiceDecisionSourceVOs: decisionSourcesB)

        when:
        hscServiceDecision.validateDecisionResources(hscServiceDecisionVO, update, currentHscServiceDecisionVO)

        then:
        if (hasErrorMessage) {
            ValueObjectAsserter.assertErrorMessagesExist(hscServiceDecisionVO)
        } else {
            ValueObjectAsserter.assertErrorMessagesDoNotExist(hscServiceDecisionVO)
        }

        where:
        update | decisionSourcesA                                                                                                               | decisionSourcesB                                                                                                               | hasErrorMessage
        false  | null                                                                                                                           | null                                                                                                                           | false
        true   | null                                                                                                                           | null                                                                                                                           | false
        true   | null                                                                                                                           | [new HscServiceDecisionSourceVO(hscID: 23L, decisionSeqNum: 1), new HscServiceDecisionSourceVO(hscID: 23L, decisionSeqNum: 2)] | true
        true   | [new HscServiceDecisionSourceVO(hscID: 23L, decisionSeqNum: 1), new HscServiceDecisionSourceVO(hscID: 23L, decisionSeqNum: 2)] | [new HscServiceDecisionSourceVO(hscID: 23L, decisionSeqNum: 1), new HscServiceDecisionSourceVO(hscID: 23L, decisionSeqNum: 2)] | false
        true   | []                                                                                                                             | []                                                                                                                             | false
    }

    def "validateDecisionResources - same resource"() {
        setup:
        def serviceSource = new HscServiceDecisionSourceVO(hscID: 23L, decisionSeqNum: 1)
        HscServiceDecisionVO newDecision = new HscServiceDecisionVO(hscID: 40019403,
                decisionSubType: HsrReferenceConstants.DECISIONSUBTYPE_NOTIFICATIONONLY,
                decisionReasonType: HsrReferenceConstants.DECISIONREASONTYPE_BENEFITEXCLUSION,
                decisionSeqNum: 2,
                changeUserID: 'TEST',
                createDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone(),
                changeDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone(),
                specialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_LEGACY,
                hscServiceDecisionSourceVOs: [serviceSource, new HscServiceDecisionSourceVO(hscID: 23L, decisionSeqNum: 2)] // newSources
        )
        HscServiceDecisionVO currentDecision = new HscServiceDecisionVO(hscID: 40019403,
                decisionSubType: HsrReferenceConstants.DECISIONSUBTYPE_NOTIFICATIONONLY,
                decisionReasonType: HsrReferenceConstants.DECISIONREASONTYPE_BENEFITEXCLUSION,
                decisionOutcomeType: HsrReferenceConstants.DECISIONOUTCOMETYPE_DENIED,
                decisionSeqNum: 2,
                changeUserID: 'TEST',
                createDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone(),
                changeDateTime: UhgCalendarUtilities.getTodaysCalendarInUserTimeZone(),
                specialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_LEGACY,
                hscServiceDecisionSourceVOs: [serviceSource, new HscServiceDecisionSourceVO(hscID: 23L, decisionSeqNum: 3), new HscServiceDecisionSourceVO(hscID: 23L, decisionSeqNum: 4)] // priorSources
        )

        when:
        hscServiceDecision.validateDecisionResources(newDecision, true, currentDecision)

        then:
        ValueObjectAsserter.assertErrorMessagesExist(newDecision)
    }

    def "test isSingleDecisionMadeOnService when decision taken on at least one service line"() {
        setup:
        long hscId = 1234
        boolean inactiveInd = false
        def qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL, new QueryFilter(FieldConstants.HSCID, hscId),
                new QueryFilter(FieldConstants.INACTIVEIND, inactiveInd))
        qp.setOrderByAscFields(FieldConstants.SERVICESEQNUM)
        def hscServiceDecisionVOs = new ArrayList<HscServiceDecisionVO>()
        hscServiceDecisionVOs.add(new HscServiceDecisionVO(hscID: hscId, decisionOutcomeType: HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED))
        hscServiceDecisionVOs.add(new HscServiceDecisionVO(hscID: hscId, decisionOutcomeType: StringUtils.EMPTY))

        when:
        boolean anySingleDecisionMadeOnService = hscServiceDecision.isSingleDecisionMadeOnService(hscId)

        then:
        1 * dao.list(qp) >> hscServiceDecisionVOs
        hscServiceDecision.getCurrentDecisions(hscId, inactiveInd) >> hscServiceDecisionVOs
        hscServiceDecisionVOs.get(0).getHscID().equals(hscId)
        hscServiceDecisionVOs.get(0).getDecisionOutcomeType().equals(HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED)
        hscServiceDecisionVOs.get(1).getHscID().equals(hscId)
        anySingleDecisionMadeOnService.equals(true)
    }

    def "test isSingleDecisionMadeOnService when decision not taken on any service line"() {
        setup:
        long hscId = 5678
        boolean inactiveInd = false
        def qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL, new QueryFilter(FieldConstants.HSCID, hscId),
                new QueryFilter(FieldConstants.INACTIVEIND, inactiveInd))
        qp.setOrderByAscFields(FieldConstants.SERVICESEQNUM)
        def hscServiceDecisionVOs = new ArrayList<HscServiceDecisionVO>()
        hscServiceDecisionVOs.add(new HscServiceDecisionVO(hscID: hscId, decisionOutcomeType: StringUtils.EMPTY))
        hscServiceDecisionVOs.add(new HscServiceDecisionVO(hscID: hscId, decisionOutcomeType: StringUtils.EMPTY))

        when:
        boolean anySingleDecisionMadeOnService = hscServiceDecision.isSingleDecisionMadeOnService(hscId)

        then:
        1 * dao.list(qp) >> hscServiceDecisionVOs
        hscServiceDecision.getCurrentDecisions(hscId, inactiveInd) >> hscServiceDecisionVOs
        hscServiceDecisionVOs.get(0).getHscID().equals(hscId)
        hscServiceDecisionVOs.get(1).getHscID().equals(hscId)
        anySingleDecisionMadeOnService.equals(false)
    }

    def "test validateAnticipatedNextReviewDate - facility"() {
        setup:
            HscVO hscVO = new HscVO(hscID: 1);
        
            HscServiceDecisionVO hscServiceDecisionVO = new HscServiceDecisionVO(anticipatedNextReviewDate: UhgCalendarUtilities.getDateBefore(UhgCalendarUtilities.getSystemDateMinutePrecision().getSQLDate()))
        when:
            hscServiceDecision.validateAnticipatedNextReviewDate(hscVO, hscServiceDecisionVO);
        then:
            hscFacility.read(1) >> new HscFacilityVO(expectedAdmissionDate: UhgCalendarUtilities.getSystemDateMinutePrecision().getSQLDate())
            0 * _._
            hscServiceDecisionVO.errorMessagesExist()
    }

    def "test validateAnticipatedNextReviewDate - service facility"() {
        setup:
            HscVO hscVO = new HscVO(hscID: 1);
    
            HscServiceDecisionVO hscServiceDecisionVO = new HscServiceDecisionVO(anticipatedNextReviewDate: UhgCalendarUtilities.getDateBefore(UhgCalendarUtilities.getSystemDateMinutePrecision().getSQLDate()), serviceSeqNum: 1)
        when:
            hscServiceDecision.validateAnticipatedNextReviewDate(hscVO, hscServiceDecisionVO);
        then:
            hscServiceFacility.read(1, 1) >> new HscServiceFacilityVO(expectedProcedureDate: UhgCalendarUtilities.getSystemDateMinutePrecision().getSQLDate())
            0 * _._
            hscServiceDecisionVO.errorMessagesExist()
    }

    def "test getLastServiceDecision"() {
        setup:

        when:
        hscServiceDecision.getLastServiceDecision(123456L, (short)1)

        then:
        1 * dao.list(_ as QueryProperties)
        0 * _._
    }

    def "test hasServiceLineWithoutDecision"() {
        setup:

        when:
        hscServiceDecision.hasServiceLineWithoutDecision(123456L)

        then:
        1 * dao.list(_ as QueryProperties)
        0 * _._
    }

    def "test hasFirstApprovedOrCancelledDecision"() {
        setup:

        when:
        hscServiceDecision.hasFirstApprovedOrCancelledDecision(123456L, (short)1)

        then:
        1 * dao.exists(_ as QueryProperties)
        0 * _._
    }

    def "test hasOnlyApprovedOrCanceledDecisionsOrNoServiceLines"() {
        setup:
        HscVO hscVO = new HscVO(hscID: 1)

        when:
        boolean result = hscServiceDecision.hasOnlyApprovedOrCanceledDecisionsOrNoServiceLines(hscVO)

        then:
        1 * dao.list(_ as QueryProperties) >> [ new HscServiceDecisionVO(decisionOutcomeType: decisionOutcome) ]
        0 * _._

        and:
        result == expectedResult

        where:
        decisionOutcome                                    | expectedResult
        HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED | true
        HsrReferenceConstants.DECISIONOUTCOMETYPE_DENIED   | false
    }

    def "test hasAtLeastOneApprovedAndOnlyApprovedOrCanceledDecisions"() {
        setup:

        when:
        boolean result = hscServiceDecision.hasAtLeastOneApprovedAndOnlyApprovedOrCanceledDecisions(123456L)

        then:
        1 * dao.list(_ as QueryProperties) >> [ new HscServiceDecisionVO(decisionOutcomeType: decisionOutcome) ]
        0 * _._

        and:
        result == expectedResult

        where:
        decisionOutcome                                    | expectedResult
        HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED | true
        HsrReferenceConstants.DECISIONOUTCOMETYPE_DENIED   | false
    }

    def "test hasAtLeastOneDecision"() {
        setup:

        when:
        boolean result = hscServiceDecision.hasAtLeastOneDecision(123456L)

        then:
        1 * dao.list(_ as QueryProperties) >> [ new HscServiceDecisionVO(decisionOutcomeType: decisionOutcome) ]
        0 * _._

        and:
        result == expectedResult

        where:
        decisionOutcome                                    | expectedResult
        HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED | true
        HsrReferenceConstants.DECISIONOUTCOMETYPE_DENIED   | true
        null                                               | false
    }

    def "test calculateAndSetClaimRemarkCode"() {
        setup:
        HscServiceDecisionVO hscServiceDecisionVO = new HscServiceDecisionVO(decisionOutcomeType: HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED)
        HscMemberCoverageVO hscMemberCoverageVO = new HscMemberCoverageVO()

        when:
        hscServiceDecision.calculateAndSetClaimRemarkCode(hscServiceDecisionVO, hscMemberCoverageVO)

        then:
        1 * hsc.readUnhydrated(0) >> new HscVO(specialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_MAHP)
        0 * _._
    }

    def "test clearValidationFailures"() {
        setup:
        HscServiceDecisionVO hscServiceDecisionVO = new HscServiceDecisionVO()

        when:
        hscServiceDecision.clearValidationFailures(hscServiceDecisionVO)

        then:
        0 * _._
    }

    def "test clearOverrideScreenData"() {
        setup:
        HscServiceDecisionVO hscServiceDecisionVO = new HscServiceDecisionVO()

        when:
        hscServiceDecision.clearOverrideScreenData(hscServiceDecisionVO)

        then:
        0 * _._
    }

    def "test updateLetterRequestProperties"() {
        setup:
        HscServiceDecisionVO hscServiceDecisionVO = new HscServiceDecisionVO()

        when:
        hscServiceDecision.updateLetterRequestProperties(hscServiceDecisionVO)

        then:
        1 * persistenceHelper.updateSubset(_ as HscServiceDecisionVO, _ as String [], true)
        0 * _._
    }

    def "test updateLetterRequestProperties with List"() {
        setup:
        HscServiceDecisionVO hscServiceDecisionVO = new HscServiceDecisionVO(facilityLine: isFacility)
        HscFacilityDecisionVO hscFacilityDecisionVO = new HscFacilityDecisionVO()

        when:
        if(isFacility) {
            hscServiceDecision.updateLetterRequestProperties([hscFacilityDecisionVO])
        } else {
            hscServiceDecision.updateLetterRequestProperties([hscServiceDecisionVO])
        }

        then:
        if(isFacility) {
            1 * hscFacilityDecision.updateLetterRequestProperties(hscFacilityDecisionVO)
        } else {
            1 * persistenceHelper.updateSubset(_ as HscServiceDecisionVO, _ as String [], true)
        }
        0 * _._

        where: isFacility << [ false, true ]
    }

    def "test listCurrentApprovedByHscID"() {
        setup:

        when:
        hscServiceDecision.listCurrentApprovedByHscID(123456L)

        then:
        1 * dao.list(_ as QueryProperties)
        0 * _._
    }

    def "test listCurrentByHscID"() {
        setup:

        when:
        hscServiceDecision.listCurrentByHscID(123456L)

        then:
        1 * dao.list(_ as QueryProperties)
        0 * _._
    }

    def "test deleteByHscIDAndServiceSeqNum"() {
        setup:

        when:
        hscServiceDecision.deleteByHscIDAndServiceSeqNum(123456L, (short)1)

        then:
        1 * dao.list(_ as QueryProperties) >> [ new HscServiceDecisionVO() ]
        1 * persistenceHelper.delete(_ as HscServiceDecisionVO)
        0 * _._
    }

    def "test getMatchingServiceSeqNums"() {
        setup:
        HscServiceDecisionVO hscServiceDecisionVO = new HscServiceDecisionVO(serviceSeqNum: 2)

        when:
        hscServiceDecision.getMatchingServiceSeqNums(hscServiceDecisionVO)

        then:
        1 * dao.list(_ as QueryProperties) >> [ new HscServiceDecisionVO(serviceSeqNum: 2) ]
        0 * _._
    }

    @Unroll
    def "test areAllDecisionsApprovedOrDeniedOutcome"() {
        setup:

        when:
        boolean actual = hscServiceDecision.areAllDecisionsApprovedOrDeniedOutcome(1l)

        then:
        1 * dao.list(_ as QueryProperties) >> hscServiceDecisions
        0 * _._
        actual == expected

        where:
        description                                 |   hscServiceDecisions                                                                                                 | expected
        "one approved"                              |   [ new HscServiceDecisionVO(decisionOutcomeType: SpclCareReferenceConstants.DECISIONOUTCOMETYPE_COVERED_APPROVED) ]  | true
        "one of them wasn't approved or denied"     |   [ new HscServiceDecisionVO(decisionOutcomeType: SpclCareReferenceConstants.DECISIONOUTCOMETYPE_COVERED_APPROVED),
          new HscServiceDecisionVO(decisionOutcomeType: SpclCareReferenceConstants.DECISIONOUTCOMETYPE_CANCELLED) ]                                                         | false
        "empty list"                                |   [  ]                                                                                                                | false
        "null"                                      |   null                                                                                                                | false
    }

}
