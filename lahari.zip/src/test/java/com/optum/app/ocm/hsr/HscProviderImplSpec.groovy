package com.optum.app.ocm.hsr

import com.optum.app.common.hsr.businesslogic.HscProviderUnetContract
import com.optum.app.ocm.common.member.businesslogic.Member
import com.optum.app.ocm.common.provider.ProviderClinicalAddress
import com.optum.app.ocm.common.provider.businesslogic.ProviderClinical
import com.optum.app.ocm.ref.businesslogic.CustomerReference
import com.optum.app.shared.constants.SpclCareFeatureFlagConstants
import com.optum.rf.bl.factory.LogicTypeFactory
import com.optum.rf.common.featureflag.util.FeatureFlagManager
import com.optum.rf.common.featureflag.util.FeatureFlagUtility
import com.optum.rf.common.reference.businesslogic.ZipCodeTimeZone
import com.optum.rf.core.util.UhgCalendar
import com.optum.rf.dao.data.ValueObject
import com.optum.rf.dao.data.message.FieldMessage
import com.optum.rf.dao.data.message.Message
import com.optum.rf.dao.exception.UhgRuntimeException
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.exception.UpdateException
import com.optum.rf.dao.sql.query.QueryFilter
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.tabledef.TableDef
import com.optum.rf.dao.util.UhgCalendarUtilities
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.optum.rf.ref.core.data.ReferenceVO
import com.optum.app.common.constants.CommonReferenceConstants
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.Hsc
import com.optum.app.common.hsr.businesslogic.HscFacility
import com.optum.app.common.hsr.businesslogic.HscMemberCoverage
import com.optum.app.common.hsr.businesslogic.HscProviderInfoRequest
import com.optum.app.common.hsr.businesslogic.HscProviderRole
import com.optum.app.common.hsr.businesslogic.HscService
import com.optum.app.common.hsr.businesslogic.impl.HscProviderImpl
import com.optum.app.common.hsr.constants.CssReferenceConstants
import com.optum.app.common.hsr.constants.HsrReferenceConstants
import com.optum.app.common.hsr.data.HscFacilityVO
import com.optum.app.common.hsr.data.HscMemberCoverageVO
import com.optum.app.common.hsr.data.HscProviderContractAmendmentVO
import com.optum.app.common.hsr.data.HscProviderRoleVO
import com.optum.app.common.hsr.data.HscProviderVO
import com.optum.app.common.hsr.data.HscVO
import com.optum.app.common.hsr.messages.HscMessages
import com.optum.app.common.member.core.data.MemberVO
import com.optum.app.common.provider.data.ProviderClinicalAddressVO
import com.optum.app.common.provider.data.ProviderClinicalVO
import org.apache.commons.collections.CollectionUtils
import spock.lang.Unroll

class HscProviderImplSpec extends HsrReadLogicSpecification {

    private HscProviderImpl hscProvider = new HscProviderImpl()
    private DataAccessObject dao
    private PersistenceHelper persistenceHelper
    private Hsc hsc
    private HscService hscService
    private HscProviderRole hscProviderRole
    private HscMemberCoverage hscMemberCoverage
    private CustomerReference customerReference
    private HscFacility hscFacility
    private Member member
    private HscProviderInfoRequest hscProviderInfoRequest
    private ZipCodeTimeZone zipCodeTimeZone
    private ProviderClinical providerClinical
    private ProviderClinicalAddress providerClinicalAddress
    private HscProviderUnetContract hscProviderUnetContract

    def setup() {
        dao = Mock(DataAccessObject)
        persistenceHelper = Mock(PersistenceHelper)
        hsc = Mock(Hsc)
        hscService = Mock(HscService)
        hscProviderRole = Mock(HscProviderRole)
        hscMemberCoverage = Mock(HscMemberCoverage)
        customerReference = Mock(CustomerReference)
        hscFacility = Mock(HscFacility)
        hscProviderInfoRequest = Mock(HscProviderInfoRequest)
        zipCodeTimeZone = Mock(ZipCodeTimeZone)
        providerClinical = Mock(ProviderClinical)
        providerClinicalAddress = Mock(ProviderClinicalAddress)
        hscProviderUnetContract= Mock(HscProviderUnetContract)
        member = Mock(Member)
        FeatureFlagManager featureFlagManager = Mock(FeatureFlagManager)

        hscProvider.setRequiredDao(dao)
        hscProvider.setRequiredPersistenceHelper(persistenceHelper)
        hscProvider.setRequiredHsc(hsc)
        hscProvider.setRequiredHscFacility(hscFacility)
        hscProvider.setRequiredHscService(hscService)
        hscProvider.setRequiredHscProviderRole(hscProviderRole)
        hscProvider.setRequiredHscMemberCoverage(hscMemberCoverage)
        hscProvider.setRequiredCustomerReference(customerReference)
        hscProvider.setRequiredProviderClinical(providerClinical)
        hscProvider.setRequiredProviderClinicalAddress(providerClinicalAddress)
        hscProvider.setRequiredMember(member)
        hscProvider.hscProviderUnetContract = hscProviderUnetContract
        FeatureFlagUtility.featureFlagManager = featureFlagManager
    }

    def "Test to read HscProviderVO"() {
        setup:
        def hscID = (long) 1
        def providerSeqNum = (short) 2
        HscProviderVO hscProviderVO = new HscProviderVO(hscID: hscID, providerSeqNum: providerSeqNum)
        def rp = new ReadProperties(FieldConstants.HSCID, FieldConstants.PROVIDERSEQNUM)
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        rp.setKeyValue(FieldConstants.PROVIDERSEQNUM, providerSeqNum)
        rp.fields = null

        when:
        hscProvider.read(hscID, providerSeqNum)

        then:
        1 * hscProviderRole.list(hscProviderVO) >> new ArrayList<>()
        1 * dao.read(rp) >> hscProviderVO
        0 * _
    }

    def "Test saveProviderVO"() {
        setup:
        def hscID = (long) 1
        def providerSeqNum = (short) 2
        HscProviderVO hscProviderVO = new HscProviderVO(hscID: hscID, providerSeqNum: providerSeqNum)
        def rp = new ReadProperties(FieldConstants.HSCID, FieldConstants.PROVIDERSEQNUM)
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        rp.setKeyValue(FieldConstants.PROVIDERSEQNUM, providerSeqNum)
        rp.fields = null

        when:
        hscProvider.saveProviderVO(hscProviderVO)

        then:
        1 * dao.isValid(_) >> true
        1 * dao.read(_) >> hscProviderVO
        1 * dao.isDuplicate(_) >> true
        1 * hsc.read(hscID, []) >> new HscVO(hscID: hscID)
        2 * hscProviderRole.list(hscProviderVO) >> new ArrayList<>()
        1 * hscProviderRole.listRolesFromOtherProvidersByHscID(hscID, providerSeqNum) >> new ArrayList<>()
        1 * hscMemberCoverage.listByHscID(hscID)
        1 * persistenceHelper.update(_)
        1 * member.read(_)
        0 * _
    }

    def "add method with valid Inpatient data: should be success without exception"() {
        given:
        HscProviderVO hscProviderVO = createHscProviderVO()
        HscVO hscVO = getValidHscVO(hscProviderVO.getHscID(), CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT, HsrReferenceConstants.SPECIALPROCESSTYPE_LEGACY)
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: hscProviderVO.getHscID())

        when:
        hscProvider.add(hscProviderVO)

        then:
        1 * hscProviderRole.listRolesFromOtherProvidersByHscID(hscProviderVO.getHscID(), hscProviderVO.getProviderSeqNum()) >> new ArrayList<>()
        notThrown(UhgRuntimeException)
        !hscProviderVO.errorMessagesExist()
        2 * hsc.read(hscProviderVO.hscID) >> hscVO
        1 * persistenceHelper.add(hscProviderVO)
        2 * hscProviderRole.add(_ as HscProviderRoleVO) >> { HscProviderRoleVO hscProvRoleVO ->
            assert hscProviderVO.hscID == hscProvRoleVO.hscID
        }
        1 * hscMemberCoverage.listByHscID(hscProviderVO.getHscID())
        1 * hscService.cascadeProviderUpdateToServices(hscVO, hscProviderVO)
        1 * member.read(_)
        0 * _
    }

    def "add method with valid outpatient data: should be success without exception"() {
        given:
        HscProviderVO hscProviderVO = getValidHscProviderVO(HsrReferenceConstants.PROVIDERCATEGORY_ASSOCIATION, false)
        hscProviderVO.setServicingProviderInd(true)
        HscVO hscVO = getValidHscVO(hscProviderVO.getHscID(), CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT, HsrReferenceConstants.SPECIALPROCESSTYPE_LEGACY)

        when:
        hscProvider.add(hscProviderVO)

        then:
        1 * hscProviderRole.listRolesFromOtherProvidersByHscID(hscProviderVO.getHscID(), hscProviderVO.getProviderSeqNum()) >> new ArrayList<>()
        notThrown(UhgRuntimeException)
        !hscProviderVO.errorMessagesExist()
        1 * hsc.read(hscProviderVO.hscID) >> hscVO
        1 * persistenceHelper.add(hscProviderVO)
        1 * hscProviderRole.add(_ as HscProviderRoleVO) >> { HscProviderRoleVO hscProvRoleVO ->
            assert hscProviderVO.hscID == hscProvRoleVO.hscID
            assert HsrReferenceConstants.PROVIDER_ROLE_SERVICING == hscProvRoleVO.providerRole
        }
        1 * hscMemberCoverage.listByHscID(123)
        1 * member.read(_)
        0 * _
    }

    def "add method with valid outpatient Facility data: should be success without exception"() {
        given:
        HscProviderVO hscProviderVO = getValidHscProviderVO(HsrReferenceConstants.PROVIDERCATEGORY_PHYSICIAN, false)
        hscProviderVO.setAttendingProviderInd(true)
        hscProviderVO.setRequestingProviderInd(true)
        hscProviderVO.setPcpProviderInd(true)
        hscProviderVO.setServicingProviderInd(true)
        HscVO hscVO = getValidHscVO(hscProviderVO.getHscID(), CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY, HsrReferenceConstants.SPECIALPROCESSTYPE_LEGACY)

        when:
        hscProvider.add(hscProviderVO)

        then:
        1 * hscProviderRole.listRolesFromOtherProvidersByHscID(hscProviderVO.getHscID(), hscProviderVO.getProviderSeqNum()) >> new ArrayList<>()
        notThrown(UhgRuntimeException)
        !hscProviderVO.errorMessagesExist()
        1 * hsc.read(hscProviderVO.hscID) >> hscVO
        1 * persistenceHelper.add(hscProviderVO)
        4 * hscProviderRole.add(_ as HscProviderRoleVO) >> { HscProviderRoleVO hscProvRoleVO ->
            assert hscProviderVO.hscID == hscProvRoleVO.hscID
        }
        1 * hscMemberCoverage.listByHscID(hscProviderVO.getHscID())
        1 * member.read(_)
        0 * _
    }
/*
    @Ignore
    def "add method with valid Invalid Inpatient data: should throw exception"() {
        given:
        HscProviderVO hscProviderVO = new HscProviderVO(
                hscID: 123,
                facilityProviderInd: true
        )
        HscVO hscVO = getValidHscVO(hscProviderVO.getHscID(), CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT, HsrReferenceConstants.SPECIALPROCESSTYPE_LEGACY)
        when:
        hscProvider.add(hscProviderVO)

        then:
        thrown(UhgRuntimeException)
        doesMsgExists(hscProviderVO, FieldConstants.LASTNAME, new ConditionalReferenceErrorMessage(FieldConstants.PROVIDERCATEGORY,
                                                                                                   HsrReferenceConstants.PROVIDERCATEGORY_PHYSICIAN))
        doesMsgExists(hscProviderVO, GlobalMessages.ERR_UPDATE_ONLY)
        doesMsgExists(hscProviderVO, FieldConstants.PROVIDERROLE,
                      HscProviderMessages.ERR_INVALID_PROVIDER_ROLE_INPATIENT_PHYSICIAN)
        1 * hsc.read(hscProviderVO.hscID) >> hscVO
        1 * member.read(0, ['origSystemMemberIDType']) >> null
        1 * hscService.isProviderInUse(123L, (Short) 1) >> false
        1 * hscProviderRole.list(_ as QueryProperties) >> new ArrayList<HscProviderRoleVO>()
        1 * persistenceHelper.add(hscProviderVO)
        1 * dao.read(_ as ReadProperties) >> { ReadProperties rp ->
            assert rp.getKeyValue(FieldConstants.HSCID) == hscProviderVO.getHscID()
            assert rp.getKeyValue(FieldConstants.PROVIDERSEQNUM) == hscProviderVO.getProviderSeqNum()
            return hscProviderVO
        }
        1 * hscProviderRole.add(_)
        1 * hscMemberCoverage.listByHscID(hscProviderVO.getHscID())
        0 * _
    }
*/
    def "delete method with valid data: should be successful without exception"() {
        given:
        HscProviderVO hscProviderVO = new HscProviderVO(
                hscID: 123,
                facilityProviderInd: true,
                servicingProviderInd: true
        )
        when:
        HscProviderVO hscProviderVO2 = hscProvider.delete(hscProviderVO)

        then:
        1 * persistenceHelper.delete(hscProviderVO)
        !hscProviderVO2.errorMessagesExist()
        !hscProviderVO.errorMessagesExist()
        0 * _
    }

    def "cascade provider Update method  with Provider Updated: should update provider to all services lines"() {
        given:
        def hscProviderVO = new HscProviderVO(providerUpdated: true)
        def hscVO = new HscVO(specialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_PACIFICARE)

        when:
        hscProvider.cascadeProviderUpdate(hscProviderVO)

        then:
        1 * hsc.read(hscProviderVO.hscID) >> hscVO
        1 * hscService.cascadeProviderUpdateToServices(hscVO, hscProviderVO)
        0 * _
    }

    def "cascade provider update: with Provider not Updated: should not do anything"() {
        given:
        def hscProviderVO = new HscProviderVO(providerUpdated: false)

        when:
        hscProvider.cascadeProviderUpdate(hscProviderVO)

        then:
        0 * _
    }

    def "delete provider role: with facility Role: should call delete and should not update provider"() {
        given:
        HscProviderRoleVO roleVOList = new HscProviderRoleVO(providerRole: HsrReferenceConstants.PROVIDER_ROLE_FACILITY)
        def vo = new HscProviderVO(facilityProviderInd: true)

        when:
        hscProvider.deleteProviderRole(vo)

        then:
        1 * hscProviderRole.list(vo) >> [roleVOList]
        1 * hscProviderRole.delete(roleVOList)
        1 * hscFacility.read(0)
        0 * _

        and:
        !vo.isProviderUpdated()

    }

    def "delete provider role: without facility role: should call delete and update provider "() {
        given:
        HscProviderRoleVO roleVOList = new HscProviderRoleVO(providerRole: HsrReferenceConstants.PROVIDER_ROLE_SERVICING)
        def vo = new HscProviderVO(facilityProviderInd: true)

        when:
        hscProvider.deleteProviderRole(vo)

        then:
        1 * hscProviderRole.list(vo) >> [roleVOList]
        1 * hscProviderRole.delete(roleVOList)
        0 * _

        and:
        vo.isProviderUpdated()
    }

    def "save: with valid data: should be success without any exception"() {
        given:
        HscProviderVO hscProviderVO = new HscProviderVO(
                hscID: 123,
                facilityProviderInd: true,
                servicingProviderInd: true
        )
        HscVO hscVO = getValidHscVO(hscProviderVO.getHscID(), CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT, HsrReferenceConstants.SPECIALPROCESSTYPE_LEGACY)

        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: hscProviderVO.getHscID())

        when:
        hscProvider.save(hscProviderVO)

        then:
        1 * hscProviderRole.listRolesFromOtherProvidersByHscID(hscProviderVO.getHscID(), hscProviderVO.getProviderSeqNum()) >> new ArrayList<>()
        notThrown(UhgRuntimeException)
        !hscProviderVO.errorMessagesExist()
        1 * dao.isDuplicate(_ as QueryProperties) >> { QueryProperties qp ->
            assert qp.queryFilters.get(0).fieldValue == hscProviderVO.hscID
            false
        }
        2 * hsc.read(hscProviderVO.hscID) >> hscVO
        1 * persistenceHelper.add(hscProviderVO)
        1 * hscProviderRole.add(_ as HscProviderRoleVO) >> { HscProviderRoleVO hscProvRoleVO ->
            assert hscProvRoleVO.hscID == hscProviderVO.hscID
            assert hscProvRoleVO.providerRole == 'FA'
            assert hscProvRoleVO.facilityRole
        }
        1 * hscProviderRole.add(_ as HscProviderRoleVO) >> { HscProviderRoleVO hscProvRoleVO ->
            assert hscProvRoleVO.hscID == hscProviderVO.hscID
            assert hscProvRoleVO.providerRole == 'SJ'
            assert hscProvRoleVO.servicingRole
        }
        1 * hscMemberCoverage.listByHscID(123)
        1 * hscService.cascadeProviderUpdateToServices(hscVO, hscProviderVO)
        1 * member.read(_)
        0 * _
    }

    def "save: with valid csp Facet indicator"() {
        given:
        MemberVO memberVO = new MemberVO(memberID: 321L, origSystemMemberIDType: HsrReferenceConstants.ORIGSYSTEMMEMBERIDTYPE_AP)

        HscProviderVO hscProviderVO = new HscProviderVO(
                hscID: 123,
                facilityProviderInd: true,
                servicingProviderInd: true
        )
        HscVO hscVO = getValidHscVO(hscProviderVO.getHscID(), CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT, HsrReferenceConstants.SPECIALPROCESSTYPE_LEGACY)
        hscVO.memberID = memberVO.memberID

        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: hscProviderVO.getHscID())

        when:
        hscProvider.save(hscProviderVO)

        then:
        1 * hscProviderRole.listRolesFromOtherProvidersByHscID(hscProviderVO.getHscID(), hscProviderVO.getProviderSeqNum()) >> new ArrayList<>()
        notThrown(UhgRuntimeException)
        !hscProviderVO.errorMessagesExist()
        1 * dao.isDuplicate(_ as QueryProperties) >> { QueryProperties qp ->
            assert qp.queryFilters.get(0).fieldValue == hscProviderVO.hscID
            false
        }
        2 * hsc.read(hscProviderVO.hscID) >> hscVO
        1 * persistenceHelper.add(hscProviderVO)
        1 * hscProviderRole.add(_ as HscProviderRoleVO) >> { HscProviderRoleVO hscProvRoleVO ->
            assert hscProvRoleVO.hscID == hscProviderVO.hscID
            assert hscProvRoleVO.providerRole == 'FA'
            assert hscProvRoleVO.facilityRole
        }
        1 * hscProviderRole.add(_ as HscProviderRoleVO) >> { HscProviderRoleVO hscProvRoleVO ->
            assert hscProvRoleVO.hscID == hscProviderVO.hscID
            assert hscProvRoleVO.providerRole == 'SJ'
            assert hscProvRoleVO.servicingRole
        }
        1 * hscMemberCoverage.listByHscID(123)
        1 * hscService.cascadeProviderUpdateToServices(hscVO, hscProviderVO)
        1 * member.read(_) // from validate
        0 * _
    }

    def "save: with valid PHS data: should be success without any exception"() {
        given:
        HscProviderVO vo = createHscProviderVO()
        HscVO hscVO = getValidHscVO(vo.getHscID(), CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT, HsrReferenceConstants.SPECIALPROCESSTYPE_PACIFICARE)
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: vo.getHscID())

        when:
        hscProvider.save(vo)

        then:
        1 * hscProviderRole.listRolesFromOtherProvidersByHscID(vo.getHscID(), vo.getProviderSeqNum()) >> new ArrayList<>()
        notThrown(UhgRuntimeException)
        !vo.errorMessagesExist()
        1 * dao.isDuplicate(_ as QueryProperties) >> { QueryProperties qp ->
            assert qp.queryFilters.get(0).fieldValue == vo.hscID
            false
        }
        2 * hsc.read(vo.hscID) >> hscVO
        1 * persistenceHelper.add(vo)
        1 * hscProviderRole.add(_ as HscProviderRoleVO) >> { HscProviderRoleVO hscProvRoleVO ->
            assert hscProvRoleVO.hscID == vo.hscID
            assert hscProvRoleVO.providerRole == 'FA'
            assert hscProvRoleVO.facilityRole
        }
        1 * hscProviderRole.add(_ as HscProviderRoleVO) >> { HscProviderRoleVO hscProvRoleVO ->
            assert hscProvRoleVO.hscID == vo.hscID
            assert hscProvRoleVO.providerRole == 'SJ'
            assert hscProvRoleVO.servicingRole
        }
        1 * hscMemberCoverage.listByHscID(123)
        1 * hscService.cascadeProviderUpdateToServices(hscVO, vo)
        1 * member.read(_) // from validate
        0 * _
    }

    def "save: with too many providers"() {
        given:
        HscProviderVO hscProviderVO = new HscProviderVO(hscID: 11L)

        List<HscProviderVO> hscProviderVOs = new ArrayList()
        hscProviderVOs.add(new HscProviderVO(hscID: 23L))
        hscProviderVOs.add(new HscProviderVO(hscID: 24L))
        hscProviderVOs.add(new HscProviderVO(hscID: 25L))
        hscProviderVOs.add(new HscProviderVO(hscID: 26L))
        hscProviderVOs.add(new HscProviderVO(hscID: 27L))
        hscProviderVOs.add(new HscProviderVO(hscID: 28L))
        hscProviderVOs.add(new HscProviderVO(hscID: 29L))
        hscProviderVOs.add(new HscProviderVO(hscID: 30L))
        hscProviderVOs.add(new HscProviderVO(hscID: 31L))
        hscProviderVOs.add(new HscProviderVO(hscID: 32L))
        hscProviderVOs.add(new HscProviderVO(hscID: 33L))

        when:
        hscProvider.save(hscProviderVO)

        then:
        1 * hscProviderRole.listRolesFromOtherProvidersByHscID(hscProviderVO.getHscID(), hscProviderVO.getProviderSeqNum()) >> new ArrayList<>()
        notThrown(UhgRuntimeException)
        !hscProviderVO.errorMessagesExist()
        1 * dao.isDuplicate(_)
        1 * hsc.read(11L) >> new HscVO(hscID: 11L)
        1 * hscMemberCoverage.listByHscID(11)
        1 * persistenceHelper.add(_)
        1 * member.read(_) // from validate
        0 * _
    }

    def "afterAdd: should attempt to create an Assignment for the hscProviderVO"() {
        given:
        HscProviderVO hscProviderVO = createHscProviderVO()

        when:
        hscProvider.afterAdd(hscProviderVO)

        then:
        0 * _
    }

    @Unroll("add: #testCaseDesc - no exception")
    def "add method: with Manual Valid and Invalid TaxId And Suffix: should be successful without exception"() {
        given:
        HscProviderVO hscProviderVO = new HscProviderVO(
                hscID: 123,
                facilityProviderInd: true,
                servicingProviderInd: true
        )
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: hscProviderVO.getHscID())
        HscVO hscVO = getValidHscVO(hscProviderVO.getHscID(), CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT, HsrReferenceConstants.SPECIALPROCESSTYPE_LEGACY)

        when:
        hscProvider.add(hscProviderVO)

        then:
        1 * hscProviderRole.listRolesFromOtherProvidersByHscID(hscProviderVO.getHscID(), hscProviderVO.getProviderSeqNum()) >> new ArrayList<>()
        notThrown(UhgRuntimeException)
        !hscProviderVO.errorMessagesExist()
        2 * hsc.read(123) >> hscVO
        1 * hscService.cascadeProviderUpdateToServices(hscVO, hscProviderVO)
        1 * hscProviderRole.add(_ as HscProviderRoleVO) >> { HscProviderRoleVO hscProvRoleVO ->
            assert hscProvRoleVO.hscID == hscProviderVO.hscID
            assert hscProvRoleVO.providerRole == 'FA'
            assert hscProvRoleVO.facilityRole
        }
        1 * hscProviderRole.add(_ as HscProviderRoleVO) >> { HscProviderRoleVO hscProvRoleVO ->
            assert hscProvRoleVO.hscID == hscProviderVO.hscID
            assert hscProvRoleVO.providerRole == 'SJ'
            assert hscProvRoleVO.servicingRole
        }
        1 * persistenceHelper.add(hscProviderVO)
        1 * hscMemberCoverage.listByHscID(hscProviderVO.getHscID())
        1 * member.read(_) // from validate
        0 * _

        where:
        testCaseId | testCaseDesc                               | taxID       | taxSuffix
        1          | "valid Manual Tax id and Tax Suffix"       | "123456789" | "12345"
        1          | "Blank Manual Tax id and Tax Suffix"       | null        | null
        3          | "valid Manual Tax id and blank Tax Suffix" | "123456789" | null

    }

    @Unroll("add: #testCaseDesc - exception thrown")
    def "add method: with Invalid Manual TaxId And Suffix: should throw exception"() {
        given:
        HscProviderVO hscProviderVO = new HscProviderVO(
                hscID: 123,
                facilityProviderInd: true,
                servicingProviderInd: true
        )
        HscVO hscVO = getValidHscVO(hscProviderVO.getHscID(), CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT, HsrReferenceConstants.SPECIALPROCESSTYPE_LEGACY)

        when:
        hscProvider.add(hscProviderVO)

        then:
        1 * hscProviderRole.listRolesFromOtherProvidersByHscID(hscProviderVO.getHscID(), hscProviderVO.getProviderSeqNum()) >> new ArrayList<>()
//        thrown(UhgRuntimeException)
        !hscProviderVO.errorMessagesExist()
        2 * hsc.read(123) >> hscVO
        2 * hscProviderRole.add(_)
        1 * hscService.cascadeProviderUpdateToServices(_,_)
        1 * persistenceHelper.add(hscProviderVO)
        1 * hscMemberCoverage.listByHscID(hscProviderVO.getHscID())
        1 * member.read(_) // from validate
        0 * _

        where:
        testCaseId | testCaseDesc                                      | taxID   | taxSuffix
        1          | "Invalid Manual Tax id and Invalid Tax Suffix"    | "12345" | "123"
        2          | "Invalid Enterprise Tax id and   Tax Suffix"      | "12345" | "123"
        3          | "Invalid Enterprise Tax id and  blank Tax Suffix" | "98723" | null
    }

    def "list unique Providers by roles: should be successful with a no empty list"() {
        given:
        HscProviderVO hscProviderVO = new HscProviderVO(hscID: 23)

        when:
        List<HscProviderVO> hscProviderVOList = hscProvider.listUniqueProvidersByRoles(1l, HsrReferenceConstants.PROVIDER_ROLE_ADMITTING)

        then:
        notThrown(UhgRuntimeException)
        CollectionUtils.isNotEmpty(hscProviderVOList)
        1 * dao.list(_ as QueryProperties) >> { QueryProperties qp ->
            assert qp.queryFilters.get(0).fieldValue == 1L
            getHscProviderVOList(hscProviderVO)
        }
        1 * hscProviderRole.isRoleInList(hscProviderVO, "AD") >> true
        0 * _
    }

    def "get provider with matching sequence number: should return non empty provider"() {
        given:
        List<HscProviderVO> hscProviderVOList = new ArrayList<HscProviderVO>()
        hscProviderVOList.add(new HscProviderVO(hscID: 1l))

        when:
        HscProviderVO hscProviderVO = hscProvider.getProviderWithMatchingSequenceNumber(hscProviderVOList, (Short) 2)

        then:
        hscProviderVO == null
    }

    def "get provider with matching sequence number: with invalid provider Sequence Number: should return null"() {
        given:
        List<HscProviderVO> hscProviderVOList = new ArrayList<HscProviderVO>()
        hscProviderVOList.add(new HscProviderVO(hscID: 1l))

        when:
        HscProviderVO hscProviderVO = hscProvider.getProviderWithMatchingSequenceNumber(hscProviderVOList, (Short) 4)

        then:
        hscProviderVO == null
    }

    def "read by external authID: valid data: returns non null VO"() {
        given:
        List<HscProviderVO> hscProviderVOList = new ArrayList<HscProviderVO>()
        hscProviderVOList.add(new HscProviderVO(hscID: 1l))

        when:
        HscProviderVO hscProviderVO = hscProvider.readByExternalAuthID(1l)

        then:
        hscProviderVO != null
        1 * dao.list(_ as QueryProperties) >> { QueryProperties qp ->
            assert qp.queryFilters.get(0).fieldValue == 1L
            hscProviderVOList
        }
        0 * _
    }

    def "save: alternate fax data is saved to prov_clin tables for NICE providers"() {
        given:
        HscProviderVO hscProviderVO = new HscProviderVO(
                providerClinicalID: 1                )
        HscVO hscVO = new HscVO()
        when:
        hscProvider.save(hscProviderVO)

        then:
        1 * hscProviderRole.listRolesFromOtherProvidersByHscID(hscProviderVO.getHscID(), hscProviderVO.getProviderSeqNum()) >> new ArrayList<>()
        1 * dao.isDuplicate(_ as QueryProperties) >> { QueryProperties qp ->
            assert hscProviderVO.hscID == qp.queryFilters.get(0).fieldValue
            false
        }
        1 * hsc.read(0) >> new HscVO()
        1 * hscMemberCoverage.listByHscID(0)
        1 * persistenceHelper.add(hscProviderVO)
        1 * member.read(_) // from validate
        0 * _
    }

/*
    @Ignore
    def "update: with Invalid Test Outpatient Facility data"() {
        given:

        HscProviderVO hscProviderVO = getValidHscProviderVO(HsrReferenceConstants.PROVIDERCATEGORY_PHYSICIAN, true)
        hscProviderVO.setFacilityProviderInd(true)
        HscVO hscVO = new HscVO(
                hscID: hscProviderVO.getHscID(),
                serviceSettingType: CommonReferenceConstants.SERVICESETTINGTYPE_OUTPATIENT_FACILITY,
                specialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_LEGACY,
                hscStatusType: HsrReferenceConstants.HSCSTATUSTYPE_OPEN)
        List<HscProviderRoleVO> duplicateList = new ArrayList<HscProviderRoleVO>()
        duplicateList.add(new HscProviderRoleVO())

        when:
        hscProvider.update(hscProviderVO)

        then:
        thrown(UhgRuntimeException)
        1 * hsc.read(123) >> hscVO
        1 * member.read(0, ['origSystemMemberIDType']) >> null
        1 * hscProviderRole.list(_)
        1 * hscMemberCoverage.listByHscID(hscProviderVO.getHscID())
        1 * persistenceHelper.update(_)
        doesMsgExists(hscProviderVO, FieldConstants.PROVIDERROLE,
                      HscProviderMessages.ERR_INVALID_PROVIDER_ROLE_OUTPATIENTFACILITY_PHYSICIAN)
        doesMsgExists(hscProviderVO,
                      new ErrorMessage(HscProviderMessages.ERR_MSGID_INVALID_PROVIDER_ROLE_DUPLICATE, "Facility"))
        0 * _
    }*/

    def "update method: without contract amendment"() {
        given:
        HscProviderVO hscProviderVO = getValidHscProviderVO(HsrReferenceConstants.PROVIDERCATEGORY_PHYSICIAN, true)
        HscVO hscVO = getValidHscVO(hscProviderVO.getHscID(), CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT, HsrReferenceConstants.SPECIALPROCESSTYPE_LEGACY)

        when:
        hscProvider.update(hscProviderVO)

        then:
        1 * hscProviderRole.listRolesFromOtherProvidersByHscID(hscProviderVO.getHscID(), hscProviderVO.getProviderSeqNum()) >> new ArrayList<>()
        notThrown(UhgRuntimeException)
        !hscProviderVO.errorMessagesExist()
        1 * hsc.read(123) >> hscVO
        1 * hscProviderRole.list(hscProviderVO) >> new ArrayList<HscProviderRoleVO>()
        1 * hscMemberCoverage.listByHscID(hscProviderVO.getHscID())
        1 * persistenceHelper.update(hscProviderVO)
        1 * member.read(_) // from validate
        0 * _
    }

    def "update: with valid data"() {
        given:
        HscProviderVO hscProviderVO = getValidHscProviderVO(HsrReferenceConstants.PROVIDERCATEGORY_PHYSICIAN, true)
        List<HscProviderContractAmendmentVO> hscProviderContractAmendmentVOs = new ArrayList<HscProviderContractAmendmentVO>();

        HscProviderContractAmendmentVO hscProviderContractAmendmentVO = new HscProviderContractAmendmentVO(
                startDate: UhgCalendarUtilities.getTodaysDate(),
                endDate: UhgCalendarUtilities.getNextDay(UhgCalendarUtilities.getTodaysDate()),
                contractAmendmentSeqNum: 1,
                contractDocumentID: "1230000000004329384200012021903A",
                hscID: hscProviderVO.getHscID(),
                medicalNecessityTypeID: "1",
                providerContractAmendmentType: "BAS"
        )
        hscProviderContractAmendmentVOs.add(hscProviderContractAmendmentVO)
        hscProviderVO.setHscProviderContractAmendmentVOs(hscProviderContractAmendmentVOs)
        HscVO hscVO = getValidHscVO(hscProviderVO.getHscID(), CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT, HsrReferenceConstants.SPECIALPROCESSTYPE_LEGACY)

        when:
        hscProvider.update(hscProviderVO)

        then:
        1 * hscProviderRole.listRolesFromOtherProvidersByHscID(hscProviderVO.getHscID(), hscProviderVO.getProviderSeqNum()) >> new ArrayList<>()
        notThrown(UhgRuntimeException)
        !hscProviderVO.errorMessagesExist()
        1 * hsc.read(123) >> hscVO
        1 * hscProviderRole.list(hscProviderVO) >> new ArrayList<HscProviderRoleVO>()
        1 * persistenceHelper.update(hscProviderVO)
        1 * hscMemberCoverage.listByHscID(hscProviderVO.getHscID())
        1 * member.read(_) // from validate
        0 * _
    }

    def "get attending:with valid data"() {
        given:
        HscProviderVO hscProviderVO = new HscProviderVO(
                facilityProviderInd: true,
                attendingProviderInd: true
        )
        List<HscProviderVO> hscProviderVoList = new ArrayList<HscProviderVO>()
        hscProviderVoList.add(hscProviderVO)

        when:
        HscProviderVO providerVO = hscProvider.getAttending(hscProviderVoList)

        then:
        notThrown(UhgRuntimeException)
        providerVO != null
        !hscProviderVO.errorMessagesExist()
        0 * _
    }

    def "get attending:with invalid data"() {
        given:
        HscProviderVO hscProviderVO = new HscProviderVO(
                facilityProviderInd: false,
                attendingProviderInd: false
        )
        List<HscProviderVO> hscProviderVoList = new ArrayList<HscProviderVO>()
        hscProviderVoList.add(hscProviderVO)

        when:
        HscProviderVO providerVO = hscProvider.getAttending(hscProviderVoList)

        then:
        notThrown(UhgRuntimeException)
        providerVO == null
        !hscProviderVO.errorMessagesExist()
        0 * _
    }

    def "get facility role provider: with Valid Data"() {
        given:
        HscProviderVO hscProviderVO = createHscProviderVO()
        long hscID = 123

        when:
        HscProviderVO providerVO = hscProvider.getFacilityRoleProvider(hscID)

        then:
        notThrown(UhgRuntimeException)
        providerVO == null
        !hscProviderVO.errorMessagesExist()
        1 * dao.list(_ as QueryProperties) >> { QueryProperties qp ->
            assert hscID == qp.queryFilters.get(0).fieldValue
            getHscProviderVOList(hscProviderVO)
        }
        1 * hsc.read(hscID, _) >> new HscVO(hscID: hscID)
    }

    def "get facility role provider: with empty VOList"() {
        given:
        HscProviderVO hscProviderVO = createHscProviderVO()
        long hscID = 123456789
        hscProviderVO.hscID = hscID

        when:
        HscProviderVO providerVO = hscProvider.getFacilityRoleProvider(hscID)

        then:
        notThrown(UhgRuntimeException)
        !providerVO
        !hscProviderVO.errorMessagesExist()
        1 * dao.list(_ as QueryProperties) >> { QueryProperties qp ->
            assert hscID == qp.queryFilters.get(0).fieldValue
            getHscProviderVOList(new HscProviderVO(hscID: hscID))
        }
        1 * hsc.read(hscID, _) >> new HscVO(hscID: hscID)
    }

    def "get facility: with valid data"() {
        given:
        HscProviderVO vo = new HscProviderVO(
                facilityProviderInd: true
        )

        when:
        HscProviderVO providerVO = hscProvider.getFacility(getHscProviderVOList(vo))

        then:
        notThrown(UhgRuntimeException)
        providerVO != null
        !vo.errorMessagesExist()
    }

    def "get facility: without facility provider indicator"() {
        given:
        HscProviderVO vo = new HscProviderVO(
                facilityProviderInd: false
        )

        when:
        HscProviderVO providerVO = hscProvider.getFacility(getHscProviderVOList(vo))

        then:
        notThrown(UhgRuntimeException)
        providerVO == null
        !vo.errorMessagesExist()
    }

    def "get requesting: with Valid data"() {
        given:
        HscProviderVO vo = new HscProviderVO(
                facilityProviderInd: true,
                requestingProviderInd: true
        )

        when:
        HscProviderVO providerVO = hscProvider.getRequesting(getHscProviderVOList(vo))

        then:
        notThrown(UhgRuntimeException)
        providerVO != null
        !vo.errorMessagesExist()
    }

    def "get requesting: with null data"() {
        given:
        HscProviderVO vo = new HscProviderVO(
                facilityProviderInd: false,
                requestingProviderInd: false
        )

        when:
        HscProviderVO providerVO = hscProvider.getRequesting(getHscProviderVOList(vo))

        then:
        notThrown(UhgRuntimeException)
        providerVO == null
        !vo.errorMessagesExist()
        0 * _
    }

    def "read by role: with Valid data"() {
        given:
        HscProviderVO vo = createHscProviderVO()
        long hscID = 123456789
        String role = "PCP"
        HscProviderVO readVO = new HscProviderVO(hscID: 23L)

        when:
        HscProviderVO resultVO = hscProvider.readByRole(hscID, role)

        then:
        notThrown(UhgRuntimeException)
        !vo.errorMessagesExist()
        1 * dao.list(_ as QueryProperties) >> { QueryProperties qp ->
            assert hscID == qp.queryFilters.get(0).fieldValue
            getHscProviderVOList(readVO)
        }
        _ * hscProviderUnetContract.read(*_)
        1 * hscProviderRole.isRole(readVO, "PCP") >> true
        0 * _

        expect:
        resultVO.hscID == readVO.hscID
    }

    def "read by role: with empty VOList"() {
        given:
        long hscID = 123456789
        String role = "PCP"

        when:
        HscProviderVO resultVO = hscProvider.readByRole(hscID, role)

        then:
        !resultVO
        1 * dao.list(_ as QueryProperties) >> { QueryProperties qp ->
            assert hscID == qp.queryFilters.get(0).fieldValue
        }
        0 * _
    }

    def "read facility: with Valid data"() {
        given:
        HscProviderVO vo = createHscProviderVO()
        long hscID = 123456789

        when:
        hscProvider.readFacility(hscID)

        then:
        notThrown(UhgRuntimeException)
        !vo.errorMessagesExist()
        1 * dao.list(_ as QueryProperties) >> { QueryProperties qp ->
            assert hscID == qp.queryFilters.get(0).fieldValue
            getHscProviderVOList(vo)
        }
        1 * hscProviderRole.isFacility(vo) >> getHscProviderVOList(new HscProviderVO(hscID: 23))
    }

    def "read facility: with empty VOList"() {
        given:
        long hscID = 123456789

        when:
        HscProviderVO resultVO = hscProvider.readFacility(hscID)

        then:
        !resultVO
        1 * dao.list(_ as QueryProperties) >> { QueryProperties qp ->
            assert hscID == qp.queryFilters.get(0).fieldValue
        }
        0 * _
    }

    def "validate: with valid data"() {
        given:
        HscProviderVO vo = createHscProviderVOWithRoles()
        HscVO hscVO = getValidHscVO(vo.getHscID(), CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT, HsrReferenceConstants.SPECIALPROCESSTYPE_LEGACY)
        hscVO.businessClassificationType = HsrReferenceConstants.BUS_CLS_TYP_ID_E_AND_I

        when:
        hscProvider.validate(vo)

        then:
        notThrown(UhgRuntimeException)
        !vo.errorMessagesExist()
        1 * dao.isDuplicate(_ as QueryProperties) >> { QueryProperties qp ->
            assert vo.hscID == qp.queryFilters.get(0).fieldValue
            false
        }
        1 * hsc.read(vo.hscID) >> hscVO
        1 * hscMemberCoverage.listByHscID(vo.getHscID())
        1 * hscProviderRole.listRolesFromOtherProvidersByHscID(vo.getHscID(), vo.getProviderSeqNum()) >> new ArrayList<>()
        1 * member.read(_)
        0 * _
    }

    def "validate: with duplicate provider roles"() {
        given:
        HscProviderVO vo = createHscProviderVOWithRoles()
        HscVO hscVO = getValidHscVO(vo.getHscID(), CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT, HsrReferenceConstants.SPECIALPROCESSTYPE_LEGACY)
        hscVO.businessClassificationType = HsrReferenceConstants.BUS_CLS_TYP_ID_E_AND_I
        List<HscProviderRoleVO> existingProviderRoleList = getExistingProviderRoleList()

        when:
        hscProvider.validate(vo)

        then:
        notThrown(UhgRuntimeException)
        vo.errorMessagesExist()
        1 * dao.isDuplicate(_ as QueryProperties) >> { QueryProperties qp ->
            assert vo.hscID == qp.queryFilters.get(0).fieldValue
            false
        }
        1 * hsc.read(vo.hscID) >> hscVO
        1 * hscMemberCoverage.listByHscID(vo.getHscID())
        1 * hscProviderRole.listRolesFromOtherProvidersByHscID(vo.getHscID(), vo.getProviderSeqNum()) >> existingProviderRoleList
        1 * member.read(_)
        0 * _
        
        and:
        doesMsgExists(vo, FieldConstants.PROVIDERROLE + HsrReferenceConstants.PROVIDER_ROLE_FACILITY, HscMessages.ERR_INVALID_PROVIDER_ROLE_ONLY_ONE_FACILITY)
        doesMsgExists(vo, FieldConstants.PROVIDERROLE + HsrReferenceConstants.PROVIDER_ROLE_ATTENDING, HscMessages.ERR_INVALID_PROVIDER_ROLE_ONLY_ONE_ATTENDING_PROV)
        doesMsgExists(vo, FieldConstants.PROVIDERROLE + HsrReferenceConstants.PROVIDER_ROLE_REQUESTING, HscMessages.ERR_INVALID_PROVIDER_ROLE_ONLY_ONE_REQUESTING_PROV)
        doesMsgExists(vo, FieldConstants.PROVIDERROLE + HsrReferenceConstants.PROVIDER_ROLE_ADMITTING, HscMessages.ERR_INVALID_PROVIDER_ROLE_ONLY_ONE_ADMITTING_PROV)
        doesMsgExists(vo, FieldConstants.PROVIDERROLE + HsrReferenceConstants.PROVIDER_ROLE_PRIMARY_CARE_PROVIDER, HscMessages.ERR_INVALID_PROVIDER_ROLE_ONLY_ONE_PCP)
    }

    def "add with valid manual cosmos provider data"() {
        given:
        HscProviderVO hscProviderVO = createHscProviderVO()

        ReferenceVO referenceVO = new ReferenceVO(
                referenceDesc: "COSMOS",
                referenceDisplay: "COSMOS",
                referenceName: "COSMOS"
        )
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: hscProviderVO.getHscID())
        HscVO hscVO = getValidHscVO(hscProviderVO.getHscID(), CommonReferenceConstants.SERVICESETTINGTYPE_INPATIENT, HsrReferenceConstants.SPECIALPROCESSTYPE_COSMOS)

        when:
        hscProvider.add(hscProviderVO)

        then:
        1 * hscProviderRole.listRolesFromOtherProvidersByHscID(hscProviderVO.getHscID(), hscProviderVO.getProviderSeqNum()) >> new ArrayList<>()
        notThrown(UhgRuntimeException)
        !hscProviderVO.errorMessagesExist()
        1 * hscService.cascadeProviderUpdateToServices(hscVO, hscProviderVO)
        2 * hsc.read(hscProviderVO.hscID) >> hscVO
        1 * persistenceHelper.add(hscProviderVO)
        1 * hscProviderRole.add(_ as HscProviderRoleVO) >> { HscProviderRoleVO hscProvRoleVO ->
            assert hscProvRoleVO.hscID == hscProviderVO.hscID
            assert hscProvRoleVO.providerRole == 'FA'
            assert hscProvRoleVO.facilityRole
        }
        1 * hscProviderRole.add(_ as HscProviderRoleVO) >> { HscProviderRoleVO hscProvRoleVO ->
            assert hscProvRoleVO.hscID == hscProviderVO.hscID
            assert hscProvRoleVO.providerRole == 'SJ'
            assert hscProvRoleVO.servicingRole
        }
        1 * hscMemberCoverage.listByHscID(hscProviderVO.getHscID()) >> getCosmosMemberCoverageList()
        1 * member.read(_) // from validate
        0 * _
    }

    def "setNonPersistedItemsAndDisplayValues"() {
        given:
        HscProviderVO vo = createHscProviderVOWithRoles()
        List<HscProviderContractAmendmentVO> hscProviderContractAmendmentVOs = new ArrayList<HscProviderContractAmendmentVO>()
        HscProviderContractAmendmentVO hscProviderContractAmendmentVO1 = new HscProviderContractAmendmentVO(hscID: 1, contractAmendmentSeqNum: 1, providerSeqNum: 1, startDate: java.sql.Date.valueOf("2012-07-01"), endDate: java.sql.Date.valueOf("2012-12-31"))
        HscProviderContractAmendmentVO hscProviderContractAmendmentVO2 = new HscProviderContractAmendmentVO(hscID: 1, contractAmendmentSeqNum: 2, providerSeqNum: 1, startDate: java.sql.Date.valueOf("2012-12-01"), endDate: java.sql.Date.valueOf("2013-04-01"))
        hscProviderContractAmendmentVOs.add(hscProviderContractAmendmentVO1)
        hscProviderContractAmendmentVOs.add(hscProviderContractAmendmentVO2)
        vo.setHscProviderContractAmendmentVOs(hscProviderContractAmendmentVOs)

        when:
        hscProvider.setNonPersistedItemsAndDisplayValues(vo)

        then:
        notThrown(UhgRuntimeException)
        !vo.errorMessagesExist()
        1 * hsc.read(123, []) >> new HscVO(hscID: 123, hscStatusType: "1")
        1 * hscProviderRole.list(vo) >> vo.getHscProviderRoleVOs()
        1 * providerClinical.read(1, []) >> new ProviderClinicalVO(providerClinicalID: 1)
        1 * providerClinicalAddress.getProviderPermanentAddress(1) >> null
        1 * customerReference.getReferenceDisplay(FieldConstants.PROVIDERROLE, HsrReferenceConstants.PROVIDER_ROLE_REQUESTING) >> "Requesting"
        1 * customerReference.getReferenceDisplay(FieldConstants.PROVIDERROLE, HsrReferenceConstants.PROVIDER_ROLE_ADMITTING) >> "Admitting"
        1 * customerReference.getReferenceDisplay(FieldConstants.PROVIDERROLE, HsrReferenceConstants.PROVIDER_ROLE_ATTENDING) >> "Attending"
        1 * customerReference.getReferenceDisplay(FieldConstants.PROVIDERROLE, HsrReferenceConstants.PROVIDER_ROLE_PRIMARY_CARE_PROVIDER) >> "PCP"
        1 * customerReference.getReferenceDisplay(FieldConstants.PROVIDERROLE, HsrReferenceConstants.PROVIDER_ROLE_FACILITY) >> "Facility"
        1 * customerReference.getReferenceDisplay(FieldConstants.PROVIDERROLE, HsrReferenceConstants.PROVIDER_ROLE_SERVICING) >> "Servicing"
        0 * _
    }

    def "set non persisted items: with valid data"() {
        given:
        HscProviderVO vo = createHscProviderVOWithRoles()
        List<HscProviderContractAmendmentVO> hscProviderContractAmendmentVOs = new ArrayList<HscProviderContractAmendmentVO>()
        HscProviderContractAmendmentVO hscProviderContractAmendmentVO1 = new HscProviderContractAmendmentVO(hscID: 1, contractAmendmentSeqNum: 1, providerSeqNum: 1, startDate: java.sql.Date.valueOf("2012-07-01"), endDate: java.sql.Date.valueOf("2012-12-31"))
        HscProviderContractAmendmentVO hscProviderContractAmendmentVO2 = new HscProviderContractAmendmentVO(hscID: 1, contractAmendmentSeqNum: 2, providerSeqNum: 1, startDate: java.sql.Date.valueOf("2012-12-01"), endDate: java.sql.Date.valueOf("2013-04-01"))
        hscProviderContractAmendmentVOs.add(hscProviderContractAmendmentVO1)
        hscProviderContractAmendmentVOs.add(hscProviderContractAmendmentVO2)
        vo.setHscProviderContractAmendmentVOs(hscProviderContractAmendmentVOs)

        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: 1, actualAdmissionDateTime: new UhgCalendar(2012, 8, 12))

        when:
        hscProvider.setNonPersistedRoles(vo)

        then:
        notThrown(UhgRuntimeException)
        !vo.errorMessagesExist()
        1 * hscProviderRole.list(vo) >> vo.getHscProviderRoleVOs()
        1 * customerReference.getReferenceDisplay(FieldConstants.PROVIDERROLE, HsrReferenceConstants.PROVIDER_ROLE_REQUESTING) >> "Requesting"
        1 * customerReference.getReferenceDisplay(FieldConstants.PROVIDERROLE, HsrReferenceConstants.PROVIDER_ROLE_ADMITTING) >> "Admitting"
        1 * customerReference.getReferenceDisplay(FieldConstants.PROVIDERROLE, HsrReferenceConstants.PROVIDER_ROLE_ATTENDING) >> "Attending"
        1 * customerReference.getReferenceDisplay(FieldConstants.PROVIDERROLE, HsrReferenceConstants.PROVIDER_ROLE_PRIMARY_CARE_PROVIDER) >> "PCP"
        1 * customerReference.getReferenceDisplay(FieldConstants.PROVIDERROLE, HsrReferenceConstants.PROVIDER_ROLE_FACILITY) >> "Facility"
        1 * customerReference.getReferenceDisplay(FieldConstants.PROVIDERROLE, HsrReferenceConstants.PROVIDER_ROLE_SERVICING) >> "Servicing"
        0 * _
    }

    def "is valid: with valid data"() {
        given:
        HscProviderVO vo = createHscProviderVO()
        Long hscID = 123456789
        Short providerSeqNo = 2

        when:
        boolean isValid = hscProvider.isValid(hscID as Long, providerSeqNo as Short)

        then:
        1 * dao.isValid(_ as ReadProperties) >> { ReadProperties rp ->
            assert rp.getKeys().equals(["hscID", "providerSeqNum"])
            assert rp.getKeyValue("hscID") == hscID
            assert rp.getKeyValue("providerSeqNum") == providerSeqNo
            vo
        }
        0 * _
        isValid
    }

    def "Test for list Hsc Provider By Member Id For Open Hscs"() {
        given:
        long memberId = 123456789
        long hscID = 1231
        long providerClinicalID = 333
        List<HscVO> hscVOs = [new HscVO(hscID: hscID)]
        List<HscProviderVO> hscProviderList = [new HscProviderVO(hscID: hscID, providerClinicalID: providerClinicalID)]
        List<HscProviderRoleVO> roleVOs = new ArrayList<>()
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: 1, actualAdmissionDateTime: new UhgCalendar(2012, 8, 12))

        when:
        List<HscProviderVO> providerList = hscProvider.listHscProviderByMemberIdForOpenHscs(memberId)

        then:
        providerList.get(0).hscID == hscProviderList.get(0).hscID
        1 * hsc.listHscByMemberHscStatus(memberId, HsrReferenceConstants.HSCSTATUSTYPE_OPEN) >> hscVOs
        1 * dao.list(_ as QueryProperties) >> { QueryProperties qp ->
            assert qp.queryFilters.get(0).fieldValue == hscVOs.get(0).hscID
            hscProviderList
        }
        1 * hscProviderRole.list(hscProviderList.get(0)) >> roleVOs
        1 * hsc.read(hscID, []) >> new HscVO(hscID: hscID, hscStatusType: HsrReferenceConstants.HSCSTATUSTYPE_OPEN)
        1 * providerClinical.read(providerClinicalID, [])
        1 * providerClinicalAddress.getProviderPermanentAddress(providerClinicalID)
        _ * hscProviderUnetContract.read(*_)
        0 * _
    }

    def "updateFacilityIpcmTypeID: oldIpcmTypeID update process"() {
        given:
        HscProviderRoleVO hscProviderRoleVO = new HscProviderRoleVO()
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: 1, actualAdmissionDateTime: new UhgCalendar(2012, 8, 12), ipcmTypeID: CssReferenceConstants.IPCM_TYPE_ID_NO)

        when:
        hscProvider.updateFacilityIpcmTypeID(hscProviderRoleVO)

        then:
        1 * hscFacility.read(hscProviderRoleVO.getHscID()) >> hscFacilityVO
        1 * hscFacility.updateIpcmTypeID(hscFacilityVO) >> { HscFacilityVO hscFacVO ->
            assert hscFacilityVO.ipcmTypeID == hscFacVO.ipcmTypeID
            hscFacVO.ipcmTypeID = CssReferenceConstants.IPCM_TYPE_ID_YES
        }
        1 * hscFacility.update(hscFacilityVO)
        0 * _

        expect:
        CssReferenceConstants.IPCM_TYPE_ID_YES == hscFacilityVO.ipcmTypeID
    }

    def "Test for update Subset"() {
        given:
        HscProviderVO hscProviderVO = new HscProviderVO(hscID: 123l, facilityProviderInd: true)
        String[] updateFields = []

        when:
        hscProvider.updateSubset(hscProviderVO, updateFields)

        then:
        1 * persistenceHelper.updateSubset(hscProviderVO, updateFields, true)
        0 * _
    }

    def "Test for update Subset exception"() {
        given:
        HscProviderVO hscProviderVO = new HscProviderVO(hscID: 123l, facilityProviderInd: true)
        String[] updateFields = []

        when:
        hscProvider.updateSubset(hscProviderVO, updateFields)

        then:
        1 * persistenceHelper.updateSubset(hscProviderVO, updateFields, true) >> { throw new UpdateException() }
        0 * _

        then:
        thrown(UhgRuntimeException)
    }

    def "Test for validate For Short Form"() {
        given:
        HscProviderVO vo = new HscProviderVO()

        when:
        hscProvider.validateForShortForm(vo)

        then:
        0 * _
    }

    @Unroll
    def "Test setDisplayValues #providerNameToDisplay"() {
        setup:
        def hscID = (long) 1
        HscProviderVO hscProviderVO = new HscProviderVO(hscID: hscID, providerClinicalID: 1)
        ProviderClinicalVO providerClinicalVO = new ProviderClinicalVO(providerClinicalID: 1, businessName: businessName, firstName: firstName, lastName: lastName)
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        qp.addQueryFilter(new QueryFilter(FieldConstants.HSCID, hscID))
        qp.setOrderByAscFields(FieldConstants.PROVIDERSEQNUM)

        when:
        HscProviderVO returnVO = hscProvider.setDisplayValues(hscProviderVO)

        then:
        returnVO.providerNameToDisplay == providerNameToDisplay
        1 * providerClinical.read(1) >> providerClinicalVO
        1 * providerClinicalAddress.getProviderPermanentAddress(hscID) >> null
        1 * hsc.read(1, []) >> new HscVO(hscID: hscID, hscStatusType: HsrReferenceConstants.HSCSTATUSTYPE_OPEN)
        0 * _

        where:
        providerNameToDisplay | businessName   | firstName   | lastName
        "businessname"        | "businessname" | "firstname" | "lastname"
        "lastname, firstname" | ""             | "firstname" | "lastname"
        "lastname"            | ""             | ""          | "lastname"
        "firstname"           | ""             | "firstname" | ""
        ""                    | ""             | ""          | ""
        ""                    | null           | null        | null
    }

    @Unroll
    def "Test setDisplayValues #addressToDisplay"() {
        setup:
        def hscID = (long) 1
        HscProviderVO hscProviderVO = new HscProviderVO(hscID: hscID, providerClinicalID: 1)
        ProviderClinicalAddressVO providerClinicalAddressVO = new ProviderClinicalAddressVO(providerClinicalID: 1, address1: address1, city: city, state: state, zip: zip)
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        qp.addQueryFilter(new QueryFilter(FieldConstants.HSCID, hscID))
        qp.setOrderByAscFields(FieldConstants.PROVIDERSEQNUM)

        when:
        HscProviderVO returnVO = hscProvider.setDisplayValues(hscProviderVO)

        then:
        returnVO.addressToDisplay == addressToDisplay
        1 * providerClinical.read(hscID) >> null
        1 * providerClinicalAddress.getProviderPermanentAddress(hscID) >> providerClinicalAddressVO
        1 * hsc.read(1, []) >> new HscVO(hscID: hscID, hscStatusType: HsrReferenceConstants.HSCSTATUSTYPE_OPEN)
        0 * _

        where:
        addressToDisplay            | address1   | city   | state   | zip
        "address1, city state, zip" | "address1" | "city" | "state" | "zip"
        "address1, city state"      | "address1" | "city" | "state" | ""
        "address1, city, zip"       | "address1" | "city" | ""      | "zip"
        "address1, state, zip"      | "address1" | ""     | "state" | "zip"
        "address1, zip"             | "address1" | ""     | ""      | "zip"
        "city state, zip"           | ""         | "city" | "state" | "zip"
        "state, zip"                | ""         | ""     | "state" | "zip"
        "zip"                       | ""         | ""     | ""      | "zip"
        ""                          | ""         | ""     | ""      | ""
        ""                          | null       | null   | null    | null
    }

    def 'Should remove Provider Role Attending from hsc_prov_role given User moves back to servicing provider page after selecting servicing and administering providers and then does not select a preferred supplier'() {
        when:
        hscProvider.deleteAdministeringProvider(1234L, hscProviderList)

        then:
        1 * FeatureFlagUtility.getManager().isActive(SpclCareFeatureFlagConstants.ENABLE_SGP_UHC_MEDICAID_MEMBER_ONBOARDING) >> true
        methodCallCount * hscProviderRole.deleteProviderRole(1234L, HsrReferenceConstants.PROVIDER_ROLE_ATTENDING)

        where:
        testcase                                                            | methodCallCount | hscProviderList
        'Attending Provider available in DB'                                | 1               | [new HscProviderVO(hscID: 1234L, providerSeqNum: 1, hscProviderRoleVOs: [new HscProviderRoleVO(providerRole: HsrReferenceConstants.PROVIDER_ROLE_REQUESTING)]), new HscProviderVO(hscID: 1234L, providerSeqNum: 1, attendingProviderInd: true, hscProviderRoleVOs: [new HscProviderRoleVO(hscID: 1234L, providerRole: HsrReferenceConstants.PROVIDER_ROLE_ATTENDING)])]
        'Attending Provider available in DB, but hscProviderRoleVOs = null' | 0               | [new HscProviderVO(hscID: 1234L, providerSeqNum: 1, hscProviderRoleVOs: [new HscProviderRoleVO(providerRole: HsrReferenceConstants.PROVIDER_ROLE_REQUESTING)]), new HscProviderVO(hscID: 1234L, providerSeqNum: 1, attendingProviderInd: true)]
        'Attending Provider not available in DB'                            | 0               | [new HscProviderVO(hscID: 1234L, providerSeqNum: 1, hscProviderRoleVOs: [new HscProviderRoleVO(providerRole: HsrReferenceConstants.PROVIDER_ROLE_REQUESTING)])]
    }

    //Private Methods starts here 

    private def getValidHscVO(long hscID, String serviceSetting, String specialProcessType) {
        HscVO hscVO = new HscVO()
        hscVO.setHscID(hscID)
        hscVO.setServiceSettingType(serviceSetting)
        hscVO.setSpecialProcessType(specialProcessType)
        hscVO.setHscStatusType(HsrReferenceConstants.HSCSTATUSTYPE_OPEN)
        return hscVO
    }

    private HscProviderVO createHscProviderVOWithRoles() {
        HscProviderVO providerVO = createHscProviderVO()
        providerVO.getHscProviderRoleVOs().add(new HscProviderRoleVO(providerRole: HsrReferenceConstants.PROVIDER_ROLE_FACILITY))
        providerVO.getHscProviderRoleVOs().add(new HscProviderRoleVO(providerRole: HsrReferenceConstants.PROVIDER_ROLE_ATTENDING))
        providerVO.getHscProviderRoleVOs().add(new HscProviderRoleVO(providerRole: HsrReferenceConstants.PROVIDER_ROLE_REQUESTING))
        providerVO.getHscProviderRoleVOs().add(new HscProviderRoleVO(providerRole: HsrReferenceConstants.PROVIDER_ROLE_ADMITTING))
        providerVO.getHscProviderRoleVOs().add(new HscProviderRoleVO(providerRole: HsrReferenceConstants.PROVIDER_ROLE_SERVICING))
        providerVO.getHscProviderRoleVOs().add(new HscProviderRoleVO(providerRole: HsrReferenceConstants.PROVIDER_ROLE_PRIMARY_CARE_PROVIDER))
        return providerVO
    }
    
    private List<HscProviderRoleVO> getExistingProviderRoleList() {
        List<HscProviderRoleVO> existingProviderRoleList = new ArrayList<>()
        existingProviderRoleList.add(new HscProviderRoleVO(providerRole: HsrReferenceConstants.PROVIDER_ROLE_FACILITY))
        existingProviderRoleList.add(new HscProviderRoleVO(providerRole: HsrReferenceConstants.PROVIDER_ROLE_ATTENDING))
        existingProviderRoleList.add(new HscProviderRoleVO(providerRole: HsrReferenceConstants.PROVIDER_ROLE_REQUESTING))
        existingProviderRoleList.add(new HscProviderRoleVO(providerRole: HsrReferenceConstants.PROVIDER_ROLE_ADMITTING))
        existingProviderRoleList.add(new HscProviderRoleVO(providerRole: HsrReferenceConstants.PROVIDER_ROLE_SERVICING))
        existingProviderRoleList.add(new HscProviderRoleVO(providerRole: HsrReferenceConstants.PROVIDER_ROLE_PRIMARY_CARE_PROVIDER))
        return existingProviderRoleList
    }

    private def createHscProviderVO() {
        HscProviderVO hscProviderVO = getValidHscProviderVO(HsrReferenceConstants.PROVIDERCATEGORY_FACILITY, false)
        hscProviderVO.setFacilityProviderInd(true)
        hscProviderVO.setServicingProviderInd(true)
        hscProviderVO.setProviderClinicalID((long) 1)
        hscProviderVO
    }

    private def getValidHscProviderVO(String providerCategoryTypeId, boolean update) {
        HscProviderVO hscProviderVO = new HscProviderVO(
                hscID: 123)
        hscProviderVO
    }

    private def doesMsgExists(ValueObject vo, Message msg) {
        boolean found = false;
        Set<Message> messages = vo.getGlobalMessages();
        if(messages == null || messages.isEmpty()) {
            found = false
        }
        for(com.optum.rf.dao.data.message.Message message : messages) {
            if(msg.equals(message)) {
                found = true;
                break;
            }
        }
        found
    }

    private def doesMsgExists(ValueObject vo, String field, Message msg) {
        List<FieldMessage> messages = vo.getMessage(field);
        boolean found = false
        if(messages == null || messages.size() == 0) {
            found = false
        }

        for(FieldMessage message : messages) {
            if(msg.equals(message.getMessage())) {
                found = true;
                break;
            }
        }
        found
    }

    private def getHscProviderVOList(HscProviderVO providerVO) {
        ArrayList<HscProviderVO> providerVOs = new ArrayList<HscProviderVO>()
        providerVOs.add(providerVO)
        return providerVOs
    }

    private def getTableDef(Object className, String tableConstant) {
        TableDef td = new TableDef()
        td.setTable(tableConstant)
        td.setValueObjectClass(className.class)
        LogicTypeFactory.putInstance(tableConstant, className)
        return td
    }

    private def getCosmosMemberCoverageList() {
        HscMemberCoverageVO vo = new HscMemberCoverageVO()
        vo.setClaimPlatformID(HsrReferenceConstants.CLAIMPLATFORMID_COSMOS)
        List<HscMemberCoverageVO> list = new ArrayList<HscMemberCoverageVO>()
        list.add(vo)
        list
    }
}
