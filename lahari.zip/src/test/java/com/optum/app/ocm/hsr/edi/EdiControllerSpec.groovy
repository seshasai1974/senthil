package com.optum.app.ocm.hsr.edi

import com.optum.app.ocm.common.common.businesslogic.ControllerHelper
import com.optum.app.ocm.common.edi.businesslogic.Edi
import com.optum.app.ocm.common.edi.businesslogic.EdiMessageLog
import com.optum.app.ocm.common.edi.businesslogic.EdiSearchElement
import com.optum.app.ocm.hsr.edi.controller.EdiController
import com.optum.app.ocm.controller.support.CommonResponse
import com.optum.rf.dao.sql.query.QueryProperties
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.edi.businesslogic.EdiProcessor
import com.optum.app.common.edi.data.EdiVO
import spock.lang.Specification

class EdiControllerSpec extends Specification {
    EdiController ediController
    Edi edi
    EdiMessageLog ediMessageLog
    EdiSearchElement ediSearchElement
    EdiProcessor ediProcessor
    ControllerHelper controllerHelper

    def setup() {
        ediController = new EdiController()

        edi = Mock(Edi)
        ediMessageLog = Mock(EdiMessageLog)
        ediSearchElement = Mock(EdiSearchElement)
        controllerHelper = Mock(ControllerHelper)
        ediProcessor = Mock(EdiProcessor)

        ediController.edi = edi
        ediController.ediMessageLog = ediMessageLog
        ediController.ediSearchElement = ediSearchElement
        ediController.controllerHelper = controllerHelper
        ediController.ediProcessor = ediProcessor
    }

    def "Test getEdiSearch"() {
        given:
        QueryProperties qp1 = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        QueryProperties qp2 = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        qp2.setOrderByDescFields(FieldConstants.CREATEDATETIME)  
        List<EdiVO> ediVOs = Arrays.asList(new EdiVO(ediID: 32), new EdiVO(ediID: 33), new EdiVO(ediID: 34))

        when:
        CommonResponse response = ediController.getEdiSearch(qp1)
        Map<String, Object> responseMap = response.getEmbedded()
        List<EdiVO> responseVOs = (List) responseMap.get("_embedded")
        int totalRecords = (Integer) response.getPagination().get(CommonResponse.TOTALRECORDSCOUNT)

        then:
        1 * controllerHelper.getQueryProperties(qp1) >> qp2
        1 * edi.listWithSearchElementQuery(qp2) >> ediVOs
        1 * edi.count(qp2) >> ediVOs.size()
        0 * _
        
        and:
        !responseVOs.isEmpty()
        responseVOs.get(0).getEdiID() == 32
        responseVOs.get(1).getEdiID() == 33
        responseVOs.get(2).getEdiID() == 34
        totalRecords == 3
    }

    def "Test getEdi"() {
        given:
        Long ediID = 1

        when:
        CommonResponse response = ediController.getEdi(ediID)
        Map<String, Object> responseMap = response.getEmbedded()
        EdiVO responseVO = (EdiVO) responseMap.get("_embedded")

        then:
        1 * edi.readWithMessageLogsAndSearchElements(ediID) >> new EdiVO(ediID: ediID)
        0 * _

        and:
        responseVO
        responseVO.getEdiID() == ediID
    }

    def "Test updateEdi"() {
        given:
        EdiVO ediVO = new EdiVO(ediID: 1)

        when:
        CommonResponse response = ediController.updateEdi(ediVO)
        Map<String, Object> responseMap = response.getEmbedded()
        EdiVO responseVO = (EdiVO) responseMap.get("_embedded")

        then:
        1 * edi.save(ediVO)
        0 * _

        and:
        responseVO
        responseVO.getEdiID() == ediVO.getEdiID()
    }

    def "Test submitEdiEntry"() {
        given:
        EdiVO ediVO = new EdiVO(ediID: 1)

        when:
        CommonResponse response = ediController.submitEdiEntry(ediVO)
        Map<String, Object> responseMap = response.getEmbedded()
        EdiVO responseVO = (EdiVO) responseMap.get("_embedded")

        then:
        1 * ediProcessor.processWithNewTransaction(ediVO, null) >> ediVO
        0 * _

        and:
        responseVO
        responseVO.getEdiID() == ediVO.getEdiID()
    }
}
