package com.optum.app.ocm.hsr

import com.optum.app.ocm.common.member.businesslogic.Member
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.util.UhgCalendarUtilities
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.optum.rf.test.core.spock.ReadLogicSpecification
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.HscServiceLineTatHelper
import com.optum.app.common.hsr.businesslogic.impl.HscServiceTatPointImpl
import com.optum.app.common.hsr.constants.HsrReferenceConstants
import com.optum.app.common.hsr.data.HscServiceTatPointVO
import spock.lang.Unroll

class HscServiceTatPointImplSpec extends HsrReadLogicSpecification {

    HscServiceTatPointImpl hscServiceTatPointImpl
    DataAccessObject dao
    HscServiceLineTatHelper hscServiceLineTatHelper
    PersistenceHelper persistenceHelper
    Member member

    def setup() {
        hscServiceTatPointImpl = new HscServiceTatPointImpl()
        persistenceHelper = Mock(PersistenceHelper)
        dao = Mock(DataAccessObject)
        hscServiceLineTatHelper = Mock(HscServiceLineTatHelper)
        member = Mock(Member)

        hscServiceTatPointImpl.setRequiredPersistenceHelper(persistenceHelper)
        hscServiceTatPointImpl.setRequiredDao(dao)
        hscServiceTatPointImpl.setRequiredMember(member)
    }

    def "get dao"() {
        when:
        DataAccessObject returnedObj = hscServiceTatPointImpl.getDao()

        then:
        returnedObj == dao
    }

    @Unroll
    def "is valid : case #testScenario"() {
        given:
        long id = 238290
        short seqNo = 89
        String tatPointTypeId = "01"

        when:
        boolean isValidResponse = hscServiceTatPointImpl.isValid(id, seqNo, tatPointTypeId)

        then:
        1 * dao.isValid(_) >> { ReadProperties rp ->
            assert rp.getKeyValue(FieldConstants.TATPOINTTYPE) == tatPointTypeId
            assert rp.getKeyValue(FieldConstants.HSCID) == id
            assert rp.getKeyValue(FieldConstants.SERVICESEQNUM) == seqNo
            return returnedFromDAO
        }
        0 * _
        isValidResponse == expValidationResp

        where:
        testScenario | expValidationResp | returnedFromDAO
        "1-invalid"  | false             | false
        "2-valid"    | true              | true
    }

    @Unroll
    def "read : case #testScenario"() {
        when:
        HscServiceTatPointVO readResponse = hscServiceTatPointImpl.read(927l, (short) 8, "01")

        then:
        1 * dao.read(_) >> { ReadProperties rp ->
            assert rp.getKeyValue(FieldConstants.TATPOINTTYPE) == "01"
            assert rp.getKeyValue(FieldConstants.HSCID) == 927
            assert rp.getKeyValue(FieldConstants.SERVICESEQNUM) == 8
            return returnedFromDAO
        }
        0 * _
        readResponse == returnedFromDAO

        where:
        testScenario    | expValidationResp | returnedFromDAO
        "1-none found"  | false             | null
        "2-found entry" | true              | new HscServiceTatPointVO(hscID: 927, serviceSeqNum: 8, tatPointType: "01")
    }

    def "get read properties"() {
        given:
        long id = 816
        short seqNo = 24
        String tatPointTypeId = "01"

        when:
        ReadProperties rp = hscServiceTatPointImpl.getReadProperties(id, seqNo, tatPointTypeId)

        then:
        rp.getKeyValue(FieldConstants.TATPOINTTYPE) == tatPointTypeId
        rp.getKeyValue(FieldConstants.HSCID) == id
        rp.getKeyValue(FieldConstants.SERVICESEQNUM) == seqNo
        0 * _
    }

    def "execute add - C & S member"() {
        given:
        long id = 725
        short seqNo = 5
        String tatPointTypeId = "01"
        HscServiceTatPointVO tatPointVO = new HscServiceTatPointVO(hscID: id, serviceSeqNum: seqNo, tatPointType: tatPointTypeId)

        when:
        hscServiceTatPointImpl.executeAdd(tatPointVO)

        then:
        1 * persistenceHelper.add(_ as HscServiceTatPointVO) >> { HscServiceTatPointVO vo ->
            assert vo.hscID == id
            assert vo.serviceSeqNum == seqNo
            assert vo.tatPointType == tatPointTypeId
        }
        0 * _
    }

    def "execute add - non C & S member"() {
        given:
        long id = 725
        short seqNo = 5
        String tatPointTypeId = "01"
        HscServiceTatPointVO tatPointVO = new HscServiceTatPointVO(hscID: id, serviceSeqNum: seqNo, tatPointType: tatPointTypeId)

        when:
        hscServiceTatPointImpl.executeAdd(tatPointVO)

        then:
        1 * persistenceHelper.add(_ as HscServiceTatPointVO) >> { HscServiceTatPointVO vo ->
            assert vo.hscID == id
            assert vo.serviceSeqNum == seqNo
            assert vo.tatPointType == tatPointTypeId
        }
        0 * _
    }

    def "execute update - C & S member"() {
        given:
        long id = 7243
        short seqNo = 9
        String tatPointTypeId = "01"
        HscServiceTatPointVO tatPointVO = new HscServiceTatPointVO(hscID: id, serviceSeqNum: seqNo, tatPointType: tatPointTypeId)

        when:
        hscServiceTatPointImpl.executeUpdate(tatPointVO)

        then:
        1 * persistenceHelper.update(_ as HscServiceTatPointVO) >> { HscServiceTatPointVO vo ->
            assert vo.hscID == id
            assert vo.serviceSeqNum == seqNo
            assert vo.tatPointType == tatPointTypeId
        }
        0 * _
    }

    def "execute update - non C & S member"() {
        given:
        long id = 342
        short seqNo = 7
        String tatPointTypeId = "01"
        HscServiceTatPointVO tatPointVO = new HscServiceTatPointVO(hscID: id, serviceSeqNum: seqNo, tatPointType: tatPointTypeId)

        when:
        hscServiceTatPointImpl.executeUpdate(tatPointVO)

        then:
        1 * persistenceHelper.update(tatPointVO)
        0 * _
    }

    def "list by HSC"() {
        given:
        long id = 23
        short seqNo = 3
        List<HscServiceTatPointVO> VOList = [new HscServiceTatPointVO(hscID: id, serviceSeqNum: seqNo)]

        when:
        List<HscServiceTatPointVO> responseList = hscServiceTatPointImpl.listByHsc(id, seqNo)

        then:
        1 * dao.list(_ as QueryProperties) >> { QueryProperties qp ->
            assert qp.getFilterType() == QueryProperties.FilterType.LIST_ALL
            assert qp.getQueryFilters().size() == 2
            assert qp.getQueryFilter(FieldConstants.HSCID).fieldValue == id
            assert qp.getQueryFilter(FieldConstants.SERVICESEQNUM).fieldValue == seqNo
            return VOList
        }
        0 * _
        responseList == VOList
    }
}
