package com.optum.app.ocm.hsr

import com.optum.rf.dao.exception.UhgRuntimeException
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.optum.rf.test.core.mock.spring.MockTransactionInterceptor
import com.optum.rf.test.core.spock.ReadLogicSpecification
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.impl.HscServiceDecisionSourceImpl
import com.optum.app.common.hsr.data.HscServiceDecisionSourceVO

class HscServiceDecisionSourceImplSpec extends HsrReadLogicSpecification{
    HscServiceDecisionSourceImpl hscServiceDecisionSource
    DataAccessObject dao
    PersistenceHelper persistenceHelper
    
    def setup() {
        hscServiceDecisionSource = new HscServiceDecisionSourceImpl()
        dao = Mock(DataAccessObject)
        persistenceHelper = Mock(PersistenceHelper)
        hscServiceDecisionSource.setRequiredDao(dao)
        hscServiceDecisionSource.setRequiredPersistenceHelper(persistenceHelper)
        hscServiceDecisionSource.setRequiredTransactionInterceptor(new MockTransactionInterceptor())
        
    }
    
    def "Valid GetHscServiceDecisionSourceList test with QueryProperties" (){
        given:
        HscServiceDecisionSourceVO vo = createHscServiceDecisionSourceVO("1", "1")
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        
        when:
        hscServiceDecisionSource.getHscServiceDecisionSourceList(123456789,(short) 1, (short) 1, qp)
        
        then:
        1* dao.list(qp) >> new ArrayList<HscServiceDecisionSourceVO>()
        0*_
        !vo.errorMessagesExist()
        notThrown UhgRuntimeException
    }
    
    def "Valid GetHscServiceDecisionSourceList test with null Query Properties" (){
        given:
        HscServiceDecisionSourceVO vo = createHscServiceDecisionSourceVO("1", "1")
        QueryProperties qp1 = null
        def voList = new ArrayList<HscServiceDecisionSourceVO>()
         
        when:
        hscServiceDecisionSource.getHscServiceDecisionSourceList(123456789,(short) 1, (short) 1, qp1)

        then:
        1* dao.list(_) >>  { QueryProperties qp ->
            assert qp.filterType == QueryProperties.FilterType.LIST_ALL
            return voList
        }
        0*_
        !vo.errorMessagesExist()
        notThrown UhgRuntimeException
    }
    
    def "test isValid"(){
        given:
        HscServiceDecisionSourceVO vo = createHscServiceDecisionSourceVO("1", "1")

        when:
        hscServiceDecisionSource.isValid(vo.hscID,(short) 1, (short) 1, (short)1)

        then:
        1*dao.isValid(_) >> { ReadProperties rp->
            assert  rp.getKeyValue(FieldConstants.HSCID) == vo.hscID 
            assert  rp.getKeyValue(FieldConstants.SERVICESEQNUM) == (short) 1
            assert  rp.getKeyValue(FieldConstants.DECISIONSEQNUM) == (short) 1
            assert  rp.getKeyValue(FieldConstants.SOURCESEQNUM) == (short) 1
        return true
        }
        0*_
    }

    def "test read method"(){
        given:
        HscServiceDecisionSourceVO vo = createHscServiceDecisionSourceVO("1", "1")
        
        when:
        hscServiceDecisionSource.read(vo.hscID,(short) 1, (short) 1, (short)1)

        then:
        1*dao.read(_) >> { ReadProperties rp->
            assert rp.getKeyValue(FieldConstants.HSCID) == vo.hscID
            assert rp.getKeyValue(FieldConstants.SERVICESEQNUM) == (short) 1
            assert  rp.getKeyValue(FieldConstants.DECISIONSEQNUM) == (short) 1
            assert  rp.getKeyValue(FieldConstants.SOURCESEQNUM) == (short) 1
        }
        0*_
    }
    
    private HscServiceDecisionSourceVO createHscServiceDecisionSourceVO(String decisionSourceType, String criteriaID) {
        HscServiceDecisionSourceVO hscServiceDecisionSourceVO = new HscServiceDecisionSourceVO(criteriaID: criteriaID,decisionSourceType:decisionSourceType,
                                                                            decisionSeqNum: 1,hscID: 34567)
        return hscServiceDecisionSourceVO
    }
}
