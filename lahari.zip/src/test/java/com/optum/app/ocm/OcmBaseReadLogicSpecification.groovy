package com.optum.app.ocm

import com.optum.rf.dao.tabledef.TableDefFactory
import com.optum.rf.test.core.spock.BaseReadLogicSpecification
import com.uhg.tabledef.spclcare.TableDefFactoryLoaderImpl

class OcmBaseReadLogicSpecification extends BaseReadLogicSpecification {
    // specify the Base built tabledef
    static {
        tableDefFactory = new TableDefFactory(TableDefFactoryLoaderImpl.newInstance())
    }
}
