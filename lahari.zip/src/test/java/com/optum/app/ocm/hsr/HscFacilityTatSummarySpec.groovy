package com.optum.app.ocm.hsr

import com.optum.rf.bl.spring.TransactionInterceptor
import com.optum.rf.core.locator.ServiceLocator
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.HscFacilityTatSummary
import com.optum.app.common.hsr.businesslogic.impl.HscFacilityTatSummaryImpl
import com.optum.app.common.hsr.data.HscFacilityTatSummaryVO
import spock.lang.Unroll

class HscFacilityTatSummarySpec extends HsrReadLogicSpecification {

    HscFacilityTatSummary hscFacilityTatSummary

    DataAccessObject dao
    PersistenceHelper persistenceHelper
    ServiceLocator serviceLocator
    TransactionInterceptor transactionInterceptor

    def setup() {
        dao = Mock(DataAccessObject)
        persistenceHelper = Mock(PersistenceHelper)
        serviceLocator = Mock(ServiceLocator)
        transactionInterceptor = Mock(TransactionInterceptor)

        hscFacilityTatSummary = new HscFacilityTatSummaryImpl(
                requiredDao: dao,
                requiredPersistenceHelper: persistenceHelper,
                requiredServiceLocator: serviceLocator,
                requiredTransactionInterceptor: transactionInterceptor
        )
    }

    @Unroll
    def "isValid #testCase"() {
        given:
        def hscID = (long) 1
        def tatPeriodCategoryTypeId = "2"
        def rp = new ReadProperties(FieldConstants.HSCID, FieldConstants.TATPERIODCATEGORYTYPEID)
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        rp.setKeyValue(FieldConstants.TATPERIODCATEGORYTYPEID, tatPeriodCategoryTypeId)
        rp.fields = null

        when:
        boolean retVal = hscFacilityTatSummary.isValid(hscID, tatPeriodCategoryTypeId)

        then:
        1 * dao.isValid(rp) >> expectedVal
        0 * _
        retVal == expectedVal

        where:
        testCase | expectedVal
        "passes" | true
        "fails"  | false
    }

    def "Test to read HscFacilityTatSummaryVO"() {
        setup:
        def hscID = (long) 1
        def tatPeriodCategoryTypeId = "2"
        HscFacilityTatSummaryVO hscFacilityTatSummaryVO = new HscFacilityTatSummaryVO(hscID: hscID, tatPeriodCategoryTypeId: tatPeriodCategoryTypeId)
        def rp = new ReadProperties(FieldConstants.HSCID, FieldConstants.TATPERIODCATEGORYTYPEID)
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        rp.setKeyValue(FieldConstants.TATPERIODCATEGORYTYPEID, tatPeriodCategoryTypeId)
        rp.fields = null

        when:
        hscFacilityTatSummary.read(hscID, tatPeriodCategoryTypeId)

        then:
        1 * dao.read(rp) >> hscFacilityTatSummaryVO
        0 * _
    }
}
