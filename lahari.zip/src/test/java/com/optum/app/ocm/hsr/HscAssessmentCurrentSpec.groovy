package com.optum.app.ocm.hsr

import com.optum.rf.bl.spring.TransactionInterceptor
import com.optum.rf.core.locator.ServiceLocator
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.QueryFilter
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.HscAssessmentCurrent
import com.optum.app.common.hsr.businesslogic.impl.HscAssessmentCurrentImpl
import com.optum.app.common.hsr.data.HscAssessmentCurrentVO

class HscAssessmentCurrentSpec extends HsrReadLogicSpecification {

    HscAssessmentCurrent hscAssessmentCurrent

    DataAccessObject dao
    PersistenceHelper persistenceHelper
    ServiceLocator serviceLocator
    TransactionInterceptor transactionInterceptor

    def setup() {
        dao = Mock(DataAccessObject)
        persistenceHelper = Mock(PersistenceHelper)
        serviceLocator = Mock(ServiceLocator)
        transactionInterceptor = Mock(TransactionInterceptor)

        hscAssessmentCurrent = new HscAssessmentCurrentImpl(
                dao: dao,
                requiredServiceLocator: serviceLocator
        )
    }

    def "Test readByHscIDAndBldAsmtID"() {
        setup:
        def hscID = (long) 1
        def builderAssessmentID = "2"
        HscAssessmentCurrentVO hscAssessmentCurrentVO = new HscAssessmentCurrentVO(hscID: hscID, builderAssessmentID: builderAssessmentID)
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.NEW_FILTER);
        qp.addQueryFilter(new QueryFilter(FieldConstants.HSCID, hscID));
        qp.addQueryFilter(new QueryFilter(FieldConstants.BUILDERASSESSMENTID, builderAssessmentID));
        qp.setResultSize(1);

        when:
        hscAssessmentCurrent.readByHscIDAndBldAsmtID(hscID, builderAssessmentID)

        then:
        1 * dao.list(qp) >> [hscAssessmentCurrentVO]
        0 * _
    }

    def "Test readByAssessmentSubjectUuid"() {
        setup:
        def hscID = (long) 1
        def assessmentSubjectUuid = "2"
        HscAssessmentCurrentVO hscAssessmentCurrentVO = new HscAssessmentCurrentVO(hscID: hscID, assessmentSubjectUuid: assessmentSubjectUuid)
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.NEW_FILTER);
        qp.addQueryFilter(new QueryFilter(FieldConstants.ASSESSMENTSUBJECTUUID, assessmentSubjectUuid));
        qp.setResultSize(1);

        when:
        hscAssessmentCurrent.readByAssessmentSubjectUuid(assessmentSubjectUuid)

        then:
        1 * dao.list(qp) >> [hscAssessmentCurrentVO]
        0 * _
    }

    def "Test readByOverrideAssessmentSubjectUuid"() {
        setup:
        def hscID = (long) 1
        def overrideAssessmentSubjectUuid = "2"
        HscAssessmentCurrentVO hscAssessmentCurrentVO = new HscAssessmentCurrentVO(hscID: hscID, overrideAssessmentSubjectUuid: overrideAssessmentSubjectUuid)
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.NEW_FILTER);
        qp.addQueryFilter(new QueryFilter(FieldConstants.OVERRIDEASSESSMENTSUBJECTUUID, overrideAssessmentSubjectUuid));
        qp.setResultSize(1);

        when:
        hscAssessmentCurrent.readByOverrideAssessmentSubjectUuid(overrideAssessmentSubjectUuid)

        then:
        1 * dao.list(qp) >> [hscAssessmentCurrentVO]
        0 * _
    }
}
