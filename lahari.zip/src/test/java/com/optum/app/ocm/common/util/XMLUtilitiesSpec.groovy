package com.optum.app.ocm.common.util

import com.uhc.oam.oam.ws.v1.assessmentconductorservice.AssessmentTemplateResponse
import spock.lang.Specification

/**
 * Created by lnagara on 5/24/2018.
 */
class XMLUtilitiesSpec extends Specification{

    def "Test unmarshall xml string to object"() {
        given:
        String xml = getXmlString()

        when:
        AssessmentTemplateResponse assessmentTemplateResponse = XMLUtilities.unmarshall(xml, AssessmentTemplateResponse)

        then:
        assessmentTemplateResponse.responseHeader.serviceCallStatus == "SUCCESS"
        assessmentTemplateResponse.assessmentTemplate.assessmentTemplateID == 9152
        assessmentTemplateResponse.assessmentTemplate.builderAssessmentID == "8772"
    }

    private String getXmlString(){
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'+
                '<AssessmentTemplateResponse>'+
                '<responseHeader serviceCallStatus="SUCCESS"/>'+
                '<assessmentTemplate assessmentTemplateID="9152" builderAssessmentID="8772" assessmentTemplateName="Adam Alpha" builderAssessmentVersionNumber="1" assessmentCategoryTypeID="6" sectionScoreDisplayIndicator="false" builderStatusTypeID="3" scored="false" totalScoreDisplayInd="false" totalAvgQuestScoreDisplayInd="false" sectionAvgQuestScoreDisplayInd="false"></assessmentTemplate>'+
                '</AssessmentTemplateResponse>'
    }
}
