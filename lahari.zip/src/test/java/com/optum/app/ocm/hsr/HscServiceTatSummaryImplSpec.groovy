package com.optum.app.ocm.hsr

import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.query.OrderByField
import com.optum.rf.dao.sql.query.QueryCriteria
import com.optum.rf.dao.sql.query.QueryFilter
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.HscServiceTatPoint
import com.optum.app.common.hsr.businesslogic.impl.HscServiceTatSummaryImpl
import com.optum.app.common.hsr.data.HscServiceTatSummaryVO
import org.apache.commons.lang.StringUtils
import spock.lang.Unroll

class HscServiceTatSummaryImplSpec extends HsrReadLogicSpecification {

    HscServiceTatSummaryImpl hscServiceTatSummary
    PersistenceHelper persistenceHelper
    DataAccessObject dao
    HscServiceTatPoint hscServiceTatPoint

    def setup() {
        hscServiceTatSummary = new HscServiceTatSummaryImpl()
        persistenceHelper = Mock(PersistenceHelper)
        dao = Mock(DataAccessObject)
        hscServiceTatPoint = Mock(HscServiceTatPoint)
        hscServiceTatSummary.setRequiredPersistenceHelper(persistenceHelper)
        hscServiceTatSummary.setRequiredDao(dao)
    }

    def "get dao"() {
        when:
        DataAccessObject returnedObj = hscServiceTatSummary.getDao()

        then:
        returnedObj
        returnedObj == dao
    }

    def "is valid"() {
        given:
        long hscId = 293820
        short serviceSeqNum = 21
        String tatPeriodCategoryTypeId = "35"

        when:
        hscServiceTatSummary.isValid(hscId, serviceSeqNum, tatPeriodCategoryTypeId)

        then:
        1 * dao.isValid(_ as ReadProperties) >> { ReadProperties rp ->
            assert rp.getKeyValue(FieldConstants.TATPERIODCATEGORYTYPEID) == tatPeriodCategoryTypeId
            assert rp.getKeyValue(FieldConstants.HSCID) == hscId
            assert rp.getKeyValue(FieldConstants.SERVICESEQNUM) == serviceSeqNum
            return true
        }
        0 * _
    }

    def "read"() {
        given:
        long hscId = 64234523
        short serviceSeqNum = 34
        String tatPeriodCategoryTypeId = "12"
        HscServiceTatSummaryVO returnVO = new HscServiceTatSummaryVO(hscID: hscId, serviceSeqNum: serviceSeqNum, tatPeriodCategoryTypeId: tatPeriodCategoryTypeId)

        when:
        HscServiceTatSummaryVO readVO = hscServiceTatSummary.read(hscId, serviceSeqNum, tatPeriodCategoryTypeId)

        then:
        1 * dao.read(_ as ReadProperties) >> { ReadProperties rp ->
            assert rp.getKeyValue(FieldConstants.TATPERIODCATEGORYTYPEID) == tatPeriodCategoryTypeId
            assert rp.getKeyValue(FieldConstants.HSCID) == hscId
            assert rp.getKeyValue(FieldConstants.SERVICESEQNUM) == serviceSeqNum
            return returnVO
        }
        0 * _
        readVO == returnVO
    }

    def "get read properties"() {
        given:
        long hscId = 87564
        short serviceSeqNum = 13
        String tatPeriodCategoryTypeId = "56"

        when:
        ReadProperties rp = hscServiceTatSummary.getReadProperties(hscId, serviceSeqNum, tatPeriodCategoryTypeId)

        then:
        rp.getKeyValue(FieldConstants.TATPERIODCATEGORYTYPEID) == tatPeriodCategoryTypeId
        rp.getKeyValue(FieldConstants.HSCID) == hscId
        rp.getKeyValue(FieldConstants.SERVICESEQNUM) == serviceSeqNum
        0 * _
    }

    def "delete TAT summaries for service"() {
        given:
        long hscId = 745
        short serviceSeqNum = 42
        List<HscServiceTatSummaryVO> listVO = [new HscServiceTatSummaryVO(hscID: hscId, serviceSeqNum: serviceSeqNum)]

        when:
        hscServiceTatSummary.deleteTatSummariesForService(serviceSeqNum, hscId)

        then:
        1 * dao.list(_ as QueryProperties) >> { QueryProperties qp ->
            assert qp.getFilterType() == QueryProperties.FilterType.LIST_ALL
            assert qp.getQueryFilter(FieldConstants.HSCID).fieldValue == hscId
            assert qp.getQueryFilter(FieldConstants.SERVICESEQNUM).fieldValue == serviceSeqNum
            assert qp.getQueryFilter(FieldConstants.SERVICESEQNUM).getCriterion() == QueryCriteria.EQUAL
            assert qp.getQueryFilter(FieldConstants.SERVICESEQNUM).getPredicateCriterion() == QueryFilter.SqlPredicateKeyword.AND
            return listVO
        }
        1 * persistenceHelper.deleteBatch(listVO)
        0 * _
    }

    @Unroll
    def "add - isUpdate flag is #isUpdate"() {
        given:
        HscServiceTatSummaryVO vo = new HscServiceTatSummaryVO(hscID: 234, serviceSeqNum: 7)

        when:
        hscServiceTatSummary.add(vo, isUpdate)

        then:
        1 * persistenceHelper.add(vo)
        0 * _

        where:
        isUpdate << [true, false]
    }

    @Unroll
    def "update - isUpdate flag is #isUpdate"() {
        given:
        HscServiceTatSummaryVO vo = new HscServiceTatSummaryVO(hscID: 9, serviceSeqNum: 8)

        when:
        hscServiceTatSummary.update(vo, isUpdate)

        then:
        1 * persistenceHelper.update(vo)
        0 * _

        where:
        isUpdate << [true, false]
    }

    def "add batch"() {
        given:
        List<HscServiceTatSummaryVO> VOList = [new HscServiceTatSummaryVO(hscID: 19, serviceSeqNum: 9)]

        when:
        hscServiceTatSummary.addBatch(VOList)

        then:
        1 * persistenceHelper.addBatch(VOList)
        0 * _
    }

    def "update batch"() {
        given:
        List<HscServiceTatSummaryVO> VOList = [new HscServiceTatSummaryVO(hscID: 75, serviceSeqNum: 5)]

        when:
        hscServiceTatSummary.updateBatch(VOList)

        then:
        1 * persistenceHelper.updateBatch(VOList)
        0 * _
    }

    def "list by hsc"() {
        given:
        long hscId = 4
        List<HscServiceTatSummaryVO> listVO = [
                new HscServiceTatSummaryVO(hscID: hscId, serviceSeqNum: 1),
                new HscServiceTatSummaryVO(hscID: hscId, serviceSeqNum: 2),
                new HscServiceTatSummaryVO(hscID: hscId, serviceSeqNum: 3)
        ]

        when:
        List<HscServiceTatSummaryVO> returnedList = hscServiceTatSummary.listByHsc(hscId)

        then:
        1 * dao.list(_ as QueryProperties) >> { QueryProperties qp ->
            assert qp.getFilterType() == QueryProperties.FilterType.LIST_ALL
            assert qp.getQueryFilter(FieldConstants.HSCID).fieldValue == hscId
            assert qp.getOrderByFields().size() == 1
            assert qp.getOrderByFields().get(0).fieldName == FieldConstants.SERVICESEQNUM
            assert qp.getOrderByFields().get(0).direction == OrderByField.Direction.ASC
            return listVO
        }
        0 * _
        returnedList == listVO
    }

    def "list by service"() {
        given:
        long hscId = 3
        short seqNum = 2
        List<HscServiceTatSummaryVO> listVO = [new HscServiceTatSummaryVO(hscID: hscId, serviceSeqNum: seqNum)]

        when:
        List<HscServiceTatSummaryVO> returnedList = hscServiceTatSummary.listByService(hscId, seqNum)

        then:
        1 * dao.list(_ as QueryProperties) >> { QueryProperties qp ->
            assert qp.getFilterType() == QueryProperties.FilterType.LIST_ALL
            assert qp.getQueryFilters().size() == 2
            assert qp.getQueryFilter(FieldConstants.HSCID).fieldValue == hscId
            assert qp.getQueryFilter(FieldConstants.SERVICESEQNUM).fieldValue == seqNum
            return listVO
        }
        0 * _
        returnedList == listVO
    }

    def "list by category"() {
        given:
        long hscId = 548
        String tatPeriodCategoryTypeId = "24"
        List<HscServiceTatSummaryVO> listVO = [new HscServiceTatSummaryVO(hscID: hscId, tatPeriodCategoryTypeId: tatPeriodCategoryTypeId)]

        when:
        List<HscServiceTatSummaryVO> returnedList = hscServiceTatSummary.listByCategory(hscId, tatPeriodCategoryTypeId)

        then:
        1 * dao.list(_ as QueryProperties) >> { QueryProperties qp ->
            assert qp.getFilterType() == QueryProperties.FilterType.LIST_ALL
            assert qp.getQueryFilters().size() == 2
            assert qp.getQueryFilter(FieldConstants.HSCID).fieldValue == hscId
            assert qp.getQueryFilter(FieldConstants.TATPERIODCATEGORYTYPEID).fieldValue == tatPeriodCategoryTypeId
            return listVO
        }
        0 * _
        returnedList == listVO
    }

    def "test getPreviousCalculatedTatServiceDetailCategoryTypeID tatServiceDetailCategoryTypId exists"() {
        given:
        short serviceSeq = 1
        QueryProperties qp = null
        
        when:
        def result = hscServiceTatSummary.getPreviousCalculatedTatServiceDetailCategoryTypeID(1234L, serviceSeq, 'AZ')

        then:
        1 * dao.list({qp = it}) >> [new HscServiceTatSummaryVO(tatRqrSeqNum: 1, tatPeriodCategoryTypeId: '01')]
        0 * _

        and:
        qp.getFilterType() == QueryProperties.FilterType.NEW_FILTER
        qp.getQueryFilters().size() == 2
        qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == 1234L
        qp.getQueryFilter(FieldConstants.SERVICESEQNUM).getFieldValue() == serviceSeq 
        qp.getOrderByAscFields().contains(FieldConstants.TATRQRSEQNUM)
    }

    def "test getPreviousCalculatedTatServiceDetailCategoryTypeID tatServiceDetailCategoryTypId doesn't exist 1"() {
        given:
        short serviceSeq = 1
        QueryProperties qp = null

        when:
        def result = hscServiceTatSummary.getPreviousCalculatedTatServiceDetailCategoryTypeID(1234L, serviceSeq, 'AZ')

        then:
        1 * dao.list({qp = it}) >> [new HscServiceTatSummaryVO(tatRqrSeqNum: 1, tatPeriodCategoryTypeId: '01')]
        0 * _

        and:
        qp.getFilterType() == QueryProperties.FilterType.NEW_FILTER
        qp.getQueryFilters().size() == 2
        qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == 1234L
        qp.getQueryFilter(FieldConstants.SERVICESEQNUM).getFieldValue() == serviceSeq
        qp.getOrderByAscFields().contains(FieldConstants.TATRQRSEQNUM)
        result == StringUtils.EMPTY
    }

    def "test getPreviousCalculatedTatServiceDetailCategoryTypeID tatServiceDetailCategoryTypId doesn't exist 2"() {
        given:
        short serviceSeq = 1
        QueryProperties qp = null

        when:
        def result = hscServiceTatSummary.getPreviousCalculatedTatServiceDetailCategoryTypeID(1234L, serviceSeq, 'AZ')

        then:
        1 * dao.list({qp = it}) >> [new HscServiceTatSummaryVO()]
        0 * _

        and:
        qp.getFilterType() == QueryProperties.FilterType.NEW_FILTER
        qp.getQueryFilters().size() == 2
        qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == 1234L
        qp.getQueryFilter(FieldConstants.SERVICESEQNUM).getFieldValue() == serviceSeq
        qp.getOrderByAscFields().contains(FieldConstants.TATRQRSEQNUM)
        result == StringUtils.EMPTY
    }
}
