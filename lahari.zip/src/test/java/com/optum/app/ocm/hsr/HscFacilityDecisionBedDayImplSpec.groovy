package com.optum.app.ocm.hsr

import com.optum.app.ocm.ref.businesslogic.CustomerReference
import com.optum.rf.common.reference.businesslogic.CodeXRef
import com.optum.rf.common.reference.businesslogic.ZipCodeTimeZone
import com.optum.rf.common.settings.businesslogic.TemporarySystemSetting
import com.optum.rf.core.util.UhgCalendar
import com.optum.rf.dao.constants.SystemGlobalMessages
import com.optum.rf.dao.constants.SystemSecurityConstants
import com.optum.rf.dao.data.ValueObject
import com.optum.rf.dao.exception.UhgRuntimeException
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.exception.FinderException
import com.optum.rf.dao.sql.query.OrderByField
import com.optum.rf.dao.sql.query.QueryCriteria
import com.optum.rf.dao.sql.query.QueryFilter
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.rf.dao.sql.query.ReadProperties
import com.optum.rf.dao.util.UhgCalendarUtilities
import com.optum.rf.dao.util.persistence.PersistenceHelper
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.AbstractHscDecisionHelper
import com.optum.app.common.hsr.businesslogic.Hsc
import com.optum.app.common.hsr.businesslogic.HscDecisionProvider
import com.optum.app.common.hsr.businesslogic.HscFacility
import com.optum.app.common.hsr.businesslogic.HscFacilityDecision
import com.optum.app.common.hsr.businesslogic.HscMemberCoverage
import com.optum.app.common.hsr.businesslogic.HscProvider
import com.optum.app.common.hsr.businesslogic.impl.HscFacilityDecisionBedDayImpl
import com.optum.app.common.hsr.constants.BedDayConstants
import com.optum.app.common.hsr.constants.BedDayDecision
import com.optum.app.common.hsr.constants.HsrReferenceConstants
import com.optum.app.common.hsr.data.HscDecisionProviderVO
import com.optum.app.common.hsr.data.HscFacilityDecisionBedDayHistoryVO
import com.optum.app.common.hsr.data.HscFacilityDecisionBedDayRangeVO
import com.optum.app.common.hsr.data.HscFacilityDecisionBedDayVO
import com.optum.app.common.hsr.data.HscFacilityVO
import com.optum.app.common.hsr.data.HscMemberCoverageVO
import com.optum.app.common.hsr.data.HscProviderVO
import com.optum.app.common.hsr.data.HscVO
import com.optum.app.common.hsr.messages.BedDayMessages
import com.optum.app.common.hsr.messages.HscDecisionMessages
import com.optum.app.common.hsr.util.BedDayUtility
import com.optum.app.common.hsr.util.helper.ValueObjectHelper
import com.optum.app.constants.HscConstants
import com.optum.app.ocm.common.security.businesslogic.AppUser
import com.optum.app.ocm.common.security.data.AppUserVO
import org.apache.commons.lang.StringUtils
import spock.lang.Unroll

import java.sql.Date

class HscFacilityDecisionBedDayImplSpec extends HsrReadLogicSpecification {

    private HscFacilityDecisionBedDayImpl hscFacilityDecisionBedDay

    private AbstractHscDecisionHelper abstractHscDecisionHelper
    private DataAccessObject<HscFacilityDecisionBedDayVO> dao
    private Hsc hsc
    private HscFacility hscFacility
    private HscFacilityDecision hscFacilityDecision
    private AppUser appUser
    private PersistenceHelper persistenceHelper
    private HscMemberCoverage hscMemberCoverage
    private HscDecisionProvider hscDecisionProvider
    private HscProvider hscProvider
    private ZipCodeTimeZone zipCodeTimeZone
    private ValueObjectHelper valueObjectHelper
    private TemporarySystemSetting temporarySystemSetting
    CustomerReference customerReference
    CodeXRef codeXRef

    private static final UhgCalendar DEFAULT_CAL = UhgCalendarUtilities.getTodaysCalendarInUserTimeZone()
    private static final int DEFAULT_INTSETTING_BEDDAYDATEBOUNDS = 10

    private static
    final List<String> BEDDAYDECISIONOUTCOMETYPELIST = Collections.unmodifiableList(Arrays.asList(HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_DENY, HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED));

    /**
     * List of fields needed for considering a rollup.
     */
    private static final String[] ROLLUP_FIELDS = [
            FieldConstants.BEDDAYDECISIONOUTCOMETYPE,
            FieldConstants.DECISIONSUBTYPE,
            FieldConstants.DECISIONREASONTYPE,
            FieldConstants.ASSESSMENTID,
            FieldConstants.DECISIONENTEREDBYUSERID,
            FieldConstants.DECISIONMADEBYUSERID,
            FieldConstants.BEDTYPEID,
            FieldConstants.REVENUECODE,
            FieldConstants.NEGOTIATEDRATETYPE,
            FieldConstants.NEGOTIATEDRATE,
            FieldConstants.OVERRIDEREASONTYPE,
            FieldConstants.DERIVEDCLAIMREMARKCODE,
            FieldConstants.CLAIMNOTELARGEOBJECT,
            FieldConstants.OVERRIDEREASONTEXT,
            FieldConstants.NEXTICMREVIEWDATE,
            FieldConstants.ACCUMULATEDBEDDAYCOUNT,
            FieldConstants.EXTENDEDBEDDAYCOUNT,
            FieldConstants.NEXTCNSREVIEWDATE
    ]

    /**
     * List of fields used in verbal communication.
     */
    private static final String[] VERBAL_COMMUNICATION_FIELDS = [
            FieldConstants.DECISIONPHYSICIANCOMMDATETIME,
            FieldConstants.DECISIONPHYSICIANCOMMROLETYPE,
            FieldConstants.DECISIONFACILITYCOMMDATETIME
    ]

    /**
     * List of fields used in ELGS communication.
     */
    private static final String[] ELGS_COMMUNICATION_FIELDS = [
            FieldConstants.POLICYDOCUMENTTYPE,
            FieldConstants.LANGUAGESOURCEANDSECTIONNAME,
            FieldConstants.LANGUAGE,
            FieldConstants.LETTERRATIONALE,
            FieldConstants.STATEOFJURISDICTION,
            FieldConstants.STATESPECIFICPLANINFOFORKYHMO,
            FieldConstants.OHIOPLANS,
            FieldConstants.RECIPIENTFAXNUMBER,
            FieldConstants.RECIPIENTFAXINTERNATIONALIND,
            FieldConstants.MEDICALPOLICYNAMEORGUIDELINE
    ]


    def setup() {
        hscFacilityDecisionBedDay = new HscFacilityDecisionBedDayImpl()

        abstractHscDecisionHelper = Mock(AbstractHscDecisionHelper)
        dao = Mock(DataAccessObject)
        hsc = Mock(Hsc)
        hscFacility = Mock(HscFacility)
        appUser = Mock(AppUser)
        persistenceHelper = Mock(PersistenceHelper)
        hscMemberCoverage = Mock(HscMemberCoverage)
        hscFacilityDecision = Mock(HscFacilityDecision)
        hscDecisionProvider = Mock(HscDecisionProvider)
        hscProvider = Mock(HscProvider)
        zipCodeTimeZone = Mock(ZipCodeTimeZone)
        valueObjectHelper = Mock(ValueObjectHelper)
        temporarySystemSetting = Mock(TemporarySystemSetting)
        customerReference = Mock(CustomerReference)
        codeXRef = Mock(CodeXRef)
        valueObjectHelper = Mock(ValueObjectHelper)

        hscFacilityDecisionBedDay.setRequiredAbstractHscDecisionHelper(abstractHscDecisionHelper)
        hscFacilityDecisionBedDay.setRequiredAppUser(appUser)
        hscFacilityDecisionBedDay.setRequiredPersistenceHelper(persistenceHelper)
        hscFacilityDecisionBedDay.setRequiredDao(dao)
        hscFacilityDecisionBedDay.setRequiredHsc(hsc)
        hscFacilityDecisionBedDay.setRequiredHscFacility(hscFacility)
        hscFacilityDecisionBedDay.setRequiredHscMemberCoverage(hscMemberCoverage)
        hscFacilityDecisionBedDay.setRequiredHscFacilityDecision(hscFacilityDecision)
        hscFacilityDecisionBedDay.setRequiredHscDecisionProvider(hscDecisionProvider)
        hscFacilityDecisionBedDay.setRequiredCustomerReference(customerReference)
        hscFacilityDecisionBedDay.setRequiredCodeXRef(codeXRef)
        hscFacilityDecisionBedDay.setRequiredValueObjectHelper(valueObjectHelper)
    }

    @Unroll
    def "is valid #testCase"() {
        given:
        long hscID = 1
        Date bedDate = UhgCalendar.getSQLDate("11/05/2011")
        short bedDayDecisionSeqNum = 2
        ReadProperties rp = getReadProperties(hscID, bedDate, bedDayDecisionSeqNum)
        def retVal

        when:
        retVal = hscFacilityDecisionBedDay.isValid(hscID, bedDate, bedDayDecisionSeqNum)

        then:
        1 * dao.isValid(rp) >> expectedVal
        0 * _
        retVal == expectedVal

        where:
        testCase | expectedVal
        "passes" | true
        "fails"  | false
    }

    def "valid read"() {
        given:
        long hscID = 1
        Date bedDate = UhgCalendar.getSQLDate("11/05/2011")
        short bedDayDecisionSeqNum = 2
        HscFacilityDecisionBedDayVO vo = new HscFacilityDecisionBedDayVO(hscID: hscID, bedDate: bedDate, bedDayDecisionSeqNum: bedDayDecisionSeqNum)
        ReadProperties rp = getReadProperties(hscID, bedDate, bedDayDecisionSeqNum)

        when:
        HscFacilityDecisionBedDayVO retVO = hscFacilityDecisionBedDay.read(hscID, bedDate, bedDayDecisionSeqNum)

        then:
        1 * dao.read(rp) >> vo
        0 * _
        retVO == vo
    }

    @Unroll
    def "Default Claim Code if Blank - TestCase = #testCaseNumber "() {
        given:
        HscFacilityDecisionBedDayRangeVO bedDayRangeVO = createClinicalBedDayRangeVO(bedDayDecisionOutcomeType, decisionReasonType)

        when:
        hscFacilityDecisionBedDay.defaultClaimCodeIfBlank(bedDayRangeVO, specialProcessType)

        then:
        derivedClaimRemarkCode == bedDayRangeVO.getDerivedClaimRemarkCode()
        overrideClaimRemarkCode == bedDayRangeVO.getOverrideClaimRemarkCode()

        where:
        testCaseNumber | bedDayDecisionOutcomeType                                | decisionReasonType                                          | specialProcessType                                     | derivedClaimRemarkCode                                             | overrideClaimRemarkCode
        1              | HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED | HsrReferenceConstants.DECISIONREASONTYPE_CLAIM_SS_COMMENTS  | HsrReferenceConstants.SPECIALPROCESSTYPE_MAHP          | null                                                               | HsrReferenceConstants.DERIVEDCLAIMREMARKCODE_SPECIALSITUATION
        2              | HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED | HsrReferenceConstants.DECISIONREASONTYPE_CLAIMPAIDCORRECTLY | HsrReferenceConstants.SPECIALPROCESSTYPE_CARE_PROGRAMS | HsrReferenceConstants.DERIVEDCLAIMREMARKCODE_AUTHORIZEDSERVICE     | null
        3              | HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_DENY     | HsrReferenceConstants.DECISIONREASONTYPE_CLAIM_SS_COMMENTS  | HsrReferenceConstants.SPECIALPROCESSTYPE_CARE_PROGRAMS | null                                                               | HsrReferenceConstants.DERIVEDCLAIMREMARKCODE_SPECIALSITUATION
        4              | HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED | HsrReferenceConstants.DECISIONREASONTYPE_CLAIMPAIDCORRECTLY | HsrReferenceConstants.SPECIALPROCESSTYPE_LEGACY        | HsrReferenceConstants.DERIVEDCLAIMREMARKCODE_AUTHORIZEDNOTIFCATION | null
        5              | HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_DENY     | HsrReferenceConstants.DECISIONREASONTYPE_CLAIM_SS_COMMENTS  | HsrReferenceConstants.SPECIALPROCESSTYPE_LEGACY        | null                                                               | HsrReferenceConstants.DERIVEDCLAIMREMARKCODE_SPECIALSITUATION
        6              | HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_DENY     | HsrReferenceConstants.DECISIONREASONTYPE_CLAIMPAIDCORRECTLY | HsrReferenceConstants.SPECIALPROCESSTYPE_LEGACY        | HsrReferenceConstants.DERIVEDCLAIMREMARKCODE_SERVICESNOTCOVERED    | null
        7              | HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_DENY     | HsrReferenceConstants.DECISIONREASONTYPE_CLAIMPAIDCORRECTLY | HsrReferenceConstants.SPECIALPROCESSTYPE_COMMERCIAL    | HsrReferenceConstants.DERIVEDCLAIMREMARKCODE_SERVICESNOTCOVERED    | null
    }

    def "update facility provider for bed days: no bed days"() {
        given:
        HscProviderVO hscProviderVO = new HscProviderVO(hscID: 1)

        when:
        hscFacilityDecisionBedDay.updateFacilityProviderForBedDays(hscProviderVO)

        then:
        1 * dao.list(_) >> { QueryProperties qp ->
            assert qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == hscProviderVO.getHscID()
            assert qp.getQueryFilter(FieldConstants.INACTIVEIND).getFieldValue() == false
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).getFieldValue().equals("8")
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).getCriterion().equals(QueryCriteria.NOT_EQUAL)
            assert qp.getQueryFilters().size() == 3
        }
        0 * _
    }

    def "update facility provider for bed days: update decisions"() {
        given:
        HscProviderVO hscProviderVO = new HscProviderVO(hscID: 1 as Long)
        List bedDays = [
                new HscFacilityDecisionBedDayVO(bedDate: UhgCalendarUtilities.getYesterdaysDate(), writtenDecnCommDateTime: new UhgCalendar()),
                new HscFacilityDecisionBedDayVO(bedDate: UhgCalendarUtilities.getTodaysDate(), writtenDecnCommDateTime: new UhgCalendar())]
        HscDecisionProviderVO decisionProviderVO = new HscDecisionProviderVO(hscID: hscProviderVO.getHscID(), decisionProviderSeqNum: 2 as Short)
        def providerIDType = decisionProviderVO.getProviderIdType()

        when:
        hscFacilityDecisionBedDay.updateFacilityProviderForBedDays(hscProviderVO)

        then:
        1 * dao.list(_) >> { QueryProperties qp ->
            assert qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == hscProviderVO.getHscID()
            assert qp.getQueryFilter(FieldConstants.INACTIVEIND).getFieldValue() == false
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).getFieldValue().equals("8")
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).getCriterion().equals(QueryCriteria.NOT_EQUAL)
            assert qp.getQueryFilters().size() == 3
            return bedDays
        }
        1 * hscDecisionProvider.createAndSaveDecisionProviderFromHscProvider(hscProviderVO) >> decisionProviderVO
        1 * abstractHscDecisionHelper.addDecisionProviderUpdatedActivity(hscProviderVO.getHscID())
        1 * persistenceHelper.updateBatch(bedDays)
        1 * persistenceHelper.addBatch(bedDays)
        0 * _
        bedDays.each({ bedDayVO ->
            assert !bedDayVO.getInactiveInd()
            assert !bedDayVO.getWrittenDecnCommDateTime()
            assert bedDayVO.getDecisionProviderSeqNum() == decisionProviderVO.decisionProviderSeqNum
            assert bedDayVO.getDecisionEnteredReasonType() == HsrReferenceConstants.DECISIONENTEREDREASONTYPE_UPDATEPROVIDER
        })
    }

    def "set written communication date where both current decision and a previous decision are approved"() {
        given:
        HscFacilityDecisionBedDayVO hscFacilityDecisionBedDayVO1 = getHscFacilityDecisionBedDayVO()
        hscFacilityDecisionBedDayVO1.setWrittenDecnCommDateTime(new UhgCalendar(2013, 4, 26))
        hscFacilityDecisionBedDayVO1.setHscID(40000000)
        hscFacilityDecisionBedDayVO1.setBedDayDecisionSeqNum(2 as Short)
        hscFacilityDecisionBedDayVO1.setBedDayDecisionOutcomeType(HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED)

        HscFacilityDecisionBedDayVO hscFacilityDecisionBedDayVO2 = getHscFacilityDecisionBedDayVO()
        hscFacilityDecisionBedDayVO2.setHscID(hscFacilityDecisionBedDayVO1.getHscID())
        hscFacilityDecisionBedDayVO2.setBedDayDecisionSeqNum(hscFacilityDecisionBedDayVO1.getBedDayDecisionSeqNum())
        hscFacilityDecisionBedDayVO2.setWrittenDecnCommDateTime(null)
        hscFacilityDecisionBedDayVO2.setBedDayDecisionOutcomeType(HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED)

        when:
        hscFacilityDecisionBedDay.setBedDayDecisionWrittenCommunicationDate(hscFacilityDecisionBedDayVO1)

        then: "current decision's writtenDecnCommDateTime is set to null"
        1 * dao.list(_) >> { QueryProperties qp ->
            assert qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == hscFacilityDecisionBedDayVO1.getHscID()
            assert qp.getQueryFilter(FieldConstants.BEDDATE).getFieldValue() == hscFacilityDecisionBedDayVO1.getBedDate()
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONSEQNUM).getFieldValue() == hscFacilityDecisionBedDayVO1.getBedDayDecisionSeqNum()
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).getFieldValue() == HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_DENY
            assert qp.getQueryFilter(FieldConstants.WRITTENDECNCOMMDATETIME)
            assert !qp.getQueryFilter(FieldConstants.WRITTENDECNCOMMDATETIME).getFieldValue()
            assert qp.getQueryFilters().size() == 5
            return []
        }
        1 * dao.list(_) >> { QueryProperties qp ->
            assert qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == hscFacilityDecisionBedDayVO1.getHscID()
            assert qp.getQueryFilter(FieldConstants.BEDDATE).getFieldValue() == hscFacilityDecisionBedDayVO1.getBedDate()
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONSEQNUM).getFieldValue() == hscFacilityDecisionBedDayVO1.getBedDayDecisionSeqNum()
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).getFieldValue() == HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED
            assert qp.getQueryFilter(FieldConstants.WRITTENDECNCOMMDATETIME)
            assert !qp.getQueryFilter(FieldConstants.WRITTENDECNCOMMDATETIME).getFieldValue()
            assert qp.getQueryFilters().size() == 5
            return [hscFacilityDecisionBedDayVO2]
        }
        0 * _
        !hscFacilityDecisionBedDayVO2.getWrittenDecnCommDateTime()
    }

    def "set written communication date where current decision is approved, previous decision is denied"() {
        given:
        HscFacilityDecisionBedDayVO hscFacilityDecisionBedDayVO1 = getHscFacilityDecisionBedDayVO()
        hscFacilityDecisionBedDayVO1.setWrittenDecnCommDateTime(new UhgCalendar(2013, 4, 26))
        hscFacilityDecisionBedDayVO1.setHscID(40000000)
        hscFacilityDecisionBedDayVO1.setBedDayDecisionSeqNum(2 as Short)
        hscFacilityDecisionBedDayVO1.setBedDayDecisionOutcomeType(HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED)

        HscFacilityDecisionBedDayVO hscFacilityDecisionBedDayVO2 = getHscFacilityDecisionBedDayVO()
        hscFacilityDecisionBedDayVO2.setHscID(hscFacilityDecisionBedDayVO1.getHscID())
        hscFacilityDecisionBedDayVO2.setBedDayDecisionSeqNum(hscFacilityDecisionBedDayVO1.getBedDayDecisionSeqNum())
        hscFacilityDecisionBedDayVO2.setWrittenDecnCommDateTime(null)
        hscFacilityDecisionBedDayVO2.setBedDayDecisionOutcomeType(HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_DENY)

        when:
        hscFacilityDecisionBedDay.setBedDayDecisionWrittenCommunicationDate(hscFacilityDecisionBedDayVO1)

        then: "current writtenDecnCommDateTime is overwritten with the previous VO's date time"
        1 * dao.list(_) >> { QueryProperties qp ->
            assert qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == hscFacilityDecisionBedDayVO1.getHscID()
            assert qp.getQueryFilter(FieldConstants.BEDDATE).getFieldValue() == hscFacilityDecisionBedDayVO1.getBedDate()
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONSEQNUM).getFieldValue() == hscFacilityDecisionBedDayVO1.getBedDayDecisionSeqNum()
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).getFieldValue() == HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_DENY
            assert qp.getQueryFilter(FieldConstants.WRITTENDECNCOMMDATETIME)
            assert !qp.getQueryFilter(FieldConstants.WRITTENDECNCOMMDATETIME).getFieldValue()
            assert qp.getQueryFilters().size() == 5
            return [hscFacilityDecisionBedDayVO2]
        }
        0 * _
        hscFacilityDecisionBedDayVO2.getWrittenDecnCommDateTime() == hscFacilityDecisionBedDayVO1.getWrittenDecnCommDateTime()
    }

    def "set written communication date where current decision is denied, written decision communication date time != null"() {
        given:
        HscFacilityDecisionBedDayVO hscFacilityDecisionBedDayVO1 = getHscFacilityDecisionBedDayVO()
        hscFacilityDecisionBedDayVO1.setWrittenDecnCommDateTime(new UhgCalendar(2013, 4, 26))
        hscFacilityDecisionBedDayVO1.setHscID(40000000)
        hscFacilityDecisionBedDayVO1.setBedDayDecisionSeqNum(2 as Short)
        hscFacilityDecisionBedDayVO1.setBedDayDecisionOutcomeType(HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_DENY)

        HscFacilityDecisionBedDayVO hscFacilityDecisionBedDayVO2 = getHscFacilityDecisionBedDayVO()
        hscFacilityDecisionBedDayVO2.setHscID(hscFacilityDecisionBedDayVO1.getHscID())
        hscFacilityDecisionBedDayVO2.setBedDayDecisionSeqNum(hscFacilityDecisionBedDayVO1.getBedDayDecisionSeqNum())
        hscFacilityDecisionBedDayVO2.setWrittenDecnCommDateTime(null)
        hscFacilityDecisionBedDayVO2.setBedDayDecisionOutcomeType(HsrReferenceConstants.DECISIONOUTCOMETYPE_APPROVED)

        when:
        hscFacilityDecisionBedDay.setBedDayDecisionWrittenCommunicationDate(hscFacilityDecisionBedDayVO1)

        then: "current decision's writtenDecnCommDateTime is set to null"
        1 * dao.list(_) >> { QueryProperties qp ->
            assert qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == hscFacilityDecisionBedDayVO1.getHscID()
            assert qp.getQueryFilter(FieldConstants.BEDDATE).getFieldValue() == hscFacilityDecisionBedDayVO1.getBedDate()
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONSEQNUM).getFieldValue() == hscFacilityDecisionBedDayVO1.getBedDayDecisionSeqNum()
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).getFieldValue() == HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_DENY
            assert qp.getQueryFilter(FieldConstants.WRITTENDECNCOMMDATETIME)
            assert !qp.getQueryFilter(FieldConstants.WRITTENDECNCOMMDATETIME).getFieldValue()
            assert qp.getQueryFilters().size() == 5
            return []
        }
        0 * _
        !hscFacilityDecisionBedDayVO2.getWrittenDecnCommDateTime()
    }

    def "update writtenDecnCommDateTime"() {
        given:
        String[] fields = [FieldConstants.WRITTENDECNCOMMDATETIME]
        HscFacilityDecisionBedDayVO hscFacilityDecisionBedDayVO = getHscFacilityDecisionBedDayVO()

        when:
        hscFacilityDecisionBedDay.updateWrittenDecnCommDateTime(hscFacilityDecisionBedDayVO)

        then:
        1 * persistenceHelper.updateSubset(hscFacilityDecisionBedDayVO, fields, true)
        0 * _
    }

    def "Get All Approved Bed Days"() {
        given:
        long hscID = 1
        HscFacilityDecisionBedDayVO hscFacilityDecisionBedDayVO = new HscFacilityDecisionBedDayVO(hscID: hscID, inactiveInd: false, bedDayDecisionOutcomeType: HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED, decisionSubType: HsrReferenceConstants.DECISIONSUBTYPE_CLINICAL)

        when:
        List<HscFacilityDecisionBedDayVO> retList = hscFacilityDecisionBedDay.getAllApprovedBedDays(hscID)

        then:
        1 * dao.list(_) >> { QueryProperties qp ->
            assert qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == hscID
            assert qp.getQueryFilter(FieldConstants.INACTIVEIND).getFieldValue() == false
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).getFieldValue().equals(HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED)
            assert qp.getQueryFilter(FieldConstants.DECISIONSUBTYPE).getFieldValue().equals(hscFacilityDecisionBedDayVO.getDecisionSubType())
            assert qp.getQueryFilters().size() == 4
            return [hscFacilityDecisionBedDayVO]
        }
        0 * _
        retList == [hscFacilityDecisionBedDayVO]
    }

    def "Get All Approved Bed Days - hscID=0"() {
        when:
        List<HscFacilityDecisionBedDayVO> retList = hscFacilityDecisionBedDay.getAllApprovedBedDays(0)

        then:
        0 * _
        retList == new ArrayList<HscFacilityDecisionBedDayVO>()
    }

    def "update bed day list fails"() {
        given:
        final ValueObject vo = new HscFacilityDecisionBedDayVO(hscID: 1 as Long)
        final List<HscFacilityDecisionBedDayVO> bedDays = Arrays.asList(vo)

        when:
        hscFacilityDecisionBedDay.updateBedDayList(vo, bedDays)

        then: "updateBatch fails, finder exception is caught, runtime exception is thrown"
        1 * persistenceHelper.updateBatch(bedDays) >> { throw new FinderException() }
        0 * _
        thrown UhgRuntimeException
    }

    def "update letter request properties"() {
        given:
        HscFacilityDecisionBedDayVO hscFacilityDecisionBedDayVO = getHscFacilityDecisionBedDayVO()
        final String[] propertyNames = [FieldConstants.POLICYDOCUMENTTYPE, FieldConstants.MEDICALPOLICYNAMEORGUIDELINE, FieldConstants.LANGUAGESOURCEANDSECTIONNAME, FieldConstants.STATEOFJURISDICTION, FieldConstants.STATESPECIFICPLANINFOFORKYHMO, FieldConstants.OHIOPLANS, FieldConstants.RECIPIENTFAXNUMBER, FieldConstants.RECIPIENTFAXINTERNATIONALIND, FieldConstants.LANGUAGE, FieldConstants.LETTERRATIONALE]

        when:
        hscFacilityDecisionBedDay.updateLetterRequestProperties(hscFacilityDecisionBedDayVO)

        then:
        1 * persistenceHelper.updateSubset(hscFacilityDecisionBedDayVO, propertyNames, true)
        0 * _
    }

    def "update letter request properties fails"() {
        given:
        HscFacilityDecisionBedDayVO hscFacilityDecisionBedDayVO = getHscFacilityDecisionBedDayVO()
        final String[] propertyNames = [FieldConstants.POLICYDOCUMENTTYPE, FieldConstants.MEDICALPOLICYNAMEORGUIDELINE, FieldConstants.LANGUAGESOURCEANDSECTIONNAME, FieldConstants.STATEOFJURISDICTION, FieldConstants.STATESPECIFICPLANINFOFORKYHMO, FieldConstants.OHIOPLANS, FieldConstants.RECIPIENTFAXNUMBER, FieldConstants.RECIPIENTFAXINTERNATIONALIND, FieldConstants.LANGUAGE, FieldConstants.LETTERRATIONALE]

        when:
        hscFacilityDecisionBedDay.updateLetterRequestProperties(hscFacilityDecisionBedDayVO)

        then: "update throws an exception which is caught, runtime exception is thrown"
        1 * persistenceHelper.updateSubset(hscFacilityDecisionBedDayVO, propertyNames, true) >> {
            throw new Exception()
        }
        0 * _
        thrown UhgRuntimeException
    }

    def "update letter request properties for a list"() {
        given:
        HscFacilityDecisionBedDayVO hscFacilityDecisionBedDayVO = getHscFacilityDecisionBedDayVO()
        final String[] propertyNames = [FieldConstants.POLICYDOCUMENTTYPE, FieldConstants.MEDICALPOLICYNAMEORGUIDELINE, FieldConstants.LANGUAGESOURCEANDSECTIONNAME, FieldConstants.STATEOFJURISDICTION, FieldConstants.STATESPECIFICPLANINFOFORKYHMO, FieldConstants.OHIOPLANS, FieldConstants.RECIPIENTFAXNUMBER, FieldConstants.RECIPIENTFAXINTERNATIONALIND, FieldConstants.LANGUAGE, FieldConstants.LETTERRATIONALE]
        List<HscFacilityDecisionBedDayVO> hscFacilityDecisionBedDayVOs = new ArrayList<HscFacilityDecisionBedDayVO>()
        hscFacilityDecisionBedDayVOs.add(hscFacilityDecisionBedDayVO)
        hscFacilityDecisionBedDayVOs.add(hscFacilityDecisionBedDayVO)

        when:
        hscFacilityDecisionBedDay.updateLetterRequestProperties(hscFacilityDecisionBedDayVOs)

        then: "updateLetterRequestProperties is called for each VO in the given list"
        2 * persistenceHelper.updateSubset(hscFacilityDecisionBedDayVO, propertyNames, true)
        0 * _
    }

    def "check for missing bed day decisions, excluding pending decisions, when there are none missing"() {
        given:
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: 1, actualAdmissionDateTime: new UhgCalendar(2010, 11, 5), actualDischargeDateTime: new UhgCalendar(2010, 11, 5))
        HscFacilityDecisionBedDayVO hscFacilityDecisionBedDayVO = getHscFacilityDecisionBedDayVO()
        hscFacilityDecisionBedDayVO.setBedDate(UhgCalendar.getSQLDate("11/05/2010"))

        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        qp.addQueryFilter(new QueryFilter(FieldConstants.HSCID, hscFacilityVO.getHscID()))
        qp.addQueryFilter(new QueryFilter(FieldConstants.INACTIVEIND, false))
        qp.setOrderByAscFields(FieldConstants.BEDDATE)
        qp.setUnboundedListAll(true)
        qp.addQueryFilter(new QueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE, HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_VOID, QueryCriteria.NOT_EQUAL))
        qp.addQueryFilter(new QueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE, HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_PEND, QueryCriteria.NOT_EQUAL))

        when: "range is from 11/5/2010-11/5/2010 and a VO for 11/5/2010 exists"
        boolean retVal = hscFacilityDecisionBedDay.isAnyBedDayDecisionMissingNotInclPend(hscFacilityVO)

        then: "returns false, days are all accounted for"
        1 * dao.list(qp) >> [hscFacilityDecisionBedDayVO]
        0 * _
        !retVal
    }

    def "check for missing bed day decisions, excluding pending decisions, when there are days missing"() {
        given:
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: 1, actualAdmissionDateTime: new UhgCalendar(2010, 11, 5), actualDischargeDateTime: new UhgCalendar(2010, 11, 8))
        HscFacilityDecisionBedDayVO hscFacilityDecisionBedDayVO = getHscFacilityDecisionBedDayVO()
        hscFacilityDecisionBedDayVO.setBedDate(UhgCalendar.getSQLDate("11/05/2010"))

        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        qp.addQueryFilter(new QueryFilter(FieldConstants.HSCID, hscFacilityVO.getHscID()))
        qp.addQueryFilter(new QueryFilter(FieldConstants.INACTIVEIND, false))
        qp.setOrderByAscFields(FieldConstants.BEDDATE)
        qp.setUnboundedListAll(true)
        qp.addQueryFilter(new QueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE, HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_VOID, QueryCriteria.NOT_EQUAL))
        qp.addQueryFilter(new QueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE, HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_PEND, QueryCriteria.NOT_EQUAL))

        when: "range is from 11/5/2010-11/8/2010, but only a VO for 11/5/2010 exists"
        boolean retVal = hscFacilityDecisionBedDay.isAnyBedDayDecisionMissingNotInclPend(hscFacilityVO)

        then: "returns true, not all days are accounted for"
        1 * dao.list(qp) >> [hscFacilityDecisionBedDayVO]
        0 * _
        retVal
    }

    def "check for missing bed day decisions when there are none missing"() {
        given:
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: 1, actualAdmissionDateTime: new UhgCalendar(2010, 11, 5), actualDischargeDateTime: new UhgCalendar(2010, 11, 5))
        HscFacilityDecisionBedDayVO hscFacilityDecisionBedDayVO = getHscFacilityDecisionBedDayVO()
        hscFacilityDecisionBedDayVO.setBedDate(UhgCalendar.getSQLDate("11/05/2010"))

        when: "range is from 11/5/2010-11/5/2010 and a VO for 11/5/2010 exists"
        boolean retVal = hscFacilityDecisionBedDay.isAnyBedDayDecisionMissing(hscFacilityVO)

        then: "returns false, days are all accounted for"
        1 * dao.list(_) >> { QueryProperties qp ->
            assert qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == hscFacilityVO.getHscID()
            assert qp.getQueryFilter(FieldConstants.INACTIVEIND).getFieldValue() == false
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).getFieldValue().equals("8")
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).getCriterion().equals(QueryCriteria.NOT_EQUAL)
            assert qp.getQueryFilters().size() == 3
            return [hscFacilityDecisionBedDayVO]
        }
        0 * _
        !retVal
    }

    def "check for missing bed day decisions when there are days missing"() {
        given:
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: 1, actualAdmissionDateTime: new UhgCalendar(2010, 11, 5), actualDischargeDateTime: new UhgCalendar(2010, 11, 8))
        HscFacilityDecisionBedDayVO hscFacilityDecisionBedDayVO = getHscFacilityDecisionBedDayVO()
        hscFacilityDecisionBedDayVO.setBedDate(UhgCalendar.getSQLDate("11/05/2010"))

        when: "range is from 11/5/2010-11/8/2010, but only a VO for 11/5/2010 exists"
        boolean retVal = hscFacilityDecisionBedDay.isAnyBedDayDecisionMissing(hscFacilityVO)

        then: "returns true, not all days are accounted for"
        1 * dao.list(_) >> { QueryProperties qp ->
            assert qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == hscFacilityVO.getHscID()
            assert qp.getQueryFilter(FieldConstants.INACTIVEIND).getFieldValue() == false
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).getFieldValue().equals("8")
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).getCriterion().equals(QueryCriteria.NOT_EQUAL)
            assert qp.getQueryFilters().size() == 3
            return [hscFacilityDecisionBedDayVO]
        }
        0 * _
        retVal
    }

    @Unroll
    def "validate range - #rateType negotiated rate is out of range - #testCase"() {
        given:
        HscFacilityDecisionBedDayVO bedDayVO = getHscFacilityDecisionBedDayVO()
        bedDayVO.setNegotiatedRateType(rateType)
        bedDayVO.setNegotiatedRate(rate)

        when:
        hscFacilityDecisionBedDay.validateRangeNegotiatedRate(bedDayVO)

        then: "error message added, negotiated rate resets to 0"
        0 * _
        bedDayVO.errorMessagesExist()
        bedDayVO.getMessage(FieldConstants.NEGOTIATEDRATE).first().getMessage().equals(errorMessage)
        bedDayVO.getNegotiatedRate() == 0

        where:
        testCase   | rateType                                         | rate                                 | errorMessage
        "too low"  | HsrReferenceConstants.NEGOTIATEDRATETYPE_DOLLAR  | BedDayConstants.MIN_RATE_DOLLAR - 1  | BedDayMessages.ERR_INVALID_NEGOTIATED_RATE_DOLLAR
        "too low"  | HsrReferenceConstants.NEGOTIATEDRATETYPE_PERCENT | BedDayConstants.MIN_RATE_PERCENT - 1 | BedDayMessages.ERR_INVALID_NEGOTIATED_RATE_PERCENT
        "too high" | HsrReferenceConstants.NEGOTIATEDRATETYPE_DOLLAR  | BedDayConstants.MAX_RATE_DOLLAR + 1  | BedDayMessages.ERR_INVALID_NEGOTIATED_RATE_DOLLAR
        "too high" | HsrReferenceConstants.NEGOTIATEDRATETYPE_PERCENT | BedDayConstants.MAX_RATE_PERCENT + 1 | BedDayMessages.ERR_INVALID_NEGOTIATED_RATE_PERCENT

    }

    def "validate range - dollar negotiated rate is over confirmation range"() {
        given:
        HscFacilityDecisionBedDayVO bedDayVO = getHscFacilityDecisionBedDayVO()
        bedDayVO.setNegotiatedRateType(HsrReferenceConstants.NEGOTIATEDRATETYPE_DOLLAR)
        bedDayVO.setNegotiatedRate(BedDayConstants.DOLLAR_CONFIRMATION_LEVEL + 1)

        when:
        hscFacilityDecisionBedDay.validateRangeNegotiatedRate(bedDayVO)

        then:
        0 * _
        bedDayVO.getMessage(FieldConstants.NEGOTIATEDRATE).first().getMessage().equals(BedDayMessages.WRN_NEGOTIATED_RATE_CONFIRMATION_LEVEL)
    }

    @Unroll
    def "is MAHP member deny decision with SS claim remark code - Test Case=#testCase"() {
        given:
        HscVO hscVO = new HscVO(hscID: 1, specialProcessType: specialProcType)
        HscFacilityDecisionBedDayVO hscFacilityDecisionBedDayVO = new HscFacilityDecisionBedDayVO(hscID: hscVO.getHscID(), bedDayDecisionOutcomeType: decisionOutcome, derivedClaimRemarkCode: derClaimRmkCode)

        when:
        boolean retVal = hscFacilityDecisionBedDay.isMAHPmemberDenyDecisionWithSSClaimRemarkCode(hscVO, hscFacilityDecisionBedDayVO)

        then:
        0 * _
        retVal == expectedVal

        where:
        testCase | expectedVal | specialProcType                               | decisionOutcome                                      | derClaimRmkCode
        1        | true        | HsrReferenceConstants.SPECIALPROCESSTYPE_MAHP | HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_DENY | HsrReferenceConstants.CLAIMREMARKCODE_SPECIAL_SITUATION
        2        | false       | ""                                            | HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_DENY | HsrReferenceConstants.CLAIMREMARKCODE_SPECIAL_SITUATION
        3        | false       | HsrReferenceConstants.SPECIALPROCESSTYPE_MAHP | ""                                                   | HsrReferenceConstants.CLAIMREMARKCODE_SPECIAL_SITUATION
        4        | false       | HsrReferenceConstants.SPECIALPROCESSTYPE_MAHP | HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_DENY | ""
    }

    def "validate no overlap in range - fails"() {
        given:
        HscFacilityDecisionBedDayRangeVO bedDayRangeVO = createClinicalBedDayRangeVO(HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED, "95")
        HscFacilityDecisionBedDayVO hscFacilityDecisionBedDayVO = getHscFacilityDecisionBedDayVO()
        hscFacilityDecisionBedDayVO.setHscID(1 as Long)
        hscFacilityDecisionBedDayVO.setBedDate(UhgCalendar.getSQLDate("11/05/2010"))

        when:
        hscFacilityDecisionBedDay.validateRangeNoOverlap(bedDayRangeVO)

        then:
        1 * dao.list(_) >> { QueryProperties qp ->
            assert qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == hscFacilityDecisionBedDayVO.getHscID()
            assert qp.getQueryFilter(FieldConstants.INACTIVEIND).getFieldValue() == false
            assert qp.getQueryFilter(FieldConstants.BEDDATE).getFieldValue().equals(bedDayRangeVO.getBedDateBegin())
            assert qp.getQueryFilter(FieldConstants.BEDDATE).getFieldValue2().equals(bedDayRangeVO.getBedDateEnd())
            assert qp.getQueryFilter(FieldConstants.BEDDATE).getCriterion().equals(QueryCriteria.FIELD_BETWEEN_VALUES)
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).getFieldValue().equals("8")
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).getCriterion().equals(QueryCriteria.NOT_EQUAL)
            assert qp.getQueryFilters().size() == 4
            return [hscFacilityDecisionBedDayVO]
        }
        0 * _
        bedDayRangeVO.errorMessagesExist()
        bedDayRangeVO.getGlobalMessages().first().getMessageID().equals(BedDayMessages.ERR_MSGID_BED_DAY_DECISION_EXISTS)
    }

    def "validate range override eligibility - claim remark code is 'special situation'"() {
        given:
        HscFacilityDecisionBedDayRangeVO bedDayRangeVO = createClinicalBedDayRangeVO(HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED, "95")
        bedDayRangeVO.setOverrideClaimRemarkCode(HsrReferenceConstants.OVERRIDECLAIMREMARKCODE_SPECIALSITUATION)
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: 1, actualAdmissionDateTime: new UhgCalendar(2010, 11, 5), actualDischargeDateTime: new UhgCalendar(2010, 11, 8))

        when:
        hscFacilityDecisionBedDay.validateRangeOverrideEligibility(bedDayRangeVO, hscFacilityVO)

        then:
        0 * _
        bedDayRangeVO.errorMessagesExist()
        bedDayRangeVO.getGlobalMessages().first().getMessageID().equals(BedDayMessages.ERR_OVERRIDE_REMARK_CODE_SS.getMessageID())
    }

    def "validate range override eligibility - bed date not within length of stay"() {
        given:
        HscFacilityDecisionBedDayRangeVO bedDayRangeVO = createClinicalBedDayRangeVO(HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED, "95")
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: 1, actualAdmissionDateTime: new UhgCalendar(2011, 11, 5), actualDischargeDateTime: new UhgCalendar(2011, 11, 8))

        when: "the facility VO is out of range"
        hscFacilityDecisionBedDay.validateRangeOverrideEligibility(bedDayRangeVO, hscFacilityVO)

        then: "errors are set"
        0 * _
        bedDayRangeVO.errorMessagesExist()
        bedDayRangeVO.getGlobalMessages().size() == 1
    }

    def "validate range void eligibility - bed date within length of stay"() {
        given:
        HscFacilityDecisionBedDayRangeVO bedDayRangeVO = createClinicalBedDayRangeVO(HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED, "95")
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: 1, actualAdmissionDateTime: new UhgCalendar(2010, 11, 6), actualDischargeDateTime: new UhgCalendar(2010, 11, 7))

        when: "the facility VO is in range"
        hscFacilityDecisionBedDay.validateRangeVoidEligibility(bedDayRangeVO)

        then: "errors are set"
        1 * hscFacility.read(hscFacilityVO.getHscID(), []) >> hscFacilityVO
        0 * _
        bedDayRangeVO.errorMessagesExist()
        bedDayRangeVO.getGlobalMessages().size() == 1
    }

    def "validate range length of stay - actual dates out of range"() {
        given:
        HscFacilityDecisionBedDayRangeVO bedDayRangeVO = createClinicalBedDayRangeVO(HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED, "95")
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: 1, actualAdmissionDateTime: new UhgCalendar(2010, 11, 6), actualDischargeDateTime: new UhgCalendar(2010, 11, 7))

        when: "actual admission date is after bed day; actual discharge is before bed day"
        hscFacilityDecisionBedDay.validateRangeLengthOfStay(bedDayRangeVO, hscFacilityVO)

        then: "warnings are set, no errors on VO"
        0 * _
        !bedDayRangeVO.errorMessagesExist()
        bedDayRangeVO.getGlobalMessages().contains(BedDayMessages.WRN_BED_DAY_BEFORE_ACTUAL_LOS)
        bedDayRangeVO.getGlobalMessages().contains(BedDayMessages.WRN_BED_DAY_AFTER_ACTUAL_LOS)
    }

    def "validate range length of stay - bed date before expected LOS"() {
        given:
        HscFacilityDecisionBedDayRangeVO bedDayRangeVO = createClinicalBedDayRangeVO(HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED, "95")
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: 1, expectedAdmissionDate: UhgCalendar.getSQLDate("11/06/2010"), expectedDischargeDate: UhgCalendar.getSQLDate("11/07/2010"))

        when: "expected admission date is after bed day"
        hscFacilityDecisionBedDay.validateRangeLengthOfStay(bedDayRangeVO, hscFacilityVO)

        then: "warnings are set, no errors on VO"
        0 * _
        !bedDayRangeVO.errorMessagesExist()
        bedDayRangeVO.getGlobalMessages().contains(BedDayMessages.WRN_BED_DAY_BEFORE_EXPECTED_LOS)
    }

    def "validate range date range"() {
        given:
        HscFacilityDecisionBedDayRangeVO bedDayRangeVO = createClinicalBedDayRangeVO(HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED, "95")
        bedDayRangeVO.setBedDateBegin(UhgCalendar.getSQLDate("11/08/2010"))
        bedDayRangeVO.setBedDateEnd(UhgCalendar.getSQLDate("11/05/2010"))

        when:
        hscFacilityDecisionBedDay.validateRangeDateRange(bedDayRangeVO)

        then:
        0 * _
        bedDayRangeVO.errorMessagesExist()
        bedDayRangeVO.getGlobalMessages().contains(BedDayMessages.ERR_END_BEFORE_BEGIN_DATE)
    }

    @Unroll
    def "validate date change fails - Test Case = #testCase"() {
        given:
        HscFacilityDecisionBedDayRangeVO bedDayRangeVO = createClinicalBedDayRangeVO(HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED, "95")

        when:
        hscFacilityDecisionBedDay.validateDateChange(bedDayRangeVO, originalBeginDate, originalEndDate)

        then:
        0 * _
        !bedDayRangeVO.errorMessagesExist()
        bedDayRangeVO.getGlobalMessages().contains(BedDayMessages.WRN_DATES_MUST_BE_CHANGED_THROUGH_OVERRIDE)

        where:
        testCase | originalBeginDate                    | originalEndDate
        1        | UhgCalendar.getSQLDate("11/04/2010") | UhgCalendar.getSQLDate("11/08/2010")
        2        | UhgCalendar.getSQLDate("11/05/2010") | UhgCalendar.getSQLDate("11/09/2010")
    }

    def "validate date change passes"() {
        given:
        HscFacilityDecisionBedDayRangeVO bedDayRangeVO = createClinicalBedDayRangeVO(HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED, "95")

        when:
        hscFacilityDecisionBedDay.validateDateChange(bedDayRangeVO, UhgCalendar.getSQLDate("11/05/2010"), UhgCalendar.getSQLDate("11/08/2010"))

        then:
        0 * _
        !bedDayRangeVO.errorMessagesExist()
        !bedDayRangeVO.getGlobalMessages().contains(BedDayMessages.WRN_DATES_MUST_BE_CHANGED_THROUGH_OVERRIDE)
    }

    @Unroll
    def "validate range override date fields - Test Case = #testCase"() {
        given:
        HscFacilityDecisionBedDayRangeVO bedDayRangeVO = createClinicalBedDayRangeVO(HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED, "95")
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: 1, actualAdmissionDateTime: actualAdmitDate, actualDischargeDateTime: actualDischargeDate)

        when:
        hscFacilityDecisionBedDay.validateRangeOverrideDateFields(bedDayRangeVO, hscFacilityVO)

        then:
        0 * _
        bedDayRangeVO.errorMessagesExist()
        bedDayRangeVO.getGlobalMessages().contains(BedDayMessages.ERR_OVERRIDE_BED_DAY_ACTUAL_LOS)

        where:
        testCase | actualAdmitDate              | actualDischargeDate
        1        | new UhgCalendar(2010, 11, 6) | new UhgCalendar(2010, 11, 9)
        2        | new UhgCalendar(2010, 11, 4) | new UhgCalendar(2010, 11, 7)
    }

    def "validate required date fields - missing begin and end dates"() {
        given:
        HscFacilityDecisionBedDayRangeVO bedDayRangeVO = new HscFacilityDecisionBedDayRangeVO(hscID: 1)

        when:
        hscFacilityDecisionBedDay.validateRangeRequiredDateFields(bedDayRangeVO)

        then:
        0 * _
        bedDayRangeVO.errorMessagesExist()
        bedDayRangeVO.getGlobalMessages().contains(BedDayMessages.ERR_BEGIN_DATE_REQUIRED)
        bedDayRangeVO.getGlobalMessages().contains(BedDayMessages.ERR_END_DATE_REQUIRED)
    }

    def "validate original date fields - original begin and end dates are null"() {
        given:
        HscFacilityDecisionBedDayRangeVO bedDayRangeVO = new HscFacilityDecisionBedDayRangeVO(hscID: 1)

        when:
        hscFacilityDecisionBedDay.validateRangeOriginalDateFields(bedDayRangeVO, null, null)

        then:
        0 * _
        bedDayRangeVO.errorMessagesExist()
        bedDayRangeVO.getGlobalMessages().contains(BedDayMessages.ERR_ORIGNAL_BEGIN_DATE_REQUIRED)
        bedDayRangeVO.getGlobalMessages().contains(BedDayMessages.ERR_ORIGNAL_END_DATE_REQUIRED)
    }

    def "validate range required fields"() {
        given:
        HscFacilityDecisionBedDayRangeVO vo = new HscFacilityDecisionBedDayRangeVO(hscID: 1)

        when: "vo has multiple missing values which are required"
        hscFacilityDecisionBedDay.validateRangeRequiredFields(vo)

        then:
        0 * _
        vo.errorMessagesExist()
        vo.getMessage(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).first().getMessage().equals(SystemGlobalMessages.ERR_REQUIRED_VALUE)
        vo.getMessage(FieldConstants.DECISIONREASONTYPE).first().getMessage().equals(SystemGlobalMessages.ERR_REQUIRED_VALUE)
        vo.getMessage(FieldConstants.DECISIONMADEBYUSERID).first().getMessage().equals(SystemGlobalMessages.ERR_REQUIRED_VALUE)
        vo.getMessage(FieldConstants.BEDTYPEID).first().getMessage().equals(SystemGlobalMessages.ERR_REQUIRED_VALUE)
        vo.getMessage(FieldConstants.REVENUECODE).first().getMessage().equals(SystemGlobalMessages.ERR_REQUIRED_VALUE)
    }

    def "validate range required fields - decision made by user is invalid"() {
        given:
        HscFacilityDecisionBedDayRangeVO vo = new HscFacilityDecisionBedDayRangeVO(hscID: 1, decisionMadeByUserID: "test ID")

        when:
        hscFacilityDecisionBedDay.validateRangeRequiredFields(vo)

        then:
        1 * appUser.read(vo.getDecisionMadeByUserID()) >> null
        0 * _
        vo.errorMessagesExist()
        vo.getMessage(FieldConstants.DECISIONMADEBYUSERID).first().getMessage().equals(SystemGlobalMessages.ERR_INVALID_VALUE)
    }

    def "validate range required fields - negotiated rate type is improperly populated"() {
        given:
        HscFacilityDecisionBedDayRangeVO vo = new HscFacilityDecisionBedDayRangeVO(hscID: 1, negotiatedRate: 2, negotiatedRateType: "")

        when: "vo has a negotiaed rate when the negotiated rate type is not given"
        hscFacilityDecisionBedDay.validateRangeRequiredFields(vo)

        then:
        0 * _
        vo.errorMessagesExist()
        vo.getMessage(FieldConstants.NEGOTIATEDRATETYPE).first().getMessage()
    }

    def "validate range override required fields"() {
        given:
        HscFacilityDecisionBedDayRangeVO vo = new HscFacilityDecisionBedDayRangeVO(hscID: 1)

        when: "vo is missing override reason type"
        hscFacilityDecisionBedDay.validateRangeOverrideRequiredFields(vo)

        then:
        0 * _
        vo.errorMessagesExist()
        vo.getMessage(FieldConstants.OVERRIDEREASONTYPE).first().getMessage().equals(SystemGlobalMessages.ERR_REQUIRED_VALUE)
    }

    def "validate range override"() {
        given:
        HscFacilityDecisionBedDayRangeVO bedDayRangeVO = createClinicalBedDayRangeVO(HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED, "95")
        bedDayRangeVO.setOverrideReasonType("test type")
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: 1, actualAdmissionDateTime: new UhgCalendar(2010, 11, 4), actualDischargeDateTime: new UhgCalendar(2010, 11, 9))

        when: "helper validation method is run"
        hscFacilityDecisionBedDay.validateRangeOverride(bedDayRangeVO)

        then: "multiple validate methods are run; the given VO has all required values and they are valid; no errors on VO"
        1 * hscFacility.read(hscFacilityVO.getHscID(), []) >> hscFacilityVO
        0 * _
        !bedDayRangeVO.errorMessagesExist()
    }

    def "next ice review date is required"() {
        given:
        long hscID = 1
        long memberID = 2
        HscVO hscVO = new HscVO(hscID: hscID, businessClassificationType: HsrReferenceConstants.BUS_CLS_TYP_ID_E_AND_I, memberID: memberID)
        HscFacilityDecisionBedDayRangeVO bedDayRangeVO = createClinicalBedDayRangeVO(HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED, "95")
        bedDayRangeVO.setDecisionSubType(HsrReferenceConstants.DECISIONSUBTYPE_CLINICAL)
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: hscID)

        when:
        boolean retVal = hscFacilityDecisionBedDay.isNextIceReviewDateRequired(hscVO, bedDayRangeVO, hscFacilityVO)

        then:
        1 * hsc.isConcurrentCase(hscVO, hscFacilityVO) >> true
        0 * _
        retVal
    }

    def "next ice review date is not required, decision outcome is not approved"() {
        given:
        long hscID = 1
        HscVO hscVO = new HscVO(hscID: hscID, businessClassificationType: HsrReferenceConstants.BUS_CLS_TYP_ID_E_AND_I)
        HscFacilityDecisionBedDayRangeVO bedDayRangeVO = createClinicalBedDayRangeVO(HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_DENY, "95")
        bedDayRangeVO.setDecisionSubType(HsrReferenceConstants.DECISIONSUBTYPE_CLINICAL)
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: hscID)

        when:
        boolean retVal = hscFacilityDecisionBedDay.isNextIceReviewDateRequired(hscVO, bedDayRangeVO, hscFacilityVO)

        then:
        0 * _
        !retVal
    }

    def "next ice review date is required, excluding outcome"() {
        given:
        long hscID = 1
        long memberID = 2
        HscVO hscVO = new HscVO(hscID: hscID, businessClassificationType: HsrReferenceConstants.BUS_CLS_TYP_ID_E_AND_I, memberID: memberID)
        HscFacilityDecisionBedDayRangeVO bedDayRangeVO = createClinicalBedDayRangeVO(HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED, "95")
        bedDayRangeVO.setDecisionSubType(HsrReferenceConstants.DECISIONSUBTYPE_CLINICAL)
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: hscID)

        when:
        boolean retVal = hscFacilityDecisionBedDay.isNextIceReviewDateRequiredExcludeOutcome(hscVO, bedDayRangeVO, hscFacilityVO)

        then:
        1 * hsc.isConcurrentCase(hscVO, hscFacilityVO) >> true
        0 * _
        retVal
    }

    def "is next ice review date required, excluding outcome, isConcurrent=false"() {
        given:
        long hscID = 1
        HscVO hscVO = new HscVO(hscID: hscID, businessClassificationType: HsrReferenceConstants.BUS_CLS_TYP_ID_E_AND_I)
        HscFacilityDecisionBedDayRangeVO bedDayRangeVO = createClinicalBedDayRangeVO(HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED, "95")
        bedDayRangeVO.setDecisionSubType(HsrReferenceConstants.DECISIONSUBTYPE_CLINICAL)
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: hscID)

        when:
        boolean retVal = hscFacilityDecisionBedDay.isNextIceReviewDateRequiredExcludeOutcome(hscVO, bedDayRangeVO, hscFacilityVO)

        then:
        1 * hsc.isConcurrentCase(hscVO, hscFacilityVO) >> false
        0 * _
        !retVal
    }

    @Unroll
    def "is next ice review date required, excluding outcome, Test Case = #testCase"() {
        given:
        long hscID = 1
        HscVO hscVO = new HscVO(hscID: hscID, businessClassificationType: bussinessClassType)
        HscFacilityDecisionBedDayRangeVO bedDayRangeVO = createClinicalBedDayRangeVO(HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED, "95")
        bedDayRangeVO.setDecisionSubType(decSubType)
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: hscID)

        when:
        boolean retVal = hscFacilityDecisionBedDay.isNextIceReviewDateRequiredExcludeOutcome(hscVO, bedDayRangeVO, hscFacilityVO)

        then:
        0 * _
        !retVal

        where:
        testCase                            | bussinessClassType                           | decSubType
        "decision sub type is not clinical" | HsrReferenceConstants.BUS_CLS_TYP_ID_E_AND_I | ""
        "hscVO is not EandI"                | ""                                           | ""
    }

    def "validate required fields for concurrent case passes"() {
        given:
        long hscID = 1
        HscVO hscVO = new HscVO(hscID: hscID, businessClassificationType: HsrReferenceConstants.BUS_CLS_TYP_ID_E_AND_I)
        HscFacilityDecisionBedDayRangeVO bedDayRangeVO = createClinicalBedDayRangeVO(HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED, "95")
        bedDayRangeVO.setDecisionSubType(HsrReferenceConstants.DECISIONSUBTYPE_CLINICAL)
        bedDayRangeVO.setNextICMReviewDate(UhgCalendar.getSQLDate("11/05/2020"))
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: hscID)

        when: "date for next review is set for bedDayRangeVO"
        hscFacilityDecisionBedDay.validateRequiredFieldsForConcurrentCase(hscVO, bedDayRangeVO, hscFacilityVO)

        then: "validation passes, no errors on the VO"
        0 * _
        !bedDayRangeVO.errorMessagesExist()
    }

    def "validate required fields for concurrent case fails"() {
        given:
        long hscID = 1
        long memberID = 2
        HscVO hscVO = new HscVO(hscID: hscID, businessClassificationType: HsrReferenceConstants.BUS_CLS_TYP_ID_E_AND_I, memberID: memberID)
        HscFacilityDecisionBedDayRangeVO bedDayRangeVO = createClinicalBedDayRangeVO(HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED, "95")
        bedDayRangeVO.setDecisionSubType(HsrReferenceConstants.DECISIONSUBTYPE_CLINICAL)
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: hscID)

        when: "date for next review is not set for bedDayRangeVO"
        hscFacilityDecisionBedDay.validateRequiredFieldsForConcurrentCase(hscVO, bedDayRangeVO, hscFacilityVO)

        then: "validation fails, errors added to VO"
        1 * hsc.isConcurrentCase(hscVO, hscFacilityVO) >> true
        0 * _
        bedDayRangeVO.errorMessagesExist()
    }

    @Unroll
    def "set Hsc Facility Decision bed day dates and concurrent attributes"() {
        given:
        def hscID = 1 as Long
        HscFacilityDecisionBedDayRangeVO bedDayRangeVO = createClinicalBedDayRangeVO(HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED, "95")
        String decisionSubType = HsrReferenceConstants.DECISIONSUBTYPE_CLINICAL
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: hscID, actualAdmissionDateTime: new UhgCalendar(2010, 11, 06))
        HscVO hscVO = new HscVO(hscID: hscID)
        HscFacilityDecisionBedDayVO hscFacilityDecisionBedDayVO = new HscFacilityDecisionBedDayVO(hscID: hscID, bedDayDecisionOutcomeType: HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED, bedDate: UhgCalendar.getSQLDate("12/10/2011"))

        when:
        hscFacilityDecisionBedDay.setHscFacilityDecisionBDDatesAndCncrntAttributes(hscID, bedDayRangeVO, decisionSubType)

        then:
        1 * hscFacility.read(hscID, []) >> hscFacilityVO
        1 * dao.list(_) >> { QueryProperties qp ->
            assert qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == hscID
            assert qp.getQueryFilter(FieldConstants.INACTIVEIND).getFieldValue() == false
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).getFieldValue().equals("8")
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).getCriterion().equals(QueryCriteria.NOT_EQUAL)
            assert qp.getQueryFilters().size() == 3
            return retList
        }
        1 * hsc.read(hscID, []) >> hscVO
        1 * hsc.isConcurrentCase(hscVO, hscFacilityVO) >> true
        1 * dao.list(_) >> { QueryProperties qp ->
            assert qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == hscID
            assert qp.getQueryFilter(FieldConstants.INACTIVEIND).getFieldValue() == false
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).getFieldValue().equals("5")
            assert qp.getQueryFilter(FieldConstants.DECISIONSUBTYPE).getFieldValue().equals("2")
            assert qp.getQueryFilter(FieldConstants.BEDDATE).getFieldValue().equals(bedDayRangeVO.getBedDateEnd())
            assert qp.getQueryFilter(FieldConstants.BEDDATE).getCriterion().equals(QueryCriteria.LESS_THAN_EQUAL)
            assert qp.getQueryFilters().size() == 5
            return []
        }
        0 * _
        bedDayRangeVO.getBedDateBegin() == expectedBeginDate
        bedDayRangeVO.getBedDateEnd() == expectedEndDate

        where:
        testCase | retList                       | expectedBeginDate                                                         | expectedEndDate
        1        | []                            | UhgCalendar.getSQLDate("11/06/2010")                                      | UhgCalendar.getSQLDate("11/06/2010")
        2        | [hscFacilityDecisionBedDayVO] | UhgCalendarUtilities.getNextDay(hscFacilityDecisionBedDayVO.getBedDate()) | UhgCalendarUtilities.getNextDay(hscFacilityDecisionBedDayVO.getBedDate())
    }

    def "set default SS Claim notes"() {
        given:
        String originalClaimNoteLrgObj = "test note"
        HscFacilityDecisionBedDayVO hscFacilityDecisionBedDayVO = new HscFacilityDecisionBedDayVO(hscID: 1 as Long, defaultedSpecialSituation: true, claimNoteLargeObject: originalClaimNoteLrgObj, bedDayDecisionOutcomeType: HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED)
        String localDay = hscFacilityDecisionBedDayVO.getChangeDateTime().getDayStringLocal()
        String localTime = hscFacilityDecisionBedDayVO.getChangeDateTime().getTimeStringLocal()
        String localAmpm = hscFacilityDecisionBedDayVO.getChangeDateTime().getAmpmStringLocal()

        when:
        hscFacilityDecisionBedDay.setDefaultSSClaimNotes(hscFacilityDecisionBedDayVO)

        then:
        1 * customerReference.getReferenceDisplay('bedDayDecisionOutcomeType', hscFacilityDecisionBedDayVO.getBedDayDecisionOutcomeType()) >> hscFacilityDecisionBedDayVO.getBedDayDecisionOutcomeType()
        0 * _
        hscFacilityDecisionBedDayVO.getClaimNoteLargeObject().equals(originalClaimNoteLrgObj + "---" + SystemSecurityConstants.SYSTEM_USER + "," + localDay + " " + localTime + localAmpm + "," + hscFacilityDecisionBedDayVO.getBedDayDecisionOutcomeType())
    }

    def "bed day is ineligible for UH One rollup - dates are not consecutive"() {
        given:
        HscFacilityDecisionBedDayRangeVO bedDayRange = createClinicalBedDayRangeVO(HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED, "95")
        HscFacilityDecisionBedDayVO rollUpBedDay = new HscFacilityDecisionBedDayVO(hscID: bedDayRange.getHscID(), bedDate: UhgCalendar.getSQLDate("11/06/2010"))

        when:
        boolean retVal = hscFacilityDecisionBedDay.isBedDayEligibleForUHOneRollup(bedDayRange, rollUpBedDay)

        then:
        0 * _
        !retVal
    }

    def "bed day is ineligible for UH One rollup - necessary values do not match"() {
        given:
        HscFacilityDecisionBedDayRangeVO bedDayRange = createClinicalBedDayRangeVO(HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED, "95")
        HscFacilityDecisionBedDayVO rollUpBedDay = new HscFacilityDecisionBedDayVO(hscID: bedDayRange.getHscID(), bedDate: UhgCalendar.getSQLDate("11/07/2010"))

        when:
        boolean retVal = hscFacilityDecisionBedDay.isBedDayEligibleForUHOneRollup(bedDayRange, rollUpBedDay)

        then:
        0 * _
        !retVal
    }

    def "bed day is eligible for UH One rollup"() {
        given:
        HscFacilityDecisionBedDayRangeVO bedDayRange = createClinicalBedDayRangeVO(HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED, "95")
        bedDayRange.setOverrideClaimRemarkCode("3")
        bedDayRange.setDerivedClaimRemarkCode("4")
        bedDayRange.setClaimNoteLargeObject("test note")
        HscFacilityDecisionBedDayVO rollUpBedDay = new HscFacilityDecisionBedDayVO(hscID: bedDayRange.getHscID(), bedDate: UhgCalendar.getSQLDate("11/09/2010"), bedDayDecisionOutcomeType: bedDayRange.getBedDayDecisionOutcomeType(), negotiatedRateType: bedDayRange.getNegotiatedRateType(), overrideClaimRemarkCode: bedDayRange.getOverrideClaimRemarkCode(), derivedClaimRemarkCode: bedDayRange.getDerivedClaimRemarkCode(), bedTypeID: bedDayRange.getBedTypeID(), negotiatedRate: bedDayRange.getNegotiatedRate(), claimNoteLargeObject: bedDayRange.getClaimNoteLargeObject())

        when: "rollUpBedDay's bedDay is consecutive with the range's endDate and necessary values match"
        boolean retVal = hscFacilityDecisionBedDay.isBedDayEligibleForUHOneRollup(bedDayRange, rollUpBedDay)

        then: "bed day is eligible, method returns true"
        0 * _
        retVal
    }

    def "bed day is ineligible for PHS rollup - dates are not consecutive"() {
        given:
        HscFacilityDecisionBedDayRangeVO bedDayRange = createClinicalBedDayRangeVO(HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED, "95")
        HscFacilityDecisionBedDayVO rollUpBedDay = new HscFacilityDecisionBedDayVO(hscID: bedDayRange.getHscID(), bedDate: UhgCalendar.getSQLDate("11/06/2010"))

        when: "rollUpBedDay's bedDate is not consecutive with bedDayRange's endDate"
        boolean retVal = hscFacilityDecisionBedDay.isBedDayEligibleForPhsRollup(bedDayRange, rollUpBedDay)

        then:
        0 * _
        !retVal
    }

    def "bed day is ineligible for Cosmos rollup - dates are not consecutive"() {
        given:
        HscFacilityDecisionBedDayRangeVO bedDayRange = createClinicalBedDayRangeVO(HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED, "95")
        HscFacilityDecisionBedDayVO rollUpBedDay = new HscFacilityDecisionBedDayVO(hscID: bedDayRange.getHscID(), bedDate: UhgCalendar.getSQLDate("11/06/2010"))

        when: "rollUpBedDay's bedDate is not consecutive with bedDayRange's endDate"
        boolean retVal = hscFacilityDecisionBedDay.isBedDayEligibleForCosmosRollup(bedDayRange, rollUpBedDay)

        then:
        0 * _
        !retVal
    }

    def "bed day is ineligible for Cosmos rollup - necessary values do not match"() {
        given:
        HscFacilityDecisionBedDayRangeVO bedDayRange = createClinicalBedDayRangeVO(HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED, "95")
        HscFacilityDecisionBedDayVO rollUpBedDay = new HscFacilityDecisionBedDayVO(hscID: bedDayRange.getHscID(), bedDate: UhgCalendar.getSQLDate("11/09/2010"), revenueCode: bedDayRange.getRevenueCode(), decisionReasonType: "test reason", bedDayDecisionOutcomeType: bedDayRange.getBedDayDecisionOutcomeType(), overrideClaimRemarkCode: "3", derivedClaimRemarkCode: "4", claimNoteLargeObject: "test note")

        when: "decisionReasonType, overrideClaimRemarkCode, derivedClaimRemarkCode, and claimNoteLargeObject do not match"
        boolean retVal = hscFacilityDecisionBedDay.isBedDayEligibleForCosmosRollup(bedDayRange, rollUpBedDay)

        then:
        0 * _
        !retVal
    }

    def "bed day is eligible for Cosmos rollup"() {
        given:
        HscFacilityDecisionBedDayRangeVO bedDayRange = createClinicalBedDayRangeVO(HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED, "95")
        bedDayRange.setDecisionReasonType("test reason")
        bedDayRange.setOverrideClaimRemarkCode("3")
        bedDayRange.setDerivedClaimRemarkCode("4")
        bedDayRange.setClaimNoteLargeObject("test note")
        HscFacilityDecisionBedDayVO rollUpBedDay = new HscFacilityDecisionBedDayVO(hscID: bedDayRange.getHscID(), bedDate: UhgCalendar.getSQLDate("11/09/2010"), revenueCode: bedDayRange.getRevenueCode(), decisionReasonType: bedDayRange.getDecisionReasonType(), bedDayDecisionOutcomeType: bedDayRange.getBedDayDecisionOutcomeType(), overrideClaimRemarkCode: bedDayRange.getOverrideClaimRemarkCode(), derivedClaimRemarkCode: bedDayRange.getDerivedClaimRemarkCode(), claimNoteLargeObject: bedDayRange.getClaimNoteLargeObject())

        when: "rollUpBedDay's bedDay is consecutive with the range's endDate and necessary values match"
        boolean retVal = hscFacilityDecisionBedDay.isBedDayEligibleForCosmosRollup(bedDayRange, rollUpBedDay)

        then:
        0 * _
        retVal
    }

    @Unroll
    def "is next day, Test Case=#testCase"() {
        when:
        boolean retVal = hscFacilityDecisionBedDay.isNextDay(toDate, fromDate)

        then:
        0 * _
        retVal == expectedVal

        where:
        testCase | toDate                               | fromDate                             | expectedVal
        1        | UhgCalendar.getSQLDate("11/09/2010") | UhgCalendar.getSQLDate("11/09/2010") | false
        2        | UhgCalendar.getSQLDate("11/09/2010") | UhgCalendar.getSQLDate("11/10/2010") | false
        3        | UhgCalendar.getSQLDate("11/10/2010") | UhgCalendar.getSQLDate("11/09/2010") | true
        4        | UhgCalendar.getSQLDate("11/09/2010") | UhgCalendar.getSQLDate("11/15/2010") | false

    }

    def "bed day is ineligible for letter rollup - necessary values do not match"() {
        given:
        HscFacilityDecisionBedDayVO bedDayVO = new HscFacilityDecisionBedDayVO(hscID: 1 as Long, bedDate: UhgCalendar.getSQLDate("11/09/2010"), bedDayDecisionOutcomeType: HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED, decisionReasonType: "95", claimNoteLargeObject: "test note", overrideClaimRemarkCode: "2", decisionMadeByUserID: "CLAYMA1", bedTypeID: "BNU", overrideReasonType: "test type", assessmentID: 3 as Long)
        HscFacilityDecisionBedDayRangeVO bedDayRangeVO = createClinicalBedDayRangeVO(HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED, "95")
        bedDayRangeVO.setClaimNoteLargeObject("test note")
        bedDayRangeVO.setOverrideClaimRemarkCode("2")
        bedDayRangeVO.setOverrideReasonType("test type")
        bedDayRangeVO.setAssessmentID(3 as Long)

        when: "create date times are unequal"
        boolean retVal = hscFacilityDecisionBedDay.isBedDayEligibleForLetterRollup(bedDayVO, bedDayRangeVO)

        then:
        0 * _
        !retVal
    }

    def "create UH One pended bed date range"() {
        given:
        Date beginDate = UhgCalendar.getSQLDate("11/05/2010")
        Date endDate = UhgCalendar.getSQLDate("11/08/2010")
        HscFacilityDecisionBedDayRangeVO vo = new HscFacilityDecisionBedDayRangeVO(bedDateBegin: beginDate, bedDateEnd: endDate, bedDayDecisionOutcomeType: HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_PEND)

        when:
        HscFacilityDecisionBedDayRangeVO retVO = hscFacilityDecisionBedDay.createUHOnePendedBedDateRange(beginDate, endDate)

        then:
        0 * _
        retVO == vo
    }

    def "create Phs pended bed date range"() {
        given:
        Date beginDate = UhgCalendar.getSQLDate("11/05/2010")
        Date endDate = UhgCalendar.getSQLDate("11/08/2010")
        HscFacilityDecisionBedDayRangeVO vo = new HscFacilityDecisionBedDayRangeVO(bedDateBegin: beginDate, bedDateEnd: endDate, bedDayDecisionOutcomeType: HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_PEND, niceAuthStatusType: HsrReferenceConstants.NICE_AUTH_STATUS_TYPE_PENDING_AUTH, decisionReasonType: HsrReferenceConstants.DECISIONREASONTYPE_ADDLINFO_DOCNEEDED, niceBedType: HscFacilityDecisionBedDayImpl.NICE_PENDED_BED_TYPE, claimBedType: HsrReferenceConstants.BEDTYPEID_DLC)

        when:
        HscFacilityDecisionBedDayRangeVO retVO = hscFacilityDecisionBedDay.createPhsPendedBedDateRange(beginDate, endDate)

        then:
        0 * _
        retVO == vo
    }

    def "create UH One bed date range"() {
        given:
        HscFacilityDecisionBedDayVO vo = new HscFacilityDecisionBedDayVO(bedDate: UhgCalendar.getSQLDate("11/05/2010"), bedTypeID: "BNU", negotiatedRate: 10, negotiatedRateType: "2", bedDayDecisionOutcomeType: HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED, overrideClaimRemarkCode: "test override code", derivedClaimRemarkCode: "test remark code", claimNoteLargeObject: "test note")
        HscFacilityDecisionBedDayRangeVO rangeVO = new HscFacilityDecisionBedDayRangeVO(changeDateTime: vo.getChangeDateTime(), createDateTime: vo.getCreateDateTime(), bedDateBegin: vo.getBedDate(), bedDateEnd: vo.getBedDate(), claimBedType: vo.getBedTypeID(), bedTypeID: vo.getBedTypeID(), negotiatedRate: vo.getNegotiatedRate(), negotiatedRateType: vo.getNegotiatedRateType(), bedDayDecisionOutcomeType: vo.getBedDayDecisionOutcomeType(), overrideClaimRemarkCode: vo.getOverrideClaimRemarkCode(), derivedClaimRemarkCode: vo.getDerivedClaimRemarkCode(), claimNoteLargeObject: vo.getClaimNoteLargeObject())

        when:
        HscFacilityDecisionBedDayRangeVO retVO = hscFacilityDecisionBedDay.createUHOneBedDateRange(vo)

        then:
        0 * _
        retVO == rangeVO
    }

    def "get max bed day - discharge date is null"() {
        given:
        HscFacilityDecisionBedDayVO hscFacilityDecisionBedDayVO = getHscFacilityDecisionBedDayVO()
        List<HscFacilityDecisionBedDayVO> bedDayList = Arrays.asList(hscFacilityDecisionBedDayVO)
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: hscFacilityDecisionBedDayVO.getHscID())

        when: "no discharge date exists and the current date is after the max day"
        Date retDate = hscFacilityDecisionBedDay.getMaximumBedDay(bedDayList, hscFacilityVO)

        then: "max date is set to current date"
        0 * _
        retDate == UhgCalendarUtilities.getTodaysDate()
    }

    def "get max bed day - discharge date later than max date"() {
        given:
        HscFacilityDecisionBedDayVO hscFacilityDecisionBedDayVO = getHscFacilityDecisionBedDayVO()
        List<HscFacilityDecisionBedDayVO> bedDayList = Arrays.asList(hscFacilityDecisionBedDayVO)
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: hscFacilityDecisionBedDayVO.getHscID(), actualDischargeDateTime: new UhgCalendar(2026, 11, 6))

        when:
        Date retDate = hscFacilityDecisionBedDay.getMaximumBedDay(bedDayList, hscFacilityVO)

        then:
        0 * _
        retDate == UhgCalendarUtilities.getPreviousDay(hscFacilityVO.getActualDischargeDateTime().getSQLDate())
    }

    def "get min bed day - admission date earlier than min date"() {
        given:
        HscFacilityDecisionBedDayVO hscFacilityDecisionBedDayVO = getHscFacilityDecisionBedDayVO()
        List<HscFacilityDecisionBedDayVO> bedDayList = Arrays.asList(hscFacilityDecisionBedDayVO)
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: hscFacilityDecisionBedDayVO.getHscID(), actualAdmissionDateTime: new UhgCalendar(2000, 11, 6))

        when:
        Date retDate = hscFacilityDecisionBedDay.getMinimumBedDay(bedDayList, hscFacilityVO)

        then:
        0 * _
        retDate == hscFacilityVO.getActualAdmissionDateTime().getSQLDate()
    }

    def "start pended range UH One"() {
        given:
        Date iterDate = UhgCalendar.getSQLDate("11/05/2010")
        HscFacilityDecisionBedDayRangeVO rangeVO = createClinicalBedDayRangeVO(HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED, "95")
        List<HscFacilityDecisionBedDayRangeVO> rollUpBedDayList = [rangeVO]
        HscFacilityDecisionBedDayRangeVO closingBedDayDecisionRange = createClinicalBedDayRangeVO(HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_DENY, "95")

        when:
        HscFacilityDecisionBedDayRangeVO retVO = hscFacilityDecisionBedDay.startPendedRangeUHOne(iterDate, rollUpBedDayList, closingBedDayDecisionRange)

        then: "closingBedDayDecisionRange is added to the rollUp list; a new pended range VO is returned"
        0 * _
        retVO == new HscFacilityDecisionBedDayRangeVO(bedDateBegin: iterDate, bedDateEnd: iterDate, bedDayDecisionOutcomeType: HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_PEND)
        rollUpBedDayList == [rangeVO, closingBedDayDecisionRange]
    }

    def "start pended range Phs"() {
        given:
        Date iterDate = UhgCalendar.getSQLDate("11/05/2010")
        HscFacilityDecisionBedDayRangeVO rangeVO = createClinicalBedDayRangeVO(HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED, "95")
        List<HscFacilityDecisionBedDayRangeVO> rollUpBedDayList = [rangeVO]
        HscFacilityDecisionBedDayRangeVO closingBedDayDecisionRange = createClinicalBedDayRangeVO(HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_DENY, "95")

        when:
        HscFacilityDecisionBedDayRangeVO retVO = hscFacilityDecisionBedDay.startPendedRangePhs(iterDate, rollUpBedDayList, closingBedDayDecisionRange)

        then: "closingBedDayDecisionRange is added to the rollUp list; a new pended range VO is returned"
        0 * _
        retVO == new HscFacilityDecisionBedDayRangeVO(bedDateBegin: iterDate, bedDateEnd: iterDate, bedDayDecisionOutcomeType: HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_PEND, niceAuthStatusType: HsrReferenceConstants.NICE_AUTH_STATUS_TYPE_PENDING_AUTH, decisionReasonType: HsrReferenceConstants.DECISIONREASONTYPE_ADDLINFO_DOCNEEDED, niceBedType: HscFacilityDecisionBedDayImpl.NICE_PENDED_BED_TYPE, claimBedType: HsrReferenceConstants.BEDTYPEID_DLC)
        rollUpBedDayList == [rangeVO, closingBedDayDecisionRange]
    }

    def "start non-pended range UH One"() {
        given:
        HscFacilityDecisionBedDayRangeVO rangeVO = createClinicalBedDayRangeVO(HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED, "95")
        List<HscFacilityDecisionBedDayRangeVO> rollUpBedDayList = [rangeVO]
        HscFacilityDecisionBedDayRangeVO closingBedDayDecisionRange = createClinicalBedDayRangeVO(HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_DENY, "95")
        HscFacilityDecisionBedDayVO bedDayVO = getHscFacilityDecisionBedDayVO()

        HscFacilityDecisionBedDayRangeVO createdRangeVO = new HscFacilityDecisionBedDayRangeVO(bedDayVO)
        createdRangeVO.setChangeDateTime(bedDayVO.getChangeDateTime())
        createdRangeVO.setCreateDateTime(bedDayVO.getCreateDateTime())
        createdRangeVO.setBedDateBegin(bedDayVO.getBedDate())
        createdRangeVO.setBedDateEnd(bedDayVO.getBedDate())
        createdRangeVO.setClaimBedType(bedDayVO.getBedTypeID())
        createdRangeVO.setBedTypeID(bedDayVO.getBedTypeID())
        createdRangeVO.setNegotiatedRate(bedDayVO.getNegotiatedRate())
        createdRangeVO.setNegotiatedRateType(bedDayVO.getNegotiatedRateType())
        createdRangeVO.setBedDayDecisionOutcomeType(bedDayVO.getBedDayDecisionOutcomeType())
        createdRangeVO.setOverrideClaimRemarkCode(bedDayVO.getOverrideClaimRemarkCode())
        createdRangeVO.setDerivedClaimRemarkCode(bedDayVO.getDerivedClaimRemarkCode())
        createdRangeVO.setClaimNoteLargeObject(bedDayVO.getClaimNoteLargeObject())

        when:
        HscFacilityDecisionBedDayRangeVO retVO = hscFacilityDecisionBedDay.startNonPendedRangeUHOne(rollUpBedDayList, closingBedDayDecisionRange, bedDayVO)

        then: "closingBedDayDecisionRange is added to the rollUp list; a new range VO is returned"
        0 * _
        retVO == createdRangeVO
        rollUpBedDayList == [rangeVO, closingBedDayDecisionRange]
    }

    def "consolidate bed day decisions for Csp: claimNoteLargeObject is not blank"() {
        given:
        long hscID = 1
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: hscID, actualAdmissionDateTime: new UhgCalendar(2000, 11, 6), actualDischargeDateTime: new UhgCalendar(2000, 11, 7))
        HscVO hscVO = new HscVO(hscID: hscID, hscFacilityVO: hscFacilityVO)
        HscFacilityDecisionBedDayVO vo = getHscFacilityDecisionBedDayVO()
        HscFacilityDecisionBedDayVO vo2 = getHscFacilityDecisionBedDayVO()
        vo2.setBedDate(UhgCalendar.getSQLDate("04/20/2013"))
        List<HscFacilityDecisionBedDayVO> bedDayList = Arrays.asList(vo, vo2)

        when:
        List<HscFacilityDecisionBedDayRangeVO> retList = hscFacilityDecisionBedDay.consolidateBedDayDecisionsForCsp(bedDayList)

        then:
        0 * _
        retList.size() == 2
        with(retList.get(0)){
            getBedDateBegin().equals(vo.getBedDate())
            getBedDateEnd().equals(vo.getBedDate())
        }
        with(retList.get(1)){
            getBedDateBegin().equals(vo2.getBedDate())
            getBedDateEnd().equals(vo2.getBedDate())
        }
    }

    def "consolidate bed day decisions for Csp: claim note is blank"() {
        given:
        long hscID = 1
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: hscID, actualAdmissionDateTime: new UhgCalendar(2013, 04, 25), actualDischargeDateTime: new UhgCalendar(2013, 04, 28))
        HscVO hscVO = new HscVO(hscID: hscID, hscFacilityVO: hscFacilityVO)
        HscFacilityDecisionBedDayVO vo = getHscFacilityDecisionBedDayVO()
        HscFacilityDecisionBedDayVO vo2 = getHscFacilityDecisionBedDayVO()
        vo2.setBedDate(UhgCalendar.getSQLDate("04/27/2013"))
        vo2.setClaimNoteLargeObject("")
        List<HscFacilityDecisionBedDayVO> bedDayList = Arrays.asList(vo, vo2)

        when:
        List<HscFacilityDecisionBedDayRangeVO> retList = hscFacilityDecisionBedDay.consolidateBedDayDecisionsForCsp(bedDayList)

        then:
        0 * _
        retList.size() == 2
        with(retList.get(0)){
            getBedDateBegin().equals(vo.getBedDate())
            getBedDateEnd().equals(vo.getBedDate())
        }
        with(retList.get(1)){
            getBedDateBegin().equals(vo2.getBedDate())
            getBedDateEnd().equals(vo2.getBedDate())
        }
    }

    def "consolidate bed day decisions for Csp: claim notes are blank and VO is eligible for cosmos rollup"() {
        given:
        long hscID = 1
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: hscID, actualAdmissionDateTime: new UhgCalendar(2013, 04, 25), actualDischargeDateTime: new UhgCalendar(2013, 04, 28))
        HscVO hscVO = new HscVO(hscID: hscID, hscFacilityVO: hscFacilityVO)
        HscFacilityDecisionBedDayVO vo = getHscFacilityDecisionBedDayVO()
        HscFacilityDecisionBedDayVO vo2 = getHscFacilityDecisionBedDayVO()
        vo.setClaimNoteLargeObject("")
        vo2.setClaimNoteLargeObject("")
        vo2.setBedDate(UhgCalendar.getSQLDate("04/27/2013"))
        vo2.setBedDayDecisionOutcomeType(HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED)
        List<HscFacilityDecisionBedDayVO> bedDayList = Arrays.asList(vo, vo2)

        when:
        List<HscFacilityDecisionBedDayRangeVO> retList = hscFacilityDecisionBedDay.consolidateBedDayDecisionsForCsp(bedDayList)

        then:
        0 * _
        retList.size() == 1
        with(retList.get(0)){
            getBedDateBegin().equals(vo.getBedDate())
            getBedDateEnd().equals(vo2.getBedDate())
        }
    }

    def "consolidate bed day decisions for cosmos: claim note is not blank"() {
        given:
        long hscID = 1
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: hscID, actualAdmissionDateTime: new UhgCalendar(2000, 11, 6), actualDischargeDateTime: new UhgCalendar(2000, 11, 7))
        HscVO hscVO = new HscVO(hscID: hscID, hscFacilityVO: hscFacilityVO)
        HscFacilityDecisionBedDayVO vo = getHscFacilityDecisionBedDayVO()
        HscFacilityDecisionBedDayVO vo2 = getHscFacilityDecisionBedDayVO()
        vo2.setBedDate(UhgCalendar.getSQLDate("04/27/2013"))
        List<HscFacilityDecisionBedDayVO> bedDayList = Arrays.asList(vo, vo2)

        when:
        List<HscFacilityDecisionBedDayRangeVO> retList = hscFacilityDecisionBedDay.consolidateBedDayDecisionsForCosmos(bedDayList)

        then:
        0 * _
        retList.size() == 2
        with(retList.get(0)){
            getBedDateBegin().equals(vo.getBedDate())
            getBedDateEnd().equals(vo.getBedDate())
        }
        with(retList.get(1)){
            getBedDateBegin().equals(vo2.getBedDate())
            getBedDateEnd().equals(vo2.getBedDate())
        }
    }

    def "consolidate bed day decisions for cosmos: claim note is blank"() {
        given:
        long hscID = 1
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: hscID, actualAdmissionDateTime: new UhgCalendar(2000, 11, 6), actualDischargeDateTime: new UhgCalendar(2000, 11, 7))
        HscVO hscVO = new HscVO(hscID: hscID, hscFacilityVO: hscFacilityVO)
        HscFacilityDecisionBedDayVO vo = getHscFacilityDecisionBedDayVO()
        HscFacilityDecisionBedDayVO vo2 = getHscFacilityDecisionBedDayVO()
        vo2.setBedDate(UhgCalendar.getSQLDate("04/27/2013"))
        vo2.setClaimNoteLargeObject("")
        List<HscFacilityDecisionBedDayVO> bedDayList = Arrays.asList(vo, vo2)

        when:
        List<HscFacilityDecisionBedDayRangeVO> retList = hscFacilityDecisionBedDay.consolidateBedDayDecisionsForCosmos(bedDayList)

        then:
        0 * _
        retList.size() == 2
        with(retList.get(0)){
            getBedDateBegin().equals(vo.getBedDate())
            getBedDateEnd().equals(vo.getBedDate())
        }
        with(retList.get(1)){
            getBedDateBegin().equals(vo2.getBedDate())
            getBedDateEnd().equals(vo2.getBedDate())
        }
    }

    def "consolidate bed day decisions for cosmos: claim note is blank and vo is eligible for cosmos rollup"() {
        given:
        long hscID = 1
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: hscID, actualAdmissionDateTime: new UhgCalendar(2013, 04, 25), actualDischargeDateTime: new UhgCalendar(2013, 04, 28))
        HscVO hscVO = new HscVO(hscID: hscID, hscFacilityVO: hscFacilityVO)
        HscFacilityDecisionBedDayVO vo = getHscFacilityDecisionBedDayVO()
        HscFacilityDecisionBedDayVO vo2 = getHscFacilityDecisionBedDayVO()
        vo.setClaimNoteLargeObject("")
        vo2.setClaimNoteLargeObject("")
        vo2.setBedDate(UhgCalendar.getSQLDate("04/27/2013"))
        List<HscFacilityDecisionBedDayVO> bedDayList = Arrays.asList(vo, vo2)

        when:
        List<HscFacilityDecisionBedDayRangeVO> retList = hscFacilityDecisionBedDay.consolidateBedDayDecisionsForCosmos(bedDayList)

        then:
        0 * _
        retList.size() == 1
        with(retList.get(0)){
            getBedDateBegin().equals(vo.getBedDate())
            getBedDateEnd().equals(vo2.getBedDate())
        }
    }

    @Unroll
    def "is timestamp within margin of error #expectedVal"() {
        when: "timestamps are within 1 minute of each other"
        boolean retVal = hscFacilityDecisionBedDay.isTimestampWithinMarginOfError(calA, calB)

        then: "return true, else return false"
        0 * _
        retVal == expectedVal

        where:
        expectedVal | calA                       | calB
        true        | new UhgCalendar(1 as Long) | new UhgCalendar(10L * 1000L)
        false       | new UhgCalendar(1 as Long) | new UhgCalendar(10L * 2000L)
    }

    def "get bed day query properties outside range"() {
        given:
        Date beginDate = UhgCalendar.getSQLDate("11/05/2010")
        Date endDate = UhgCalendar.getSQLDate("11/08/2010")
        long hscID = 1

        when:
        QueryProperties qp = hscFacilityDecisionBedDay.getBedDayQueryPropertiesOutsideRange(hscID, beginDate, endDate)

        then:
        0 * _
        qp
        qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == hscID
        qp.getQueryFilter(FieldConstants.INACTIVEIND).getFieldValue() == false
        qp.getQueryFilter(FieldConstants.BEDDATE).getFieldValue() == beginDate
        qp.getQueryFilter(FieldConstants.BEDDATE).getFieldValue2() == endDate
        qp.getQueryFilter(FieldConstants.BEDDATE).getCriterion().equals(QueryCriteria.FIELD_NOT_BETWEEN_VALUES)
    }

    def "has no denial bed day decisions"() {
        given:
        long hscID = 1

        when:
        boolean retVal = hscFacilityDecisionBedDay.hasNoDenialBedDayDecisions(hscID)

        then:
        1 * dao.exists(_) >> { QueryProperties qp ->
            assert qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == hscID
            assert qp.getQueryFilter(FieldConstants.INACTIVEIND).getFieldValue() == false
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).getFieldValue().equals("6")
            assert qp.getQueryFilters().size() == 3
            return expectedVal
        }
        0 * _
        retVal == !expectedVal

        where:
        seq | expectedVal
        1   | true
        2   | false
    }

    @Unroll
    def "update claim note Test Case=#testCase"() {
        given:
        HscFacilityDecisionBedDayRangeVO bedDayRangeVO = new HscFacilityDecisionBedDayRangeVO(changeUserID: "user", changeDateTime: DEFAULT_CAL, claimDetailNote: originalClaimDetailNote, claimNoteLargeObject: originalClaimNoteLargeObject)

        when:
        hscFacilityDecisionBedDay.updateClaimNote(bedDayRangeVO)

        then:
        0 * _
        bedDayRangeVO.getClaimNoteLargeObject().equals(expectedClaimNoteLargeObject)

        where:
        testCase | originalClaimDetailNote | originalClaimNoteLargeObject | expectedClaimNoteLargeObject
        1        | null                    | "test note large object"     | "test note large object"
        3        | "test note detail"      | null                         | "user," + DEFAULT_CAL.getDayStringLocal() + " " + DEFAULT_CAL.getTimeStringLocal() + DEFAULT_CAL.getAmpmStringLocal() + ":" + "test note detail"
        2        | "test note detail"      | "test note large object"     | "user," + DEFAULT_CAL.getDayStringLocal() + " " + DEFAULT_CAL.getTimeStringLocal() + DEFAULT_CAL.getAmpmStringLocal() + ":" + "test note detail" + " " + "test note large object"
    }

    def "get total approved bed days for clinical decisions"() {
        given:
        long hscID = 1
        Date bedDateEnd = DEFAULT_CAL.getSQLDate()
        HscFacilityDecisionBedDayVO hscFacilityDecisionBedDayVO = new HscFacilityDecisionBedDayVO(bedDayDecisionOutcomeType: HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED, decisionSubType: HsrReferenceConstants.DECISIONSUBTYPE_CLINICAL, bedDate: UhgCalendarUtilities.getDateBefore(bedDateEnd))

        when:
        int retVal = hscFacilityDecisionBedDay.getTotalApprovedBedDaysForClinicalDecisions(hscID, bedDateEnd)

        then:
        1 * dao.list(_) >> { QueryProperties qp ->
            assert qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == hscID
            assert qp.getQueryFilter(FieldConstants.INACTIVEIND).getFieldValue() == false
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).getFieldValue().equals("5")
            assert qp.getQueryFilter(FieldConstants.DECISIONSUBTYPE).getFieldValue().equals("2")
            assert qp.getQueryFilter(FieldConstants.BEDDATE).getFieldValue().equals(bedDateEnd)
            assert qp.getQueryFilter(FieldConstants.BEDDATE).getCriterion().equals(QueryCriteria.LESS_THAN_EQUAL)
            assert qp.getQueryFilters().size() == 5
            return [hscFacilityDecisionBedDayVO]
        }
        0 * _
        retVal == 1
    }

    def "get bed date ranges for csp"() {
        given:
        long hscID = 1

        when:
        List<HscFacilityDecisionBedDayRangeVO> retList = hscFacilityDecisionBedDay.getBedDateRangesForCsp(hscID)

        then:
        1 * dao.list(_) >> { QueryProperties qp ->
            assert qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == hscID
            assert qp.getQueryFilter(FieldConstants.INACTIVEIND).getFieldValue() == false
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).getFieldValue().equals("8")
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).getCriterion().equals(QueryCriteria.NOT_EQUAL)
            assert qp.getQueryFilters().size() == 3
            return [new HscFacilityDecisionBedDayRangeVO(hscID: hscID)]
        }
        0 * _
        retList.get(0).getHscID() == hscID
    }

    def "get bed date ranges for cosmos"() {
        given:
        long hscID = 1
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        qp.addQueryFilter(new QueryFilter(FieldConstants.HSCID, hscID))
        qp.addQueryFilter(new QueryFilter(FieldConstants.INACTIVEIND, false))
        qp.addQueryFilter(new QueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE, HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_VOID, QueryCriteria.NOT_EQUAL))
        qp.addQueryFilter(new QueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE, HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_PEND, QueryCriteria.NOT_EQUAL))
        qp.setOrderByAscFields(FieldConstants.BEDDATE);
        qp.setUnboundedListAll(true);

        when:
        List<HscFacilityDecisionBedDayRangeVO> retList = hscFacilityDecisionBedDay.getBedDateRangesForCosmos(hscID)

        then:
        1 * dao.list(qp) >> [new HscFacilityDecisionBedDayRangeVO(hscID: hscID)]
        0 * _
        retList.get(0).getHscID() == hscID
    }

    def "create and validate bed day range VO where VO is missing bedDayDecisionSeqNum, update=false"() {
        given:
        long hscID = 1
        HscFacilityDecisionBedDayRangeVO bedDayRangeVO = new HscFacilityDecisionBedDayRangeVO(hscID: hscID, bedDateBegin: UhgCalendar.getSQLDate("2012, 10, 11"), bedDateEnd: UhgCalendar.getSQLDate("2012, 10, 13"))
        Date beginDate = UhgCalendar.getSQLDate("2011, 1, 3")
        Date endDate = UhgCalendar.getSQLDate("2011, 1, 7")
        boolean update = false
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: hscID)

        when:
        HscFacilityDecisionBedDayRangeVO retVO = hscFacilityDecisionBedDay.createAndValidateBedDayRangeVO(bedDayRangeVO, beginDate, endDate, update, hscFacilityVO)

        then:
        1 * hsc.read(hscID, ['hscID', 'memberCoverageSeqNum', 'specialProcessType', 'serviceSettingType', 'secondarySpecialProcessType']) >> new HscVO(hscID: hscID)
        1 * dao.list(_) >> { QueryProperties qp ->
            assert qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == hscID
            assert qp.getQueryFilter(FieldConstants.INACTIVEIND).getFieldValue() == false
            assert qp.getQueryFilter(FieldConstants.BEDDATE).getFieldValue() == bedDayRangeVO.getBedDateBegin()
            assert qp.getQueryFilter(FieldConstants.BEDDATE).getFieldValue2() == bedDayRangeVO.getBedDateEnd()
            assert qp.getQueryFilter(FieldConstants.BEDDATE).getCriterion().equals(QueryCriteria.FIELD_BETWEEN_VALUES)
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).getFieldValue().equals("8")
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).getCriterion().equals(QueryCriteria.NOT_EQUAL)
            return []
        }
        0 * _
        !retVO.getOverrideReasonText()
        !retVO.getOverrideReasonType()
    }


    @Unroll
    def "has active bed day list for Icm Review, Test Case = #testCase"() {
        given:
        long hscID = 1
        long assessmentID = 2

        when:
        boolean retVal = hscFacilityDecisionBedDay.hasActiveBedDayListForIcmReview(hscID, assessmentID)

        then:
        1 * dao.exists(_) >> { QueryProperties qp ->
            assert qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == hscID
            assert qp.getQueryFilter(FieldConstants.INACTIVEIND).getFieldValue() == false
            assert qp.getQueryFilter(FieldConstants.ASSESSMENTID).getFieldValue() == assessmentID
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).getFieldValue().equals("8")
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).getCriterion().equals(QueryCriteria.NOT_EQUAL)
            assert qp.getQueryFilters().size() == 4
            return expectedVal
        }
        0 * _
        retVal == expectedVal

        where:
        testCase | expectedVal
        1        | true
        2        | false
    }

    def "get active bed day list for assessment where assessmentID=0"() {
        when:
        List<HscFacilityDecisionBedDayVO> retList = hscFacilityDecisionBedDay.getActiveBedDayListForAssessment(0)

        then:
        0 * _
        retList == new ArrayList<HscFacilityDecisionBedDayVO>()
    }

    def "get active bed day list for assessment where assessmentID>0, no active bed days"() {
        given:
        long assessmentID = 1

        when:
        List<HscFacilityDecisionBedDayVO> retList = hscFacilityDecisionBedDay.getActiveBedDayListForAssessment(assessmentID)

        then:
        1 * dao.list(_) >> { QueryProperties qp ->
            assert qp.getQueryFilter(FieldConstants.ASSESSMENTID).getFieldValue() == assessmentID
            assert qp.getQueryFilter(FieldConstants.INACTIVEIND).getFieldValue() == false
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).getFieldValue().equals("8")
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).getCriterion().equals(QueryCriteria.NOT_EQUAL)
            assert qp.getQueryFilters().size() == 3
            return null
        }
        0 * _
        retList == new ArrayList<HscFacilityDecisionBedDayVO>()
    }

    def "get active bed day list for assessment where assessmentID>0, with active bed days"() {
        given:
        long assessmentID = 1
        HscFacilityDecisionBedDayVO vo = getHscFacilityDecisionBedDayVO()
        vo.setAssessmentID(assessmentID)
        List<HscFacilityDecisionBedDayVO> bedDayList = Arrays.asList(vo)

        when:
        List<HscFacilityDecisionBedDayVO> retList = hscFacilityDecisionBedDay.getActiveBedDayListForAssessment(assessmentID)

        then:
        1 * dao.list(_) >> { QueryProperties qp ->
            assert qp.getQueryFilter(FieldConstants.ASSESSMENTID).getFieldValue() == assessmentID
            assert qp.getQueryFilter(FieldConstants.INACTIVEIND).getFieldValue() == false
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).getFieldValue().equals("8")
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).getCriterion().equals(QueryCriteria.NOT_EQUAL)
            assert qp.getQueryFilters().size() == 3
            return bedDayList
        }
        0 * _
        retList == bedDayList
    }

    @Unroll
    def "get bed day count, TestCase=#testCase"() {
        given:
        long hscID = 1
        String bedStatus = "test status"

        when:
        int retVal = hscFacilityDecisionBedDay.getBedDayCount(new HscFacilityVO(), hscID, bedStatus)

        then:
        1 * dao.getCount(_) >> { QueryProperties qp ->
            assert qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == hscID
            assert qp.getQueryFilter(FieldConstants.INACTIVEIND).getFieldValue() == false
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).getFieldValue() == bedStatus
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).getFieldValue().equals(bedStatus)
            assert qp.getQueryFilters().size() == 4
            return expectedVal
        }
        0 * _
        retVal == expectedVal

        where:
        testCase | expectedVal
        1        | 0
        2        | 1
    }

    @Unroll
    def "get active bed day list within range, Test Case=#testCase"() {
        given:
        long hscID = 1
        Date beginDate = UhgCalendar.getSQLDate("04/25/2013")
        Date endDate = UhgCalendar.getSQLDate("04/27/2013")

        when:
        List<HscFacilityDecisionBedDayVO> retList = hscFacilityDecisionBedDay.getActiveBedDayListWithinRange(hscID, beginDate, endDate)

        then:
        1 * dao.list(_) >> { QueryProperties qp ->
            assert qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == hscID
            assert qp.getQueryFilter(FieldConstants.INACTIVEIND).getFieldValue() == false
            assert qp.getQueryFilter(FieldConstants.BEDDATE).getFieldValue().equals(beginDate)
            assert qp.getQueryFilter(FieldConstants.BEDDATE).getFieldValue2().equals(endDate)
            assert qp.getQueryFilter(FieldConstants.BEDDATE).getCriterion().equals(QueryCriteria.FIELD_BETWEEN_VALUES)
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).getFieldValue().equals("8")
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).getCriterion().equals(QueryCriteria.NOT_EQUAL)
            assert qp.getQueryFilters().size() == 4
            return voList
        }
        0 * _
        retList == voList

        where:
        testCase | voList
        1        | null
        2        | [getHscFacilityDecisionBedDayVO()]
    }

    @Unroll
    def "get active bed day list outside range, Test Case=#testCase"() {
        given:
        long hscID = 1
        Date beginDate = UhgCalendar.getSQLDate("11/05/2010")
        Date endDate = UhgCalendar.getSQLDate("11/08/2010")

        when:
        List<HscFacilityDecisionBedDayVO> retList = hscFacilityDecisionBedDay.getActiveBedDayListOutsideRange(hscID, beginDate, endDate)

        then:
        1 * dao.list(_) >> { QueryProperties qp ->
            assert qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == hscID
            assert qp.getQueryFilter(FieldConstants.INACTIVEIND).getFieldValue() == false
            assert qp.getQueryFilter(FieldConstants.BEDDATE).getFieldValue().equals(beginDate)
            assert qp.getQueryFilter(FieldConstants.BEDDATE).getFieldValue2().equals(UhgCalendarUtilities.getPreviousDay(endDate))
            assert qp.getQueryFilter(FieldConstants.BEDDATE).getCriterion().equals(QueryCriteria.FIELD_NOT_BETWEEN_VALUES)
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).getFieldValue().equals("8")
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).getCriterion().equals(QueryCriteria.NOT_EQUAL)
            assert qp.getQueryFilters().size() == 4
            return voList
        }
        0 * _
        retList == voList

        where:
        testCase | voList
        1        | null
        2        | [getHscFacilityDecisionBedDayVO()]
    }

    def "get hsc decisions with appeal rights unrolled"() {
        given:
        long hscID = 1
        Date beginDate = UhgCalendar.getSQLDate("11/05/2010")
        Date endDate = UhgCalendar.getSQLDate("11/08/2010")
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        qp.addQueryFilter(new QueryFilter(FieldConstants.INACTIVEIND, false))
        qp.addQueryFilter(new QueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE, BEDDAYDECISIONOUTCOMETYPELIST, QueryCriteria.IN))
        qp.addQueryFilter(new QueryFilter(FieldConstants.HSCID, hscID))
        qp.addQueryFilter(new QueryFilter().fieldBetweenValues(FieldConstants.BEDDATE, beginDate, endDate))

        List<HscFacilityDecisionBedDayRangeVO> voList = [new HscFacilityDecisionBedDayRangeVO(hscID: hscID, inactiveInd: false, bedDayDecisionOutcomeType: HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_DENY, bedDate: UhgCalendar.getSQLDate("11/06/2010"))]

        when:
        List<HscFacilityDecisionBedDayRangeVO> retList = hscFacilityDecisionBedDay.getHscBedDayDecisionsWithAppealRightsUnrolled(hscID, beginDate, endDate)

        then:
        1 * dao.list(qp) >> voList
        0 * _
        retList == voList
    }

    def "create new VO with range after"() {
        given:
        long hscID = 1
        HscFacilityDecisionBedDayRangeVO bedDayRangeVO = createClinicalBedDayRangeVO(HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED, "50")
        bedDayRangeVO.setClaimDetailNote("test note")
        Date originalEndDate = UhgCalendarUtilities.getNextDay(bedDayRangeVO.getBedDateBegin())
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: hscID, actualAdmissionDateTime: new UhgCalendar(bedDayRangeVO.getBedDateBegin()), actualDischargeDateTime: new UhgCalendar(bedDayRangeVO.getBedDateEnd()))

        when:
        HscFacilityDecisionBedDayRangeVO retVO = hscFacilityDecisionBedDay.rangeAfter(bedDayRangeVO, originalEndDate, hscFacilityVO)

        then:
        1 * hsc.read(hscID, ['hscID', 'memberCoverageSeqNum', 'specialProcessType', 'serviceSettingType', 'secondarySpecialProcessType']) >> new HscVO(hscID: hscID)
        1 * appUser.read('CLAYMA1') >> new AppUserVO()
        1 * dao.list(_) >> { QueryProperties qp ->
            assert qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == hscID
            assert qp.getQueryFilter(FieldConstants.INACTIVEIND).getFieldValue() == false
            assert qp.getQueryFilter(FieldConstants.BEDDATE).getFieldValue().equals(UhgCalendarUtilities.getNextDay(originalEndDate))
            assert qp.getQueryFilter(FieldConstants.BEDDATE).getFieldValue2().equals(bedDayRangeVO.getBedDateEnd())
            assert qp.getQueryFilter(FieldConstants.BEDDATE).getCriterion().equals(QueryCriteria.FIELD_BETWEEN_VALUES)
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).getFieldValue().equals("8")
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).getCriterion().equals(QueryCriteria.NOT_EQUAL)
            return []
        }
        0 * _
        retVO.getHscID() == hscID
        retVO.getBedDateBegin() == UhgCalendarUtilities.getNextDay(originalEndDate)
        retVO.getBedDateEnd() == bedDayRangeVO.getBedDateEnd()
        !retVO.getOverrideReasonText()
        !retVO.getOverrideReasonType()
        retVO.getClaimDetailNote() == bedDayRangeVO.getClaimDetailNote()
    }

    def "create new VO with range before"() {
        given:
        long hscID = 1
        HscFacilityDecisionBedDayRangeVO bedDayRangeVO = createClinicalBedDayRangeVO(HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED, "50")
        bedDayRangeVO.setClaimDetailNote("test note")
        Date originalBeginDate = UhgCalendarUtilities.getDateBefore(bedDayRangeVO.getBedDateEnd())
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: hscID, actualAdmissionDateTime: new UhgCalendar(bedDayRangeVO.getBedDateBegin()), actualDischargeDateTime: new UhgCalendar(bedDayRangeVO.getBedDateEnd()))

        when:
        HscFacilityDecisionBedDayRangeVO retVO = hscFacilityDecisionBedDay.rangeBefore(bedDayRangeVO, originalBeginDate, hscFacilityVO)

        then:
        1 * hsc.read(hscID, ['hscID', 'memberCoverageSeqNum', 'specialProcessType', 'serviceSettingType', 'secondarySpecialProcessType']) >> new HscVO(hscID: hscID)
        1 * appUser.read('CLAYMA1') >> new AppUserVO()
        1 * dao.list(_) >> { QueryProperties qp ->
            assert qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == hscID
            assert qp.getQueryFilter(FieldConstants.INACTIVEIND).getFieldValue() == false
            assert qp.getQueryFilter(FieldConstants.BEDDATE).getFieldValue().equals(bedDayRangeVO.getBedDateBegin())
            assert qp.getQueryFilter(FieldConstants.BEDDATE).getFieldValue2().clearTime().equals(originalBeginDate.clearTime())
            assert qp.getQueryFilter(FieldConstants.BEDDATE).getCriterion().equals(QueryCriteria.FIELD_BETWEEN_VALUES)
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).getFieldValue().equals("8")
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).getCriterion().equals(QueryCriteria.NOT_EQUAL)
            assert qp.getQueryFilters().size() == 4
            return []
        }
        0 * _
        retVO.getHscID() == hscID
        retVO.getBedDateBegin() == bedDayRangeVO.getBedDateBegin()
        retVO.getBedDateEnd().clearTime().equals(originalBeginDate.clearTime())
        !retVO.getOverrideReasonText()
        !retVO.getOverrideReasonType()
        retVO.getClaimDetailNote() == bedDayRangeVO.getClaimDetailNote()
    }

    def "get derived claim remark code - code is null, special process type is CMC_FACETS"() {
        given:
        long hscID = 1
        HscFacilityDecisionBedDayRangeVO bedDayRangeVO = new HscFacilityDecisionBedDayRangeVO(hscID: hscID)
        HscMemberCoverageVO hscMemberCoverageVO = new HscMemberCoverageVO(hscID: hscID)
        HscVO hscVO = new HscVO(hscID: hscID, specialProcessType: HsrReferenceConstants.SPECIALPROCESSTYPE_CMC_FACETS)
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: hscID)

        when:
        String retStr = hscFacilityDecisionBedDay.getDerivedClaimRemarkCode(bedDayRangeVO, hscMemberCoverageVO, hscVO, hscFacilityVO)

        then:
        0 * _
        !retStr
    }

    /*
    @Ignore
    def "create default admin days"(){
        given:
        long hscID = 1
        Date admitDate = UhgCalendar.getSQLDate("11/05/2010")
        Date dischargeDate = UhgCalendar.getSQLDate("11/08/2010")
        HscFacilityVO hscFacilityVO = new HscFacilityVO(hscID: hscID, actualAdmissionDateTime: new UhgCalendar(admitDate as Date), actualDischargeDateTime: new UhgCalendar(dischargeDate as Date), goalLOSDayCount: 2)
        HscFacilityDecisionBedDayRangeVO bedDayRangeVO = hscFacilityDecisionBedDay.createDefaultBedDayRangeVO(hscFacilityVO)

        HscFacilityDecisionBedDayVO bedDayVO = new HscFacilityDecisionBedDayVO(hscID: hscID, inactiveInd: false, bedDayDecisionOutcomeType: HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_APPROVED)
        HscVO hscVO = new HscVO(hscID: hscID)
        HscMemberCoverageVO hscMemberCoverageVO = new HscMemberCoverageVO(hscID: hscID)
        HscFacilityDecisionBedDayVO emptyBedDayVO = new HscFacilityDecisionBedDayVO()

        when:
        hscFacilityDecisionBedDay.createDefaultAdminDays(hscFacilityVO)

        then:
        1 * dao.list(_) >> { QueryProperties qp ->
            assert qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == hscID
            assert qp.getQueryFilter(FieldConstants.INACTIVEIND).getFieldValue() == false
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).getFieldValue().equals("8")
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).getCriterion().equals(QueryCriteria.NOT_EQUAL)
            assert qp.getQueryFilters().size() == 3
            return [bedDayVO]
        }
        1 * hsc.read(hscID, ['hscID', 'memberID', 'memberCoverageSeqNum', 'specialProcessType', 'serviceSettingType', 'secondarySpecialProcessType']) >> hscVO
        1 * hscMemberCoverage.read(hscID, 0, []) >> hscMemberCoverageVO
        3 * temporarySystemSetting.getIntSetting('BedDayDateBounds') >> DEFAULT_INTSETTING_BEDDAYDATEBOUNDS
        3 * valueObjectHelper.copyFields(VERBAL_COMMUNICATION_FIELDS, emptyBedDayVO, _ as HscFacilityDecisionBedDayRangeVO)
        3 * valueObjectHelper.copyFields(ELGS_COMMUNICATION_FIELDS, emptyBedDayVO, _ as HscFacilityDecisionBedDayRangeVO)
        1 * persistenceHelper.addBatch(_) >> {
            List<List<HscFacilityDecisionBedDayVO>> args ->
                with(args.get(0).get(0)) {
                    assert getBedDate() == UhgCalendarUtilities.getNextDay(admitDate)
                    assert getHscID() == bedDayRangeVO.getHscID()
                }
                return 0
        }
        1 * persistenceHelper.addBatch(_) >> {
            List<List<HscFacilityDecisionBedDayVO>> args ->
                with(args.get(0).get(0)) {
                    assert getBedDate() == admitDate
                    assert getHscID() == bedDayRangeVO.getHscID()
                }
                return 0
        }
        2 * dao.list(_) >> { QueryProperties qp ->
            assert qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == hscID
            assert qp.getQueryFilter(FieldConstants.INACTIVEIND).getFieldValue() == false
            assert qp.getQueryFilter(FieldConstants.BEDDATE).getFieldValue().equals(UhgCalendarUtilities.getNextDay(admitDate))
            assert qp.getQueryFilter(FieldConstants.BEDDATE).getFieldValue2().equals(UhgCalendarUtilities.getNextDay(admitDate))
            assert qp.getQueryFilter(FieldConstants.BEDDATE).getCriterion().equals(QueryCriteria.FIELD_BETWEEN_VALUES)
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).getFieldValue().equals("8")
            assert qp.getQueryFilters().size() == 4
            return []
        }
        2 * dao.list(_) >> { QueryProperties qp ->
            assert qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == hscID
            assert qp.getQueryFilter(FieldConstants.INACTIVEIND).getFieldValue() == false
            assert qp.getQueryFilter(FieldConstants.BEDDATE).getFieldValue().equals(admitDate)
            assert qp.getQueryFilter(FieldConstants.BEDDATE).getFieldValue2().equals(admitDate)
            assert qp.getQueryFilter(FieldConstants.BEDDATE).getCriterion().equals(QueryCriteria.FIELD_BETWEEN_VALUES)
            assert qp.getQueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE).getFieldValue().equals("8")
            assert qp.getQueryFilters().size() == 4
            return []
        }
        0 * _
    }*/


    def "get active hsc bed day decision"(){
        given:
        final long hscID = 1
        final Date bedDate = UhgCalendar.getSQLDate("11/05/2010")
        HscFacilityDecisionBedDayVO vo = new HscFacilityDecisionBedDayVO(hscID: hscID, inactiveInd: false, bedDate: bedDate)

        when:
        HscFacilityDecisionBedDayVO retVO = hscFacilityDecisionBedDay.getActiveHscBedDayDecision(hscID, bedDate)

        then:
        1 * dao.list(_) >> { QueryProperties qp ->
            assert qp.getQueryFilter(FieldConstants.HSCID).getFieldValue() == hscID
            assert qp.getQueryFilter(FieldConstants.INACTIVEIND).getFieldValue() == false
            assert qp.getQueryFilter(FieldConstants.BEDDATE).getFieldValue().equals(bedDate)
            assert qp.getQueryFilters().size() == 3
            return [vo]
        }
        0 * _
        retVO == vo
    }

    private HscFacilityDecisionBedDayVO getHscFacilityDecisionBedDayVO() {
        new HscFacilityDecisionBedDayVO(bedDate: UhgCalendar.getSQLDate("04/26/2013"),
                bedTypeID: "MED",
                revenueCode: "101",
                decisionSubType: "1",
                claimNoteLargeObject: "RCORCO1,05-01-2013 04:19PM:Another Claim Comment RCORCO1,05-01-2013 10:20AM:Claim Comment",
                derivedClaimRemarkCode: "SS",
                bedDayDecisionOutcomeType: "5",
                overrideClaimRemarkCode: "SS",
                overrideReasonText: "OverrideComment",
                overrideReasonType: "EEE",
                decisionReasonType: "95",
                bedDayDecisionSeqNum: 4)
    }

    private HscFacilityDecisionBedDayRangeVO createClinicalBedDayRangeVO(String bedDayDecisionOutcomeType, String decisionReasonType) {
        HscFacilityDecisionBedDayRangeVO bedDayRangeVO = new HscFacilityDecisionBedDayRangeVO()

        bedDayRangeVO.hscID = 1
        bedDayRangeVO.bedDayDecisionSeqNum = 17
        bedDayRangeVO.bedDate = UhgCalendarUtilities.getTodaysDate()

        bedDayRangeVO.bedDayDecisionOutcomeType = bedDayDecisionOutcomeType
        bedDayRangeVO.setDecisionReasonType(decisionReasonType)

        bedDayRangeVO.bedDateBegin = UhgCalendar.getSQLDate("11/05/2010")
        bedDayRangeVO.bedDateEnd = UhgCalendar.getSQLDate("11/08/2010")
        bedDayRangeVO.bedTypeID = "BNU"
        bedDayRangeVO.decisionEnteredByUserID = "CLAYMA1"
        bedDayRangeVO.decisionMadeByUserID = "CLAYMA1"
        bedDayRangeVO.revenueCode = "207"
        bedDayRangeVO.decisionSubType = "3"
        bedDayRangeVO.setNegotiatedRate(10)
        bedDayRangeVO.setNegotiatedRateType("4")
        bedDayRangeVO.setAssessmentID(2)

        bedDayRangeVO.decisionMadeByUserComplocID = 7L
        bedDayRangeVO.decisionMadeByUserDepartmentID = 6L
        bedDayRangeVO.decisionMadeByUserPositionID = 5L
        bedDayRangeVO.decisionFacilityCommDateTime = UhgCalendarUtilities.getTodaysCalendarInUserTimeZone()
        bedDayRangeVO.decisionPhysicianCommDateTime = UhgCalendarUtilities.getTodaysCalendarInUserTimeZone()
        bedDayRangeVO.decisionPhysicianCommRoleType = "AB"

        return bedDayRangeVO
    }

    private QueryProperties getBedDayQueryProperties(long hscID) {
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL);
        qp.addQueryFilter(new QueryFilter(FieldConstants.HSCID, hscID));
        qp.addQueryFilter(new QueryFilter(FieldConstants.INACTIVEIND, false));
        qp.setOrderByAscFields(FieldConstants.BEDDATE);
        qp.setUnboundedListAll(true);
        return qp;
    }

    private QueryProperties makeQueryProperties(long ID) {
        long hscID = ID
        QueryProperties qp = getBedDayQueryProperties(hscID)
        qp.addQueryFilter(new QueryFilter(FieldConstants.BEDDAYDECISIONOUTCOMETYPE, HsrReferenceConstants.BEDDAYDECISIONOUTCOMETYPE_VOID, QueryCriteria.NOT_EQUAL))
        qp
    }

    private ReadProperties getReadProperties(long hscID, java.sql.Date bedDate, short bedDayDecisionSeqNum) {
        ReadProperties rp = new ReadProperties([FieldConstants.HSCID, FieldConstants.BEDDATE, FieldConstants.BEDDAYDECISIONSEQNUM] as String[])
        rp.setKeyValue(FieldConstants.HSCID, hscID)
        rp.setKeyValue(FieldConstants.BEDDATE, bedDate)
        rp.setKeyValue(FieldConstants.BEDDAYDECISIONSEQNUM, bedDayDecisionSeqNum)
        return rp
    }
}
