package com.optum.app;

/**
 * This exception is a generic RuntimeException that can be used in testing.
 * Whenever we expect a RuntimeException thrown by a collaborator
 * and the module under test is not doing to catch it.
 * */
class MockExternalException extends RuntimeException {

    MockExternalException() {
        super()
    }

    MockExternalException(String message) {
        super(message)
    }

}
