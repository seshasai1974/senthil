package com.optum.app.shared.authorization.service

import com.optum.app.common.hsr.businesslogic.HscServiceDosageReport
import com.optum.app.common.hsr.data.HscMeasurementVO
import com.optum.app.common.hsr.data.HscServiceDosageReportVO
import com.optum.app.common.hsr.data.HscSpecialtyProcedureVO
import com.optum.app.ocm.common.member.businesslogic.Member
import com.optum.app.ocm.common.member.businesslogic.MemberAddress
import com.optum.app.ocm.common.member.businesslogic.MemberCoverage
import com.optum.app.ocm.common.member.businesslogic.MemberIdentifier
import com.optum.app.ocm.common.member.businesslogic.MemberTelephone
import com.optum.app.ocm.common.note.businesslogic.Note
import com.optum.app.ocm.controller.support.CommonResponse
import com.optum.app.ocm.ref.businesslogic.CustomerReference
import com.optum.app.shared.authorization.businesslogic.Auth
import com.optum.app.shared.constants.MultiPayerConstants
import com.optum.app.shared.constants.SpclCareConstants
import com.optum.app.shared.constants.SpclCareFeatureFlagConstants
import com.optum.app.shared.constants.SpclCareNonPersistedFieldConstants
import com.optum.app.shared.constants.SpclCareReferenceConstants
import com.optum.app.shared.drugPolicy.data.DosageDO
import com.optum.app.shared.hsc.businesslogic.HscClose
import com.optum.app.shared.hsc.businesslogic.HscHelper
import com.optum.app.shared.hsc.data.AuthRequestDetailsDO
import com.optum.app.shared.microservice.data.AuthRequestDO
import com.optum.app.shared.procedure.businesslogic.ProcedureView
import com.optum.app.shared.procedure.data.ProcedureViewVO
import com.optum.app.shared.specialtyPharmacy.businesslogic.SpecialtyProceduresView
import com.optum.app.shared.specialtyPharmacy.data.SpecialtyProceduresViewVO
import com.optum.rf.common.featureflag.util.FeatureFlagManager
import com.optum.rf.common.featureflag.util.FeatureFlagUtility
import com.optum.rf.common.security.businesslogic.User
import com.optum.rf.core.util.UhgCalendar
import com.optum.rf.dao.constants.SystemGlobalMessages
import com.optum.rf.dao.util.UhgCalendarUtilities
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.Hsc
import com.optum.app.common.hsr.constants.HsrReferenceConstants
import com.optum.app.common.hsr.data.HscAttributeVO
import com.optum.app.common.hsr.data.HscServiceNonFacilityVO
import com.optum.app.common.hsr.data.HscServiceVO
import com.optum.app.common.hsr.data.HscVO
import com.optum.app.common.member.core.data.MemberVO
import spock.lang.Specification
import spock.lang.Unroll

class AuthServiceSpec extends Specification {
    AuthService authService

    private CustomerReference customerReference
    private Hsc hsc
    private Auth auth
    private Note note
    private User user
    private Member member
    private MemberAddress memberAddress
    private MemberCoverage memberCoverage
    private MemberIdentifier memberIdentifier
    private MemberTelephone memberTelephone
    private SpecialtyProceduresView specialtyProceduresView
    private ProcedureView procedureView
    private HscClose hscClose
    private HscHelper hscHelper
    private FeatureFlagManager featureFlagManager
    private HscServiceDosageReport hscServiceDosageReport

    def setup() {
        customerReference = Mock(CustomerReference)
        hsc = Mock(Hsc)
        auth = Mock(Auth)
        note = Mock(Note)
        user = Mock(User)
        member = Mock(Member)
        memberAddress = Mock(MemberAddress)
        memberCoverage = Mock(MemberCoverage)
        memberIdentifier = Mock(MemberIdentifier)
        memberTelephone = Mock(MemberTelephone)
        specialtyProceduresView = Mock(SpecialtyProceduresView)
        procedureView = Mock(ProcedureView)
        hscHelper = Mock(HscHelper)
        hscClose = Mock(HscClose)
        featureFlagManager = Mock(FeatureFlagManager)
        hscServiceDosageReport = Mock(HscServiceDosageReport)

        FeatureFlagUtility.featureFlagManager = featureFlagManager

        authService = new AuthService(hsc: hsc, auth: auth, note: note, user: user, member: member, memberAddress: memberAddress,
                memberCoverage: memberCoverage, memberIdentifier: memberIdentifier, memberTelephone: memberTelephone,
                customerReference: customerReference, specialtyProceduresView: specialtyProceduresView,
                procedureView: procedureView, hscHelper: hscHelper, hscServiceDosageReport: hscServiceDosageReport,
                hscClose: hscClose)
    }

    def "read Member Information"() {
        given:
        long memberID = 12345

        when:
        authService.readMemberInformation(memberID)

        then:
        1 * member.read(memberID) >> new MemberVO(memberID: memberID)
        1 * memberAddress.listByMemberID(memberID) >> []
        1 * memberCoverage.listByMemberID(memberID) >> []
        1 * memberIdentifier.listByMemberID(memberID) >> []
        1 * memberTelephone.listByMemberID(memberID) >> []
        0 * _
    }

    def "validate HscID valid ID"() {
        given:
        AuthRequestDO authRequestDO = new AuthRequestDO(hscID: 555L)

        when:
        authService.validateHscID(authRequestDO)

        then:
        1 * hsc.isValid(authRequestDO.hscID) >> true
        0 * _

        and:
        !authRequestDO.messages
    }

    def "validate HscID invalid ID"() {
        given:
        AuthRequestDO authRequestDO = new AuthRequestDO(hscID: 555L)

        when:
        authService.validateHscID(authRequestDO)

        then:
        1 * hsc.isValid(authRequestDO.hscID) >> false
        0 * _

        and:
        authRequestDO.messages
    }

    def "validate"() {
        given:
        AuthRequestDO authRequestDO = new AuthRequestDO(hscID: 555L)

        when:
        authService.validate(authRequestDO, false)

        then:
        1 * hsc.isValid(authRequestDO.hscID) >> true
        0 * _

        and:
        !authRequestDO.messages
    }

    def "processAuthSubmission"() {
        given:
        long memberID = 1234L
        long hscID = 555L
        AuthRequestDO authRequestDO = new AuthRequestDO(hscID: hscID)
        AuthRequestDetailsDO authRequestDetailsDO
        HscServiceNonFacilityVO hscServiceNonFacilityVO = new HscServiceNonFacilityVO(serviceEndDate: UhgCalendarUtilities.getSqlDateWithDayOffset(30))
        HscServiceVO hscServiceVO = new HscServiceVO(hscServiceNonFacilityVO: hscServiceNonFacilityVO)
        HscVO hscVO = new HscVO(hscID: hscID, memberID: memberID, hscStatusReasonType: HsrReferenceConstants.HSCSTATUSREASONTYPE_SUBMISSION_NOT_REQUIRED, vendorTypeID: 'MBM', vendorCaseID: 'ZZABC123', hscServiceVOs: [hscServiceVO], hscSpecialtyProcedureVO: new HscSpecialtyProcedureVO())
        MemberVO memberVO = new MemberVO(memberID: memberID)
        UhgCalendar submissionDate = UhgCalendarUtilities.getLocalCalendar(UhgCalendarUtilities.todaysDate)
        UhgCalendar startDate = UhgCalendarUtilities.getLocalCalendar(UhgCalendarUtilities.getSqlDateWithDayOffset(20))

        when:
        authService.processAuthSubmission(authRequestDO, authRequestDetailsDO)

        then:
        1 * hsc.isValid(authRequestDO.hscID) >> true
        1 * hsc.readCascadingSpclCare(authRequestDO.hscID) >> hscVO
        1 * member.read(memberID) >> memberVO
        1 * memberAddress.listByMemberID(memberID) >> []
        1 * memberCoverage.listByMemberID(memberID) >> []
        1 * memberIdentifier.listByMemberID(memberID) >> []
        1 * memberTelephone.listByMemberID(memberID) >> []
        1 * note.listByHscID(hscVO.hscID) >> []
        1 * auth.processAuthSubmissionData(hscVO, memberVO, authRequestDetailsDO) >> new Tuple2(submissionDate, startDate)
        1 * customerReference.getReferenceDescription(SpclCareNonPersistedFieldConstants.HSC_OVERALL_STATUS_TYPE, SpclCareReferenceConstants.HSCOVERALLSTATUSTYPE_SUBMISSION_NOT_REQUIRED)
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_PROC_BRAND_REFACTOR) >> enableProcBrandRefactor
        if(enableProcBrandRefactor) {
            1 * procedureView.readByHscID(hscID) >> new ProcedureViewVO()
        } else {
            1 * specialtyProceduresView.read(_) >> new SpecialtyProceduresViewVO()
        }
        1 * hscHelper.isFutureDatingEnabled(hscVO) >> true
        1 * hscHelper.isPHTherapyAuthorization(authRequestDetailsDO?.authType) >> false
        1 * auth.setHttpHeaders(_)

        where: enableProcBrandRefactor << [false, true ]
    }

    def "processAuthSubmission - Elapsed Auth Start Date"() {
        given:
        long memberID = 1234L
        long hscID = 555L
        AuthRequestDO authRequestDO = new AuthRequestDO(hscID: hscID)
        AuthRequestDetailsDO authRequestDetailsDO = new AuthRequestDetailsDO(hscAttributeVOs: [new HscAttributeVO()])
        HscServiceNonFacilityVO hscServiceNonFacilityVO = new HscServiceNonFacilityVO(serviceEndDate: UhgCalendarUtilities.getSqlDateWithDayOffset(30))
        HscServiceVO hscServiceVO = new HscServiceVO(hscServiceNonFacilityVO: hscServiceNonFacilityVO)
        HscVO hscVO = new HscVO(hscID: hscID, memberID: memberID, hscStatusReasonType: HsrReferenceConstants.HSCSTATUSREASONTYPE_SUBMISSION_NOT_REQUIRED, vendorTypeID: 'MBM', vendorCaseID: 'ZZABC123', hscServiceVOs: [hscServiceVO], hscAttributeVOs: [new HscAttributeVO(hscAttributeType: SpclCareReferenceConstants.HSCATTRIBUTETYPE_INITIAL_TREATMENT_DATE, hscAttributeValue: UhgCalendarUtilities.getLocalCalendar().getSQLDate() - 1), new HscAttributeVO(hscAttributeType: SpclCareReferenceConstants.HSCATTRIBUTETYPE_BACKDATING_AUTH, hscAttributeValue: '0')])

        when:
        authService.processAuthSubmission(authRequestDO, authRequestDetailsDO)

        then:
        1 * hsc.isValid(authRequestDO.hscID) >> true
        1 * hsc.readCascadingSpclCare(authRequestDO.hscID) >> hscVO
        1 * hscHelper.isFutureDatingEnabled(hscVO) >> true
        1 * hscHelper.isPHTherapyAuthorization(authRequestDetailsDO?.authType) >> false
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_DEFAULT_HTTP_HEADERS) >> true
        0 * _
    }

    def "process Auth Submission with error message"() {
        given:
        long hscID = 555L
        AuthRequestDO authRequestDO = new AuthRequestDO(hscID: hscID)
        authRequestDO.addMessage(FieldConstants.MEMBERID, SystemGlobalMessages.ERR_REQUIRED_VALUE)
        AuthRequestDetailsDO authRequestDetailsDO = new AuthRequestDetailsDO(hscAttributeVOs: [new HscAttributeVO()])

        when:
        CommonResponse retVal = authService.processAuthSubmission(authRequestDO, authRequestDetailsDO)

        then:
        1 * hsc.isValid(authRequestDO.hscID) >> true
        1 * auth.setHttpHeaders(_)
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_DEFAULT_HTTP_HEADERS) >> false
        1 * hscHelper.isPHTherapyAuthorization(authRequestDetailsDO?.authType) >> false
        0 * _

        and:
        retVal
        retVal.messages
    }

    @Unroll
    def "test recordDrugPolicyMaxDosages: #testCase"(){
        given:
        HscVO hscVO = new HscVO(
                hscID: 7523l,
                authTypeID: SpclCareReferenceConstants.AUTH_TYPE_SPECIALTY_PHARMACY,
                hscAttributeVOs: [new HscAttributeVO(hscAttributeType: SpclCareReferenceConstants.HSCATTRIBUTETYPE_INIT_CHNG_TREATMENT, hscAttributeValue: treatment)],
                hscMeasurementVOs: [new HscMeasurementVO(measurementType: SpclCareReferenceConstants.MEASUREMENTTYPE_WEIGHT, measurementValueDescription: weight)]
        )
        AuthRequestDetailsDO authRequestDetailsDO = new AuthRequestDetailsDO(
                drugPolicyID: 128745l,
                dosageDOs: [
                        new DosageDO(
                                initialFlag: true,
                                dosageFrequency: 3,
                                doseLimit: 10d,
                                procedureFrequencyType: '3',
                                weightMin: 40,
                                weightMax: 50,
                                frequencyMeasurement: '1 / day', totalDoses: 30),
                        new DosageDO(
                                initialFlag: false,
                                dosageFrequency: 1,
                                doseLimit: 20d,
                                procedureFrequencyType: '3',
                                weightMin: 40,
                                weightMax: 50,
                                frequencyMeasurement: '2 / day', totalDoses: 20),
                        new DosageDO(
                                initialFlag: false,
                                dosageFrequency: 1,
                                doseLimit: 20d,
                                procedureFrequencyType: '3',
                                frequencyMeasurement: '2 / day', totalDoses: 20)
                ]
        )

        when:
        authService.recordDrugPolicyMaxDosages(hscVO, authRequestDetailsDO)

        then:
        saves * hscServiceDosageReport.read(hscVO.hscID, _ as Short, SpclCareReferenceConstants.DOSAGE_TYPE_MAX, []) >> null
        saves * hscServiceDosageReport.save({HscServiceDosageReportVO saved ->
            saved.dosageType == SpclCareReferenceConstants.DOSAGE_TYPE_MAX
        })
        0 * _

        where:
        testCase                            | saves | weight    | treatment
        "filter by treatment"               | 1     | '50'      | SpclCareConstants.SPECIALTY_PHARMACY_TREATMENT_STATUS_NEW
        "filter by weight"                  | 2     | '50'      | SpclCareConstants.SPECIALTY_PHARMACY_TREATMENT_STATUS_CONTINUATION
        "filter by weight and treatment"    | 1     | '60'      | SpclCareConstants.SPECIALTY_PHARMACY_TREATMENT_STATUS_CONTINUATION
    }

    @Unroll
    def "test recordDrugPolicyMaxDosages with existing records: #testCase"(){
        given:
        HscVO hscVO = new HscVO(
                hscID: 7523l,
                authTypeID: SpclCareReferenceConstants.AUTH_TYPE_SPECIALTY_PHARMACY,
                hscAttributeVOs: [new HscAttributeVO(hscAttributeType: SpclCareReferenceConstants.HSCATTRIBUTETYPE_INIT_CHNG_TREATMENT, hscAttributeValue: treatment)],
                hscMeasurementVOs: [new HscMeasurementVO(measurementType: SpclCareReferenceConstants.MEASUREMENTTYPE_WEIGHT, measurementValueDescription: weight)]
        )
        AuthRequestDetailsDO authRequestDetailsDO = new AuthRequestDetailsDO(
                drugPolicyID: 128745l,
                dosageDOs: [
                        new DosageDO(
                                initialFlag: true,
                                dosageFrequency: 3,
                                doseLimit: 10d,
                                procedureFrequencyType: '3',
                                weightMin: 40,
                                weightMax: 50,
                                frequencyMeasurement: '1 / day', totalDoses: 30),
                        new DosageDO(
                                initialFlag: false,
                                dosageFrequency: 1,
                                doseLimit: 20d,
                                procedureFrequencyType: '3',
                                weightMin: 40,
                                weightMax: 50,
                                frequencyMeasurement: '2 / day', totalDoses: 20),
                        new DosageDO(
                                initialFlag: false,
                                dosageFrequency: 1,
                                doseLimit: 20d,
                                procedureFrequencyType: '3',
                                frequencyMeasurement: '2 / day', totalDoses: 20)
                ]
        )

        when:
        authService.recordDrugPolicyMaxDosages(hscVO, authRequestDetailsDO)

        then:
        saves * hscServiceDosageReport.read(hscVO.hscID, _ as Short, SpclCareReferenceConstants.DOSAGE_TYPE_MAX, []) >> new HscServiceDosageReportVO(hscID: hscVO.hscID, dosageType: SpclCareReferenceConstants.DOSAGE_TYPE_MAX)
        saves * hscServiceDosageReport.save({HscServiceDosageReportVO saved ->
            saved.dosageType == SpclCareReferenceConstants.DOSAGE_TYPE_MAX
        })
        0 * _

        where:
        testCase                            | saves | weight    | treatment
        "filter by treatment"               | 1     | '50'      | SpclCareConstants.SPECIALTY_PHARMACY_TREATMENT_STATUS_NEW
        "filter by weight"                  | 2     | '50'      | SpclCareConstants.SPECIALTY_PHARMACY_TREATMENT_STATUS_CONTINUATION
        "filter by weight and treatment"    | 1     | '60'      | SpclCareConstants.SPECIALTY_PHARMACY_TREATMENT_STATUS_CONTINUATION
    }

    /**
     * ignoring other functions of processAuthSubmission, ensure the dosage reporting is called when its conditions are met.
     */
    @Unroll
    def "test processAuthSubmission for recordDrugPolicyMaxDosages: #testCase"(){
        given:
        long hscID = new Random().nextLong()
        long drugPolicyID = new Random().nextLong()
        long memberID = new Random().nextLong()
        AuthRequestDO authRequestDO = new AuthRequestDO(hscID: hscID)
        AuthRequestDetailsDO authRequestDetailsDO = new AuthRequestDetailsDO(
                drugPolicyID: drugPolicyID,
                dosageDOs: dosageVOs
        )
        UhgCalendar submissionDate = UhgCalendarUtilities.getLocalCalendar(UhgCalendarUtilities.todaysDate)
        UhgCalendar startDate = UhgCalendarUtilities.getLocalCalendar(UhgCalendarUtilities.getSqlDateWithDayOffset(20))

        when:
        authService.processAuthSubmission(authRequestDO, authRequestDetailsDO)

        then: // before
        hscHelper.isPHTherapyAuthorization(_ as String) >> false
        hscHelper.isFutureDatingEnabled(_ as HscVO) >> false
        hsc.isValid(hscID) >> true
        hsc.readCascadingSpclCare(hscID) >> new HscVO(
                hscID: hscID,
                customerID: MultiPayerConstants.UHC_PAYER_ID,
                memberID: memberID,
                authTypeID: SpclCareReferenceConstants.AUTH_TYPE_SPECIALTY_PHARMACY,
                hscServiceVOs: [new HscServiceVO(serviceSeqNum: 1)],
                hscAttributeVOs: [new HscAttributeVO(hscAttributeType: SpclCareReferenceConstants.HSCATTRIBUTETYPE_INIT_CHNG_TREATMENT, hscAttributeValue: SpclCareConstants.SPECIALTY_PHARMACY_TREATMENT_STATUS_NEW)],
                hscMeasurementVOs: [new HscMeasurementVO(measurementType: SpclCareReferenceConstants.MEASUREMENTTYPE_WEIGHT, measurementValueDescription: '60')]
        )

        and: // dosage recording interactions
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.SGP_DOSAGE_REPORTING) >> flag
        calls * hscServiceDosageReport.save({HscServiceDosageReportVO saved ->
            saved.dosageType == SpclCareReferenceConstants.DOSAGE_TYPE_MAX
        })

        and: // after
        member.read(memberID) >> new MemberVO(memberID: memberID)
        memberAddress.listByMemberID(memberID) >> []
        memberCoverage.listByMemberID(memberID) >> []
        memberIdentifier.listByMemberID(memberID) >> []
        memberTelephone.listByMemberID(memberID) >> []
        auth.processAuthSubmissionData(_ as HscVO, _ as MemberVO, _ as AuthRequestDetailsDO) >> new Tuple2(submissionDate, startDate)

        // can't get these completable futures resolved. catch the exception
//        1 * auth.submitAuthorization(_ as HscVO, _ as MemberVO, _ as List<NoteVO>, _ as UhgCalendar, startDate, _ as AuthRequestDetailsDO, _ as CommonResponse, _ as Session) >> authResponseDO
//        1 * auth.processTermination(_ as HscVO, startDate, _ as Session) >> terminatedAuth
//        hscClose.autoCloseAuth(_ as HscVO)
        NullPointerException npe = thrown(NullPointerException)
        assert npe.stackTrace.find {StackTraceElement e ->
            e.declaringClass = "java.util.concurrent.CompletableFuture"
        }

        where:
        testCase     | calls   | flag  | dosageVOs
        "called"     | 1       | true  | [new DosageDO(initialFlag: true, dosageFrequency: 3, doseLimit: 10d, procedureFrequencyType: '3', frequencyMeasurement: '1 / day', totalDoses: 30)]
        "called"     | 1       | true  | [new DosageDO(initialFlag: false, dosageFrequency: 3, doseLimit: 10d, procedureFrequencyType: '3', frequencyMeasurement: '1 / day', totalDoses: 30), new DosageDO(initialFlag: true, dosageFrequency: 3, doseLimit: 10d, procedureFrequencyType: '3', frequencyMeasurement: '1 / day', totalDoses: 30)]
        "called"     | 2       | true  | [new DosageDO(initialFlag: true, dosageFrequency: 3, doseLimit: 10d, procedureFrequencyType: '3', frequencyMeasurement: '1 / day', totalDoses: 30), new DosageDO(initialFlag: true, dosageFrequency: 3, doseLimit: 10d, procedureFrequencyType: '3', frequencyMeasurement: '1 / day', totalDoses: 30)]
        "not called" | 0       | true  | []
        "not called" | 0       | true  | null
        "not called" | 0       | false | []
    }

    /**
     * ignoring other functions of processAuthSubmission, ensure the dosage reporting is not called
     * if auth type is not Specialty Pharmacy.
     */
    @Unroll
    def "test processAuthSubmission for recordDrugPolicyMaxDosages: non-SGP auth type #authType"(){
        given:
        long hscID = new Random().nextLong()
        long memberID = new Random().nextLong()
        AuthRequestDO authRequestDO = new AuthRequestDO(hscID: hscID)
        AuthRequestDetailsDO authRequestDetailsDO = new AuthRequestDetailsDO()
        UhgCalendar submissionDate = UhgCalendarUtilities.getLocalCalendar(UhgCalendarUtilities.todaysDate)
        UhgCalendar startDate = UhgCalendarUtilities.getLocalCalendar(UhgCalendarUtilities.getSqlDateWithDayOffset(20))

        when:
        authService.processAuthSubmission(authRequestDO, authRequestDetailsDO)

        then: // before
        hscHelper.isPHTherapyAuthorization(_ as String) >> false
        hscHelper.isFutureDatingEnabled(_ as HscVO) >> false
        hsc.isValid(hscID) >> true
        hsc.readCascadingSpclCare(hscID) >> new HscVO(
                hscID: hscID,
                customerID: MultiPayerConstants.UHC_PAYER_ID,
                memberID: memberID,
                authTypeID: authType,
                hscServiceVOs: [new HscServiceVO(serviceSeqNum: 1)]
        )
        member.read(memberID) >> new MemberVO(memberID: memberID)
        memberAddress.listByMemberID(memberID) >> []
        memberCoverage.listByMemberID(memberID) >> []
        memberIdentifier.listByMemberID(memberID) >> []
        memberTelephone.listByMemberID(memberID) >> []
        auth.processAuthSubmissionData(_ as HscVO, _ as MemberVO, _ as AuthRequestDetailsDO) >> new Tuple2(submissionDate, startDate)

        and: // no dosage recording interactions
        0 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.SGP_DOSAGE_REPORTING)
        0 * hscServiceDosageReport.save(_ as HscServiceDosageReportVO)

        // can't get these completable futures resolved. catch the exception
//        1 * auth.submitAuthorization(_ as HscVO, _ as MemberVO, _ as List<NoteVO>, _ as UhgCalendar, startDate, _ as AuthRequestDetailsDO, _ as CommonResponse, _ as Session) >> authResponseDO
//        1 * auth.processTermination(_ as HscVO, startDate, _ as Session) >> terminatedAuth
//        hscClose.autoCloseAuth(_ as HscVO)
        NullPointerException npe = thrown(NullPointerException)
        assert npe.stackTrace.find {StackTraceElement e ->
            e.declaringClass = "java.util.concurrent.CompletableFuture"
        }

        where:
        authType << [
                SpclCareReferenceConstants.AUTH_TYPE_INJECTABLE_CHEMOTHERAPY,
                SpclCareReferenceConstants.AUTH_TYPE_SUPPORTIVE_DRUGS,
                SpclCareReferenceConstants.AUTH_TYPE_OCCUPATIONAL_THERAPY,
                SpclCareReferenceConstants.AUTH_TYPE_ORAL_DRUGS,
                SpclCareReferenceConstants.AUTH_TYPE_RADIATION_ONCOLOGY,
                SpclCareReferenceConstants.AUTH_TYPE_RADIOPHARMACEUTICAL,
                SpclCareReferenceConstants.AUTH_TYPE_SPEECH_THERAPY
        ]
    }

    /**
     * ignoring other functions of processAuthSubmission, ensure the dosage reporting is not called
     * if payer is not UHC.
     */
    @Unroll
    def "test processAuthSubmission for recordDrugPolicyMaxDosages: non-UHC auth #payer"(){
        given:
        long hscID = new Random().nextLong()
        long memberID = new Random().nextLong()
        AuthRequestDO authRequestDO = new AuthRequestDO(hscID: hscID)
        AuthRequestDetailsDO authRequestDetailsDO = new AuthRequestDetailsDO()
        UhgCalendar submissionDate = UhgCalendarUtilities.getLocalCalendar(UhgCalendarUtilities.todaysDate)
        UhgCalendar startDate = UhgCalendarUtilities.getLocalCalendar(UhgCalendarUtilities.getSqlDateWithDayOffset(20))

        when:
        authService.processAuthSubmission(authRequestDO, authRequestDetailsDO)

        then: // before
        hscHelper.isPHTherapyAuthorization(_ as String) >> false
        hscHelper.isFutureDatingEnabled(_ as HscVO) >> false
        hsc.isValid(hscID) >> true
        hsc.readCascadingSpclCare(hscID) >> new HscVO(
                hscID: hscID,
                customerID: payer,
                memberID: memberID,
                authTypeID: SpclCareReferenceConstants.AUTH_TYPE_SPECIALTY_PHARMACY,
                hscServiceVOs: [new HscServiceVO(serviceSeqNum: 1)]
        )
        member.read(memberID) >> new MemberVO(memberID: memberID)
        memberAddress.listByMemberID(memberID) >> []
        memberCoverage.listByMemberID(memberID) >> []
        memberIdentifier.listByMemberID(memberID) >> []
        memberTelephone.listByMemberID(memberID) >> []
        auth.processAuthSubmissionData(_ as HscVO, _ as MemberVO, _ as AuthRequestDetailsDO) >> new Tuple2(submissionDate, startDate)

        and: // no dosage recording interactions
        0 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.SGP_DOSAGE_REPORTING)
        0 * hscServiceDosageReport.save(_ as HscServiceDosageReportVO)

        // can't get these completable futures resolved. catch the exception
//        1 * auth.submitAuthorization(_ as HscVO, _ as MemberVO, _ as List<NoteVO>, _ as UhgCalendar, startDate, _ as AuthRequestDetailsDO, _ as CommonResponse, _ as Session) >> authResponseDO
//        1 * auth.processTermination(_ as HscVO, startDate, _ as Session) >> terminatedAuth
//        hscClose.autoCloseAuth(_ as HscVO)
        NullPointerException npe = thrown(NullPointerException)
        assert npe.stackTrace.find {StackTraceElement e ->
            e.declaringClass = "java.util.concurrent.CompletableFuture"
        }

        where:
        payer << [
                MultiPayerConstants.BCBS_SC_PAYER_ID,
                MultiPayerConstants.MBM_PAYER_ID,
                MultiPayerConstants.PHN_PAYER_ID
        ]
    }
}
