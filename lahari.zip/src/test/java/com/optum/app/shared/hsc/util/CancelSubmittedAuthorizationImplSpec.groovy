package com.optum.app.shared.hsc.util

import com.optum.app.ocm.common.member.businesslogic.Member
import com.optum.app.shared.constants.SpclCareReferenceConstants
import com.optum.app.shared.hsc.businesslogic.HscHelper
import com.optum.app.shared.hsc.data.CancelSubmittedAuthDO
import com.optum.app.shared.jbpm.JbpmHelper
import com.optum.app.shared.jbpm.data.JbpmConstants
import com.optum.app.shared.letters.businesslogic.RRDLetters
import com.optum.app.shared.workqueue.businesslogic.MbmWorkQueueSearch
import com.optum.app.shared.workqueue.mapper.MbmWorkQueueSearchRequestMapper
import com.optum.mbm.workqueue.data.v3.response.ItemTaskCriteriaResponse
import com.optum.rf.common.featureflag.util.FeatureFlagManager
import com.optum.rf.common.featureflag.util.FeatureFlagUtility
import com.optum.rf.common.security.data.UserSecurityVO
import com.optum.rf.dao.controller.session.SessionThreadLocal
import com.optum.rf.web.controller.session.HttpUserSession
import com.optum.app.common.activity.data.ActivityVO
import com.optum.app.common.hsr.businesslogic.Hsc
import com.optum.app.common.hsr.businesslogic.HscServiceDecision
import com.optum.app.common.hsr.data.HscServiceDecisionVO
import com.optum.app.common.hsr.data.HscVO
import com.optum.app.common.member.core.data.MemberVO
import spock.lang.Specification

class CancelSubmittedAuthorizationImplSpec extends Specification {
    private CancelSubmittedAuthorizationImpl cancelSubmittedAuthorizationImpl
    private Hsc hsc = Mock(Hsc)
    private HscServiceDecision hscServiceDecision = Mock(HscServiceDecision)
    private MbmWorkQueueSearch mbmWorkQueueSearch = Mock(MbmWorkQueueSearch)
    private MbmWorkQueueSearchRequestMapper mbmWorkQueueSearchRequestMapper = Mock(MbmWorkQueueSearchRequestMapper)
    private Member member = Mock(Member)
    private JbpmHelper jbpmHelper = Mock(JbpmHelper)
    private final static long TEST_HSC_ID = 1234L
    private HscHelper hscHelper = Mock(HscHelper)
    private RRDLetters rrdLetters = Mock()
    FeatureFlagManager featureFlagManager

    def setup() {
        cancelSubmittedAuthorizationImpl = new CancelSubmittedAuthorizationImpl()
        cancelSubmittedAuthorizationImpl.hsc = hsc
        cancelSubmittedAuthorizationImpl.hscServiceDecision = hscServiceDecision
        cancelSubmittedAuthorizationImpl.mbmWorkQueueSearch = mbmWorkQueueSearch
        cancelSubmittedAuthorizationImpl.hscHelper = hscHelper
        cancelSubmittedAuthorizationImpl.rrdLetters = rrdLetters
        cancelSubmittedAuthorizationImpl.member = member
        cancelSubmittedAuthorizationImpl.jbpmHelper = jbpmHelper
        cancelSubmittedAuthorizationImpl.workQueueSearchRequestMapper = mbmWorkQueueSearchRequestMapper
        featureFlagManager = Mock(FeatureFlagManager)
        FeatureFlagUtility.featureFlagManager = featureFlagManager
    }

    def 'cancel submitted authorization request'() {
        given:
        CancelSubmittedAuthDO cancelSubmittedAuthDO = new CancelSubmittedAuthDO()
        HttpUserSession session = new HttpUserSession()
        session.setUserSecurity(new UserSecurityVO(userID: 'testID'))
        SessionThreadLocal.setSession(session)

        String cancelReason = 1
        String decisionReason = 1
        HscVO hscVO = new HscVO(hscID: TEST_HSC_ID)
        HscVO hscEpaVO = new HscVO(hscID: TEST_HSC_ID)
        List<HscServiceDecisionVO> hscServiceDecisionVOs = mockHscServiceDecisionVOs()
        List<ItemTaskCriteriaResponse> itemTaskCriteriaResponseList = [new ItemTaskCriteriaResponse(itemTaskId: 1, assignmentTypeId: 1), new ItemTaskCriteriaResponse(itemTaskId: 1, assignmentTypeId: 1)]

        cancelSubmittedAuthDO.setCancelReason(cancelReason)
        cancelSubmittedAuthDO.setHscID(TEST_HSC_ID)
        cancelSubmittedAuthDO.setDecisionReason(decisionReason)
        cancelSubmittedAuthDO.setActivityResolutionReason('94')
        cancelSubmittedAuthDO.setItemTaskCriteriaResponseList(itemTaskCriteriaResponseList)
        MemberVO memberVO = new MemberVO()

        ActivityVO activityVO = new ActivityVO()
        activityVO.setActivityResolutionReasonType('94')
        activityVO.setContactUserID(session.getUserSecurity().getUserID())

        when:
        cancelSubmittedAuthorizationImpl.cancelRequest(cancelSubmittedAuthDO)

        then:
        1 * hsc.readCascadingSpclCare(TEST_HSC_ID) >> hscEpaVO
        1 * hscHelper.readCascadingSpclCare(TEST_HSC_ID) >> hscVO
        1 * hscHelper.cancelEPARequest(hscVO) >> true
        1 * hscHelper.isPHTherapyAuthorization(hscHelper.getAuthType(TEST_HSC_ID)) >> true
        1 * rrdLetters.cancelAuth(TEST_HSC_ID)
        1 * hscServiceDecision.update(_)
        1 * member.readCascading(0) >> memberVO
        1 * hsc.save(hscVO)
        1 * jbpmHelper.sendStepperContinueSignal(hscVO, memberVO, activityVO, JbpmConstants.DYNAMIC_UM_FLOW, SpclCareReferenceConstants.CANCEL_AUTH_ACTIVITY)
        1 * hscServiceDecision.listCurrentByHscID(TEST_HSC_ID) >> hscServiceDecisionVOs
        _ * mbmWorkQueueSearch.saveItemTaskList(itemTaskCriteriaResponseList)
    }

    def 'cancel submitted authorization request non-PHTherapy'() {
        given:
        CancelSubmittedAuthDO cancelSubmittedAuthDO = new CancelSubmittedAuthDO()
        HttpUserSession session = new HttpUserSession()
        session.setUserSecurity(new UserSecurityVO(userID: 'testID'))
        SessionThreadLocal.setSession(session)

        String cancelReason = 1
        String decisionReason = 1
        HscVO hscVO = new HscVO(hscID: TEST_HSC_ID)
        HscVO hscEpaVO = new HscVO(hscID: TEST_HSC_ID)
        List<HscServiceDecisionVO> hscServiceDecisionVOs = mockHscServiceDecisionVOs()
        List<ItemTaskCriteriaResponse> itemTaskCriteriaResponseList = [new ItemTaskCriteriaResponse(itemTaskId: 1, assignmentTypeId: 1), new ItemTaskCriteriaResponse(itemTaskId: 1, assignmentTypeId: 1)]

        cancelSubmittedAuthDO.setCancelReason(cancelReason)
        cancelSubmittedAuthDO.setHscID(TEST_HSC_ID)
        cancelSubmittedAuthDO.setDecisionReason(decisionReason)
        cancelSubmittedAuthDO.setActivityResolutionReason('94')
        cancelSubmittedAuthDO.setItemTaskCriteriaResponseList(itemTaskCriteriaResponseList)
        MemberVO memberVO = new MemberVO()

        ActivityVO activityVO = new ActivityVO()
        activityVO.setActivityResolutionReasonType('94')
        activityVO.setContactUserID(session.getUserSecurity().getUserID())

        when:
        cancelSubmittedAuthorizationImpl.cancelRequest(cancelSubmittedAuthDO)

        then:
        1 * hsc.readCascadingSpclCare(TEST_HSC_ID) >> hscEpaVO
        1 * hscHelper.readCascadingSpclCare(TEST_HSC_ID) >> hscVO
        1 * hscHelper.cancelEPARequest(hscVO) >> true
        1 * hscHelper.isPHTherapyAuthorization(hscHelper.getAuthType(TEST_HSC_ID)) >> false
        0 * rrdLetters.cancelAuth(TEST_HSC_ID)
        1 * hscServiceDecision.update(_)
        1 * member.readCascading(0) >> memberVO
        1 * hsc.save(hscVO)
        1 * jbpmHelper.sendStepperContinueSignal(hscVO, memberVO, activityVO, JbpmConstants.DYNAMIC_UM_FLOW, SpclCareReferenceConstants.CANCEL_AUTH_ACTIVITY)
        1 * hscServiceDecision.listCurrentByHscID(TEST_HSC_ID) >> hscServiceDecisionVOs
        _ * mbmWorkQueueSearch.saveItemTaskList(itemTaskCriteriaResponseList)
    }

    private List<HscServiceDecisionVO> mockHscServiceDecisionVOs() {
        List<HscServiceDecisionVO> hscServiceDecisionVOs = new ArrayList<>()
        HscServiceDecisionVO hscServiceDecisionVO = new HscServiceDecisionVO(decisionOutcomeType: '1', serviceSeqNum: 1, decisionSeqNum: 1)
        hscServiceDecisionVOs.add(hscServiceDecisionVO)
        return hscServiceDecisionVOs
    }
}
