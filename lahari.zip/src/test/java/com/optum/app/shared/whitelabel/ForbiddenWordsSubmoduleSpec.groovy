package com.optum.app.shared.whitelabel

import spock.lang.Specification

class ForbiddenWordsSubmoduleSpec extends Specification implements WhiteLabelTestData {
    // Subject Under Test. Instantiating here ensures we restart internal state in each test
    def forbiddenWordsSubmodule = new ForbiddenWordsSubmoduleConfig().forbiddenWordsSubmoduleWithInMemoryRepos()

    def "Success: Merging the different forbidden words levels"() {
        given:
        if(customerForbiddenWords != null) {
            forbiddenWordsSubmodule.saveFWCustomerLevelValues("c1", customerForbiddenWords)
        }
        if(orgForbiddenWords != null) {
            forbiddenWordsSubmodule.saveFWOrganizationLevelValues('o1', orgForbiddenWords)
        }

        when:
        def whiteLabels = forbiddenWordsSubmodule.getMergedForbiddenWords("c1", "o1")

        then:
        noExceptionThrown()
        whiteLabels == expectedMergedWhiteLabels

        where:
        customerForbiddenWords | orgForbiddenWords  | expectedMergedWhiteLabels
        [] as List<String>     | [] as List<String> | [] as List<String>
        [] as List<String>     | ["bOnly"]          | ["bOnly"]
        ["aOnly"]              | []                 | ["aOnly"]
        ["a"]                  | ["b"]              | ["a", "b"]
    }

    def "Success: Customer Level forbidden words maintenance"() {
        given:
        def customerVO = newCustomerVO(1)

        when:
        forbiddenWordsSubmodule.saveFWCustomerLevelValues(customerVO.customerName, forbiddenWords())
        def getResult = forbiddenWordsSubmodule.getFWCustomerLevelValues(customerVO.customerName)

        then:
        noExceptionThrown()
        getResult != null
    }

    def "Success: Org Level forbidden words maintenance"() {
        given:
        def customerVO = newCustomerVO(1)

        when:
        forbiddenWordsSubmodule.saveFWOrganizationLevelValues(customerVO.customerName, forbiddenWords())
        def getResult = forbiddenWordsSubmodule.getFWOrganizationLevelValues(customerVO.customerName)

        then:
        noExceptionThrown()
        getResult != null
    }

}
