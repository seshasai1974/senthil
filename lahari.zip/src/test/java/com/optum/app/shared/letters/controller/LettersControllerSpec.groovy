package com.optum.app.shared.letters.controller


import com.optum.app.ocm.controller.support.CommonResponse
import com.optum.app.shared.letters.businesslogic.RRDLetters
import com.optum.mbm.letters.service.model.fileservice.DocumentResponse
import com.optum.mbm.letters.service.model.fileservice.FDSAttachments
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import spock.lang.Specification

class LettersControllerSpec extends Specification {

    LettersController lettersController


    RRDLetters rrdLettersService = Mock(RRDLetters)


    def setup() {
        lettersController = new LettersController()
        lettersController.rrdLettersService = rrdLettersService;
    }

    def "getLetterPdf for attachmentId and documentId"()  {
        given:
        ResponseEntity res = new ResponseEntity("OK", HttpStatus.OK)
        when:
        CommonResponse response = lettersController.getLetterPdf( documentId, attachmentId);

        then:
        1 * rrdLettersService.retrievePDF(_,_) >> res

        where:
        attachmentId | documentId
        "e6cc2179-6abf-4935-9999-aeb98b546208"            | "5ddbd5bba49b50004c0fb911"
    }

}