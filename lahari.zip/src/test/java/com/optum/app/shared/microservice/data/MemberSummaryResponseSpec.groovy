package com.optum.app.shared.microservice.data

import com.optum.app.shared.microservice.data.MemberSummaryItem
import com.optum.app.shared.microservice.data.MemberSummaryResponse
import org.apache.commons.lang.StringUtils
import spock.lang.Specification

/**
 * Created by cnadipin on 1/10/19.
 */
class MemberSummaryResponseSpec extends Specification{

    MemberSummaryResponse memberSummaryResponse

    def setup() {
        MemberSummaryItem memberSummaryItem = new MemberSummaryItem(firstName: 'AAAAA', lastName: 'BBBBB')
        List<MemberSummaryItem> memberSummary =[memberSummaryItem]

        memberSummaryResponse = new MemberSummaryResponse(summaryItems: memberSummary)

    }

    def "getSummaryItems"() {

        when:
        List<MemberSummaryItem> retVal = memberSummaryResponse.getsummaryItems()

        then:
        0 * _

        and:
        !retVal.isEmpty()
    }

    def "setSummaryItems"() {

        when:
        List<MemberSummaryItem> retVal = memberSummaryResponse.setsummaryItems([])

        then:
        0 * _

        and:
        !retVal
    }

    def "equals true"() {

        when:
        boolean retVal = memberSummaryResponse.equals(memberSummaryResponse)

        then:
        0 * _

        and:
        retVal
    }

    def "equals false"() {

        when:
        boolean retVal = memberSummaryResponse.equals(_)

        then:
        0 * _

        and:
        !retVal
    }

    def "hash"() {

        when:
        int retVal = memberSummaryResponse.hashCode()

        then:
        0 * _

        and:
        retVal
        retVal > 0
    }

    def "to String"() {

        when:
        String retVal = memberSummaryResponse.toString()

        then:
        0 * _

        and:
        StringUtils.isNotBlank(retVal)
    }
}
