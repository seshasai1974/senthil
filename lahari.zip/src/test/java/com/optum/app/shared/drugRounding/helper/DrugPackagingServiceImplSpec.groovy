package com.optum.app.shared.drugRounding.helper

import com.fasterxml.jackson.databind.ObjectMapper
import com.optum.app.shared.drugRounding.data.DrugPackagingDO
import com.optum.app.shared.drugRounding.helper.impl.DrugPackagingServiceImpl
import com.optum.app.shared.drugRounding.mapper.DrugPackagingRequestMapper
import com.optum.app.shared.spclcare.SpecialtyCareReadLogicSpecification
import com.optum.rf.common.settings.businesslogic.SystemSettingsWebService
import com.optum.rf.common.settings.data.SystemSettingsWebServiceVO
import com.optum.rf.common.webservice.logging.businesslogic.WebServiceLog
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.client.RestTemplate
import spock.lang.Unroll

class DrugPackagingServiceImplSpec extends SpecialtyCareReadLogicSpecification {

    private DrugPackagingServiceImpl drugPackagingServiceImpl
    private SystemSettingsWebService systemSettingsWebService
    private RestTemplate restTemplate
    private WebServiceLog webServiceLog
    private ObjectMapper jsonObjectMapper
    private DrugPackagingRequestMapper drugPackagingRequestMapper

    def setup() {
        drugPackagingServiceImpl = new DrugPackagingServiceImpl()
        drugPackagingRequestMapper = Mock(DrugPackagingRequestMapper)
        systemSettingsWebService = Mock(SystemSettingsWebService)
        restTemplate = Mock(RestTemplate)
        webServiceLog = Mock(WebServiceLog)
        jsonObjectMapper = Mock(ObjectMapper)
        drugPackagingServiceImpl.drugPackagingRequestMapper = drugPackagingRequestMapper
        drugPackagingServiceImpl.restTemplate = restTemplate
        drugPackagingServiceImpl.webServiceLog = webServiceLog
        drugPackagingServiceImpl.jsonObjectMapper = jsonObjectMapper
    }

    @Unroll
    def 'getDrugsPackaging'(){
        given:
        String drugs = 'abcDrug&reg;,xyzDrug&reg;'

        when:
        DrugPackagingDO drugPackagingDO = drugPackagingServiceImpl.getDrugsPackaging(drugs)

        then:
        1 * drugPackagingRequestMapper.getSystemSettingsWebServiceVO() >> systemSettingsWebServiceVO
        1 * drugPackagingRequestMapper.getDrugPackagingRestTemplate(restTemplate)
        1 * drugPackagingRequestMapper.buildHttpHeader()
        1 * restTemplate.exchange(*_) >> responseEntity
        1 * webServiceLog.addNewTransaction(_)

        and:
        drugPackagingDO

        where:
        testCase | systemSettingsWebServiceVO                                  | responseEntity
        0        | new SystemSettingsWebServiceVO(wsUrl: 'http://www.abc.com') | new ResponseEntity(_, HttpStatus.OK)
        1        | new SystemSettingsWebServiceVO(wsUrl: 'http://www.abc.com') | new ResponseEntity(HttpStatus.CONFLICT)

       }


}
