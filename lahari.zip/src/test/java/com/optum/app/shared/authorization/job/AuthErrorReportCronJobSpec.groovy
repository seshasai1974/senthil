package com.optum.app.shared.authorization.job

import com.optum.app.shared.authorization.job.AuthErrorReportCronJob
import spock.lang.Specification

/**
 * Created by cnadipin on 1/9/19.
 */
class AuthErrorReportCronJobSpec extends Specification {

    def "test AuthErrorReportCronJob"(){
        given:
        AuthErrorReportCronJob authErrorReportCronJob = new AuthErrorReportCronJob()

        when:
        authErrorReportCronJob != null

        then:
        authErrorReportCronJob.getCronPattern() == "45 11 * * *"
        authErrorReportCronJob.getSystemJobID() == "AER"
        authErrorReportCronJob.getDescription() == "Auth Error Report"
        authErrorReportCronJob.getTask() != null
    }

}
