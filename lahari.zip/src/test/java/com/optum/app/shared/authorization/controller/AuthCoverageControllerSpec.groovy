package com.optum.app.shared.authorization.controller

import com.optum.app.ocm.controller.support.CommonResponse
import com.optum.app.shared.authorization.businesslogic.AuthCoverageService
import com.optum.app.shared.hsc.data.AuthRequestDetailsDO
import spock.lang.Specification

class AuthCoverageControllerSpec extends Specification{

    AuthCoverageController authCoverageController
    AuthCoverageService authCoverageService

    def setup() {
        authCoverageController = new AuthCoverageController()
        authCoverageService = Mock(AuthCoverageService)
        authCoverageController.authCoverageService = authCoverageService
    }

    def "test showDraftPopup"(){

        when:
        CommonResponse response = authCoverageController.showDraftPopup(hscId)

        then:
        1 * authCoverageService.showDraftPopup(hscId)

        where:
        testCase | hscId
        0        | 12L
    }

    def "test getAuthCoverageDetails "(){

        when:
        CommonResponse response = authCoverageController.getAuthCoverageDetails(memberId, hscId)

        then:
        1 * authCoverageService.getAuthCoverageDetails(memberId, hscId)

        where:
        testCase | hscId    | memberId
        0        | 12L      | 1L

    }

}
