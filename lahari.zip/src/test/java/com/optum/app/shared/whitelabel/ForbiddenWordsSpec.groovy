package com.optum.app.shared.whitelabel

import com.optum.app.common.organization.data.OrganizationVO
import com.optum.app.ocm.customer.businesslogic.Customer
import com.optum.app.ocm.organization.businesslogic.Organization
import com.optum.app.shared.authorization.businesslogic.Authorizations
import com.optum.app.shared.common.controller.advice.BadRequestException
import com.optum.app.shared.common.messages.SpclCareMessages
import com.optum.app.shared.whitelabel.dto.ForbiddenWordsDto
import com.optum.rf.dao.exception.UhgRuntimeException
import spock.lang.Specification

class ForbiddenWordsSpec extends Specification implements WhiteLabelTestData {
    // Mocks dependencies external to the current module.
    Customer customer = Mock(Customer)
    Authorizations authorizations = Mock(Authorizations)
    Organization organization = Mock(Organization)
    CustomerWLSubmodule customerWhiteLabelsSubmodule = Mock(CustomerWLSubmodule)
    ForbiddenWordsSubmodule forbiddenWordsSubmodule = Mock(ForbiddenWordsSubmodule)
    // Subject Under Test. Instantiating here ensures we restart internal state in each test
    WhiteLabel whiteLabel = new WhiteLabelConfiguration().whiteLabel(
            authorizations,
            customer,
            organization,
            customerWhiteLabelsSubmodule,
            forbiddenWordsSubmodule
    )

    def 'Success: read customer level forbidden words'() {
        given:
        def customerId = 1

        when: "read"
        List<String> response = whiteLabel.forbiddenWordsMaintenance.getFWCustomerLevelValues(customerId)

        then:
        noExceptionThrown()
        response == ["FoRbIddEnWOrD", "forbidden WORDS", "custo"]
        1 * authorizations.validateCustomer(customerId)
        1 * customer.read(customerId, []) >> newCustomerVO(customerId)
        1 * forbiddenWordsSubmodule.getFWCustomerLevelValues(_ as String) >> ["FoRbIddEnWOrD", "forbidden WORDS", "custo"]
    }

    def 'Success: read org level forbidden words'() {
        given:
        def customerId = 1

        when: "read"
        List<String> response = whiteLabel.forbiddenWordsMaintenance.getFWOrganizationLevelValues(customerId)

        then:
        noExceptionThrown()
        response == ["FoRbIddEnWOrD", "forbidden WORDS", "custo"]
        1 * authorizations.validateCustomer(customerId)
        1 * customer.read(customerId, []) >> newCustomerVO(customerId)
        1 * organization.read(0, []) >> new OrganizationVO(organizationShortName: "org-0")
        1 * forbiddenWordsSubmodule.getFWOrganizationLevelValues( "org-0") >> ["FoRbIddEnWOrD", "forbidden WORDS", "custo"]
    }

    def 'Success: save customer level forbidden words'() {
        given:
        def customerId = 1
        def customerModel = toCustomerModel(newCustomerVO(customerId))

        when: "save"
        whiteLabel.forbiddenWordsMaintenance.saveFWCustomerLevelValues(forbiddenWordsDtoFor(newCustomerVO(customerId)))

        then:
        1 * authorizations.validateCustomer(customerId)
        1 * customer.read(_) >> newCustomerVO(customerId)
        1 * organization.read(_) >> new OrganizationVO(organizationID: 0, organizationShortName: "org-0")
        1 * customerWhiteLabelsSubmodule.getMergedCustomerWhiteLabels(customerModel.customerName, customerModel.organizationName) >> Optional.empty()
    }

    def 'Success: save org level forbidden words'() {
        given:
        def customerId = 1
        def customerModel = toCustomerModel(newCustomerVO(customerId))

        when: "save"
        whiteLabel.forbiddenWordsMaintenance.saveFWOrganizationLevelValues(forbiddenWordsDtoFor(newCustomerVO(customerId)))

        then:
        1 * authorizations.validateCustomer(customerId)
        1 * customer.read(_) >> newCustomerVO(customerId)
        1 * organization.read(_) >> new OrganizationVO(organizationID: 0, organizationShortName: "org-0")
        1 * customerWhiteLabelsSubmodule.getMergedCustomerWhiteLabels(customerModel.customerName, customerModel.organizationName) >> Optional.empty()
    }

    def 'Failure save customer level whiteLabels - forbidden words (internal)'() {
        given:
        def customerVO = newCustomerVO(1)

        when: 'save'
        whiteLabel.customerWhiteLabelsMaintenance.saveWLCustomerLevelValues(newCustomerWhiteLabelsDto(customerVO.customerID, invalidWhiteLabels))

        then:
        UhgRuntimeException e = thrown(exception)
        e.getErrorVO().getGlobalMessages().contains(SpclCareMessages.ERR_FORBIDDEN_WORD_IN_WHITE_LABELS(customerVO.customerName))
        1 * authorizations.validateCustomer(_)
        1 * customer.read(customerVO.customerID, []) >> customerVO
        1 * organization.read(0, []) >> new OrganizationVO(organizationShortName: "org-0")
        1 * forbiddenWordsSubmodule.getMergedForbiddenWords(customerVO.customerName, "org-0") >> forbiddenWords()

        where:
        exception                | invalidWhiteLabels
        UhgRuntimeException      | '{ "aKey": "a forbiddenWord here" }'
        UhgRuntimeException      | '{"nested": { "aKey": " forbiddenWord" } }'
        UhgRuntimeException      | '{"array": ["aValue", "forbiddenWord"] }'
        UhgRuntimeException      | '{ "aKey": "forbiddenWord" }'
        UhgRuntimeException      | '{"nested": { "aKey": "forbiddenWord" }}'
        UhgRuntimeException      | '{"array": ["aValue", "forbiddenWord"] }'
        UhgRuntimeException      | '{ "aKey": "FORBIDDEn   WORDs" }'
        UhgRuntimeException      | '{"nested": { "aKey": " FORBIDDEn    WORDs"} }'
        UhgRuntimeException      | '{"array": ["aValue", "FORBIDDEn\\t  \\tWORDs"]    }'
        UhgRuntimeException      | '{ "aKey": "forbiddenWord"}'
        UhgRuntimeException      | '{"nested": { "aKey": "FORBIDDEn WORDs" }}'
        UhgRuntimeException      | '{"array": ["aValue", "FORBIDDEn WORDs"] }'
    }

    def 'Failure save customer level forbidden words - forbidden words (internal)'() {
        given:
        def customerVO = newCustomerVO(1)

        when: 'save'
        whiteLabel.forbiddenWordsMaintenance.saveFWCustomerLevelValues(forbiddenWordsDtoFor(customerVO))

        then:
        UhgRuntimeException e = thrown(exception)
        e.getErrorVO().getGlobalMessages().contains(SpclCareMessages.ERR_FORBIDDEN_WORD_IN_WHITE_LABELS(customerVO.customerName))
        1 * authorizations.validateCustomer(customerVO.customerID)
        1 * customer.read(_) >> newCustomerVO(customerVO.customerID)
        1 * organization.read(_) >> new OrganizationVO(organizationID: 0, organizationShortName: "org-0")
        1 * customerWhiteLabelsSubmodule.getMergedCustomerWhiteLabels(customerVO.customerName, "org-0") >> toOptionalJson(invalidWhiteLabels)

        where:
        exception                 | invalidWhiteLabels
        UhgRuntimeException      | '{ "aKey": "a forbiddenWord here" }'
        UhgRuntimeException      | '{"nested": { "aKey": " forbiddenWord" } }'
        UhgRuntimeException      | '{"array": ["aValue", "forbiddenWord"] }'
        UhgRuntimeException      | '{ "aKey": "forbiddenWord" }'
        UhgRuntimeException      | '{"nested": { "aKey": "forbiddenWord" }}'
        UhgRuntimeException      | '{"array": ["aValue", "forbiddenWord"] }'
        UhgRuntimeException      | '{ "aKey": "FORBIDDEn   WORDs" }'
        UhgRuntimeException      | '{"nested": { "aKey": " FORBIDDEn    WORDs"} }'
        UhgRuntimeException      | '{"array": ["aValue", "FORBIDDEn\\t  \\tWORDs"]    }'
        UhgRuntimeException      | '{ "aKey": "forbiddenWord"}'
        UhgRuntimeException      | '{"nested": { "aKey": "FORBIDDEn WORDs" }}'
        UhgRuntimeException      | '{"array": ["aValue", "FORBIDDEn WORDs"] }'
    }

    def 'External Customer Failures (null) - save and consume customer level forbidden words'() {
        given:
        def customerId = 1
        def forbiddenWords = ["Forbidden word"]

        when:
        whiteLabel.forbiddenWordsMaintenance.saveFWCustomerLevelValues(new ForbiddenWordsDto(
                customerId: customerId,
                forbiddenWords: forbiddenWords
        ))

        then:
        thrown(BadRequestException)
        1 * customer.read(customerId) >> null

        when:
        whiteLabel.customerWhiteLabels(customerId)

        then:
        thrown(BadRequestException)
        1 * customer.read(customerId) >> null
    }

}
