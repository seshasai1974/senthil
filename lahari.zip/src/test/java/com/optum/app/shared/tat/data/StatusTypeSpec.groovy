package com.optum.app.shared.tat.data

import com.optum.rf.dao.exception.UhgRuntimeException
import spock.lang.Specification

class StatusTypeSpec extends Specification{

    def 'fromCode("1")'(){
        given:
        String code = '1'

        when:
        StatusType statusType = StatusType.fromCode(code)

        then:
        statusType == StatusType.GENERATING
    }

    def 'fromCode("2")'(){
        given:
        String code = '2'

        when:
        StatusType statusType = StatusType.fromCode(code)

        then:
        statusType == StatusType.FAILED
    }

    def 'fromCode("3")'(){
        given:
        String code = '3'

        when:
        StatusType statusType = StatusType.fromCode(code)

        then:
        statusType == StatusType.VIEWABLE
    }

    def 'fromCode("4")'(){
        given:
        String code = '4'

        when:
        StatusType statusType = StatusType.fromCode(code)

        then:
        statusType == StatusType.SUCCESS
    }

    def 'fromCode("5")'(){
        given:
        String code = '5'

        when:
        StatusType statusType = StatusType.fromCode(code)

        then:
        statusType == StatusType.USPS_CONFIRMATION
    }

    def 'fromCode("6")'(){
        given:
        String code = '6'

        when:
        StatusType statusType = StatusType.fromCode(code)

        then:
        statusType == StatusType.GENERATED_FAX
    }


    def 'fromCode("7")'(){
        given:
        String code = '7'

        when:
        StatusType statusType = StatusType.fromCode(code)

        then:
        statusType == StatusType.PENDING
    }


    def 'fromCode("8")'(){
        given:
        String code = '8'

        when:
        StatusType statusType = StatusType.fromCode(code)

        then:
        statusType == StatusType.QUEUED
    }

    def 'fromCode invalid' () {
        given:
        String code = '9'


        when:
        StatusType.fromCode(code)

        then:
        final UhgRuntimeException exception = thrown()
        exception.message == 'Invalid StatusType code specified'
    }
}
