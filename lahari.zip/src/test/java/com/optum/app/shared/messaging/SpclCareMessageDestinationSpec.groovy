package com.optum.app.shared.messaging

import com.optum.app.shared.amqp.SpclCareAMQPDestinationProvider
import com.optum.app.shared.messaging.SpclCareMessageDestination
import spock.lang.Specification

/**
 * Created by jboyd34 on 10/10/18.
 */
class SpclCareMessageDestinationSpec extends Specification{


    def "test default constructor"(){

        given:
        SpclCareMessageDestination spclCareMessageDestination = new SpclCareMessageDestination(new SpclCareAMQPDestinationProvider())

        when:
        spclCareMessageDestination != null

        then:
        SpclCareMessageDestination.getDestination(SpclCareMessageDestination.AUTHORIZATION_REFRESH_QUEUE) != null
    }

    def "test exceptions"(){

        given:
        SpclCareMessageDestination spclCareMessageDestination = new SpclCareMessageDestination(null)

        when:
        spclCareMessageDestination.afterPropertiesSet()

        then:
        thrown RuntimeException
        SpclCareMessageDestination.getDestination(SpclCareMessageDestination.AUTHORIZATION_REFRESH_QUEUE) == null
    }

    def "test getMsgDestinationsByMessageType"(){

        given:
        SpclCareMessageDestination spclCareMessageDestination = new SpclCareMessageDestination(new SpclCareAMQPDestinationProvider())

        when:
        spclCareMessageDestination != null

        then:
        SpclCareMessageDestination.getMsgDestinationsByMessageType().size() == 0
        !SpclCareMessageDestination.isMessageTrackingEnabledForMessageType(SpclCareMessageDestination.AUTHORIZATION_REFRESH_QUEUE)
    }
}
