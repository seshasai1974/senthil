package com.optum.app.shared.authorization.job

import com.optum.app.shared.authorization.job.ReprocessUpdateAuthTasksProcessor
import com.optum.app.shared.authorization.job.ReprocessUpdateAuthorizationTasks
import com.optum.rf.core.spring.ApplicationContextHolder
import com.optum.rf.test.core.mock.spring.MockWebApplicationContext
import spock.lang.Specification

/**
 * Created by jboyd34 on 10/8/18.
 */
class ReprocessUpdateAuthorizationTasksSpec extends Specification{

    def "test runtask" () {
        given:
        ApplicationContextHolder.setApplicationContext(new MockWebApplicationContext(), true)
        ((MockWebApplicationContext) ApplicationContextHolder.getApplicationContext()).setBean("reprocessUpdateAuthTasksProcessor", Mock(ReprocessUpdateAuthTasksProcessor))
        ReprocessUpdateAuthorizationTasks tasks = new ReprocessUpdateAuthorizationTasks()

        when:
        boolean result = tasks.runTask(null,null)
        then:
        !result
    }

}
