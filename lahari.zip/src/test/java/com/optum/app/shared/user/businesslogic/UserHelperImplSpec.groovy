package com.optum.app.shared.user.businesslogic

import com.optum.app.ocm.ref.businesslogic.CustomerReference
import com.optum.app.shared.constants.SpclCareConstants
import com.optum.app.shared.ssoauthentication.constants.SsoMbmConstants
import com.optum.app.shared.ssoauthentication.controller.SsoLoginController
import com.optum.app.shared.ssoauthentication.data.OcmSsoData
import com.optum.app.shared.ssoauthentication.data.OcmSsoProviderData
import com.optum.app.shared.user.businesslogic.UserHelper
import com.optum.app.shared.user.businesslogic.impl.UserHelperImpl
import com.optum.rf.common.security.data.UserSecurityVO
import com.optum.rf.dao.controller.session.Session
import com.optum.rf.dao.controller.session.SessionThreadLocal
import com.optum.rf.web.controller.session.HttpUserSession
import spock.lang.Specification
import spock.lang.Unroll

import javax.servlet.http.HttpSession

class UserHelperImplSpec extends Specification{

    UserHelper userHelper
    HttpSession httpSession
    CustomerReference customerReference

    def setup() {
        customerReference = Mock(CustomerReference)
        httpSession = Mock(HttpSession)
        userHelper = new UserHelperImpl(customerReference: customerReference, httpSession: httpSession)
    }

    def 'Test isBriovaUser'() {
        when:
        userHelper.isBriovaUser()

        then:
        1 * httpSession.getAttribute(SsoLoginController.SSO_DATA)
        0 * _
    }

    @Unroll
    def 'Test isSsoDataValid - #testCase'() {
        given:
        Session session = new HttpUserSession()
        session.setUserSecurity(new UserSecurityVO(userGroupID: userGroupID))
        SessionThreadLocal.setSession(session)

        when:
        boolean result = userHelper.isSsoDataValid()

        then:
        1 * httpSession.getAttribute(SsoLoginController.SSO_DATA) >> ocmSsoData
        0 * _

        and:
        result == expectedResult

        where:
        testCase                               | userGroupID                                | expectedResult | ocmSsoData
        "Valid - User is operations"           | SpclCareConstants.ROLE_INTERNAL_OPERATIONS | true           | new OcmSsoData(applicationName: SsoMbmConstants.SYSTEM_MIM)
        "Valid - SSO not through MIM"          | SpclCareConstants.ROLE_PROVIDER            | true           | new OcmSsoData(applicationName: 'PAAN')
        "Invalid - Missing Provider Address 1" | SpclCareConstants.ROLE_PROVIDER            | false          | new OcmSsoData(applicationName: SsoMbmConstants.SYSTEM_MIM, userID: 'user1', providerData: new OcmSsoProviderData(providerCity: 'Fake City', providerState: 'FS', providerZip: 'ZIP12', providerNPI: 'NPI1234', providerBName: 'Fake Business'))
        "Invalid - Missing Provider City"      | SpclCareConstants.ROLE_PROVIDER            | false          | new OcmSsoData(applicationName: SsoMbmConstants.SYSTEM_MIM, userID: 'user1', providerData: new OcmSsoProviderData(providerAddress1: '10 Fake Ln', providerState: 'FS', providerZip: 'ZIP12', providerNPI: 'NPI1234', providerBName: 'Fake Business'))
        "Invalid - Missing Provider State"     | SpclCareConstants.ROLE_PROVIDER            | false          | new OcmSsoData(applicationName: SsoMbmConstants.SYSTEM_MIM, userID: 'user1', providerData: new OcmSsoProviderData(providerAddress1: '10 Fake Ln', providerCity: 'Fake City', providerZip: 'ZIP12', providerNPI: 'NPI1234', providerBName: 'Fake Business'))
        "Invalid - Missing Provider ZIP"       | SpclCareConstants.ROLE_PROVIDER            | false          | new OcmSsoData(applicationName: SsoMbmConstants.SYSTEM_MIM, userID: 'user1', providerData: new OcmSsoProviderData(providerAddress1: '10 Fake Ln', providerCity: 'Fake City', providerState: 'FS', providerNPI: 'NPI1234', providerBName: 'Fake Business'))
        "Invalid - Missing Provider NPI"       | SpclCareConstants.ROLE_PROVIDER            | false          | new OcmSsoData(applicationName: SsoMbmConstants.SYSTEM_MIM, userID: 'user1', providerData: new OcmSsoProviderData(providerAddress1: '10 Fake Ln', providerCity: 'Fake City', providerState: 'FS', providerZip: 'ZIP12', providerBName: 'Fake Business'))
        "Invalid - Missing Provider Name"      | SpclCareConstants.ROLE_PROVIDER            | false          | new OcmSsoData(applicationName: SsoMbmConstants.SYSTEM_MIM, userID: 'user1', providerData: new OcmSsoProviderData(providerAddress1: '10 Fake Ln', providerCity: 'Fake City', providerState: 'FS', providerZip: 'ZIP12', providerNPI: 'NPI1234'))
        "Invalid - Missing User ID"            | SpclCareConstants.ROLE_PROVIDER            | false          | new OcmSsoData(applicationName: SsoMbmConstants.SYSTEM_MIM, providerData: new OcmSsoProviderData(providerAddress1: '10 Fake Ln', providerCity: 'Fake City', providerState: 'FS', providerZip: 'ZIP12', providerNPI: 'NPI1234', providerBName: 'Fake Business'))
        "Valid - All attributes present"       | SpclCareConstants.ROLE_PROVIDER            | true           | new OcmSsoData(applicationName: SsoMbmConstants.SYSTEM_MIM, userID: 'user1', providerData: new OcmSsoProviderData(providerAddress1: '10 Fake Ln', providerCity: 'Fake City', providerState: 'FS', providerZip: 'ZIP12', providerNPI: 'NPI1234', providerBName: 'Fake Business'))
        "Valid - All attributes present"       | SpclCareConstants.ROLE_PROVIDER            | true           | new OcmSsoData(applicationName: SsoMbmConstants.SYSTEM_MIM, userID: 'user1', providerData: new OcmSsoProviderData(providerAddress1: '10 Fake Ln', providerCity: 'Fake City', providerState: 'FS', providerZip: 'ZIP12', providerNPI: 'NPI1234', providerLName: 'Fake Name'))
    }
}
