package com.optum.app.shared.regimen.controller

import com.optum.app.ocm.controller.support.CommonResponse
import com.optum.app.shared.constants.SpclCareFeatureFlagConstants
import com.optum.app.shared.diseaseTraversal.businesslogic.RegimenProcedureView
import com.optum.app.shared.diseaseTraversal.businesslogic.TreatmentRegimen
import com.optum.app.shared.diseaseTraversal.businesslogic.TreatmentRegimenVersion
import com.optum.app.shared.diseaseTraversal.businesslogic.TreatmentRegimenVersionProcedure
import com.optum.app.shared.diseaseTraversal.data.RegimenProcedureViewVO
import com.optum.app.shared.diseaseTraversal.data.TreatmentRegimenVO
import com.optum.app.shared.diseaseTraversal.data.TreatmentRegimenVersionVO
import com.optum.app.shared.procedure.businesslogic.ProcedureBrand
import com.optum.app.shared.procedure.data.ProcedureBrandVO
import com.optum.app.shared.regimen.data.ReplaceProcedureCodeDO
import com.optum.rf.common.reference.data.ProcedureCodeVO
import com.optum.rf.common.featureflag.util.FeatureFlagManager
import com.optum.rf.common.featureflag.util.FeatureFlagUtility
import com.optum.rf.common.reference.businesslogic.Cpt4
import com.optum.rf.common.reference.businesslogic.Hcpcs
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.app.constants.HsrReferenceConstants
import spock.lang.Specification
import spock.lang.Unroll

class RegimenMaintenanceControllerSpec extends Specification {

    TreatmentRegimen treatmentRegimen
    TreatmentRegimenVersion treatmentRegimenVersion
    TreatmentRegimenVersionProcedure treatmentRegimenVersionProcedure
    Cpt4 cpt4
    Hcpcs hcpcs
    RegimenMaintenanceController controller
    RegimenProcedureView regimenProcedureView
    ProcedureBrand procedureBrand
    FeatureFlagManager featureFlagManager

    def setup(){
        treatmentRegimen = Mock(TreatmentRegimen)
        treatmentRegimenVersion = Mock(TreatmentRegimenVersion)
        treatmentRegimenVersionProcedure = Mock(TreatmentRegimenVersionProcedure)
        cpt4 = Mock(Cpt4)
        hcpcs = Mock(Hcpcs)
        regimenProcedureView = Mock(RegimenProcedureView)
        procedureBrand = Mock(ProcedureBrand)
        featureFlagManager = Mock(FeatureFlagManager)
        FeatureFlagUtility.featureFlagManager = featureFlagManager

        controller = new RegimenMaintenanceController(treatmentRegimen: treatmentRegimen, treatmentRegimenVersion: treatmentRegimenVersion, treatmentRegimenVersionProcedure: treatmentRegimenVersionProcedure,
                                                    cpt4: cpt4, hcpcs: hcpcs, regimenProcedureView: regimenProcedureView, procedureBrand: procedureBrand)
    }

    def 'getRegimen'(){
        given:
        QueryProperties qp = new QueryProperties()

        when:
        CommonResponse commonResponse = controller.getRegimen(qp)

        then:
        1 * treatmentRegimen.listAndCascade(qp) >> []
        1 * treatmentRegimen.count(qp)
        0 * _

        and:
        ((List<TreatmentRegimenVO>) commonResponse.embedded.get(CommonResponse.EMBEDDED)).isEmpty()
    }

    def 'saveTreatmentRegimen'(){
        given:
        List<TreatmentRegimenVO> voList = [new TreatmentRegimenVO()]

        when:
        CommonResponse commonResponse = controller.saveTreatmentRegimen(voList)

        then:
        1 * treatmentRegimen.save(voList.first())
        0 * _
    }

    def 'deleteTreatmentRegimen'(){
        given:
        TreatmentRegimenVO vo = new TreatmentRegimenVO()

        when:
        CommonResponse commonResponse = controller.deleteTreatmentRegimen(vo)

        then:
        1 * treatmentRegimen.deleteCascading(vo)
        0 * _
    }

    def 'getTreatmentRegimenByID'(){
        given:
        int treatmentRegimenID = 1234

        when:
        CommonResponse commonResponse = controller.getTreatmentRegimenByID(treatmentRegimenID)

        then:
        1 * treatmentRegimen.readCascading(treatmentRegimenID)
        0 * _
    }

    def 'saveRegimen'(){
        given:
        TreatmentRegimenVO vo = new TreatmentRegimenVO()

        when:
        CommonResponse commonResponse = controller.saveRegimen(0, false, vo)

        then:
        1 * treatmentRegimen.saveCascading(vo, 0, false)
        0 * _
    }

    @Unroll()
    def 'getProcedureCodes: #testCase'(){
        when:
        CommonResponse commonResponse = controller.getProcedureCodes(procCodeType, "", "30")

        then:
        cpt4Call * cpt4.list(_ as QueryProperties) >> [new ProcedureCodeVO(procedureCode: 'S0149')]
        hcpcsCall * hcpcs.list(_ as QueryProperties) >> [new ProcedureCodeVO(procedureCode: 'S0149')]

        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_REGIMEN_MAINTENANCE_PROC_BRAND) >> true
        cpt4Call * procedureBrand.list(_ as QueryProperties) >> [ new ProcedureBrandVO(procedureBrandID: 123) ]
        hcpcsCall * procedureBrand.list(_ as QueryProperties) >> [ new ProcedureBrandVO(procedureBrandID: 123) ]
        0 * _

        where:
        testCase                              | procCodeType                          | hcpcsCall | cpt4Call
        HsrReferenceConstants.PROC_TYPE_CPT4  | HsrReferenceConstants.PROC_TYPE_CPT4  | 0         | 1
        HsrReferenceConstants.PROC_TYPE_HCPCS | HsrReferenceConstants.PROC_TYPE_HCPCS | 1         | 0
        'empty'                               | ''                                    | 0         | 0
    }

    def 'getRegimenDetail'(){
        given:
        QueryProperties qp = new QueryProperties()

        when:
        CommonResponse commonResponse = controller.getRegimenDetail(qp)

        then:
        1 * treatmentRegimenVersion.listAndCascade(qp) >> []
        1 * treatmentRegimenVersion.count(qp)
        0 * _

        and:
        ((List<TreatmentRegimenVersionVO>) commonResponse.embedded.get(CommonResponse.EMBEDDED)).isEmpty()
    }

    def 'getRegimenVersion'(){
        given:
        int treatmentRegimenVersionID = 1234
        TreatmentRegimenVersionVO vo = new TreatmentRegimenVersionVO(treatmentRegimenVersionID: treatmentRegimenVersionID)

        when:
        CommonResponse response = controller.getRegimenVersion(treatmentRegimenVersionID)

        then:
        1 * treatmentRegimenVersion.read(treatmentRegimenVersionID) >> vo
        1 * treatmentRegimenVersionProcedure.listByVersionID(vo.treatmentRegimenVersionID) >> []
        0 * _

        and:
        response.embedded.get(CommonResponse.EMBEDDED) == vo
    }

    def 'saveRegimenVersion'(){
        given:
        TreatmentRegimenVersionVO vo = new TreatmentRegimenVersionVO(treatmentRegimenVersionID: 1234)

        when:
        CommonResponse commonResponse = controller.saveRegimenVersion(vo)

        then:
        1 * treatmentRegimenVersion.saveCascading(vo)
        0 * _
    }

    def 'getRegimenProcedures'() {
        given:
        QueryProperties query = new QueryProperties(QueryProperties.FilterType.IS_FILTERING)
        List<RegimenProcedureViewVO> procedureViewVOList = [new RegimenProcedureViewVO()]

        when:
        CommonResponse commonResponse = controller.getRegimenProcedures(query)

        then:
        1 * regimenProcedureView.listDraftOrApproved(query) >> procedureViewVOList
        1 * regimenProcedureView.countDraftOrApproved(query) >> 1
        0 * _

        and:
        commonResponse.embedded.get(CommonResponse.EMBEDDED) == procedureViewVOList
    }

    def 'addReplaceProcedure'(){
        given:
        String oldProcCode = 'J9999'
        String newProcCode = 'J9999'
        String addOrReplace = '1'
        List<RegimenProcedureViewVO> voList = [new RegimenProcedureViewVO()]

        when:
        CommonResponse response = controller.addReplaceProcedure(oldProcCode, newProcCode, addOrReplace, voList)

        then:
        1 * regimenProcedureView.addNewProcedure(oldProcCode, newProcCode, voList, false)
        0 * _

        and:
        response.getEmbedded().get(CommonResponse.EMBEDDED) == voList.size()
    }

    def 'getRegimensByDiseaseType'() {
        given:
        String diseaseType = 'disease'
        List<TreatmentRegimenVO> regimenVOList = [new TreatmentRegimenVO(treatmentRegimenID: 1, treatmentRegimenName: 'test')]

        when:
        CommonResponse response = controller.getRegimensByDiseaseType(diseaseType)

        then:
        1 * treatmentRegimen.listRegimensByDiseaseType(diseaseType) >> regimenVOList
        0 * _

        and:
        response.embedded.get('_embedded') == regimenVOList
    }

    def 'addNewProcBrand'(){
        given:
        ReplaceProcedureCodeDO replaceProcedureCodeDO =  new ReplaceProcedureCodeDO(oldProcCode: 'J9999', newProcCode: 'J9999', addOrReplace : '1', oldProcBrandID: 1, newProcBrandID: 1,regimenProcedureViewVOList: [new RegimenProcedureViewVO()])

        when:
        CommonResponse response = controller.addReplaceProcedureBrand(replaceProcedureCodeDO)

        then:
        1 * regimenProcedureView.addNewProcBrand(replaceProcedureCodeDO)
        0 * _

        and:
        response.getEmbedded().get(CommonResponse.EMBEDDED) == replaceProcedureCodeDO.regimenProcedureViewVOList.size()
    }
}
