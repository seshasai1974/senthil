package com.optum.app.shared.workqueue.controller

import com.optum.app.shared.spclcare.SpecialtyCareReadLogicSpecification
import com.optum.app.shared.workqueue.businesslogic.impl.MbmWorkQueueSearchImpl
import com.optum.app.shared.workqueue.data.WorkQueueHelperDO
import com.optum.app.shared.workqueue.data.WorkQueueItemsDO
import com.optum.mbm.workqueue.data.v1.request.ItemTask
import com.optum.mbm.workqueue.data.v1.request.ItemTaskHistory
import com.optum.mbm.workqueue.data.v1.request.WorkQueue
import com.optum.mbm.workqueue.data.v2.response.ItemTaskCriteriaResponse
import com.optum.rf.common.featureflag.util.FeatureFlagManager
import com.optum.rf.common.featureflag.util.FeatureFlagUtility
import com.optum.rf.core.util.UhgCalendar
import com.optum.rf.dao.sql.query.QueryFilter
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.app.ocm.controller.support.CommonResponse
import com.optum.rf.dao.util.UhgCalendarUtilities

import java.sql.Timestamp

/**
 * Created by agudikan on 10/14/2019.
 */
class MbmWorkQueueSearchControllerSpec extends SpecialtyCareReadLogicSpecification{

    MbmWorkQueueSearchController mbmWorkQueueSearchController
    MbmWorkQueueSearchImpl mbmWorkQueueSearch
    FeatureFlagManager featureFlagManager

    def setup() {
        mbmWorkQueueSearchController = new MbmWorkQueueSearchController()
        mbmWorkQueueSearch = Mock(MbmWorkQueueSearchImpl)
        featureFlagManager = Mock(FeatureFlagManager)
        FeatureFlagUtility.featureFlagManager = featureFlagManager
        mbmWorkQueueSearchController.mbmWorkQueueSearch = mbmWorkQueueSearch
    }

    def 'getWorkQueueItems'(){
        given:
        QueryProperties query = new QueryProperties()
        query.addQueryFilter(new QueryFilter('owner', owner))
        query.addQueryFilter(new QueryFilter('workQueueId', workQueueId))
        query.addQueryFilter(new QueryFilter('assignmentDueDate', assignmentDueDate))
        ItemTaskCriteriaResponse itemTaskResponse = new ItemTaskCriteriaResponse(hscId: 123, itemTaskId: 123, workQueueId: 123, descriptionId: '1', assignmentTypeId: '04', owner: 'Test',
                assignmentDueDate: new Timestamp(new UhgCalendar().year - 1900, new UhgCalendar().month - 2, new UhgCalendar().day, 23, 59, 00, 00), createDateTime: new Timestamp(11, 0, 12, 0, 0, 0, 0))
        List<WorkQueueItemsDO> doList = [new WorkQueueItemsDO(itemTaskResponse: itemTaskResponse, authorizationType: '4', anticipatedStartDt: '2019-11-11', memberName: 'Test',
                policyGroup: '0908410', policyName: 'OXFORD HEALTH INSURANCE, INC.', insuranceType: '4', reviewPriority: '1', stateOfIssue: 'AR', stateOfResidence: 'NJ', stateOfService: 'OH',
                serviceReferenceNum: 'A003011288', providerName: 'HAZRA ANUPINDER', tatDueDate: new UhgCalendar(), tatExists: '0')]
        WorkQueueHelperDO helperDO = new WorkQueueHelperDO(doList: doList,totalRecordsCount: 1)

        when:
        CommonResponse response = mbmWorkQueueSearchController.getWorkQueueItems(query)

        then:
        1 * mbmWorkQueueSearch.getWorkQueueItems(query) >> helperDO
        0*_

        and:
        response.getEmbedded().get('_embedded') == helperDO.doList

        where:
        Sno | owner  | workQueueId | assignmentDueDate
        1   | ''     | 1234        | ''
        2   | 'test' | null        | '1'

    }

    def 'saveAssignment'(){
        given:
        ItemTask itemTask = new ItemTask(itemTaskId: 123,queueItemId: 123,typeId: '04',owner: 'SYSTEM', dueDate: new Timestamp(11,0,12,0,0,0,0), comment: 'test', assignDate: UhgCalendarUtilities.todaysDate,
                assigner: 'test',statusId: '123', outcomeId: '123',priorityTypeId: '01',workQueueId: 123,descriptionId: '01',createDateTime: new Timestamp(11,0,12,0,0,0,0), createUserId: 'SYSTEM')

        when:
        CommonResponse response = mbmWorkQueueSearchController.saveAssignment(itemTask)

        then:
        1 * featureFlagManager.isActive(_) >> false
        1 * mbmWorkQueueSearch.saveAssignment(_) >> itemTask
        0*_

        and:
        response.getEmbedded().get('_embedded') == itemTask
    }

    def 'getActiveWorkQueueList'(){
        given:
        QueryProperties query = new QueryProperties()
        query.addQueryFilter(new QueryFilter('fieldValue', fieldValue))
        List<WorkQueue> workQueueList = [new WorkQueue(workQueueId: 700,name: 'Test', description: 'test', status: 'Active'),
                                         new WorkQueue(workQueueId: 1004,name: 'Test1', description: 'test1', status: 'Active')]

        when:
        CommonResponse response = mbmWorkQueueSearchController.getActiveWorkQueueList(query)

        then:
        1 * mbmWorkQueueSearch.getActiveWorkQueueList(_) >> workQueueList
        0*_

        and:
        response.getEmbedded().get('_embedded') == workQueueList

        where:
        sno |   fieldValue
        1   |   ''
        2   |   '1'

    }

    def 'getAssignments'(){
        given:
        QueryProperties query = new QueryProperties()
        List<ItemTaskCriteriaResponse> assignmentList = [new ItemTaskCriteriaResponse(hscId: 123, itemTaskId: 123, workQueueId: 123, descriptionId: '1', assignmentTypeId: '04',
                owner: 'Test', assignmentDueDate: new Timestamp(new UhgCalendar().year - 1900, new UhgCalendar().month - 2, new UhgCalendar().day, 23, 59, 00, 00), createDateTime: new Timestamp(11, 0, 12, 0, 0, 0, 0),
                assignmentComments: 'test', statusId: '1', outcomeId: '1', priorityTypeId: '1', createUserId: 'SYSTEM', assignedTo: '100')]
        WorkQueueHelperDO helperDO = new WorkQueueHelperDO(assignmentList: assignmentList,totalRecordsCount: 1)

        when:
        CommonResponse response = mbmWorkQueueSearchController.getAssignments(query)

        then:
        1 * mbmWorkQueueSearch.getAssignments(query) >> helperDO
        0*_

        and:
        response.getEmbedded().get('_embedded') == helperDO.assignmentList
    }

    def 'getAssignmentHistory'(){
        given:
        QueryProperties query = new QueryProperties()
        long itemTaskId = 12345L
        List<ItemTaskHistory> historyList = [new ItemTaskHistory(itemTaskHistoryId: 1, itemTaskId: 123, fieldLabelId: '1', fromValue: '1', toValue: '2', changeUserId: 'Test', changedDateTime: new Timestamp(11,0,12,0,0,0,0))]
                        WorkQueueHelperDO helperDO = new WorkQueueHelperDO(assignmentHistoryList: historyList,totalRecordsCount: 1)

        when:
        CommonResponse response = mbmWorkQueueSearchController.getAssignmentHistory(itemTaskId,query)

        then:
        1 * mbmWorkQueueSearch.getAssignmentHistory(query,itemTaskId) >> helperDO
        0*_

        and:
        response.getEmbedded().get('_embedded') == helperDO.assignmentHistoryList
    }

    def 'saveItemTaskList'(){
        given:
        List<ItemTask> itemTaskList = [new ItemTask(itemTaskId: 123,queueItemId: 123,typeId: '04',owner: 'SYSTEM', dueDate: new Timestamp(11,0,12,0,0,0,0), comment: 'test', assignDate: UhgCalendarUtilities.todaysDate,
                assigner: 'test',statusId: '123', outcomeId: '123',priorityTypeId: '01',workQueueId: 123,descriptionId: '01',createDateTime: new Timestamp(11,0,12,0,0,0,0), createUserId: 'SYSTEM')]

        when:
        CommonResponse response = mbmWorkQueueSearchController.saveItemTaskList(itemTaskList)

        then:
        1 * featureFlagManager.isActive(_) >> false
        1 * mbmWorkQueueSearch.saveItemTaskList(_) >> itemTaskList
        0 * _

        and:
        response.getEmbedded().get('_embedded') == itemTaskList
    }
}
