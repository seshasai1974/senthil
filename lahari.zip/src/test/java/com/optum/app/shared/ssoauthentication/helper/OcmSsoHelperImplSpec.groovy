package com.optum.app.shared.ssoauthentication.helper

import com.optum.app.ocm.customer.businesslogic.CustomerSettingsView
import com.optum.app.ocm.customer.businesslogic.CustomerUser
import com.optum.app.ocm.ref.businesslogic.CustomerReference
import com.optum.app.shared.constants.MultiPayerConstants
import com.optum.app.shared.constants.SpclCareNonPersistedFieldConstants
import com.optum.app.shared.constants.SpclCareReferenceConstants
import com.optum.app.shared.planlookup.data.PlanLookupVO
import com.optum.app.shared.providergroup.businesslogic.ProviderGroup
import com.optum.app.shared.providergroup.data.ProviderGroupVO
import com.optum.app.shared.ssoauthentication.constants.SsoMbmConstants
import com.optum.app.shared.ssoauthentication.controller.SsoLoginController
import com.optum.app.shared.ssoauthentication.controller.mbm.MbmSsoController
import com.optum.app.shared.ssoauthentication.data.OcmSsoData
import com.optum.app.shared.ssoauthentication.data.OcmSsoProviderData
import com.optum.app.shared.ssoauthentication.helper.impl.OcmSsoHelperImpl
import com.optum.rf.common.featureflag.util.FeatureFlagManager
import com.optum.rf.common.featureflag.util.FeatureFlagUtility
import com.optum.rf.common.security.businesslogic.UserAddress
import com.optum.rf.common.security.data.UserAddressVO
import com.optum.rf.common.security.data.UserProfileVO
import com.optum.rf.common.settings.businesslogic.SystemSettingsPingFederatePartner
import com.optum.rf.common.settings.businesslogic.SystemSettingsWebService
import com.optum.rf.common.settings.data.SystemSettingsPingFederatePartnerVO
import com.optum.rf.common.settings.data.SystemSettingsWebServiceVO
import com.optum.rf.core.util.Environment
import com.optum.rf.dao.sql.query.QueryProperties
import com.uhg.app.common.customer.data.CustomerSettingsViewVO
import com.optum.app.common.customer.data.CustomerSettingsViewVO
import com.optum.app.common.customer.data.CustomerUserVO
import com.optum.app.ocm.common.security.businesslogic.AppUser
import com.optum.app.ocm.common.security.data.AppUserVO
import org.springframework.mock.web.MockHttpServletRequest
import spock.lang.Specification
import spock.lang.Unroll

/**
 * Created by jboyd34 on 10/10/18.
 */
class OcmSsoHelperImplSpec extends Specification {

    AppUser appUser
    OcmSsoHelper ocmSsoHelper
    CustomerReference customerReference = Mock(CustomerReference)
    SystemSettingsWebService systemSettingsWebService = Mock(SystemSettingsWebService)
    SystemSettingsPingFederatePartner systemSettingsPingFederatePartner = Mock(SystemSettingsPingFederatePartner)
    Environment environment = Mock(Environment)
    UserAddress userAddress = Mock(UserAddress)
    CustomerUser customerUser = Mock(CustomerUser)
    ProviderGroup providerGroup = Mock(ProviderGroup)
    CustomerSettingsView customerSettingsView = Mock(CustomerSettingsView)
    FeatureFlagManager featureFlagManager = Mock(FeatureFlagManager)

    def setup() {
        ocmSsoHelper = new OcmSsoHelperImpl()
        ocmSsoHelper.setUser(Mock(AppUser))
        ocmSsoHelper.setSystemSettingsWebService(Mock(SystemSettingsWebService))
        ocmSsoHelper.customerReference = customerReference
        ocmSsoHelper.systemSettingsWebService = systemSettingsWebService
        ocmSsoHelper.systemSettingsPingFederatePartner = systemSettingsPingFederatePartner
        ocmSsoHelper.environment = environment
        ocmSsoHelper.userAddress = userAddress
        ocmSsoHelper.customerUser = customerUser
        ocmSsoHelper.providerGroup = providerGroup
        ocmSsoHelper.customerSettingsView = customerSettingsView
        FeatureFlagUtility.featureFlagManager = featureFlagManager
    }

    def "create UserDetails from SSO test empty string first/last name"() {
        given:
        OcmSsoData ocmSsoData = new OcmSsoData()
        ocmSsoData.setUserFName("")
        ocmSsoData.setUserLName("")
        ocmSsoData.setUuid(UUID.randomUUID().toString())
        ocmSsoData.setHscID("null")

        when:
        appUser.read(_) >> null
        AppUserVO userVO = ocmSsoHelper.createUserDetailsFromSSO(ocmSsoData)

        then:
        userVO.getFirstName() == "PROVIDER"
        userVO.getLastName() == "PROVIDER"
        userVO.getLastLoginDate().toLocalDate() == new java.sql.Date(System.currentTimeMillis()).toLocalDate()

    }

    def "create UserDetails from SSO test null first/last name"() {
        given:
        OcmSsoData ocmSsoData = new OcmSsoData()
        ocmSsoData.setUuid(UUID.randomUUID().toString())
        ocmSsoData.setHscID("null")

        when:
        AppUserVO userVO = ocmSsoHelper.createUserDetailsFromSSO(ocmSsoData)

        then:
        userVO.getFirstName() == "PROVIDER"
        userVO.getLastName() == "PROVIDER"
        userVO.getLastLoginDate().toLocalDate() == new java.sql.Date(System.currentTimeMillis()).toLocalDate()

    }

    def "create UserDetails from SSO test empty string first"() {
        given:
        OcmSsoData ocmSsoData = new OcmSsoData()

        ocmSsoData.setUserFName("")
        ocmSsoData.setUserLName(null)
        ocmSsoData.setUuid(UUID.randomUUID().toString())
        ocmSsoData.setHscID("null")

        when:
        AppUserVO userVO = ocmSsoHelper.createUserDetailsFromSSO(ocmSsoData)

        then:
        userVO.getFirstName() == "PROVIDER"
        userVO.getLastName() == "PROVIDER"
        userVO.getLastLoginDate().toLocalDate() == new java.sql.Date(System.currentTimeMillis()).toLocalDate()

    }

    def "create UserDetails from SSO test empty string last name"() {
        given:
        OcmSsoData ocmSsoData = new OcmSsoData()

        ocmSsoData.setUserFName(null)
        ocmSsoData.setUserLName("")
        ocmSsoData.setUuid(UUID.randomUUID().toString())
        ocmSsoData.setHscID("null")

        when:
        AppUserVO userVO = ocmSsoHelper.createUserDetailsFromSSO(ocmSsoData)

        then:
        userVO.getFirstName() == "PROVIDER"
        userVO.getLastName() == "PROVIDER"
        userVO.getLastLoginDate().toLocalDate() == new java.sql.Date(System.currentTimeMillis()).toLocalDate()
    }

    @Unroll
    def "test checkBriovaUserTIN #testCase"() {
        given:
        String federalTaxID = '1234'

        when:
        customerReference.isValid(SpclCareNonPersistedFieldConstants.BRIOVA_TIN, federalTaxID) >> isValid
        ocmSsoHelper.checkBriovaUserTIN(federalTaxID)

        then:
        0*_

        where:
        testcase | isValid
         0       | false
         1       | true
    }

    @Unroll
    def "Mbm buildUserProfileVO #testCase"() {
        given:
        UserProfileVO userProfileVO
        MbmSsoController mbmSsoController = new MbmSsoController()

        when:
        userProfileVO = ocmSsoHelper.buildUserProfileVO(mbmSsoController.buildSsoData(mbmSsoData))

        then:
        userProfileVO.getLastName()== 'Josh'
        userProfileVO.getUserGroupID() == SsoMbmConstants.PROVIDER

        where:
        testCase           | mbmSsoData
        'Expected outcome' | [userID: null, userFName: 'Dan', userLName: 'Josh', userEmail: 'test.Email@optum.com', isSuperUser: false]
    }

    @Unroll
    def "Mbm useAmazonS3ToParseSsoAttributesFromSAMLorHardcodeForLocalHost #testCase"() {
        given:
        Map attributes

        when:
        attributes = ocmSsoHelper.useAmazonS3ToParseSsoAttributesFromSAMLorHardcodeForLocalHost(Mock(MockHttpServletRequest))

        then:
        systemSettingsWebService.read(_) >> new SystemSettingsWebServiceVO(wsUrl: "wsUrl")
        systemSettingsPingFederatePartner.read(_) >> new SystemSettingsPingFederatePartnerVO(pingFederateConfigFileName: "file",pingFederatePartnerID: "ptId",pingFederateUrl: "pingFed",pingFederateTargetUrl: "target")
        environment.getEnvironment() >> Environment.Env.LOCAL

        and:
        attributes.get('userID')

        where:
        testCase           | userID  | map
        'Expected outcome' | 'db123' | [userID: null, userFName: 'Dan', userLName: 'Josh', userEmail: 'test.Email@optum.com', isSuperUser: false]
    }

    @Unroll
    def "MIM createUserDetailsFromSSO #testCase"() {
        given:
        MbmSsoController mbmSsoController = new MbmSsoController()

        when:
        AppUserVO userVO = ocmSsoHelper.createUserDetailsFromSSO(mbmSsoController.buildSsoData(map))

        then:
        appUser.read(_ as String) >> userData

        and:
        userVO?.getFirstName() == firstName
        userVO?.getLastName() == lastName
        userVO?.getLastLoginDate()?.toLocalDate() == dateObj

        where:
        testCase                           | dateObj                                                     | lastName | firstName | userData        | map
        'Expected outcome update - MIM'    | new java.sql.Date(System.currentTimeMillis()).toLocalDate() | 'Josh'   | 'Dan'     | new AppUserVO() | [applicationName: 'MIM', userID: 'db123', userFName: 'Dan', userLName: 'Josh', userEmail: 'test.Email@optum.com', isSuperUser: false]
        'Expected outcome provision - MIM' | new java.sql.Date(System.currentTimeMillis()).toLocalDate() | 'Josh'   | 'Dan'     | null            | [applicationName: 'MIM', userID: 'db123', userFName: 'Dan', userLName: 'Josh', userEmail: 'test.Email@optum.com', isSuperUser: false]
        'No Application Name'              | null                                                        | null     | null      | new AppUserVO() | [userID: 'db123', userFName: 'Dan', userLName: 'Josh', userEmail: 'test.Email@optum.com', isSuperUser: false]
        'No userID Name'                   | null                                                        | null     | null      | new AppUserVO() | [applicationName: 'MIM', userFName: 'Dan', userLName: 'Josh', userEmail: 'test.Email@optum.com', isSuperUser: false]

    }

    @Unroll
    def "PAAN createUserDetailsFromSSO #testCase"() {
        given:
        SsoLoginController ssoController = new SsoLoginController()

        when:
        AppUserVO userVO = ocmSsoHelper.createUserDetailsFromSSO(ssoController.buildSsoData(map))

        then:
        appUser.read(_ as String) >> userData

        and:
        userVO?.getFirstName() == firstName
        userVO?.getLastName() == lastName
        userVO?.getLastLoginDate()?.toLocalDate() == dateObj

        where:
        testCase                            | dateObj                                                     | lastName | firstName | userData        | map
        'Expected outcome update - PAAN'    | new java.sql.Date(System.currentTimeMillis()).toLocalDate() | 'Josh'   | 'Dan'     | new AppUserVO() | [applicationName: 'PAAN', uuid: '16def776-f11e-48d8-9f73-64769d7e8b42', userID: '', userFName: 'Dan', userLName: 'Josh', providerFName: '', providerMPIN: '12345678', providerNPI: '[12345678]', hscID: 'null', userEmail: 'test.Email@optum.com', isSuperUser: false]
        'Expected outcome provision - PAAN' | new java.sql.Date(System.currentTimeMillis()).toLocalDate() | 'Josh'   | 'Dan'     | null            | [applicationName: 'PAAN', uuid: '16def776-f11e-48d8-9f73-64769d7e8b42', userID: '', userFName: 'Dan', userLName: 'Josh', providerFName: '', providerMPIN: '12345678', providerNPI: '[12345678]', hscID: 'null', userEmail: 'test.Email@optum.com', isSuperUser: false]
        'InvalidUUID - PAAN'                | null                                                        | null     | null      | null            | [applicationName: 'PAAN', uuid: 'invalid uuid', userID: '', userFName: 'Dan', userLName: 'Josh', providerFName: '', providerMPIN: '12345678', providerNPI: '[12345678]', hscID: '', userEmail: 'test.Email@optum.com', isSuperUser: false]
        'hscID empty - PAAN'                | null                                                        | null     | null      | null            | [applicationName: 'PAAN', uuid: '16def776-f11e-48d8-9f73-64769d7e8b42', userID: '', userFName: 'Dan', userLName: 'Josh', providerFName: '', providerMPIN: '12345678', providerNPI: '[12345678]', hscID: '', userEmail: 'test.Email@optum.com', isSuperUser: false]
        'No User Found'                     | null                                                        | null     | null      | null            | [applicationName: 'PAAN', uuid: '16def776-f11e-48d8-9f73-64769d7e8b42', userID: '', userFName: 'Dan', userLName: 'Josh', providerFName: '', providerMPIN: '12345678', providerNPI: '[12345678]', hscID: '', userEmail: 'test.Email@optum.com', isSuperUser: false]

    }

    @Unroll
    def "ICUE createUserDetailsFromSSO #testCase"() {
        given:
        SsoLoginController ssoController = new SsoLoginController()

        when:
        AppUserVO userVO = ocmSsoHelper.createUserDetailsFromSSO(ssoController.buildSsoData(map))

        then:
        appUser.read(_ as String) >> userData

        and:
        userVO?.userID == userID
        userVO?.userGroupID == userGroupID
        userVO?.getLastLoginDate()?.toLocalDate() == dateObj

        where:
        testCase                            | dateObj                                                     | userID  | userGroupID | userData        | map
        'Expected outcome update - ICUE'    | new java.sql.Date(System.currentTimeMillis()).toLocalDate() | 'db123' | 'ICUE USER' | new AppUserVO() | [userID: 'db123', userFName: 'Dan', userLName: 'Josh', hscID: '12345']
        'Expected outcome provision - ICUE' | new java.sql.Date(System.currentTimeMillis()).toLocalDate() | 'db123' | 'ICUE USER' | null            | [userID: 'db123', userFName: 'Dan', userLName: 'Josh', hscID: '12345']
        'hscID empty - ICUE'                | null                                                        | null    | null        | null            | [userID: 'db123', userFName: 'Dan', userLName: 'Josh']

    }


    @Unroll
    def "Mbm createUserAddressFromSSO #testCase"() {
        given:
        OcmSsoData mbmSsoData = new OcmSsoData()
        mbmSsoData.setUserID('db123')
        mbmSsoData.setProviderData(new OcmSsoProviderData(providerAddress1: '123 starmount Dr'))

        when:
        UserAddressVO userAddressVO = ocmSsoHelper.createUserAddressFromSSO(mbmSsoData)

        then:
        userAddress.read(_, _) >> userAddressData

        and:
        userAddressVO.getAddress1() == "123 starmount Dr"

        where:
        testCase           | userAddressData
        'Expected outcome' | new UserAddressVO(address1: '123 starmount Dr')
        'No User Found'    | null
    }

    @Unroll
    def "Mbm createUserCustomerFromSSO #testCase"() {
        given:
        System.setProperty(MultiPayerConstants.APPROVAL_TYPE , customer)
        System.setProperty(MultiPayerConstants.PAYER , payer)
        OcmSsoData mbmSsoData = new OcmSsoData()
        mbmSsoData.setUserID('db123')
        mbmSsoData.setProviderData(new OcmSsoProviderData(providerAddress1: '123 starmount Dr'))
        boolean featureFlag = false

        when:
        ocmSsoHelper.createUserCustomerFromSSO(mbmSsoData)

        then:
        customerUser.read(_, _) >> userCustomerData
        1 * featureFlagManager.isActive(_) >> featureFlag

        where:
        testCase                                  | customer | payer    | userCustomerData
        'UHC - Expected outcome, first login'     | '1'      | 'UHC'    | null
        'UHC - Expected outcome, second login'    | '1'      | 'UHC'    | new CustomerUserVO(userID: 'db123')
        'BCBSSC - Expected outcome'               | '2'      | 'BCBSSC' | null
        'BCBSSC - Expected outcome, second login' | '2'      | 'BCBSSC' | new CustomerUserVO(userID: 'db123')
        'No User Found'                           | '89'     | ''       | null
    }

    @Unroll
    def "Mbm createUserCustomerFromSSO with LS and CDOs #testCase"() {
        given:
        System.setProperty(MultiPayerConstants.APPROVAL_TYPE , customer)
        System.setProperty(MultiPayerConstants.PAYER , payer)
        OcmSsoData mbmSsoData = new OcmSsoData()
        mbmSsoData.setUserID('db123')
        mbmSsoData.setApplicationName(appName)
        mbmSsoData.setProviderData(new OcmSsoProviderData(providerAddress1: '123 starmount Dr'))
        boolean featureFlag = true
        CustomerSettingsViewVO customerSettingsViewVO = new CustomerSettingsViewVO(customerID: 1,customerSetTypeID: '1', settingValue: 'PAAN;ICUE', customerName: 'UHC')
        List<CustomerSettingsViewVO> customerSettingsViewVOList = [new CustomerSettingsViewVO(customerID: 2,customerSetTypeID: '1', settingValue: 'LINK', customerName: 'OC-OMN-AZ')]
        List<CustomerSettingsViewVO> customerIDsList = [new CustomerSettingsViewVO(customerID: 3,customerSetTypeID: '2', settingValue: 'OMN-AZ', customerName: 'OC-OMN-AZ'),
                                                        new CustomerSettingsViewVO(customerID: 4,customerSetTypeID: '2', settingValue: 'OMN-NV/SMA', customerName: 'OC-SMA')]
        List<String> CDOs = ['OMN-AZ','OMN-NV/SMA']
        mbmSsoData.customers = CDOs

        when:
        ocmSsoHelper.createUserCustomerFromSSO(mbmSsoData)

        then:
        customerUser.read(_, _) >> userCustomerData
        1 * featureFlagManager.isActive(_) >> featureFlag
        a * customerSettingsView.readByTypeIDAndSettingVal('1', appName) >> customerSettingsViewVO
        b * customerSettingsView.readListByTypeIDAndSettingVal(SpclCareReferenceConstants.CUSTOMER_SET_TYPE_SSO_SOURCE_APPS, appName) >> customerSettingsViewVOList
        b * customerUser.deleteCustUsersList(_,_)
        b * customerSettingsView.getCustIDList(SpclCareReferenceConstants.CUSTOMER_SET_TYPE_SSO_SOURCE_ID, CDOs) >> customerIDsList
        c * customerUser.add(_)
        d * customerUser.update(_)
        1 * customerUser.listByUserID(_)
        0 * _

        where:
        testCase                                  | customer | appName       | payer    |   a    |   b    |   c    |   d    | userCustomerData
        'UHC - Expected outcome, first login'     | '1'      | 'PAAN;ICUE'   | 'UHC'    |   1    |   0    |   2    |   0    | null
        'UHC - Expected outcome, second login'    | '1'      | 'PAAN;ICUE'   | 'UHC'    |   1    |   0    |   0    |   1    | new CustomerUserVO(userID: 'db123')
        'BCBSSC - Expected outcome'               | '2'      | 'MIM'         | 'BCBSSC' |   1    |   0    |   2    |   0    | null
        'BCBSSC - Expected outcome, second login' | '2'      | 'MIM'         | 'BCBSSC' |   1    |   0    |   0    |   1    | new CustomerUserVO(userID: 'db123')
        'LINK - Expected outcome'                 | '3'      | 'LinkSecurity'| 'LINK'   |   0    |   1    |   2    |   0    | new CustomerUserVO(userID: 'db123')
        'No User Found'                           | '89'     | 'PAAN;ICUE'   |   ''     |   1    |   0    |   2    |   0    | null
    }


    def "test checkLimitedSupplierTIN #testCase"() {
        given:
        String federalTaxID = '1234'
        String providerGroupName = 'MSE'
        when:
        ocmSsoHelper.checkLimitedSupplierTIN(federalTaxID, providerGroupName)

        then:
        1 * providerGroup.findByProviderTinAndGroupName(federalTaxID, providerGroupName) >> new ProviderGroupVO()
    }

}
