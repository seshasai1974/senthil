package com.optum.app.shared.whitelabel

import com.optum.app.common.organization.data.OrganizationVO
import com.optum.app.ocm.customer.businesslogic.Customer
import com.optum.app.ocm.organization.businesslogic.Organization
import com.optum.app.shared.authorization.businesslogic.Authorizations
import com.optum.app.shared.common.controller.advice.BadRequestException
import com.optum.app.shared.whitelabel.dto.CustomerWhiteLabelsDto
import com.optum.rf.dao.exception.UhgRuntimeException
import spock.lang.Specification

class WhiteLabelSpec extends Specification implements WhiteLabelTestData {
    // Mocks dependencies external to the current module.
    def customer = Mock(Customer)
    def authorizations = Mock(Authorizations)
    def organization = Mock(Organization)
    def customerWhiteLabelsSubmodule = Mock(CustomerWLSubmodule)
    def forbiddenWordsSubmodule = Mock(ForbiddenWordsSubmodule)
    // Subject Under Test. Instantiating here ensures we restart internal state in each test
    def whiteLabel = new WhiteLabelConfiguration().whiteLabel(
            authorizations,
            customer,
            organization,
            customerWhiteLabelsSubmodule,
            forbiddenWordsSubmodule
    )

    def 'Success: consume whiteLabels'() {
        given:
        def savedCustomerVO = newCustomerVO(1)

        when: "read whiteLabels success"
        CustomerWhiteLabelsDto response = whiteLabel.customerWhiteLabels(savedCustomerVO.customerID)

        then:
        noExceptionThrown()
        assert response != null
        1 * authorizations.validateCustomer(_)
        1 * customer.read(savedCustomerVO.customerID) >> savedCustomerVO
        1 * organization.read(0) >> new OrganizationVO(organizationShortName: "org-0")
        forbiddenWordsSubmodule.getMergedForbiddenWords(savedCustomerVO.customerName, "org-0") >> forbiddenWords()
        customerWhiteLabelsSubmodule.getMergedCustomerWhiteLabels(savedCustomerVO.customerName, "org-0") >>> toOptionalJson(validWhiteLabels)

        where:
        _ | validWhiteLabels
        _ | '{ "newLineIsNotAWordSeparator": "not a forbiddenWord\\nhere" }'
        _ | '{ "newLineIsNotAWordSeparator": "not a forbiddenWord\\nhere" }'
        _ | '{"nested": { "partialMatchesWontInvalidateTheText": " NOTforbiddenWord" } }'
        _ | '{"array": ["aValue", "forbiddenWordNOT"] }'
        _ | '{"numeric": 123 }'
    }

    def 'Failure to save customer level whiteLabels (internal)'() {
        when: 'save'
        whiteLabel.customerWhiteLabelsMaintenance.saveWLCustomerLevelValues(input)

        then:
        thrown(exception)
        auths * authorizations.validateCustomer(input?.customerId)
        reads * customer.read(input?.customerId) >> customerVO
        organization.read(0) >> new OrganizationVO(organizationShortName: "org-0")
        forbiddenWordsSubmodule.getMergedForbiddenWords(customerVO?.customerName, "org-0") >> forbiddenWords()

        where:
        auths | reads | exception                | customerVO                  | input
        0     | 0     | NullPointerException           | newCustomerVO(1) | null
        0     | 0     | NullPointerException           | newCustomerVO(1) | new CustomerWhiteLabelsDto()
        0     | 0     | NullPointerException           | newCustomerVO(1) | newCustomerWhiteLabelsDto(null, "{}")
        0     | 0     | NullPointerException           | newCustomerVO(1) | newCustomerWhiteLabelsDto(1, null)
        1     | 1     | IllegalArgumentException | newCustomerVO(1) | newCustomerWhiteLabelsDto(1, "[]")
        1     | 1     | IllegalArgumentException | newCustomerVO(1) | newCustomerWhiteLabelsDto(1, '"Hello"')
        1     | 1     | IllegalArgumentException | newCustomerVO(1) | newCustomerWhiteLabelsDto(1, '"1"')
        1     | 1     | BadRequestException      | null                        | newCustomerWhiteLabelsDto(1, '{}')
    }

    def 'Failure to consume whiteLabel configuration (internal)'() {
        when:
        whiteLabel.customerWhiteLabels(customerVO?.customerID)

        then:
        thrown(exception)
        auths * authorizations.validateCustomer(customerVO?.customerID)
        reads * customer.read(customerVO?.customerID) >> customerVO
        reads * organization.read(0) >> new OrganizationVO(organizationShortName: "org-0")
        customerWhiteLabelsSubmodule.getMergedCustomerWhiteLabels(customerVO?.customerName, "org-0") >> Optional.empty()

        where:
        auths | reads| customerVO                  | exception
        1     | 1    | newCustomerVO(1) | UhgRuntimeException
        0     | 0    | null                        | NullPointerException
    }

    def 'External Customer Failures (null) - read whiteLabels'() {
        given:
        def customerID = 1

        when:
        whiteLabel.customerWhiteLabels(customerID)

        then:
        thrown(BadRequestException)
        1 * customer.read(customerID) >> null
    }

    def "Success: whiteLabel organization Level maintenance"() {
        given:
        def customerVO = newCustomerVO(1)
        def customerModel = toCustomerModel(customerVO)

        when:
        whiteLabel.customerWhiteLabelsMaintenance.saveWLOrganizationLevelValues(toCustomerDto(customerVO))

        then:
        1 * authorizations.validateCustomer(customerVO.customerID)
        1 * customer.read(customerVO.customerID) >> customerVO
        1 * organization.read(0) >> new OrganizationVO(organizationShortName: customerModel.organizationName)
        forbiddenWordsSubmodule.getMergedForbiddenWords(customerModel.customerName, customerModel.organizationName) >> forbiddenWords()

        when:
        def getResult = whiteLabel.customerWhiteLabelsMaintenance.getWLOrganizationValues(customerModel.customerId)

        then:
        noExceptionThrown()
        getResult != null
        1 * authorizations.validateCustomer(customerVO.customerID)
        1 * customer.read(customerVO.customerID) >> customerVO
        1 * organization.read(0) >> new OrganizationVO(organizationShortName: customerModel.organizationName)
        1 * customerWhiteLabelsSubmodule.getWLOrganizationLevelValues(customerModel.organizationName) >> toOptionalJson('{}').get()


        when:
        def namesResult = whiteLabel.customerWhiteLabelsMaintenance.getOrganizationNamesWithOrganizationLevelValues()

        then:
        noExceptionThrown()
        namesResult == [customerModel.organizationName] as Set
        1 * customerWhiteLabelsSubmodule.getOrganizationNamesWithOrganizationLevelValues() >> [customerModel.organizationName]
    }

    def 'Success Unsafe read whitelabels'() {

        given:
        def savedCustomerVO = newCustomerVO(1)

        when: "read whiteLabels success"
        CustomerWhiteLabelsDto response = whiteLabel.unsafeCustomerWhiteLabels(savedCustomerVO.customerID)

        then:
        noExceptionThrown()
        assert response != null
        0 * authorizations.validateCustomer(savedCustomerVO.customerID)
        1 * customer.read(savedCustomerVO.customerID) >> newCustomerVO(savedCustomerVO.customerID)
        1 * organization.read(0) >> new OrganizationVO(organizationShortName: "org-0")
        forbiddenWordsSubmodule.getMergedForbiddenWords(savedCustomerVO.customerName, "org-0") >> forbiddenWords()
        customerWhiteLabelsSubmodule.getMergedCustomerWhiteLabels(savedCustomerVO.customerName, "org-0") >>> toOptionalJson(validWhiteLabels)

        where:
        _ | validWhiteLabels
        _ | '{ "newLineIsNotAWordSeparator": "not a forbiddenWord\\nhere" }'
        _ | '{ "newLineIsNotAWordSeparator": "not a forbiddenWord\\nhere" }'
        _ | '{"nested": { "partialMatchesWontInvalidateTheText": " NOTforbiddenWord" } }'
        _ | '{"array": ["aValue", "forbiddenWordNOT"] }'

    }
}
