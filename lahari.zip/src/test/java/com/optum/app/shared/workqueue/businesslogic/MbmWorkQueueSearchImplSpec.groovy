package com.optum.app.shared.workqueue.businesslogic

import com.optum.app.ocm.ref.businesslogic.CustomerReference
import com.optum.app.shared.constants.SpclCareFeatureFlagConstants
import com.optum.app.shared.constants.SpclCareReferenceConstants
import com.optum.app.shared.procedure.businesslogic.ProcedureView
import com.optum.app.shared.specialtyPharmacy.businesslogic.SpecialtyProceduresView
import com.optum.app.shared.workqueue.businesslogic.impl.MbmWorkQueueSearchImpl
import com.optum.app.shared.workqueue.data.RestConstants
import com.optum.app.shared.workqueue.data.WorkQueueHelperDO
import com.optum.app.shared.workqueue.data.WorkQueueViewVO
import com.optum.app.shared.workqueue.mapper.MbmWorkQueueSearchRequestMapper
import com.optum.mbm.workqueue.data.v1.request.ItemTask
import com.optum.mbm.workqueue.data.v1.request.ItemTaskHistory
import com.optum.mbm.workqueue.data.v1.request.WorkQueue
import com.optum.mbm.workqueue.data.v2.response.ItemTaskCriteriaResponse
import com.optum.rf.common.featureflag.util.FeatureFlagManager
import com.optum.rf.common.featureflag.util.FeatureFlagUtility
import com.optum.rf.common.settings.data.SystemSettingsWebServiceVO
import com.optum.rf.common.webservice.logging.businesslogic.WebServiceLog
import com.optum.rf.core.util.GenericUtilities
import com.optum.rf.core.util.UhgCalendar
import com.optum.rf.dao.controller.session.SessionThreadLocal
import com.optum.rf.dao.sql.query.QueryFilter
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.rf.dao.util.UhgCalendarUtilities
import com.optum.rf.web.controller.session.HttpUserSession
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.dao.StoredProcProperties
import com.optum.app.ocm.common.security.businesslogic.AppUser
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.client.RestTemplate
import spock.lang.Specification
import spock.lang.Unroll

import java.sql.Timestamp
import java.text.DateFormat
import java.text.SimpleDateFormat

/**
 * Created by agudikan on 8/26/2019.
 */
class MbmWorkQueueSearchImplSpec extends Specification {

    MbmWorkQueueSearchImpl mbmWorkQueueSearchImpl
    MbmWorkQueueSearchRequestMapper queueSearchRequestMapper
    WorkQueueView workQueueView
    CustomerReference customerReference
    AppUser appUser
    RestTemplate restTemplate
    SpecialtyProceduresView specialtyProceduresView
    ProcedureView procedureView
    FeatureFlagManager featureFlagManager
    SystemSettingsWebServiceVO systemSettingsWebServiceVO = new SystemSettingsWebServiceVO(wsUrl: 'https://myurl.optum.com/test')
    WorkQueueHelperDO workQueueHelperDO
    final String timeZone = 'UTC'
    WebServiceLog webServiceLog

    def setup() {
        workQueueHelperDO = Mock(WorkQueueHelperDO)
        customerReference = Mock(CustomerReference)
        workQueueView = Mock(WorkQueueView)
        webServiceLog = Mock(WebServiceLog)
        queueSearchRequestMapper = Mock(MbmWorkQueueSearchRequestMapper)
        restTemplate = Mock(RestTemplate)
        specialtyProceduresView = Mock(SpecialtyProceduresView)
        procedureView = Mock(ProcedureView)
        featureFlagManager = Mock(FeatureFlagManager)
        appUser = Mock(AppUser)
        mbmWorkQueueSearchImpl = new MbmWorkQueueSearchImpl()
        mbmWorkQueueSearchImpl.queueSearchRequestMapper = queueSearchRequestMapper
        mbmWorkQueueSearchImpl.customerReference = customerReference
        mbmWorkQueueSearchImpl.appUser = appUser
        mbmWorkQueueSearchImpl.specialtyProceduresView = specialtyProceduresView
        mbmWorkQueueSearchImpl.procedureView = procedureView
        FeatureFlagUtility.featureFlagManager = featureFlagManager
        mbmWorkQueueSearchImpl.workQueueView = workQueueView
        mbmWorkQueueSearchImpl.webServiceLog = webServiceLog
        mbmWorkQueueSearchImpl.restTemplate = restTemplate

        TimeZone.setDefault(TimeZone.getTimeZone(timeZone))
        SessionThreadLocal.setSession(new HttpUserSession())
    }

    @Unroll
    def 'getWorkQueueItems'() {
        given:
        QueryProperties query = new QueryProperties()
        query.addQueryFilter(new QueryFilter('owner', owner))
        query.addQueryFilter(new QueryFilter('workQueueId', workQueueId))
        query.addQueryFilter(new QueryFilter('assignmentDueDate', assignmentDueDate))
        query.addQueryFilter(new QueryFilter('timeZoneID', 'Asia/Calcutta'))
        query.setOrderByAscFields('tatDueDate')
        query.setResultSize(1)
        List<ItemTaskCriteriaResponse> workQueueItemsList = [new ItemTaskCriteriaResponse(hscId: 123, itemTaskId: 123, workQueueId: 123, descriptionId: '1', assignmentTypeId: '04',
                owner: 'Test', assignmentDueDate: asgnDueDt, createDateTime: new Timestamp(11, 0, 12, 0, 0, 0, 0),
                assignmentComments: 'test', statusId: '1', outcomeId: '1', priorityTypeId: '1', createUserId: 'SYSTEM', assignedTo: '100'),
                                                             new ItemTaskCriteriaResponse(hscId: 1234, itemTaskId: 123, workQueueId: 123, descriptionId: '1', assignmentTypeId: '04',
                                                                     owner: 'Test', assignmentDueDate: asgnDueDt, createDateTime: new Timestamp(11, 0, 12, 0, 0, 0, 0),
                                                                     assignmentComments: 'test', statusId: '1', outcomeId: '1', priorityTypeId: '1', createUserId: 'SYSTEM', assignedTo: '100'),
                                                             new ItemTaskCriteriaResponse(hscId: 1234, itemTaskId: 123, workQueueId: 123, descriptionId: '1', assignmentTypeId: '04',
                                                                     owner: 'Test', assignmentDueDate: asgnDueDt, createDateTime: new Timestamp(11, 0, 12, 0, 0, 0, 0),
                                                                     assignmentComments: '', statusId: '1', outcomeId: '1', priorityTypeId: '1', createUserId: 'SYSTEM', assignedTo: '100')]
        List<WorkQueueViewVO> workQueueViewVOs = [new WorkQueueViewVO(hscId: 123, authorizationType: authorizationType, cancerType: '12', anticipatedStartDt: '2019-11-11', memberName: 'Test',
                policyGroup: '0908410', policyName: 'OXFORD HEALTH INSURANCE, INC.', insuranceType: '4', reviewPriority: '1', stateOfIssue: 'AR', stateOfResidence: 'NJ', stateOfService: 'OH',
                serviceReferenceNum: 'A003011288', providerName: 'HAZRA ANUPINDER', tatDueDate: tatDueDate, tatExists: tatExists, submittedDate: '9999-01-01'),
                                                  new WorkQueueViewVO(hscId: 1234, authorizationType: authorizationType, cancerType: '12', anticipatedStartDt: '2019-11-11', memberName: 'Test',
                                                          policyGroup: '0908410', policyName: 'OXFORD HEALTH INSURANCE, INC.', insuranceType: '4', reviewPriority: '1', stateOfIssue: 'AR', stateOfResidence: 'NJ', stateOfService: 'OH',
                                                          serviceReferenceNum: 'A003011288', providerName: 'HAZRA ANUPINDER', tatDueDate: tatDueDate, tatExists: tatExists, submittedDate: '9999-01-01'),
                                                  new WorkQueueViewVO(hscId: 123, authorizationType: "", cancerType: '12', anticipatedStartDt: '2019-11-11', memberName: '',
                                                          policyGroup: '', policyName: '', insuranceType: '', reviewPriority: '', stateOfIssue: '', stateOfResidence: '', stateOfService: '',
                                                          serviceReferenceNum: '', providerName: '', tatDueDate: tatDueDate, tatExists: tatExists, submittedDate: null)]

        when:
        mbmWorkQueueSearchImpl.getWorkQueueItems(query)

        then:
        1 * restTemplate.exchange(_, _, _, _) >> new ResponseEntity<List<ItemTaskCriteriaResponse>>(workQueueItemsList, HttpStatus.OK)
        1 * queueSearchRequestMapper.getSystemSettingsWebServiceVO() >> systemSettingsWebServiceVO
        1 * queueSearchRequestMapper.setWorkQueueSearchRestTemplateTimeout(restTemplate)
        1 * queueSearchRequestMapper.buildHttpHeader()
        1 * workQueueView.callStoredProcedure(_,_) >> workQueueViewVOs
        1 * webServiceLog.addNewTransaction(_)
        _ * specialtyProceduresView.list(_)
        y * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_PROC_BRAND_REFACTOR) >> false
        z * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_PROC_BRAND_REFACTOR) >> true
        a * procedureView.readByHscID(_)
        0 * _

        where:
        Sno | owner  | workQueueId | authorizationType | tatDueDate                    | tatExists | assignmentDueDate | x  | y | z | a | asgnDueDt
        1   | ''     | 1234        | '4'               | new UhgCalendar()             | '0'       | ''                | 1  | 1 | 0 | 0 | new Timestamp(new UhgCalendar().year - 1900, new UhgCalendar().month - 2, new UhgCalendar().day, 23, 59, 00, 00)
        2   | 'test' | null        | '4'               | new UhgCalendar()             | '0'       | '1'               | 1  | 1 | 0 | 0 | new Timestamp(new UhgCalendar().year - 1900, new UhgCalendar().month - 2, new UhgCalendar().day, 23, 59, 00, 00)
        3   | 'test' | null        | '4'               | new UhgCalendar()             | '0'       | '2'               | 1  | 1 | 0 | 0 | new Timestamp(new UhgCalendar().year - 1900, new UhgCalendar().month - 1, new UhgCalendar().day, 05, 59, 00, 00)
        4   | 'test' | null        | '4'               | new UhgCalendar()             | '0'       | '3'               | 1  | 1 | 0 | 0 | new Timestamp(new UhgCalendar().year - 1900, new UhgCalendar().month - 1, new UhgCalendar().day + 1, 05, 59, 00, 00)
        5   | 'test' | null        | '4'               | new UhgCalendar()             | '0'       | '4'               | 1  | 1 | 0 | 0 | new Timestamp(new UhgCalendar().year - 1900, new UhgCalendar().month - 1, new UhgCalendar().day + 2, 23, 59, 00, 00)
        6   | 'test' | null        | '1'               | null                          | '1'       | ''                | 1  | 1 | 0 | 0 | new Timestamp(new UhgCalendar().year - 1900, new UhgCalendar().month - 1, new UhgCalendar().day, 23, 59, 00, 00)
        7   | ''     | 1234        | '4'               | new UhgCalendar(2028, 12, 12) | '0'       | ''                | 1  | 1 | 0 | 0 | new Timestamp(new UhgCalendar().year - 1900, new UhgCalendar().month - 2, new UhgCalendar().day, 23, 59, 00, 00)
        8   | ''     | 1234        | '4'               | new UhgCalendar()             | '0'       | '1'               | 1  | 1 | 0 | 0 | new Timestamp(new UhgCalendar().year - 1900, new UhgCalendar().month - 1, new UhgCalendar().day + 2, 23, 59, 00, 00)
        9   | ''     | 1234        | '4'               | new UhgCalendar()             | '0'       | '2'               | 1  | 1 | 0 | 0 | new Timestamp(new UhgCalendar().year - 1900, new UhgCalendar().month - 1, new UhgCalendar().day + 2, 23, 59, 00, 00)
        10  | ''     | 1234        | '4'               | new UhgCalendar()             | '0'       | '3'               | 1  | 1 | 0 | 0 | new Timestamp(new UhgCalendar().year - 1900, new UhgCalendar().month - 1, new UhgCalendar().day + 2, 23, 59, 00, 00)
        11  | ''     | 1234        | '4'               | new UhgCalendar()             | '0'       | '4'               | 1  | 0 | 1 | 3 | new Timestamp(new UhgCalendar().year - 1900, new UhgCalendar().month - 1, new UhgCalendar().day + 2, 23, 59, 00, 00)
    }

    @Unroll
    def 'getWorkQueueItems with assignment type search'() {
        given:
        QueryProperties query = new QueryProperties()
        query.addQueryFilter(new QueryFilter('owner', 'Test'))
        query.addQueryFilter(new QueryFilter('workQueueId', '123'))
        query.addQueryFilter(new QueryFilter('timeZoneID', 'Asia/Calcutta'))
        query.addQueryFilter(new QueryFilter(FieldConstants.ASSIGNMENTTYPE, assignmentType))

        List<ItemTaskCriteriaResponse> itemTaskCriteriaResponseList = [
                new ItemTaskCriteriaResponse(hscId: 123, itemTaskId: 123, workQueueId: 123, descriptionId: '1', assignmentTypeId: '04',
                        owner: 'Test', assignmentDueDate: new Timestamp(new UhgCalendar().year - 1900, new UhgCalendar().month - 2, new UhgCalendar().day, 23, 59, 00, 00),
                        createDateTime: new Timestamp(11, 0, 12, 0, 0, 0, 0),
                        assignmentComments: 'test', statusId: '1', outcomeId: '1', priorityTypeId: '1', createUserId: 'SYSTEM', assignedTo: '100'),
                new ItemTaskCriteriaResponse(hscId: 1234, itemTaskId: 123, workQueueId: 123, descriptionId: '1', assignmentTypeId: '04',
                        owner: 'Test', assignmentDueDate: new Timestamp(new UhgCalendar().year - 1900, new UhgCalendar().month - 2, new UhgCalendar().day, 23, 59, 00, 00),
                        createDateTime: new Timestamp(11, 0, 12, 0, 0, 0, 0),
                        assignmentComments: 'test', statusId: '1', outcomeId: '1', priorityTypeId: '1', createUserId: 'SYSTEM', assignedTo: '100'),
                new ItemTaskCriteriaResponse(hscId: 1234, itemTaskId: 123, workQueueId: 123, descriptionId: '1', assignmentTypeId: '04',
                        owner: 'Test', assignmentDueDate: new Timestamp(new UhgCalendar().year - 1900, new UhgCalendar().month - 2, new UhgCalendar().day, 23, 59, 00, 00),
                        createDateTime: new Timestamp(11, 0, 12, 0, 0, 0, 0),
                        assignmentComments: '', statusId: '1', outcomeId: '1', priorityTypeId: '1', createUserId: 'SYSTEM', assignedTo: '100'),
                new ItemTaskCriteriaResponse(hscId: 1234, itemTaskId: 123, workQueueId: 123, descriptionId: '1', assignmentTypeId: '02',
                        owner: 'Test', assignmentDueDate: new Timestamp(new UhgCalendar().year - 1900, new UhgCalendar().month - 2, new UhgCalendar().day, 23, 59, 00, 00),
                        createDateTime: new Timestamp(11, 0, 12, 0, 0, 0, 0),
                        assignmentComments: '', statusId: '1', outcomeId: '1', priorityTypeId: '1', createUserId: 'SYSTEM', assignedTo: '100'),
                new ItemTaskCriteriaResponse(hscId: 1234, itemTaskId: 123, workQueueId: 123, descriptionId: '1', assignmentTypeId: '1',
                        owner: 'Test', assignmentDueDate: new Timestamp(new UhgCalendar().year - 1900, new UhgCalendar().month - 2, new UhgCalendar().day, 23, 59, 00, 00),
                        createDateTime: new Timestamp(11, 0, 12, 0, 0, 0, 0),
                        assignmentComments: '', statusId: '1', outcomeId: '1', priorityTypeId: '1', createUserId: 'SYSTEM', assignedTo: '100')]

        List<WorkQueueViewVO> workQueueViewVOList = [
                new WorkQueueViewVO(hscId: 123, authorizationType: authorizationType, cancerType: '12', anticipatedStartDt: '2019-11-11', memberName: 'Test',
                        policyGroup: '0908410', policyName: 'OXFORD HEALTH INSURANCE, INC.', insuranceType: '4', reviewPriority: '1', stateOfIssue: 'AR', stateOfResidence: 'NJ', stateOfService: 'OH',
                        serviceReferenceNum: 'A003011288', providerName: 'HAZRA ANUPINDER', tatDueDate: new UhgCalendar(), tatExists: '1', submittedDate: '9999-01-01'),
                new WorkQueueViewVO(hscId: 1234, authorizationType: authorizationType, cancerType: '12', anticipatedStartDt: '2019-11-11', memberName: 'Test',
                        policyGroup: '0908410', policyName: 'OXFORD HEALTH INSURANCE, INC.', insuranceType: '4', reviewPriority: '1', stateOfIssue: 'AR', stateOfResidence: 'NJ', stateOfService: 'OH',
                        serviceReferenceNum: 'A003011288', providerName: 'HAZRA ANUPINDER', tatDueDate: new UhgCalendar(), tatExists: '1', submittedDate: '9999-01-01'),
                new WorkQueueViewVO(hscId: 123, authorizationType: "", cancerType: '12', anticipatedStartDt: '2019-11-11', memberName: '',
                        policyGroup: '', policyName: '', insuranceType: '', reviewPriority: '', stateOfIssue: '', stateOfResidence: '', stateOfService: '',
                        serviceReferenceNum: '', providerName: '', tatDueDate: new UhgCalendar(), tatExists: '1', submittedDate: null)]

        restTemplate.exchange(_, _, _, _) >> new ResponseEntity<List<ItemTaskCriteriaResponse>>(itemTaskCriteriaResponseList, HttpStatus.OK)
        queueSearchRequestMapper.getSystemSettingsWebServiceVO() >> systemSettingsWebServiceVO
        1 * queueSearchRequestMapper.setWorkQueueSearchRestTemplateTimeout(restTemplate)
        workQueueView.listBySearchParams(_, _) >> workQueueViewVOList

        when:
        WorkQueueHelperDO workQueueHelperDO = mbmWorkQueueSearchImpl.getWorkQueueItems(query)


        then:
        1 * workQueueView.callStoredProcedure(_,_) >> workQueueViewVOList
        workQueueHelperDO.doList.size() == numberOfWorkQueuesReturned

        where:
        authorizationType | assignmentType | numberOfWorkQueuesReturned
        '1'      | '03'           | 0
        '1'      | '04'           | 3
        '1'      | '02'           | 1
        '1'      | null           | 5
        '1'      | 1              | 1
    }


    def 'saveAssignment'() {
        given:
        ItemTask itemTask = new ItemTask(itemTaskId: 123, queueItemId: 123, typeId: '04', owner: 'SYSTEM', dueDate: new Timestamp(11, 0, 12, 0, 0, 0, 0), comment: 'test', assignDate: assignDt,
                assigner: assignr, statusId: '123', outcomeId: '123', priorityTypeId: '01', workQueueId: wrkQueueId, descriptionId: '01', createDateTime: new Timestamp(11, 0, 12, 0, 0, 0, 0), createUserId: 'SYSTEM')

        when:
        mbmWorkQueueSearchImpl.saveAssignment(itemTask)

        then:
        1 * restTemplate.postForEntity(_, _, _) >> new ResponseEntity<ItemTask>(itemTask, HttpStatus.OK)
        1 * queueSearchRequestMapper.getSystemSettingsWebServiceVO() >> systemSettingsWebServiceVO
        1 * queueSearchRequestMapper.setWorkQueueSearchRestTemplateTimeout(restTemplate)
        1 * queueSearchRequestMapper.buildHttpHeader()
        0 * _

        where:
        Sno | wrkQueueId | assignDt                        | assignr
        1   | 123L       | UhgCalendarUtilities.todaysDate | 'test'
        2   | 0          | null                            | ''

    }

    def 'getActiveWorkQueueList'() {
        given:
        QueryProperties query = new QueryProperties()

        when:
        mbmWorkQueueSearchImpl.getActiveWorkQueueList(query)

        then:
        1 * queueSearchRequestMapper.getSystemSettingsWebServiceVO() >> systemSettingsWebServiceVO
        1 * queueSearchRequestMapper.setWorkQueueSearchRestTemplateTimeout(restTemplate)
        1 * queueSearchRequestMapper.buildHttpHeader()
        1 * restTemplate.exchange(_, _, _, _) >> new ResponseEntity<List<WorkQueue>>(HttpStatus.OK)
        0 * _
    }

    def 'getAssignments'() {
        given:
        QueryProperties query = new QueryProperties()
        query.addQueryFilter(new QueryFilter('hscId', 123))
        query.setOrderByAscFields('queueItemId')
        List<ItemTaskCriteriaResponse> criteriaResponseList = [new ItemTaskCriteriaResponse(hscId: 123, itemTaskId: 123, workQueueId: 123, descriptionId: '1', assignmentTypeId: '04',
                owner: 'Test', assignmentDueDate: new Timestamp(11, 0, 12, 0, 0, 0, 0), createDateTime: new Timestamp(11, 0, 12, 0, 0, 0, 0),
                assignmentComments: 'test', statusId: '1', outcomeId: '1', priorityTypeId: '1', createUserId: 'SYSTEM', assignedTo: '100')]

        when:
        mbmWorkQueueSearchImpl.getAssignments(query)

        then:
        1 * queueSearchRequestMapper.getSystemSettingsWebServiceVO() >> systemSettingsWebServiceVO
        1 * queueSearchRequestMapper.setWorkQueueSearchRestTemplateTimeout(restTemplate)
        1 * queueSearchRequestMapper.buildHttpHeader()
        1 * restTemplate.exchange(_, _, _, _) >> new ResponseEntity<List<ItemTaskCriteriaResponse>>(criteriaResponseList, HttpStatus.OK)
        0 * _
    }

    @Unroll
    def 'getAssignmentHistory'() {
        given:
        QueryProperties query = new QueryProperties()
        query.addQueryFilter(new QueryFilter('hscId', 123))
        query.setOrderByAscFields('fieldLabelId')
        query.setResultSize(1)
        List<WorkQueue> workQueueList = [new WorkQueue(workQueueId: 700, name: 'Test', description: 'test', status: 'Active'),
                                         new WorkQueue(workQueueId: 1004, name: 'Test1', description: 'test1', status: 'Active')]
        List<ItemTaskHistory> historyList = [new ItemTaskHistory(itemTaskHistoryId: 1, itemTaskId: 123, fieldLabelId: fieldLabelId, fromValue: fromValue, toValue: toValue, changeUserId: 'Test', changedDateTime: new Timestamp(11, 0, 12, 0, 0, 0, 0)),
                                             new ItemTaskHistory(itemTaskHistoryId: 2, itemTaskId: 1234, fieldLabelId: fieldLabelId, fromValue: fromValue, toValue: toValue, changeUserId: 'Test', changedDateTime: new Timestamp(11, 0, 12, 0, 0, 0, 0))]

        when:
        mbmWorkQueueSearchImpl.getAssignmentHistory(query, 123)

        then:
        1 * restTemplate.exchange(_, _, _, _) >> new ResponseEntity<List<ItemTaskHistory>>(historyList, HttpStatus.OK)
        1 * restTemplate.exchange(_, _, _, _) >> new ResponseEntity<List<WorkQueue>>(workQueueList, HttpStatus.OK)
        2 * queueSearchRequestMapper.getSystemSettingsWebServiceVO() >> systemSettingsWebServiceVO
        2 * queueSearchRequestMapper.setWorkQueueSearchRestTemplateTimeout(restTemplate)
        2 * queueSearchRequestMapper.buildHttpHeader()
        X * customerReference.getReferenceDescription(_, _)
        y * appUser.read(_)
        0 * _

        where:
        Sno | fieldLabelId | fromValue                 | toValue                   | X | y
        1   | '1'          | '1'                       | '2'                       | 6 | 2
        2   | '2'          | '1'                       | '2'                       | 6 | 2
        3   | '3'          | '1'                       | '2'                       | 6 | 2
        4   | '4'          | '2019-08-12 17:56:00.000' | '2019-08-12 12:00:00.000' | 2 | 2
        5   | '5'          | '700'                     | '1004'                    | 2 | 2
        6   | '5'          | 'Test1'                   | 'test2'                   | 2 | 6
        6   | ''           | 'Test1'                   | 'test2'                   | 2 | 2
    }

    def 'saveItemTaskList'() {
        given:
        List<ItemTask> itemTaskList = new ArrayList<ItemTask>()

        when:
        mbmWorkQueueSearchImpl.saveItemTaskList(itemTaskList)

        then:
        1 * restTemplate.exchange(_, _, _, _) >> new ResponseEntity<ItemTaskHistory>(HttpStatus.OK)
        1 * queueSearchRequestMapper.getSystemSettingsWebServiceVO() >> systemSettingsWebServiceVO
        1 * queueSearchRequestMapper.setWorkQueueSearchRestTemplateTimeout(restTemplate)
        1 * queueSearchRequestMapper.buildHttpHeader()
        0 * _
    }

    @Unroll
    def 'getTatDateFor48Hrs'() {
        given:
        final String dueDateSearchIdValue = SpclCareReferenceConstants.DUE_WITHIN_48_HOURS

        final UhgCalendar uhgCalendarWithinRange = new UhgCalendar(TimeZone.getTimeZone(timeZone))
        uhgCalendarWithinRange.add(Calendar.HOUR, 48)
        uhgCalendarWithinRange.add(Calendar.MINUTE, -5)

        final UhgCalendar uhgCalendarOutsideOfRange = new UhgCalendar(TimeZone.getTimeZone(timeZone))
        uhgCalendarOutsideOfRange.add(Calendar.MINUTE, 10)
        uhgCalendarOutsideOfRange.add(Calendar.HOUR, 48)

        when:
        List<StoredProcProperties> properties = new ArrayList<>()

        mbmWorkQueueSearchImpl.addQFForTatDueDateFiltering(
                dueDateSearchIdValue,
                properties)

        then:
        properties.size() == 2
        String uhgCalendarForCurrentTimeResultTimeStamp =  properties.stream()
                .filter({p -> p.parameterName == RestConstants.WORKQUEUE_STORED_PROC_PARAMS.USERCURRENTDATE.getValue()})
                .findFirst().orElse(null).parameterValue
        Date uhgCalendarForCurrentTimeResultDate = sqlDateStringToDate(uhgCalendarForCurrentTimeResultTimeStamp)
        UhgCalendar uhgCalendarForCurrentTimeResult = new UhgCalendar(TimeZone.getTimeZone(timeZone))
        uhgCalendarForCurrentTimeResult.setTime(uhgCalendarForCurrentTimeResultDate)

        String uhgCalendarForTatDueDateResultTimeStamp = properties.stream()
                .filter({p -> p.parameterName == RestConstants.WORKQUEUE_STORED_PROC_PARAMS.TATDUEDATE.getValue()})
                .findFirst().orElse(null).parameterValue
        Date uhgCalendarForTatDueDateResultDate = sqlDateStringToDate(uhgCalendarForTatDueDateResultTimeStamp)
        UhgCalendar uhgCalendarForTatDueDateResult = new UhgCalendar(TimeZone.getTimeZone(timeZone))
        uhgCalendarForTatDueDateResult.setTime(uhgCalendarForTatDueDateResultDate)
        UhgCalendarUtilities.isAfter(uhgCalendarWithinRange.getTime(),uhgCalendarForCurrentTimeResult.getTime()) &&
                UhgCalendarUtilities.isBeforeOrEqualTo(uhgCalendarWithinRange.getTime(), uhgCalendarForTatDueDateResult.getTime())
        UhgCalendarUtilities.isAfter(uhgCalendarOutsideOfRange.getTime(),uhgCalendarForCurrentTimeResult.getTime()) &&
                !UhgCalendarUtilities.isBeforeOrEqualTo(uhgCalendarOutsideOfRange.getTime(), uhgCalendarForTatDueDateResult.getTime())
    }

    @Unroll
    def 'getTatDateFor7Days'() {
        given:
        final String dueDateSearchIdValue = SpclCareReferenceConstants.DUE_WITHIN_7_DAYS

        final UhgCalendar uhgCalendarWithinRange = new UhgCalendar(TimeZone.getTimeZone(timeZone))
        uhgCalendarWithinRange.add(Calendar.DAY_OF_WEEK, 7)
        uhgCalendarWithinRange.add(Calendar.MINUTE, -5)

        final UhgCalendar uhgCalendarOutsideOfRange = new UhgCalendar(TimeZone.getTimeZone(timeZone))
        uhgCalendarOutsideOfRange.add(Calendar.DAY_OF_WEEK, 7)
        uhgCalendarOutsideOfRange.add(Calendar.MINUTE, 5)

        List<StoredProcProperties> properties = new ArrayList<>()

        when:
        mbmWorkQueueSearchImpl.addQFForTatDueDateFiltering(
                dueDateSearchIdValue,
                properties)

        then:
        properties.size() == 2
        String uhgCalendarForCurrentTimeResultTimeStamp =  properties.stream()
                .filter({p -> p.parameterName == RestConstants.WORKQUEUE_STORED_PROC_PARAMS.USERCURRENTDATE.getValue()})
                .findFirst().orElse(null).parameterValue
        Date uhgCalendarForCurrentTimeResultDate = sqlDateStringToDate(uhgCalendarForCurrentTimeResultTimeStamp)
        UhgCalendar uhgCalendarForCurrentTimeResult = new UhgCalendar(TimeZone.getTimeZone(timeZone))
        uhgCalendarForCurrentTimeResult.setTime(uhgCalendarForCurrentTimeResultDate)

        String uhgCalendarForTatDueDateResultTimeStamp = properties.stream()
                .filter({p -> p.parameterName == RestConstants.WORKQUEUE_STORED_PROC_PARAMS.TATDUEDATE.getValue()})
                .findFirst().orElse(null).parameterValue
        Date uhgCalendarForTatDueDateResultDate = sqlDateStringToDate(uhgCalendarForTatDueDateResultTimeStamp)
        UhgCalendar uhgCalendarForTatDueDateResult = new UhgCalendar(TimeZone.getTimeZone(timeZone))
        uhgCalendarForTatDueDateResult.setTime(uhgCalendarForTatDueDateResultDate)
        UhgCalendarUtilities.isAfter(uhgCalendarWithinRange.getTime(),uhgCalendarForCurrentTimeResult.getTime()) &&
                UhgCalendarUtilities.isBeforeOrEqualTo(uhgCalendarWithinRange.getTime(), uhgCalendarForTatDueDateResult.getTime())
        UhgCalendarUtilities.isAfter(uhgCalendarOutsideOfRange.getTime(),uhgCalendarForCurrentTimeResult.getTime()) &&
                !UhgCalendarUtilities.isBeforeOrEqualTo(uhgCalendarOutsideOfRange.getTime(), uhgCalendarForTatDueDateResult.getTime())
    }

    @Unroll
    def 'getTatDateFor24Hrs'() {
        given:
        final String dueDateSearchIdValue = SpclCareReferenceConstants.DUE_WITHIN_24_HOURS
        final UhgCalendar uhgCalendarWithinRange = new UhgCalendar(TimeZone.getTimeZone(timeZone))
        uhgCalendarWithinRange.add(Calendar.HOUR, 24)
        uhgCalendarWithinRange.add(Calendar.MINUTE, -1)

        final UhgCalendar uhgCalendarOutsideOfRange = new UhgCalendar(TimeZone.getTimeZone(timeZone))
        uhgCalendarOutsideOfRange.add(Calendar.HOUR, 24)
        uhgCalendarOutsideOfRange.add(Calendar.MINUTE, 5)

        when:
        List<StoredProcProperties> properties = new ArrayList<>()

        mbmWorkQueueSearchImpl.addQFForTatDueDateFiltering(
                dueDateSearchIdValue,
                properties)

        then:
        properties.size() == 2
        String uhgCalendarForCurrentTimeResultTimeStamp =  properties.stream()
                .filter({p -> p.parameterName == RestConstants.WORKQUEUE_STORED_PROC_PARAMS.USERCURRENTDATE.getValue()})
                .findFirst().orElse(null).parameterValue
        Date uhgCalendarForCurrentTimeResultDate = sqlDateStringToDate(uhgCalendarForCurrentTimeResultTimeStamp)
        UhgCalendar uhgCalendarForCurrentTimeResult = new UhgCalendar(TimeZone.getTimeZone(timeZone))
        uhgCalendarForCurrentTimeResult.setTime(uhgCalendarForCurrentTimeResultDate)

        String uhgCalendarForTatDueDateResultTimeStamp = properties.stream()
                .filter({p -> p.parameterName == RestConstants.WORKQUEUE_STORED_PROC_PARAMS.TATDUEDATE.getValue()})
                .findFirst().orElse(null).parameterValue
        Date uhgCalendarForTatDueDateResultDate = sqlDateStringToDate(uhgCalendarForTatDueDateResultTimeStamp)
        UhgCalendar uhgCalendarForTatDueDateResult = new UhgCalendar(TimeZone.getTimeZone(timeZone))
        uhgCalendarForTatDueDateResult.setTime(uhgCalendarForTatDueDateResultDate)
        UhgCalendarUtilities.isAfter(uhgCalendarWithinRange.getTime(),uhgCalendarForCurrentTimeResult.getTime()) &&
                UhgCalendarUtilities.isBeforeOrEqualTo(uhgCalendarWithinRange.getTime(), uhgCalendarForTatDueDateResult.getTime())
        UhgCalendarUtilities.isAfter(uhgCalendarOutsideOfRange.getTime(),uhgCalendarForCurrentTimeResult.getTime()) &&
                !UhgCalendarUtilities.isBeforeOrEqualTo(uhgCalendarOutsideOfRange.getTime(), uhgCalendarForTatDueDateResult.getTime())
    }

    @Unroll
    def 'getTatDateForPastDue'() {
        given:
        final String dueDateSearchIdValue = SpclCareReferenceConstants.TAT_PAST_DUE

        final UhgCalendar uhgCalendarWithinRange = new UhgCalendar(TimeZone.getTimeZone(timeZone))
        uhgCalendarWithinRange.add(Calendar.MINUTE, -50)

        final UhgCalendar uhgCalendarOutsideOfRange = new UhgCalendar(TimeZone.getTimeZone(timeZone))
        uhgCalendarOutsideOfRange.add(Calendar.HOUR, 1)

        when:
        List<StoredProcProperties> properties = new ArrayList<>()

        mbmWorkQueueSearchImpl.addQFForTatDueDateFiltering(
                dueDateSearchIdValue,
                properties)

        then:
        properties.size() == 2
        String uhgCalendarForCurrentTimeResultTimeStamp =  properties.stream()
                .filter({p -> p.parameterName == RestConstants.WORKQUEUE_STORED_PROC_PARAMS.USERCURRENTDATE.getValue()})
                .findFirst().orElse(null).parameterValue
        Date uhgCalendarForCurrentTimeResultDate = sqlDateStringToDate(uhgCalendarForCurrentTimeResultTimeStamp)
        UhgCalendar uhgCalendarForCurrentTimeResult = new UhgCalendar(TimeZone.getTimeZone(timeZone))
        uhgCalendarForCurrentTimeResult.setTime(uhgCalendarForCurrentTimeResultDate)
        UhgCalendarUtilities.isBefore(uhgCalendarWithinRange.getTime(),uhgCalendarForCurrentTimeResult.getTime())
        UhgCalendarUtilities.isAfterOrEqualTo(uhgCalendarOutsideOfRange.getTime(),uhgCalendarForCurrentTimeResult.getTime())

        String uhgCalendarForTatDueDateResultTimeStamp = properties.stream()
                .filter({p -> p.parameterName == RestConstants.WORKQUEUE_STORED_PROC_PARAMS.TATDUEDATE.getValue()})
                .findFirst().orElse(null).parameterValue
        uhgCalendarForTatDueDateResultTimeStamp == null
    }

    Date sqlDateStringToDate(String sqlDateString) {
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        dateFormat.setTimeZone(TimeZone.getTimeZone(timeZone))
        Date dt = dateFormat.parse(sqlDateString)
        dt
    }
}
