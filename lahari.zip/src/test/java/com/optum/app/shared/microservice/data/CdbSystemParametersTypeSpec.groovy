package com.optum.app.shared.microservice.data

import com.optum.app.shared.microservice.data.CdbSystemParametersType
import org.apache.commons.lang.StringUtils
import spock.lang.Specification

class CdbSystemParametersTypeSpec extends Specification {

    CdbSystemParametersType cdbSystemParametersType

    def setup() {
        cdbSystemParametersType = new CdbSystemParametersType(applicationId: 'MBM_TEST', roleId: 'TESTING')
    }

    def "equals true"() {

        when:
        boolean retVal = cdbSystemParametersType.equals(cdbSystemParametersType)

        then:
        0 * _

        and:
        retVal
    }

    def "equals false"() {
        given:
        CdbSystemParametersType object2 = new CdbSystemParametersType(applicationId: 'MBM_TEST2', roleId: 'TESTING')

        CdbSystemParametersType object = new CdbSystemParametersType(applicationId: 'MBM_TEST', roleId: 'TESTING')

        when:
        boolean retVal = object.equals(_)

        then:
        0 * _

        and:
        !retVal
    }

    def "hash"() {
        given:

        CdbSystemParametersType object = new CdbSystemParametersType(applicationId: 'MBM_TEST', roleId: 'TESTING')

        when:
        int retVal = object.hashCode()

        then:
        0 * _

        and:
        retVal
        retVal > 0
    }

    def "to String"() {
        given:

        CdbSystemParametersType object = new CdbSystemParametersType(applicationId: 'MBM_TEST', roleId: 'TESTING')

        when:
        String retVal = object.toString()

        then:
        0 * _

        and:
        StringUtils.isNotBlank(retVal)
    }

}
