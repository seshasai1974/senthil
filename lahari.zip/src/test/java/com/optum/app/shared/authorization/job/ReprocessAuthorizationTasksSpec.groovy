package com.optum.app.shared.authorization.job

import com.optum.app.shared.authorization.job.ReprocessAuthTasksProcessor
import com.optum.app.shared.authorization.job.ReprocessAuthorizationTasks
import com.optum.rf.core.spring.ApplicationContextHolder
import com.optum.rf.test.core.mock.spring.MockWebApplicationContext
import spock.lang.Specification

/**
 * Created by jboyd34 on 10/8/18.
 */
class ReprocessAuthorizationTasksSpec extends Specification{

    def "test runtask" () {
        given:
        ApplicationContextHolder.setApplicationContext(new MockWebApplicationContext(), true)
        ((MockWebApplicationContext) ApplicationContextHolder.getApplicationContext()).setBean("reprocessAuthTasksProcessor", Mock(ReprocessAuthTasksProcessor))
        ReprocessAuthorizationTasks tasks = new ReprocessAuthorizationTasks()

        when:
        boolean result = tasks.runTask(null,null)
        then:
        !result
    }

}
