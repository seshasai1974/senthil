package com.optum.app.shared.ssoauthentication.helper

import com.optum.app.shared.constants.SpclCareConstants
import com.optum.app.shared.ssoauthentication.helper.impl.SSOActivityLogImpl
import com.optum.rf.common.controller.ReturnConstants
import com.optum.rf.common.log.businesslogic.IRMEvent
import com.optum.rf.common.log.businesslogic.UserActivityLog
import com.optum.rf.common.security.businesslogic.Permission
import com.optum.rf.common.security.data.UserProfileVO
import com.optum.rf.common.security.data.UserSecurityVO
import com.optum.rf.common.settings.businesslogic.TemporarySystemSetting
import com.optum.rf.common.system.util.DbUtilities
import com.optum.rf.dao.controller.session.SessionThreadLocal
import com.optum.rf.web.controller.response.Response
import com.optum.rf.web.controller.session.HttpUserSession
import org.springframework.mock.web.MockHttpServletRequest
import spock.lang.Specification

import java.time.Instant

class SSOActivityLogImplSpec extends Specification {
    SSOActivityLogImpl ssoActivityLog = new SSOActivityLogImpl()
    DbUtilities dbUtilities = Mock(DbUtilities)
    UserActivityLog userActivityLog = Mock(UserActivityLog)
    Permission permission = Mock(Permission)
    IRMEvent irmEvent = Mock(IRMEvent)
    TemporarySystemSetting temporarySystemSetting = Mock(TemporarySystemSetting)
    SessionThreadLocal sessionThreadLocal = Mock(SessionThreadLocal)

    def setup() {
        ssoActivityLog.dbUtilities = dbUtilities
        ssoActivityLog.userActivityLog = userActivityLog
        ssoActivityLog.permission = permission
        ssoActivityLog.irmEvent = irmEvent
        ssoActivityLog.temporarySystemSetting = temporarySystemSetting
    }

    def "test logUserAction"() {
        given:
        String permissionID = "permissionID"
        sessionThreadLocal.setSession(session)
        Long startTime = Instant.now().toEpochMilli()

        when:
        ssoActivityLog.logUserAction(startTime, permissionID, response, request)

        then:
        1 * userActivityLog.add(_)

        where:
        testCase | response                                                                                                  | session                                                                                                                                                              | request
        0        | new Response()                                                                                            | new HttpUserSession(databaseTransactionCount: 1).setUserSecurity(new UserSecurityVO(userID: "testUser", userGroupID: SpclCareConstants.ROLE_INTERNAL_OPERATIONS))    | new MockHttpServletRequest()
        1        | new Response().addResponseObject(ReturnConstants.USERPROFILEVO, new UserProfileVO(userID: "testUser321")) | new HttpUserSession(databaseTransactionCount: 1).setUserSecurity(new UserSecurityVO(userID: "testUser321", userGroupID: SpclCareConstants.ROLE_INTERNAL_OPERATIONS)) | new MockHttpServletRequest()
    }
}
