package com.optum.app.shared.filter

import org.junit.rules.ExternalResource

import java.lang.reflect.Field
import org.apache.commons.logging.Log

import java.lang.reflect.Modifier;

class ReplacePrivateFinalMember extends ExternalResource{
    Field logField
    Log logger
    Log originalLogger

    ReplacePrivateFinalMember(Class logClass, Log logger, String logFieldName) {
        logField = logClass.getDeclaredField(logFieldName);
        this.logger = logger
    }

    @Override
    protected void before() throws Throwable {
        logField.accessible = true

        Field modifiersField = Field.getDeclaredField("modifiers")
        modifiersField.accessible = true

        // remove the final modifier from the field
        modifiersField.setInt(logField, logField.getModifiers() & ~Modifier.FINAL)

        originalLogger = (Log) logField.get(null)
        logField.set(null, logger)
    }

    @Override
    protected void after() {
        logField.set(null, originalLogger)
    }
}
