package com.optum.app.shared.dashboard.controller

import com.optum.app.shared.dashboard.controller.WidgetController
import com.optum.app.shared.hsc.businesslogic.HscSearch
import spock.lang.Specification

/**
 * Created by jboyd34 on 5/30/19.
 */
class WidgetControllerSpec extends Specification{

    WidgetController widgetController
    HscSearch hscSearch

    def setup(){
        widgetController = new WidgetController()
        hscSearch = Mock(HscSearch)

        widgetController.hscSearch = hscSearch
    }

    def "getDraftWidget"(){
        when:
        widgetController.getDraftWidget()

        then:
        1 * hscSearch.getHscsForDraftWidget()
    }
}
