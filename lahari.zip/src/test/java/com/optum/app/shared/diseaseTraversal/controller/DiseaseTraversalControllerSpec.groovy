package com.optum.app.shared.diseaseTraversal.controller

import com.optum.app.ocm.controller.support.CommonResponse
import com.optum.app.shared.constants.MultiPayerConstants
import com.optum.app.shared.constants.SpclCareConstants
import com.optum.app.shared.constants.SpclCareReferenceConstants
import com.optum.app.shared.diseaseTraversal.businesslogic.DiseaseTraversal
import com.optum.app.shared.diseaseTraversal.businesslogic.DiseaseTraversalAssessmentVariable
import com.optum.app.shared.diseaseTraversal.businesslogic.DiseaseTraversalClinicalVariable
import com.optum.app.shared.diseaseTraversal.businesslogic.DiseaseTraversalHelper
import com.optum.app.shared.diseaseTraversal.businesslogic.DiseaseTraversalTreatmentRegimen
import com.optum.app.shared.diseaseTraversal.businesslogic.DiseaseTraversalVersion
import com.optum.app.shared.diseaseTraversal.businesslogic.DrugExceptionsView
import com.optum.app.shared.diseaseTraversal.businesslogic.RegimenTraversalView
import com.optum.app.shared.diseaseTraversal.businesslogic.TreatmentProcedureAuthorizationRule
import com.optum.app.shared.diseaseTraversal.businesslogic.TreatmentProcedureAuthorizationRuleException
import com.optum.app.shared.diseaseTraversal.businesslogic.TreatmentRegimen
import com.optum.app.shared.diseaseTraversal.businesslogic.TreatmentRegimenVersion
import com.optum.app.shared.diseaseTraversal.businesslogic.TreatmentRegimenVersionProcedure
import com.optum.app.shared.diseaseTraversal.businesslogic.TreatmentSupportiveCareProcedure
import com.optum.app.shared.diseaseTraversal.businesslogic.TreatmentSupportiveCareProcedureCustomer
import com.optum.app.shared.diseaseTraversal.data.BulkEditTraversalDO
import com.optum.app.shared.diseaseTraversal.data.DiseaseTraversalClinicalVariableVO
import com.optum.app.shared.diseaseTraversal.data.DiseaseTraversalDO
import com.optum.app.shared.diseaseTraversal.data.DiseaseTraversalProcedureVO
import com.optum.app.shared.diseaseTraversal.data.DiseaseTraversalTreatmentRegimenVO
import com.optum.app.shared.diseaseTraversal.data.DiseaseTraversalVO
import com.optum.app.shared.diseaseTraversal.data.DiseaseTraversalVariableVersionDO
import com.optum.app.shared.diseaseTraversal.data.DiseaseTraversalVersionVO
import com.optum.app.shared.diseaseTraversal.data.DrugExceptionsViewVO
import com.optum.app.shared.diseaseTraversal.data.RegimenTraversalViewVO
import com.optum.app.shared.diseaseTraversal.data.TraversalDeterminationDO
import com.optum.app.shared.diseaseTraversal.data.TraversalLinkageDO
import com.optum.app.shared.diseaseTraversal.data.TreatmentProcedureAuthorizationRuleVO
import com.optum.app.shared.diseaseTraversal.data.TreatmentRegimenVO
import com.optum.app.shared.diseaseTraversal.data.TreatmentRegimenVersionProcedureVO
import com.optum.app.shared.diseaseTraversal.data.TreatmentRegimenVersionVO
import com.optum.app.shared.diseaseTraversal.data.TreatmentSupportiveCareProcedureVO
import com.optum.app.shared.diseaseTraversal.helper.TraversalHelper
import com.optum.app.shared.spclcare.SpecialtyCareReadLogicSpecification
import com.optum.app.shared.supportive.businesslogic.NewProcedure
import com.optum.app.shared.supportive.businesslogic.NewProcedureView
import com.optum.app.shared.supportive.data.NewProcedureVO
import com.optum.app.shared.supportive.data.NewProcedureViewVO
import com.optum.rf.common.security.businesslogic.UserGroupPermissionGroup
import com.optum.rf.common.security.businesslogic.UserPermissionGroup
import com.optum.rf.common.settings.businesslogic.TemporarySystemSetting
import com.optum.rf.dao.exception.UhgRuntimeException
import com.optum.rf.dao.sql.query.QueryFilter
import com.optum.rf.dao.sql.query.QueryProperties
import com.uhg.app.common.constants.spclcare.FieldConstants
import org.apache.poi.hssf.usermodel.HSSFSheet
import org.apache.poi.hssf.usermodel.HSSFWorkbook
import org.apache.poi.ss.usermodel.Row
import org.apache.poi.ss.usermodel.Workbook
import org.springframework.mock.web.MockMultipartFile
import org.springframework.web.multipart.MultipartFile
import spock.lang.Unroll

class DiseaseTraversalControllerSpec extends SpecialtyCareReadLogicSpecification {

    DiseaseTraversalController controller = new DiseaseTraversalController()
    DiseaseTraversal diseaseTraversal = Mock(DiseaseTraversal)
    DiseaseTraversalClinicalVariable clinicalVariable = Mock(DiseaseTraversalClinicalVariable)
    DiseaseTraversalTreatmentRegimen diseaseTraversalTreatmentRegimen = Mock(DiseaseTraversalTreatmentRegimen)
    DiseaseTraversalVersion diseaseTraversalVersion = Mock(DiseaseTraversalVersion)
    DiseaseTraversalAssessmentVariable diseaseTraversalAssessmentVariable = Mock(DiseaseTraversalAssessmentVariable)
    UserPermissionGroup userPermissionGroup = Mock(UserPermissionGroup)
    UserGroupPermissionGroup userGroupPermissionGroup = Mock(UserGroupPermissionGroup)
    TreatmentRegimen treatmentRegimen = Mock(TreatmentRegimen)
    TreatmentRegimenVersion treatmentRegimenVersion = Mock(TreatmentRegimenVersion)
    TreatmentRegimenVersionProcedure treatmentRegimenVersionProcedure = Mock(TreatmentRegimenVersionProcedure)
    RegimenTraversalView regimenTraversalView = Mock(RegimenTraversalView)
    DiseaseTraversalHelper diseaseTraversalHelper = Mock(DiseaseTraversalHelper)
    TreatmentProcedureAuthorizationRuleException treatmentProcedureAuthorizationRuleException = Mock(TreatmentProcedureAuthorizationRuleException)
    TreatmentProcedureAuthorizationRule treatmentProcedureAuthorizationRule = Mock(TreatmentProcedureAuthorizationRule)
    TreatmentSupportiveCareProcedure treatmentSupportiveCareProcedure = Mock(TreatmentSupportiveCareProcedure)
    DrugExceptionsView drugExceptionsView = Mock(DrugExceptionsView)
    NewProcedure newProcedure = Mock(NewProcedure)
    NewProcedureView newProcedureView = Mock(NewProcedureView)
    TreatmentSupportiveCareProcedureCustomer treatmentSupportiveCareProcedureCustomer = Mock(TreatmentSupportiveCareProcedureCustomer)
    TraversalHelper traversalHelper = Mock(TraversalHelper)
    TemporarySystemSetting temporarySystemSetting = Mock(TemporarySystemSetting)

    def setup() {
        controller.diseaseTraversal = diseaseTraversal
        controller.diseaseTraversalClinicalVariable = clinicalVariable
        controller.diseaseTraversalTreatmentRegimen = diseaseTraversalTreatmentRegimen
        controller.treatmentRegimen = treatmentRegimen
        controller.treatmentRegimenVersion = treatmentRegimenVersion
        controller.treatmentRegimenVersionProcedure = treatmentRegimenVersionProcedure
        controller.regimenTraversalView = regimenTraversalView
        controller.diseaseTraversalHelper = diseaseTraversalHelper
        controller.treatmentProcedureAuthorizationRuleException = treatmentProcedureAuthorizationRuleException
        controller.treatmentProcedureAuthorizationRule = treatmentProcedureAuthorizationRule
        controller.treatmentSupportiveCareProcedure = treatmentSupportiveCareProcedure
        controller.drugExceptionsView = drugExceptionsView
        controller.newProcedure = newProcedure
        controller.newProcedureView = newProcedureView
        controller.diseaseTraversalVersion = diseaseTraversalVersion
        controller.userPermissionGroup = userPermissionGroup
        controller.userGroupPermissionGroup = userGroupPermissionGroup
        controller.diseaseTraversalAssessmentVariable = diseaseTraversalAssessmentVariable
        controller.traversalHelper = traversalHelper
        controller.temporarySystemSetting = temporarySystemSetting
    }

    def "getDiseaseTraversal"() {
        given:
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        qp.addQueryFilter(new QueryFilter(FieldConstants.CREATEUSERID, "test"))
        List<DiseaseTraversalVO> voList = [new DiseaseTraversalVO(diseaseTraversalDescription: "Test Desc", diseaseType: "01")]
        CommonResponse commonResponse = new CommonResponse().setEmbedded(voList).setPaginationInfo(qp).setTotalRecordsCount(voList.size())

        when:
        CommonResponse response = controller.getDiseaseTraversal(qp)

        then:
        1 * diseaseTraversalHelper.listTraversalsByCustomFilters(qp) >> commonResponse
        0 * _

        and:
        Map<String, Object> responseMap = response.getEmbedded()
        ArrayList responseVOs = (ArrayList)responseMap.get("_embedded")
        responseVOs == voList
    }
    
    def "saveDiseaseTraversal"() {
        given:
        List<DiseaseTraversalVO> voList = [new DiseaseTraversalVO(diseaseTraversalDescription: "Test Desc", diseaseType: "01")]
        CommonResponse commonResponse = new CommonResponse().setEmbedded(voList)

        when:
        CommonResponse response = controller.saveDiseaseTraversal(voList)

        then:
        1 * diseaseTraversalHelper.saveDiseaseTraversal(voList) >> commonResponse
        0 * _

        and:
        Map<String, Object> responseMap = response.getEmbedded()
        ArrayList responseVOs = (ArrayList)responseMap.get("_embedded")
        responseVOs == voList
    }

    def "deleteDiseaseTraversal"() {
        given:
        List<DiseaseTraversalVO> vo = [new DiseaseTraversalVO(diseaseTraversalDescription: "Test Desc", diseaseType: "01")]

        when:
        CommonResponse response = controller.deleteDiseaseTraversal(vo)

        then:
        1 * diseaseTraversalHelper.deleteTraversalsNotLinkedToHsc(vo) >> new CommonResponse().setEmbedded([vo])
        0 * _

        and:
        Map<String, Object> responseMap = response.getEmbedded()
        responseMap

    }

    def "getDiseaseTraversalTreatmentRegimen"() {
        given:
        int diseaseTraversalID = 1234
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        qp.addQueryFilter(new QueryFilter(FieldConstants.DISEASETRAVERSALID, diseaseTraversalID))
        List<DiseaseTraversalTreatmentRegimenVO> voList = [new DiseaseTraversalTreatmentRegimenVO(diseaseTraversalID: diseaseTraversalID)]

        when:
        CommonResponse response = controller.getDiseaseTraversalTreatmentRegimen(qp)

        then:
        1 * diseaseTraversalTreatmentRegimen.list(qp) >> voList
        1 * diseaseTraversalTreatmentRegimen.count(qp) >> voList.size()
        0 * _

        and:
        Map<String, Object> responseMap = response.getEmbedded()
        ArrayList responseVOs = (ArrayList)responseMap.get("_embedded")
        responseVOs == voList
    }

    def "saveDiseaseTraversalTreatmentRegimen"() {
        given:
        int diseaseTraversalID = 1234
        DiseaseTraversalTreatmentRegimenVO vo = new DiseaseTraversalTreatmentRegimenVO(diseaseTraversalID: diseaseTraversalID)

        when:
        CommonResponse response = controller.saveDiseaseTraversalTreatmentRegimen([vo])

        then:
        1 * diseaseTraversalTreatmentRegimen.save(vo)
        0 * _

        and:
        Map<String, Object> responseMap = response.getEmbedded()
        ArrayList responseVOs = (ArrayList)responseMap.get("_embedded")
        responseVOs == [vo]
    }

    def "deleteDiseaseTraversalTreatmentRegimen"() {
        given:
        int diseaseTraversalID = 1234
        DiseaseTraversalTreatmentRegimenVO vo = new DiseaseTraversalTreatmentRegimenVO(diseaseTraversalID: diseaseTraversalID)

        when:
        CommonResponse response = controller.deleteDiseaseTraversalTreatmentRegimen([vo])

        then:
        1 * diseaseTraversalTreatmentRegimen.delete(vo)
        0 * _

        and:
        Map<String, Object> responseMap = response.getEmbedded()
        ArrayList responseVOs = (ArrayList)responseMap.get("_embedded")
        responseVOs == [vo]
    }

    def "getDiseaseTraversalClinicalVariable"() {
        given:
        int diseaseTraversalID = 1234
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        qp.addQueryFilter(new QueryFilter(FieldConstants.DISEASETRAVERSALID, diseaseTraversalID))
        DiseaseTraversalClinicalVariableVO vo = new DiseaseTraversalClinicalVariableVO(diseaseTraversalID: diseaseTraversalID)

        when:
        CommonResponse response = controller.getDiseaseTraversalClinicalVariable(qp)

        then:
        1 * clinicalVariable.list(qp) >> [vo]
        1 * clinicalVariable.count(qp) >> [vo].size()
        0 * _

        and:
        Map<String, Object> responseMap = response.getEmbedded()
        ArrayList responseVOs = (ArrayList)responseMap.get("_embedded")
        responseVOs == [vo]
    }

    def "saveDiseaseTraversalClinicalVariable"() {
        given:
        int diseaseTraversalID = 1234
        DiseaseTraversalClinicalVariableVO vo = new DiseaseTraversalClinicalVariableVO(diseaseTraversalID: diseaseTraversalID)

        when:
        CommonResponse response = controller.saveDiseaseTraversalClinicalVariable([vo])

        then:
        1 * clinicalVariable.save(vo)
        0 * _

        and:
        Map<String, Object> responseMap = response.getEmbedded()
        ArrayList responseVOs = (ArrayList)responseMap.get("_embedded")
        responseVOs == [vo]
    }

    def "deleteDiseaseTraversalClinicalVariable"() {
        given:
        int diseaseTraversalID = 1234
        DiseaseTraversalClinicalVariableVO vo = new DiseaseTraversalClinicalVariableVO(diseaseTraversalID: diseaseTraversalID)

        when:
        CommonResponse response = controller.deleteDiseaseTraversalClinicalVariable([vo])

        then:
        1 * clinicalVariable.delete(vo)
        0 * _

        and:
        Map<String, Object> responseMap = response.getEmbedded()
        ArrayList responseVOs = (ArrayList)responseMap.get("_embedded")
        responseVOs == [vo]
    }

    def "getTreatmentRegimen"() {
        given:
        int treatmentRegimenID = 1234
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        qp.addQueryFilter(new QueryFilter(FieldConstants.TREATMENTREGIMENID, treatmentRegimenID))
        TreatmentRegimenVO vo = new TreatmentRegimenVO(treatmentRegimenID: treatmentRegimenID)

        when:
        CommonResponse response = controller.getTreatmentRegimen(qp)

        then:
        1 * treatmentRegimen.list(qp) >> [vo]
        1 * treatmentRegimen.count(qp) >> [vo].size()
        0 * _

        and:
        Map<String, Object> responseMap = response.getEmbedded()
        ArrayList responseVOs = (ArrayList)responseMap.get("_embedded")
        responseVOs == [vo]
    }

    def "saveTreatmentRegimen"() {
        given:
        int treatmentRegimenID = 1234
        TreatmentRegimenVO vo = new TreatmentRegimenVO(treatmentRegimenID: treatmentRegimenID)

        when:
        CommonResponse response = controller.saveTreatmentRegimen([vo])

        then:
        1 * treatmentRegimen.save(vo)
        0 * _

        and:
        Map<String, Object> responseMap = response.getEmbedded()
        ArrayList responseVOs = (ArrayList)responseMap.get("_embedded")
        responseVOs == [vo]
    }

    def "deleteTreatmentRegimen"() {
        given:
        int treatmentRegimenID = 1234
        TreatmentRegimenVO vo = new TreatmentRegimenVO(treatmentRegimenID: treatmentRegimenID)

        when:
        CommonResponse response = controller.deleteTreatmentRegimen([vo])

        then:
        1 * treatmentRegimen.delete(vo)
        0 * _

        and:
        Map<String, Object> responseMap = response.getEmbedded()
        ArrayList responseVOs = (ArrayList)responseMap.get("_embedded")
        responseVOs == [vo]
    }

    def "getTreatmentRegimenVersion"() {
        given:
        int treatmentRegimenVersionID = 55
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        qp.addQueryFilter(new QueryFilter(FieldConstants.TREATMENTREGIMENVERSIONID, treatmentRegimenVersionID))
        TreatmentRegimenVersionVO vo = new TreatmentRegimenVersionVO(treatmentRegimenVersionID: treatmentRegimenVersionID)

        when:
        CommonResponse response = controller.getTreatmentRegimenVersion(qp)

        then:
        1 * treatmentRegimenVersion.list(qp) >> [vo]
        1 * treatmentRegimenVersion.count(qp) >> [vo].size()
        0 * _

        and:
        Map<String, Object> responseMap = response.getEmbedded()
        ArrayList responseVOs = (ArrayList)responseMap.get("_embedded")
        responseVOs == [vo]
    }

    def "saveTreatmentRegimenVersion"() {
        given:
        int treatmentRegimenVersionID = 55
        TreatmentRegimenVersionVO vo = new TreatmentRegimenVersionVO(treatmentRegimenVersionID: treatmentRegimenVersionID)

        when:
        CommonResponse response = controller.saveTreatmentRegimenVersion([vo])

        then:
        1 * treatmentRegimenVersion.save(vo)
        0 * _

        and:
        Map<String, Object> responseMap = response.getEmbedded()
        ArrayList responseVOs = (ArrayList)responseMap.get("_embedded")
        responseVOs == [vo]
    }

    def "deleteTreatmentRegimenVersion"() {
        given:
        int treatmentRegimenVersionID = 55
        TreatmentRegimenVersionVO vo = new TreatmentRegimenVersionVO(treatmentRegimenVersionID: treatmentRegimenVersionID)

        when:
        CommonResponse response = controller.deleteTreatmentRegimenVersion([vo])

        then:
        1 * treatmentRegimenVersion.delete(vo)
        0 * _

        and:
        Map<String, Object> responseMap = response.getEmbedded()
        ArrayList responseVOs = (ArrayList)responseMap.get("_embedded")
        responseVOs == [vo]
    }

    def "getTreatmentRegimenVersionProcedure"() {
        given:
        int treatmentRegimenVersionID = 55
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        qp.addQueryFilter(new QueryFilter(FieldConstants.TREATMENTREGIMENVERSIONID, treatmentRegimenVersionID))
        TreatmentRegimenVersionProcedureVO vo = new TreatmentRegimenVersionProcedureVO(treatmentRegimenVersionID: treatmentRegimenVersionID)

        when:
        CommonResponse response = controller.getTreatmentRegimenVersionProcedure(qp)

        then:
        1 * treatmentRegimenVersionProcedure.list(qp) >> [vo]
        1 * treatmentRegimenVersionProcedure.count(qp) >> [vo].size()
        0 * _

        and:
        Map<String, Object> responseMap = response.getEmbedded()
        ArrayList responseVOs = (ArrayList)responseMap.get("_embedded")
        responseVOs == [vo]
    }

    def "saveTreatmentRegimenVersionProcedure"() {
        given:
        int treatmentRegimenVersionID = 55
        TreatmentRegimenVersionProcedureVO vo = new TreatmentRegimenVersionProcedureVO(treatmentRegimenVersionID: treatmentRegimenVersionID)

        when:
        CommonResponse response = controller.saveTreatmentRegimenVersionProcedure([vo])

        then:
        1 * treatmentRegimenVersionProcedure.save(vo)
        0 * _

        and:
        Map<String, Object> responseMap = response.getEmbedded()
        ArrayList responseVOs = (ArrayList)responseMap.get("_embedded")
        responseVOs == [vo]
    }

    def "deleteTreatmentRegimenVersionProcedure"() {
        given:
        int treatmentRegimenVersionID = 55
        TreatmentRegimenVersionProcedureVO vo = new TreatmentRegimenVersionProcedureVO(treatmentRegimenVersionID: treatmentRegimenVersionID)

        when:
        CommonResponse response = controller.deleteTreatmentRegimenVersionProcedure([vo])

        then:
        1 * treatmentRegimenVersionProcedure.delete(vo)
        0 * _

        and:
        Map<String, Object> responseMap = response.getEmbedded()
        ArrayList responseVOs = (ArrayList)responseMap.get("_embedded")
        responseVOs == [vo]
    }

    def "getTreatmentRegimenTraversal"() {
        given:
        int diseaseTraversalID = 1234
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        qp.addQueryFilter(new QueryFilter(FieldConstants.DISEASETRAVERSALID, diseaseTraversalID))
        List<RegimenTraversalViewVO> voList = new ArrayList<>()
        voList.add(new RegimenTraversalViewVO(diseaseTraversalID: diseaseTraversalID))

        when:
        CommonResponse response = controller.getTreatmentRegimenTraversal(qp)

        then:
        1 * regimenTraversalView.listActive(qp) >> voList
        1 * regimenTraversalView.count(qp) >> voList.size()
        0 * _

        and:
        Map<String, Object> responseMap = response.getEmbedded()
        ArrayList responseVOs = (ArrayList)responseMap.get("_embedded")
        responseVOs == voList
    }

    def 'getTreatmentRegimenWithProcedureCodes'(){
        given:
        int diseaseTraversalID = 1
        int customerID = 1

        when:
        CommonResponse response = controller.getTreatmentRegimensWithProcedureCodes(diseaseTraversalID,customerID)

        then:
        1 * regimenTraversalView.listActiveByTraversalID(diseaseTraversalID,customerID) >> []
        0 * _

        and:
        response.embedded.get('_embedded') == []
    }

    def 'getTreatmentRegimenTraversals'(){
        given:
        int diseaseTraversalID = 1
        int treatmentRegimenVersionID = 2
        int customerID = 1
        System.setProperty(MultiPayerConstants.APPROVAL_TYPE, customerID.toString())
        RegimenTraversalViewVO vo = new RegimenTraversalViewVO()

        when:
        CommonResponse response = controller.getTreatmentRegimen(diseaseTraversalID, treatmentRegimenVersionID)

        then:
        1 * regimenTraversalView.readByTraversalIDAndVersionID(diseaseTraversalID, treatmentRegimenVersionID) >> vo
        0 * _

        and:
        response.embedded.get('_embedded') == vo
    }

    def "getNewDrug"() {
        given:
        int newProcedureID = 1234
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        qp.addQueryFilter(new QueryFilter(FieldConstants.NEWPROCEDUREID, newProcedureID))
        NewProcedureViewVO vo = new NewProcedureViewVO(newProcedureID: newProcedureID)

        when:
        CommonResponse response = controller.getNewDrug(qp)

        then:
        1 * newProcedureView.applyClientFilter(qp) >> qp
        1 * newProcedureView.list(qp) >> [vo]
        1 * newProcedureView.count(qp) >> [vo].size()
        0 * _

        and:
        Map<String, Object> responseMap = response.getEmbedded()
        ArrayList responseVOs = (ArrayList)responseMap.get("_embedded")
        responseVOs == [vo]
    }

    def "getDrugException"() {
        given:
        int treatmentProcAuthRuleID = 1234
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        qp.addQueryFilter(new QueryFilter(FieldConstants.TREATMENTREGIMENID, treatmentProcAuthRuleID))
        DrugExceptionsViewVO vo = new DrugExceptionsViewVO(treatmentProcAuthRuleID: treatmentProcAuthRuleID)

        when:
        CommonResponse response = controller.getDrugException(qp)

        then:
        1 * drugExceptionsView.listWithExceptions(qp) >> [vo]
        1 * drugExceptionsView.count(qp) >> [vo].size()
        0 * _

        and:
        Map<String, Object> responseMap = response.getEmbedded()
        ArrayList responseVOs = (ArrayList)responseMap.get("_embedded")
        responseVOs == [vo]
    }

    def "getSupportiveDrug"() {
        given:
        int treatmentSuppCareProcedureID = 1234
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        qp.addQueryFilter(new QueryFilter(FieldConstants.TREATMENTSUPPCAREPROCEDUREID, treatmentSuppCareProcedureID))
        TreatmentSupportiveCareProcedureVO vo = new TreatmentSupportiveCareProcedureVO(treatmentSuppCareProcedureID: treatmentSuppCareProcedureID)

        when:
        CommonResponse response = controller.getSupportiveDrug(qp)

        then:
        1 * treatmentSupportiveCareProcedure.searchSupportiveDrugs(qp) >> [vo]
        1 * treatmentSupportiveCareProcedure.count(qp) >> [vo].size()
        0 * _

        and:
        response.embedded.get('_embedded') == [vo]
    }

    def 'saveSupportiveDrug'(){
        given:
        List<TreatmentSupportiveCareProcedureVO> procedureVOs = [new TreatmentSupportiveCareProcedureVO(treatmentSuppCareProcedureID: 12, updateVersion: 0)]

        when:
        CommonResponse response = controller.saveSupportiveDrug(procedureVOs)

        then:
        1 * treatmentSupportiveCareProcedure.saveSupportiveProcedure(procedureVOs[0])
        0 * _

        and:
        response.embedded.get('_embedded') == procedureVOs
    }

    def 'determineTraversalFromAssessment'(){
        given:
        int assessmentID = 1
        DiseaseTraversalDO data = new DiseaseTraversalDO()

        when:
        CommonResponse response = controller.determineTraversalFromAssessmentID(assessmentID)

        then:
        1 * diseaseTraversalHelper.determineTraversal(assessmentID) >> data
        0 * _

        and:
        response.embedded.get('_embedded') == data
    }

    def 'saveNewDrug'(){
        given:
        List<NewProcedureVO> voList = [new NewProcedureVO()]

        when:
        CommonResponse response = controller.saveNewDrug(voList)

        then:
        1 * newProcedure.save(voList.first())
        0 * _

        and:
        response.embedded.get('_embedded') == voList
    }

    def 'saveDrugException'(){
        given:
        List<TreatmentProcedureAuthorizationRuleVO> voList = [new TreatmentProcedureAuthorizationRuleVO()]

        when:
        CommonResponse response = controller.saveDrugException(voList)

        then:
        1 * treatmentProcedureAuthorizationRule.saveCascading(voList.first())
        0 * _

        and:
        response.embedded.get('_embedded') == voList
    }

    def 'deleteNewDrug'(){
        given:
        List<NewProcedureVO> voList = [new NewProcedureVO()]

        when:
        CommonResponse response = controller.deleteNewDrug(voList)

        then:
        1 * newProcedure.delete(voList.first())
        0 * _

        and:
        response.embedded.get('_embedded') == voList
    }

    def 'deleteSupportiveDrug'(){
        given:
        List<TreatmentSupportiveCareProcedureVO> voList = [new TreatmentSupportiveCareProcedureVO()]

        when:
        CommonResponse response = controller.deleteSupportiveDrug(voList)

        then:
        1 * treatmentSupportiveCareProcedure.deleteCascading(voList.first())
        0 * _

        and:
        response.embedded.get('_embedded') == voList
    }

    def 'deleteDrugException'(){
        given:
        List<TreatmentProcedureAuthorizationRuleVO> voList = [new TreatmentProcedureAuthorizationRuleVO()]

        when:
        CommonResponse response = controller.deleteDrugException(voList)

        then:
        1 * treatmentProcedureAuthorizationRule.delete(voList.first())
        0 * _

        and:
        response.embedded.get('_embedded') == voList
    }

    def 'getClinicalVariablesForDiseaseType'(){
        given:
        String diseaseType = 'disease'
        List<DiseaseTraversalClinicalVariableVO> voList = [new DiseaseTraversalClinicalVariableVO()]

        when:
        CommonResponse response = controller.getClinicalVariablesForDiseaseType(diseaseType)

        then:
        1 * clinicalVariable.listDistinctByDiseaseType(diseaseType) >> voList
        0 * _

        and:
        response.embedded.get('_embedded') == voList
    }

    def 'mapClinicalVariableTypeValues'(){
        given:
        String diseaseType = 'disease'
        String statusType = '01'
        DiseaseTraversalVariableVersionDO traversalVariableVersionDO = new DiseaseTraversalVariableVersionDO(diseaseTraversalVersionVO: new DiseaseTraversalVersionVO(), clinicalVariableTypeValuesMap: [:])

        when:
        CommonResponse response = controller.mapClinicalVariableTypeValues(diseaseType,statusType)

        then:
        1 * diseaseTraversalAssessmentVariable.mapClinicalVariableTypeValues(diseaseType,statusType) >> traversalVariableVersionDO
        0 * _

        and:
        response.embedded.get('_embedded') == traversalVariableVersionDO
    }

    def 'latestVerStatusByDiseaseType'() {
        given:
        String diseaseType = 'disease'
        DiseaseTraversalVersionVO diseaseTraversalVersionVO = new DiseaseTraversalVersionVO(diseaseTraversalVersionID: 01,versionStatusType: '3')

        when:
        CommonResponse response = controller.latestVerStatusByDiseaseType(diseaseType)

        then:
        1 * diseaseTraversalVersion.readMostRecentByDiseaseTypeAndVersionStatusTypes(diseaseType, SpclCareReferenceConstants.VERSIONSTATUSTYPE_LIST) >> diseaseTraversalVersionVO
        0 * _

        and:
        response.embedded.get('_embedded') == diseaseTraversalVersionVO
    }


    def 'approveTraversal'() {
        given:
        DiseaseTraversalVersionVO diseaseTraversalVersionVO = new DiseaseTraversalVersionVO(diseaseTraversalVersionID: 01, versionStatusType: '01')

        when:
        CommonResponse response = controller.approveTraversal(diseaseTraversalVersionVO)

        then:
        1 * diseaseTraversalVersion.approveTraversal(diseaseTraversalVersionVO)
        0 * _

        and:
        response
    }

    def 'deployTraversal'() {
        given:
        DiseaseTraversalVersionVO diseaseTraversalVersionVO = new DiseaseTraversalVersionVO(diseaseTraversalVersionID: 01, versionStatusType: '01')

        when:
        CommonResponse response = controller.deployTraversal(diseaseTraversalVersionVO)

        then:
        1 * diseaseTraversalVersion.deployTraversal(diseaseTraversalVersionVO)
        0 * _

        and:
        response
    }


    def 'rejectTraversalByDiseaseType'(){
        given:
       DiseaseTraversalVersionVO diseaseTraversalVersionVO = new DiseaseTraversalVersionVO(diseaseTraversalVersionID: 01,versionStatusType: '01')

        when:
        CommonResponse response = controller.rejectTraversal(diseaseTraversalVersionVO)

        then:
        1 * diseaseTraversalVersion.rejectTraversal(diseaseTraversalVersionVO)
        0 * _

        and:
        response
    }

    @Unroll()
    def 'linkOrUnlinkTraversalAndRegimen: #testCase'(){
        given:
        int treatmentRegimenID = 1234
        int diseaseTraversalID = 1234

        when:
        CommonResponse response = controller.linkOrUnlinkTraversalAndRegimen(treatmentRegimenID, diseaseTraversalID, linked)

        then:
        unlinkCall * diseaseTraversalTreatmentRegimen.unlinkRegimenAndTraversal(treatmentRegimenID, diseaseTraversalID)
        linkCall * diseaseTraversalTreatmentRegimen.linkRegimenAndTraversal(treatmentRegimenID, diseaseTraversalID)
        0 * _

        and:
        response

        where:
        testCase    | linked | unlinkCall | linkCall
        'linked'    | true   | 1          | 0
        'unlinked'  | false  | 0          | 1
    }

    @Unroll()
    def 'bulkLinkTraversal: #testCase'(){
        given:
        int treatmentRegimenID = 1234
        int diseaseTraversalID = 1234
        DiseaseTraversalVO vo = new DiseaseTraversalVO(diseaseTraversalID: diseaseTraversalID)

        when:
        CommonResponse response = controller.bulkLinkTraversal(treatmentRegimenID, linked, [vo])

        then:
        unlinkCall * diseaseTraversalTreatmentRegimen.unlinkRegimenAndTraversal(treatmentRegimenID, diseaseTraversalID)
        linkCall * diseaseTraversalTreatmentRegimen.linkRegimenAndTraversal(treatmentRegimenID, diseaseTraversalID)
        0 * _

        and:
        response

        where:
        testCase    | linked | unlinkCall | linkCall
        'linked'    | true   | 1          | 0
        'unlinked'  | false  | 0          | 1
    }

    @Unroll()
    def 'bulkEditVariableValue: #testCase'() {
        given:
        BulkEditTraversalDO bulkEditTraversalDO = new BulkEditTraversalDO()

        when:
        CommonResponse response = controller.bulkEditVariableValue(bulkEditTraversalDO)

        then:
        1 * diseaseTraversalHelper.bulkEditTraversalValue(bulkEditTraversalDO)
        0 * _

        and:
        response
    }

    @Unroll()
    def 'bulkEditVariableType: #testCase'() {
        given:
        BulkEditTraversalDO bulkEditTraversalDO = new BulkEditTraversalDO(fromVariableType: "set", toVariableType: "get")

        when:
        CommonResponse response = controller.bulkEditVariableType(bulkEditTraversalDO)

        then:
        1 * diseaseTraversalHelper.bulkEditTraversalType(bulkEditTraversalDO, bulkEditTraversalDO.fromVariableType, bulkEditTraversalDO.toVariableType)
        0 * _

        and:
        response
    }

    @Unroll()
    def 'bulkEditAuthDuration: #testCase'() {
        given:
        BulkEditTraversalDO bulkEditTraversalDO = new BulkEditTraversalDO(fromVariableType: "set", toVariableType: "get")

        when:
        CommonResponse response = controller.bulkEditAuthDuration(bulkEditTraversalDO)

        then:
        1 * diseaseTraversalHelper.bulkEditAuthDuration(bulkEditTraversalDO)
        0 * _

        and:
        response
    }

    @Unroll()
    def 'addTraversal: #testCase'() {
        given:
        DiseaseTraversalProcedureVO diseaseTraversalProcedureVO = new DiseaseTraversalProcedureVO()

        when:
        CommonResponse response = controller.addTraversal(diseaseTraversalProcedureVO)

        then:
        1 * diseaseTraversalHelper.addTraversal(diseaseTraversalProcedureVO)
        0 * _
    }

    @Unroll()
    def 'determineTraversal: #testCase'() {
        given:
        TraversalDeterminationDO traversalDeterminationDO = new TraversalDeterminationDO()

        when:
        CommonResponse response = controller.determineTraversal(traversalDeterminationDO)

        then:
        1 * diseaseTraversalHelper.determineTraversal(traversalDeterminationDO)
        0 * _

        and:
        response
    }

    def 'traversalDocument'() {
        given:
        TraversalLinkageDO linkageDO = new TraversalLinkageDO(documentID: 'testID')

        when:
        CommonResponse response = controller.traversalDocument(linkageDO)

        then:
        1 * traversalHelper.deleteTraversalDocument(linkageDO)
        0 * _

        and:
        response
    }

//    @Ignore // this is passing when run locally, but fails in Jenkins
//    def "traversalSpreadsheet"() {
//        given:
//        ByteArrayOutputStream baos = new ByteArrayOutputStream()
//        Workbook wb = getFile()
//        wb.write(baos)
//        baos.close()
//        String testFile = 'testFile'
//        baos.toByteArray()
//        List<MultipartFile> files = [new MockMultipartFile(testFile, (testFile + '.xlsx'), 'excel', baos.toByteArray())]
//        wb.close()
//        long traversalVersionID = 55500321
//        String fileName = StringUtils.EMPTY
//        Workbook wbTest = null
//
//        when:
//        controller.traversalSpreadsheet(files, traversalVersionID)
//
//        then:
//        1 * traversalHelper.importSpreadsheet( { wbTest = it }, _, { fileName = it }, _)
//        1 * diseaseTraversalVersion.read(traversalVersionID) >> new DiseaseTraversalVersionVO(diseaseTraversalVersionID: traversalVersionID)
//        1 * diseaseTraversalVersion.update(_ as DiseaseTraversalVersionVO)
//        0 * _
//
//        and:
//        StringUtils.isNotBlank(fileName)
//        fileName.contains(testFile + '.xlsx')
//        wbTest
//    }

    def "traversalSpreadsheet with invalid file name"() {
        given:
        ByteArrayOutputStream baos = new ByteArrayOutputStream()
        getFile().write(baos)

        baos.toByteArray()
        List<MultipartFile> files = [new MockMultipartFile('testFile', baos.toByteArray())]
        long traversalVersionID = 55500321

        when:
        controller.traversalSpreadsheet(files, traversalVersionID)

        then:
        1 * temporarySystemSetting.getIntSetting(SpclCareConstants.IMPORT_TRAVERSAL_SPREADSHEET_FILE_SIZE_LIMIT) >> 1500000
        1 * diseaseTraversalVersion.read(traversalVersionID) >> new DiseaseTraversalVersionVO(diseaseTraversalVersionID: traversalVersionID)
        1 * diseaseTraversalVersion.update(_ as DiseaseTraversalVersionVO)
        0 * _

        and:
        thrown(UhgRuntimeException)
    }

    private static Workbook getFile() {
        Workbook wb = new HSSFWorkbook()
        HSSFSheet sheet = wb.createSheet('test cancer')

        Row row = sheet.createRow(0)
        row.createCell(0).setCellValue('Primary Cancer')
        row.createCell(1).setCellValue('Histology')
        row.createCell(2).setCellValue('Line of Therapy')
        row.createCell(3).setCellValue('Indication')
        row.createCell(4).setCellValue('CD20')
        row.createCell(5).setCellValue('T3151')
        row.createCell(6).setCellValue('Regimen ID')
        row.createCell(7).setCellValue('Payer')
        row.createCell(8).setCellValue('Pathway')
        row.createCell(9).setCellValue('Auto-Approve')

        Row row1 = sheet.createRow(1)
        row1.createCell(0).setCellValue('Acute Lymphoblastic Leukemia')
        row1.createCell(1).setCellValue('Serous')
        row1.createCell(2).setCellValue('Recurrent')
        row1.createCell(3).setCellValue('Adjuvant; Recurrent')
        row1.createCell(4).setCellValue('Negative; Positive; Unknown')
        row1.createCell(5).setCellValue('Negative; Positive; Unknown')
        row1.createCell(6).setCellValue('1')
        row1.createCell(7).setCellValue('UHC')
        row1.createCell(8).setCellValue('yes')
        row1.createCell(9).setCellValue('yes')

        wb
    }
}
