package com.optum.app.shared.documentManager.controller

import com.optum.app.ocm.controller.support.CommonResponse
import com.optum.app.shared.documentManager.businesslogic.DocumentManagerService
import com.optum.rf.common.featureflag.util.FeatureFlagManager
import com.optum.rf.common.featureflag.util.FeatureFlagUtility
import org.springframework.http.ResponseEntity
import org.springframework.web.multipart.MultipartFile
import spock.lang.Specification

/**
 * Created by calbrit1 on 10/9/18.
 */
class DocumentManagerControllerSpec extends Specification {
    DocumentManagerController documentManagerController
    DocumentManagerService documentManagerService = Mock(DocumentManagerService)
    FeatureFlagManager featureFlagManager = Mock(FeatureFlagManager)

    def setup(){
        documentManagerController = new DocumentManagerController()
        documentManagerController.documentManagerService = documentManagerService
        FeatureFlagUtility.featureFlagManager = featureFlagManager
    }

    def "delete Attachment"() {
        given:
        long docReqId = 5555L
        ResponseEntity responseEntity1

        when:
        ResponseEntity responseEntity = documentManagerController.deleteAttachment(docReqId)

        then:
        1 * documentManagerService.deleteAttachment(docReqId) >> responseEntity1
        responseEntity1 == responseEntity

    }

    def "get Attachment by HSC"() {
        given:
        long hscID = 5555L
        CommonResponse commonResponse = new CommonResponse()

        when:
        CommonResponse commonResponse1 = documentManagerController.getAttachmentsByHscID(hscID)

        then:
        1 * documentManagerService.getAttachmentsByHSC(hscID) >> commonResponse
        commonResponse == commonResponse1
    }

    def "delete  Attachment by HSC ID"() {
        given:
        long hscID = 5555L
        ResponseEntity responseEntity

        when:
        ResponseEntity responseEntity1 = documentManagerController.deleteAttachmentsByHscID(hscID)

        then:
        1 * documentManagerService.deleteAttachmentsByHSC(hscID) >> responseEntity
        responseEntity1 == responseEntity
    }

    def "create Document"(){
        given:
        List<MultipartFile> file
        long hscID = 5555L
        String userID = "userId"
        long rowNumber = 5
        CommonResponse commonResponse1 = new CommonResponse()
        boolean featureFlag = false

        when:
        CommonResponse commonResponse = documentManagerController.createDocument(file, hscID, userID, rowNumber)

        then:
        1 * featureFlagManager.isActive(_) >> featureFlag
        1 * documentManagerService.createDocument(file, hscID, userID) >> commonResponse1
        0 * _

        and:
        commonResponse1 == commonResponse
        commonResponse1.getCustomData() == [rowNumber]

    }
}

