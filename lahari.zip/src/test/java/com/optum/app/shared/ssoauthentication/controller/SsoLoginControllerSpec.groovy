package com.optum.app.shared.ssoauthentication.controller

import com.amazonaws.auth.BasicAWSCredentials
import com.amazonaws.services.s3.AmazonS3Client
import com.amazonaws.services.s3.model.GetObjectRequest
import com.amazonaws.services.s3.model.S3Object
import com.optum.app.ocm.common.util.SsoViewMapping
import com.optum.app.ocm.customer.businesslogic.CustomerUser
import com.optum.app.ocm.customer.businesslogic.CustomerUserView
import com.optum.app.ocm.ref.businesslogic.CustomerReference
import com.optum.app.shared.common.messages.SpclCareMessages
import com.optum.app.shared.constants.MultiPayerConstants
import com.optum.app.shared.constants.SpclCareFeatureFlagConstants
import com.optum.app.shared.hsc.businesslogic.HscHelper
import com.optum.app.shared.microservice.businesslogic.MemberDetailsProcessor
import com.optum.app.shared.ssoauthentication.data.OcmSsoData
import com.optum.app.shared.ssoauthentication.data.OcmSsoProviderData
import com.optum.app.shared.ssoauthentication.helper.OcmSsoHelper
import com.optum.app.shared.ssoauthentication.helper.SSOActivityLog
import com.optum.app.shared.ssoauthentication.helper.impl.OcmSsoHelperImpl
import com.optum.rf.common.constants.CommonFieldConstants
import com.optum.rf.common.exception.RestrictedAccessException
import com.optum.rf.common.featureflag.util.FeatureFlagManager
import com.optum.rf.common.featureflag.util.FeatureFlagUtility
import com.optum.rf.common.security.data.UserProfileVO
import com.optum.rf.common.settings.businesslogic.SystemSettingsPingFederatePartner
import com.optum.rf.common.settings.businesslogic.SystemSettingsWebService
import com.optum.rf.common.settings.businesslogic.impl.SystemSettingsPingFederatePartnerImpl
import com.optum.rf.common.settings.data.SystemSettingsPingFederatePartnerVO
import com.optum.rf.common.settings.data.SystemSettingsWebServiceVO
import com.optum.rf.common.webservice.logging.businesslogic.WebServiceLog
import com.optum.rf.common.webservice.security.UserPermissionGroupProvider
import com.optum.rf.core.util.Environment
import com.optum.rf.core.util.EnvironmentImpl
import com.optum.rf.dao.data.ValueObject
import com.optum.rf.dao.data.message.ErrorMessage
import com.optum.rf.dao.exception.UhgRuntimeException
import com.optum.rf.dao.security.UserSecurity
import com.optum.rf.test.core.mock.http.MockHttpSession
import com.optum.rf.test.core.spock.BaseReadLogicSpecification
import com.optum.rf.web.constants.WebConstants
import com.optum.app.common.customer.data.CustomerUserViewVO
import com.optum.app.common.hsr.businesslogic.Hsc
import com.optum.app.common.hsr.data.HscVO
import com.optum.app.shared.providergroup.businesslogic.ProviderGroup
import com.optum.app.icue.sso.constants.SsoConstants
import com.optum.app.icue.sso.messages.SsoMessages
import com.optum.app.ocm.common.security.businesslogic.AppUser
import com.optum.app.ocm.common.security.data.AppUserVO
import org.springframework.mock.web.MockHttpServletRequest
import org.springframework.mock.web.MockHttpServletResponse
import org.springframework.web.client.HttpClientErrorException
import org.springframework.web.servlet.ModelAndView

import javax.naming.AuthenticationException
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse
import javax.servlet.http.HttpSession

/**
 * Created by dbrow147 on 7/20/2018.
 */
class SsoLoginControllerSpec extends BaseReadLogicSpecification {
    SsoLoginController controller
    OcmSsoData ocmSsoData
    OcmSsoHelper ocmSsoHelper
    SystemSettingsPingFederatePartner systemSettingsPingFederatePartner
    SystemSettingsPingFederatePartnerVO systemSettingsPingFederatePartnerVO
    Map ssoInfo
    UserSecurity userSecurity
    HttpSession httpSession
    GetObjectRequest getObjectRequest
    OcmSsoProviderData ocmSsoProviderData
    Environment environment
    S3Object s3Object
    AmazonS3Client amazonS3Client
    BasicAWSCredentials basicAWSCredentials
    String userID
    String domain
    AppUser appUser
    UserPermissionGroupProvider userPermissionGroupProvider
    CustomerUserView customerUserView
    WebServiceLog webServiceLog
    HscHelper hscHelper
    Hsc hsc
    ProviderGroup providerGroup = Mock(ProviderGroup)
    MemberDetailsProcessor memberDetailsProcessor
    SSOActivityLog ssoActivityLog
    CustomerReference customerReference = Mock(CustomerReference)
    OcmSsoHelperImpl ocmSsoHelperImpl
    FeatureFlagManager featureFlagManager

    def setup() {
        ocmSsoHelper = Mock(OcmSsoHelper)
        ocmSsoData = Mock(OcmSsoData)
        ssoInfo = Mock(Map)
        userSecurity = Mock(UserSecurity)
        httpSession = Mock(HttpSession)
        getObjectRequest = Mock(GetObjectRequest)
        environment = Mock(Environment)
        systemSettingsPingFederatePartner = Mock(SystemSettingsPingFederatePartnerImpl)
        systemSettingsPingFederatePartnerVO=Mock(SystemSettingsPingFederatePartnerVO)
        s3Object = Mock(S3Object)
        amazonS3Client = Mock(AmazonS3Client)
        controller = new SsoLoginController(ocmSsoHelper: ocmSsoHelper, environment: environment)
        userPermissionGroupProvider = Mock(UserPermissionGroupProvider)
        customerUserView = Mock(CustomerUserView)
        webServiceLog = Mock(WebServiceLog)
        hscHelper = Mock(HscHelper)
        hsc = Mock(Hsc)
        memberDetailsProcessor = Mock(MemberDetailsProcessor)
        ssoActivityLog = Mock(SSOActivityLog)
        ocmSsoHelperImpl = Mock(OcmSsoHelperImpl)
        ocmSsoHelperImpl.customerReference = customerReference
        ocmSsoHelperImpl.providerGroup = providerGroup
        FeatureFlagUtility.featureFlagManager = Mock(FeatureFlagManager)

    }


    def "Test getSuccessViewPath"() {
        when:
        String viewPath = controller.getSuccessViewPath(new HashMap())

        then:
        SsoViewMapping.OCM_OPTUM_LANDING_PAGE.getPath() == viewPath
        0 * _
    }

    def "Test getErrorViewPath"() {
        when:
        String viewPath = controller.getErrorViewPath(new HashMap())

        then:
        SsoViewMapping.OPTUM_SSO_ERROR.getPath() == viewPath
        0 * _
    }


    def "Test validateSSOAttributes"() {
        given:
        AppUserVO result = new AppUserVO()
        AppUserVO response = new AppUserVO()

        Map map = new HashMap()
        map.put("uuid", "75533cb8-99d7-47eb-9b98-776d2efae3e7")
        map.put(SsoConstants.OPTUM_ID, "OptumID")
        map.put(SsoConstants.USER_FIRST_NAME, "Dan")
        map.put(SsoConstants.USER_LAST_NAME, "Josh")
        map.put(SsoConstants.UHCONLINE_SSO_TOKEN_EMULATED_USERUUID, "uuid")
        map.put(SsoConstants.UHCONLINE_SSO_TOKEN_IS_SUPERUSER, false)

        when:
        controller.validateSSOAttributes(map, new ValueObject())
        result.setLastLoginDate(response.getLastLoginDate())

        then:
        1 * ocmSsoHelper.createUserDetailsFromSSO(_) >> response
        1 * ocmSsoHelper.createUserCustomerFromSSO(_)
        2 * FeatureFlagUtility.getManager().isActive(SpclCareFeatureFlagConstants.ENABLE_OPTUM_CARE_USER_AUTH) >> false
        0 * _

        and:
        result == response
    }

    def "Test validateSSOAttributes ICUE"() {
        given:
        AppUserVO result = new AppUserVO()
        AppUserVO response = new AppUserVO()

        Map map = new HashMap()
        map.put("uuid", "75533cb8-99d7-47eb-9b98-776d2efae3e7")
        map.put(SsoConstants.OPTUM_ID, "OptumID")
        map.put(SsoConstants.HSC_ID, "123567")
        map.put(SsoConstants.USER_FIRST_NAME, "Dan")
        map.put(SsoConstants.USER_LAST_NAME, "Josh")
        map.put(SsoConstants.UHCONLINE_SSO_TOKEN_EMULATED_USERUUID, "uuid")
        map.put(SsoConstants.UHCONLINE_SSO_TOKEN_IS_SUPERUSER, false)

        when:
        controller.validateSSOAttributes(map, new ValueObject())
        result.setLastLoginDate(response.getLastLoginDate())

        then:
        1 * ocmSsoHelper.createUserDetailsFromSSO(_) >> response
        1 * ocmSsoHelper.createUserCustomerFromSSO(_)
        2 * FeatureFlagUtility.getManager().isActive(SpclCareFeatureFlagConstants.ENABLE_OPTUM_CARE_USER_AUTH) >> false
        0 * _

        and:
        result == response
    }

    def "Test validateSSOAttributes ICUE exception"() {
        given:
        AppUserVO result = new AppUserVO()
        AppUserVO response = new AppUserVO()

        Map map = new HashMap()
        map.put("uuid", "75533cb8-99d7-47eb-9b98-776d2efae3e7")
        map.put(SsoConstants.OPTUM_ID, "OptumID")
        map.put(SsoConstants.HSC_ID, "123567")
        map.put(SsoConstants.USER_FIRST_NAME, "Dan")
        map.put(SsoConstants.USER_LAST_NAME, "Josh")
        map.put(SsoConstants.UHCONLINE_SSO_TOKEN_EMULATED_USERUUID, "uuid")
        map.put(SsoConstants.UHCONLINE_SSO_TOKEN_IS_SUPERUSER, false)

        when:
        controller.validateSSOAttributes(map, new ValueObject())
        ocmSsoHelper.createUserDetailsFromSSO(_)

        then:
        thrown UhgRuntimeException
    }

    def "Test validateSSOAttributes invalid UUID"() {
        given:
        ValueObject valueObject = new ValueObject()
        Map map = new HashMap()
        map.put("uuid", "75533c&**b8-99d7-47eb-9b98-776d2efae3e7")
        map.put(SsoConstants.OPTUM_ID, "OptumID")
        map.put(SsoConstants.USER_FIRST_NAME, "Dan")
        map.put(SsoConstants.USER_LAST_NAME, "Josh")
        map.put(SsoConstants.UHCONLINE_SSO_TOKEN_EMULATED_USERUUID, "uuid")
        map.put(SsoConstants.UHCONLINE_SSO_TOKEN_IS_SUPERUSER, false)

        when:
        controller.validateSSOAttributes(map, valueObject)

        then:
        valueObject.getGlobalMessages().size() == 1
        valueObject.getGlobalMessages().getAt(0).equals(SpclCareMessages.ERR_SSO_UUID_INVALID)
    }

    def "Test buildUserProfileVO ICUE"() {
        given:
        controller.setHscHelper(hscHelper)
        controller.setHsc(hsc)
        UserProfileVO userProfileVO
        ValueObject valueObject = new ValueObject()
        Map map = new HashMap()
        map.put("uuid", "75533c&**b8-99d7-47eb-9b98-776d2efae3e7")
        map.put(SsoConstants.OPTUM_ID, "OptumID")
        map.put(SsoConstants.HSC_ID, "123567")
        map.put(SsoConstants.USER_FIRST_NAME, "Dan")
        map.put(SsoConstants.USER_LAST_NAME, "Josh")
        map.put(SsoConstants.UHCONLINE_SSO_TOKEN_EMULATED_USERUUID, "uuid")
        map.put(SsoConstants.UHCONLINE_SSO_TOKEN_IS_SUPERUSER, false)

        when:
        hsc.read(_) >> new HscVO(memberID: 1234)
        userProfileVO = controller.buildUserProfileVO(controller.buildSsoData(map))

        then:
        userProfileVO.getLastName().equals("Josh")
        userProfileVO.getUserGroupID().equals(controller.ICUE_USER)
    }

    def "Test buildUserProfileVO PAAN empty HSCID"() {
        given:
        controller.setHscHelper(hscHelper)
        controller.setHsc(hsc)
        UserProfileVO userProfileVO
        ValueObject valueObject = new ValueObject()
        Map map = new HashMap()
        map.put("uuid", "75533c&**b8-99d7-47eb-9b98-776d2efae3e7")
        map.put(SsoConstants.OPTUM_ID, "OptumID")
        map.put(SsoConstants.HSC_ID, "")
        map.put(SsoConstants.USER_FIRST_NAME, "Dan")
        map.put(SsoConstants.USER_LAST_NAME, "Josh")
        map.put(SsoConstants.UHCONLINE_SSO_TOKEN_EMULATED_USERUUID, "uuid")
        map.put(SsoConstants.UHCONLINE_SSO_TOKEN_IS_SUPERUSER, false)

        when:
        hsc.read(_) >> new HscVO(memberID: 1234)
        userProfileVO = controller.buildUserProfileVO(controller.buildSsoData(map))

        then:
        userProfileVO.getLastName().equals("Josh")
        userProfileVO.getUserGroupID().equals(controller.PROVIDER)
    }

    def "Test buildUserProfileVO PAAN"() {
        given:
        controller.setHscHelper(hscHelper)
        controller.setHsc(hsc)
        UserProfileVO userProfileVO
        ValueObject valueObject = new ValueObject()
        Map map = new HashMap()
        map.put("uuid", "75533c&**b8-99d7-47eb-9b98-776d2efae3e7")
        map.put(SsoConstants.OPTUM_ID, "OptumID")
        map.put(SsoConstants.USER_FIRST_NAME, "Dan")
        map.put(SsoConstants.USER_LAST_NAME, "Josh")
        map.put(SsoConstants.UHCONLINE_SSO_TOKEN_EMULATED_USERUUID, "uuid")
        map.put(SsoConstants.UHCONLINE_SSO_TOKEN_IS_SUPERUSER, false)

        when:
        hsc.read(_) >> new HscVO(memberID: 1234)
        userProfileVO = controller.buildUserProfileVO(controller.buildSsoData(map))

        then:
        userProfileVO.getLastName().equals("Josh")
        userProfileVO.getUserGroupID().equals(controller.PROVIDER)
    }

    def "Test validateSSOAttributes null map"() {
        given:
        ValueObject valueObject = new ValueObject()

        when:
        controller.validateSSOAttributes(null, valueObject)

        then:
        valueObject.getGlobalMessages().size() == 1
        valueObject.getGlobalMessages().getAt(0).equals(new ErrorMessage(SsoMessages.ERR_SSO_PING_FEDERATE_TOKEN))
    }

    def "Test readSSOAttributes null amazon client exception"() {
        given:
        Environment env = new EnvironmentImpl()
        env.environment = Environment.Env.DEVELOPMENT
        AmazonS3Client s3 = new AmazonS3Client()

        when:
        controller.setEnvironment(env)
        controller.systemSettingsWebService = Mock(SystemSettingsWebService)
        controller.systemSettingsPingFederatePartner = Mock(SystemSettingsPingFederatePartner)
        controller.systemSettingsWebService.read(_) >> new SystemSettingsWebServiceVO(wsUrl: "wsUrl")
        controller.systemSettingsPingFederatePartner.read(_) >> new SystemSettingsPingFederatePartnerVO(pingFederateConfigFileName: "file",pingFederatePartnerID: "ptId",pingFederateUrl: "pingFed",pingFederateTargetUrl: "target")

        controller.readSSOAttributes(Mock(MockHttpServletRequest))

        then:
        thrown UhgRuntimeException
    }

    def "Test readSSOAttributes null sso attributes"() {
        given:
        Environment env = new EnvironmentImpl()
        env.environment = Environment.Env.DEVELOPMENT
        AmazonS3Client s3 = new AmazonS3Client()

        when:
        controller.setEnvironment(env)
        controller.systemSettingsWebService = Mock(SystemSettingsWebService)
        controller.systemSettingsPingFederatePartner = Mock(SystemSettingsPingFederatePartner)
        controller.systemSettingsWebService.read(_) >> new SystemSettingsWebServiceVO(wsUrl: "wsUrl")
        controller.systemSettingsPingFederatePartner.read(_) >> new SystemSettingsPingFederatePartnerVO(pingFederateConfigFileName: "file",pingFederatePartnerID: "ptId",pingFederateUrl: "pingFed",pingFederateTargetUrl: "target")
        controller.useAmazonS3ToParseSsoAttributesFromSAMLorHardcodeForLocalHost(_) >> new HashMap<>()
        controller.readSSOAttributes(Mock(MockHttpServletRequest))

        then:
        thrown UhgRuntimeException
    }

    def "test null system web service settings"(){

        given:
        SsoLoginController loginController = new SsoLoginController()
        loginController.ssoActivityLog = ssoActivityLog

        when:
        loginController.systemSettingsWebService = Mock(SystemSettingsWebService)
        loginController.handleRequest(Mock(HttpServletRequest), Mock(HttpServletResponse))

        then:
        thrown HttpClientErrorException
    }

    def "test not null system web service settings"(){

        given:
        SsoLoginController loginController = new SsoLoginController()
        loginController.systemSettingsWebService = Mock(SystemSettingsWebService)

        when:
        loginController.systemSettingsWebService.read("awsSSO") >> Mock(SystemSettingsWebServiceVO)
        loginController.handleRequest(Mock(HttpServletRequest), Mock(HttpServletResponse))

        then:
        thrown NullPointerException
    }

    // This is not using the already set login controller due to different testing requirements
    def "test handleRequest"(){
        given:
        System.setProperty(MultiPayerConstants.APPROVAL_TYPE, '1')
        Environment env = new EnvironmentImpl()
        env.environment = Environment.Env.LOCAL
        SsoLoginController loginController = new SsoLoginController()
        OcmSsoHelper ocmSsoHelper = new OcmSsoHelperImpl()
        ocmSsoHelper.customerReference = customerReference
        ocmSsoHelper.setUser(Mock(AppUser))
        ocmSsoHelper.setCustomerUser(Mock(CustomerUser))
        ocmSsoHelper.providerGroup = providerGroup
        ocmSsoHelper.customerUserView = customerUserView
        loginController.setUserPermissionGroupProvider(userPermissionGroupProvider)
        loginController.setOcmSsoHelper(ocmSsoHelper)
        loginController.environment = env
        loginController.systemSettingsWebService = Mock(SystemSettingsWebService)
        loginController.systemSettingsPingFederatePartner = Mock(SystemSettingsPingFederatePartner)
        loginController.systemSettingsWebService.read(_) >> Mock(SystemSettingsWebServiceVO)
        loginController.systemSettingsPingFederatePartner.read(_) >> Mock(SystemSettingsPingFederatePartnerVO)
        loginController.setCustomerUserView(customerUserView)
        loginController.setWebServiceLog(webServiceLog)
        loginController.memberDetailsProcessor = memberDetailsProcessor
        loginController.hscHelper = hscHelper
        loginController.hsc = hsc
        loginController.ssoActivityLog = ssoActivityLog

        when:
        hscHelper.readFormattedHscID(_) >> 1L
        hsc.read(_) >> new HscVO(memberID: 1)
        userPermissionGroupProvider.getUserPermissionGroups(_) >> ["These permissions"].asCollection()
        customerUserView.getActiveByUserID(_) >> [new CustomerUserViewVO(customerID: 1)]
        MockHttpServletRequest request = new MockHttpServletRequest()
        HttpServletResponse response = Mock(MockHttpServletResponse)
        request.setServerName("Test")
        request.setSession(new MockHttpSession())
        request.setParameter(CommonFieldConstants.LOGINDOMAIN, '')
        FeatureFlagUtility.getManager()?.isActive(SpclCareFeatureFlagConstants.ENABLE_MSE_BEHAVIOUR) >> false


        ModelAndView responseMV = loginController.handleRequest(request, response)

        then:
        responseMV.getViewName().equals(SsoViewMapping.OCM_OPTUM_LANDING_PAGE.getPath())
    }

    def "test handleRequest handle error"(){
        given:
        Environment env = new EnvironmentImpl()
        env.environment = Environment.Env.LOCAL
        SsoLoginController loginController = new SsoLoginController()
        OcmSsoHelper ocmSsoHelper = new OcmSsoHelperImpl()
        ocmSsoHelper.customerReference = customerReference
        loginController.setUserPermissionGroupProvider(userPermissionGroupProvider)
        loginController.setOcmSsoHelper(ocmSsoHelper)
        loginController.environment = env
        loginController.systemSettingsWebService = Mock(SystemSettingsWebService)
        loginController.systemSettingsPingFederatePartner = Mock(SystemSettingsPingFederatePartner)
        loginController.systemSettingsWebService.read(_) >> Mock(SystemSettingsWebServiceVO)
        loginController.systemSettingsPingFederatePartner.read(_) >> Mock(SystemSettingsPingFederatePartnerVO)
        loginController.setCustomerUserView(customerUserView)
        loginController.setWebServiceLog(webServiceLog)
        loginController.memberDetailsProcessor = memberDetailsProcessor
        loginController.hscHelper = hscHelper
        loginController.ssoActivityLog = ssoActivityLog

        when:
        userPermissionGroupProvider.getUserPermissionGroups(_) >> ["These permissions"].asCollection()
        customerUserView.getActiveByUserID(_) >> [new CustomerUserViewVO(customerID: 1)]
        MockHttpServletRequest request = new MockHttpServletRequest()
        HttpServletResponse response = Mock(MockHttpServletResponse)
        request.setServerName("Test")
        request.setSession(new MockHttpSession())

        ModelAndView responseMV = loginController.handleRequest(request, response)

        then:
        responseMV.getViewName().equals(SsoViewMapping.OPTUM_SSO_ERROR.getPath())
    }

    def "test handleRequest UhgRuntimeException"(){
        given:
        Environment env = new EnvironmentImpl()
        env.environment = Environment.Env.LOCAL
        SsoLoginController loginController = new SsoLoginController()
        OcmSsoHelper ocmSsoHelper = new OcmSsoHelperImpl()
        ocmSsoHelper.customerReference = customerReference
        ocmSsoHelper.setUser(Mock(AppUser))
        loginController.setUserPermissionGroupProvider(userPermissionGroupProvider)
        loginController.setOcmSsoHelper(ocmSsoHelper)
        loginController.environment = env
        loginController.systemSettingsWebService = Mock(SystemSettingsWebService)
        loginController.systemSettingsPingFederatePartner = Mock(SystemSettingsPingFederatePartner)
        loginController.systemSettingsWebService.read(_) >> Mock(SystemSettingsWebServiceVO)
        loginController.systemSettingsPingFederatePartner.read(_) >> Mock(SystemSettingsPingFederatePartnerVO)
        loginController.setCustomerUserView(customerUserView)
        loginController.setWebServiceLog(webServiceLog)
        loginController.memberDetailsProcessor = memberDetailsProcessor
        loginController.hscHelper = hscHelper
        loginController.hsc = hsc
        loginController.ssoActivityLog = ssoActivityLog

        when:
        hscHelper.readFormattedHscID(_) >> 1L
        hsc.read(_) >> new HscVO(memberID: 1)
        userPermissionGroupProvider.getUserPermissionGroups(_) >> {throw new UhgRuntimeException()}
        customerUserView.getActiveByUserID(_) >> [new CustomerUserViewVO(customerID: 1)]
        MockHttpServletRequest request = new MockHttpServletRequest()
        HttpServletResponse response = Mock(MockHttpServletResponse)
        request.setServerName("Test")
        request.setSession(new MockHttpSession())

        ModelAndView responseMV = loginController.handleRequest(request, response)

        then:
        responseMV.getModel().get(WebConstants.REQUEST_ERROR) != null
        responseMV.getViewName().equals(SsoViewMapping.OPTUM_SSO_ERROR.getPath())
    }

    def "test handleRequest RestrictedAccessException"(){
        given:
        Environment env = new EnvironmentImpl()
        env.environment = Environment.Env.LOCAL
        SsoLoginController loginController = new SsoLoginController()
        OcmSsoHelper ocmSsoHelper = new OcmSsoHelperImpl()
        ocmSsoHelper.customerReference = customerReference
        ocmSsoHelper.setUser(Mock(AppUser))
        loginController.setUserPermissionGroupProvider(userPermissionGroupProvider)
        loginController.setOcmSsoHelper(ocmSsoHelper)
        loginController.environment = env
        loginController.systemSettingsWebService = Mock(SystemSettingsWebService)
        loginController.systemSettingsPingFederatePartner = Mock(SystemSettingsPingFederatePartner)
        loginController.systemSettingsWebService.read(_) >> Mock(SystemSettingsWebServiceVO)
        loginController.systemSettingsPingFederatePartner.read(_) >> Mock(SystemSettingsPingFederatePartnerVO)
        loginController.setCustomerUserView(customerUserView)
        loginController.setWebServiceLog(webServiceLog)
        loginController.memberDetailsProcessor = memberDetailsProcessor
        loginController.hscHelper = hscHelper
        loginController.hsc = hsc
        loginController.ssoActivityLog = ssoActivityLog

        when:
        hscHelper.readFormattedHscID(_) >> 1L
        hsc.read(_) >> new HscVO(memberID: 1)
        userPermissionGroupProvider.getUserPermissionGroups(_) >> {throw new RestrictedAccessException()}
        customerUserView.getActiveByUserID(_) >> [new CustomerUserViewVO(customerID: 1)]
        MockHttpServletRequest request = new MockHttpServletRequest()
        HttpServletResponse response = Mock(MockHttpServletResponse)
        request.setServerName("Test")
        request.setSession(new MockHttpSession())

        ModelAndView responseMV = loginController.handleRequest(request, response)

        then:
        responseMV.getModel().get(WebConstants.REQUEST_ERROR) != null
        responseMV.getViewName().equals(SsoViewMapping.OPTUM_SSO_ERROR.getPath())
    }

    def "test handleRequest AuthenticationException"(){
        given:
        Environment env = new EnvironmentImpl()
        env.environment = Environment.Env.LOCAL
        SsoLoginController loginController = new SsoLoginController()
        OcmSsoHelper ocmSsoHelper = new OcmSsoHelperImpl()
        ocmSsoHelper.customerReference = customerReference
        ocmSsoHelper.setUser(Mock(AppUser))
        loginController.setUserPermissionGroupProvider(userPermissionGroupProvider)
        loginController.setOcmSsoHelper(ocmSsoHelper)
        loginController.environment = env
        loginController.systemSettingsWebService = Mock(SystemSettingsWebService)
        loginController.systemSettingsPingFederatePartner = Mock(SystemSettingsPingFederatePartner)
        loginController.systemSettingsWebService.read(_) >> Mock(SystemSettingsWebServiceVO)
        loginController.systemSettingsPingFederatePartner.read(_) >> Mock(SystemSettingsPingFederatePartnerVO)
        loginController.setCustomerUserView(customerUserView)
        loginController.setWebServiceLog(webServiceLog)
        loginController.memberDetailsProcessor = memberDetailsProcessor
        loginController.hscHelper = hscHelper
        loginController.hsc = hsc
        loginController.ssoActivityLog = ssoActivityLog

        when:
        hscHelper.readFormattedHscID(_) >> 1L
        hsc.read(_) >> new HscVO(memberID: 1)
        userPermissionGroupProvider.getUserPermissionGroups(_) >> {throw new AuthenticationException()}
        customerUserView.getActiveByUserID(_) >> [new CustomerUserViewVO(customerID: 1)]
        MockHttpServletRequest request = new MockHttpServletRequest()
        HttpServletResponse response = Mock(MockHttpServletResponse)
        request.setServerName("Test")
        request.setSession(new MockHttpSession())

        ModelAndView responseMV = loginController.handleRequest(request, response)

        then:
        responseMV.getModel().get(WebConstants.REQUEST_ERROR) != null
        responseMV.getViewName().equals(SsoViewMapping.OPTUM_SSO_ERROR.getPath())
    }

}
