package com.optum.app.shared.authorization.controller

import com.optum.app.shared.authorization.amqp.AuthRefreshMessage
import com.optum.app.shared.authorization.controller.AuthRefreshController
import com.optum.app.shared.hsc.businesslogic.HscHelper
import com.optum.app.shared.messaging.SpclCareMessageNotifier
import spock.lang.Specification

/**
 * Created by jboyd34 on 10/15/18.
 */
class AuthRefreshControllerSpec extends Specification{

    AuthRefreshController authRefreshController = new AuthRefreshController()
    SpclCareMessageNotifier spclCareMessageNotifier = Mock(SpclCareMessageNotifier)
    HscHelper hscHelper = Mock(HscHelper)

    def setup() {
        authRefreshController.spclCareMessageNotifier = spclCareMessageNotifier
        authRefreshController.hscHelper = hscHelper
    }

    def "test controller"(){
        given:
        String hscID = "432"
        String primarySRN = "1234"
        long formattedHscID = 432

        when:
        authRefreshController.authorize(primarySRN,hscID)

        then:
        1 * hscHelper.readFormattedHscID(hscID) >> formattedHscID
        1 * spclCareMessageNotifier.refreshAuthorization(_ as AuthRefreshMessage) >> { AuthRefreshMessage authRefreshMessage ->
            assert authRefreshMessage.primarySRN == primarySRN
            assert authRefreshMessage.hscID == formattedHscID
        }
        0 * _
    }
}
