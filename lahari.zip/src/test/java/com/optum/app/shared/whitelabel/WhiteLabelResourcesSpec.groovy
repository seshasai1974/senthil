package com.optum.app.shared.whitelabel

import com.optum.app.common.organization.data.OrganizationVO
import com.optum.app.ocm.customer.businesslogic.Customer
import com.optum.app.ocm.organization.businesslogic.Organization
import com.optum.app.shared.authorization.businesslogic.Authorizations
import com.optum.app.shared.whitelabel.dto.ForbiddenWordsDto
import com.optum.rf.dao.exception.UhgRuntimeException
import com.optum.rf.dao.sql.query.QueryProperties
import spock.lang.Specification

/**
 * Test the white label configurations and associated forbidden words configurations are valid
 * Verify customers that require forbidden words configurations
 * */
class WhiteLabelResourcesSpec extends Specification implements WhiteLabelTestData {
    Authorizations authorizations = Mock(Authorizations)
    Customer customer = Mock(Customer)
    Organization organization = Mock(Organization)
    WhiteLabel whiteLabel = new WhiteLabelConfiguration().whiteLabelWithResourceRepos(
            authorizations,
            customer,
            organization
    )

    def 'Success: All customer level whitelabel json resource files are valid'() {

        when: 'List all orgs with whiteLabel resource files'
        def customerNamesWithWhiteLabels = whiteLabel.customerWhiteLabelsMaintenance.getCustomerNamesWithCustomerLevelValues()

        then: 'Expect these customers to be a subset of orgs with whiteLabels'
        noExceptionThrown()
        def someExpectedCustomerNamesWithWhiteLabels = ["OC-SMA", "OC-OMN-AZ", "OC-OMN-UT", "OC-OMN-CO"]
        customerNamesWithWhiteLabels.containsAll(
                someExpectedCustomerNamesWithWhiteLabels
        )

        when: 'Read whiteLabels for that repo'
        def whiteLabels = customerNamesWithWhiteLabels.withIndex().collect{
            whiteLabel.customerWhiteLabelsMaintenance.getWLCustomerLevelValues(it.second + 1)
        }

        then:
        customer.read(_ as Integer) >>> namesToCustomerVOList(customerNamesWithWhiteLabels)
        noExceptionThrown()

        when: 'Attempt saving those values to trigger validation'
        whiteLabels.each{
            whiteLabel.customerWhiteLabelsMaintenance.validateWhiteLabels(1, it)
        }

        then: 'Unsupported Operation means that validation was successful'
        noExceptionThrown()
        customer.list(_ as QueryProperties) >> namesToCustomerVOList(customerNamesWithWhiteLabels)
        customer.read(_ as Integer) >>> namesToCustomerVOList(customerNamesWithWhiteLabels)
        organization.read(_ as Integer) >>> customerNamesWithWhiteLabels.collect{new OrganizationVO(organizationShortName: it)}
    }

    def 'Success: All organization level whitelabel json resource files are valid'() {

        when: 'List all orgs with whiteLabel resource files'
        def organizationNamesWithWhiteLabels = whiteLabel.customerWhiteLabelsMaintenance.getOrganizationNamesWithOrganizationLevelValues()

        then: 'Expect these customers to be a subset of orgs with whiteLabels'
        noExceptionThrown()
        def someExpectedCustomerNamesWithWhiteLabels = []
        organizationNamesWithWhiteLabels.containsAll(
                someExpectedCustomerNamesWithWhiteLabels
        )

        when: 'Read whiteLabels for that repo'
        def whiteLabels = organizationNamesWithWhiteLabels.withIndex().collect {
            whiteLabel.customerWhiteLabelsMaintenance.getWLOrganizationValues(it.second + 1)
        }

        then:
        noExceptionThrown()
        customer.read(_ as Integer) >>> namesToCustomerVOList(organizationNamesWithWhiteLabels)
        organization.read(_ as Integer) >>> organizationNamesWithWhiteLabels.collect{new OrganizationVO(organizationShortName: it)}


        when: 'Attempt saving those values to trigger validation'
        whiteLabels.each{
            whiteLabel.customerWhiteLabelsMaintenance.validateWhiteLabels(1, it)
        }

        then: 'Unsupported Operation means that validation was successful'
        noExceptionThrown()
        customer.list(_ as QueryProperties) >> namesToCustomerVOList(organizationNamesWithWhiteLabels)
        customer.read(_ as Integer) >>> namesToCustomerVOList(organizationNamesWithWhiteLabels)
        organization.read(_ as Integer) >>> organizationNamesWithWhiteLabels.collect{new OrganizationVO(organizationShortName: it)}
    }

    def 'Forbidden Words: Validate these customers have defined at least one forbidden word'() {
        when:
        if(whiteLabel.consumeForbiddenWords(customerId).isEmpty()) {
            throw new Exception("Missing forbidden values for customer " + customerName + " that requires them.")
        }

        then:
        noExceptionThrown()
        1 * authorizations.validateCustomer(customerId)
        1 * customer.read(customerId) >> newCustomerVO(customerId, customerName)
        1 * organization.read(0, []) >> new OrganizationVO(organizationShortName: "BCBS SC")

        where:
        customerName | organizationName  | customerId
        "BCBSSC"     | "BCBS SC"         | 2
    }

    def 'Failure to save whitelabel (Unsuported Operation)'() {
        given:
        def customerVO = newCustomerVO(1)

        when:
        whiteLabel.customerWhiteLabelsMaintenance.saveWLCustomerLevelValues(toCustomerDto(customerVO))

        then:
        thrown(UnsupportedOperationException)
        1 * authorizations.validateCustomer(customerVO.customerID)
        1 * customer.read(customerVO.customerID) >> customerVO
        1 * organization.read(0) >> new OrganizationVO(organizationShortName: "org-0")
    }

    def 'Failure to save forbidden words (Unsuported Operation)'() {
        given:
        def forbiddenWordsDto = new ForbiddenWordsDto(
                customerId: 1,
                forbiddenWords: forbiddenWords()
        )

        when:
        whiteLabel.forbiddenWordsMaintenance.saveFWCustomerLevelValues(forbiddenWordsDto)

        then:
        thrown(UnsupportedOperationException)
        1 * authorizations.validateCustomer(forbiddenWordsDto.customerId)
        1 * customer.read(forbiddenWordsDto.customerId) >> newCustomerVO(forbiddenWordsDto.customerId)
        1 * organization.read(0) >> new OrganizationVO(organizationShortName: "org-0")
    }

    def 'Failure to read'() {
        when:
        def invalidId = 2
        whiteLabel.customerWhiteLabelsMaintenance.getWLCustomerLevelValues(invalidId)

        then:
        thrown(UhgRuntimeException)
    }

}
