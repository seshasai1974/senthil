package com.optum.app.shared.federatedConfiguration.businesslogic

import com.optum.app.common.hsr.data.HscMemberCoverageVO
import com.optum.app.common.hsr.data.HscServiceDecisionVO
import com.optum.app.common.hsr.data.HscServiceVO
import com.optum.app.common.hsr.data.HscVO
import com.optum.app.ocm.cache.OcmCacheRefresh
import com.optum.app.ocm.common.constants.FeatureFlagConstants
import com.optum.app.shared.constants.MultiPayerConstants
import com.optum.app.shared.constants.SpclCareReferenceConstants
import com.optum.app.shared.federatedConfiguration.data.ClientConfiguration
import com.optum.app.shared.federatedConfiguration.data.MemberBenefitType
import com.optum.app.shared.federatedConfiguration.data.Product
import com.optum.rf.common.featureflag.util.FeatureFlagUtility
import com.optum.app.ocm.customer.businesslogic.Customer
import com.optum.app.shared.federatedConfiguration.businesslogic.impl.FederatedConfigServiceImpl
import com.optum.app.shared.federatedConfiguration.data.ConfigurationOverride
import com.optum.app.shared.federatedConfiguration.data.Letter
import com.optum.app.shared.federatedConfiguration.data.Recipient
import com.optum.rf.common.featureflag.util.FeatureFlagManager
import com.optum.rf.common.settings.businesslogic.SystemSettingsWebService
import com.optum.rf.common.settings.businesslogic.SystemSettingsWebServiceModifier
import com.optum.rf.common.settings.data.SystemSettingsWebServiceModifierVO
import com.optum.rf.common.settings.data.SystemSettingsWebServiceVO
import com.optum.app.common.customer.data.CustomerVO
import com.optum.rf.dao.exception.UhgRuntimeException
import org.springframework.cloud.config.environment.Environment
import org.springframework.cloud.config.environment.PropertySource
import org.springframework.web.client.RestTemplate
import spock.lang.Specification
import spock.lang.Unroll

import java.time.Instant


class FederatedConfigServiceImplSpec extends Specification{

    FederatedConfigService federatedConfigServiceImpl
    SystemSettingsWebService systemSettingsWebService
    SystemSettingsWebServiceModifier systemSettingsWebServiceModifier
    Customer customer
    RestTemplate restTemplate
    Environment environment
    SystemSettingsWebServiceVO systemSettingsWebServiceVO
    SystemSettingsWebServiceModifierVO systemSettingsWebServiceModifierVO
    OcmCacheRefresh ocmCacheRefresh
    FeatureFlagManager featureFlagManager

    def setup(){

        systemSettingsWebService = Mock(SystemSettingsWebService)
        systemSettingsWebServiceModifier = Mock(SystemSettingsWebServiceModifier)
        ocmCacheRefresh = Mock(OcmCacheRefresh)
        customer = Mock(Customer)
        restTemplate = Mock(RestTemplate)
        featureFlagManager = Mock(FeatureFlagManager)
        systemSettingsWebServiceVO = new SystemSettingsWebServiceVO(wsUrl: 'fedCfg')
        systemSettingsWebServiceModifierVO = new SystemSettingsWebServiceModifierVO(wsID: 'fedCfg', webServiceModifierCategoryName: 'config', webServiceModifierKeyName: 'branch', webServiceModifierValue: 'master' )
        FeatureFlagUtility.featureFlagManager = featureFlagManager

        // WARNING: must instantiate for each test because class contains a cache config Map
        federatedConfigServiceImpl = new FederatedConfigServiceImpl(
                systemSettingsWebService: systemSettingsWebService,
                systemSettingsWebServiceModifier: systemSettingsWebServiceModifier,
                customer: customer,
                ocmCacheRefresh: ocmCacheRefresh,
                restTemplate: restTemplate
        )
    }

    @Unroll
    def "test getAllClientConfiguration"() {
        given:

        when:
        ClientConfiguration config = federatedConfigServiceImpl.getAllClientConfiguration(clientId,auth)

        then:
        config == new ClientConfiguration(customerVO: customerVO)

        1 * FeatureFlagUtility.getManager().isActive(FeatureFlagConstants.FEDERATED_CONFIGS_CACHE) >> true
        1 * systemSettingsWebService.read(_) >> systemSettingsWebServiceVO
        1 * customer.read(_) >> customerVO
        1 * restTemplate.getForObject(*_) >> environment

        where:
        testCase |auth      | customerVO                                             | environment                                                    |  clientId
        'UHC'    |'1'      | new CustomerVO(customerID: 1, customerName: "UHC")     | getEnvironment(['spring.profiles.active'],['UHC'])             |  1
        'BCBSSC' |'1'     | new CustomerVO(customerID: 2, customerName: "BCBSSC")  | getEnvironment(['spring.profiles.active'], ['BCBSSC'])         |  2

    }

    @Unroll
    def "test getAllClientConfiguration uses cache on repeated calls for a specific client & auth"() {
        given:
        ClientConfiguration expectedConfig = new ClientConfiguration(customerVO: new CustomerVO(customerID: 1, customerName: "UHC"))

        when:
        // call 3 times to show cache functionality by later counting REST calls.
        ClientConfiguration config1 = federatedConfigServiceImpl.getAllClientConfiguration(1, '1')
        ClientConfiguration config2 = federatedConfigServiceImpl.getAllClientConfiguration(1, '1')
        ClientConfiguration config3 = federatedConfigServiceImpl.getAllClientConfiguration(1, '1')

        then:
        expectedConfig == config1
        expectedConfig == config2
        expectedConfig == config3

        configRequests * FeatureFlagUtility.getManager().isActive(FeatureFlagConstants.FEDERATED_CONFIGS_CACHE) >> activeCache
        _ * systemSettingsWebService.read(_) >> systemSettingsWebServiceVO
        _ * customer.read(_) >> expectedConfig.getCustomerVO()
        _ * ocmCacheRefresh.getLastCacheRefreshDate() >> Date.from(Instant.ofEpochSecond(0))
        envRequests * restTemplate.getForObject(*_) >> getEnvironment(['spring.profiles.active'], ['UHC'])

        where:
        activeCache | envRequests | configRequests
        true        | 1           | 3  // if cache is active, should only need one external I/O call
        false       | 3           | 3
    }

    @Unroll
    def "test getAllByClientAndProduct"() {
        when:
        Product product = federatedConfigServiceImpl.getAllByClientAndProduct(clientId, authType)

        then:
        product == new Product(type: authType)

        1 * systemSettingsWebService.read(_) >> systemSettingsWebServiceVO
        1 * customer.read(_) >> customerVO
        1 * restTemplate.getForObject(*_) >> environment

        where:
        testCase | customerVO                                            | environment                                                                       | clientId | authType
        'UHC'    | new CustomerVO(customerID: 1, customerName: "UHC")    | getEnvironment(['spring.profiles.active', 'products[0].type'], ['UHC', 'CGP'])    | 1        | 'CGP'
        'BCBSSC' | new CustomerVO(customerID: 2, customerName: "BCBSSC") | getEnvironment(['spring.profiles.active', 'products[0].type'], ['BCBSSC', 'SGP']) | 2        | 'SGP'
    }

    @Unroll "test getMemberBenefitsByClientAndProduct"(){
        given:
        CustomerVO customerVO = new CustomerVO(customerID: clientId, customerName: testCase)

        when:
        List<MemberBenefitType> benefits = federatedConfigServiceImpl.getMemberBenefitsByClientAndProduct(clientId, authType)

        then:
        benefits.size() == 1
        benefits.get(0) == new MemberBenefitType(type: expectedBenefitType)

        1 * systemSettingsWebService.read(_) >> systemSettingsWebServiceVO
        1 * customer.read(_) >> customerVO
        1 * restTemplate.getForObject(*_) >> environment

        where:
        testCase | environment                                                                                                                             | clientId | authType | expectedBenefitType
        'UHC'    | getEnvironment(['spring.profiles.active', 'products[0].type', 'products[0].memberBenefitTypes[0].type'], ['UHC', 'CGP', 'Medical'])     | 1        | 'CGP'    | 'Medical'
        'BCBSSC' | getEnvironment(['spring.profiles.active', 'products[0].type', 'products[0].memberBenefitTypes[0].type'], ['BCBSSC', 'SGP', 'Pharmacy']) | 2        | 'SGP'    | 'Pharmacy'

    }

    @Unroll "test getProviderTypesByClientAndProduct"(){
        given:

        when:
        federatedConfigServiceImpl.getProviderTypesByClientAndProduct(clientId, authType)

        then:
        1 * systemSettingsWebService.read(_) >> systemSettingsWebServiceVO
        1 * customer.read(_) >> customerVO
        1 * restTemplate.getForObject(*_) >> environment

        where:
        testCase       | customerVO                                             | environment                                                                                                                           |  clientId  | authType
        'UHC'          | new CustomerVO(customerID: 1, customerName: "UHC")     | getEnvironment(['spring.profiles.active','products[0].type','products[0].providerTypes[0].type'],['UHC','CGP','Physician'])           |  1         |  'CGP'
        'BCBSSC'       | new CustomerVO(customerID: 2, customerName: "BCBSSC")  | getEnvironment(['spring.profiles.active','products[0].type','products[0].providerTypes[0].type'], ['BCBSSC','SGP','Facility'])        |  2         |  'SGP'
    }

    @Unroll "test getIntegrationsByClientAndProduct"(){
        given:

        when:
        federatedConfigServiceImpl.getIntegrationsByClientAndProduct(clientId, authType)

        then:
        1 * systemSettingsWebService.read(_) >> systemSettingsWebServiceVO
        1 * customer.read(_) >> customerVO
        1 * restTemplate.getForObject(*_) >> environment

        where:
        testCase       | customerVO                                             | environment                                                                                                                      |  clientId  | authType
        'UHC'          | new CustomerVO(customerID: 1, customerName: "UHC")     | getEnvironment(['spring.profiles.active','products[0].type','products[0].integrations[0].type'],['UHC','CGP','claims'])          |  1         |  'CGP'
        'BCBSSC'       | new CustomerVO(customerID: 2, customerName: "BCBSSC")  | getEnvironment(['spring.profiles.active','products[0].type','products[0].integrations[0].type'], ['BCBSSC','SGP','ICUE'])        |  2         |  'SGP'
    }

    @Unroll "test getPagesByClientAndProduct"(){
        given:

        when:
        federatedConfigServiceImpl.getPagesByClientAndProduct(clientId, authType)

        then:
        1 * systemSettingsWebService.read(_) >> systemSettingsWebServiceVO
        1 * customer.read(_) >> customerVO
        1 * restTemplate.getForObject(*_) >> environment

        where:
        testCase       | customerVO                                             | environment                                                                                                                           |  clientId  | authType
        'UHC'          | new CustomerVO(customerID: 1, customerName: "UHC")     | getEnvironment(['spring.profiles.active','products[0].type','products[0].pages[0].type'],['UHC','CGP','requestingProvider'])          |  1         |  'CGP'
        'BCBSSC'       | new CustomerVO(customerID: 2, customerName: "BCBSSC")  | getEnvironment(['spring.profiles.active','products[0].type','products[0].pages[0].type'], ['BCBSSC','SGP','servicingProvider'])       |  2         |  'SGP'
    }

    @Unroll "test getPageConfigsByClientAndProductAndPage"(){
        given:

        when:
        federatedConfigServiceImpl.getPageConfigsByClientAndProductAndPage(clientId, authType, pageName)

        then:
        1 * systemSettingsWebService.read(_) >> systemSettingsWebServiceVO
        1 * customer.read(_) >> customerVO
        1 * restTemplate.getForObject(*_) >> environment

        where:
        testCase       | customerVO                                             | environment                                                                                                                           |  clientId  | authType | pageName
        'UHC'          | new CustomerVO(customerID: 1, customerName: "UHC")     | getEnvironment(['spring.profiles.active','products[0].type','products[0].pages[0].type'],['UHC','CGP','utilizationManagement'])          |  1         |  'CGP'   | 'utilizationManagement'
        'BCBSSC'       | new CustomerVO(customerID: 2, customerName: "BCBSSC")  | getEnvironment(['spring.profiles.active','products[0].type','products[0].pages[0].type'], ['BCBSSC','SGP','requestSummary'])       |  2         |  'SGP'   | 'requestSummary'
    }

    def "is Servicing Provider Screen Enabled"(){
        given:

        when:
        boolean isScreenEnabled = federatedConfigServiceImpl.isScreenEnabled(clientId, authType, "servicingProvider", hscVO)

        then:
        1 * systemSettingsWebService.read(_) >> systemSettingsWebServiceVO
        1 * customer.read(_) >> customerVO
        1 * restTemplate.getForObject(*_) >> environment

        and:
        isScreenEnabled == result

        where:
        testCase    | customerVO                                                | environment                                                                                                                                                                                                                                          |  clientId                                 | authType                                                        | hscVO                   | result
        0           | new CustomerVO(customerID: 1, customerName: "UHC")        | getEnvironment(['spring.profiles.active','products[0].type','products[0].pages[0].type','products[0].pages[0].display.enabled','products[0].pages[0].display.enableProperties'],['UHC','1','servicingProvider',true,getEnableProperties()])          |  MultiPayerConstants.UHC_PAYER_ID         |  SpclCareReferenceConstants.AUTH_TYPE_INJECTABLE_CHEMOTHERAPY   | exchangeMemberHsc()     | true
        1           | new CustomerVO(customerID: 1, customerName: "UHC")        | getEnvironment(['spring.profiles.active','products[0].type','products[0].pages[0].type','products[0].pages[0].display.enabled','products[0].pages[0].display.enableProperties'],['UHC','1','servicingProvider',true,getEnableProperties()])          |  MultiPayerConstants.UHC_PAYER_ID         |  SpclCareReferenceConstants.AUTH_TYPE_INJECTABLE_CHEMOTHERAPY   | mandrMemberHsc()        | false
        2           | new CustomerVO(customerID: 1, customerName: "UHC")        | getEnvironment(['spring.profiles.active','products[0].type','products[0].pages[0].type','products[0].pages[0].display.enabled','products[0].pages[0].display.enableProperties'],['UHC','1','servicingProvider',true,getEnableProperties()])          |  MultiPayerConstants.UHC_PAYER_ID         |  SpclCareReferenceConstants.AUTH_TYPE_INJECTABLE_CHEMOTHERAPY   | eandiMemberHsc()        | false
        3           | new CustomerVO(customerID: 1, customerName: "UHC")        | getEnvironment(['spring.profiles.active','products[0].type','products[0].pages[0].type','products[0].pages[0].display.enabled','products[0].pages[0].display.enableProperties'],['UHC','2','servicingProvider',true,getEnableProperties()])          |  MultiPayerConstants.UHC_PAYER_ID         |  SpclCareReferenceConstants.AUTH_TYPE_SUPPORTIVE_DRUGS          | exchangeMemberHsc()     | true
        4           | new CustomerVO(customerID: 1, customerName: "UHC")        | getEnvironment(['spring.profiles.active','products[0].type','products[0].pages[0].type','products[0].pages[0].display.enabled','products[0].pages[0].display.enableProperties'],['UHC','2','servicingProvider',true,getEnableProperties()])          |  MultiPayerConstants.UHC_PAYER_ID         |  SpclCareReferenceConstants.AUTH_TYPE_SUPPORTIVE_DRUGS          | mandrMemberHsc()        | false
        5           | new CustomerVO(customerID: 1, customerName: "UHC")        | getEnvironment(['spring.profiles.active','products[0].type','products[0].pages[0].type','products[0].pages[0].display.enabled','products[0].pages[0].display.enableProperties'],['UHC','2','servicingProvider',true,getEnableProperties()])          |  MultiPayerConstants.UHC_PAYER_ID         |  SpclCareReferenceConstants.AUTH_TYPE_SUPPORTIVE_DRUGS          | eandiMemberHsc()        | false
        6           | new CustomerVO(customerID: 1, customerName: "UHC")        | getEnvironment(['spring.profiles.active','products[0].type','products[0].pages[0].type','products[0].pages[0].display.enabled','products[0].pages[0].display.enableProperties'],['UHC','3','servicingProvider',true,getEnableProperties()])          |  MultiPayerConstants.UHC_PAYER_ID         |  SpclCareReferenceConstants.AUTH_TYPE_RADIOPHARMACEUTICAL       | exchangeMemberHsc()     | true
        7           | new CustomerVO(customerID: 1, customerName: "UHC")        | getEnvironment(['spring.profiles.active','products[0].type','products[0].pages[0].type','products[0].pages[0].display.enabled','products[0].pages[0].display.enableProperties'],['UHC','3','servicingProvider',true,getEnableProperties()])          |  MultiPayerConstants.UHC_PAYER_ID         |  SpclCareReferenceConstants.AUTH_TYPE_RADIOPHARMACEUTICAL       | mandrMemberHsc()        | false
        8           | new CustomerVO(customerID: 1, customerName: "UHC")        | getEnvironment(['spring.profiles.active','products[0].type','products[0].pages[0].type','products[0].pages[0].display.enabled','products[0].pages[0].display.enableProperties'],['UHC','3','servicingProvider',true,getEnableProperties()])          |  MultiPayerConstants.UHC_PAYER_ID         |  SpclCareReferenceConstants.AUTH_TYPE_RADIOPHARMACEUTICAL       | eandiMemberHsc()        | false
        9           | new CustomerVO(customerID: 1, customerName: "UHC")        | getEnvironment(['spring.profiles.active','products[0].type','products[0].pages[0].type','products[0].pages[0].display.enabled'],['UHC','4','servicingProvider',true])                                                                                |  MultiPayerConstants.UHC_PAYER_ID         |  SpclCareReferenceConstants.AUTH_TYPE_SPECIALTY_PHARMACY        | new HscVO()             | true
        10          | new CustomerVO(customerID: 1, customerName: "UHC")        | getEnvironment(['spring.profiles.active','products[0].type','products[0].pages[0].type','products[0].pages[0].display.enabled'],['UHC','5','servicingProvider',false])                                                                               |  MultiPayerConstants.UHC_PAYER_ID         |  SpclCareReferenceConstants.AUTH_TYPE_ORAL_DRUGS                | new HscVO()             | false
        11          | new CustomerVO(customerID: 1, customerName: "UHC")        | getEnvironment(['spring.profiles.active','products[0].type','products[0].pages[0].type','products[0].pages[0].display.enabled'],['UHC','6','servicingProvider',false])                                                                               |  MultiPayerConstants.UHC_PAYER_ID         |  SpclCareReferenceConstants.AUTH_TYPE_PHYSICAL_THERAPY          | new HscVO()             | false
        12          | new CustomerVO(customerID: 1, customerName: "UHC")        | getEnvironment(['spring.profiles.active','products[0].type','products[0].pages[0].type','products[0].pages[0].display.enabled'],['UHC','7','servicingProvider',false])                                                                               |  MultiPayerConstants.UHC_PAYER_ID         |  SpclCareReferenceConstants.AUTH_TYPE_SPEECH_THERAPY            | new HscVO()             | false
        13          | new CustomerVO(customerID: 1, customerName: "UHC")        | getEnvironment(['spring.profiles.active','products[0].type','products[0].pages[0].type','products[0].pages[0].display.enabled'],['UHC','8','servicingProvider',false])                                                                               |  MultiPayerConstants.UHC_PAYER_ID         |  SpclCareReferenceConstants.AUTH_TYPE_OCCUPATIONAL_THERAPY      | new HscVO()             | false
        14          | new CustomerVO(customerID: 1, customerName: "UHC")        | getEnvironment(['spring.profiles.active','products[0].type','products[0].pages[0].type','products[0].pages[0].display.enabled'],['UHC','9','servicingProvider',true])                                                                                |  MultiPayerConstants.UHC_PAYER_ID         |  SpclCareReferenceConstants.AUTH_TYPE_RADIATION_ONCOLOGY        | new HscVO()             | true
        15          | new CustomerVO(customerID: 2, customerName: "BCBSSC")     | getEnvironment(['spring.profiles.active','products[0].type','products[0].pages[0].type','products[0].pages[0].display.enabled'],['BCBSSC','1','servicingProvider',true])                                                                             |  MultiPayerConstants.BCBS_SC_PAYER_ID     |  SpclCareReferenceConstants.AUTH_TYPE_INJECTABLE_CHEMOTHERAPY   | new HscVO()             | true
        16          | new CustomerVO(customerID: 2, customerName: "BCBSSC")     | getEnvironment(['spring.profiles.active','products[0].type','products[0].pages[0].type','products[0].pages[0].display.enabled'],['BCBSSC','2','servicingProvider',true])                                                                             |  MultiPayerConstants.BCBS_SC_PAYER_ID     |  SpclCareReferenceConstants.AUTH_TYPE_SUPPORTIVE_DRUGS          | new HscVO()             | true
        17          | new CustomerVO(customerID: 2, customerName: "BCBSSC")     | getEnvironment(['spring.profiles.active','products[0].type','products[0].pages[0].type','products[0].pages[0].display.enabled'],['BCBSSC','3','servicingProvider',true])                                                                             |  MultiPayerConstants.BCBS_SC_PAYER_ID     |  SpclCareReferenceConstants.AUTH_TYPE_RADIOPHARMACEUTICAL       | new HscVO()             | true
        18          | new CustomerVO(customerID: 3, customerName: "OC-OMN-AZ")  | getEnvironment(['spring.profiles.active','products[0].type','products[0].pages[0].type','products[0].pages[0].display.enabled'],['OC-OMN-AZ','1','servicingProvider',true])                                                                          |  MultiPayerConstants.OC_OMN_AZ_PAYER_ID   |  SpclCareReferenceConstants.AUTH_TYPE_INJECTABLE_CHEMOTHERAPY   | new HscVO()             | true
        19          | new CustomerVO(customerID: 3, customerName: "OC-OMN-AZ")  | getEnvironment(['spring.profiles.active','products[0].type','products[0].pages[0].type','products[0].pages[0].display.enabled'],['OC-OMN-AZ','2','servicingProvider',true])                                                                          |  MultiPayerConstants.OC_OMN_AZ_PAYER_ID   |  SpclCareReferenceConstants.AUTH_TYPE_SUPPORTIVE_DRUGS          | new HscVO()             | true
        20          | new CustomerVO(customerID: 3, customerName: "OC-OMN-AZ")  | getEnvironment(['spring.profiles.active','products[0].type','products[0].pages[0].type','products[0].pages[0].display.enabled'],['OC-OMN-AZ','3','servicingProvider',true])                                                                          |  MultiPayerConstants.OC_OMN_AZ_PAYER_ID   |  SpclCareReferenceConstants.AUTH_TYPE_RADIOPHARMACEUTICAL       | new HscVO()             | true
        21          | new CustomerVO(customerID: 4, customerName: "OC-SMA")     | getEnvironment(['spring.profiles.active','products[0].type','products[0].pages[0].type','products[0].pages[0].display.enabled'],['OC-SMA','1','servicingProvider',true])                                                                             |  MultiPayerConstants.OC_SMA_PAYER_ID      |  SpclCareReferenceConstants.AUTH_TYPE_INJECTABLE_CHEMOTHERAPY   | new HscVO()             | true
        22          | new CustomerVO(customerID: 4, customerName: "OC-SMA")     | getEnvironment(['spring.profiles.active','products[0].type','products[0].pages[0].type','products[0].pages[0].display.enabled'],['OC-SMA','2','servicingProvider',true])                                                                             |  MultiPayerConstants.OC_SMA_PAYER_ID      |  SpclCareReferenceConstants.AUTH_TYPE_SUPPORTIVE_DRUGS          | new HscVO()             | true
        23          | new CustomerVO(customerID: 4, customerName: "OC-SMA")     | getEnvironment(['spring.profiles.active','products[0].type','products[0].pages[0].type','products[0].pages[0].display.enabled'],['OC-SMA','3','servicingProvider',true])                                                                             |  MultiPayerConstants.OC_SMA_PAYER_ID      |  SpclCareReferenceConstants.AUTH_TYPE_RADIOPHARMACEUTICAL       | new HscVO()             | true
        24          | new CustomerVO(customerID: 5, customerName: "OC-OMN-UT")  | getEnvironment(['spring.profiles.active','products[0].type','products[0].pages[0].type','products[0].pages[0].display.enabled'],['OC-OMN-UT','1','servicingProvider',true])                                                                          |  MultiPayerConstants.OC_OMN_UT_PAYER_ID   |  SpclCareReferenceConstants.AUTH_TYPE_INJECTABLE_CHEMOTHERAPY   | new HscVO()             | true
        25          | new CustomerVO(customerID: 5, customerName: "OC-OMN-UT")  | getEnvironment(['spring.profiles.active','products[0].type','products[0].pages[0].type','products[0].pages[0].display.enabled'],['OC-OMN-UT','2','servicingProvider',true])                                                                          |  MultiPayerConstants.OC_OMN_UT_PAYER_ID   |  SpclCareReferenceConstants.AUTH_TYPE_SUPPORTIVE_DRUGS          | new HscVO()             | true
        25          | new CustomerVO(customerID: 5, customerName: "OC-OMN-UT")  | getEnvironment(['spring.profiles.active','products[0].type','products[0].pages[0].type','products[0].pages[0].display.enabled'],['OC-OMN-UT','3','servicingProvider',true])                                                                          |  MultiPayerConstants.OC_OMN_UT_PAYER_ID   |  SpclCareReferenceConstants.AUTH_TYPE_RADIOPHARMACEUTICAL       | new HscVO()             | true
        25          | new CustomerVO(customerID: 6, customerName: "OC-OMN-CO")  | getEnvironment(['spring.profiles.active','products[0].type','products[0].pages[0].type','products[0].pages[0].display.enabled'],['OC-OMN-CO','1','servicingProvider',true])                                                                          |  MultiPayerConstants.OC_OMN_CO_PAYER_ID   |  SpclCareReferenceConstants.AUTH_TYPE_INJECTABLE_CHEMOTHERAPY   | new HscVO()             | true
        25          | new CustomerVO(customerID: 6, customerName: "OC-OMN-CO")  | getEnvironment(['spring.profiles.active','products[0].type','products[0].pages[0].type','products[0].pages[0].display.enabled'],['OC-OMN-CO','2','servicingProvider',true])                                                                          |  MultiPayerConstants.OC_OMN_CO_PAYER_ID   |  SpclCareReferenceConstants.AUTH_TYPE_SUPPORTIVE_DRUGS          | new HscVO()             | true
        25          | new CustomerVO(customerID: 6, customerName: "OC-OMN-CO")  | getEnvironment(['spring.profiles.active','products[0].type','products[0].pages[0].type','products[0].pages[0].display.enabled'],['OC-OMN-CO','3','servicingProvider',true])                                                                          |  MultiPayerConstants.OC_OMN_CO_PAYER_ID   |  SpclCareReferenceConstants.AUTH_TYPE_RADIOPHARMACEUTICAL       | new HscVO()             | true
        26          | new CustomerVO(customerID: 7, customerName: "PHN")        | getEnvironment(['spring.profiles.active','products[0].type','products[0].pages[0].type','products[0].pages[0].display.enabled'],['PHN','1','servicingProvider',true])                                                                                |  MultiPayerConstants.PHN_PAYER_ID         |  SpclCareReferenceConstants.AUTH_TYPE_INJECTABLE_CHEMOTHERAPY   | new HscVO()             | true
        27          | new CustomerVO(customerID: 7, customerName: "PHN")        | getEnvironment(['spring.profiles.active','products[0].type','products[0].pages[0].type','products[0].pages[0].display.enabled'],['PHN','2','servicingProvider',true])                                                                                |  MultiPayerConstants.PHN_PAYER_ID         |  SpclCareReferenceConstants.AUTH_TYPE_SUPPORTIVE_DRUGS          | new HscVO()             | true
        28          | new CustomerVO(customerID: 7, customerName: "PHN")        | getEnvironment(['spring.profiles.active','products[0].type','products[0].pages[0].type','products[0].pages[0].display.enabled'],['PHN','3','servicingProvider',true])                                                                                |  MultiPayerConstants.PHN_PAYER_ID         |  SpclCareReferenceConstants.AUTH_TYPE_RADIOPHARMACEUTICAL       | new HscVO()             | true
        29          | new CustomerVO(customerID: 8, customerName: "OptumRx")    | getEnvironment(['spring.profiles.active','products[0].type','products[0].pages[0].type','products[0].pages[0].display.enabled'],['OptumRx','3','servicingProvider',true])                                                                            |  MultiPayerConstants.ORX_PAYER_ID         |  SpclCareReferenceConstants.AUTH_TYPE_SPECIALTY_PHARMACY        | new HscVO()             | true
    }

    HscVO exchangeMemberHsc(){
        HscVO hscVO = new HscVO(memberCoverageSeqNum: 1)
        List<HscMemberCoverageVO> hscMemberCoverageVOs = [new HscMemberCoverageVO(memberCoverageSeqNum: 1, reportCode: 'EXGN')]
        hscVO.hscMemberCoverageVOs = hscMemberCoverageVOs
        return hscVO
    }

    HscVO mandrMemberHsc(){
        HscVO hscVO = new HscVO(memberCoverageSeqNum: 1)
        List<HscMemberCoverageVO> hscMemberCoverageVOs = [new HscMemberCoverageVO(memberCoverageSeqNum: 1, productCategoryType: '2')]
        hscVO.hscMemberCoverageVOs = hscMemberCoverageVOs
        return hscVO
    }

    HscVO eandiMemberHsc(){
        HscVO hscVO = new HscVO(memberCoverageSeqNum: 1)
        List<HscMemberCoverageVO> hscMemberCoverageVOs = [new HscMemberCoverageVO(memberCoverageSeqNum: 1, lineOfBusinessType: '18')]
        hscVO.hscMemberCoverageVOs = hscMemberCoverageVOs
        return hscVO
    }

    Map<String, String> getEnableProperties(){
        Map<String, String> enableProperties = new HashMap<>()
        enableProperties.put('reportingCode', 'EXGN')
        enableProperties.put('lineOfBusinessType', '1, 2, 3, 4, 5, 6, 8, 9, 10, 12, 13, 16, 17, 19, 20')
        enableProperties.put('productCategoryType', '0, 1, 4, 5')
        return enableProperties
    }

    @Unroll
    def "test getServiceReferencePrefix"(){
        given:

        when:
        federatedConfigServiceImpl.getServiceReferencePrefix(clientId, authType)

        then:
        1 * systemSettingsWebService.read(_) >> systemSettingsWebServiceVO
        1 * customer.read(_) >> customerVO
        1 * restTemplate.getForObject(*_) >> environment

        where:
        testCase       | customerVO                                                   | environment                                                                             |  clientId  | authType
        'UHC'          | new CustomerVO(customerID: 1, customerName: "UHC")           | getEnvironment(['spring.profiles.active','products[0].type'],['UHC','CGP'])             |  1         |  'CGP'
        'BCBSSC'       | new CustomerVO(customerID: 2, customerName: "BCBSSC")        | getEnvironment(['spring.profiles.active','products[0].type'], ['BCBSSC','SGP'])         |  2         |  'SGP'
        'OC-OMN-AZ'    | new CustomerVO(customerID: 3, customerName: "OC-OMN-AZ")     | getEnvironment(['spring.profiles.active','products[0].type'],['OC-OMN-AZ','CGP'])       |  3         |  'CGP'
        'OC-SMA'       | new CustomerVO(customerID: 4, customerName: "OC-SMA")        | getEnvironment(['spring.profiles.active','products[0].type'],['OC-SMA','CGP'])          |  4         |  'CGP'
        'OC-OMN-UT'    | new CustomerVO(customerID: 5, customerName: "OC-OMN-UT")     | getEnvironment(['spring.profiles.active','products[0].type'],['OC-OMN-UT','CGP'])       |  5         |  'CGP'
        'OC-OMN-CO'    | new CustomerVO(customerID: 6, customerName: "OC-OMN-CO")     | getEnvironment(['spring.profiles.active','products[0].type'],['OC-OMN-CO','CGP'])       |  6         |  'CGP'

    }

    @Unroll
    def 'test getLettersByClientAndProduct with overrides checked and potentially applied'() {
        given:
        HscVO hscVO = new HscVO(customerID: 1, authTypeID: "7", hscServiceVOs: [new HscServiceVO(hscServiceDecisionVOs: decisionVos)])
        Letter mockReturnLetter = new Letter(
                autoLetter: true,
                pendingLetter: true,
                recipients: [
                        new Recipient(type: "member", createAutoLetter: true,
                                overrides: [
                                        new ConfigurationOverride(
                                                type: "hscServiceVOs.?[hscServiceDecisionVOs.?[decnClinicalRespCatgryId == 1].size() != 0].size() > 0 ",
                                                fields: Collections.singletonMap("createAutoLetter", "false")),
                                        new ConfigurationOverride(
                                                type: "hscServiceVOs.?[hscServiceDecisionVOs.?[decnClinicalRespCatgryId == 3].size() != 0].size() > 0 ",
                                                fields: Collections.singletonMap("createAutoLetter", "false"))
                                ])])

        // WARNING: partial mock! Otherwise would need impractically complicated rest call & Environment object mocking
        FederatedConfigServiceImpl federatedConfigService = Spy {
            getAllByClientAndProduct(_, _) >> new Product(letter: mockReturnLetter)
        }

        when:
        Letter actualLetter = federatedConfigService.getLettersByClientAndProduct(hscVO)

        then:
        actualLetter.recipients.size() == mockReturnLetter.recipients.size()

        // DEFECT FIX check for DE522883.
        // mockReturnLetter is deep-copied and mutated by actualLetter
        !actualLetter.recipients.get(0).is(mockReturnLetter.recipients.get(0))
        // If no override, the actual and mock input recipients both should have the same values.
        overrideExpected == (actualLetter.recipients.get(0) != mockReturnLetter.recipients.get(0))

        // if override applied, flips createAutoLetter to false
        expectedCreateAutoLetter == actualLetter.recipients.get(0).getCreateAutoLetter()

        where:
        testCase                        | overrideExpected | expectedCreateAutoLetter | decisionVos
        'not managed'                   | true             | false                    | [new HscServiceDecisionVO(decnClinicalRespCatgryId: 1)]
        'other reason'                  | false            | true                     | [new HscServiceDecisionVO(decnClinicalRespCatgryId: 2)]
        'administrative grounds'        | true             | false                    | [new HscServiceDecisionVO(decnClinicalRespCatgryId: 3)]
        'multiple decisions'            | false            | true                     | [new HscServiceDecisionVO(), new HscServiceDecisionVO(decnClinicalRespCatgryId: 2)]
    }

    @Unroll
    def "test getFusionEngineByClientAndProduct"(){
        given:

        when:
        federatedConfigServiceImpl.getFusionEngineByClientAndProduct(clientId, authType)

        then:
        1 * systemSettingsWebService.read(_) >> systemSettingsWebServiceVO
        1 * customer.read(_) >> customerVO
        1 * restTemplate.getForObject(*_) >> environment

        where:
        testCase       | customerVO                                                   | environment                                                                                                                               |  clientId  | authType
        'UHC'          | new CustomerVO(customerID: 1, customerName: "UHC")           | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].optumFusionEngine.enabled'],['UHC','CGP','false'])              |  1         |  'CGP'
        'BCBSSC'       | new CustomerVO(customerID: 2, customerName: "BCBSSC")        | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].optumFusionEngine.enabled'], ['BCBSSC','SGP', 'true'])          |  2         |  'SGP'
        'OC-OMN-AZ'    | new CustomerVO(customerID: 3, customerName: "OC-OMN-AZ")     | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].optumFusionEngine.enabled'],['OC-OMN-AZ','CGP', 'false'])       |  3         |  'CGP'
        'OC-SMA'       | new CustomerVO(customerID: 4, customerName: "OC-SMA")        | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].optumFusionEngine.enabled'],['OC-SMA','CGP', 'false'])          |  4         |  'CGP'
        'OC-OMN-UT'    | new CustomerVO(customerID: 5, customerName: "OC-OMN-UT")     | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].optumFusionEngine.enabled'],['OC-OMN-UT','CGP', 'false'])       |  5         |  'CGP'
        'OC-OMN-CO'    | new CustomerVO(customerID: 6, customerName: "OC-OMN-CO")     | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].optumFusionEngine.enabled'],['OC-OMN-CO','CGP', 'false'])       |  6         |  'CGP'

    }

    @Unroll
    def "test getEpaIntegrationByClientAndProduct"(){
        given:

        when:
        federatedConfigServiceImpl.getEpaIntegrationByClientAndProduct(clientId, authType)

        then:
        1 * systemSettingsWebService.read(_) >> systemSettingsWebServiceVO
        1 * customer.read(_) >> customerVO
        1 * restTemplate.getForObject(*_) >> environment

        where:
        testCase       | customerVO                                                   | environment                                                                                                                            |  clientId  | authType
        'UHC'          | new CustomerVO(customerID: 1, customerName: "UHC")           | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].epaIntegration.enabled'],['UHC','CGP','false'])              |  1         |  'CGP'
        'BCBSSC'       | new CustomerVO(customerID: 2, customerName: "BCBSSC")        | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].epaIntegration.enabled'], ['BCBSSC','SGP', 'true'])          |  2         |  'SGP'
        'OC-OMN-AZ'    | new CustomerVO(customerID: 3, customerName: "OC-OMN-AZ")     | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].epaIntegration.enabled'],['OC-OMN-AZ','CGP', 'false'])       |  3         |  'CGP'
        'OC-SMA'       | new CustomerVO(customerID: 4, customerName: "OC-SMA")        | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].epaIntegration.enabled'],['OC-SMA','CGP', 'false'])          |  4         |  'CGP'
        'OC-OMN-UT'    | new CustomerVO(customerID: 5, customerName: "OC-OMN-UT")     | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].epaIntegration.enabled'],['OC-OMN-UT','CGP', 'false'])       |  5         |  'CGP'
        'OC-OMN-CO'    | new CustomerVO(customerID: 6, customerName: "OC-OMN-CO")     | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].epaIntegration.enabled'],['OC-OMN-CO','CGP', 'false'])       |  6         |  'CGP'

    }

    @Unroll
    def "Should fetch RxSupported Configuration given client and authType"(){
        given:

        when:
        federatedConfigServiceImpl.getRxSupportedByClientAndProduct(clientId, authType)

        then:
        1 * systemSettingsWebService.read(_) >> systemSettingsWebServiceVO
        1 * customer.read(_) >> customerVO
        1 * restTemplate.getForObject(*_) >> environment

        where:
        testCase       | customerVO                                                   | environment                                                                                                                                                                                                                                  |  clientId  | authType
        'UHC'          | new CustomerVO(customerID: 1, customerName: "UHC")           | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].rxSupported.enabled', 'products[0].rxSupported.enableProperties'], ['UHC', 'CGP', 'false', ['lineOfBusinessType': '11', 'reportingCode': 'EXGN']] as List<String>) |  1         |  'CGP'
        'BCBSSC'       | new CustomerVO(customerID: 2, customerName: "BCBSSC")        | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].rxSupported.enabled'], ['BCBSSC','SGP', 'true'])                                                                                                                   |  2         |  'SGP'
        'OC-OMN-AZ'    | new CustomerVO(customerID: 3, customerName: "OC-OMN-AZ")     | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].rxSupported.enabled'],['OC-OMN-AZ','CGP', 'false'])                                                                                                                |  3         |  'CGP'
        'OC-SMA'       | new CustomerVO(customerID: 4, customerName: "OC-SMA")        | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].rxSupported.enabled'],['OC-SMA','CGP', 'false'])                                                                                                                   |  4         |  'CGP'
        'OC-OMN-UT'    | new CustomerVO(customerID: 5, customerName: "OC-OMN-UT")     | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].rxSupported.enabled'],['OC-OMN-UT','CGP', 'false'])                                                                                                                |  5         |  'CGP'
        'OC-OMN-CO'    | new CustomerVO(customerID: 6, customerName: "OC-OMN-CO")     | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].rxSupported.enabled'],['OC-OMN-CO','CGP', 'false'])                                                                                                                |  6         |  'CGP'
        'PHN'          | new CustomerVO(customerID: 6, customerName: "PHN")           | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].rxSupported.enabled'],['PHN','CGP', 'false'])                                                                                                                      |  7         |  'CGP'
        'ORX'          | new CustomerVO(customerID: 6, customerName: "ORX")           | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].rxSupported.enabled'],['ORX','CGP', 'true'])                                                                                                                       |  8         |  'CGP'
    }

    @Unroll
    def "Should throw UhgRuntimeException when fetching RxSupported Configuration given microservice is down"(){
        given:

        when:
        federatedConfigServiceImpl.getRxSupportedByClientAndProduct(clientId, authType)

        then:
        1 * systemSettingsWebService.read(_) >> systemSettingsWebServiceVO
        1 * customer.read(_) >> customerVO
        1 * restTemplate.getForObject(*_) >> environment

        where:
        testCase       | customerVO                                                   | environment                                                                                                      |  clientId  | authType
        'UHC'          | new CustomerVO(customerID: 1, customerName: "UHC")           | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].rxSupported'], ['UHC', 'CGP', null])   |  1         |  'CGP'
        'BCBSSC'       | new CustomerVO(customerID: 2, customerName: "BCBSSC")        | getEnvironment(['spring.profiles.active','products'], ['BCBSSC', null])                                          |  2         |  'SGP'
    }

    @Unroll
    def "test getDelegationOfCareByClientAndProduct"(){
        given:

        when:
        federatedConfigServiceImpl.getDelegationOfCareByClientAndProduct(clientId, authType)

        then:
        1 * systemSettingsWebService.read(_) >> systemSettingsWebServiceVO
        1 * customer.read(_) >> customerVO
        1 * restTemplate.getForObject(*_) >> environment

        where:
        testCase       | customerVO                                                   | environment                                                                                                                             |  clientId    | authType
        'UHC-1'        | new CustomerVO(customerID: 1, customerName: "UHC")           | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].delegationOfCare.enabled'],['UHC','CGP','true'])              |  1           |  'CGP'
        'UHC-4'        | new CustomerVO(customerID: 1, customerName: "UHC")           | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].delegationOfCare.enabled'],['UHC','SGP','true'])              |  1           |  'SGP'
        'UHC-9'        | new CustomerVO(customerID: 1, customerName: "UHC")           | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].delegationOfCare.enabled'],['UHC','RadOnc','true'])           |  1           |  'RadOnc'
        'UHC-2'        | new CustomerVO(customerID: 1, customerName: "UHC")           | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].delegationOfCare.enabled'],['UHC','Supportive','true'])       |  1           |  'Supportive'
        'UHC-3'        | new CustomerVO(customerID: 1, customerName: "UHC")           | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].delegationOfCare.enabled'],['UHC','RadioPharma','true'])      |  1           |  'RadioPharma'
        'BCBSSC'       | new CustomerVO(customerID: 2, customerName: "BCBSSC")        | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].delegationOfCare.enabled'], ['BCBSSC','SGP', 'false'])        |  2           |  'SGP'
        'OC-OMN-AZ'    | new CustomerVO(customerID: 3, customerName: "OC-OMN-AZ")     | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].delegationOfCare.enabled'],['OC-OMN-AZ','CGP', 'false'])      |  3           |   'CGP'
        'OC-SMA'       | new CustomerVO(customerID: 4, customerName: "OC-SMA")        | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].delegationOfCare.enabled'],['OC-SMA','CGP', 'false'])         |  4           |  'CGP'
        'OC-OMN-UT'    | new CustomerVO(customerID: 5, customerName: "OC-OMN-UT")     | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].delegationOfCare.enabled'],['OC-OMN-UT','CGP', 'false'])      |  5           |  'CGP'
        'OC-OMN-CO'    | new CustomerVO(customerID: 6, customerName: "OC-OMN-CO")     | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].delegationOfCare.enabled'],['OC-OMN-CO','CGP', 'false'])      |  6           |  'CGP'

    }

    @Unroll
    def "test getPreferredPathwayByClientAndProduct"(){
        given:

        when:
        federatedConfigServiceImpl.getPreferredPathwayByClientAndProduct(clientId, authType)

        then:
        1 * systemSettingsWebService.read(_) >> systemSettingsWebServiceVO
        1 * customer.read(_) >> customerVO
        1 * restTemplate.getForObject(*_) >> environment

        where:
        testCase            | customerVO                                                   | environment                                                                                                                             |  clientId    | authType
        'UHC-1'             | new CustomerVO(customerID: 1, customerName: "UHC")           | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].preferredPathway.enabled'],['UHC','CGP','true'])              |  1           |  'CGP'
        'BCBSSC-1'          | new CustomerVO(customerID: 1, customerName: "BCBSSC")        | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].preferredPathway.enabled'],['BCBSSC','CGP','true'])           |  1           |  'CGP'
        'OC-OMN-AZ-1'       | new CustomerVO(customerID: 1, customerName: "OC-OMN-AZ")     | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].preferredPathway.enabled'],['OC-OMN-AZ','CGP','true'])        |  1           |  'CGP'
        'OC-SMA-1'          | new CustomerVO(customerID: 1, customerName: "OC-SMA")        | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].preferredPathway.enabled'],['OC-SMA','CGP','true'])           |  1           |  'CGP'
        'OC-OMN-UT-1'       | new CustomerVO(customerID: 1, customerName: "OC-OMN-UT")     | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].preferredPathway.enabled'],['OC-OMN-UT','CGP','true'])        |  1           |  'CGP'
        'OC-OMN-CO-1'       | new CustomerVO(customerID: 2, customerName: "OC-OMN-CO")     | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].preferredPathway.enabled'], ['OC-OMN-CO','SGP', 'false'])     |  2           |  'SGP'
        'OC-OMN-AZ'         | new CustomerVO(customerID: 3, customerName: "OC-OMN-AZ")     | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].preferredPathway.enabled'],['OC-OMN-AZ','CGP', 'false'])      |  3           |   'CGP'
        'OC-SMA'            | new CustomerVO(customerID: 4, customerName: "OC-SMA")        | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].preferredPathway.enabled'],['OC-SMA','CGP', 'false'])         |  4           |  'CGP'
        'OC-OMN-UT'         | new CustomerVO(customerID: 5, customerName: "OC-OMN-UT")     | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].preferredPathway.enabled'],['OC-OMN-UT','CGP', 'false'])      |  5           |  'CGP'
        'OC-OMN-CO'         | new CustomerVO(customerID: 6, customerName: "OC-OMN-CO")     | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].preferredPathway.enabled'],['OC-OMN-CO','CGP', 'false'])      |  6           |  'CGP'

    }

    @Unroll
    def "Should fetch AdministeringProvider Configuration given client and authType"(){
        given:

        when:
        federatedConfigServiceImpl.getAdministeringProviderByClientAndProduct(clientId, authType)

        then:
        1 * systemSettingsWebService.read(_) >> systemSettingsWebServiceVO
        1 * customer.read(_) >> customerVO
        1 * restTemplate.getForObject(*_) >> environment

        where:
        testCase       | customerVO                                                   | environment                                                                                                                                                                                                                            | clientId  | authType
        'UHC'          | new CustomerVO(customerID: 1, customerName: "UHC")           | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].administeringProvider.enabled', 'products[0].administeringProvider.enableProperties'], ['UHC', 'SGP', 'true', ['lineOfBusinessType': '12']] as List<String>) | 1         | 'SGP'
        'BCBSSC'       | new CustomerVO(customerID: 2, customerName: "BCBSSC")        | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].administeringProvider.enabled'], ['BCBSSC','SGP', 'false'])                                                                                                  | 2         | 'SGP'
        'OC-OMN-AZ'    | new CustomerVO(customerID: 3, customerName: "OC-OMN-AZ")     | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].administeringProvider.enabled'],['OC-OMN-AZ','CGP', 'false'])                                                                                                | 3         | 'CGP'
        'OC-SMA'       | new CustomerVO(customerID: 4, customerName: "OC-SMA")        | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].administeringProvider.enabled'],['OC-SMA','CGP', 'false'])                                                                                                   | 4         | 'CGP'
        'OC-OMN-UT'    | new CustomerVO(customerID: 5, customerName: "OC-OMN-UT")     | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].administeringProvider.enabled'],['OC-OMN-UT','CGP', 'false'])                                                                                                | 5         | 'CGP'
        'OC-OMN-CO'    | new CustomerVO(customerID: 6, customerName: "OC-OMN-CO")     | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].administeringProvider.enabled'],['OC-OMN-CO','CGP', 'false'])                                                                                                | 6         | 'CGP'
        'PHN'          | new CustomerVO(customerID: 6, customerName: "PHN")           | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].administeringProvider.enabled'],['PHN','CGP', 'false'])                                                                                                              | 7         | 'CGP'
        'ORX'          | new CustomerVO(customerID: 6, customerName: "ORX")           | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].administeringProvider.enabled'],['ORX','CGP', 'false'])                                                                                                      | 8         | 'CGP'
    }

    @Unroll
    def "Should throw UhgRuntimeException when fetching AdministeringProvider Configuration given microservice is down"(){
        given:

        when:
        federatedConfigServiceImpl.getAdministeringProviderByClientAndProduct(clientId, authType)

        then:
        1 * systemSettingsWebService.read(_) >> systemSettingsWebServiceVO
        1 * customer.read(_) >> customerVO
        1 * restTemplate.getForObject(*_) >> environment

        where:
        testCase       | customerVO                                                   | environment                                                                                                                |  clientId  | authType
        'UHC'          | new CustomerVO(customerID: 1, customerName: "UHC")           | getEnvironment(['spring.profiles.active','products[0].type', 'products[0].administeringProvider'], ['UHC', 'CGP', null])   |  1         |  'SGP'
        'BCBSSC'       | new CustomerVO(customerID: 2, customerName: "BCBSSC")        | getEnvironment(['spring.profiles.active','products'], ['BCBSSC', null])                                                    |  2         |  'CGP'
    }


    protected Environment getEnvironment(List<String> key, List <String> Data){
        List <PropertySource> propertySources = new ArrayList<>()
        Map<String, Object> map = new HashMap<>()
        for (int i = 0; i < key.size(); i++) {
            map.put(key[i],Data[i])
        }
        PropertySource propertySource = new PropertySource("xyz", map)
        propertySources.add(propertySource)
        Environment environment = new Environment("ABC")
        environment.add(propertySource)
        environment
    }

}
