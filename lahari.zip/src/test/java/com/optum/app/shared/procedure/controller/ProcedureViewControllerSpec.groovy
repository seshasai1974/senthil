package com.optum.app.shared.procedure.controller

import com.optum.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.member.core.data.MemberVO
import com.optum.app.ocm.controller.support.CommonResponse
import com.optum.app.shared.authorization.businesslogic.Authorizations
import com.optum.app.shared.constants.SpclCareReferenceConstants
import com.optum.app.shared.procedure.businesslogic.ProcedureView
import com.optum.app.shared.procedure.data.ProcedureViewDO
import com.optum.app.shared.procedure.data.ProcedureViewVO
import com.optum.app.shared.spclcare.SpecialtyCareReadLogicSpecification
import com.optum.rf.dao.sql.query.QueryCriteria
import com.optum.rf.dao.sql.query.QueryFilter
import com.optum.rf.dao.sql.query.QueryProperties

class ProcedureViewControllerSpec extends SpecialtyCareReadLogicSpecification {

    ProcedureViewController procedureViewController = new ProcedureViewController()
    ProcedureView procedureView = Mock(ProcedureView)
    Authorizations authorizations = Mock(Authorizations)

    def setup(){
        procedureViewController.procedureView = procedureView
        procedureViewController.authorizations = authorizations
    }

    def "Test list"() {
        given:
        List<ProcedureViewVO> procedureViewVOList = [new ProcedureViewVO()]

        when:
        CommonResponse commonResponse = procedureViewController.list()

        then:
        1 * procedureView.list(_ as QueryProperties) >> procedureViewVOList
        1 * procedureView.count(_ as QueryProperties)
        0 * _

        and:
        commonResponse.getEmbedded().get('_embedded') == procedureViewVOList
    }

    def "Test listByCustomerId"() {
        given:
        int customerId = 1
        List<ProcedureViewVO> procedureViewVOList = [new ProcedureViewVO()]

        when:
        CommonResponse commonResponse = procedureViewController.listByCustomerId(customerId)

        then:
        1 * authorizations.validateCustomer(customerId)
        1 * procedureView.listByCustomerId(customerId, _ as QueryProperties) >> procedureViewVOList
        0 * _

        and:
        commonResponse.getEmbedded().get('_embedded') == procedureViewVOList
    }

    def "Test listByCustomerIdAndAuthType"() {
        given:
        int customerId = 1
        String authType = SpclCareReferenceConstants.AUTH_TYPE_SPECIALTY_PHARMACY
        MemberVO memberVO = new MemberVO(memberID: 123)
        ProcedureViewDO procedureViewDO = new ProcedureViewDO(hscID: hscID, isPreferred: isPreferred, memberVO: memberVO)
        ProcedureViewVO procedureViewVO = new ProcedureViewVO()
        List<ProcedureViewVO> procedureViewVOList = [ procedureViewVO ]

        when:
        CommonResponse commonResponse = procedureViewController.listByCustomerIdAndAuthType(customerId, authType, procedureViewDO)

        then:
        1 * authorizations.validateCustomer(customerId)
        if(isPreferred) {
            1 * procedureView.listActivePreferred(_ as QueryProperties, memberVO) >> procedureViewVOList
        } else if(hscID) {
            1 * procedureView.readByHscID(12345) >> procedureViewVO
        } else {
            1 * procedureView.listByCustomerIdAndAuthType(customerId, authType, _ as QueryProperties) >> procedureViewVOList
        }
        0 * _

        and:
        if(hscID) {
            commonResponse.getEmbedded().get('_embedded') == procedureViewVO
        } else {
            commonResponse.getEmbedded().get('_embedded') == procedureViewVOList
        }

        where:
        hscID | isPreferred
        0     | false
        0     | true
        12345 | false
    }

    def "Test listCpt4Procedures"() {
        given:
        int customerId = 1
        String authType = SpclCareReferenceConstants.AUTH_TYPE_RADIATION_ONCOLOGY
        QueryProperties queryProperties = new QueryProperties(queryFilters: [new QueryFilter(fieldName: FieldConstants.PROCEDURECODE, fieldValue: 'G0', criterion: QueryCriteria.LIKE)])
        List<ProcedureViewVO> procedureViewVOList = [new ProcedureViewVO()]

        when:
        CommonResponse commonResponse = procedureViewController.listCpt4Procedures(customerId, authType, queryProperties)

        then:
        1 * authorizations.validateCustomer(customerId)
        1 * procedureView.listByCustomerIdAndAuthType(customerId, authType, _ as QueryProperties) >> procedureViewVOList
        0 * _

        and:
        commonResponse.getEmbedded().get('_embedded') == procedureViewVOList
    }

    def "Test listHcpcsProcedures"() {
        given:
        int customerId = 1
        String authType = SpclCareReferenceConstants.AUTH_TYPE_RADIATION_ONCOLOGY
        QueryProperties queryProperties = new QueryProperties(queryFilters: [new QueryFilter(fieldName: FieldConstants.PROCEDURECODE, fieldValue: 'G0', criterion: QueryCriteria.LIKE)])
        List<ProcedureViewVO> procedureViewVOList = [new ProcedureViewVO()]

        when:
        CommonResponse commonResponse = procedureViewController.listHcpcsProcedures(customerId, authType, queryProperties)

        then:
        1 * authorizations.validateCustomer(customerId)
        1 * procedureView.listByCustomerIdAndAuthType(customerId, authType, _ as QueryProperties) >> procedureViewVOList
        0 * _

        and:
        commonResponse.getEmbedded().get('_embedded') == procedureViewVOList
    }

}
