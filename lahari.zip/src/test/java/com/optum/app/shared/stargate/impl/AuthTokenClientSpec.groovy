package com.optum.app.shared.stargate.impl

import com.optum.app.shared.stargate.RestTemplateStargate
import com.optum.app.shared.stargate.data.AuthToken
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.client.HttpClientErrorException
import org.springframework.web.client.RestTemplate
import spock.lang.Specification
import spock.lang.Unroll

class AuthTokenClientSpec extends Specification {

    AuthTokenClientImpl authTokenClientImpl
    RestTemplateStargate restTemplateStargate
    RestTemplate restTemplate

    def setup() {
        authTokenClientImpl = new AuthTokenClientImpl()
        restTemplateStargate = Mock(RestTemplateStargate)
        restTemplate = Mock(RestTemplate)
        authTokenClientImpl.restTemplateStargate = restTemplateStargate
    }

    @Unroll
    def 'test buildHeader with authToken #testCase'() {
        given:
        AuthToken newToken = new AuthToken(expiresIn: 30, tokenType: 'Bearer', accessToken: 'test')

        when:
        HttpHeaders returnHeader = authTokenClientImpl.buildHeader()

        then:
        1 * restTemplateStargate.restTemplate() >> restTemplate
        1 * restTemplate.postForEntity(_, _, _) >> ResponseEntity.ok(newToken)
        returnHeader.get('Authorization').get(0) == newToken.getTokenType() + " " + newToken.getAccessToken()

        where:
        testCase | stargetURL                 | clientId | clientSecret
        1        | 'http://example.com:8082/' | 'client' | 'secret'
    }

    @Unroll
    def 'test buildHeader with blank token #testCase'() {
        given:
        AuthToken newToken = new AuthToken(expiresIn: 30, tokenType: 'Bearer', accessToken: '')

        when:
        HttpHeaders returnHeader = authTokenClientImpl.buildHeader()

        then:
        1 * restTemplateStargate.restTemplate() >> restTemplate
        1 * restTemplate.postForEntity(_, _, _) >> ResponseEntity.ok(newToken)
        and:
        HttpClientErrorException exception = thrown()
        exception.getStatusCode() == HttpStatus.UNAUTHORIZED

        where:
        testCase | stargetURL                 | clientId | clientSecret
        1        | 'http://example.com:8082/' | 'client' | 'secret'
    }

}
