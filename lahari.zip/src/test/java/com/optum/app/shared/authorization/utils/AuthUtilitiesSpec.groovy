package com.optum.app.shared.authorization.utils

import com.optum.app.common.member.core.data.MemberCoverageVO
import com.optum.app.common.member.core.data.MemberVO
import com.optum.app.shared.authorization.utils.AuthUtilities
import com.optum.app.shared.constants.SpclCareConstants
import com.optum.app.shared.ssoauthentication.data.OcmSsoData
import com.optum.app.shared.ssoauthentication.data.OcmSsoProviderData
import com.optum.rf.common.featureflag.util.FeatureFlagManager
import com.optum.rf.common.featureflag.util.FeatureFlagUtility
import com.optum.rf.common.security.data.UserSecurityVO
import com.optum.rf.dao.controller.session.Session
import com.optum.rf.dao.controller.session.SessionThreadLocal
import com.optum.rf.dao.exception.UhgRuntimeException
import com.optum.rf.dao.util.UhgCalendarUtilities
import com.optum.rf.web.controller.session.HttpUserSession
import spock.lang.Specification

import java.sql.Date

class AuthUtilitiesSpec extends Specification {
    FeatureFlagManager featureFlagManager = Mock(FeatureFlagManager)
    void setup() {
        FeatureFlagUtility.featureFlagManager =  featureFlagManager
    }

    def "GetSSOData does not throw NPE when session is null"() {
        setup:
           OcmSsoData ocmOssData = AuthUtilities.getSSOData()

        when:
           SessionThreadLocal.getSession() >> null

        then:
           ocmOssData == null

        and:
           notThrown NullPointerException
    }

    def "GetSSOProvider does not throw NPE when session is null"() {
        setup:
           OcmSsoProviderData ocmSsoProviderData = AuthUtilities.getSSOProvider()

        when:
           SessionThreadLocal.getSession() >> null

        then:
           ocmSsoProviderData == null

        and:
           notThrown NullPointerException
    }

    def "GetSSOProviderTIN"() {
        setup:
            String providerTIN = AuthUtilities.getSSOProviderTIN()

        when:
            AuthUtilities.getSSOProvider() >> null

        then:
            providerTIN == null

        and:
            notThrown NullPointerException
    }

    def "ValidateAuthorization when ExpiredCoverage Invalid DateRange"() {
        setup:
        Date coverageStartDate = UhgCalendarUtilities.getTodaysDate()-2
        Date coverageEndDate = UhgCalendarUtilities.getTodaysDate()-1
        Date authStartDate = UhgCalendarUtilities.getTodaysDate()

        MemberVO memberVO = new MemberVO(memberCoverageVOs: [new MemberCoverageVO(coverageEffectiveDate: coverageStartDate, coverageEndDate: coverageEndDate)])
        boolean  isChemoTherapy = false

        when:
        AuthUtilities.validateAuthorizationDate(memberVO,authStartDate,isChemoTherapy)

        then:
        _*_
        thrown (UhgRuntimeException.class)
    }

    def "ValidateAuthorization when ActiveCoverage Invalid DateRange"() {
        setup:
        Date coverageStartDate = UhgCalendarUtilities.getTodaysDate()-1
        Date coverageEndDate = UhgCalendarUtilities.getTodaysDate()+1
        Date authStartDate = UhgCalendarUtilities.getTodaysDate()-2

        MemberVO memberVO = new MemberVO(memberCoverageVOs: [new MemberCoverageVO(coverageEffectiveDate: coverageStartDate, coverageEndDate: coverageEndDate, memberCoverageSeqNum: 1)])
        boolean  isChemoTherapy = false

        when:
        AuthUtilities.validateAuthorizationDate(memberVO,authStartDate,isChemoTherapy)

        then:
        _*_
        thrown (UhgRuntimeException.class)
    }

    def "ValidateAuthorization when ActiveCoverage Invalid Date range for BCBS Outpatient Chemo"() {
        setup:
        Date coverageStartDate = UhgCalendarUtilities.getTodaysDate()-1
        Date coverageEndDate = UhgCalendarUtilities.getTodaysDate()+1
        Date authStartDate = UhgCalendarUtilities.getTodaysDate()+2

        MemberVO memberVO = new MemberVO(memberCoverageVOs: [new MemberCoverageVO(coverageEffectiveDate: coverageStartDate, coverageEndDate: coverageEndDate, memberCoverageSeqNum: 1)])
        boolean  isChemoTherapy = true

        when:
        AuthUtilities.validateAuthorizationDate(memberVO,authStartDate,isChemoTherapy)

        then:
        1 * featureFlagManager.isActive(*_) >> true
        _*_
        thrown (UhgRuntimeException.class)
    }

    def "ValidateAuthorization when ActiveCoverage AuthStartDate is not defined"() {
        setup:
        Date coverageStartDate = UhgCalendarUtilities.getTodaysDate()-1
        Date coverageEndDate = UhgCalendarUtilities.getTodaysDate()+1
        Date authStartDate = null

        MemberVO memberVO = new MemberVO(memberCoverageVOs: [new MemberCoverageVO(coverageEffectiveDate: coverageStartDate, coverageEndDate: coverageEndDate, memberCoverageSeqNum: 1)])
        boolean  isChemoTherapy = false

        when:
        AuthUtilities.validateAuthorizationDate(memberVO,authStartDate,isChemoTherapy)

        then:
        _*_
        thrown (UhgRuntimeException.class)
    }

    def "ValidateAuthorization when FutureCoverage Invalid DateRange"() {
        setup:
        Date coverageStartDate = UhgCalendarUtilities.getTodaysDate()+1
        Date coverageEndDate = UhgCalendarUtilities.getTodaysDate()+2
        Date authStartDate = UhgCalendarUtilities.getTodaysDate()+3

        MemberVO memberVO = new MemberVO(memberCoverageVOs: [new MemberCoverageVO(coverageEffectiveDate: coverageStartDate, coverageEndDate: coverageEndDate, memberCoverageSeqNum: 1)])
        boolean  isChemoTherapy = false

        when:
        AuthUtilities.validateAuthorizationDate(memberVO,authStartDate,isChemoTherapy)

        then:
        _*_
        thrown (UhgRuntimeException.class)
    }

    def "ValidateAuthorization when FutureCoverage ChemoTherapy Not Allowed"() {
        setup:
        Date coverageStartDate = UhgCalendarUtilities.getTodaysDate()+1
        Date coverageEndDate = UhgCalendarUtilities.getTodaysDate()+3
        Date authStartDate = UhgCalendarUtilities.getTodaysDate()+2

        MemberVO memberVO = new MemberVO(memberCoverageVOs: [new MemberCoverageVO(coverageEffectiveDate: coverageStartDate, coverageEndDate: coverageEndDate, memberCoverageSeqNum: 1)])
        boolean  isChemoTherapy = true

        when:
        AuthUtilities.validateAuthorizationDate(memberVO,authStartDate,isChemoTherapy)

        then:
        1 * featureFlagManager.isActive(*_) >> true
        _*_
        thrown (UhgRuntimeException.class)
    }

    def "ValidateAuthorization when ExpiredCoverage Provider BackDated Authorization Not Allowed"() {
        given:
        Session session = new HttpUserSession()
        session.setUserSecurity(new UserSecurityVO(userGroupID: userRole))
        SessionThreadLocal.setSession(session)

        Date coverageStartDate = UhgCalendarUtilities.getTodaysDate()-2
        Date coverageEndDate = UhgCalendarUtilities.getTodaysDate()-1
        Date authStartDate = UhgCalendarUtilities.getTodaysDate()-1

        MemberVO memberVO = new MemberVO(memberCoverageVOs: [new MemberCoverageVO(coverageEffectiveDate: coverageStartDate, coverageEndDate: coverageEndDate)])
        boolean  isChemoTherapy = false

        when:
        AuthUtilities.validateAuthorizationDate(memberVO,authStartDate,isChemoTherapy)

        then:
        _*_
        thrown (UhgRuntimeException.class)

        where:
        testCase | userRole
        0 | SpclCareConstants.ROLE_PROVIDER
    }

    def "ValidateAuthorization when Active Coverage Pass successfully"() {
        setup:
        Date coverageStartDate2 = UhgCalendarUtilities.getTodaysDate()-2
        Date coverageEndDate2 = UhgCalendarUtilities.getTodaysDate()+2
        Date authStartDate = UhgCalendarUtilities.getTodaysDate()
        Date coverageStartDate = UhgCalendarUtilities.getTodaysDate()-50
        Date coverageEndDate = UhgCalendarUtilities.getTodaysDate()-3

        MemberVO memberVO = new MemberVO(memberCoverageVOs: [new MemberCoverageVO(coverageEffectiveDate: coverageStartDate, coverageEndDate: coverageEndDate, memberCoverageSeqNum: 1),
                                                             new MemberCoverageVO(coverageEffectiveDate: coverageStartDate2, coverageEndDate: coverageEndDate2, memberCoverageSeqNum: 2)])
        boolean  isChemoTherapy = false

        when:
        AuthUtilities.validateAuthorizationDate(memberVO,authStartDate,isChemoTherapy)

        then:
        _*_
    }
}
