package com.optum.app.shared.user.controller

import com.optum.app.shared.user.businesslogic.UserHelper
import com.optum.app.shared.user.controller.UserController
import spock.lang.Specification

class UserControllerSpec extends Specification{
    UserController controller
    UserHelper userHelper

    def setup() {
        userHelper = Mock(UserHelper)
        controller = new UserController(userHelper: userHelper)
    }

    def 'Test isBriovaUser'() {
        when:
        controller.isBriovaUser()

        then:
        1 * userHelper.isBriovaUser()
        0 * _
    }
}
