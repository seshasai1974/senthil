package com.optum.app.shared.spclcare

import com.optum.rf.dao.tabledef.TableDefFactory
import com.optum.rf.test.core.spock.BaseReadLogicSpecification
import com.uhg.tabledef.spclcare.TableDefFactoryLoaderImpl

class SpecialtyCareReadLogicSpecification extends BaseReadLogicSpecification {
    // specify the Specialty Care built tabledef
    static {
        tableDefFactory = new TableDefFactory(TableDefFactoryLoaderImpl.newInstance())
    }
}
