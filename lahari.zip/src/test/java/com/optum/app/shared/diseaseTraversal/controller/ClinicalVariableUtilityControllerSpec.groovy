package com.optum.app.shared.diseaseTraversal.controller

import com.optum.app.ocm.controller.support.CommonResponse
import com.optum.app.shared.diseaseTraversal.businesslogic.ClinicalVariableHelper
import com.optum.app.shared.diseaseTraversal.controller.ClinicalVariableUtilityController
import com.optum.app.shared.diseaseTraversal.data.ClinicalVariableValidationDO
import spock.lang.Specification

class ClinicalVariableUtilityControllerSpec extends Specification {
    ClinicalVariableHelper helper = Mock(ClinicalVariableHelper)
    ClinicalVariableUtilityController controller = new ClinicalVariableUtilityController()

    def setup() {
           controller.clinicalVariableHelper = helper
    }
    def "ValidateClinicalVariables"() {
        given:
            def assessmentTemplateID = 123456
            def diseaseType = "ABadDisease"
            def clinicalVariableTypeValueMap = ["age" : 34, "weight" : 156]
            def missingClinicalVariableTypes = ["A", "B", "C"]


            ClinicalVariableValidationDO clinicalVariableValidateDO = new ClinicalVariableValidationDO()
            clinicalVariableValidateDO.assessmentTemplateID = assessmentTemplateID
            clinicalVariableValidateDO.diseaseType = diseaseType
            clinicalVariableValidateDO.clinicalVariableTypeValueMap = clinicalVariableTypeValueMap

            clinicalVariableValidateDO.missingClinicalVariableTypes = missingClinicalVariableTypes
            clinicalVariableValidateDO.missingClinicalVariableValues = []

        when:
            CommonResponse response = controller.validateClinicalVariables("")

        then:
            helper.validateClinicalVariablesForDiseaseType("") >>  clinicalVariableValidateDO
            with(response.embedded.get("_embedded")) {
                assessmentTemplateID == assessmentTemplateID
                diseaseType == diseaseType
                clinicalVariableTypeValueMap == clinicalVariableTypeValueMap
            }


    }

}
