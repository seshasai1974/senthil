package com.optum.app.shared.specialtyPharmacy.controller

import com.optum.app.common.hsr.data.HscAssessmentVO
import com.optum.app.common.hsr.data.HscSpecialtyProcedureVO
import com.optum.app.common.member.core.data.MemberVO
import com.optum.app.ocm.controller.support.CommonResponse
import com.optum.app.shared.constants.MultiPayerConstants
import com.optum.app.shared.constants.SpclCareFeatureFlagConstants
import com.optum.app.shared.procedure.data.ProcedureViewVO
import com.optum.app.shared.specialtyPharmacy.businesslogic.SpecialtyPharmacyHelper
import com.optum.app.shared.specialtyPharmacy.businesslogic.SpecialtyProceduresView
import com.optum.app.shared.specialtyPharmacy.data.SpecialtyPharmacyClinicalStatusDO
import com.optum.app.shared.specialtyPharmacy.data.SpecialtyProcedureExceptionRequestDO
import com.optum.app.shared.specialtyPharmacy.data.SpecialtyProceduresViewVO
import com.optum.rf.common.featureflag.util.FeatureFlagManager
import com.optum.rf.common.featureflag.util.FeatureFlagUtility
import com.optum.rf.dao.exception.UhgRuntimeException
import com.optum.rf.dao.sql.query.QueryProperties
import spock.lang.Specification
import spock.lang.Unroll

class SpecialtyPharmacyControllerSpec extends Specification {

    SpecialtyPharmacyController specialtyPharmacyController = new SpecialtyPharmacyController()
    SpecialtyPharmacyHelper specialtyPharmacyHelper = Mock(SpecialtyPharmacyHelper)
    SpecialtyProceduresView specialtyProceduresView = Mock(SpecialtyProceduresView)
    FeatureFlagManager featureFlagManager = Mock(FeatureFlagManager)

    def setup() {
        specialtyPharmacyController.specialtyPharmacyHelper = specialtyPharmacyHelper
        specialtyPharmacyController.specialtyProceduresView = specialtyProceduresView
        FeatureFlagUtility.featureFlagManager = featureFlagManager
    }

    def "saveClinicalStatus"() {
        given:
        SpecialtyPharmacyClinicalStatusDO requestDO = new SpecialtyPharmacyClinicalStatusDO(hscAssessmentVO: new HscAssessmentVO(hscID: 1234L))
        SpecialtyPharmacyClinicalStatusDO responseDO = new SpecialtyPharmacyClinicalStatusDO(autoApprove: true)
        int customerId = 1
        System.setProperty(MultiPayerConstants.APPROVAL_TYPE, "${customerId}")

        when:
        CommonResponse response = specialtyPharmacyController.saveClinicalStatus(requestDO)

        then:
        1 * specialtyPharmacyHelper.saveClinicalStatus(customerId, requestDO) >> responseDO
        0 * _

        and:
        response.getEmbedded().get('_embedded') == responseDO
    }

    def "getSpecialtyProcedureID"() {
        given:
        long hscID = 1234L
        SpecialtyProceduresViewVO specialtyProceduresViewVO = new SpecialtyProceduresViewVO(specialtyProcedureID: 5555L)
        ProcedureViewVO procedureViewVO = new ProcedureViewVO(procedureBenefitID: 5555L)

        when:
        CommonResponse response = specialtyPharmacyController.getSpecialtyProcedureByHscID(hscID)

        then:
        1 * specialtyProceduresView.readByHscID(hscID) >> specialtyProceduresViewVO
        0 * _

        and:
        response.getEmbedded().get('_embedded') == specialtyProceduresViewVO
    }

    @Unroll
    def "isSpecialtyProcedureException #testCaseMember"() {
        given:
        SpecialtyProcedureExceptionRequestDO specialtyProcedureExceptionRequestDO = new SpecialtyProcedureExceptionRequestDO()
        specialtyProcedureExceptionRequestDO.exceptionType = exception

        when:
        CommonResponse response = specialtyPharmacyController.isSpecialtyProcedureException(specialtyProcedureExceptionRequestDO)

        then:
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.CHECK_MEMBER_EXCEPTION) >> featureFlag
        1 * specialtyPharmacyHelper.isSpecialtyMemberProcedureException(specialtyProcedureExceptionRequestDO) >> memberDrugException
        1 * _

        and:
        response.getEmbedded().get('_embedded') == expectedResult

        where:
        testCase | expectedResult | memberDrugException | featureFlag | exception
        0        | false          | false               | false       | 'Member Exception'
        1        | true           | true                | false       | 'Member Exception'
    }

    @Unroll
    def "isSpecialtyProcedureException #testCaseProvider"() {
        given:
        SpecialtyProcedureExceptionRequestDO specialtyProcedureExceptionRequestDO = new SpecialtyProcedureExceptionRequestDO()
        specialtyProcedureExceptionRequestDO.exceptionType = exception

        when:
        CommonResponse response = specialtyPharmacyController.isSpecialtyProcedureException(specialtyProcedureExceptionRequestDO)

        then:
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.CHECK_SERVICING_PROVIDER_EXCEPTION) >> featureFlag
        1 * specialtyPharmacyHelper.isSpecialtyProviderProcedureException(specialtyProcedureExceptionRequestDO) >> providerDrugException
        1 * _

        and:
        response.getEmbedded().get('_embedded') == expectedResult

        where:
        testCase | expectedResult | providerDrugException | featureFlag | exception
        0        | false          | false                 | false       | 'Provider Exception'
        1        | true           | true                  | false       | 'Provider Exception'
    }

    @Unroll
    def 'displayDraftPopup #testCase'() {
        given:
        CommonResponse expected = new CommonResponse()
        expected.embedded = droolsReturn
        long hscId = 1

        when:
        CommonResponse commonResponse = specialtyPharmacyController.displayDraftPopup(hscId)

        then:
        specialtyPharmacyHelper.displayDraftPopup(*_) >> droolsReturn

        and:
        0 * _

        and:
        commonResponse.embedded == expected.embedded

        where:
        testCase        | droolsReturn
        'true return'   | true
        'false return'  | false
    }

    @Unroll
    def 'displayDraftPopup exceptions #testCase'() {
        given:
        long hscId = 1

        when:
        specialtyPharmacyController.displayDraftPopup(hscId)

        then:
        specialtyPharmacyHelper.displayDraftPopup(*_) >> { throw new UhgRuntimeException() }

        and:
        0 * _

        and:
        thrown UhgRuntimeException

        where:
        testCase                        | hscSpecialtyProcedureVO
        'Drools error'                  | new HscSpecialtyProcedureVO()
    }

    @Unroll
    def 'listAllPreferredActiveSpecialtyProcedures'() {
        given:
        MemberVO memberVO = new MemberVO(memberID: 12345, customerID: 1, primaryMedMemberCoverageSeqNum: 1)

        when:
        specialtyPharmacyController.listAllPreferredActiveSpecialtyProcedures(memberVO)

        then:
        1 * specialtyProceduresView.listActivePreferred(_ as QueryProperties, memberVO)
        0 * _
    }

}
