package com.optum.app.shared.drugRounding.helper

import com.optum.app.shared.diseaseTraversal.businesslogic.TreatmentRegimenVersion
import com.optum.app.shared.diseaseTraversal.data.TreatmentRegimenVersionVO
import com.optum.app.shared.drugRounding.businesslogic.DrugParsing
import com.optum.app.shared.drugRounding.data.DrugPackagingDO
import com.optum.app.shared.drugRounding.data.DrugPackagingVialsDO
import com.optum.app.shared.drugRounding.data.DrugParsedDO
import com.optum.app.shared.drugRounding.data.VialsDO
import com.optum.app.shared.drugRounding.helper.impl.DrugRoundingHelperImpl
import com.optum.app.shared.procedure.businesslogic.ProcedureBrand
import com.optum.app.shared.procedure.data.ProcedureBrandVO
import com.optum.app.shared.spclcare.SpecialtyCareReadLogicSpecification
import com.optum.rf.common.reference.businesslogic.Hcpcs
import com.optum.rf.common.reference.data.HcpcsVO
import com.optum.app.common.hsr.businesslogic.Hsc
import com.optum.app.common.hsr.constants.HsrReferenceConstants
import com.optum.app.common.hsr.data.HscMeasurementVO
import com.optum.app.common.hsr.data.HscVO
import spock.lang.Unroll

class DrugRoundingHelperImplSpec extends SpecialtyCareReadLogicSpecification {

    private DrugRoundingHelperImpl drugRoundingHelperImpl
    private Hsc hsc
    private TreatmentRegimenVersion treatmentRegimenVersion
    private DrugPackagingService drugPackagingService
    private Hcpcs hcpcs
    private ProcedureBrand procedureBrand
    private DrugParsing drugParsing

    def setup() {
        drugRoundingHelperImpl = new DrugRoundingHelperImpl()
        treatmentRegimenVersion = Mock(TreatmentRegimenVersion)
        hsc = Mock(Hsc)
        drugPackagingService = Mock(DrugPackagingService)
        procedureBrand = Mock(ProcedureBrand)
        hcpcs = Mock(Hcpcs)
        drugParsing = Mock(DrugParsing)
        drugRoundingHelperImpl.hsc = hsc
        drugRoundingHelperImpl.treatmentRegimenVersion = treatmentRegimenVersion
        drugRoundingHelperImpl.drugPackagingService = drugPackagingService
        drugRoundingHelperImpl.procedureBrand = procedureBrand
        drugRoundingHelperImpl.hcpcs = hcpcs
        drugRoundingHelperImpl.drugParsing = drugParsing
    }

    @Unroll
    def 'test getDrugPackagingInfo' () {
        given:
        List<DrugParsedDO> drugParsedDOList = new ArrayList<DrugParsedDO>([new DrugParsedDO(procedureCode: "X9999", totalDosage: 80.0), new DrugParsedDO(procedureCode: "Y9999", totalDosage: 70.0)])
        Set<VialsDO> vialsDto = new HashSet<>()
        vialsDto.add(new VialsDO(id:  3244L,vial:  "100 mg"))
        DrugPackagingDO drugPackagingDO = new DrugPackagingDO(drugPackaging:new ArrayList<DrugPackagingVialsDO>([new DrugPackagingVialsDO (drugBrandName : 'xyzbrand',vials:  vialsDto)]))
        when:
        drugRoundingHelperImpl.getDrugPackagingInfo(drugParsedDOList)

        then:
        _ * procedureBrand.list(_) >> procBrand
        _ * hcpcs.list(_) >> hcpcsVOList
        _ * drugParsing.getBrandNameFromString(_) >> brandName
        (0..1) * drugPackagingService.getDrugsPackaging("xyzbrand") >> drugPackagingDO

        where:
        testCase  |   procBrand                                              | hcpcsVOList                                                                               | brandName
        0         |  null                                                    | null                                                                                      | null
        1         |  [new ProcedureBrandVO(procedureBrandName: "xyzbrand")]  | null                                                                                      | null
        2         |  null                                                    | [new HcpcsVO(shortDescription: "DOXORUBICIN LIPO")]                                       | null
        3         |  null                                                    | [new HcpcsVO(shortDescription: "DOXORUBICIN")]                                            | null
        4         |  null                                                    | [new HcpcsVO(shortDescription: "XYZ Drug", fullDescription: "XYZ Drug (XYZ&reg;) 10 mg")] | "XYZ&reg;"

    }

    @Unroll
    def 'test mapParsedDrugsVials' (){
        given:
        List<DrugPackagingVialsDO>  listHashMap = new ArrayList<>()
        Set<VialsDO> vialsDto = new HashSet<>()
        vialsDto.add(new VialsDO(id:  1234L,vial:  "500 mg"))
        listHashMap.add(new DrugPackagingVialsDO (drugBrandName : 'xyzbrand',vials:  vialsDto))
        DrugPackagingDO drugVialsList = new DrugPackagingDO()
        drugVialsList.setDrugPackaging(listHashMap)

        Map<String, DrugParsedDO> drugBrandParsedMap = new HashMap<>()
        drugBrandParsedMap.put('xyzbrand', new DrugParsedDO(procedureCode: "X9999", totalDosage: 80.0))

        List<DrugParsedDO> drugParsedDOList = new ArrayList<>()
        drugParsedDOList.putAt(0, new DrugParsedDO(procedureCode: "X9999", totalDosage: 80.0))

        when:
        drugRoundingHelperImpl.mapParsedDrugsVials(drugVialsList, drugBrandParsedMap, drugParsedDOList)

        then:
        _ * drugParsing.getDecimalsFromString(_) >> [70,50]
        _

    }

    @Unroll
    def 'test constructRoundingDosageResponse' (){
        expect:
        drugRoundingHelperImpl.constructRoundingDosageResponse(listOfVials, singleDosage) == val

        where:
        testCase | listOfVials  | singleDosage | val
        0        | [500,100,50] | 647          | 650 // Vials Combination:- 500 + 100 + 50
        1        | [50,80]      | 285          | 290 // Vials Combination:- 80 * 3 + 50
        2        | [50,80]      | 315          | 320 // Vials Combination:- 80 * 4
        3        | [50,80]      | 320          | 320 // Vials Combination:- 80 * 4
        4        | [0.5,1.1]    | 3.42         | 3.5 // Vials Combination:- 0.5 * 5
        5        | [0.5,1.1]    | 3.62         | 3.7 // Vials Combination:- 1.1 * 2 + 0.5 * 3

    }

    @Unroll
    def 'test getAuthDurationInDays' () {
        given:
        HscVO hscVO = new HscVO(diseaseTraversalID: 0, reqTreatmentRegimenVersionID: 0)

        when:
        drugRoundingHelperImpl.getAuthDurationInDays(hscVO)

        then:
        1 * treatmentRegimenVersion.read(_) >> new TreatmentRegimenVersionVO()

    }

    @Unroll
    def 'test getBSA' () {
        given:
        HscVO hscVO = new HscVO(hscMeasurementVOs: hscMeasurementVOs)

        when:
        double val = drugRoundingHelperImpl.getBSA(hscVO)

        then:
        val == bsa

        where:
        testCase | bsa                      | hscMeasurementVOs
        0        | 0                        | [new HscMeasurementVO(measurementType: HsrReferenceConstants.MEASUREMENTTYPE_HEIGHT, measurementValueDescription: '192', unitOfMeasureType: HsrReferenceConstants.UNITOFMEASURETYPE_CENTIMETERS)]
        1        | 0                        | [new HscMeasurementVO(measurementType: HsrReferenceConstants.MEASUREMENTTYPE_WEIGHT, measurementValueDescription: '75', unitOfMeasureType: HsrReferenceConstants.UNITOFMEASURETYPE_KILOGRAMS)]
        2        | 2.0354514661775616       | [new HscMeasurementVO(measurementType: HsrReferenceConstants.MEASUREMENTTYPE_HEIGHT, measurementValueDescription: '192', unitOfMeasureType: HsrReferenceConstants.UNITOFMEASURETYPE_CENTIMETERS), new HscMeasurementVO(measurementType: HsrReferenceConstants.MEASUREMENTTYPE_WEIGHT, measurementValueDescription: '75', unitOfMeasureType: HsrReferenceConstants.UNITOFMEASURETYPE_KILOGRAMS)]
        3        | 1.7661394967819322       | [new HscMeasurementVO(measurementType: HsrReferenceConstants.MEASUREMENTTYPE_HEIGHT, measurementValueDescription: '75', unitOfMeasureType: HsrReferenceConstants.UNITOFMEASURETYPE_INCHES), new HscMeasurementVO(measurementType: HsrReferenceConstants.MEASUREMENTTYPE_WEIGHT, measurementValueDescription: '120', unitOfMeasureType: HsrReferenceConstants.UNITOFMEASURETYPE_POUNDS)]
    }

}
