package com.optum.app.shared.drugRounding.mapper

import com.optum.app.shared.drugRounding.mapper.impl.DrugPackagingRequestMapperImpl
import com.optum.app.shared.microservice.constants.RestConstants
import com.optum.clinical.security.jwt.client.service.JwtClientService
import com.optum.rf.common.settings.businesslogic.SystemSettingsWebService
import com.optum.rf.common.settings.data.SystemSettingsWebServiceVO
import org.springframework.http.HttpHeaders
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory
import org.springframework.web.client.HttpClientErrorException
import org.springframework.web.client.RestTemplate
import spock.lang.Specification
import spock.lang.Unroll

import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpSession

class DrugPackagingRequestMapperImplSpec extends Specification {

    DrugPackagingRequestMapperImpl drugPackagingRequestMapperImpl
    RestTemplate restTemplate
    SystemSettingsWebService systemSettingsWebService
    JwtClientService jwtClientService
    HttpSession httpSession
    HttpServletRequest httpServletRequest

    def setup() {
        drugPackagingRequestMapperImpl = new DrugPackagingRequestMapperImpl()
        restTemplate = Mock(RestTemplate)
        systemSettingsWebService = Mock(SystemSettingsWebService)
        jwtClientService = Mock(JwtClientService)
        httpSession = Mock(HttpSession)
        httpServletRequest = Mock(HttpServletRequest)
        drugPackagingRequestMapperImpl.systemSettingsWebService = systemSettingsWebService
        drugPackagingRequestMapperImpl.jwtClientService = jwtClientService
        drugPackagingRequestMapperImpl.httpSession = httpSession
        drugPackagingRequestMapperImpl.httpServletRequest = httpServletRequest
    }

    @Unroll
    def "test getSystemSettingsWebServiceVO"() {
        given:
        SystemSettingsWebServiceVO systemSettingsWebServiceVO = new SystemSettingsWebServiceVO()

        when:
        SystemSettingsWebServiceVO systemSettingsWebServiceV01 = drugPackagingRequestMapperImpl.getSystemSettingsWebServiceVO()

        then:
        1 * systemSettingsWebService.read(RestConstants.WS_ID_DRUG_PACKAGING) >> systemSettingsWebServiceVO
        systemSettingsWebServiceVO == systemSettingsWebServiceV01
    }

    @Unroll
    def "test getSystemSettingsWebServiceVO exception thrown"() {
        given:

        when:
        drugPackagingRequestMapperImpl.getSystemSettingsWebServiceVO()

        then:
        thrown(HttpClientErrorException)
    }

    @Unroll
    def "test getDrugPackagingRestTemplate"() {
        given:
        HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory()
        requestFactory.setConnectTimeout(RestConstants.DRUG_PACKAGING_CONNECTION_TIMEOUT)
        requestFactory.setReadTimeout(RestConstants.DRUG_PACKAGING_READ_TIMEOUT)

        when:
        drugPackagingRequestMapperImpl.getDrugPackagingRestTemplate(restTemplate)
        then:
        1 * restTemplate.getRequestFactory() >> requestFactory
        1 * restTemplate.setRequestFactory(requestFactory)
    }

    def "test buildHttpHeader"() {
        given:

        when:
        HttpHeaders headers = drugPackagingRequestMapperImpl.buildHttpHeader()

        then:
        1 * jwtClientService.getToken(RestConstants.JWTTOKEN_NAME, RestConstants.JWTTOKEN_NAME, 30) >> 'tokenString'
        1 * httpSession.getId()
        1 * httpServletRequest.getHeader(RestConstants.MBM_TRANSACTION_ID)
        0 * _

        and:
        headers
    }


}
