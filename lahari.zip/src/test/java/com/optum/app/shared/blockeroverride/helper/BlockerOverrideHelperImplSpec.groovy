package com.optum.app.shared.blockeroverride.helper

import com.fasterxml.jackson.databind.ObjectMapper
import com.optum.app.ocm.controller.support.CommonResponse
import com.optum.app.shared.blockeroverride.businesslogic.BlockerOverride
import com.optum.app.shared.blockeroverride.data.BlockerOverrideVO
import com.optum.app.shared.blockeroverride.data.CustomBlockerDetailsDO
import com.optum.app.shared.blockeroverride.helper.impl.BlockerOverrideHelperImpl
import com.optum.app.shared.spclcare.SpecialtyCareReadLogicSpecification
import com.optum.rf.common.security.businesslogic.UserGroupPermissionGroup
import com.optum.rf.common.security.businesslogic.UserPermissionGroup
import com.optum.rf.common.security.data.UserSecurityVO
import com.optum.rf.common.webservice.logging.businesslogic.WebServiceLog
import com.optum.rf.dao.controller.session.SessionThreadLocal
import com.optum.rf.web.controller.session.HttpUserSession
import spock.lang.Unroll

class BlockerOverrideHelperImplSpec extends SpecialtyCareReadLogicSpecification {
    BlockerOverrideHelper blockerOverrideHelper
    BlockerOverride blockerOverride
    WebServiceLog webServiceLog
    ObjectMapper jsonObjectMapper
    UserPermissionGroup userPermissionGroup
    UserGroupPermissionGroup userGroupPermissionGroup
    public final static String BLOCKER_OVERRIDE = 'BLOCKER_OVERRIDE'

    def setup() {
        blockerOverrideHelper = new BlockerOverrideHelperImpl()
        blockerOverride = Mock(BlockerOverride)
        webServiceLog = Mock(WebServiceLog)
        jsonObjectMapper = Mock(ObjectMapper)
        userPermissionGroup = Mock(UserPermissionGroup)
        userGroupPermissionGroup = Mock(UserGroupPermissionGroup)

        blockerOverrideHelper.blockerOverride = blockerOverride
        blockerOverrideHelper.webServiceLog = webServiceLog
        blockerOverrideHelper.jsonObjectMapper = jsonObjectMapper
        blockerOverrideHelper.userPermissionGroup = userPermissionGroup
        blockerOverrideHelper.userGroupPermissionGroup = userGroupPermissionGroup
    }

    @Unroll
    def 'test checkOverridePermission userID Given'() {
        given:
        HttpUserSession session = new HttpUserSession()
        session.setUserSecurity(new UserSecurityVO(userID: 'testID'))
        SessionThreadLocal.setSession(session)

        when:
        CommonResponse commonResponse = blockerOverrideHelper.checkOverridePermission()

        then:
        1 * userPermissionGroup.read(SessionThreadLocal.getSession()?.getUserSecurity()?.getUserID(), BLOCKER_OVERRIDE)
        (0..1) * userGroupPermissionGroup.read(SessionThreadLocal.getSession()?.getUserSecurity()?.getUserGroupID(), BLOCKER_OVERRIDE)
        1 * webServiceLog.addNewTransaction(_)
        _ * _
    }

    @Unroll
    def 'test checkOverridePermission userGroupID Given'() {
        given:
        HttpUserSession session = new HttpUserSession()
        session.setUserSecurity(new UserSecurityVO(userGroupID: 'testGroup'))
        SessionThreadLocal.setSession(session)

        when:
        CommonResponse commonResponse = blockerOverrideHelper.checkOverridePermission()

        then:
        1 * userPermissionGroup.read(SessionThreadLocal.getSession()?.getUserSecurity()?.getUserID(), BLOCKER_OVERRIDE)
        1 * userGroupPermissionGroup.read(SessionThreadLocal.getSession()?.getUserSecurity()?.getUserGroupID(), BLOCKER_OVERRIDE)
        1 * webServiceLog.addNewTransaction(_)
        _ * _
    }

    @Unroll
    def 'test overrideBlockers'() {
        when:
        CommonResponse commonResponse = blockerOverrideHelper.overrideBlockers(customBlockerDetailsDO)

        then:
        1 * blockerOverride.deleteByHscIDOverrideTypeIDList(customBlockerDetailsDO.getBlockerOverrideVOList().get(0).hscID, customBlockerDetailsDO.getOverrideTypeIDList())
        1 * blockerOverride.saveAll(customBlockerDetailsDO.getBlockerOverrideVOList())
        1 * webServiceLog.addNewTransaction(_)
        _ * _

        where:
        testCase | customBlockerDetailsDO
        0        | new CustomBlockerDetailsDO(overrideTypeIDList: Arrays.asList(1), blockerOverrideVOList: Arrays.asList(new BlockerOverrideVO(hscID: 1234L, overrideTypeID: "1", overrideReasonCode: "2", overrideDescription: "abc", primaryServiceReferenceNum: "A1234")))
        1        | new CustomBlockerDetailsDO(overrideTypeIDList: Arrays.asList(1,3), blockerOverrideVOList: Arrays.asList(new BlockerOverrideVO(hscID: 1234L, overrideTypeID: "1", overrideReasonCode: "2", overrideDescription: "abc", primaryServiceReferenceNum: "A1234"), new BlockerOverrideVO(hscID: 1234L, overrideTypeID: "3", overrideReasonCode: "4", overrideDescription: "abc", primaryServiceReferenceNum: "A1234")))
        2        | new CustomBlockerDetailsDO(overrideTypeIDList: Arrays.asList(1), blockerOverrideVOList: Arrays.asList(new BlockerOverrideVO()))
    }

    @Unroll
    def 'test getOverriddenBlockers'(){
        when:
        blockerOverrideHelper.getOverriddenBlockers(hscID)

        then:
        1 * blockerOverride.listByHscID(hscID) >> result
        1 * webServiceLog.addNewTransaction(_)

        where:
        testCase | hscID  | result
        0        |  1L    | Arrays.asList(new BlockerOverrideVO(hscID: 1, overrideTypeID: "1", overrideReasonCode: "2", overrideDescription: "abc", primaryServiceReferenceNum: "1234"))
        1        |  2L    | Arrays.asList(new BlockerOverrideVO(hscID: 2, overrideTypeID: "3", overrideReasonCode: "3", overrideDescription: "abc", primaryServiceReferenceNum: "1234"))
        2        |  3L    | Arrays.asList(new BlockerOverrideVO(hscID: 3, overrideTypeID: "1", overrideReasonCode: "2", overrideDescription: "abc", primaryServiceReferenceNum: "1234"), new BlockerOverrideVO(hscID: 3, overrideTypeID: "3", overrideReasonCode: "3", overrideDescription: "abc", primaryServiceReferenceNum: "1234"))
        3        |  4L    | Arrays.asList(new BlockerOverrideVO(hscID: 4, overrideTypeID: "1", overrideReasonCode: "2", overrideDescription: "abc", primaryServiceReferenceNum: "1234"), new BlockerOverrideVO(hscID: 4, overrideTypeID: "3", overrideReasonCode: "3", overrideDescription: "abc", primaryServiceReferenceNum: "1234"))
    }

    @Unroll
    def 'test deleteSpecificOverriddenBlockers'() {
        given:

        when:
        CommonResponse commonResponse = blockerOverrideHelper.deleteSpecificOverriddenBlockers(hscID, overrideTypeIDList)

        then:
        1 * blockerOverride.deleteByHscIDOverrideTypeIDList(hscID, overrideTypeIDList)
        1 * webServiceLog.addNewTransaction(_)
        _ * _

        where:
        testCase | hscID | overrideTypeIDList
        0        | 1L    | Arrays.asList(new Long(1L), new Long(3L))
        1        | 2L    | Arrays.asList(new Long(3L))
    }
}
