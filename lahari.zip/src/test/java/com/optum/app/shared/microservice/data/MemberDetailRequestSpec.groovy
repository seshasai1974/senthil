package com.optum.app.shared.microservice.data

import com.optum.app.shared.microservice.data.MemberDetailRequest
import org.apache.commons.lang.StringUtils
import spock.lang.Specification

class MemberDetailRequestSpec extends Specification {
    MemberDetailRequest memberDetailRequest

    def setup() {
        memberDetailRequest = new MemberDetailRequest(cdbXrefId: 'MBM_TEST', cdbXrefIdPartitionNumber: 'TESTING')
    }

    def "equals true"() {

        when:
        boolean retVal = memberDetailRequest.equals(memberDetailRequest)

        then:
        0 * _

        and:
        retVal
    }

    def "equals false"() {
        given:
        MemberDetailRequest object = new MemberDetailRequest(cdbXrefId: 'MBM_TEST', cdbXrefIdPartitionNumber: 'TESTING')

        when:
        boolean retVal = object.equals(_)

        then:
        0 * _

        and:
        !retVal
    }

    def "hash"() {
        given:

        MemberDetailRequest object = new MemberDetailRequest(cdbXrefId: 'MBM_TEST', cdbXrefIdPartitionNumber: 'TESTING', policyNumber: 'AAA', asOfDate: '2019-01-01')

        when:
        int retVal = object.hashCode()

        then:
        0 * _

        and:
        retVal
        retVal > 0
    }

    def "to String"() {
        given:

        MemberDetailRequest object = new MemberDetailRequest(cdbXrefId: 'MBM_TEST', cdbXrefIdPartitionNumber: 'TESTING')

        when:
        String retVal = object.toString()

        then:
        0 * _

        and:
        StringUtils.isNotBlank(retVal)
    }
}
