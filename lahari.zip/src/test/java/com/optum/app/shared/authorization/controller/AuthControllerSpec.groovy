package com.optum.app.shared.authorization.controller

import com.optum.app.ocm.controller.support.CommonResponse
import com.optum.app.shared.authorization.businesslogic.Auth
import com.optum.app.shared.authorization.service.AuthService
import com.optum.app.shared.constants.MultiPayerConstants
import com.optum.app.shared.constants.SpclCareReferenceConstants
import com.optum.app.shared.hsc.businesslogic.HscHelper
import com.optum.app.shared.hsc.data.AuthRequestDetailsDO
import com.optum.app.shared.microservice.data.AuthRequestDO
import com.optum.app.shared.microservice.data.AuthResponseDO
import com.optum.app.shared.spclcare.SpecialtyCareReadLogicSpecification
import com.optum.app.common.hsr.data.HscAttributeVO
import spock.lang.Unroll

class AuthControllerSpec extends SpecialtyCareReadLogicSpecification {

    AuthController authController
    AuthService authService
    Auth auth
    HscHelper hscHelper

    def setup() {
        authController = new AuthController()
        auth = Mock(Auth)
        hscHelper = Mock(HscHelper)
        authService = Mock(AuthService)

        authController.auth = auth
        authController.authService = authService
        authController.hscHelper = hscHelper
    }

    @Unroll
    def "test authorize success #testCase"() {
        when:
        CommonResponse response = authController.authorize(hscID, new AuthRequestDetailsDO())

        then:
        1 * authService.processAuthSubmission(new AuthRequestDO(hscID: hscID ?: 0L), _) >> new CommonResponse().setEmbedded(new AuthResponseDO(hscID: hscID ?: 0L))
        ((AuthResponseDO) response.getEmbedded().get(CommonResponse.EMBEDDED)).getHscID() == (hscID ?: 0L)

        where:
        testCase | hscID
        0        | 12L
        1        | null
    }

    @Unroll
    def "test update success #testCase"() {
        given:
        int customerId = 1
        System.setProperty(MultiPayerConstants.APPROVAL_TYPE, "${customerId}")

        when:
        CommonResponse response = authController.update(hscID, authRequestDetailsDO)

        then:
        1 * hscHelper.saveHscAttributesPostSubmission(authRequestDetailsDO.getHscAttributeVOs())
        1 * auth.updateAuthorizationBackDating(customerId, new AuthRequestDO(hscID: hscID ?: 0L)) >> new CommonResponse().setEmbedded(new AuthResponseDO(hscID: hscID ?: 0L))
        ((AuthResponseDO) response.getEmbedded().get(CommonResponse.EMBEDDED)).getHscID() == (hscID ?: 0L)

        where:
        testCase | hscID | authRequestDetailsDO
        0        | 12L   | new AuthRequestDetailsDO(hscAttributeVOs: [new HscAttributeVO(hscID: 0L, hscAttributeType: SpclCareReferenceConstants.HSCATTRIBUTETYPE_BACKDATING_AUTH, hscAttributeValue: '1')])
        1        | null  | new AuthRequestDetailsDO(hscAttributeVOs: [new HscAttributeVO(hscID: 0L, hscAttributeType: SpclCareReferenceConstants.HSCATTRIBUTETYPE_BACKDATING_AUTH, hscAttributeValue: '1')])
    }
}

