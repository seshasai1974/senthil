package com.optum.app.shared.microservice.data

import com.optum.app.shared.microservice.data.MemberDetailsItem
import com.optum.app.shared.microservice.data.MemberDetailsResponse
import org.apache.commons.lang.StringUtils
import spock.lang.Specification

class MemberDetailsResponseSpec extends Specification {
    MemberDetailsResponse detailsResponse

    def setup() {
        MemberDetailsItem memberDetailsItem = new MemberDetailsItem(firstName: 'fName', lastName: 'lName')
        List<MemberDetailsItem> memberDetails = [memberDetailsItem]

        detailsResponse = new MemberDetailsResponse(memberDetails: memberDetails)
    }

    def "getDetailItems"() {

        when:
        List<MemberDetailsItem> retVal = detailsResponse.getDetailItems()

        then:
        0 * _

        and:
        !retVal.isEmpty()
    }

    def "setDetailItems"() {

        when:
        List<MemberDetailsItem> retVal = detailsResponse.setDetailItems([])

        then:
        0 * _

        and:
        !retVal
    }

    def "equals true"() {

        when:
        boolean retVal = detailsResponse.equals(detailsResponse)

        then:
        0 * _

        and:
        retVal
    }

    def "equals false"() {

        when:
        boolean retVal = detailsResponse.equals(_)

        then:
        0 * _

        and:
        !retVal
    }

    def "hash"() {

        when:
        int retVal = detailsResponse.hashCode()

        then:
        0 * _

        and:
        retVal
        retVal > 0
    }

    def "to String"() {

        when:
        String retVal = detailsResponse.toString()

        then:
        0 * _

        and:
        StringUtils.isNotBlank(retVal)
    }
}
