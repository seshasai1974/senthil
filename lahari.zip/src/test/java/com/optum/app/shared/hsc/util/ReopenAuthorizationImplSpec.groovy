package com.optum.app.shared.hsc.util

import com.optum.app.shared.constants.SpclCareReferenceConstants
import com.optum.app.shared.hsc.data.ReopenAuthDO
import com.optum.app.shared.jbpm.data.JbpmConstants
import com.optum.app.shared.workqueue.businesslogic.MbmWorkQueueSearch
import com.optum.app.shared.workqueue.mapper.MbmWorkQueueSearchRequestMapper
import com.optum.mbm.workqueue.data.v3.response.ItemTaskCriteriaResponse
import com.optum.rf.common.featureflag.util.FeatureFlagManager
import com.optum.rf.common.featureflag.util.FeatureFlagUtility
import com.optum.rf.common.security.data.UserSecurityVO
import com.optum.rf.dao.controller.session.SessionThreadLocal
import com.optum.rf.web.controller.session.HttpUserSession
import com.optum.app.common.activity.data.ActivityVO
import com.optum.app.common.hsr.businesslogic.Hsc
import com.optum.app.common.hsr.data.HscVO
import com.optum.app.common.member.core.data.MemberVO
import com.optum.app.ocm.common.member.businesslogic.Member
import com.optum.app.shared.jbpm.JbpmHelper
import spock.lang.Specification
import com.optum.app.shared.hsc.businesslogic.HscHelper

class ReopenAuthorizationImplSpec extends Specification {
    private ReopenAuthorizationImpl reopenAuthorizationImpl
    MbmWorkQueueSearchRequestMapper mbmWorkQueueSearchRequestMapper = Mock(MbmWorkQueueSearchRequestMapper)
    FeatureFlagManager featureFlagManager
    private Hsc hsc = Mock(Hsc)
    private MbmWorkQueueSearch mbmWorkQueueSearch = Mock(MbmWorkQueueSearch)
    private Member member = Mock(Member)
    private JbpmHelper jbpmHelper = Mock(JbpmHelper)
    private HscHelper hscHelper = Mock(HscHelper)
    private final static long TEST_HSC_ID = 1234L

    def setup() {
        reopenAuthorizationImpl = new ReopenAuthorizationImpl()
        reopenAuthorizationImpl.hsc = hsc
        reopenAuthorizationImpl.mbmWorkQueueSearch = mbmWorkQueueSearch
        reopenAuthorizationImpl.member = member
        reopenAuthorizationImpl.jbpmHelper = jbpmHelper
        reopenAuthorizationImpl.hscHelper = hscHelper
        reopenAuthorizationImpl.workQueueSearchRequestMapper = mbmWorkQueueSearchRequestMapper
        featureFlagManager = Mock(FeatureFlagManager)
        FeatureFlagUtility.featureFlagManager = featureFlagManager
    }

    def 'reopen closed authorization request'() {
        given:
        ReopenAuthDO reopenAuthDO = new ReopenAuthDO()
        HttpUserSession session = new HttpUserSession()
        session.setUserSecurity(new UserSecurityVO(userID: 'testID'))
        SessionThreadLocal.setSession(session)
        HscVO hscVO = new HscVO(hscID: TEST_HSC_ID)
        List<ItemTaskCriteriaResponse> itemTaskCriteriaResponseList = [new ItemTaskCriteriaResponse(itemTaskId: 1, assignmentTypeId: 1), new ItemTaskCriteriaResponse(itemTaskId: 1, assignmentTypeId: 1)]
        reopenAuthDO.setUserID('testID')
        reopenAuthDO.setReopenReason('1')
        reopenAuthDO.setHscID(TEST_HSC_ID)
        reopenAuthDO.setActivityResolutionReason('94')
        reopenAuthDO.setItemTaskCriteriaResponseList(itemTaskCriteriaResponseList)
        MemberVO memberVO = new MemberVO()

        ActivityVO activityVO = new ActivityVO()
        activityVO.setActivityResolutionReasonType('124')
        activityVO.setContactUserID(session.getUserSecurity().getUserID())

        when:
        HscVO vo = reopenAuthorizationImpl.reopenRequest(reopenAuthDO)

        then:
        1 * hscHelper.readCascadingSpclCare(TEST_HSC_ID) >> hscVO
        1 * member.readCascading(0) >> memberVO
        1 * hsc.save(hscVO)
        0/1 * jbpmHelper.sendStepperContinueSignal(hscVO, memberVO, activityVO, JbpmConstants.DYNAMIC_UM_FLOW, SpclCareReferenceConstants.AUTH_STEPPER_REOPEN)
        and:
        vo
        vo.getHscID() == hscVO.getHscID()
        vo.getHscStatusType() == hscVO.getHscStatusType()
    }
}
