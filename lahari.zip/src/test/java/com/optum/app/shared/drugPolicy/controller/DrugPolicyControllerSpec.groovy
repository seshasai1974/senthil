package com.optum.app.shared.drugPolicy.controller

import com.optum.app.ocm.controller.support.CommonResponse
import com.optum.app.ocm.ref.businesslogic.CustomerReference
import com.optum.app.shared.constants.SpclCareFeatureFlagConstants
import com.optum.app.shared.constants.SpclCareNonPersistedFieldConstants
import com.optum.app.shared.drugPolicy.data.DosageDO
import com.optum.app.shared.drugPolicy.data.DosageListDO
import com.optum.app.shared.drugPolicy.data.DrugPolicyBrandNameDO
import com.optum.app.shared.drugPolicy.data.DrugPolicyDO
import com.optum.app.shared.drugPolicy.processor.DrugPolicyProcessor
import com.optum.app.shared.procedure.businesslogic.ProcedureView
import com.optum.app.shared.procedure.data.ProcedureViewVO
import com.optum.app.shared.specialtyPharmacy.businesslogic.SpecialtyProceduresView
import com.optum.app.shared.specialtyPharmacy.data.SpecialtyProceduresViewVO
import com.optum.app.common.customer.data.CustomerReferenceVO
import com.optum.rf.common.featureflag.util.FeatureFlagManager
import com.optum.rf.common.featureflag.util.FeatureFlagUtility
import spock.lang.Specification

class DrugPolicyControllerSpec extends Specification {

    DrugPolicyController drugPolicyController = new DrugPolicyController()

    SpecialtyProceduresView specialtyProceduresView = Mock(SpecialtyProceduresView)
    ProcedureView procedureView = Mock(ProcedureView)
    DrugPolicyProcessor drugPolicyProcessor = Mock(DrugPolicyProcessor)
    CustomerReference customerReference = Mock(CustomerReference)
    FeatureFlagManager featureFlagManager = Mock(FeatureFlagManager)

    def setup() {
        drugPolicyController.specialtyProceduresView = specialtyProceduresView
        drugPolicyController.procedureView = procedureView
        drugPolicyController.drugPolicyProcessor = drugPolicyProcessor
        drugPolicyController.customerReference = customerReference
        FeatureFlagUtility.featureFlagManager = featureFlagManager
    }

    def "getDrugPolicyBrand"() {
        given:
        long hscID = 1234L
        String brandName = 'Test&reg;'
        SpecialtyProceduresViewVO specialtyProceduresViewVO = new SpecialtyProceduresViewVO(procedureBrandName: brandName)
        DrugPolicyBrandNameDO drugPolicyBrandNameDO = new DrugPolicyBrandNameDO(drugPolicyBrandID: 6789L)

        when:
        CommonResponse commonResponse = drugPolicyController.getDrugPolicyBrand(hscID)

        then:
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_PROC_BRAND_REFACTOR) >> featureFlag
        if(featureFlag) {
            1 * procedureView.readByHscID(hscID) >> new ProcedureViewVO(procedureBrandName: brandName)
        } else {
            1 * specialtyProceduresView.readByHscID(hscID) >> specialtyProceduresViewVO
        }
        1 * drugPolicyProcessor.getDrugPolicyBrandName(specialtyProceduresViewVO.procedureBrandName, hscID) >> drugPolicyBrandNameDO
        0 * _

        and:
        commonResponse.getEmbedded().get('_embedded') == drugPolicyBrandNameDO

        where: featureFlag << [ false, true ]
    }

    def "getDrugPolicyWithParams"() {
        given:
        long hscID = 1234L
        String diagnosisClass = '12'
        String diagnosisClassDescription = 'test diagnosis class descprition'
        String brandName = 'Test&reg;'
        SpecialtyProceduresViewVO specialtyProceduresViewVO = new SpecialtyProceduresViewVO(procedureBrandName: brandName)
        DrugPolicyDO drugPolicyDO = new DrugPolicyDO(drugPolicyID: 6789L)

        when:
        CommonResponse commonResponse = drugPolicyController.getDrugPolicyWithParams(diagnosisClass, hscID)

        then:
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_PROC_BRAND_REFACTOR) >> featureFlag
        if(featureFlag) {
            1 * procedureView.readByHscID(hscID) >> new ProcedureViewVO(procedureBrandName: brandName)
        } else {
            1 * specialtyProceduresView.readByHscID(hscID) >> specialtyProceduresViewVO
        }
        1 * customerReference.readByRefData(SpclCareNonPersistedFieldConstants.SPECIALTY_PHARMA_DIAGNOSIS_TYPE, diagnosisClass) >> new CustomerReferenceVO(referenceDesc: diagnosisClassDescription)
        1 * drugPolicyProcessor.getDrugPolicyWithParams(diagnosisClassDescription, brandName, hscID) >> drugPolicyDO
        0 * _

        and:
        commonResponse.getEmbedded().get('_embedded') == drugPolicyDO

        where: featureFlag << [ false, true ]
    }

    def "getAllDosages"() {
        given:
        long hscID = 1234L
        String diagnosisClass = '12'
        String diagnosisClassDescription = 'test diagnosis class descprition'
        String brandName = 'Test&reg;'
        SpecialtyProceduresViewVO specialtyProceduresViewVO = new SpecialtyProceduresViewVO(procedureBrandName: brandName)
        DosageListDO dosageListDO = new DosageListDO(dosageDOs: [new DosageDO(initialFlag: true)])

        when:
        CommonResponse commonResponse = drugPolicyController.getAllDosages(diagnosisClass, hscID)

        then:
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_PROC_BRAND_REFACTOR) >> featureFlag
        if(featureFlag) {
            1 * procedureView.readByHscID(hscID) >> new ProcedureViewVO(procedureBrandName: brandName)
        } else {
            1 * specialtyProceduresView.readByHscID(hscID) >> specialtyProceduresViewVO
        }
        1 * customerReference.readByRefData(SpclCareNonPersistedFieldConstants.SPECIALTY_PHARMA_DIAGNOSIS_TYPE, diagnosisClass) >> new CustomerReferenceVO(referenceDesc: diagnosisClassDescription)
        1 * drugPolicyProcessor.getDosages(diagnosisClassDescription, brandName, hscID) >> dosageListDO
        0 * _

        and:
        commonResponse.getEmbedded().get('_embedded') == dosageListDO

        where: featureFlag << [ false, true ]
    }
}
