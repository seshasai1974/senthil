package com.optum.app.shared.microservice.data

import com.optum.app.shared.microservice.data.MemberSummaryListItem
import org.apache.commons.lang.StringUtils
import spock.lang.Specification

/**
 * Created by cnadipin on 1/10/19.
 */
class MemberSummaryListItemSpec extends Specification {

    MemberSummaryListItem memberSummaryListItem

    def setup() {
        memberSummaryListItem = new MemberSummaryListItem(firstName: 'AAAA', lastName:'BBBB', subscriberID: '123', policyEffectiveDate: '1999-10-10', policyEndDate: '2020-02-01',
                sourceMemberID: '1234', sourceMemberIDPartitionNumber: '123456', policyNumber: '222', gender:'M', addressType: 'Res', address1: 'Six Forks road',address2: '11', city: 'Raleigh', state:'NC', zip:'1111', countryCode: 'USA')
    }
    def "equals true"() {

        when:
        boolean retVal = MemberSummaryListItem.equals(MemberSummaryListItem)

        then:
        0 * _

        and:
        retVal
    }

    def "equals false"() {
        given:
        MemberSummaryListItem object = new MemberSummaryListItem(firstName: 'AAAA', lastName:'BBBB', subscriberID: '123', policyEffectiveDate: '1999-10-10', policyEndDate: '2020-02-01',
                sourceMemberID: '1234', sourceMemberIDPartitionNumber: '123456', policyNumber: '222', gender:'M', addressType: 'Res', address1: 'Six Forks road',address2: '11', city: 'Raleigh', state:'NC', zip:'1111', countryCode: 'USA')

        when:
        boolean retVal = object.equals(_)

        then:
        0 * _

        and:
        !retVal
    }

    def "hash"() {
        given:

        MemberSummaryListItem object = new MemberSummaryListItem(firstName: 'AAAA', lastName:'BBBB', subscriberID: '123', policyEffectiveDate: '1999-10-10', policyEndDate: '2020-02-01',
                sourceMemberID: '1234', sourceMemberIDPartitionNumber: '123456', policyNumber: '222', gender:'M', addressType: 'Res', address1: 'Six Forks road',address2: '11', city: 'Raleigh', state:'NC', zip:'1111', countryCode: 'USA')
        when:
        int retVal = object.hashCode()

        then:
        0 * _

        and:
        retVal
        memberSummaryListItem.hashCode() == retVal
    }

    def "to String"() {
        given:

        MemberSummaryListItem object = new MemberSummaryListItem(firstName: 'AAAA', lastName:'BBBB', subscriberID: '123', policyEffectiveDate: '2000-10-10', policyEndDate: '2020-02-01',
                sourceMemberID: '1234', sourceMemberIDPartitionNumber: '123456', policyNumber: '222', gender:'M', addressType: 'Res', address1: 'Six Forks road',address2: '11', city: 'Raleigh', state:'NC', zip:'1111', countryCode: 'USA')

        when:
        String retVal = object.toString()

        then:
        0 * _

        and:
        StringUtils.isNotBlank(retVal)
    }
}
