package com.optum.app.shared.ssoauthentication.controller

import com.amazonaws.services.s3.AmazonS3Client
import com.amazonaws.services.s3.model.GetObjectRequest
import com.amazonaws.services.s3.model.S3Object
import com.optum.app.ocm.common.util.SsoViewMapping
import com.optum.app.ocm.customer.businesslogic.CustomerUserView
import com.optum.app.ocm.ref.businesslogic.CustomerReference
import com.optum.app.shared.hsc.businesslogic.HscHelper
import com.optum.app.shared.microservice.businesslogic.MemberDetailsProcessor
import com.optum.app.shared.ssoauthentication.controller.mbm.MbmSsoController
import com.optum.app.shared.ssoauthentication.data.OcmSsoData
import com.optum.app.shared.ssoauthentication.helper.OcmSsoHelper
import com.optum.app.shared.ssoauthentication.helper.SSOActivityLog
import com.optum.app.shared.ssoauthentication.helper.impl.OcmSsoHelperImpl
import com.optum.rf.common.security.data.UserAddressVO
import com.optum.rf.common.security.data.UserProfileVO
import com.optum.rf.common.settings.businesslogic.SystemSettingsPingFederatePartner
import com.optum.rf.common.settings.businesslogic.SystemSettingsWebService
import com.optum.rf.common.settings.businesslogic.impl.SystemSettingsPingFederatePartnerImpl
import com.optum.rf.common.settings.data.SystemSettingsPingFederatePartnerVO
import com.optum.rf.common.webservice.logging.businesslogic.WebServiceLog
import com.optum.rf.common.webservice.security.UserPermissionGroupProvider
import com.optum.rf.core.util.Environment
import com.optum.rf.dao.data.ValueObject
import com.optum.rf.dao.exception.UhgRuntimeException
import com.optum.rf.dao.security.UserSecurity
import com.optum.rf.test.core.mock.http.MockHttpSession
import com.optum.rf.test.core.spock.BaseReadLogicSpecification
import com.optum.app.common.customer.data.CustomerUserViewVO
import com.optum.app.common.hsr.businesslogic.Hsc
import com.optum.app.ocm.common.security.data.AppUserVO
import org.springframework.mock.web.MockHttpServletRequest
import org.springframework.mock.web.MockHttpServletResponse
import org.springframework.web.servlet.ModelAndView
import spock.lang.Unroll

import javax.servlet.http.HttpServletResponse
import javax.servlet.http.HttpSession

class MbmSsoControllerSpec extends BaseReadLogicSpecification {
    MbmSsoController controller
    OcmSsoData ssoData
    OcmSsoHelper ocmSsoHelper

    SystemSettingsPingFederatePartner systemSettingsPingFederatePartner
    SystemSettingsPingFederatePartnerVO systemSettingsPingFederatePartnerVO
    UserSecurity userSecurity
    HttpSession httpSession
    GetObjectRequest getObjectRequest
    Environment environment
    S3Object s3Object
    AmazonS3Client amazonS3Client
    UserPermissionGroupProvider userPermissionGroupProvider
    CustomerUserView customerUserView
    WebServiceLog webServiceLog
    HscHelper hscHelper
    Hsc hsc
    MemberDetailsProcessor memberDetailsProcessor
    SSOActivityLog ssoActivityLog
    CustomerReference customerReference = Mock(CustomerReference)
    OcmSsoHelperImpl ocmSsoHelperImpl

    def setup() {
        ocmSsoHelper = Mock(OcmSsoHelper)
        ssoData = Mock(OcmSsoData)
        userSecurity = Mock(UserSecurity)
        httpSession = Mock(HttpSession)
        getObjectRequest = Mock(GetObjectRequest)
        environment = Mock(Environment)
        systemSettingsPingFederatePartner = Mock(SystemSettingsPingFederatePartnerImpl)
        systemSettingsPingFederatePartnerVO=Mock(SystemSettingsPingFederatePartnerVO)
        s3Object = Mock(S3Object)
        amazonS3Client = Mock(AmazonS3Client)
        controller = new MbmSsoController(ocmSsoHelper: ocmSsoHelper)
        userPermissionGroupProvider = Mock(UserPermissionGroupProvider)
        customerUserView = Mock(CustomerUserView)
        webServiceLog = Mock(WebServiceLog)
        hscHelper = Mock(HscHelper)
        hsc = Mock(Hsc)
        memberDetailsProcessor = Mock(MemberDetailsProcessor)
        ssoActivityLog = Mock(SSOActivityLog)
        ocmSsoHelperImpl = Mock(OcmSsoHelperImpl)
        ocmSsoHelperImpl.customerReference = customerReference
        ocmSsoHelperImpl.environment = environment
    }

    def "Test getSuccessViewPath"() {
        when:
        String viewPath = controller.getSuccessViewPath(new HashMap())

        then:
        SsoViewMapping.OCM_OPTUM_LANDING_PAGE.getPath() == viewPath
        0 * _
    }

    def "Test getErrorViewPath"() {
        when:
        String viewPath = controller.getErrorViewPath(new HashMap())

        then:
        SsoViewMapping.OPTUM_SSO_ERROR.getPath() == viewPath
        0 * _
    }

    @Unroll
    def "validateSSOAttributes #testCase"() {
        given:
        AppUserVO userResult = AppUserResult
        UserAddressVO addressResult = userAddressResult
        ValueObject valueObj = errorMessageVO

        when:
        controller.validateSSOAttributes(map, errorMessageVO)
        userResult.setLastLoginDate(userDetailsResponse.getLastLoginDate())

        then:
        ssoHelperCall * ocmSsoHelper.createUserDetailsFromSSO(_ as OcmSsoData) >> userDetailsResponse
        //ssoHelperCall * ocmSsoHelper.createUserAddressFromSSO(_) >> userAddressResult
        ssoHelperCall * ocmSsoHelper.createUserCustomerFromSSO(_)
        0 * _

        and:
        userResult == userDetailsResponse
        addressResult == userAddressResult
        valueObj.getGlobalMessages().size() == globalMessage

        where:
        testCase                                 | errorMessageVO    | AppUserResult   | userDetailsResponse | userAddressResult   | globalMessage | ssoHelperCall | map
        'Map is populated with expected returns' | new ValueObject() | new AppUserVO() | new AppUserVO()     | new UserAddressVO() | 0             | 1             | [userID: 'db123', userFName: 'Dan', userLName: 'Josh', userEmail: 'test.Email@optum.com', isSuperUser: false]
        'Empty Attribute Map'                    | new ValueObject() | new AppUserVO() | new AppUserVO()     | new UserAddressVO() | 1             | 0             | new HashMap()
        'Null Attribute Map'                     | new ValueObject() | new AppUserVO() | new AppUserVO()     | new UserAddressVO() | 1             | 0             | null
        'Null userID'                            | new ValueObject() | new AppUserVO() | new AppUserVO()     | new UserAddressVO() | 1             | 0             | [userID: null, userFName: 'Dan', userLName: 'Josh', userEmail: 'test.Email@optum.com', isSuperUser: false]
        'Null String userID'                     | new ValueObject() | new AppUserVO() | new AppUserVO()     | new UserAddressVO() | 1             | 0             | [userID: 'null', userFName: 'Dan', userLName: 'Josh', userEmail: 'test.Email@optum.com', isSuperUser: false]
    }

    @Unroll
    def "readSSOAttributes #testCase"() {
        given:
        Map testMap = map

        when:
        controller.readSSOAttributes(Mock(MockHttpServletRequest))

        then:
        ssoHelperCall * ocmSsoHelper.useAmazonS3ToParseSsoAttributesFromSAMLorHardcodeForLocalHost(_) >> map
        0 * _

        and:
        testMap == map

        where:
        testCase                       | ssoHelperCall | map
        'Expected behavior'            | 1             | [userID: 'db123', userFName: 'Dan', userLName: 'Josh', userEmail: 'test.Email@optum.com', isSuperUser: false]
    }

    @Unroll
    def "Exceptions - readSSOAttributes #testCase"() {
        when:
        controller.readSSOAttributes(Mock(MockHttpServletRequest))

        then:
        ssoHelperCall * ocmSsoHelper.useAmazonS3ToParseSsoAttributesFromSAMLorHardcodeForLocalHost(_) >> map

        and:
        thrown UhgRuntimeException

        where:
        testCase                       | ssoHelperCall | map
        'Empty Attribute Map'          | 1             | new HashMap()
        'Null Attribute Map'           | 1             | null
    }

    @Unroll
    def "handleRequest #testCase"(){
        given:
        MockHttpServletRequest request = new MockHttpServletRequest()
        HttpServletResponse response = Mock(MockHttpServletResponse)
        UserProfileVO userProfileVO = userProfile
        request.setServerName("Test")
        request.setSession(new MockHttpSession())
        MbmSsoController mbmSsoController = new MbmSsoController(userPermissionGroupProvider: userPermissionGroupProvider, ocmSsoHelper: ocmSsoHelper, systemSettingsWebService: Mock(SystemSettingsWebService),
                                                                                    customerUserView: customerUserView, webServiceLog: webServiceLog, memberDetailsProcessor: memberDetailsProcessor, ssoActivityLog: ssoActivityLog)

        when:
        ModelAndView responseMV = mbmSsoController.handleRequest(request, response)

        then:
        ssoHelperCall * ocmSsoHelper.createUserDetailsFromSSO(_ as OcmSsoData) >> userDetailsResponse
        //ssoHelperCall * ocmSsoHelper.createUserAddressFromSSO(_) >> userAddressResult
        ssoHelperCall * ocmSsoHelper.buildUserProfileVO(_) >> userProfileVO
        ssoHelperCall * userPermissionGroupProvider.getUserPermissionGroups(_) >> permissionGroups
        ssoHelperCall * customerUserView.getActiveByUserID(_ as String) >> customerPermissions
        ssoHelperCall * ocmSsoHelper.createUserCustomerFromSSO(_)
        1 * ocmSsoHelper.useAmazonS3ToParseSsoAttributesFromSAMLorHardcodeForLocalHost(_) >> ssoInfoMap
        1 * ssoActivityLog.logUserAction(_, _, _, _)
        1 * webServiceLog.addNewTransaction(_)
        0 * _

        and:
        responseMV.getViewName() == landingPage

        where:
        testCase                        | customerPermissions                     | permissionGroups                     | userProfile                        | userDetailsResponse | userAddressResult   | ssoHelperCall | landingPage                                     | ssoInfoMap
        'Empty userID'                  | [new CustomerUserViewVO(customerID: 1)] | ["These permissions"].asCollection() | new UserProfileVO(userID: 'db123') | new AppUserVO()     | new UserAddressVO() | 0             | SsoViewMapping.OPTUM_SSO_ERROR.getPath()        | [userID: null, userFName: 'Dan', userLName: 'Josh', userEmail: 'test.Email@optum.com', isSuperUser: false]
        'Null String userID'            | [new CustomerUserViewVO(customerID: 1)] | ["These permissions"].asCollection() | new UserProfileVO(userID: 'db123') | new AppUserVO()     | new UserAddressVO() | 0             | SsoViewMapping.OPTUM_SSO_ERROR.getPath()        | [userID: 'null', userFName: 'Dan', userLName: 'Josh', userEmail: 'test.Email@optum.com', isSuperUser: false]
        'Null userProfileVO'            | [new CustomerUserViewVO(customerID: 1)] | ["These permissions"].asCollection() | null                               | new AppUserVO()     | new UserAddressVO() | 0             | SsoViewMapping.OPTUM_SSO_ERROR.getPath()        | [userID: 'null', userFName: 'Dan', userLName: 'Josh', userEmail: 'test.Email@optum.com', isSuperUser: false]
        'Empty userID in userProfileVO' | [new CustomerUserViewVO(customerID: 1)] | ["These permissions"].asCollection() | new UserProfileVO()                | new AppUserVO()     | new UserAddressVO() | 0             | SsoViewMapping.OPTUM_SSO_ERROR.getPath()        | [userID: 'null', userFName: 'Dan', userLName: 'Josh', userEmail: 'test.Email@optum.com', isSuperUser: false]
        'Null ssoInfo'                  | [new CustomerUserViewVO(customerID: 1)] | ["These permissions"].asCollection() | new UserProfileVO(userID: 'db123') | new AppUserVO()     | new UserAddressVO() | 0             | SsoViewMapping.OPTUM_SSO_ERROR.getPath()        | null
        'Empty ssoInfo'                 | [new CustomerUserViewVO(customerID: 1)] | ["These permissions"].asCollection() | new UserProfileVO(userID: 'db123') | new AppUserVO()     | new UserAddressVO() | 0             | SsoViewMapping.OPTUM_SSO_ERROR.getPath()        | new HashMap()
    }

    @Unroll
    def "handleRequestEmpty #testCase"(){
        given:
        MockHttpServletRequest request = new MockHttpServletRequest()
        HttpServletResponse response = Mock(MockHttpServletResponse)
        UserProfileVO userProfileVO = userProfile
        HttpSession session = new MockHttpSession()
        session.setAttribute('customerUserVOs', [])
        request.setServerName("Test")
        request.setSession(session)
        MbmSsoController mbmSsoController = new MbmSsoController(userPermissionGroupProvider: userPermissionGroupProvider, ocmSsoHelper: ocmSsoHelper, systemSettingsWebService: Mock(SystemSettingsWebService),
                customerUserView: customerUserView, webServiceLog: webServiceLog, memberDetailsProcessor: memberDetailsProcessor, ssoActivityLog: ssoActivityLog)

        when:
        ModelAndView responseMV = mbmSsoController.handleRequest(request, response)

        then:
        ssoHelperCall * ocmSsoHelper.createUserDetailsFromSSO(_ as OcmSsoData) >> userDetailsResponse
        ssoHelperCall * ocmSsoHelper.buildUserProfileVO(_) >> userProfileVO
        ssoHelperCall * userPermissionGroupProvider.getUserPermissionGroups(_) >> permissionGroups
        ssoHelperCall * ocmSsoHelper.createUserCustomerFromSSO(_)
        1 * ocmSsoHelper.useAmazonS3ToParseSsoAttributesFromSAMLorHardcodeForLocalHost(_) >> ssoInfoMap
        1 * ssoActivityLog.logUserAction(_, _, _, _)
        1 * webServiceLog.addNewTransaction(_)
        1 * ocmSsoHelper.populateDefaultSessionAttributes(request, session)
        0 * _

        and:
        responseMV.getViewName() == landingPage

        where:
        testCase                        | customerPermissions                     | permissionGroups                     | userProfile                        | userDetailsResponse | userAddressResult   | ssoHelperCall | landingPage                                     | ssoInfoMap
        'Expected behavior'             | [new CustomerUserViewVO(customerID: 1)] | ["These permissions"].asCollection() | new UserProfileVO(userID: 'db123') | new AppUserVO()     | new UserAddressVO() | 1             | SsoViewMapping.OCM_OPTUM_LANDING_PAGE.getPath() | [userID: 'db123', userFName: 'Dan', userLName: 'Josh', userEmail: 'test.Email@optum.com', isSuperUser: false]
        'Empty permissions'             | [new CustomerUserViewVO(customerID: 1)] | [].asCollection()                    | new UserProfileVO(userID: 'db123') | new AppUserVO()     | new UserAddressVO() | 1             | SsoViewMapping.OCM_OPTUM_LANDING_PAGE.getPath() | [userID: 'db123', userFName: 'Dan', userLName: 'Josh', userEmail: 'test.Email@optum.com', isSuperUser: false]
        'Empty customerView'            | []                                      | ["These permissions"].asCollection() | new UserProfileVO(userID: 'db123') | new AppUserVO()     | new UserAddressVO() | 1             | SsoViewMapping.OCM_OPTUM_LANDING_PAGE.getPath() | [userID: 'db123', userFName: 'Dan', userLName: 'Josh', userEmail: 'test.Email@optum.com', isSuperUser: false]
    }

}
