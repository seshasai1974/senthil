package com.optum.app.shared.authorization.controller

import com.optum.app.common.hsr.businesslogic.HscProvider
import com.optum.app.common.hsr.businesslogic.HscProviderRole
import com.optum.app.common.hsr.constants.HsrReferenceConstants
import com.optum.app.common.hsr.data.HscProviderVO
import com.optum.app.common.member.core.data.MemberCoverageVO
import com.optum.app.ocm.common.member.businesslogic.MemberCoverage
import com.optum.app.ocm.controller.support.CommonResponse
import com.optum.app.shared.authorization.businesslogic.Auth
import com.optum.app.shared.authorization.businesslogic.Authorizations
import com.optum.app.shared.authorization.data.AuthDetailsDO
import com.optum.app.shared.constants.SpclCareFeatureFlagConstants
import com.optum.app.shared.constants.SpclCareReferenceConstants
import com.optum.app.shared.diseaseTraversal.businesslogic.TreatmentSupportiveCareProcedure
import com.optum.app.shared.diseaseTraversal.data.TreatmentProcedureAuthorizationRuleVO
import com.optum.app.shared.diseaseTraversal.data.TreatmentSupportiveCareProcedureVO
import com.optum.app.shared.diseaseTraversal.businesslogic.AuthorizationRuleHelper
import com.optum.app.shared.drugRounding.businesslogic.DrugRounding
import com.optum.app.shared.drugRounding.data.DrugRoundingRequestDO
import com.optum.app.shared.drugRounding.data.DrugRoundingResponseDO
import com.optum.app.shared.hsc.businesslogic.HscClone
import com.optum.app.shared.hsc.businesslogic.HscHelper
import com.optum.app.shared.hsc.data.AdjustAuthDO
import com.optum.app.shared.hsc.data.AuthRequestDetailsDO
import com.optum.app.shared.hsc.data.CloneRequestDO
import com.optum.app.shared.hsc.data.CustomRegimenDO
import com.optum.app.shared.hsc.data.DrugExceptionCheckDO
import com.optum.app.shared.hsc.data.HscCloningDO
import com.optum.app.shared.hsc.data.RegimenSelectionDO
import com.optum.app.shared.microservice.businesslogic.ClaimsHistoryService
import com.optum.app.shared.hsc.data.StartDateDO
import com.optum.app.shared.microservice.data.AuthRequestDO
import com.optum.app.shared.microservice.data.AuthResponseDO
import com.optum.app.shared.microservice.data.ProviderDetails
import com.optum.app.shared.orxfusion.businesslogic.OrxFusionService
import com.optum.app.shared.orxfusion.data.HscFusionDO
import com.optum.app.shared.orxfusion.data.OrxFusionResponse
import com.optum.app.shared.procedure.data.ProcedureViewVO
import com.optum.app.shared.radiationOncology.data.CptCode
import com.optum.app.shared.radiationOncology.data.RadiationOncologyTechniqueDO
import com.optum.app.shared.specialtyPharmacy.businesslogic.SpecialtyPharmacyHelper
import com.optum.app.shared.specialtyPharmacy.data.SpecialtyPharmacyClinicalStatusDO
import com.optum.app.shared.specialtyPharmacy.data.SpecialtyProceduresViewVO
import com.optum.rf.common.featureflag.util.FeatureFlagManager
import com.optum.rf.common.featureflag.util.FeatureFlagUtility
import com.optum.rf.dao.util.UhgCalendarUtilities
import com.optum.rf.dao.sql.query.QueryFilter
import com.optum.rf.dao.sql.query.QueryProperties
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.HscAssessment
import com.optum.app.common.hsr.businesslogic.HscAttribute
import com.optum.app.common.hsr.businesslogic.HscService
import com.optum.app.common.hsr.businesslogic.Hsc
import com.optum.app.common.hsr.businesslogic.UserHscHistory
import com.optum.app.common.hsr.data.HscAssessmentVO
import com.optum.app.common.hsr.data.HscAttributeVO
import com.optum.app.common.hsr.data.HscServiceVO
import com.optum.app.common.hsr.data.HscVO
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import spock.lang.Specification
import spock.lang.Unroll

import java.sql.Date

class AuthorizationsControllerSpec extends Specification {
    AuthorizationsController authorizationsController

    Authorizations authorizations = Mock(Authorizations)
    HscHelper hscHelper = Mock(HscHelper)
    HscAttribute hscAttribute = Mock(HscAttribute)
    Hsc hsc = Mock(Hsc)
    HscClone hscClone = Mock(HscClone)
    UserHscHistory userHscHistory = Mock(UserHscHistory)
    HscService hscService = Mock(HscService)
    HscAssessment hscAssessment = Mock(HscAssessment)
    SpecialtyPharmacyHelper specialtyPharmacyHelper = Mock(SpecialtyPharmacyHelper)
    Auth auth = Mock(Auth)
    TreatmentSupportiveCareProcedure treatmentSupportiveCareProcedure = Mock(TreatmentSupportiveCareProcedure)
    AuthorizationRuleHelper authorizationRuleHelper = Mock(AuthorizationRuleHelper)
    DrugRounding drugRounding = Mock(DrugRounding)
    MemberCoverage memberCoverage = Mock(MemberCoverage)
    HscProvider hscProvider = Mock(HscProvider)
    HscProviderRole hscProviderRole = Mock(HscProviderRole)
    OrxFusionService orxFusionService = Mock(OrxFusionService)
    FeatureFlagManager featureFlagManager = Mock(FeatureFlagManager)
    ClaimsHistoryService claimsHistoryService = Mock(ClaimsHistoryService)

    def setup() {
        authorizationsController = new AuthorizationsController()
        authorizationsController.authorizations = authorizations
        authorizationsController.hscHelper = hscHelper
        authorizationsController.hscAttribute = hscAttribute
        authorizationsController.hscProvider = hscProvider
        authorizationsController.hscProviderRole = hscProviderRole
        authorizationsController.hsc = hsc
        authorizationsController.hscClone = hscClone
        authorizationsController.userHscHistory = userHscHistory
        authorizationsController.hscService = hscService
        authorizationsController.hscAssessment = hscAssessment
        authorizationsController.specialtyPharmacyHelper = specialtyPharmacyHelper
        authorizationsController.auth = auth
        authorizationsController.treatmentSupportiveCareProcedure = treatmentSupportiveCareProcedure
        authorizationsController.authorizationRuleHelper = authorizationRuleHelper
        authorizationsController.drugRounding = drugRounding
        authorizationsController.memberCoverage = memberCoverage
        authorizationsController.orxFusionService = orxFusionService
        FeatureFlagUtility.featureFlagManager = featureFlagManager
        authorizationsController.claimsHistoryService = claimsHistoryService
    }

    def "getHsc"() {
        given:
        HscVO hscVO = new HscVO(hscID: hscId)

        when:
        CommonResponse response = authorizationsController.getHsc(customerId, hscId)

        then:
        1 * authorizations.validateAuthorization(customerId, hscId, isValid)
        1 * hscHelper.readCascadingSpclCare(hscId) >> hscVO
        1 * userHscHistory.saveUserHscHistory(_)
        0 * _

        and:
        response.getEmbedded() == ['_embedded': hscVO]

        where:
        customerId | hscId | isValid
        1          | 1234L | false
    }

    def "saveRegimen"() {
        given:
        RegimenSelectionDO regimenSelectionDO = new RegimenSelectionDO(hscID: hscId, diseaseTraversalID: diseaseTraversalId)

        when:
        CommonResponse response = authorizationsController.saveRegimen(customerId, hscId, regimenSelectionDO)

        then:
        1 * authorizations.validateAuthorization(customerId, hscId, isValid)
        1 * hscHelper.saveRegimenSelectionDetails(regimenSelectionDO) >> regimenSelectionDO
        0 * _

        and:
        response.getEmbedded() == ['_embedded': regimenSelectionDO]

        where:
        customerId | hscId | isValid | diseaseTraversalId
        1          | 1234L | true    | 5555L
    }

    def "saveCustomRegimen"() {
        given:
        CustomRegimenDO customRegimenDO = new CustomRegimenDO(hscID: hscId)
        List<HscServiceVO> hscServiceVOS = [new HscServiceVO(hscID: hscId)]

        when:
        CommonResponse response = authorizationsController.saveCustomRegimen(customerId, hscId, customRegimenDO)

        then:
        1 * authorizations.validateAuthorization(customerId, hscId, isValid)
        1 * hscHelper.saveCustomRegimenDetails(customRegimenDO) >> customRegimenDO
        1 * hscService.listServiceAndFacility(customRegimenDO.hscID, true) >> hscServiceVOS
        0 * _

        and:
        response.getEmbedded() == ['_embedded': customRegimenDO]
        customRegimenDO.getHscServiceVOs() == hscServiceVOS

        where:
        customerId | hscId | isValid
        1          | 1234L | true
    }

    def "saveRequestDetails"() {
        given:
        AuthRequestDetailsDO authRequestDetailsDO = new AuthRequestDetailsDO(hscID: hscId, memberID: 5555L)

        when:
        CommonResponse response = authorizationsController.saveRequestDetails(customerId, hscId, authRequestDetailsDO)

        then:
        1 * authorizations.validateAuthorization(customerId, hscId, isValid)
        1 * hscHelper.saveRequestDetails(authRequestDetailsDO)
        0 * _

        and:
        response.getEmbedded() == ['_embedded': authRequestDetailsDO]

        where:
        customerId | hscId | isValid
        1          | 1234L | true
    }

    def "saveAssessment"() {
        given:
        HscAssessmentVO hscAssessmentVO = new HscAssessmentVO(hscID: hscId, assessmentID: assessmentId, assessmentTypeID: assessmentTypeId)

        when:
        CommonResponse response = authorizationsController.saveAssessment(customerId, hscId, hscAssessmentVO)

        then:
        1 * authorizations.validateAuthorization(customerId, hscId, validateStatus)
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_PH_MULTIPLE_OTHER_ASSESSMENTS_FOM) >> flagStatus
        1 * hscAssessment.save(hscAssessmentVO)
        0 * _

        and:
        response.getEmbedded() == ['_embedded': hscAssessmentVO]

        where:
        customerId | hscId | validateStatus | assessmentId | assessmentTypeId | flagStatus
        1          | 1234L | true           | 5555L        | '1'              | false
        1          | 1235L | true           | 5556L        | '6'              | true
    }

    def "saveTechniques"() {
        given:
        long hscId = 12345
        RadiationOncologyTechniqueDO radiationOncologyTechniqueDO = new RadiationOncologyTechniqueDO(
                cptCodes: [ new CptCode(procedureCode: 'procCode', procCodeType: 'procCodeType') ],
                autoApprove: true
        )

        when:
        CommonResponse response = authorizationsController.saveTechniques(1, hscId, radiationOncologyTechniqueDO)

        then:
        1 * authorizations.validateAuthorization(1, hscId, true)
        1 * hscHelper.saveTechnique(hscId, radiationOncologyTechniqueDO) >> radiationOncologyTechniqueDO
        0 * _

        and:
        response.getEmbedded() == ['_embedded': radiationOncologyTechniqueDO]
    }

    def "deleteTechniques"() {
        given:
        long hscId = 12345
        HscVO hscVO = new HscVO(hscID: hscId)

        when:
        CommonResponse response = authorizationsController.deleteTechniques(1, hscId, false)

        then:
        1 * authorizations.validateAuthorization(1, hscId, true)
        1 * hscHelper.deleteTechnique(hscId, false) >> hscVO
        0 * _

        and:
        response.getEmbedded() == ['_embedded': hscVO]
    }

    def "saveClinicalStatus"() {
        given:
        SpecialtyPharmacyClinicalStatusDO requestDO = new SpecialtyPharmacyClinicalStatusDO(hscAssessmentVO: new HscAssessmentVO(hscID: hscId))
        SpecialtyPharmacyClinicalStatusDO responseDO = new SpecialtyPharmacyClinicalStatusDO(autoApprove: autoApprove)

        when:
        CommonResponse response = authorizationsController.saveClinicalStatus(customerId, hscId, requestDO)

        then:
        1 * authorizations.validateAuthorization(customerId, hscId, validateStatus)
        1 * specialtyPharmacyHelper.saveClinicalStatus(customerId, requestDO) >> responseDO
        0 * _

        and:
        response.getEmbedded().get('_embedded') == responseDO

        where:
        customerId | hscId | validateStatus | autoApprove
        1          | 1234L | true           | true
    }

    @Unroll
    def "updateHsc"() {
        when:
        CommonResponse response = authorizationsController.updateHsc(customerId, hscId, authRequestDetailsDO)

        then:
        1 * authorizations.validateAuthorization(customerId, hscId, false)
        1 * hscHelper.saveHscAttributesPostSubmission(authRequestDetailsDO.getHscAttributeVOs())
        1 * auth.updateAuthorizationBackDating(customerId, new AuthRequestDO(hscID: hscId ?: 0L)) >> commonResponse

        and:
        response.getEmbedded().get('_embedded')

        where:
        testCase | hscId | customerId | authRequestDetailsDO                                                                                                                                                              | commonResponse
        0        | 12L   | 1          | new AuthRequestDetailsDO(hscAttributeVOs: [new HscAttributeVO(hscID: 0L, hscAttributeType: SpclCareReferenceConstants.HSCATTRIBUTETYPE_BACKDATING_AUTH, hscAttributeValue: '1')]) | new CommonResponse().setEmbedded(new AuthResponseDO(hscID: 12L))
    }

    def "getCloneAuthDetails"() {
        when:
        CommonResponse response = authorizationsController.getCloneAuthDetails(customerId, hscId, hscAuthType)

        then:
        1 * authorizations.validateAuthorization(customerId, hscId, validateStatus)
        x * hscClone.getPrimaryCancer(hscId) >> returnVO
        y * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_PROC_BRAND_REFACTOR) >> enableProcBrandRefactor
        z * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_PH_THERAPY_CLONING) >> enablePhCloning
        if(enableProcBrandRefactor) {
            y * hscClone.getCloneAuthDetailsProcedure(hscId, hscAuthType) >> returnVO
        } else {
            y * hscClone.getCloneAuthDetails(hscId, hscAuthType) >> returnVO
        }
        0 * _

        and:
        response.getEmbedded().get('_embedded') == returnVO

        where:
        x | y | z | customerId | hscId | hscAuthType | validateStatus | returnVO |enableProcBrandRefactor | enablePhCloning
        1 | 0 | 1 |1          | 1L    | '2'         | false          | new HscAttributeVO() |false | false
        0 | 1 | 0 |1          | 1L    | '4'         | false          | new SpecialtyProceduresViewVO() |false | false
        0 | 1 | 0 |1          | 1L    | '4'         | false          | new ProcedureViewVO() |true | false
        0 | 0 | 1 |1          | 1L    | '6'         | false          | ''   |false  | true
        0 | 0 | 1 |1          | 1L    | '7'         | false          | ''   |false  | true
        0 | 0 | 1 |1          | 1L    | '8'         | false          | ''   |false  | true
        1 | 0 | 1 |1          | 1L    | '8'         | false          | new HscAttributeVO()   |false  | false
        1 | 0 | 1 |1          | 1L    | '7'         | false          | new HscAttributeVO()   |false  | false
        1 | 0 | 1 |1          | 1L    | '6'         | false          | new HscAttributeVO()   |false  | false
        1 | 0 | 1 |1          | 1L    | '2'         | false          | new HscAttributeVO()   |false  | true

    }

    def "cloneAuthorizations"() {
        given:
        CloneRequestDO cloneRequestDO = new CloneRequestDO(hscID: hscId, authType: authType, isFromAuthNotReqPopup: validateStatus)
        HscCloningDO hscCloningDO = new HscCloningDO(clonedHscID: hscId)

        when:
        CommonResponse response = authorizationsController.cloneAuthorizations(customerId, hscId, cloneRequestDO)

        then:
        1 * authorizations.validateAuthorization(customerId, hscId, validateStatus)
        1 * hscClone.cloneAuthorization(customerId, cloneRequestDO) >> hscCloningDO
        0 * _

        and:
        response.getEmbedded().get('_embedded') == hscCloningDO

        where:
        customerId | hscId | authType | validateStatus
        1          | 1L    | '2'      | false

    }

    def "getRadioPharmaDrug"() {
        given:
        int customerId = 1
        String radioPharmaDrugType = 'radioPharmaDrugType'
        String diseaseType = 'diseaseType'
        List<TreatmentSupportiveCareProcedureVO> treatmentSupportiveCareProcedureVOList = [ new TreatmentSupportiveCareProcedureVO(treatmentSuppCareProcedureID: 123) ]

        when:
        CommonResponse response = authorizationsController.getRadioPharmaDrug(customerId, radioPharmaDrugType, diseaseType)

        then:
        1 * authorizations.validateCustomer(customerId)
        1 * treatmentSupportiveCareProcedure.listByRadioPharmaDrugType(FieldConstants.DISEASETYPE, 'radioPharmaDrugType', customerId) >> treatmentSupportiveCareProcedureVOList
        0 * _

        and:
        response.getEmbedded().get('_embedded') == treatmentSupportiveCareProcedureVOList[0]
    }

    def "getFilteredSupportiveDrugList"() {
        given:
        int customerId = 1
        long hscId = 12L
        List<TreatmentSupportiveCareProcedureVO> treatmentSupportiveCareProcedureVOList = [ new TreatmentSupportiveCareProcedureVO(treatmentSuppCareProcedureID: 123) ]

        when:
        CommonResponse response = authorizationsController.getFilteredSupportiveDrugList(customerId, hscId)

        then:
        1 * authorizations.validateAuthorization(customerId, hscId, false)
        1 * hscAttribute.read(12, '62')
        1 * treatmentSupportiveCareProcedure.listBySupportiveCareType(12, 'GF', true, customerId) >> treatmentSupportiveCareProcedureVOList
        0 * _

        and:
        response.getEmbedded().get('_embedded') == treatmentSupportiveCareProcedureVOList
    }

    def "getSupportiveDrugList"() {
        given:
        int customerId = 1
        List<TreatmentSupportiveCareProcedureVO> treatmentSupportiveCareProcedureVOList = [ new TreatmentSupportiveCareProcedureVO(treatmentSuppCareProcedureID: 123) ]

        when:
        CommonResponse response = authorizationsController.getSupportiveDrugList(customerId)

        then:
        1 * authorizations.validateCustomer(customerId)
        1 * treatmentSupportiveCareProcedure.listAllActiveSupportiveCareDrugs(customerId) >> treatmentSupportiveCareProcedureVOList
        0 * _

        and:
        response.getEmbedded().get('_embedded') == treatmentSupportiveCareProcedureVOList
    }

    @Unroll
    def "checkRegimenDrugException"() {
        when:
        CommonResponse response = authorizationsController.checkRegimenDrugException(customerId, hscId, drugExceptionCheckDO)

        then:
        1 * authorizations.validateAuthorization(customerId, hscId, false)
        1 * authorizationRuleHelper.checkRulesForRegimen(drugExceptionCheckDO, customerId) >> drugException

        and:
        response.getEmbedded() == ['_embedded': embeddedResponse]

        where:
        testCase | hscId | customerId | drugExceptionCheckDO                 | drugException                                                           | embeddedResponse
        0        | 12L   | 1          | new DrugExceptionCheckDO(hscID: 12L) | new TreatmentProcedureAuthorizationRuleVO(treatmentProcAuthRuleID: 123) | new TreatmentProcedureAuthorizationRuleVO(treatmentProcAuthRuleID: 123)
    }

    @Unroll
    def "checkRegimenDrugException NO HSC"() {
        when:
        CommonResponse response = authorizationsController.checkRegimenDrugException(customerId, drugExceptionCheckDO)

        then:
        1 * authorizations.validateCustomer(customerId)
        1 * authorizationRuleHelper.checkRulesForRegimen(drugExceptionCheckDO, customerId) >> drugException

        and:
        response.getEmbedded() == ['_embedded': embeddedResponse]

        where:
        testCase | customerId | drugExceptionCheckDO                 | drugException                                                           | embeddedResponse
        0        | 1          | new DrugExceptionCheckDO(hscID: 12L) | new TreatmentProcedureAuthorizationRuleVO(treatmentProcAuthRuleID: 123) | new TreatmentProcedureAuthorizationRuleVO(treatmentProcAuthRuleID: 123)
    }

    @Unroll
    def 'drugRounding'(){
        given:
        long TEST_HSC_ID = 1234L
        DrugRoundingRequestDO drugRoundingRequestDO = new DrugRoundingRequestDO(hscID: TEST_HSC_ID)
        DrugRoundingResponseDO drugRoundingResponseDO = new DrugRoundingResponseDO()

        when:
        CommonResponse response = authorizationsController.drugRounding(1, TEST_HSC_ID, drugRoundingRequestDO)

        then:
        1 * authorizations.validateAuthorization(_,_,_)
        1 * drugRounding.drugRoundingParsing(1, drugRoundingRequestDO) >> drugRoundingResponseDO

        and:
        response.getEmbedded() == ['_embedded': drugRoundingResponseDO]
    }

    @Unroll
    def "saveRequestingProvider"() {
        given:
        long hscID = 5555L
        long TEST_HSC_ID = 1234L
        long memberID = 5678L
        short providerSeqNum = 1
        int customerId = 1
        boolean featureFlag = true
        String stepperLocation = SpclCareReferenceConstants.AUTH_STEPPER_REQUESTING_PROVIDER
        HscProviderVO requestingProvider = new HscProviderVO(hscID: TEST_HSC_ID, providerSeqNum: providerSeqNum)
        HscVO hscVO = new HscVO(hscID: hscID, memberID: memberID)
        List<MemberCoverageVO> memberCoverageVOList = [new MemberCoverageVO()]
        List<String> ipaNumberList = [new String()]
        ProviderDetails providerDetails = new ProviderDetails()

        when:
        CommonResponse response = authorizationsController.saveRequestingProvider(customerId, hscID, requestingProvider)

        then:
        1 * hscHelper.isEandI(TEST_HSC_ID) >> isEandIMember
        1 * hscProvider.saveProviderAndRole(requestingProvider, HsrReferenceConstants.PROVIDER_ROLE_REQUESTING) >> requestingProvider
        1 * hscProvider.listByHscWithRoles(TEST_HSC_ID) >> []
        FeatureFlagUtility.getManager().isActive(SpclCareFeatureFlagConstants.DRAFT_JBPM_CALLS) >> false
        1 * hscHelper.autoTrackDraft(TEST_HSC_ID, stepperLocation)
        3 * hscHelper.getAuthType(TEST_HSC_ID) >> authType
        1 * hscHelper.isPHTherapyAuthorization(authType) >> true
        1 * hsc.read(TEST_HSC_ID) >> hscVO
        1 * memberCoverage.listByMemberID(_) >> memberCoverageVOList
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_PROVIDER_DETAILS_FOR_AUTH_TYPE) >> featureFlag
        1 * hscHelper.getProviderDetails(requestingProvider, memberCoverageVOList?.first()) >> providerDetails
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_PROVIDER_BLOCKING_RULES) >> featureFlag
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_MAP_UNIQUE_UNET_CONTRACT_LIST) >> featureFlag
        1 * hscHelper.getProviderIPAList(providerDetails, memberCoverageVOList?.first()) >> ipaNumberList

        and:
        response.getEmbedded() == ['_embedded': requestingProvider]
        requestingProvider.requestingProviderInd

        where:
        isEandIMember | authTypeCheck | authType                                                     | deleteProviders
        true          | 1             | SpclCareReferenceConstants.AUTH_TYPE_PHYSICAL_THERAPY        | 0
        true          | 1             | SpclCareReferenceConstants.AUTH_TYPE_SPEECH_THERAPY          | 1
        true          | 1             | SpclCareReferenceConstants.AUTH_TYPE_OCCUPATIONAL_THERAPY    | 0
    }

    @Unroll
    def "saveRequestingProvider Network Status for Exchange"() {
        given:
        long hscID = 5555L
        long TEST_HSC_ID = 1234L
        long memberID = 5678L
        short providerSeqNum = 1
        int customerId = 1
        String stepperLocation = SpclCareReferenceConstants.AUTH_STEPPER_REQUESTING_PROVIDER
        HscProviderVO requestingProvider = new HscProviderVO(hscID: TEST_HSC_ID, providerSeqNum: providerSeqNum)
        HscVO hscVO = new HscVO(hscID: hscID, memberID: memberID)
        List<MemberCoverageVO> memberCoverageVOList = [new MemberCoverageVO(reportCode: reportCode)]
        List<String> ipaNumberList = [new String()]
        ProviderDetails providerDetails = new ProviderDetails(networkStatusType: networkStatusType)

        when:
        CommonResponse response = authorizationsController.saveRequestingProvider(customerId, hscID, requestingProvider)

        then:
        1 * hscHelper.isEandI(TEST_HSC_ID) >> true
        1 * hscProvider.saveProviderAndRole(requestingProvider, HsrReferenceConstants.PROVIDER_ROLE_REQUESTING) >> requestingProvider
        1 * hscProvider.listByHscWithRoles(TEST_HSC_ID) >> []
        FeatureFlagUtility.getManager().isActive(SpclCareFeatureFlagConstants.DRAFT_JBPM_CALLS) >> false
        1 * hscHelper.autoTrackDraft(TEST_HSC_ID, stepperLocation)
        3 * hscHelper.getAuthType(TEST_HSC_ID) >> '1'
        2 * hscHelper.isPHTherapyAuthorization(_) >> true
        1 * hsc.read(TEST_HSC_ID) >> hscVO
        1 * memberCoverage.listByMemberID(_) >> memberCoverageVOList
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_NETWORK_STATUS_DERIVATION_FOR_EXCHANGE) >> featureFlag
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_PROVIDER_DETAILS_FOR_AUTH_TYPE) >> featureFlag
        1 * hscHelper.getProviderDetails(requestingProvider, memberCoverageVOList?.first()) >> providerDetails
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_PROVIDER_BLOCKING_RULES) >> featureFlag
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_MAP_UNIQUE_UNET_CONTRACT_LIST) >> featureFlag
        1 * hscHelper.getProviderIPAList(providerDetails, memberCoverageVOList?.first()) >> ipaNumberList

        and:
        response.getEmbedded() == ['_embedded': requestingProvider]
        requestingProvider.networkStatusType

        where:
        featureFlag   | reportCode | networkStatusType | result
        true          | 'EXGN'     | '1'               | '1'
        true          | 'EXGN'     | '2'               | '2'
    }
    
    @Unroll
    def "saveRequestingProvider Network Status for Cosmos"() {
        given:
        long hscID = 5555L
        long TEST_HSC_ID = 1234L
        long memberID = 5678L
        short providerSeqNum = 1
        int customerId = 1
        String stepperLocation = SpclCareReferenceConstants.AUTH_STEPPER_REQUESTING_PROVIDER
        HscProviderVO requestingProvider = new HscProviderVO(hscID: TEST_HSC_ID, providerSeqNum: providerSeqNum)
        HscVO hscVO = new HscVO(hscID: hscID, memberID: memberID)
        List<MemberCoverageVO> memberCoverageVOList = [new MemberCoverageVO(claimPlatformID: "01")]
        List<String> ipaNumberList = [new String()]
        ProviderDetails providerDetails = new ProviderDetails(networkStatusType: networkStatusTypeFromEDI)

        when:
        CommonResponse response = authorizationsController.saveRequestingProvider(customerId, hscID, requestingProvider)

        then:
        1 * hscHelper.isEandI(TEST_HSC_ID) >> true
        1 * hscProvider.saveProviderAndRole(requestingProvider, HsrReferenceConstants.PROVIDER_ROLE_REQUESTING) >> requestingProvider
        1 * hscProvider.listByHscWithRoles(TEST_HSC_ID) >> []
        FeatureFlagUtility.getManager().isActive(SpclCareFeatureFlagConstants.DRAFT_JBPM_CALLS) >> false
        1 * hscHelper.autoTrackDraft(TEST_HSC_ID, stepperLocation)
        3 * hscHelper.getAuthType(TEST_HSC_ID) >> '1'
        2 * hscHelper.isPHTherapyAuthorization(_) >> true
        1 * hsc.read(TEST_HSC_ID) >> hscVO
        1 * memberCoverage.listByMemberID(_) >> memberCoverageVOList
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_NETWORK_STATUS_DERIVATION_FOR_EXCHANGE) >> true
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_PROVIDER_DETAILS_FOR_AUTH_TYPE) >> true
        1 * hscHelper.getProviderDetails(requestingProvider, memberCoverageVOList?.first()) >> providerDetails
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_PROVIDER_BLOCKING_RULES) >> true
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_MAP_UNIQUE_UNET_CONTRACT_LIST) >> true
        1 * hscHelper.getProviderIPAList(providerDetails, memberCoverageVOList?.first()) >> ipaNumberList
        1 * hscHelper.isInOrOutOfNetwork(_, _) >> networkStatusTypeFromSpclCare

        and:
        response.getEmbedded() == ['_embedded': requestingProvider]
        requestingProvider.networkStatusType.equalsIgnoreCase(result)

        where:
        networkStatusTypeFromEDI  | networkStatusTypeFromSpclCare | result
        '1'                       | '1'                           | '1'
        '2'                       | '2'                           | '2'
        '1'                       | '2'                           | '2'
        '2'                       | '1'                           | '1'
    }

    @Unroll
    def "saveRequestingProvider Network Status for Facets"() {
        given:
        long hscID = 5555L
        long TEST_HSC_ID = 1234L
        long memberID = 5678L
        short providerSeqNum = 1
        int customerId = 1
        String stepperLocation = SpclCareReferenceConstants.AUTH_STEPPER_REQUESTING_PROVIDER
        HscProviderVO requestingProvider = new HscProviderVO(hscID: TEST_HSC_ID, providerSeqNum: providerSeqNum)
        HscVO hscVO = new HscVO(hscID: hscID, memberID: memberID)
        List<MemberCoverageVO> memberCoverageVOList = [new MemberCoverageVO(claimPlatformID: "A9")]
        List<String> ipaNumberList = [new String()]
        ProviderDetails providerDetails = new ProviderDetails(networkStatusType: networkStatusTypeFromEDI)

        when:
        CommonResponse response = authorizationsController.saveRequestingProvider(customerId, hscID, requestingProvider)

        then:
        1 * hscHelper.isEandI(TEST_HSC_ID) >> true
        1 * hscProvider.saveProviderAndRole(requestingProvider, HsrReferenceConstants.PROVIDER_ROLE_REQUESTING) >> requestingProvider
        1 * hscProvider.listByHscWithRoles(TEST_HSC_ID) >> []
        FeatureFlagUtility.getManager().isActive(SpclCareFeatureFlagConstants.DRAFT_JBPM_CALLS) >> false
        1 * hscHelper.autoTrackDraft(TEST_HSC_ID, stepperLocation)
        3 * hscHelper.getAuthType(TEST_HSC_ID) >> '1'
        2 * hscHelper.isPHTherapyAuthorization(_) >> true
        1 * hsc.read(TEST_HSC_ID) >> hscVO
        1 * hscHelper.isOxfordProvider(_) >> false
        1 * memberCoverage.listByMemberID(_) >> memberCoverageVOList
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_NETWORK_STATUS_DERIVATION_FOR_EXCHANGE) >> true
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_PROVIDER_DETAILS_FOR_AUTH_TYPE) >> true
        1 * hscHelper.getProviderDetails(requestingProvider, memberCoverageVOList?.first()) >> providerDetails
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_PROVIDER_BLOCKING_RULES) >> true
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_MAP_UNIQUE_UNET_CONTRACT_LIST) >> true
        1 * hscHelper.getProviderIPAList(providerDetails, memberCoverageVOList?.first()) >> ipaNumberList
        0 * hscHelper.isInOrOutOfNetwork(_, _) >> networkStatusTypeFromSpclCare

        and:
        response.getEmbedded() == ['_embedded': requestingProvider]
        requestingProvider.networkStatusType.equalsIgnoreCase(result)

        where:
        networkStatusTypeFromEDI  | networkStatusTypeFromSpclCare | result
        '1'                       | '1'                           | '1'
        '2'                       | '2'                           | '2'
        '1'                       | '2'                           | '1'
        '2'                       | '1'                           | '2'
    }

    @Unroll
    def "saveRequestingProviderforIfCheck"() {
        given:
        long hscID = 5555L
        long TEST_HSC_ID = 1234L
        long memberID = 5678L
        short providerSeqNum = 1
        int customerId = 1
        boolean featureFlag = true
        String stepperLocation = SpclCareReferenceConstants.AUTH_STEPPER_REQUESTING_PROVIDER
        HscProviderVO requestingProvider = new HscProviderVO(hscID: TEST_HSC_ID, providerSeqNum: providerSeqNum)
        HscVO hscVO = new HscVO(hscID: hscID, memberID: memberID)
        List<MemberCoverageVO> memberCoverageVOList = [new MemberCoverageVO()]
        List<String> ipaNumberList = [new String()]
        ProviderDetails providerDetails = new ProviderDetails()

        when:
        CommonResponse response = authorizationsController.saveRequestingProvider(customerId, hscID, requestingProvider)

        then:
        1 * hscHelper.isEandI(TEST_HSC_ID) >> isEandIMember
        1 * hscProvider.saveProviderAndRole(requestingProvider, HsrReferenceConstants.PROVIDER_ROLE_REQUESTING) >> requestingProvider
        1 * hscProvider.listByHscWithRoles(TEST_HSC_ID) >> []
        FeatureFlagUtility.getManager().isActive(SpclCareFeatureFlagConstants.DRAFT_JBPM_CALLS) >> false
        1 * hscHelper.autoTrackDraft(TEST_HSC_ID, stepperLocation)
        hscHelper.getAuthType(TEST_HSC_ID) >> authType
        0 * hscHelper.isPHTherapyAuthorization(authType) >> true
        1 * hsc.read(TEST_HSC_ID) >> hscVO
        1 * memberCoverage.listByMemberID(_) >> memberCoverageVOList
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_PROVIDER_DETAILS_FOR_AUTH_TYPE) >> featureFlag
        0 * hscHelper.getProviderDetails(requestingProvider, memberCoverageVOList?.first()) >> providerDetails
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_PROVIDER_BLOCKING_RULES) >> false
        0 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_MAP_UNIQUE_UNET_CONTRACT_LIST) >> featureFlag
        0 * hscHelper.getProviderIPAList(providerDetails, memberCoverageVOList?.first()) >> ipaNumberList
        1 * hscHelper.isOxfordProvider(_) >> true
        1 * FeatureFlagUtility.getManager()?.isActive(SpclCareFeatureFlagConstants.ENABLE_EPA_INTERGRATION_FOR_SPECIALTY_BCBS) >> false




        and:
        response.getEmbedded() == ['_embedded': requestingProvider]
        requestingProvider.requestingProviderInd

        where:
        isEandIMember | authTypeCheck | authType                                                     | deleteProviders
        true          | 1             | SpclCareReferenceConstants.AUTH_TYPE_PHYSICAL_THERAPY        | 0
    }

    def 'test saveStartDate'() {
        given:
        Date today = UhgCalendarUtilities.getTodaysDate()
        StartDateDO startDateDO = new StartDateDO(startDate: today, hscID: 123L)

        when:
        CommonResponse response = authorizationsController.saveStartDate(1, startDateDO)

        then:
        1 * authorizations.validateAuthorization(1, 123, false)
        1 * hscHelper.saveStartDate(today, 0, 123L, true)
        0 * _
    }

    def 'test callFusionEngine'() {
        given:
        HscFusionDO hscFusionDO = new HscFusionDO()
        OrxFusionResponse orxFusionResponse = new OrxFusionResponse()

        when:
        CommonResponse response = authorizationsController.callFusionEngine(2, 123L, hscFusionDO)

        then:
        1 * authorizations.validateAuthorization(2, 123L, true)
        1 * orxFusionService.callFusionEngine(_,_) >> [orxFusionResponse]
        _ * orxFusionService.mergeOrxFusionResponseList(_) >> orxFusionResponse
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.MERGE_MULTIPLE_FUSION_RESPONSES) >> flag

        and:
        response.getEmbedded().get('_embedded')

        where:
        testCase  |  flag   |  result
        0         |  true   |  new OrxFusionResponse()
        1         |  false  |  [new OrxFusionResponse()]

    }

    def 'test adjustPHTherapyAuth'() {
        given:
        int customerId = 1
        long hscId = 1
        AdjustAuthDO adjustAuthDO = new AdjustAuthDO(hscID: 1, reviseReason: '208')

        when:
        CommonResponse response = authorizationsController.adjustPHTherapyAuth(customerId, hscId, adjustAuthDO)

        then:
        1 * authorizations.validateCustomer(customerId)
        1 * hscHelper.adjustPHTherapyAuth(customerId, adjustAuthDO)
    }

    def "auth Details Endpoint"() {
        given:
            long hscID = 12345L
            int customerId = 1
            ResponseEntity<AuthDetailsDO> authDetailsResponse = new ResponseEntity<>(new AuthDetailsDO(new ArrayList<ProcedureViewVO>(), new ArrayList<TreatmentSupportiveCareProcedureVO>(), new ArrayList<HscServiceVO>(), new HscProviderVO()), HttpStatus.OK)
        when:
            CommonResponse response = authorizationsController.getAuthDetails(customerId, hscID, hscAuthType)
        then:
            1 * authorizations.validateCustomer(customerId)
            1 * hscHelper.getAuthDetails(hscID, customerId, hscAuthType) >> authDetailsResponse
        and:
            response.getEmbedded() == ['_embedded': authDetailsResponse]
        where:
            hscAuthType << ["2", "4"]
    }

    @Unroll
    def 'test updateClaimsHistory'() {
        given:
        int memberId = 0
        int customerId = 1
        String policyId = "1"
        long hscId = 1000
        CommonResponse result
        query?.addQueryFilter(response)

        when:
        result = authorizationsController.updateClaimsHistory(customerId, memberId, hscId, policyId, query)

        then:
        1 * authorizations.validateCustomer(customerId)
        (0..1) * query.getQueryFilter("customQueryFilter") >> response

        and:
        result?.getEmbedded()?.get("_embedded") == response

        where:
        query                  | response
        new QueryProperties() | new QueryFilter("customQueryFilter", "test")
        null                   | null
    }
}
