package com.optum.app.shared.procedure.controller

import com.optum.app.ocm.controller.support.CommonResponse
import com.optum.app.shared.epa.businesslogic.ProcedureBenefit
import com.optum.app.shared.procedure.businesslogic.ProcedureBrand
import com.optum.app.shared.procedure.data.ProcedureBrandVO
import com.optum.app.shared.spclcare.SpecialtyCareReadLogicSpecification
import com.optum.app.shared.specialtyPharmacy.businesslogic.SpecialtyProcedure
import com.optum.rf.dao.sql.query.QueryProperties

class ProcedureBrandControllerSpec extends SpecialtyCareReadLogicSpecification{

    ProcedureBrandController procedureBrandController = new ProcedureBrandController();
    ProcedureBrand procedureBrand = Mock(ProcedureBrand)
    ProcedureBenefit procedureBenefit = Mock(ProcedureBenefit)
    SpecialtyProcedure specialtyProcedure = Mock(SpecialtyProcedure)

    def setup(){
        procedureBrandController.procedureBrand = procedureBrand
        procedureBrandController.procedureBenefit = procedureBenefit
        procedureBrandController.specialtyProcedure = specialtyProcedure
    }

    def "Test getProcedureBrandById"(){
        given:
        String procedureCode = "J8520"
        List<ProcedureBrandVO> procedureBrandVOList = [new ProcedureBrandVO()]

        when:
        CommonResponse commonResponse = procedureBrandController.getProcedureBrandById(procedureCode)

        then:
        1 * procedureBrand.listByProcedureCode(procedureCode) >> procedureBrandVOList
        0 * _

        and:
        commonResponse.getEmbedded().get('_embedded') == procedureBrandVOList
    }

    def "Test getProcedureBrand"(){
        given:
        List<ProcedureBrandVO> procedureBrandVOList = [new ProcedureBrandVO(procedureCode: '12345', procedureBrandName: 'brandName', procedureGenericName: 'genericName')]
        QueryProperties queryProperties = new QueryProperties()

        when:
        CommonResponse commonResponse = procedureBrandController.getProcedureBrand(queryProperties)

        then:
        1 * procedureBrand.list(_ as QueryProperties) >> procedureBrandVOList
        1 * procedureBrand.setNonPersistedFields(_)
        1 * procedureBrand.count(_ as QueryProperties)
        0 * _

        and:
        commonResponse.getEmbedded().get('_embedded') == procedureBrandVOList
    }

}
