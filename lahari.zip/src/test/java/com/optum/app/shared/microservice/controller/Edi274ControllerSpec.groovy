package com.optum.app.shared.microservice.controller

import com.optum.app.ocm.controller.support.CommonResponse
import com.optum.app.shared.microservice.businesslogic.Edi274
import com.optum.app.shared.microservice.constants.EdiConstants
import com.optum.app.shared.microservice.data.ProfessionalRequestDO
import com.optum.app.shared.microservice.data.ProfessionalRequestHelperDO
import com.optum.app.shared.microservice.data.ProviderDetails
import com.optum.app.shared.microservice.data.ProviderDetailsRequest
import com.optum.app.shared.spclcare.SpecialtyCareReadLogicSpecification
import com.optum.rf.dao.sql.query.QueryFilter
import com.optum.rf.dao.sql.query.QueryProperties
import spock.lang.Unroll

class Edi274ControllerSpec extends SpecialtyCareReadLogicSpecification {

    private static final String TEST_TAX_ID_FACILITY = '12345'
    private static final String TEST_TAX_ID_PHYSICIAN = '67890'
    private static final String TEST_FIRST_NAME = 'Paul'
    private static final String TEST_FIRST_NAME_WILDCARD = 'Paul*'
    private static final String TEST_LAST_NAME = 'Bunyan'
    private static final String TEST_LAST_NAME_WILDCARD = 'Bunyan*'
    private static final String TEST_BUSINESS_NAME = 'General Hospital'
    private static final String TEST_BUSINESS_NAME_WILDCARD = 'General Hospital*'
    private static final String TEST_NPI = '987654321'
    private static final String TEST_STATE_FACILITY = 'MN'
    private static final String TEST_STATE_PHYSICIAN = 'OH'
    private static final String TEST_ZIP_FACILITY = '55442'
    private static final String TEST_ZIP_PHYSICIAN = '33333'
    private static final String TEST_PROVIDER_ID = '123456789'
    private static final String TEST_NDB_ADR_SEQ_NBR = '12'
    private static final String TEST_HSC_ID = '12345'
    private static final String TEST_MEMBER_ID = '67890'
    private static final String TEST_MARKET_NUMBER = '123'
    private static final String TEST_PRODUCT_TYPE = 'POV'
    private static final String TEST_OBLIGOR_ID = '01'
    private static final String TEST_SHARED_ARRANGEMENT_ID = '02'
    private static final String TEST_MARKET_NETWORK_ID = '03'
    private static final String TEST_MARKET_TYPE = '04'
    private static final String TEST_IPA_ID = '05'
    private static final String TEST_DIV_ID = '06'
    private static final String TEST_PANEL_ID = '07'
    private static final String TEST_CLAIM_PLATFORM_ID = '08'
    private static final String TEST_HEALTH_SERVICE_PRODUCT_CODE = '09'
    private static final String TEST_SERVICE_SEQ_NBR = '1'
    private static final String TEST_EMERGENT_WRAP_BENEFICIARY_TYPE_ID = '10'
    private static final String TEST_POLICY_ISSUE_STATE = 'MN'
    private static final String TEST_REPORT_CODE = '11'
    private static final String TEST_PRODUCT_CODE = '12'
    private static final String TEST_LEGAL_ENTITY_ID = '12'
    private static final int TEST_CUSTOMER_ID = 1
    private static final String TEST_TINID = '1111'
    private static final String TEST_PROVIDER_TYPE_CODE = 'TIN'
    private static final String TEST_ADDRESS_TYPE_CODE = 'PRAC'
    private static final String TEST_MDM_PROVIDER_ID = '111'
    private static final String TEST_MDM_ADDRESS_ID= '222'
    private static final String TEST_MDM_DECNUMBER= '333'
    private static final String TEST_CITY = 'city'
    private static final String TEST_PRIMARY_COV_REPORT_CODE = 'EXGN'
    private static final String TEST_PRIMARY_COV_POLICY_ISSUE_STATE = 'OH'

    Edi274Controller edi274Controller
    Edi274 edi274

    def setup() {
        edi274Controller = new Edi274Controller()
        edi274 = Mock(Edi274)

        edi274Controller.edi274 = edi274
    }

    @Unroll
    def "test getEdi274"() {
        when:
        CommonResponse response = edi274Controller.getEdi274(TEST_TAX_ID_FACILITY,
                                                             TEST_TAX_ID_PHYSICIAN,
                                                             firstName,
                                                             lastName,
                                                             businessName,
                                                             TEST_NPI,
                                                             TEST_STATE_FACILITY,
                                                             TEST_STATE_PHYSICIAN,
                                                             TEST_ZIP_FACILITY,
                                                             TEST_ZIP_PHYSICIAN,
                                                             providerType,
                                                             providerSubType,
                                                             ndbAddressSeqNum,
                                                             providerAddress1,
                                                             providerAddress2,
                                                             providerCity,
                                                             TEST_CUSTOMER_ID,
                                                             Long.parseLong(TEST_HSC_ID)
        )

        then:
        1 * edi274.getEdi274(_ as ProfessionalRequestDO) >> getProfessionalRequestDOList()
        (List<ProfessionalRequestDO>) response.getEmbedded().get(CommonResponse.EMBEDDED)
        0 *_._

        where:
        providerType                            | providerSubType                           | firstName                | lastName                | businessName                | ndbAddressSeqNum | providerAddress1 | providerAddress2 | providerCity
        EdiConstants.PROVIDER_TYPE_PROFESSIONAL | EdiConstants.PROVIDER_SUB_TYPE_TAXID      | null                     | null                    | null                        | null             | null             | null             | null
        EdiConstants.PROVIDER_TYPE_PROFESSIONAL | EdiConstants.PROVIDER_SUB_TYPE_NAME_STATE | TEST_FIRST_NAME          | TEST_LAST_NAME          | null                        | null             | null             | null             | null
        EdiConstants.PROVIDER_TYPE_PROFESSIONAL | EdiConstants.PROVIDER_SUB_TYPE_NAME_STATE | TEST_FIRST_NAME_WILDCARD | TEST_LAST_NAME_WILDCARD | null                        | null             | null             | null             | null
        EdiConstants.PROVIDER_TYPE_FACILITY     | EdiConstants.PROVIDER_SUB_TYPE_TAXID      | null                     | null                    | null                        | null             | null             | null             | null
        EdiConstants.PROVIDER_TYPE_FACILITY     | EdiConstants.PROVIDER_SUB_TYPE_NAME_STATE | null                     | null                    | TEST_BUSINESS_NAME          | null             | null             | null             | null
        EdiConstants.PROVIDER_TYPE_FACILITY     | EdiConstants.PROVIDER_SUB_TYPE_NAME_STATE | null                     | null                    | TEST_BUSINESS_NAME_WILDCARD | null             | null             | null             | null
        null                                    | null                                      | null                     | null                    | null                        | "35"             | null             | null             | null
        EdiConstants.PROVIDER_TYPE_PROFESSIONAL | null                                      | TEST_FIRST_NAME          | TEST_LAST_NAME          | null                        | "-1"             | "Address 1"      | null             | "City"
        EdiConstants.PROVIDER_TYPE_FACILITY     | null                                      | null                     | null                    | TEST_BUSINESS_NAME          | "-1"             | "Address 1"      | null             | "City"
    }

    def "when provider is a physician and has # in its address1"() {

        given:
        List<ProfessionalRequestDO> responses = new ArrayList<>()

        when:
        CommonResponse response = edi274Controller.getEdi274(TEST_TAX_ID_FACILITY,
                TEST_TAX_ID_PHYSICIAN,
                TEST_FIRST_NAME,
                TEST_LAST_NAME,
                null,
                TEST_NPI,
                TEST_STATE_FACILITY,
                TEST_STATE_PHYSICIAN,
                TEST_ZIP_FACILITY,
                TEST_ZIP_PHYSICIAN,
                EdiConstants.PROVIDER_TYPE_PROFESSIONAL,
                EdiConstants.PROVIDER_SUB_TYPE_NAME_STATE,
                "-1",
                providerAddress1,
                "Address 2",
                TEST_CITY,
                TEST_CUSTOMER_ID,
                Long.parseLong(TEST_HSC_ID)
        )

        then:
        1 * edi274.getEdi274(_ as ProfessionalRequestDO) >> [new ProfessionalRequestDO(address1: "Address#1")]

        and:
        ((List<ProfessionalRequestDO>) response.getEmbedded().get(CommonResponse.EMBEDDED)).get(0).address1 == result

        where:
        testCase  |  providerAddress1  |  result
        0         |  "Address#1"       |  "Address#1"
    }

    def "when provider is a facility and has # in its address1"() {

        given:
        List<ProfessionalRequestDO> responses = new ArrayList<>()

        when:
        CommonResponse response = edi274Controller.getEdi274(TEST_TAX_ID_FACILITY,
                TEST_TAX_ID_PHYSICIAN,
                null,
                null,
                TEST_BUSINESS_NAME,
                TEST_NPI,
                TEST_STATE_FACILITY,
                TEST_STATE_PHYSICIAN,
                TEST_ZIP_FACILITY,
                TEST_ZIP_PHYSICIAN,
                EdiConstants.PROVIDER_TYPE_PROFESSIONAL,
                EdiConstants.PROVIDER_SUB_TYPE_NAME_STATE,
                "-1",
                providerAddress1,
                "Address 2",
                TEST_CITY,
                TEST_CUSTOMER_ID,
                Long.parseLong(TEST_HSC_ID)
        )

        then:
        1 * edi274.getEdi274(_ as ProfessionalRequestDO) >> [new ProfessionalRequestDO(address1: "Address#1")]

        and:
        ((List<ProfessionalRequestDO>) response.getEmbedded().get(CommonResponse.EMBEDDED)).get(0).address1 == result

        where:
        testCase  |  providerAddress1  |  result
        0         |  "Address#1"       |  "Address#1"
    }

    def "when provider is a physician and has # in its address2"() {

        given:
        List<ProfessionalRequestDO> responses = new ArrayList<>()

        when:
        CommonResponse response = edi274Controller.getEdi274(TEST_TAX_ID_FACILITY,
                TEST_TAX_ID_PHYSICIAN,
                TEST_FIRST_NAME,
                TEST_LAST_NAME,
                null,
                TEST_NPI,
                TEST_STATE_FACILITY,
                TEST_STATE_PHYSICIAN,
                TEST_ZIP_FACILITY,
                TEST_ZIP_PHYSICIAN,
                EdiConstants.PROVIDER_TYPE_PROFESSIONAL,
                EdiConstants.PROVIDER_SUB_TYPE_NAME_STATE,
                "-1",
                "Address 1",
                providerAddress2,
                TEST_CITY,
                TEST_CUSTOMER_ID,
                Long.parseLong(TEST_HSC_ID)
        )

        then:
        1 * edi274.getEdi274(_ as ProfessionalRequestDO) >> [new ProfessionalRequestDO(address2: "Address#2")]

        and:
        ((List<ProfessionalRequestDO>) response.getEmbedded().get(CommonResponse.EMBEDDED)).get(0).address2 == result

        where:
        testCase  |  providerAddress2  |  result
        0         |  "Address#2"       |  "Address#2"
    }

    def "when provider is a facility and has # in its address2"() {

        given:
        List<ProfessionalRequestDO> responses = new ArrayList<>()

        when:
        CommonResponse response = edi274Controller.getEdi274(TEST_TAX_ID_FACILITY,
                TEST_TAX_ID_PHYSICIAN,
                null,
                null,
                TEST_BUSINESS_NAME,
                TEST_NPI,
                TEST_STATE_FACILITY,
                TEST_STATE_PHYSICIAN,
                TEST_ZIP_FACILITY,
                TEST_ZIP_PHYSICIAN,
                EdiConstants.PROVIDER_TYPE_PROFESSIONAL,
                EdiConstants.PROVIDER_SUB_TYPE_NAME_STATE,
                "-1",
                "Address 1",
                providerAddress2,
                TEST_CITY,
                TEST_CUSTOMER_ID,
                Long.parseLong(TEST_HSC_ID)
        )

        then:
        1 * edi274.getEdi274(_ as ProfessionalRequestDO) >> [new ProfessionalRequestDO(address2: "Address#2")]

        and:
        ((List<ProfessionalRequestDO>) response.getEmbedded().get(CommonResponse.EMBEDDED)).get(0).address2 == result

        where:
        testCase  |  providerAddress2  |  result
        0         |  "Address#2"       |  "Address#2"
    }

    def "when provider is a physician and has # in its address1 as well as address2"() {

        given:
        List<ProfessionalRequestDO> responses = new ArrayList<>()

        when:
        CommonResponse response = edi274Controller.getEdi274(TEST_TAX_ID_FACILITY,
                TEST_TAX_ID_PHYSICIAN,
                TEST_FIRST_NAME,
                TEST_LAST_NAME,
                null,
                TEST_NPI,
                TEST_STATE_FACILITY,
                TEST_STATE_PHYSICIAN,
                TEST_ZIP_FACILITY,
                TEST_ZIP_PHYSICIAN,
                EdiConstants.PROVIDER_TYPE_PROFESSIONAL,
                EdiConstants.PROVIDER_SUB_TYPE_NAME_STATE,
                "-1",
                "Address 1",
                providerAddress2,
                TEST_CITY,
                TEST_CUSTOMER_ID,
                Long.parseLong(TEST_HSC_ID)
        )

        then:
        1 * edi274.getEdi274(_ as ProfessionalRequestDO) >> [new ProfessionalRequestDO(address1: "Address#1", address2: "Address#2")]

        and:
        ((List<ProfessionalRequestDO>) response.getEmbedded().get(CommonResponse.EMBEDDED)).get(0).address1 == resultAddress1
        ((List<ProfessionalRequestDO>) response.getEmbedded().get(CommonResponse.EMBEDDED)).get(0).address2 == resultAddress2

        where:
        testCase  |  providerAddress1  |  providerAddress2  |  resultAddress1   |  resultAddress2
        0         |  "Address#1"       |  "Address#2"       |  "Address#1"      |  "Address#2"
    }

    def "when provider is a facility and has # in its address1 as well as address2"() {

        given:
        List<ProfessionalRequestDO> responses = new ArrayList<>()

        when:
        CommonResponse response = edi274Controller.getEdi274(TEST_TAX_ID_FACILITY,
                TEST_TAX_ID_PHYSICIAN,
                null,
                null,
                TEST_BUSINESS_NAME,
                TEST_NPI,
                TEST_STATE_FACILITY,
                TEST_STATE_PHYSICIAN,
                TEST_ZIP_FACILITY,
                TEST_ZIP_PHYSICIAN,
                EdiConstants.PROVIDER_TYPE_PROFESSIONAL,
                EdiConstants.PROVIDER_SUB_TYPE_NAME_STATE,
                "-1",
                providerAddress1,
                providerAddress2,
                TEST_CITY,
                TEST_CUSTOMER_ID,
                Long.parseLong(TEST_HSC_ID)
        )

        then:
        1 * edi274.getEdi274(_ as ProfessionalRequestDO) >> [new ProfessionalRequestDO(address1: "Address#1", address2: "Address#2")]

        and:
        ((List<ProfessionalRequestDO>) response.getEmbedded().get(CommonResponse.EMBEDDED)).get(0).address1 == resultAddress1
        ((List<ProfessionalRequestDO>) response.getEmbedded().get(CommonResponse.EMBEDDED)).get(0).address2 == resultAddress2

        where:
        testCase  |  providerAddress1  |  providerAddress2  |  resultAddress1   |  resultAddress2
        0         |  "Address#1"       |  "Address#2"       |  "Address#1"      |  "Address#2"
    }

    def "test getEdi274 with QueryProperties as Request"() {
        when:
        CommonResponse response = edi274Controller.getEdi274(queryProperties)

        then:
        1 * edi274.getEdi274(_ as QueryProperties, _ as ProfessionalRequestDO) >> new ProfessionalRequestHelperDO(totalRecordsCount: 1, doList: [new ProfessionalRequestDO()])
        (List<ProfessionalRequestDO>) response.getEmbedded().get(CommonResponse.EMBEDDED)
        0 *_._

        where:
        queryProperties << [
                new QueryProperties(queryFilters: [ new QueryFilter('providerType', EdiConstants.PROVIDER_TYPE_PROFESSIONAL),
                                                    new QueryFilter('firstName', TEST_FIRST_NAME),
                                                    new QueryFilter('lastName', TEST_LAST_NAME),
                                                    new QueryFilter('zip', TEST_ZIP_PHYSICIAN),
                                                    new QueryFilter('federalTaxID', TEST_TAX_ID_PHYSICIAN),
                                                    new QueryFilter('NPI', TEST_NPI),
                                                    new QueryFilter('state', TEST_STATE_PHYSICIAN),
                                                    new QueryFilter('businessName', TEST_BUSINESS_NAME),
                                                    new QueryFilter('claimPlatformID', TEST_CLAIM_PLATFORM_ID),
                                                    new QueryFilter('customerID', TEST_CUSTOMER_ID),
                                                    new QueryFilter('hscID', TEST_HSC_ID)
                ]),
                new QueryProperties(queryFilters: [ new QueryFilter('providerType', EdiConstants.PROVIDER_TYPE_PROFESSIONAL),
                                                    new QueryFilter('firstName', TEST_FIRST_NAME_WILDCARD),
                                                    new QueryFilter('lastName', TEST_LAST_NAME_WILDCARD),
                                                    new QueryFilter('businessName', TEST_BUSINESS_NAME_WILDCARD) ])
        ]
    }

    def "test getGoldCardStatus"() {

        given:
        ProfessionalRequestDO professionalRequestDO = new ProfessionalRequestDO()

        when:
        edi274Controller.getGoldCardStatus(professionalRequestDO)

        then:
        1 * edi274.getGoldCardStatus(professionalRequestDO)
    }

    def "test getProviderDetails"() {
        when:
        CommonResponse response = edi274Controller.getProviderDetails(true,
                                                                      TEST_PROVIDER_ID,
                                                                      TEST_NDB_ADR_SEQ_NBR,
                                                                      TEST_HSC_ID,
                                                                      TEST_MEMBER_ID,
                                                                      TEST_MARKET_NUMBER,
                                                                      TEST_PRODUCT_TYPE,
                                                                      TEST_OBLIGOR_ID,
                                                                      TEST_SHARED_ARRANGEMENT_ID,
                                                                      marketNetworkID,
                                                                      TEST_MARKET_TYPE,
                                                                      TEST_IPA_ID,
                                                                      TEST_DIV_ID,
                                                                      TEST_PANEL_ID,
                                                                      TEST_CLAIM_PLATFORM_ID,
                                                                      TEST_HEALTH_SERVICE_PRODUCT_CODE,
                                                                      TEST_SERVICE_SEQ_NBR,
                                                                      TEST_EMERGENT_WRAP_BENEFICIARY_TYPE_ID,
                                                                      TEST_POLICY_ISSUE_STATE,
                                                                      TEST_REPORT_CODE,
                                                                      TEST_PRODUCT_CODE,
                                                                      TEST_LEGAL_ENTITY_ID,
                                                                      false,
                                                                      TEST_TINID,
                                                                      TEST_PROVIDER_TYPE_CODE,
                                                                      TEST_ADDRESS_TYPE_CODE,
                                                                      TEST_MDM_PROVIDER_ID,
                                                                      TEST_MDM_ADDRESS_ID,
                                                                      TEST_MDM_DECNUMBER,
                                                                      TEST_PRIMARY_COV_REPORT_CODE,
                                                                      TEST_PRIMARY_COV_POLICY_ISSUE_STATE
        )

        then:
        1 * edi274.getProviderDetails(_ as ProviderDetailsRequest) >> getProviderDetails()
        (ProviderDetails) response.getEmbedded().get(CommonResponse.EMBEDDED)
        0 *_._

        where: marketNetworkID << [ TEST_MARKET_NETWORK_ID, 'null', null ]
    }

    def "test getProviderDetails with Contract Information"() {
        when:
        CommonResponse response = edi274Controller.getProviderDetails(makeProfessionalDetailCall,
                providerId,
                ndbAddressSequenceNumber,
                TEST_HSC_ID,
                TEST_MEMBER_ID,
                TEST_MARKET_NUMBER,
                TEST_PRODUCT_TYPE,
                TEST_OBLIGOR_ID,
                TEST_SHARED_ARRANGEMENT_ID,
                marketNetworkID,
                TEST_MARKET_TYPE,
                TEST_IPA_ID,
                TEST_DIV_ID,
                TEST_PANEL_ID,
                TEST_CLAIM_PLATFORM_ID,
                TEST_HEALTH_SERVICE_PRODUCT_CODE,
                TEST_SERVICE_SEQ_NBR,
                TEST_EMERGENT_WRAP_BENEFICIARY_TYPE_ID,
                TEST_POLICY_ISSUE_STATE,
                TEST_REPORT_CODE,
                TEST_PRODUCT_CODE,
                TEST_LEGAL_ENTITY_ID,
                retrieveContractDetails,
                TEST_TINID,
                TEST_PROVIDER_TYPE_CODE,
                TEST_ADDRESS_TYPE_CODE,
                TEST_MDM_PROVIDER_ID,
                TEST_MDM_ADDRESS_ID,
                TEST_MDM_DECNUMBER,
                TEST_PRIMARY_COV_REPORT_CODE,
                TEST_PRIMARY_COV_POLICY_ISSUE_STATE
        )

        then:
        1 * edi274.getProviderDetails(_ as ProviderDetailsRequest) >> getProviderDetails()
        (ProviderDetails) response.getEmbedded().get(CommonResponse.EMBEDDED)
        0 *_._

        where:
        makeProfessionalDetailCall   | retrieveContractDetails  | providerId | ndbAddressSequenceNumber | marketNetworkID
        true                         | true                     | '002976428'  | '5'                    | null
        true                         | false                    | '002976428'  | '5'                    | null
        false                        | true                     | '001021187'  | '10'                   | null
        false                        | false                    | '001021187'  | '10'                   | null
    }

    @Unroll
    def "test getEdi274 with QueryProperties"() {
        when:
        CommonResponse response = edi274Controller.getEdi274(queryProperties)

        then:
        1 * edi274.getEdi274(_ as QueryProperties, _ as ProfessionalRequestDO) >> new ProfessionalRequestHelperDO(totalRecordsCount: 1, doList: [new ProfessionalRequestDO()])
        (List<ProfessionalRequestDO>) response.getEmbedded().get(CommonResponse.EMBEDDED)
        0 *_._

        where:
        queryProperties << [
                new QueryProperties(queryFilters: [ new QueryFilter('providerType', EdiConstants.PROVIDER_TYPE_PROFESSIONAL),
                                                    new QueryFilter('firstName', TEST_FIRST_NAME),
                                                    new QueryFilter('lastName', TEST_LAST_NAME),
                                                    new QueryFilter('zip', TEST_ZIP_PHYSICIAN),
                                                    new QueryFilter('federalTaxID', TEST_TAX_ID_PHYSICIAN),
                                                    new QueryFilter('NPI', TEST_NPI),
                                                    new QueryFilter('state', TEST_STATE_PHYSICIAN),
                                                    new QueryFilter('businessName', TEST_BUSINESS_NAME) ]),
                new QueryProperties(queryFilters: [ new QueryFilter('providerType', EdiConstants.PROVIDER_TYPE_PROFESSIONAL),
                                                    new QueryFilter('firstName', TEST_FIRST_NAME_WILDCARD),
                                                    new QueryFilter('lastName', TEST_LAST_NAME_WILDCARD),
                                                    new QueryFilter('businessName', TEST_BUSINESS_NAME_WILDCARD) ])
        ]
    }

    private static List<ProfessionalRequestDO> getProfessionalRequestDOList() {
        List<ProfessionalRequestDO> professionalRequestDOs = new ArrayList<>()
        professionalRequestDOs.add(new ProfessionalRequestDO(providerID: TEST_PROVIDER_ID, providerNPI: TEST_NPI, customerID: TEST_CUSTOMER_ID))
        professionalRequestDOs
    }

    private static ProviderDetails getProviderDetails() {
        new ProviderDetails(firstName: TEST_FIRST_NAME, lastName: TEST_LAST_NAME)
    }

}
