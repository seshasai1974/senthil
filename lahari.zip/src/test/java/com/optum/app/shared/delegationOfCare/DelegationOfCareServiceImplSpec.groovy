package com.optum.app.shared.delegationOfCare

import com.optum.app.common.hsr.businesslogic.HscAttribute
import com.optum.app.common.hsr.data.HscAttributeVO
import com.optum.app.common.hsr.data.HscDiagnosisVO
import com.optum.app.common.hsr.data.HscMemberCoverageVO
import com.optum.app.common.hsr.data.HscProviderVO
import com.optum.app.common.hsr.data.HscServiceNonFacilityVO
import com.optum.app.common.hsr.data.HscServiceVO
import com.optum.app.common.hsr.data.HscVO
import com.optum.app.common.member.core.data.MemberAddressVO
import com.optum.app.common.member.core.data.MemberCoverageVO
import com.optum.app.common.member.core.data.MemberIdentifierVO
import com.optum.app.common.member.core.data.MemberVO
import com.optum.app.ocm.common.member.businesslogic.CoverageSystemCheckHelper
import com.optum.app.shared.constants.SpclCareFeatureFlagConstants
import com.optum.app.shared.constants.SpclCareReferenceConstants
import com.optum.app.shared.delegationOfCare.businesslogic.impl.DelegationOfCareServiceImpl
import com.optum.app.shared.federatedConfiguration.businesslogic.FederatedConfigService
import com.optum.app.shared.federatedConfiguration.data.DelegationOfCare
import com.optum.app.shared.hsc.data.AuthRequestDetailsDO
import com.optum.app.shared.hsc.data.domrV1.AuthorizationDelegationsDO
import com.optum.app.shared.hsc.data.domrV1.DelegationInformationDO
import com.optum.app.shared.hsc.data.domrV1.DiagnosisCode
import com.optum.app.shared.radiationOncology.data.CptCode
import com.optum.clinical.security.jwt.client.service.JwtClientService
import com.optum.rf.common.featureflag.util.FeatureFlagManager
import com.optum.rf.common.featureflag.util.FeatureFlagUtility
import com.optum.rf.common.settings.businesslogic.SystemSettingsWebService
import com.optum.rf.common.settings.data.SystemSettingsWebServiceVO
import com.optum.rf.core.util.UhgCalendar
import com.optum.rf.dao.util.UhgCalendarUtilities
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.client.RestTemplate
import spock.lang.Specification
import spock.lang.Unroll

import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpSession


class DelegationOfCareServiceImplSpec extends Specification {

    DelegationOfCareServiceImpl delegationOfCareServiceImpl = new DelegationOfCareServiceImpl()
    HscAttribute hscAttribute = Mock(HscAttribute)
    FederatedConfigService federatedConfigService = Mock(FederatedConfigService)
    CoverageSystemCheckHelper coverageSystemCheckHelper = Mock(CoverageSystemCheckHelper)
    FeatureFlagManager featureFlagManager = Mock(FeatureFlagManager)
    RestTemplate restTemplate = Mock(RestTemplate)
    SystemSettingsWebService systemSettingsWebService = Mock(SystemSettingsWebService)
    JwtClientService jwtClientService = Mock(JwtClientService)
    HttpServletRequest httpServletRequest = Mock(HttpServletRequest)
    HttpSession httpSession = Mock(HttpSession)

    def setup() {
        delegationOfCareServiceImpl.hscAttribute = hscAttribute
        delegationOfCareServiceImpl.federatedConfigService = federatedConfigService
        delegationOfCareServiceImpl.coverageSystemCheckHelper = coverageSystemCheckHelper
        delegationOfCareServiceImpl.restTemplate = restTemplate
        delegationOfCareServiceImpl.systemSettingsWebService = systemSettingsWebService
        delegationOfCareServiceImpl.jwtClientService = jwtClientService
        delegationOfCareServiceImpl.httpServletRequest = httpServletRequest
        delegationOfCareServiceImpl.httpSession = httpSession
        FeatureFlagUtility.featureFlagManager = featureFlagManager
    }

    @Unroll
    def "test saveDelegationOfCare"() {
        given:
        long hscID = 5555L
        HscVO hscVO = new HscVO(hscID: hscID)
        MemberVO memberVO = new MemberVO()

        when:
        delegationOfCareServiceImpl.saveDelegationOfCare(hscVO, memberVO, authStartDate)

        then:
        1 * FeatureFlagUtility.getManager()?.isActive(SpclCareFeatureFlagConstants.ENABLE_DELEGATION_OF_CARE) >> flag
        _ * FeatureFlagUtility.getManager()?.isActive(SpclCareFeatureFlagConstants.ALLOW_ALL_MEMBER_COVERAGES) >> flag2
        n * hscAttribute.save(_)
        _ * federatedConfigService.getDelegationOfCareByClientAndProduct(_,_) >> new DelegationOfCare(enabled: true, platformId: '_*')

        where:
        testCase | flag  | flag2 | n | authStartDate
            0    | true  | true  | 1 | UhgCalendarUtilities.getTodaysDate()
            1    | true  | false | 1 | UhgCalendarUtilities.getTodaysDate()
            2    | false | true  | 0 | UhgCalendarUtilities.getTodaysDate()
            3    | false | false | 0 | UhgCalendarUtilities.getTodaysDate()

    }

    @Unroll
    def "test checkDelegationOfCare"() {
        given:
        long hscID = 5555L
        HscVO hscVO = new HscVO(hscID: hscID, customerID: 2, authTypeID: '1')
        MemberCoverageVO memberMedicalCoverageVO = new MemberCoverageVO(coverageType: 'M', productCategoryType: '0', lineOfBusinessType:'5', coverageEndDate: new UhgCalendar().addDay(1).getSQLDate(), coverageEffectiveDate: new UhgCalendar().addMonth(-1).getSQLDate())

        when:
        boolean response = delegationOfCareServiceImpl.checkDelegationOfCare(hscVO, memberVO, UhgCalendarUtilities.getTodaysDate())

        then:
        _ * federatedConfigService.getDelegationOfCareByClientAndProduct(_,_) >> delegationOfCare
        _ * coverageSystemCheckHelper.selectMemberCoverageForHsr(_, _) >> memberMedicalCoverageVO
        

        and:
        response == result

        where:
        testCase | result | delegationOfCare                                                                                                                    | memberVO
        0        | true   | new DelegationOfCare(enabled: true, platformId: '_*')                                                                               | new MemberVO(origSystemMemberIDType:'CO', memberCoverageVOs:[new MemberCoverageVO(coverageType: 'M', productCategoryType: '0', lineOfBusinessType:'5', coverageEndDate: new UhgCalendar().addDay(1).getSQLDate(), coverageEffectiveDate: new UhgCalendar().addMonth(-1).getSQLDate())] )
        1        | true   | new DelegationOfCare(enabled: true, platformId: 'CO', supportedPopulations: [productCategoryType: '0', lineOfBusinessType: '5'])    | new MemberVO(origSystemMemberIDType:'CO', memberCoverageVOs:[new MemberCoverageVO(coverageType: 'M', productCategoryType: '0', lineOfBusinessType:'5', coverageEndDate: new UhgCalendar().addDay(1).getSQLDate(), coverageEffectiveDate: new UhgCalendar().addMonth(-1).getSQLDate())] )
        2        | false  | new DelegationOfCare(enabled: true, platformId: 'AP', supportedPopulations: [productCategoryType: '0', lineOfBusinessType: '12'])   | new MemberVO(origSystemMemberIDType:'CO', memberCoverageVOs:[new MemberCoverageVO(coverageType: 'M', productCategoryType: '0', lineOfBusinessType:'5', coverageEndDate: new UhgCalendar().addDay(1).getSQLDate(), coverageEffectiveDate: new UhgCalendar().addMonth(-1).getSQLDate())] )
        3        | false  | new DelegationOfCare(enabled: false)                                                                                                | new MemberVO(origSystemMemberIDType:'CO', memberCoverageVOs:[new MemberCoverageVO(coverageType: 'M', productCategoryType: '0', lineOfBusinessType:'5', coverageEndDate: new UhgCalendar().addDay(1).getSQLDate(), coverageEffectiveDate: new UhgCalendar().addMonth(-1).getSQLDate())] )
        4        | false  | new DelegationOfCare(enabled: true, platformId: 'CS', supportedPopulations: [productCategoryType: '_*', lineOfBusinessType: '10'])  | new MemberVO(origSystemMemberIDType:'CO', memberCoverageVOs:[new MemberCoverageVO(coverageType: 'M', productCategoryType: '0', lineOfBusinessType:'5', coverageEndDate: new UhgCalendar().addDay(1).getSQLDate(), coverageEffectiveDate: new UhgCalendar().addMonth(-1).getSQLDate())] )
        5        | false  | new DelegationOfCare(enabled: true, platformId: 'CO', supportedPopulations: [productCategoryType: '_*', lineOfBusinessType: '10'])  | new MemberVO(origSystemMemberIDType:'CO', memberCoverageVOs:[new MemberCoverageVO(coverageType: 'M', productCategoryType: '0', lineOfBusinessType:'5', coverageEndDate: new UhgCalendar().addDay(1).getSQLDate(), coverageEffectiveDate: new UhgCalendar().addMonth(-1).getSQLDate())] )
        6        | true   | new DelegationOfCare(enabled: true, platformId: '_*', supportedPopulations: [productCategoryType: '_*', lineOfBusinessType: '5'])   | new MemberVO(origSystemMemberIDType:'CO', memberCoverageVOs:[new MemberCoverageVO(coverageType: 'M', productCategoryType: '0', lineOfBusinessType:'5', coverageEndDate: new UhgCalendar().addDay(1).getSQLDate(), coverageEffectiveDate: new UhgCalendar().addMonth(-1).getSQLDate())] )


    }

    def "Check DOMR Status for Successful API Call when user selects CPT Codes"() {

        given:
        long hscID = 5555L
        long memberID = 1234L
        boolean authorizationDelegated = true
        String wsUrl = "http://localhost:8082/authorization/authorizationDomrStatus"
        SystemSettingsWebServiceVO systemSettingsWebServiceVO = new SystemSettingsWebServiceVO(wsUrl: wsUrl)
        AuthorizationDelegationsDO authorizationDelegationsDO = new AuthorizationDelegationsDO(
                hscId: hscID,
                mbrId: memberID,
                authType: "4",
                memberId: "123",
                platformId: "CO",
                memberSuffix: "01",
                memberGroup: "90111",
                div: "ntl",
                memberZipCode: "11111",
                effectiveDate: "2022-02-02",
                delegateParStatusType: "2",
                serviceLocZipCode: "22222",
                placeOfServiceCode: "24",
                diagnosisCodeDetails: [new DiagnosisCode(diagnosisCodeType: "0", diagCode: "C00.0")]
        )
        List<CptCode> cptCodes = [new CptCode(procCodeType: "2", procedureCode: "77067")]
        ResponseEntity<DelegationInformationDO> delegationInformationDOResponseEntity =  new ResponseEntity(new DelegationInformationDO(authorizationDelegated: authorizationDelegated), HttpStatus.OK)

        when:
        String delegatedAuth = delegationOfCareServiceImpl.determineDOMREligibilityForAuth(cptCodes, null, authorizationDelegationsDO)

        then:
        1 * systemSettingsWebService.read("domr") >> systemSettingsWebServiceVO
        1 * jwtClientService.getToken(_, _, _) >> "JWTTOKEN"
        _ * restTemplate.postForEntity(*_) >> delegationInformationDOResponseEntity
        _ * httpServletRequest?.getHeader("mbmtransactionid") >> "mbm"
        _ * httpServletRequest?.getHeader("PAYER") >> "PAYER"
        _ * httpSession?.getId() >> "John_Cena"

        and:
        delegatedAuth == "1"

    }

    def "Check DOMR Status for Successful API Call when user selects HCPC Codes"() {

        given:
        long hscID = 5555L
        long memberID = 1234L
        boolean authorizationDelegated = true
        String wsUrl = "http://localhost:8082/authorization/authorizationDomrStatus"
        SystemSettingsWebServiceVO systemSettingsWebServiceVO = new SystemSettingsWebServiceVO(wsUrl: wsUrl)
        AuthorizationDelegationsDO authorizationDelegationsDO = new AuthorizationDelegationsDO(
                hscId: hscID,
                mbrId: memberID,
                authType: "4",
                memberId: "123",
                platformId: "CO",
                memberSuffix: "01",
                memberGroup: "90111",
                div: "ntl",
                memberZipCode: "11111",
                effectiveDate: "2022-02-02",
                delegateParStatusType: "2",
                serviceLocZipCode: "22222",
                placeOfServiceCode: "24",
                diagnosisCodeDetails: [new DiagnosisCode(diagnosisCodeType: "0", diagCode: "C00.0")]
        )
        List<HscServiceVO> hscServiceVOs = [new HscServiceVO(procCodeType: "4", procedureCode: "J8999")]
        ResponseEntity<DelegationInformationDO> delegationInformationDOResponseEntity =  new ResponseEntity(new DelegationInformationDO(authorizationDelegated: authorizationDelegated), HttpStatus.OK)

        when:
        String delegatedAuth = delegationOfCareServiceImpl.determineDOMREligibilityForAuth(null, hscServiceVOs, authorizationDelegationsDO)

        then:
        1 * systemSettingsWebService.read("domr") >> systemSettingsWebServiceVO
        1 * jwtClientService.getToken(_, _, _) >> "JWTTOKEN"
        _ * restTemplate.postForEntity(*_) >> delegationInformationDOResponseEntity
        _ * httpServletRequest?.getHeader("mbmtransactionid") >> "mbm"
        _ * httpServletRequest?.getHeader("PAYER") >> "PAYER"
        _ * httpSession?.getId() >> "John_Cena"

        and:
        delegatedAuth == "1"

    }

    def"Check DOMR Status for Successful API Call when user selects Codes for physical therapy auth"(){

        given:
        long hscID = 5555L
        long memberID = 1234L
        boolean authorizationDelegated = true
        String wsUrl = "http://localhost:8082/authorization/authorizationDomrStatus"
        SystemSettingsWebServiceVO systemSettingsWebServiceVO = new SystemSettingsWebServiceVO(wsUrl: wsUrl)
        AuthorizationDelegationsDO authorizationDelegationsDO = new AuthorizationDelegationsDO(
                hscId: hscID,
                mbrId: memberID,
                authType: "6",
                memberId: "123",
                platformId: "CO",
                memberSuffix: "01",
                memberGroup: "90111",
                div: "ntl",
                memberZipCode: "11111",
                effectiveDate: "2022-02-02",
                delegateParStatusType: "2",
                serviceLocZipCode: "22222",
                placeOfServiceCode: "24",
                diagnosisCodeDetails: [new DiagnosisCode(diagnosisCodeType: "0", diagCode: "C00.0")]
        )

        ResponseEntity<DelegationInformationDO> delegationInformationDOResponseEntity =  new ResponseEntity(new DelegationInformationDO(authorizationDelegated: authorizationDelegated), HttpStatus.OK)

        when:
        String delegatedAuth = delegationOfCareServiceImpl.determineDOMREligibilityForAuth(null, null, authorizationDelegationsDO)

        then:
        1 * systemSettingsWebService.read("domr") >> systemSettingsWebServiceVO
        1 * jwtClientService.getToken(_, _, _) >> "JWTTOKEN"
        _ * restTemplate.postForEntity(*_) >> delegationInformationDOResponseEntity
        _ * httpServletRequest?.getHeader("mbmtransactionid") >> "mbm"
        _ * httpServletRequest?.getHeader("PAYER") >> "PAYER"
        _ * httpSession?.getId() >> "John_Cena"

        and:
        delegatedAuth == "1"

    }

    def"Check DOMR Status for Successful API Call when user selects Codes for speech therapy auth"(){

        given:
        long hscID = 5555L
        long memberID = 1234L
        boolean authorizationDelegated = true
        String wsUrl = "http://localhost:8082/authorization/authorizationDomrStatus"
        SystemSettingsWebServiceVO systemSettingsWebServiceVO = new SystemSettingsWebServiceVO(wsUrl: wsUrl)
        AuthorizationDelegationsDO authorizationDelegationsDO = new AuthorizationDelegationsDO(
                hscId: hscID,
                mbrId: memberID,
                authType: "7",
                memberId: "123",
                platformId: "CO",
                memberSuffix: "01",
                memberGroup: "90111",
                div: "ntl",
                memberZipCode: "11111",
                effectiveDate: "2022-02-02",
                delegateParStatusType: "2",
                serviceLocZipCode: "22222",
                placeOfServiceCode: "24",
                diagnosisCodeDetails: [new DiagnosisCode(diagnosisCodeType: "0", diagCode: "C00.0")]
        )

        ResponseEntity<DelegationInformationDO> delegationInformationDOResponseEntity =  new ResponseEntity(new DelegationInformationDO(authorizationDelegated: authorizationDelegated), HttpStatus.OK)

        when:
        String delegatedAuth = delegationOfCareServiceImpl.determineDOMREligibilityForAuth(null, null, authorizationDelegationsDO)

        then:
        1 * systemSettingsWebService.read("domr") >> systemSettingsWebServiceVO
        1 * jwtClientService.getToken(_, _, _) >> "JWTTOKEN"
        _ * restTemplate.postForEntity(*_) >> delegationInformationDOResponseEntity
        _ * httpServletRequest?.getHeader("mbmtransactionid") >> "mbm"
        _ * httpServletRequest?.getHeader("PAYER") >> "PAYER"
        _ * httpSession?.getId() >> "John_Cena"

        and:
        delegatedAuth == "1"

    }

    def"Check DOMR Status for Successful API Call when user selects Codes for occupational therapy auth"(){

        given:
        long hscID = 5555L
        long memberID = 1234L
        boolean authorizationDelegated = true
        String wsUrl = "http://localhost:8082/authorization/authorizationDomrStatus"
        SystemSettingsWebServiceVO systemSettingsWebServiceVO = new SystemSettingsWebServiceVO(wsUrl: wsUrl)
        AuthorizationDelegationsDO authorizationDelegationsDO = new AuthorizationDelegationsDO(
                hscId: hscID,
                mbrId: memberID,
                authType: "8",
                memberId: "123",
                platformId: "CO",
                memberSuffix: "01",
                memberGroup: "90111",
                div: "ntl",
                memberZipCode: "11111",
                effectiveDate: "2022-02-02",
                delegateParStatusType: "2",
                serviceLocZipCode: "22222",
                placeOfServiceCode: "24",
                diagnosisCodeDetails: [new DiagnosisCode(diagnosisCodeType: "0", diagCode: "C00.0")]
        )

        ResponseEntity<DelegationInformationDO> delegationInformationDOResponseEntity =  new ResponseEntity(new DelegationInformationDO(authorizationDelegated: authorizationDelegated), HttpStatus.OK)

        when:
        String delegatedAuth = delegationOfCareServiceImpl.determineDOMREligibilityForAuth(null, null, authorizationDelegationsDO)

        then:
        1 * systemSettingsWebService.read("domr") >> systemSettingsWebServiceVO
        1 * jwtClientService.getToken(_, _, _) >> "JWTTOKEN"
        _ * restTemplate.postForEntity(*_) >> delegationInformationDOResponseEntity
        _ * httpServletRequest?.getHeader("mbmtransactionid") >> "mbm"
        _ * httpServletRequest?.getHeader("PAYER") >> "PAYER"
        _ * httpSession?.getId() >> "John_Cena"

        and:
        delegatedAuth == "1"

    }

    def "Check DOMR Status for failed API Call"() {

        given:
        long hscID = 5555L
        long memberID = 1234L
        boolean authorizationDelegated = false
        String wsUrl = "http://localhost:8082/authorization/authorizationDomrStatus"
        SystemSettingsWebServiceVO systemSettingsWebServiceVO = new SystemSettingsWebServiceVO(wsUrl: wsUrl)
        AuthorizationDelegationsDO authorizationDelegationsDO = new AuthorizationDelegationsDO(
                hscId: hscID,
                mbrId: memberID,
                authType: "4",
                memberId: "123",
                platformId: "CO",
                memberSuffix: "01",
                memberGroup: "90111",
                div: "ntl",
                memberZipCode: "11111",
                effectiveDate: "2022-02-02",
                delegateParStatusType: "2",
                serviceLocZipCode: "22222",
                placeOfServiceCode: "24",
                diagnosisCodeDetails: [new DiagnosisCode(diagnosisCodeType: "0", diagCode: "C00.0")]
        )
        List<HscServiceVO> hscServiceVOs = [new HscServiceVO(procCodeType: "4", procedureCode: "J8999")]

        when:
        String delegatedAuth = delegationOfCareServiceImpl.determineDOMREligibilityForAuth(null, hscServiceVOs, authorizationDelegationsDO)
        then:
        1 * systemSettingsWebService.read("domr") >> systemSettingsWebServiceVO
        _ * httpServletRequest?.getHeader("mbmtransactionid") >> "mbm"
        _ * httpServletRequest?.getHeader("PAYER") >> {throw new IllegalStateException()}
        1 * jwtClientService.getToken(_, _, _) >> "JWTTOKEN"
        _ * restTemplate.postForEntity(_, _, _) >> {throw Exception}

        and:
        delegatedAuth == "0"

    }

    def "checkDOMREligibilityForMember"() {

        given:
        List<HscAttributeVO> hscAttributeVOS = [hscAttributeVO]

        when:
        boolean memberEligible = delegationOfCareServiceImpl.checkDOMREligibilityForMember(hscAttributeVOS)

        then:
        0 * _

        and:
        memberEligible == result

        where:
        testCase |  hscAttributeVO                                                          | result
        0        |  new HscAttributeVO(hscAttributeType: '134', hscAttributeValue: '1')     | true
        0        |  new HscAttributeVO(hscAttributeType: '134', hscAttributeValue: '0')     | false
        0        |  new HscAttributeVO()                                                    | false

    }

}
