package com.optum.app.shared.fax.controller

import com.optum.app.ocm.controller.support.CommonResponse
import com.optum.app.shared.fax.businesslogic.FaxDataHelper
import com.optum.app.shared.fax.data.FaxDataDO
import com.optum.app.shared.spclcare.SpecialtyCareReadLogicSpecification
import com.optum.mbm.fax.service.data.model.FaxDO
import com.optum.mbm.fax.service.data.model.FetchFaxHistoryDO
import com.optum.rf.dao.sql.query.QueryFilter
import com.optum.rf.dao.sql.query.QueryProperties
import com.uhg.app.common.constants.spclcare.FieldConstants
import spock.lang.Unroll

class FaxDataControllerSpec extends SpecialtyCareReadLogicSpecification {
    FaxDataController faxDataController
    FaxDataHelper faxDataHelper
    QueryProperties query

    def setup() {
        faxDataController = new FaxDataController()
        faxDataHelper = Mock(FaxDataHelper)
        faxDataController.faxDataHelper = faxDataHelper
        query = Mock(QueryProperties)
    }

    @Unroll
    def "test getFaxHistory"() {
        when:
        String hscId = new String("get")
        CommonResponse response = faxDataController.getFaxHistory(hscId,query)
        then:
        thrown(NullPointerException)
    }

    def "getFaxHistory"()
    {
        given:
        String hscId = new String("get")
        List<FetchFaxHistoryDO> data=new ArrayList<>()
        data.add(temp)
        when:

        faxDataController.getFaxHistory(hscId,query)

        then:
        1 * faxDataHelper.getFaxHistory(_) >> data

        where:
               testcase |     temp
                    1  |   new FetchFaxHistoryDO()

    }
    def "getFaxHistory if data size is zero"()
    {
        given:
        String hscId = new String("get")
        List<FetchFaxHistoryDO> data=new ArrayList<>()
        when:

        faxDataController.getFaxHistory(hscId,query)

        then:
        1 * faxDataHelper.getFaxHistory(_) >> data

    }
}
