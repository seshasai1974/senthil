package com.optum.app.shared.orxfusion

import com.optum.app.common.customer.data.CustomerVO
import com.optum.app.common.hsr.businesslogic.Hsc
import com.optum.app.common.hsr.businesslogic.HscAttribute
import com.optum.app.common.hsr.businesslogic.HscServiceDetail
import com.optum.app.common.hsr.data.*
import com.optum.app.common.hsr.helper.HscMemberCoverageHelper
import com.optum.app.common.member.core.data.MemberCoverageVO
import com.optum.app.common.member.core.data.MemberVO
import com.optum.app.ocm.customer.businesslogic.Customer
import com.optum.app.shared.constants.MultiPayerConstants
import com.optum.app.shared.constants.SpclCareFeatureFlagConstants
import com.optum.app.shared.constants.SpclCareReferenceConstants
import com.optum.app.shared.diseaseTraversal.businesslogic.TreatmentSupportiveCareProcedure
import com.optum.app.shared.diseaseTraversal.data.TreatmentSupportiveCareProcedureVO
import com.optum.app.shared.epa.businesslogic.ProcedureBenefit
import com.optum.app.shared.epa.data.ProcedureBenefitVO
import com.optum.app.shared.federatedConfiguration.businesslogic.FederatedConfigService
import com.optum.app.shared.federatedConfiguration.data.Integration
import com.optum.app.shared.federatedConfiguration.data.OptumFusionEngine
import com.optum.app.shared.federatedConfiguration.data.Population
import com.optum.app.shared.hsc.data.GenerateHscDO
import com.optum.app.shared.hsc.data.OrxFusionRequestDO
import com.optum.app.shared.jbpm.JbpmHelper
import com.optum.app.shared.microservice.businesslogic.MemberDetailsMergeLogic
import com.optum.app.shared.microservice.constants.RestConstants
import com.optum.app.shared.orxfusion.businesslogic.impl.OrxFusionServiceImpl
import com.optum.app.shared.orxfusion.data.OrxFusionResponse
import com.optum.app.shared.orxfusion.data.ScenarioClaims
import com.optum.app.shared.orxfusion.data.TxnData
import com.optum.app.shared.procedure.businesslogic.ProcedureBrand
import com.optum.app.shared.procedure.data.ProcedureBrandVO
import com.optum.mbm.flow.data.v1.request.RuleParameters
import com.optum.mbm.flow.data.v1.signal.StepperSignal
import com.optum.rf.common.featureflag.util.FeatureFlagManager
import com.optum.rf.common.featureflag.util.FeatureFlagUtility
import com.optum.rf.common.reference.businesslogic.CodeXRef
import com.optum.rf.common.settings.businesslogic.SystemSettingsWebService
import com.optum.rf.common.settings.businesslogic.SystemSettingsWebServiceModifier
import com.optum.rf.common.settings.data.SystemSettingsWebServiceModifierVO
import com.optum.rf.common.settings.data.SystemSettingsWebServiceVO
import com.optum.rf.core.spring.ApplicationContextHolder
import com.optum.rf.core.util.Environment
import com.optum.rf.core.util.UhgCalendar
import com.optum.rf.test.core.mock.spring.MockWebApplicationContext
import org.springframework.http.HttpHeaders
import org.springframework.http.ResponseEntity
import org.springframework.web.client.RestTemplate
import spock.lang.Specification
import spock.lang.Unroll

import java.sql.Date

import static org.springframework.http.HttpStatus.OK

class OrxFusionServiceImplSpec extends Specification {

    OrxFusionServiceImpl orxFusionServiceImpl = new OrxFusionServiceImpl()

    FederatedConfigService federatedConfigService = Mock(FederatedConfigService)
    HttpHeaders httpHeaders
    SystemSettingsWebService systemSettingsWebService = Mock(SystemSettingsWebService)
    FeatureFlagManager featureFlagManager = Mock(FeatureFlagManager)
    SystemSettingsWebServiceModifier systemSettingsWebServiceModifier = Mock(SystemSettingsWebServiceModifier)
    MemberDetailsMergeLogic memberDetailsMergeLogic = Mock(MemberDetailsMergeLogic)
    RestTemplate restTemplate = Mock(RestTemplate)
    HscMemberCoverageHelper hscMemberCoverageHelper = Mock(HscMemberCoverageHelper)
    HscAttribute hscAttribute = Mock(HscAttribute)
    TreatmentSupportiveCareProcedure treatmentSupportiveCareProcedure = Mock(TreatmentSupportiveCareProcedure)
    CodeXRef codeXRef
    HscServiceDetail hscServiceDetail = Mock(HscServiceDetail)
    ProcedureBrand procedureBrand = Mock(ProcedureBrand)
    ProcedureBenefit procedureBenefit = Mock(ProcedureBenefit)
    JbpmHelper jbpmHelper = Mock(JbpmHelper)
    Customer customer = Mock(Customer)
    Hsc hsc = Mock(Hsc)
    def setup() {
        codeXRef = Mock(CodeXRef)
        orxFusionServiceImpl.setRequiredSystemSettingsWebService(systemSettingsWebService)
        orxFusionServiceImpl.setHttpHeaders(httpHeaders)
        orxFusionServiceImpl.federatedConfigService = federatedConfigService
        orxFusionServiceImpl.systemSettingsWebService = systemSettingsWebService
        orxFusionServiceImpl.systemSettingsWebServiceModifier = systemSettingsWebServiceModifier
        orxFusionServiceImpl.memberDetailsMergeLogic = memberDetailsMergeLogic
        orxFusionServiceImpl.hscMemberCoverageHelper = hscMemberCoverageHelper
        orxFusionServiceImpl.hscAttribute = hscAttribute
        orxFusionServiceImpl.treatmentSupportiveCareProcedure = treatmentSupportiveCareProcedure
        orxFusionServiceImpl.codeXRef = codeXRef
        FeatureFlagUtility.featureFlagManager = featureFlagManager
        MockWebApplicationContext applicationContext = new MockWebApplicationContext()
        applicationContext.setBean(Environment.class.name, Mock(Environment))
        ApplicationContextHolder.setApplicationContext(applicationContext, true)
        orxFusionServiceImpl.hscServiceDetail = hscServiceDetail
        orxFusionServiceImpl.procedureBrand = procedureBrand
        orxFusionServiceImpl.procedureBenefit = procedureBenefit
        orxFusionServiceImpl.jbpmHelper = jbpmHelper
        orxFusionServiceImpl.customer = customer
        orxFusionServiceImpl.hsc = hsc
    }

    @Unroll
    def "callAndLogOrxFusionApi" (){
        given:
        long hscID = 5555L
        OptumFusionEngine optumFusionEngine = new OptumFusionEngine(enabled: true)
        HscProviderVO requestingProviderVO = new HscProviderVO(requestingProviderInd: true, providerNPI: '11')
        HscProviderVO servicingProviderVO = new HscProviderVO(servicingProviderInd: true, providerNPI: '11', specialtyType: 'AA')
        List<HscProviderVO> hscProviderVOList = [requestingProviderVO, servicingProviderVO]
        List<HscDiagnosisVO> hscDiagnosisVOList = [new HscDiagnosisVO(primaryInd: true)]
        List<HscAttributeVO> hscAttributeVOList = [new HscAttributeVO(hscAttributeType: SpclCareReferenceConstants.HSCATTRIBUTETYPE_INITIAL_TREATMENT_DATE, hscAttributeValue: "2022-02-02")]
        HscVO hscVO = new HscVO(hscID: hscID, customerID: 2, authTypeID: '1', hscDiagnosisVOs: hscDiagnosisVOList, hscAttributeVOs: hscAttributeVOList, hscProviderVOs: hscProviderVOList, hscServiceVOs: [new HscServiceVO(procCodeType: '6', procedureBenefitID: 1, hscServiceNonFacilityVO: new HscServiceNonFacilityVO(placeOfServiceCode: 11, procedureUnitCount: 11))])
        MemberCoverageVO memberMedicalCoverageVO = new MemberCoverageVO(coverageType: 'M', productCategoryType: '0', coverageEndDate: new UhgCalendar().addDay(1).getSQLDate(), coverageEffectiveDate: new UhgCalendar().addMonth(-1).getSQLDate())
        MemberCoverageVO memberPharmacyCoverageVO = new MemberCoverageVO(coverageType: 'RX', coverageEndDate: new UhgCalendar().addDay(1).getSQLDate(), coverageEffectiveDate: new UhgCalendar().addMonth(-1).getSQLDate())
        MemberVO memberVO = new MemberVO(state:'OH', memberCoverageVOs:[memberMedicalCoverageVO, memberPharmacyCoverageVO] )

        when:
        orxFusionServiceImpl.callAndLogOrxFusionApi(memberVO, hscVO)

        then:
        2 * FeatureFlagUtility.getManager()?.isActive(SpclCareFeatureFlagConstants.ENABLE_FUSION_INTEGRATION) >> true
        1 * FeatureFlagUtility.getManager()?.isActive(SpclCareFeatureFlagConstants.ENABLE_FUSION_CLIENT) >> flag
        _ * federatedConfigService.getIntegrationsByClientAndProduct(_,_) >> [new Integration(type: MultiPayerConstants.ORX_FUSION_ENGINE, value:integration)]
        _ * federatedConfigService?.getFusionEngineByClientAndProduct(_,_) >> optumFusionEngine
        _ * systemSettingsWebService.read(_) >> new SystemSettingsWebServiceVO(wsUrl: "https://myurl.uhc.com/test1")
        _ * systemSettingsWebServiceModifier.list(_) >> [new SystemSettingsWebServiceModifierVO()]
        _ * memberDetailsMergeLogic.getMemberIdentifierByType(_, _)
        _ * restTemplate.postForEntity(_,_,_) >> new ResponseEntity(_, OK)
        _ * codeXRef.getInboundAttributeToValue(_,_,_) >> "11"
        _ * procedureBenefit.readByProcedureBenefitID(_) >> new ProcedureBenefitVO(procedureBrandID: 1, medicalBenefitInd: true)
        _ * procedureBrand.read(_) >> new ProcedureBrandVO(procedureBrandID: 1, procedureCode: 'J8999', procedureBrandName: 'CIMZIA')

        where:
        testCase | flag  | integration
        0        | false | "enable"
        1        | true  | "disable"

    }

    @Unroll
    def "callAndLogOrxFusionApi when JCODE is null" (){
        given:
        long hscID = 5555L
        OptumFusionEngine optumFusionEngine = new OptumFusionEngine(enabled: true)
        HscProviderVO requestingProviderVO = new HscProviderVO(requestingProviderInd: true, providerNPI: '11')
        HscProviderVO servicingProviderVO = new HscProviderVO(servicingProviderInd: true, providerNPI: '11', specialtyType: 'AA')
        List<HscProviderVO> hscProviderVOList = [requestingProviderVO, servicingProviderVO]
        List<HscDiagnosisVO> hscDiagnosisVOList = [new HscDiagnosisVO(primaryInd: true)]
        List<HscAttributeVO> hscAttributeVOList = [new HscAttributeVO(hscAttributeType: SpclCareReferenceConstants.HSCATTRIBUTETYPE_INITIAL_TREATMENT_DATE, hscAttributeValue: "2022-02-02")]
        HscVO hscVO = new HscVO(hscID: hscID, customerID: 2, authTypeID: '1', hscDiagnosisVOs: hscDiagnosisVOList, hscAttributeVOs: hscAttributeVOList, hscProviderVOs: hscProviderVOList, hscServiceVOs: [new HscServiceVO(procCodeType: '6', procedureBenefitID: 1, hscServiceNonFacilityVO: new HscServiceNonFacilityVO(placeOfServiceCode: 11))])
        MemberCoverageVO memberMedicalCoverageVO = new MemberCoverageVO(coverageType: 'M', productCategoryType: '0', coverageEndDate: new UhgCalendar().addDay(1).getSQLDate(), coverageEffectiveDate: new UhgCalendar().addMonth(-1).getSQLDate())
        MemberCoverageVO memberPharmacyCoverageVO = new MemberCoverageVO(coverageType: 'RX', coverageEndDate: new UhgCalendar().addDay(1).getSQLDate(), coverageEffectiveDate: new UhgCalendar().addMonth(-1).getSQLDate())
        MemberVO memberVO = new MemberVO(state:'OH', memberCoverageVOs:[memberMedicalCoverageVO, memberPharmacyCoverageVO] )

        when:
        orxFusionServiceImpl.callAndLogOrxFusionApi(memberVO, hscVO)

        then:
        2 * FeatureFlagUtility.getManager()?.isActive(SpclCareFeatureFlagConstants.ENABLE_FUSION_INTEGRATION) >> true
        1 * FeatureFlagUtility.getManager()?.isActive(SpclCareFeatureFlagConstants.ENABLE_FUSION_CLIENT) >> flag
        _ * federatedConfigService.getIntegrationsByClientAndProduct(_,_) >> [new Integration(type: MultiPayerConstants.ORX_FUSION_ENGINE, value:integration)]
        _ * federatedConfigService?.getFusionEngineByClientAndProduct(_,_) >> optumFusionEngine
        _ * systemSettingsWebService.read(_) >> new SystemSettingsWebServiceVO(wsUrl: "https://myurl.uhc.com/test1")
        _ * systemSettingsWebServiceModifier.list(_) >> [new SystemSettingsWebServiceModifierVO()]
        _ * memberDetailsMergeLogic.getMemberIdentifierByType(_, _)
        _ * restTemplate.postForEntity(_,_,_) >> new ResponseEntity(_, OK)
        _ * codeXRef.getInboundAttributeToValue(_,_,_) >> "11"
        _ * procedureBenefit.readByProcedureBenefitID(_) >> new ProcedureBenefitVO(procedureBrandID: 1, medicalBenefitInd: true)
        _ * procedureBrand.read(_) >> new ProcedureBrandVO(procedureBrandID: 1, procedureCode: null, procedureBrandName: 'CIMZIA')

        where:
        testCase | flag  | integration
        0        | false | "enable"
        1        | true  | "disable"

    }

    def "callAndLogOrxFusionApi BrandName is null" (){
        given:
        long hscID = 5555L
        OptumFusionEngine optumFusionEngine = new OptumFusionEngine(enabled: true)
        HscProviderVO requestingProviderVO = new HscProviderVO(requestingProviderInd: true, providerNPI: '11')
        HscProviderVO servicingProviderVO = new HscProviderVO(servicingProviderInd: true, providerNPI: '11', specialtyType: 'AA')
        List<HscProviderVO> hscProviderVOList = [requestingProviderVO, servicingProviderVO]
        List<HscAttributeVO> hscAttributeVOList = [new HscAttributeVO(hscAttributeType: SpclCareReferenceConstants.HSCATTRIBUTETYPE_INITIAL_TREATMENT_DATE, hscAttributeValue: "2022-02-02")]
        HscVO hscVO = new HscVO(hscID: hscID, customerID: 2, authTypeID: '1',hscAttributeVOs: hscAttributeVOList, hscProviderVOs: hscProviderVOList, hscServiceVOs: [new HscServiceVO(procCodeType: '6', procedureBenefitID: 1, hscServiceNonFacilityVO: new HscServiceNonFacilityVO(placeOfServiceCode: 11))])
        MemberCoverageVO memberMedicalCoverageVO = new MemberCoverageVO(coverageType: 'M', productCategoryType: '0', coverageEndDate: new UhgCalendar().addDay(1).getSQLDate(), coverageEffectiveDate: new UhgCalendar().addMonth(-1).getSQLDate())
        MemberCoverageVO memberPharmacyCoverageVO = new MemberCoverageVO(coverageType: 'RX', coverageEndDate: new UhgCalendar().addDay(1).getSQLDate(), coverageEffectiveDate: new UhgCalendar().addMonth(-1).getSQLDate())
        MemberVO memberVO = new MemberVO(state:'OH', memberCoverageVOs:[memberMedicalCoverageVO, memberPharmacyCoverageVO] )

        when:
        orxFusionServiceImpl.callAndLogOrxFusionApi(memberVO, hscVO)

        then:
        2 * FeatureFlagUtility.getManager()?.isActive(SpclCareFeatureFlagConstants.ENABLE_FUSION_INTEGRATION) >> true
        1 * FeatureFlagUtility.getManager()?.isActive(SpclCareFeatureFlagConstants.ENABLE_FUSION_CLIENT) >> flag
        _ * federatedConfigService.getIntegrationsByClientAndProduct(_,_) >> [new Integration(type: MultiPayerConstants.ORX_FUSION_ENGINE, value:integration)]
        _ * federatedConfigService?.getFusionEngineByClientAndProduct(_,_) >> optumFusionEngine
        _ * systemSettingsWebService.read(_) >> new SystemSettingsWebServiceVO(wsUrl: "https://myurl.uhc.com/test1")
        _ * systemSettingsWebServiceModifier.list(_) >> [new SystemSettingsWebServiceModifierVO()]
        _ * memberDetailsMergeLogic.getMemberIdentifierByType(_, _)
        _ * restTemplate.postForEntity(_,_,_) >> new ResponseEntity<>(OK)
        _ * codeXRef.getInboundAttributeToValue(_,_,_) >> "11"
        _ * procedureBenefit.readByProcedureBenefitID(_) >> new ProcedureBenefitVO(procedureBrandID: 1, medicalBenefitInd: true)
        _ * procedureBrand.read(_) >> new ProcedureBrandVO(procedureBrandID: 1, procedureCode: 'J8999', procedureGenericName: 'CIMZIA')

        where:
        testCase | flag  | integration
        0        | false | "enable"
        1        | true  | "disable"

    }

    @Unroll
    def "test saveFusionClient"() {
        given:
        long hscID = 5555L
        HscVO hscVO = new HscVO(hscID: hscID, customerID: 2, authTypeID: '1')
        MemberCoverageVO memberMedicalCoverageVO = new MemberCoverageVO(coverageType: 'M', productCategoryType: '0', coverageEndDate: new UhgCalendar().addDay(1).getSQLDate(), coverageEffectiveDate: new UhgCalendar().addMonth(-1).getSQLDate())
        MemberCoverageVO memberPharmacyCoverageVO = new MemberCoverageVO(coverageType: 'RX', coverageEndDate: new UhgCalendar().addDay(1).getSQLDate(), coverageEffectiveDate: new UhgCalendar().addMonth(-1).getSQLDate())
        MemberVO memberVO = new MemberVO(state:'OH', memberCoverageVOs:[memberMedicalCoverageVO, memberPharmacyCoverageVO] )

        when:
        orxFusionServiceImpl.saveFusionClient(hscVO, memberVO)

        then:
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_FUSION_CLIENT) >> true
        1 * hscAttribute.save(_)
        _ * hscMemberCoverageHelper.deriveMostEffectiveCoverage(_) >> memberMedicalCoverageVO
        _ * federatedConfigService?.getFusionEngineByClientAndProduct(2,'1') >> new OptumFusionEngine(enabled: true, supportedPopulations: [new Population( productCategoryType: '0', states: '_*')])
        0 * _

    }

    @Unroll
    def "test checkFusionEngine"() {
        given:
        long hscID = 5555L
        HscVO hscVO = new HscVO(hscID: hscID, customerID: 2, authTypeID: '1')
        MemberCoverageVO memberMedicalCoverageVO = new MemberCoverageVO(coverageType: 'M', productCategoryType: '0', coverageEndDate: new UhgCalendar().addDay(1).getSQLDate(), coverageEffectiveDate: new UhgCalendar().addMonth(-1).getSQLDate())
        MemberCoverageVO memberPharmacyCoverageVO = new MemberCoverageVO(coverageType: 'RX', coverageEndDate: new UhgCalendar().addDay(1).getSQLDate(), coverageEffectiveDate: new UhgCalendar().addMonth(-1).getSQLDate())
        MemberVO memberVO = new MemberVO(state:'OH', memberCoverageVOs:[memberMedicalCoverageVO, memberPharmacyCoverageVO] )

        when:
        boolean response = orxFusionServiceImpl.checkFusionEngine(hscVO, memberVO)

        then:
        _ * hscMemberCoverageHelper.deriveMostEffectiveCoverage(_) >> memberMedicalCoverageVO
        _ * federatedConfigService?.getFusionEngineByClientAndProduct(2,'1') >> fusionEngine
        0 * _

        and:
        response == result

        where:
        testCase | result | fusionEngine
        0        | true   | new OptumFusionEngine(enabled: true)
        1        | true   | new OptumFusionEngine(enabled: true, supportedPopulations: [new Population( productCategoryType: '0', states: '_*')])
        2        | true   | new OptumFusionEngine(enabled: true, supportedPopulations: [new Population( productCategoryType: '0', states: 'OH,SC,AL')])
        3        | false  | new OptumFusionEngine(enabled: false)
        4        | false  | new OptumFusionEngine(enabled: true, supportedPopulations: [new Population( productCategoryType: '1', states: '_*')])
        5        | false  | new OptumFusionEngine(enabled: true, supportedPopulations: [new Population( productCategoryType: '0', states: 'SC,AL')])

    }


    @Unroll
    def "callFusionEngine" (){
        given:
        long hscID = 5555L
        TreatmentSupportiveCareProcedureVO treatmentSupportiveCareProcedureVO = new TreatmentSupportiveCareProcedureVO(procedureCode: 'J9419')
        HscProviderVO requestingProviderVO = new HscProviderVO(requestingProviderInd: true, providerNPI: '11')
        HscProviderVO servicingProviderVO = new HscProviderVO(servicingProviderInd: true, providerNPI: '11', specialtyType: 'AA')
        List<HscProviderVO> hscProviderVOList = [requestingProviderVO, servicingProviderVO]
        HscVO hscVO = new HscVO(hscID: hscID, customerID: 2, authTypeID: authType, hscAttributeVOs: hscAttributeVOs, hscProviderVOs: hscProviderVOList)
        MemberCoverageVO memberMedicalCoverageVO = new MemberCoverageVO(coverageType: 'M', productCategoryType: '0', coverageEndDate: new UhgCalendar().addDay(1).getSQLDate(), coverageEffectiveDate: new UhgCalendar().addMonth(-1).getSQLDate())
        MemberCoverageVO memberPharmacyCoverageVO = new MemberCoverageVO(coverageType: 'RX', coverageEndDate: new UhgCalendar().addDay(1).getSQLDate(), coverageEffectiveDate: new UhgCalendar().addMonth(-1).getSQLDate())
        MemberVO memberVO = new MemberVO(state:'OH', memberCoverageVOs:[memberMedicalCoverageVO, memberPharmacyCoverageVO] )

        when:
        orxFusionServiceImpl.callFusionEngine(hscVO, memberVO)

        then:
        1 * FeatureFlagUtility.getManager()?.isActive(SpclCareFeatureFlagConstants.ENABLE_FUSION_CLIENT) >> flag
        _ * treatmentSupportiveCareProcedure.read(_) >> treatmentSupportiveCareProcedureVO
        _ * treatmentSupportiveCareProcedure.listBySupportiveCareType(_,_, _ as boolean,_) >> [treatmentSupportiveCareProcedureVO]
        _ * systemSettingsWebService.read(_) >> new SystemSettingsWebServiceVO(wsUrl: "https://myurl.uhc.com/test1")
        _ * systemSettingsWebServiceModifier.list(_) >> [new SystemSettingsWebServiceModifierVO()]
        _ * memberDetailsMergeLogic.getMemberIdentifierByType(_, _)
        _ * restTemplate.postForEntity(_,_,_) >> new ResponseEntity<>(OK)
        _ * codeXRef.getInboundAttributeToValue(_,_,_) >> "11"

        where:
        testCase | flag  | authType | hscAttributeVOs
        0        | true  | '2'      | [new HscAttributeVO( hscAttributeType: SpclCareReferenceConstants.HSCATTRIBUTETYPE_AUTHORIZATION_START_DATE, hscAttributeValue: '2021-01-01'), new HscAttributeVO( hscAttributeType: SpclCareReferenceConstants.HSCATTRIBUTETYPE_SUPPORTIVE_CARE_PROCEDURE_ID, hscAttributeValue: '123'), new HscAttributeVO(hscAttributeType: SpclCareReferenceConstants.HSCATTRIBUTETYPE_PLACE_OF_SERVICE, hscAttributeValue: "11")]
        1        | true  | '2'      | [new HscAttributeVO( hscAttributeType: SpclCareReferenceConstants.HSCATTRIBUTETYPE_AUTHORIZATION_START_DATE, hscAttributeValue: '2021-01-01'), new HscAttributeVO( hscAttributeType: SpclCareReferenceConstants.HSCATTRIBUTETYPE_SUPPORTIVE_TYPE, hscAttributeValue: '1')]
        2        | true  | '4'      | [new HscAttributeVO( hscAttributeType: SpclCareReferenceConstants.HSCATTRIBUTETYPE_AUTHORIZATION_START_DATE, hscAttributeValue: '2021-01-01'), new HscAttributeVO( hscAttributeType: SpclCareReferenceConstants.HSCATTRIBUTETYPE_SUPPORTIVE_TYPE, hscAttributeValue: '1')]
        3        | true  | '1'      | [new HscAttributeVO( hscAttributeType: SpclCareReferenceConstants.HSCATTRIBUTETYPE_AUTHORIZATION_START_DATE, hscAttributeValue: '2021-01-01'), new HscAttributeVO( hscAttributeType: SpclCareReferenceConstants.HSCATTRIBUTETYPE_SUPPORTIVE_TYPE, hscAttributeValue: '1')]
    }

    @Unroll
    def "osfPlaceOfServiceCode" () {
        when:
        int osfPlaceOfServiceCode = orxFusionServiceImpl.osfPlaceOfServiceCode(placeOfServiceCode)

        then:
        _ * codeXRef.getInboundAttributeToValue("00", "osfPlaceOfServiceCode", "11") >> "11"
        _ * codeXRef.getInboundAttributeToValue("00", "osfPlaceOfServiceCode", "33") >> "12"
        _ * codeXRef.getInboundAttributeToValue("00", "osfPlaceOfServiceCode", "62") >> "22"

        and:
        osfPlaceOfServiceCode == result

        where:
        testCase  | placeOfServiceCode | result
        1         | "11"               | 11
        2         | "33"               | 12
        3         | "62"               | 22

    }

    @Unroll
    def "callOrxFusionAPI" (){
        given:
        HscVO hscVO = new HscVO(hscID: 5555L, customerID: 2, authTypeID: authTypeId ,hscDiagnosisVOs: [new HscDiagnosisVO(diagnosisCode: 'C00.0')], hscServiceVOs: [hscServiceVO])
        MemberCoverageVO memberMedicalCoverageVO = new MemberCoverageVO(coverageType: 'M', productCategoryType: '0', policyNumber: 'MBMBM', coverageEndDate: new UhgCalendar().addDay(1).getSQLDate(), coverageEffectiveDate: new UhgCalendar().addMonth(-1).getSQLDate())
        MemberCoverageVO memberPharmacyCoverageVO = new MemberCoverageVO(coverageType: 'RX', carrierName: 'TESTMBM', alternatePolicyNumber: 'TESTMBM', policyNumber: 'TESTMBM', coverageEndDate: new UhgCalendar().addDay(1).getSQLDate(), coverageEffectiveDate: new UhgCalendar().addMonth(-1).getSQLDate())
        MemberVO memberVO = new MemberVO(memberID: 23L, lastName: 'FOUR', firstName: 'MBM', customerID: 2, birthDate: new Date(1, 1, 1), memberCoverageVOs:[memberMedicalCoverageVO, memberPharmacyCoverageVO] )

        when:
        orxFusionServiceImpl.callOrxFusionAPI(hscVO, memberVO, hscServiceVO)

        then:
        _ * systemSettingsWebService.read(RestConstants.FUSION_V2_API_URL) >> new SystemSettingsWebServiceVO(wsUrl: '', clientConnectTimeout: 20000, clientReceiveTimeout: 20000)
        _ * systemSettingsWebService.read(RestConstants.FUSION_V2_TOKEN_URL) >> new SystemSettingsWebServiceVO(wsUrl: '', clientConnectTimeout: 20000, clientReceiveTimeout: 20000)
        _ * restTemplate.postForEntity(_,_,_) >> new ResponseEntity(_, OK)
        _ * codeXRef.getInboundAttributeToValue("00", "osfPlaceOfServiceCode", "11") >> "11"
        _ * codeXRef.getInboundAttributeToValue("00", "osfPlaceOfServiceCode", "33") >> "12"
        _ * orxFusionServiceImpl.makeOrxFusionCall()
        _ * procedureBenefit.readByProcedureBenefitID(1) >> new ProcedureBenefitVO(procedureBrandID: 1)
        _ * procedureBrand.read(1) >> new ProcedureBrandVO(procedureCode: "J1217", procedureBrandName: "John&Cena")
        _ * procedureBrand.listByProcedureCode("J1217") >> [new ProcedureBrandVO(procedureCode: "J1217", procedureBrandName: "CAPECITABINE", procedureGenericName: "ORAL", customerID: 2)]
        where:
        testCase  | authTypeId    | hscServiceVO
        0         |  '2'          | new HscServiceVO(hscID: 5555L ,serviceSeqNum: 1, procCodeType: '4', procedureCode: 'J1217', hscServiceNonFacilityVO: new HscServiceNonFacilityVO(placeOfServiceCode: '33', dmeServiceDescriptionText : 'CAPECITABINE ORAL 500 MG', procUnitDesc: '1 mg/m2'))
        1         |  '4'          | new HscServiceVO(procCodeType: '4', procedureCode: '12345672651', hscServiceNonFacilityVO: new HscServiceNonFacilityVO(placeOfServiceCode: '11', dmeServiceDescriptionText : 'Test 123 mg', procUnitDesc: '1.9 mg/m2'), procedureBenefitID: 1)
    }

    @Unroll
    def "mapOrxFusionRequest for Cancer Supportive when SupportiveCareID exists" (){
        given:
        HscAttributeVO hscAttributeVO = new HscAttributeVO(hscAttributeType: SpclCareReferenceConstants.HSCATTRIBUTETYPE_SUPPORTIVE_CARE_PROCEDURE_ID, hscAttributeValue: "81")
        HscVO hscVO = new HscVO(hscID: 5555L, customerID: 2, authTypeID: "2" ,hscAttributeVOs: [hscAttributeVO], hscDiagnosisVOs: [new HscDiagnosisVO(diagnosisCode: 'C00.0')], hscServiceVOs: [hscServiceVO])
        MemberCoverageVO memberMedicalCoverageVO = new MemberCoverageVO(coverageType: 'M', productCategoryType: '0', policyNumber: 'MBMBM', coverageEndDate: new UhgCalendar().addDay(1).getSQLDate(), coverageEffectiveDate: new UhgCalendar().addMonth(-1).getSQLDate())
        MemberCoverageVO memberPharmacyCoverageVO = new MemberCoverageVO(coverageType: 'RX', carrierName: 'TESTMBM', alternatePolicyNumber: 'TESTMBM', policyNumber: 'TESTMBM', coverageEndDate: new UhgCalendar().addDay(1).getSQLDate(), coverageEffectiveDate: new UhgCalendar().addMonth(-1).getSQLDate())
        MemberVO memberVO = new MemberVO(memberID: 23L, lastName: 'FOUR', firstName: 'MBM', customerID: 2, birthDate: new Date(1, 1, 1), memberCoverageVOs:[memberMedicalCoverageVO, memberPharmacyCoverageVO] )

        when:
        OrxFusionRequestDO orxFusionRequestDO = orxFusionServiceImpl.mapOrxFusionRequest(memberVO, hscVO, hscServiceVO)

        then:
        1 * hscServiceDetail.read(5555L, 1) >> new HscServiceDetailVO(procCodeType: "4", procedureCode: "Q5110", procedureBrandName: "Filgrastim-aafi (Nivestym)")
        1 * treatmentSupportiveCareProcedure.read(81) >> new TreatmentSupportiveCareProcedureVO(medicalBenefitInd: true, pharmacyBenefitInd: true)
        1 * procedureBrand.listByProcedureCode("Q5110") >> [new ProcedureBrandVO(procedureCode: "Q5110", procedureBrandName: "Nivestym", procedureGenericName: "Filgrastim-aafi", customerID: 2)]
        1 * codeXRef.getInboundAttributeToValue(_,_,_) >> "11"

        and:
        orxFusionRequestDO.jCode == "Q5110"
        orxFusionRequestDO.drugName == "Nivestym"
        orxFusionRequestDO.medicationCoverage == "B"

        where:
        testCase  | hscServiceVO
        0         | new HscServiceVO(hscID: 5555L ,serviceSeqNum: 1, procCodeType: '6', procedureCode: '00069029301', hscServiceNonFacilityVO: new HscServiceNonFacilityVO(placeOfServiceCode: '21', dmeServiceDescriptionText : 'NIVESTYM SOLN 300.0 MCG/ML'))
    }

    @Unroll
    def "mapOrxFusionRequest for Cancer Supportive when SupportiveCareDrugCategory exists" (){
        given:
        HscAttributeVO hscAttributeVO = new HscAttributeVO(hscAttributeType: SpclCareReferenceConstants.HSCATTRIBUTETYPE_SUPPORTIVE_TYPE, hscAttributeValue: "GF")
        HscVO hscVO = new HscVO(hscID: 5555L, customerID: 2, authTypeID: "2" ,hscAttributeVOs: [hscAttributeVO], hscDiagnosisVOs: [new HscDiagnosisVO(diagnosisCode: 'C00.0')], hscServiceVOs: [hscServiceVO])
        MemberCoverageVO memberMedicalCoverageVO = new MemberCoverageVO(coverageType: 'M', productCategoryType: '0', policyNumber: 'MBMBM', coverageEndDate: new UhgCalendar().addDay(1).getSQLDate(), coverageEffectiveDate: new UhgCalendar().addMonth(-1).getSQLDate())
        MemberCoverageVO memberPharmacyCoverageVO = new MemberCoverageVO(coverageType: 'RX', carrierName: 'TESTMBM', alternatePolicyNumber: 'TESTMBM', policyNumber: 'TESTMBM', coverageEndDate: new UhgCalendar().addDay(1).getSQLDate(), coverageEffectiveDate: new UhgCalendar().addMonth(-1).getSQLDate())
        MemberVO memberVO = new MemberVO(memberID: 23L, lastName: 'FOUR', firstName: 'MBM', customerID: 2, birthDate: new Date(1, 1, 1), memberCoverageVOs:[memberMedicalCoverageVO, memberPharmacyCoverageVO] )

        when:
        OrxFusionRequestDO orxFusionRequestDO = orxFusionServiceImpl.mapOrxFusionRequest(memberVO, hscVO, hscServiceVO)

        then:
        1 * hscServiceDetail.read(5555L, 1) >> new HscServiceDetailVO(procCodeType: "4", procedureCode: "Q5110", procedureBrandName: "Filgrastim-aafi (Nivestym)")
        1 * treatmentSupportiveCareProcedure.listBySupportiveCareType(5555L, "GF", true, 2) >> [new TreatmentSupportiveCareProcedureVO(medicalBenefitInd: true, pharmacyBenefitInd: true)]
        1 * procedureBrand.listByProcedureCode("Q5110") >> [new ProcedureBrandVO(procedureCode: "Q5110", procedureBrandName: "Nivestym", procedureGenericName: "Filgrastim-aafi", customerID: 2)]
        1 * codeXRef.getInboundAttributeToValue(_,_,_) >> "11"

        and:
        orxFusionRequestDO.jCode == "Q5110"
        orxFusionRequestDO.drugName == "Nivestym"
        orxFusionRequestDO.medicationCoverage == "B"

        where:
        testCase  | hscServiceVO
        0         | new HscServiceVO(hscID: 5555L ,serviceSeqNum: 1, procCodeType: '6', procedureCode: '00069029301', hscServiceNonFacilityVO: new HscServiceNonFacilityVO(placeOfServiceCode: '21', dmeServiceDescriptionText : 'NIVESTYM SOLN 300.0 MCG/ML'))
    }

    @Unroll
    def "getMedicationCoverage" () {

        given:
        ProcedureBenefitVO procedureBenefitVO = new ProcedureBenefitVO(medicalBenefitInd: medicalBenefitInd, pharmacyBenefitInd: pharmacyBenefitInd)


        when:
        String medicationCoverage = orxFusionServiceImpl.getMedicationCoverage(procedureBenefitVO)

        then:
        0 * (_)

        and:
        medicationCoverage == result

        where:
        testcase   |  medicalBenefitInd  |  pharmacyBenefitInd   | result
        0          |  0                  |  0                    |"M"
        1          |  1                  |  1                    |"B"
        2          |  1                  |  0                    |"M"
        3          |  0                  |  1                    |"P"
    }

    @Unroll
    def "Test Scenario: getWeight when weight is in Kg"() {

        given:
        HscVO hscVO = new HscVO(hscMeasurementVOs: [new HscMeasurementVO(measurementType: measurementType, measurementValueDescription: measurementValueDescription, unitOfMeasureType: unitOfMeasurementType)])

        when:
        Double getWeight = orxFusionServiceImpl.getWeightInKG(hscVO)

        then:
        0 * (_)

        and:
        getWeight == result

        where:
        testcase | measurementType | unitOfMeasurementType | measurementValueDescription | result
        0        | "WGT"           | "KG"                  | "32"                        | 32

    }

    @Unroll
    def "Test Scenario: getWeight when weight is in pounds"() {

        given:
        HscVO hscVO = new HscVO(hscMeasurementVOs: [new HscMeasurementVO(measurementType: measurementType, measurementValueDescription: measurementValueDescription, unitOfMeasureType: unitOfMeasurementType)])

        when:
        Double getWeight = orxFusionServiceImpl.getWeightInKG(hscVO)

        then:
        0 * (_)

        and:
        getWeight == result

        where:
        testcase | measurementType | unitOfMeasurementType | measurementValueDescription | result
        0        | "WGT"           | "LBS"                 | "123"                       | 55.791816
        1        | "WGT"           | "LBS"                 | "212"                       | 96.161504

    }
    @Unroll
    def "Test Scenario: getWeight when weight is null"() {

        given:
        HscVO hscVO = new HscVO(hscMeasurementVOs: [new HscMeasurementVO(measurementType: measurementType, measurementValueDescription: measurementValueDescription, unitOfMeasureType: unitOfMeasurementType)])

        when:
        Double getWeight = orxFusionServiceImpl.getWeightInKG(hscVO)

        then:
        0 * (_)

        and:
        getWeight == result

        where:
        testcase | measurementType | unitOfMeasurementType | measurementValueDescription | result
        0        | "WGT"           | "LBS"                 | null                        | 0

    }

    @Unroll
    def "Test Scenario for Merging OrxResponseList having one list" (){
        given:
        List<OrxFusionResponse> orxFusionResponseList = new ArrayList<OrxFusionResponse>()
        OrxFusionResponse orxFusionResponse1 = new OrxFusionResponse(txnData: new TxnData(scenarioClaims: [ScenarioClaims1 ,ScenarioClaims2]) )
        orxFusionResponseList.add(orxFusionResponse1)
        when:
        OrxFusionResponse orxFusionResponse = orxFusionServiceImpl.mergeOrxFusionResponseList(orxFusionResponseList)
        then:
        0 * (_)
        and:
        orxFusionResponse?.txnData?.scenarioClaims?.size() == result
        where:
        testcase | ScenarioClaims1                                                  | ScenarioClaims2                                        | result
        0        | new ScenarioClaims(osfRank: 1,scenarioDrug: "J0180")             | new ScenarioClaims(osfRank: 2,scenarioDrug: "J0180")   | 2
        1        | null                                                             | new ScenarioClaims(osfRank: 2,scenarioDrug: "J0180")   | 2
        2        | null                                                             | null                                                   | 2
        3        | new ScenarioClaims()                                             | new ScenarioClaims(osfRank: 2,scenarioDrug: "J0180")   | 2
    }

    @Unroll
    def "Test Scenario for Merging OrxResponseList having multiple drugs" (){
        given:
        List<OrxFusionResponse> orxFusionResponseList = new ArrayList<OrxFusionResponse>()
        OrxFusionResponse orxFusionResponse1 = new OrxFusionResponse(txnData: new TxnData(scenarioClaims: [ScenarioClaims1 ,ScenarioClaims2]) )
        OrxFusionResponse orxFusionResponse2 = new OrxFusionResponse(txnData:  new TxnData(scenarioClaims: [ScenarioClaims3 ,ScenarioClaims4]))
        orxFusionResponseList.add(orxFusionResponse1)
        orxFusionResponseList.add(orxFusionResponse2)
        when:
        OrxFusionResponse orxFusionResponse = orxFusionServiceImpl.mergeOrxFusionResponseList(orxFusionResponseList)
        then:
        0 * (_)
        and:
        orxFusionResponse?.txnData?.scenarioClaims?.size() == result
        where:
        testcase | ScenarioClaims1                                                  | ScenarioClaims2                                        |ScenarioClaims3                                           |  ScenarioClaims4                                        | result
        0        | new ScenarioClaims(osfRank: 1,scenarioDrug: "J0180")             | new ScenarioClaims(osfRank: 2,scenarioDrug: "J0180")   | new ScenarioClaims(osfRank: 3,scenarioDrug: "J0181")     | new ScenarioClaims(osfRank: 4,scenarioDrug: "J0181")    | 4
        1        | new ScenarioClaims(osfRank: 1,scenarioDrug: "J0180")             | new ScenarioClaims(osfRank: 2,scenarioDrug: "J0180")   | null                                                     | null                                                    | 4
        2        | null                                                             | null                                                   | new ScenarioClaims(osfRank: 3,scenarioDrug: "J0181")     | new ScenarioClaims(osfRank: 4,scenarioDrug: "J0181")    | 4
        2        | null                                                             | null                                                   | null                                                     | null                                                    | 4

    }

    @Unroll
    def "Test Scenario for Merging OrxResponseList-> null OrxFusionResponse case" (){
        given:
        List<OrxFusionResponse> orxFusionResponseList = new ArrayList<OrxFusionResponse>()
        OrxFusionResponse orxFusionResponse1 = new OrxFusionResponse()
        orxFusionResponseList.add(orxFusionResponse1)
        when:
        OrxFusionResponse orxFusionResponse = orxFusionServiceImpl.mergeOrxFusionResponseList(orxFusionResponseList)
        then:
        0 * (_)
        and:
        orxFusionResponse?.txnData?.scenarioClaims?.size() == result
        where:
        testcase   | result
        0          | null
    }

    @Unroll
    def "Test Scenario for Merging OrxResponseList-> empty Scenario claims case" (){
        given:
        List<OrxFusionResponse> orxFusionResponseList = new ArrayList<OrxFusionResponse>()
        OrxFusionResponse orxFusionResponse1 = new OrxFusionResponse(txnData: new TxnData(scenarioClaims:[scenarioClims1]))
        orxFusionResponseList.add(orxFusionResponse1)
        when:
        OrxFusionResponse orxFusionResponse = orxFusionServiceImpl.mergeOrxFusionResponseList(orxFusionResponseList)
        then:
        0 * (_)
        and:
        orxFusionResponse?.txnData?.scenarioClaims?.size() == result
        where:
        testcase  | scenarioClims1                       | result
        0         |   new ScenarioClaims()               | 1

    }


    @Unroll
    def "Test checkFusionRule"() {
        given:
        long hscID = 123L
        CustomerVO customerVO = new CustomerVO(customerID: 2, organizationID:2)
        HscVO hscVO = new HscVO(hscID: hscID, customerID: 2, authTypeID: '4', hscAttributeVOs: [])
        MemberVO memberVO = new MemberVO(state: 'MN')
        GenerateHscDO generateHscDO = new GenerateHscDO(procedureCode: 'J123', procedureBrandName: 'test&reg;')

        when:
        boolean response = orxFusionServiceImpl.checkFusionRule(hscID, memberVO, generateHscDO)
        and:
        response == result
        then:
        _ * jbpmHelper?.callRules(_) >> objectList
        _ * customer.read(hscVO.customerID) >> customerVO
        _ * hsc.readHscAndMemberCoverages(hscID) >> hscVO
        where:
        testCase | result | objectList
        0        | true   | [new StepperSignal(ruleParameters: new RuleParameters(parameters: Collections.singletonMap('preferredBenefit', '1')))]
        1        | false  | []
    }

    @Unroll
    def "test checkFusionEngineForSpecAuth"() {
        given:
        long hscID = 444L
        HscVO hscVO = new HscVO(hscID: hscID, customerID: 2, authTypeID: '4', hscAttributeVOs: [])
        CustomerVO customerVO = new CustomerVO(customerID: 2, organizationID:2)
        GenerateHscDO generateHscDO = new GenerateHscDO(procedureCode: 'J123', procedureBrandName: 'test&reg;')
        MemberCoverageVO memberMedicalCoverageVO = new MemberCoverageVO(coverageType: 'M', productCategoryType: '0', coverageEndDate: new UhgCalendar().addDay(1).getSQLDate(), coverageEffectiveDate: new UhgCalendar().addMonth(-1).getSQLDate())
        MemberCoverageVO memberPharmacyCoverageVO = new MemberCoverageVO(coverageType: 'RX', coverageEndDate: new UhgCalendar().addDay(1).getSQLDate(), coverageEffectiveDate: new UhgCalendar().addMonth(-1).getSQLDate())
        MemberVO memberVO = new MemberVO(state:'OH', memberCoverageVOs:[memberMedicalCoverageVO, memberPharmacyCoverageVO] )

        StepperSignal stepperSignal = new StepperSignal()
        stepperSignal.setRuleParameters(new RuleParameters())
        stepperSignal.getRuleParameters().setParameter("preferredBenefit", '1')
        List<Object> objectList = new Arrays().asList(stepperSignal)

        when:
        boolean response = orxFusionServiceImpl.checkFusionEngine(hscVO, memberVO, generateHscDO)

        then:
        _ * hscMemberCoverageHelper.deriveMostEffectiveCoverage(_) >> memberMedicalCoverageVO
        _ * federatedConfigService?.getFusionEngineByClientAndProduct(2,'4') >> fusionEngine
        _ * hsc.readHscAndMemberCoverages(hscID) >> hscVO
        _ * jbpmHelper?.callRules(_) >> objectList
        _ * customer.read(hscVO.customerID) >> customerVO

        and:
        response == result

        where:
        testCase | result | fusionEngine
        0        | true   | new OptumFusionEngine(enabled: true)
        1        | true   | new OptumFusionEngine(enabled: true, supportedPopulations: [new Population( productCategoryType: '0', states: '_*')])
        2        | true   | new OptumFusionEngine(enabled: true, supportedPopulations: [new Population( productCategoryType: '0', states: 'OH,SC,AL')])
        3        | false  | new OptumFusionEngine(enabled: false)
        4        | false  | new OptumFusionEngine(enabled: true, supportedPopulations: [new Population( productCategoryType: '1', states: '_*')])
        5        | false  | new OptumFusionEngine(enabled: true, supportedPopulations: [new Population( productCategoryType: '0', states: 'SC,AL')])

    }
}

