package com.optum.app.shared.microservice.utils


import com.optum.app.shared.spclcare.SpecialtyCareReadLogicSpecification
import spock.lang.Unroll

class EdiUtilitiesSpec extends SpecialtyCareReadLogicSpecification {

    private static final String requestText = "ISA*00*          *00*          *33*87726          *ZZ*B00099999853   *180409*0822*>*00405*000000001*0*T*:~GS*PW*87726*BPR21GRACEZI*20180409*0822*1*X*004050X109~ST*274*1   *004050X109~BHT*0027*11*001*20180409*08224035~DTM*507*20180409~PER*BJ**TE*7325723952~HL*1**20*1~NM1*ACV*2*UNITEDHEALTHCARE*****NI*87726~HL*2*1*21*1~NM1*40*2*MIDTOWN FAMILY CLINIC INC~"+ "HL*1*2*19*1~NM1*1P*1*Bunyan*Paul****SV*123456789~DMG***M~DTP*092*D8*2018-06-01~DTP*093*D8*9999-12-31~LQ*ZZ*~TPB*3G*General Practice*addressType=S*addressSequenceNumber=15~REF*TJ*111222333~REF*XX*54321~HL*2*1*N*0~NM1*77*2~PER*AJ**TE*123-456-7890~NX1*77~N3*123 4th Street S*~N4*Minneapolis*MN*55440~"

    @Unroll
    def "test parseValue"() {
        when:
        String result = EdiUtilities.parseValue(requestText, startPattern, endChar)

        then:
        0 *_._

        result == expectedResult

        where:
        startPattern | endChar | expectedResult
        "~REF*TJ*"   | "~"     | "111222333"
        "NM1*1P*1*"  | "*"     | "Bunyan"
        "~N4*"       | "*"     | "Minneapolis"
    }

}
