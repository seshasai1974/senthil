package com.optum.app.shared.epa.controller

import com.optum.app.ocm.controller.support.CommonResponse
import com.optum.app.shared.epa.businesslogic.ProcedureBenefit
import com.optum.app.shared.epa.data.ProcedureBenefitVO
import com.optum.app.shared.spclcare.SpecialtyCareReadLogicSpecification

class ProcedureBenefitControllerSpec extends SpecialtyCareReadLogicSpecification {

    ProcedureBenefitController procedureBenefitController = new ProcedureBenefitController();
    ProcedureBenefit procedureBenefit = Mock(ProcedureBenefit)

    def setup(){
        procedureBenefitController.procedureBenefit = procedureBenefit
    }

    def "Test getProcedureBenefits"(){
        given:
        Integer procedureBrandID = 147
        System.setProperty('APPROVAL_TYPE', customer as String)
        List<ProcedureBenefitVO> procedureBenefitVOList = [new ProcedureBenefitVO()]

        when:
        CommonResponse commonResponse = procedureBenefitController.getProcedureBenefits(procedureBrandID)

        then:
        1 * procedureBenefit.listByProcedureBrandID(procedureBrandID, customer) >> procedureBenefitVOList
        0 * _

        and:
        commonResponse.getEmbedded().get('_embedded') == procedureBenefitVOList

        where:
        customer << [1, 2]
    }
}
