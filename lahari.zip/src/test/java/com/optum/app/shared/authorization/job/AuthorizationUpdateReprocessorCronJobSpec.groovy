package com.optum.app.shared.authorization.job

import com.optum.app.shared.authorization.job.AuthorizationUpdateReprocessorCronJob
import spock.lang.Specification
import spock.lang.Unroll


/**
 * Created by jboyd34 on 10/8/18.
 */
class AuthorizationUpdateReprocessorCronJobSpec extends Specification {

    @Unroll
    def "test AuthReprocessorCronJob"() {
       given:
       AuthorizationUpdateReprocessorCronJob authorizationReprocessorCronJob = new AuthorizationUpdateReprocessorCronJob()

       when:
       authorizationReprocessorCronJob != null
        
       then:
        authorizationReprocessorCronJob.getCronPattern() == "15,45 * * * *"
        authorizationReprocessorCronJob.getSystemJobID() == "RUA"
        authorizationReprocessorCronJob.getDescription() == "Reprocess Update Authorization Failures"
        authorizationReprocessorCronJob.getTask() != null

    }

}
