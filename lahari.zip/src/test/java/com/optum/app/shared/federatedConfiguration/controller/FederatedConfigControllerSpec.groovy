package com.optum.app.shared.federatedConfiguration.controller

import com.optum.app.common.hsr.data.HscVO
import com.optum.app.ocm.controller.support.CommonResponse
import com.optum.app.shared.constants.MultiPayerConstants
import com.optum.app.shared.constants.SpclCareConstants
import com.optum.app.shared.constants.SpclCareReferenceConstants
import com.optum.app.shared.federatedConfiguration.businesslogic.FederatedConfigService
import com.optum.app.shared.federatedConfiguration.data.*
import spock.lang.Specification

class FederatedConfigControllerSpec extends Specification{

    FederatedConfigController federatedConfigController = new FederatedConfigController()
    FederatedConfigService federatedConfigService = Mock(FederatedConfigService)

    def setup() {
        federatedConfigController.federatedConfigService=federatedConfigService
    }

    def "getAllConfigsByClientAndProduct"() {
        given:

        when:
        CommonResponse commonResponse = federatedConfigController.getAllConfigsByClientAndProduct(c,a)

        then:
        1 * federatedConfigService.getAllByClientAndProduct(c,a) >> product
        0 * _

        and:
        commonResponse.getEmbedded().get('_embedded') == product

        where:
        testcase| c    | a      |    product
        0       |   1  | '1'    | new Product(type: '1')
        1       |   2  | '2'    | new Product(type: '2')


    }

    def "getMemberBenefitsByClientAndProduct"() {
        given:

        when:
        CommonResponse commonResponse = federatedConfigController.getMemberBenefitsByClientAndProduct(c,a)

        then:
        1 * federatedConfigService.getMemberBenefitsByClientAndProduct(c,a) >> member
        0 * _

        and:
        commonResponse.getEmbedded().get('_embedded') == member

        where:
        testcase| c    | a      |    member
        0       |   1  | '1'    | [new MemberBenefitType(type: 'Medical')]


    }

    def "getProviderTypesByClientAndProduct"() {
        given:

        when:
        CommonResponse commonResponse = federatedConfigController.getProviderTypesByClientAndProduct(c,a)

        then:
        1 * federatedConfigService.getProviderTypesByClientAndProduct(c,a) >> provider
        0 * _

        and:
        commonResponse.getEmbedded().get('_embedded') == provider

        where:
        testcase| c    | a      |    provider
        0       |   1  | '1'    | [new ProviderType(type: 'Physician')]


    }

    def "getIntegrationsByClientAndProduct"() {
        given:

        when:
        CommonResponse commonResponse = federatedConfigController.getIntegrationsByClientAndProduct(c,a)

        then:
        1 * federatedConfigService.getIntegrationsByClientAndProduct(c,a) >> integration
        0 * _

        and:
        commonResponse.getEmbedded().get('_embedded') == integration

        where:
        testcase| c    | a      |    integration
        0       |   1  | '1'    | [new Integration(type: 'claims')]


    }

    def "getPagesByClientAndProduct"() {
        given:

        when:
        CommonResponse commonResponse = federatedConfigController.getPagesByClientAndProduct(c,a)

        then:
        1 * federatedConfigService.getPagesByClientAndProduct(c,a) >> page
        0 * _

        and:
        commonResponse.getEmbedded().get('_embedded') == page

        where:
        testcase| c    | a      |    page
        0       |   1  | '1'    | [new Page(type: 'requestingProvider')]


    }

    def "getPageConfigsByClientAndProduct"() {
        given:

        when:
        CommonResponse commonResponse = federatedConfigController.getPageConfigsByClientAndProduct(c,a,p)

        then:
        1 * federatedConfigService.getPageConfigsByClientAndProductAndPage(c,a,p) >> page
        0 * _

        and:
        commonResponse.getEmbedded().get('_embedded') == page

        where:
        testcase| c    | a      |   p                   |    page
        0       |   1  | '1'    | 'requestingProvider'  |new Page(type: 'requestingProvider')


    }

    def "isPageEnabled"() {
        given:
        HscVO hscVO = new HscVO()

        when:
        CommonResponse commonResponse = federatedConfigController.isPageEnabled(clientId, authType, SpclCareConstants.SERVICING_PROVIDER_PAGE, hscVO)

        then:
        1 * federatedConfigService.isScreenEnabled(clientId, authType, SpclCareConstants.SERVICING_PROVIDER_PAGE, hscVO) >> result

        and:
        commonResponse.getEmbedded().get('_embedded') == result

        where:
        testcase     |   clientId                                   |   authType                                                        |   result
        0            |   MultiPayerConstants.UHC_PAYER_ID           |   SpclCareReferenceConstants.AUTH_TYPE_INJECTABLE_CHEMOTHERAPY    |   false
        1            |   MultiPayerConstants.UHC_PAYER_ID           |   SpclCareReferenceConstants.AUTH_TYPE_SUPPORTIVE_DRUGS           |   false
        2            |   MultiPayerConstants.UHC_PAYER_ID           |   SpclCareReferenceConstants.AUTH_TYPE_RADIOPHARMACEUTICAL        |   false
        3            |   MultiPayerConstants.UHC_PAYER_ID           |   SpclCareReferenceConstants.AUTH_TYPE_INJECTABLE_CHEMOTHERAPY    |   false
        4            |   MultiPayerConstants.UHC_PAYER_ID           |   SpclCareReferenceConstants.AUTH_TYPE_INJECTABLE_CHEMOTHERAPY    |   true
        5            |   MultiPayerConstants.UHC_PAYER_ID           |   SpclCareReferenceConstants.AUTH_TYPE_SPECIALTY_PHARMACY         |   true
        6            |   MultiPayerConstants.UHC_PAYER_ID           |   SpclCareReferenceConstants.AUTH_TYPE_ORAL_DRUGS                 |   false
        7            |   MultiPayerConstants.UHC_PAYER_ID           |   SpclCareReferenceConstants.AUTH_TYPE_PHYSICAL_THERAPY           |   false
        8            |   MultiPayerConstants.UHC_PAYER_ID           |   SpclCareReferenceConstants.AUTH_TYPE_SPEECH_THERAPY             |   false
        9            |   MultiPayerConstants.UHC_PAYER_ID           |   SpclCareReferenceConstants.AUTH_TYPE_OCCUPATIONAL_THERAPY       |   false
        10           |   MultiPayerConstants.UHC_PAYER_ID           |   SpclCareReferenceConstants.AUTH_TYPE_RADIATION_ONCOLOGY         |   true
        11           |   MultiPayerConstants.BCBS_SC_PAYER_ID       |   SpclCareReferenceConstants.AUTH_TYPE_INJECTABLE_CHEMOTHERAPY    |   true
        12           |   MultiPayerConstants.BCBS_SC_PAYER_ID       |   SpclCareReferenceConstants.AUTH_TYPE_SUPPORTIVE_DRUGS           |   true
        13           |   MultiPayerConstants.BCBS_SC_PAYER_ID       |   SpclCareReferenceConstants.AUTH_TYPE_RADIOPHARMACEUTICAL        |   true
        14           |   MultiPayerConstants.OC_OMN_AZ_PAYER_ID     |   SpclCareReferenceConstants.AUTH_TYPE_INJECTABLE_CHEMOTHERAPY    |   true
        15           |   MultiPayerConstants.OC_OMN_AZ_PAYER_ID     |   SpclCareReferenceConstants.AUTH_TYPE_SUPPORTIVE_DRUGS           |   true
        16           |   MultiPayerConstants.OC_OMN_AZ_PAYER_ID     |   SpclCareReferenceConstants.AUTH_TYPE_RADIOPHARMACEUTICAL        |   true
        17           |   MultiPayerConstants.OC_SMA_PAYER_ID        |   SpclCareReferenceConstants.AUTH_TYPE_INJECTABLE_CHEMOTHERAPY    |   true
        18           |   MultiPayerConstants.OC_SMA_PAYER_ID        |   SpclCareReferenceConstants.AUTH_TYPE_SUPPORTIVE_DRUGS           |   true
        19           |   MultiPayerConstants.OC_SMA_PAYER_ID        |   SpclCareReferenceConstants.AUTH_TYPE_RADIOPHARMACEUTICAL        |   true
        20           |   MultiPayerConstants.OC_OMN_UT_PAYER_ID     |   SpclCareReferenceConstants.AUTH_TYPE_INJECTABLE_CHEMOTHERAPY    |   true
        21           |   MultiPayerConstants.OC_OMN_UT_PAYER_ID     |   SpclCareReferenceConstants.AUTH_TYPE_SUPPORTIVE_DRUGS           |   true
        22           |   MultiPayerConstants.OC_OMN_UT_PAYER_ID     |   SpclCareReferenceConstants.AUTH_TYPE_SUPPORTIVE_DRUGS           |   true
        23           |   MultiPayerConstants.OC_OMN_CO_PAYER_ID     |   SpclCareReferenceConstants.AUTH_TYPE_INJECTABLE_CHEMOTHERAPY    |   true
        24           |   MultiPayerConstants.OC_OMN_CO_PAYER_ID     |   SpclCareReferenceConstants.AUTH_TYPE_SUPPORTIVE_DRUGS           |   true
        25           |   MultiPayerConstants.OC_OMN_CO_PAYER_ID     |   SpclCareReferenceConstants.AUTH_TYPE_RADIOPHARMACEUTICAL        |   true
        26           |   MultiPayerConstants.PHN_PAYER_ID           |   SpclCareReferenceConstants.AUTH_TYPE_INJECTABLE_CHEMOTHERAPY    |   true
        27           |   MultiPayerConstants.PHN_PAYER_ID           |   SpclCareReferenceConstants.AUTH_TYPE_SUPPORTIVE_DRUGS           |   true
        28           |   MultiPayerConstants.PHN_PAYER_ID           |   SpclCareReferenceConstants.AUTH_TYPE_RADIOPHARMACEUTICAL        |   true
        29           |   MultiPayerConstants.ORX_PAYER_ID           |   SpclCareReferenceConstants.AUTH_TYPE_SPECIALTY_PHARMACY         |   true
        30           |   MultiPayerConstants.MBM_PAYER_ID           |   SpclCareReferenceConstants.AUTH_TYPE_SPECIALTY_PHARMACY         |   true
    }

//    def "getIntegrationByClientProductAndIntegration"() {
//        given:
//
//        when:
//        CommonResponse commonResponse = federatedConfigController.getIntegrationByClientProductAndIntegration(c,a,i)
//
//        then:
//        1 * federatedConfigService.getIntegrationByClientProductAndIntegration(c,a,i) >> integration
//        0 * _
//
//        and:
//        commonResponse.getEmbedded().get('_embedded') == integration
//
//        where:
//        testcase       | c    | a    |i               |    integration
//    0                  |   1  | '1'  |'ae-supportive' | [new Integration(type: 'ae-supportive')]
//
//
//    }


    def "getEpaConfigsByClientAndProduct"() {
        given:

        when:
        CommonResponse commonResponse = federatedConfigController.getEpaIntegrationByClientIdAndProduct(c,a)

        then:
        1 * federatedConfigService.getEpaIntegrationByClientAndProduct(c,a) >> epaIntegration
        0 * _

        and:
        commonResponse.getEmbedded().get('_embedded') == epaIntegration

        where:
        testcase| c    | a     |    epaIntegration
        0       | 1    | '1'   |new EpaIntegration(enabled: true)


    }
}
