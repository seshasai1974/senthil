package com.optum.app.shared.messaging.impl

import com.optum.app.shared.amqp.SpclCareAMQPDestinationProvider
import com.optum.app.shared.authorization.amqp.AuthRefreshMessage
import com.optum.app.shared.messaging.SpclCareMessageDestination
import com.optum.app.shared.messaging.SpclCareMessageNotifier
import com.optum.app.shared.messaging.impl.SpclCareMessageNotifierImpl
import com.optum.rf.amqp.AMQPMessagingException
import com.optum.rf.amqp.AMQPNotifierImpl
import org.springframework.amqp.rabbit.core.RabbitTemplate
import spock.lang.Specification

/**
 * Created by jboyd34 on 10/10/18.
 */
class SpclCareMessageNotifierImplSpec extends Specification {

    def "test sending a message"() {

        given:
        SpclCareMessageNotifier spclCareMessageNotifier = new SpclCareMessageNotifierImpl()
        SpclCareMessageDestination spclCareMessageDestination = new SpclCareMessageDestination(new SpclCareAMQPDestinationProvider())

        when:
        spclCareMessageNotifier != null
        AMQPNotifierImpl amqpNotifier = new AMQPNotifierImpl()
        amqpNotifier.setTransactionalRabbitTemplate(new RabbitTemplate())
        spclCareMessageNotifier.setRequiredMessageNotifier(amqpNotifier)
        spclCareMessageNotifier.refreshAuthorization(new AuthRefreshMessage(hscID: 1, primarySRN: 'A1231212'))

        then:
        thrown AMQPMessagingException

    }

    def "test getSpclCareMessageDestinationProvider"() {

        given:
        SpclCareMessageNotifier spclCareMessageNotifier = new SpclCareMessageNotifierImpl()

        when:
        spclCareMessageNotifier != null

        then:
        spclCareMessageNotifier.getSpclCareMessageDestinationProvider() != null

    }
}
