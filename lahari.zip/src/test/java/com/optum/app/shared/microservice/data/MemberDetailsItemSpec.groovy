package com.optum.app.shared.microservice.data

import com.optum.app.shared.microservice.data.MemberDetailsItem
import org.apache.commons.lang.StringUtils
import spock.lang.Specification

class MemberDetailsItemSpec extends Specification {
    MemberDetailsItem memberDetailsItem

    def setup() {
        memberDetailsItem = new MemberDetailsItem()
    }


    def "to String"() {
        given:

        MemberDetailsItem object = new MemberDetailsItem(firstName: 'MBM_TEST', lastName: 'TESTING')

        when:
        String retVal = object.toString()

        then:
        0 * _

        and:
        StringUtils.isNotBlank(retVal)
        retVal.contains(object.firstName)
        retVal.contains(object.lastName)
    }
}
