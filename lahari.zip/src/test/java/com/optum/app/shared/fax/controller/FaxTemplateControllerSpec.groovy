package com.optum.app.shared.fax.controller

import com.optum.app.shared.fax.businesslogic.FaxTemplate
import com.optum.mbm.fax.service.data.model.FaxTemplateDO
import com.optum.app.shared.spclcare.SpecialtyCareReadLogicSpecification
import com.optum.app.ocm.controller.support.CommonResponse
import com.optum.rf.dao.sql.query.QueryProperties
import spock.lang.Unroll

class FaxTemplateControllerSpec extends SpecialtyCareReadLogicSpecification{
    FaxTemplateController faxTemplateController
    FaxTemplate faxTemplate
    QueryProperties query

        def setup() {
            faxTemplateController = new FaxTemplateController()
            faxTemplate = Mock(FaxTemplate)
            faxTemplateController.faxTemplate = faxTemplate
            query = Mock(QueryProperties)
        }

        @Unroll
        def "test addFaxTemplate"() {
            when:
            FaxTemplateDO faxTemplateDO = new FaxTemplateDO()
            CommonResponse response = faxTemplateController.addFaxTemplate(faxTemplateDO)
            then:
            1 * faxTemplate.addFaxTemplate(_) >> "Response"
            0 *_._
        }

    @Unroll
    def "test updateFaxTemplate"() {
        when:
        FaxTemplateDO faxTemplateDO = new FaxTemplateDO()
        CommonResponse response = faxTemplateController.updateFaxTemplate(faxTemplateDO)
        then:
        1 * faxTemplate.updateFaxTemplate(_) >> "Response"
        0 *_._
    }

    @Unroll
    def "test getFaxTemplate"() {
        when:
        String templateId = new String("get")
        CommonResponse response = faxTemplateController.getFaxTemplate(templateId, query)
        then:
        1 * faxTemplate.getFaxTemplate('get',query)
        1 * faxTemplate.processQuery(query,null,false)
        0 * _._
    }

    @Unroll
    def "test deleteFaxTemplate"() {
        when:
        String templateId = new String("delete")
        CommonResponse response = faxTemplateController.deleteFaxTemplate(templateId)
        then:
        1 * faxTemplate.deleteFaxTemplate(_) >> "Response"
        0 *_._
    }
}
