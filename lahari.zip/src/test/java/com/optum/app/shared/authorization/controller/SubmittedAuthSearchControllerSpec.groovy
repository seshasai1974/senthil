package com.optum.app.shared.authorization.controller

import com.optum.app.ocm.controller.support.CommonResponse
import com.optum.app.shared.authorization.businesslogic.SubmittedAuthSearch
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.app.common.hsr.data.HscSubmittedAuthViewVO
import spock.lang.Specification

class SubmittedAuthSearchControllerSpec extends Specification {


    SubmittedAuthSearchController submittedAuthSearchController
    SubmittedAuthSearch submittedAuthSearch = Mock(SubmittedAuthSearch)

    def setup() {
        submittedAuthSearchController = new SubmittedAuthSearchController()
        submittedAuthSearchController.submittedAuthSearch = submittedAuthSearch
    }

    def 'getSubmittedAuthDetails'() {
        given:
        QueryProperties query = new QueryProperties()

        when:
        CommonResponse response = submittedAuthSearchController.getSubmittedAuthDetails(memberId, query)

        then:
        1 * submittedAuthSearch.getSubmittedAuthDetailsByMemberId(memberId, query) >> new CommonResponse(embedded: embeddedResponse).setPaginationInfo(query).setTotalRecordsCount(count)

        and:
        response.getPagination().get("totalRecordsCount") == 2

        where:
        Sno | memberId | customerId | count | embeddedResponse
        1   | 1234L    |     1      |  2    | [new HscSubmittedAuthViewVO(authTypeID:"123")]
    }
}