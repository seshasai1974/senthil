package com.optum.app.shared.tat.data

import spock.lang.Specification

class ActivityTypeSpec extends Specification{

    def 'fromDeliveryTypeAndLetterType(DeliveryType.PDF, LetterType.APPROVAL)' () {
        given:
            DeliveryType deliveryType = DeliveryType.PDF
            LetterType letterType = LetterType.APPROVAL

        when:
        ActivityType activityType = ActivityType.fromDeliveryTypeAndLetterType(deliveryType, letterType)

        then:
        activityType == ActivityType.MANUAL_LETTER_SENT
    }

    def 'fromDeliveryTypeAndLetterType(DeliveryType.PDF, LetterType.DENIAL)' () {
        given:
        DeliveryType deliveryType = DeliveryType.PDF
        LetterType letterType = LetterType.DENIAL

        when:
        ActivityType activityType = ActivityType.fromDeliveryTypeAndLetterType(deliveryType, letterType)

        then:
        activityType == ActivityType.MANUAL_LETTER_SENT
    }

    def 'fromDeliveryTypeAndLetterType(DeliveryType.PDF, LetterType.LACK_OF_INFORMATION)' () {
        given:
        DeliveryType deliveryType = DeliveryType.PDF
        LetterType letterType = LetterType.LACK_OF_INFORMATION

        when:
        ActivityType activityType = ActivityType.fromDeliveryTypeAndLetterType(deliveryType, letterType)

        then:
        activityType == ActivityType.MANUAL_LETTER_SENT
    }

    def 'fromDeliveryTypeAndLetterType(DeliveryType.PHYSICAL_MAIL, LetterType.APPROVAL)' () {
        given:
        DeliveryType deliveryType = DeliveryType.PHYSICAL_MAIL
        LetterType letterType = LetterType.APPROVAL

        when:
        ActivityType activityType = ActivityType.fromDeliveryTypeAndLetterType(deliveryType, letterType)

        then:
        activityType == ActivityType.LETTER_SENT
    }

    def 'fromDeliveryTypeAndLetterType(DeliveryType.PHYSICAL_MAIL, LetterType.DENIAL)' () {
        given:
        DeliveryType deliveryType = DeliveryType.PHYSICAL_MAIL
        LetterType letterType = LetterType.DENIAL

        when:
        ActivityType activityType = ActivityType.fromDeliveryTypeAndLetterType(deliveryType, letterType)

        then:
        activityType == ActivityType.LETTER_SENT
    }

    def 'fromDeliveryTypeAndLetterType(DeliveryType.PHYSICAL_MAIL, LetterType.LACK_OF_INFORMATION)' () {
        given:
        DeliveryType deliveryType = DeliveryType.PHYSICAL_MAIL
        LetterType letterType = LetterType.LACK_OF_INFORMATION

        when:
        ActivityType activityType = ActivityType.fromDeliveryTypeAndLetterType(deliveryType, letterType)

        then:
        activityType == ActivityType.LOI_LETTER_SENT
    }

    def 'fromDeliveryTypeAndLetterType(DeliveryType.FAX, LetterType.APPROVAL)' () {
        given:
        DeliveryType deliveryType = DeliveryType.FAX
        LetterType letterType = LetterType.APPROVAL

        when:
        ActivityType activityType = ActivityType.fromDeliveryTypeAndLetterType(deliveryType, letterType)

        then:
        activityType == ActivityType.LETTER_SENT
    }

    def 'fromDeliveryTypeAndLetterType(DeliveryType.FAX, LetterType.DENIAL)' () {
        given:
        DeliveryType deliveryType = DeliveryType.FAX
        LetterType letterType = LetterType.DENIAL

        when:
        ActivityType activityType = ActivityType.fromDeliveryTypeAndLetterType(deliveryType, letterType)

        then:
        activityType == ActivityType.LETTER_SENT
    }

    def 'fromDeliveryTypeAndLetterType(DeliveryType.FAX, LetterType.LACK_OF_INFORMATION)' () {
        given:
        DeliveryType deliveryType = DeliveryType.FAX
        LetterType letterType = LetterType.LACK_OF_INFORMATION

        when:
        ActivityType activityType = ActivityType.fromDeliveryTypeAndLetterType(deliveryType, letterType)

        then:
        activityType == ActivityType.LOI_FAX_SENT
    }
}
