package com.optum.app.shared.whitelabel

import com.optum.app.shared.common.messages.SpclCareMessages
import com.optum.rf.dao.exception.UhgRuntimeException
import spock.lang.Specification

class CustomerWLSubmoduleSpec extends Specification implements WhiteLabelTestData {
    // Subject Under Test. Instantiating here ensures we restart internal state in each test
    def customerWLSubmodule = new CustomerWLSubmoduleConfig().customerWLSubmoduleWithInMemoryRepos()

    def "Success: Merging the different WhiteLabel levels"() {
        given:
        if(customerWhiteLabels != null) {
            customerWLSubmodule.saveWLCustomerLevelValues('c1', toOptionalJson(customerWhiteLabels).get())
        }
        if(orgWhiteLabels != null) {
            customerWLSubmodule.saveWLOrganizationLevelValues('o1', toOptionalJson(orgWhiteLabels).get())
        }

        when:
        def whiteLabels = customerWLSubmodule.getMergedCustomerWhiteLabels("c1", "o1")

        then:
        noExceptionThrown()
        whiteLabels == toOptionalJson(expectedMergedWhiteLabels)

        where:
        orgWhiteLabels                      | customerWhiteLabels               | expectedMergedWhiteLabels
        null                                | null                              | null
        null                                | '{}'                              | '{}'
        '{}'                                | null                              | '{}'
        '{}'                                | '{}'                              | '{}'
        '{"a": "xyz"}'                      | '{"b": "qwe"}'                    | '{"a": "xyz", "b": "qwe"}'
        '{"a": "xyz"}'                      | '{"b": "qwe"}'                    | '{"a": "xyz", "b": "qwe"}'
        '{"a": "xyz"}'                      | '{"a": "override"}'               | '{"a": "override"}'
        '{"a": [1, 2]}'                     | '{"a": [11]}'                     | '{"a": [11]}'
        '{"a": ["1", "2"]}'                 | '{"a": ["11"]}'                   | '{"a": ["11"]}'
        '{"a": {"nestedB": "xyz"}}'         | '{"a": {"nestedC": "qwe"}}'       | '{"a": {"nestedB": "xyz", "nestedC": "qwe"}}'
    }

    def "Success: Customer Level WhiteLabels maintenance"() {
        given:
        def customerVO = newCustomerVO(1)

        when:
        customerWLSubmodule.saveWLCustomerLevelValues(customerVO.customerName, toOptionalJson(customerVO).get())
        def getResult = customerWLSubmodule.getWLCustomerLevelValues(customerVO.customerName)

        then:
        noExceptionThrown()
        getResult != null

        when:
        def namesResult = customerWLSubmodule.getCustomerNamesWithCustomerLevelValues()

        then:
        noExceptionThrown()
        namesResult == [customerVO.customerName] as Set
    }

    def "Success: Organization Level WhiteLabels maintenance"() {
        given:
        def customerVO = newCustomerVO(1)

        when:
        customerWLSubmodule.saveWLOrganizationLevelValues(customerVO.customerName, toOptionalJson(customerVO).get())
        def getResult = customerWLSubmodule.getWLOrganizationLevelValues(customerVO.customerName)

        then:
        noExceptionThrown()
        getResult != null

        when:
        def namesResult = customerWLSubmodule.getOrganizationNamesWithOrganizationLevelValues()

        then:
        noExceptionThrown()
        namesResult == [customerVO.customerName] as Set
    }

    def "Failure to read Customer Level WhiteLabels"() {
        given:
        def customerVO = newCustomerVO(1)

        when:
        customerWLSubmodule.getWLCustomerLevelValues(customerVO.customerName)

        then:
        UhgRuntimeException e = thrown(UhgRuntimeException)
        e.getErrorVO().getGlobalMessages().contains(SpclCareMessages.ERR_MISSING_CONFIGURATION_FOR("customerName " + customerVO.customerName))
    }

    def "Failure to read Organization Level WhiteLabels maintenance"() {
        when:
        customerWLSubmodule.getWLOrganizationLevelValues("org-0")

        then:
        UhgRuntimeException e = thrown(UhgRuntimeException)
        e.getErrorVO().getGlobalMessages().contains(SpclCareMessages.ERR_MISSING_CONFIGURATION_FOR("organizationName " + "org-0"))
    }
}
