package com.optum.app.shared.whitelabel

import com.optum.app.common.organization.data.OrganizationVO
import com.optum.app.ocm.customer.businesslogic.Customer
import com.optum.app.ocm.organization.businesslogic.Organization
import com.optum.app.shared.authorization.businesslogic.Authorizations
import com.optum.rf.dao.sql.query.QueryProperties
import spock.lang.Specification

import java.util.concurrent.CancellationException

class WhiteLabelPreloadSpec extends Specification implements WhiteLabelTestData {
    // Mocks dependencies external to the current module.
    Authorizations authorizations = Mock(Authorizations)
    Customer customer = Mock(Customer)
    Organization organization = Mock(Organization)
    CustomerWLSubmodule customerWhiteLabelsSubmodule = Mock(CustomerWLSubmodule)
    ForbiddenWordsSubmodule forbiddenWordsSubmodule = Mock(ForbiddenWordsSubmodule)
    // Subject Under Test. Instantiating here ensures we restart internal state in each test
    def whiteLabel = new WhiteLabelConfiguration().whiteLabel(
            authorizations,
            customer,
            organization,
            customerWhiteLabelsSubmodule,
            forbiddenWordsSubmodule
    )

    // SUCCESS
    def 'Success preload'() {

        when: "Conditional preload"
        Set<String> preloadResults = null
        if (withPreload) {
            preloadResults = whiteLabel.asyncPreload().get()
        }

        then: "verify preload results"
        preloadResults == expectedPreloadResult
        customer.list(_ as QueryProperties) >> customerList
        customer.read(_ as Integer) >>> customerList
        organization.read(_ as Integer) >> new OrganizationVO(organizationID: 1, organizationShortName: "org-1")
        customersWithSavedWhiteLabels.each {
            customerWhiteLabelsSubmodule.getMergedCustomerWhiteLabels(it.customerName,"org-1") >>>
                    customersWithSavedWhiteLabels.collect{ toOptionalJson(it) }
        } || true //avoids failing the test because customersWithSavedWhiteLabels is empty
        forbiddenWordsSubmodule.getMergedForbiddenWords(_ as String, _ as String) >> []

        when: "read whiteLabels"
        customersWithSavedWhiteLabels.forEach { customerVO ->
            whiteLabel.customerWhiteLabels(customerVO.customerID)
        }

        then: "Validation happens but reading whiteLabels may be prevented"
        customer.read(_ as Integer) >>> customerList
        organization.read(_ as Integer) >> new OrganizationVO(organizationID: 1, organizationShortName: "org-1")
        readRepoInteractions * customerWhiteLabelsSubmodule.getMergedCustomerWhiteLabels(_ as String, _ as String) >>> customersWithSavedWhiteLabels.collect{ toOptionalJson(it) }
        readRepoInteractions * forbiddenWordsSubmodule.getMergedForbiddenWords(_ as String, _ as String) >> []

        when: "preload is invoked again"
        if (withPreload) {
            preloadResults = whiteLabel.asyncPreload().get()
        }

        then: "Validation happens but reading whiteLabels may be prevented"
        preloadResults == expectedPreloadResult

        where:
        withPreload | customersWithSavedWhiteLabels | customerList               | readRepoInteractions | expectedPreloadResult
        true        | newCustomerVOList(1)     | newCustomerVOList(1) | 0                    | ["customer-1"] as Set
        true        | newCustomerVOList(1)     | newCustomerVOList(2) | 0                    | ["customer-1"] as Set
        true        | newCustomerVOList(1)     | newCustomerVOList(3) | 0                    | ["customer-1"] as Set
        true        | newCustomerVOList(3)     | newCustomerVOList(3) | 0                    | ["customer-1", "customer-2", "customer-3"] as Set
        true        | newCustomerVOList(3)     | newCustomerVOList(4) | 0                    | ["customer-1", "customer-2", "customer-3"] as Set
        true        | newCustomerVOList(3)     | newCustomerVOList(5) | 0                    | ["customer-1", "customer-2", "customer-3"] as Set
        true        | []                            | newCustomerVOList(1) | 0                    | [] as Set
        false       | newCustomerVOList(1)     | newCustomerVOList(1) | 1                    | null
        false       | newCustomerVOList(1)     | newCustomerVOList(2) | 1                    | null
        false       | newCustomerVOList(1)     | newCustomerVOList(3) | 1                    | null
        false       | newCustomerVOList(3)     | newCustomerVOList(3) | 3                    | null
        false       | newCustomerVOList(3)     | newCustomerVOList(4) | 3                    | null
        false       | newCustomerVOList(3)     | newCustomerVOList(5) | 3                    | null
        false        | []                            | newCustomerVOList(1) | 0                    | null

    }


    def 'Failure to preload - cancellation'() {
        when:
        whiteLabel.asyncPreload().get()

        then: "Preload execution timeout results in a cancellation exception"
        thrown(CancellationException)
        1 * customer.list(_ as QueryProperties) >> { sleep(300); return [] }
    }
}
