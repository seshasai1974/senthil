package com.optum.app.shared.microservice.data

import com.optum.app.shared.microservice.data.MemberSummaryListRequest
import org.apache.commons.lang.StringUtils
import spock.lang.Specification

/**
 * Created by cnadipin on 1/10/19.
 */
class MemberSummaryListRequestSpec  extends Specification{

    MemberSummaryListRequest memberSummaryListRequest

    def setup() {
        memberSummaryListRequest= new MemberSummaryListRequest(firstName: 'AAAA', lastName:'BBBB', birthDate:'1992-10-10', stateCode: 'NC', subscriberID: '123',
                 searchTypeCode: 'AAA', trimLeadingZeros: 'AB', policyID: '111', coverageType: 'F', effectiveStartDate: '2019-01-01', effectiveEndDate:"2020-01-01", pageNumber: '01', pageSize: '04', environmentType: 'MBM_TEST')
    }
    def "equals true"() {

        when:
        boolean retVal = memberSummaryListRequest.equals(memberSummaryListRequest)

        then:
        0 * _

        and:
        retVal
    }

    def "equals false"() {
        given:
        MemberSummaryListRequest object = new MemberSummaryListRequest(firstName: 'AAAA', lastName:'BBBB', birthDate:'1992-10-10', stateCode: 'NC', subscriberID: '123',
                searchTypeCode: 'AAA', trimLeadingZeros: 'AB', policyID: '111', coverageType: 'F', effectiveStartDate: '2019-01-01', effectiveEndDate:"2020-01-01", pageNumber: '01', pageSize: '04', environmentType: 'MBM_TEST')

        when:
        boolean retVal = object.equals(_)

        then:
        0 * _

        and:
        !retVal
    }

    def "hash"() {
        given:

        MemberSummaryListRequest object = new MemberSummaryListRequest(firstName: 'AAAA', lastName:'BBBB', birthDate:'1992-10-10', stateCode: 'NC', subscriberID: '123',
                searchTypeCode: 'AAA', trimLeadingZeros: 'AB', policyID: '111', coverageType: 'F', effectiveStartDate: '2019-01-01', effectiveEndDate:"2020-01-01", pageNumber: '01', pageSize: '04', environmentType: 'MBM_TEST')

        when:
        int hashVal = object.hashCode()

        then:
        0 * _

        and:
        memberSummaryListRequest.hashCode() == hashVal
    }

    def "to String"() {
        given:

        MemberSummaryListRequest object = new MemberSummaryListRequest(firstName: 'AAAA', lastName:'BBBB', birthDate:'1992-10-10', stateCode: 'NC', subscriberID: '123',
                searchTypeCode: 'AAA', trimLeadingZeros: 'AB', policyID: '111', coverageType: 'F', effectiveStartDate: '2019-01-01', effectiveEndDate:"2020-01-01", pageNumber: '01', pageSize: '04', environmentType: 'MBM_TEST')

        when:
        String retVal = object.toString()

        then:
        0 * _

        and:
        StringUtils.isNotBlank(retVal)
    }
}
