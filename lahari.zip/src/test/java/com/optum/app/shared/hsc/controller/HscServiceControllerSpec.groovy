package com.optum.app.shared.hsc.controller

import com.optum.app.ocm.controller.support.CommonResponse
import com.optum.app.shared.authorization.businesslogic.Authorizations
import com.optum.app.shared.hsc.businesslogic.HscServiceLine
import com.optum.app.common.hsr.data.HscServiceNonFacilityVO
import com.optum.app.common.hsr.data.HscServiceVO
import spock.lang.Specification
import spock.lang.Unroll

class HscServiceControllerSpec extends Specification {

    HscServiceController hscServiceController
    HscServiceLine hscServiceLine
    Authorizations authorizations

    def setup() {
        hscServiceController = new HscServiceController()
        hscServiceLine = Mock(HscServiceLine)
        authorizations = Mock(Authorizations)
        hscServiceController.hscServiceLine = hscServiceLine
        hscServiceController.authorizations = authorizations
    }

    @Unroll
    def 'updateServiceLine'(){
        given :
        int customerID = 3
        short serviceSeqNum = 1
        HscServiceNonFacilityVO hscServiceNonFacilityVO = new HscServiceNonFacilityVO(totalBillableUnits:1233 , procUnitDesc:'123 mg', serviceSeqNum : 1, dosageEditReason: '2' )
        List<HscServiceVO> hscServiceVOs = [new HscServiceVO(serviceSeqNum: serviceSeqNum,hscServiceNonFacilityVO: hscServiceNonFacilityVO), new HscServiceVO(serviceSeqNum: serviceSeqNum, hscServiceNonFacilityVO: hscServiceNonFacilityVO)]
        CommonResponse response = new CommonResponse(embedded: hscServiceNonFacilityVO)

        when:
        hscServiceController.updateServiceLine(customerID, 12345L, serviceSeqNum, hscServiceVOs)

        then:
        1 * authorizations.validateAuthorization(_,_,_)
        1 * hscServiceLine.updateServiceLine(_,_) >> response

        and:
        response.getEmbedded() == ['_embedded': hscServiceNonFacilityVO]
    }
}
