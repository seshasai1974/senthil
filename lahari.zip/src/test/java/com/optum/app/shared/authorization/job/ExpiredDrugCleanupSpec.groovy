package com.optum.app.shared.authorization.job

import spock.lang.Specification

class ExpiredDrugCleanupSpec extends Specification {

    def "test ExpiredDrugCleanupSpec"(){
        given:
        ExpiredDrugCleanupCronJob expiredDrugCleanupCronJob = new ExpiredDrugCleanupCronJob()

        when:
        expiredDrugCleanupCronJob

        then:
        expiredDrugCleanupCronJob.cronPattern == '1 0 * * *'
        expiredDrugCleanupCronJob.systemJobID == "EDC"
        expiredDrugCleanupCronJob.description == "Change Deployed drugs to Expired if their end date has passed"
        expiredDrugCleanupCronJob.task != null
    }
}
