package com.optum.app.shared.hsc.controller

import com.optum.app.common.activity.data.CommunicationTransactionVO
import com.optum.app.common.customer.data.CustomerVO
import com.optum.app.ocm.customer.businesslogic.Customer
import com.optum.app.shared.hsc.data.StartDateDO
import com.optum.app.shared.microservice.data.ProviderDetails
import com.optum.app.shared.procedure.data.ProcedureViewVO
import com.optum.rf.dao.constants.SystemGlobalMessages
import com.optum.mbm.flow.data.v1.request.DroolsRuleRequest
import com.optum.mbm.flow.data.v1.signal.StepperSignal
import com.optum.mbm.flow.data.v1.signal.hsc.HscSignal
import com.optum.mbm.flow.data.v1.signal.hsc.HscSpecialtyProcedureSignal
import com.optum.mbm.flow.data.v1.signal.member.MemberCoverageSignal
import com.optum.mbm.flow.data.v1.signal.member.MemberSignal
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.hsr.businesslogic.Hsc
import com.optum.app.common.hsr.businesslogic.HscAssessment
import com.optum.app.common.hsr.businesslogic.HscAttribute
import com.optum.app.common.hsr.businesslogic.HscComponentStatus
import com.optum.app.common.hsr.businesslogic.HscCustomReason
import com.optum.app.common.hsr.businesslogic.HscFollowUpContact
import com.optum.app.common.hsr.businesslogic.HscProvider
import com.optum.app.common.hsr.businesslogic.HscProviderRole
import com.optum.app.common.hsr.businesslogic.HscService
import com.optum.app.common.hsr.businesslogic.UserHscHistory
import com.optum.app.common.hsr.constants.HsrReferenceConstants
import com.optum.app.common.hsr.data.HscAssessmentVO
import com.optum.app.common.hsr.data.HscAttributeVO
import com.optum.app.common.hsr.data.HscComponentStatusVO
import com.optum.app.common.hsr.data.HscCustomReasonVO
import com.optum.app.common.hsr.data.HscFollowUpContactVO
import com.optum.app.common.hsr.data.HscMemberCoverageVO
import com.optum.app.common.hsr.data.HscProviderRoleVO
import com.optum.app.common.hsr.data.HscProviderVO
import com.optum.app.common.hsr.data.HscServiceVO
import com.optum.app.common.hsr.data.HscSpecialtyProcedureVO
import com.optum.app.common.hsr.data.HscVO
import com.optum.app.common.member.core.data.MemberCoverageVO
import com.optum.app.common.member.core.data.MemberVO
import com.optum.app.ocm.common.activity.businesslogic.CommunicationTransaction
import com.optum.app.ocm.common.member.businesslogic.Member
import com.optum.app.ocm.common.member.businesslogic.MemberIdentifier
import com.optum.app.ocm.common.member.businesslogic.MemberTelephone
import com.optum.app.ocm.controller.support.CommonResponse
import com.optum.app.ocm.controller.support.SelectDataVO
import com.optum.app.ocm.ref.businesslogic.CustomerReference
import com.optum.app.shared.authorization.businesslogic.HscDetail
import com.optum.app.shared.authorization.businesslogic.HscSummary
import com.optum.app.shared.common.messages.SpclCareMessages
import com.optum.app.shared.constants.MultiPayerConstants
import com.optum.app.shared.constants.SpclCareConstants
import com.optum.app.shared.constants.SpclCareFeatureFlagConstants
import com.optum.app.shared.constants.SpclCareNonPersistedFieldConstants
import com.optum.app.shared.constants.SpclCareReferenceConstants
import com.optum.app.shared.diseaseTraversal.businesslogic.AuthorizationRuleHelper
import com.optum.app.shared.diseaseTraversal.businesslogic.DrugExceptionsView
import com.optum.app.shared.diseaseTraversal.businesslogic.TreatmentProcedureAuthorizationRuleException
import com.optum.app.shared.diseaseTraversal.data.TreatmentProcedureAuthorizationRuleVO
import com.optum.app.shared.documentManager.businesslogic.DocumentManagerService
import com.optum.app.shared.drugRounding.businesslogic.DrugRounding
import com.optum.app.shared.drugRounding.data.DrugRoundingRequestDO
import com.optum.app.shared.drugRounding.data.DrugRoundingResponseDO
import com.optum.app.shared.genericRuleService.v1.data.out.GenericRuleServiceResponse
import com.optum.app.shared.genericRuleService.v1.processor.GenericRuleServiceProcessor
import com.optum.app.shared.hsc.businesslogic.HscClone
import com.optum.app.shared.hsc.businesslogic.HscDuplicate
import com.optum.app.shared.hsc.businesslogic.HscHelper
import com.optum.app.shared.hsc.businesslogic.HscSearch
import com.optum.app.shared.hsc.businesslogic.HscUpdate
import com.optum.app.shared.hsc.data.AuthRequestDetailsDO
import com.optum.app.shared.hsc.data.CancelSubmittedAuthDO
import com.optum.app.shared.hsc.data.CloneRequestDO
import com.optum.app.shared.hsc.data.CustomRegimenDO
import com.optum.app.shared.hsc.data.DrugExceptionCheckDO
import com.optum.app.shared.hsc.data.GenerateHscDO
import com.optum.app.shared.hsc.data.HscCloningDO
import com.optum.app.shared.hsc.data.RegimenSelectionDO
import com.optum.app.shared.hsc.data.ReopenAuthDO
import com.optum.app.shared.hsc.data.RuleEngineDetailsDO
import com.optum.app.shared.hsc.data.SupportiveCareRegimenDO
import com.optum.app.shared.hsc.util.CancelSubmittedAuthorization
import com.optum.app.shared.hsc.util.ReopenAuthorization
import com.optum.app.shared.jbpm.JbpmHelper
import com.optum.app.shared.microservice.businesslogic.Edi274
import com.optum.app.shared.specialtyPharmacy.businesslogic.SpecialtyProceduresView
import com.optum.app.shared.specialtyPharmacy.data.SpecialtyProceduresViewVO
import com.optum.mbm.flow.data.v1.response.DroolsProcessResponse
import com.optum.mbm.workqueue.data.v1.request.ItemTask
import com.optum.mbm.workqueue.data.v2.response.ItemTaskCriteriaResponse
import com.optum.rf.common.featureflag.util.FeatureFlagManager
import com.optum.rf.common.featureflag.util.FeatureFlagUtility
import com.optum.rf.common.security.data.UserSecurityVO
import com.optum.rf.dao.controller.session.SessionThreadLocal
import com.optum.rf.dao.exception.UhgRuntimeException
import com.optum.rf.dao.sql.query.QueryFilter
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.rf.dao.util.UhgCalendarUtilities
import com.optum.rf.web.controller.session.HttpUserSession
import com.optum.app.ocm.common.member.businesslogic.MemberCoverage
import com.uhg.app.common.constants.spclcare.FieldConstants
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestMethod
import org.springframework.web.bind.annotation.ResponseBody
import spock.lang.Specification
import spock.lang.Unroll
import com.optum.app.shared.hsc.data.HscCustomReasonDO
import com.optum.rf.dao.controller.session.Session

import java.sql.Date

class HscControllerSpec extends Specification {
    HscController hscController

    Member member = Mock(Member)
    MemberIdentifier memberIdentifier = Mock(MemberIdentifier)
    Hsc hsc = Mock(Hsc)
    HscHelper hscHelper = Mock(HscHelper)
    HscDuplicate hscDuplicate = Mock(HscDuplicate)
    HscClone hscClone = Mock(HscClone)
    HscUpdate hscUpdate = Mock(HscUpdate)
    HscProvider hscProvider = Mock(HscProvider)
    HscProviderRole hscProviderRole = Mock(HscProviderRole)
    HscSearch hscSearch = Mock(HscSearch)
    HscAssessment hscAssessment = Mock(HscAssessment)
    HscAttribute hscAttribute = Mock(HscAttribute)
    HscSummary hscSummary = Mock(HscSummary)
    HscDetail hscDetail = Mock(HscDetail)
    MemberTelephone memberTelephone = Mock(MemberTelephone)
    HscFollowUpContact hscFollowUpContact = Mock(HscFollowUpContact)
    HscComponentStatus hscComponentStatus = Mock(HscComponentStatus)
    HscService hscService = Mock(HscService)
    AuthorizationRuleHelper authorizationRuleHelper = Mock(AuthorizationRuleHelper)
    DocumentManagerService documentManagerService = Mock(DocumentManagerService)
    DrugExceptionsView authorizationRuleView = Mock(DrugExceptionsView)
    TreatmentProcedureAuthorizationRuleException ruleException = Mock(TreatmentProcedureAuthorizationRuleException)
    CustomerReference customerReference = Mock(CustomerReference)
    FeatureFlagManager featureFlagManager = Mock(FeatureFlagManager)
    CommunicationTransaction communicationTransaction = Mock(CommunicationTransaction)
    GenericRuleServiceProcessor genericRuleServiceProcessor = Mock(GenericRuleServiceProcessor)
    UserHscHistory userHscHistory = Mock(UserHscHistory)
    CancelSubmittedAuthorization cancelSubmittedAuthorization = Mock(CancelSubmittedAuthorization)
    ReopenAuthorization reopenAuthorization = Mock(ReopenAuthorization)
    JbpmHelper jbpmHelper = Mock(JbpmHelper)
    SpecialtyProceduresView specialtyProceduresView = Mock(SpecialtyProceduresView)
    HscCustomReason hscCustomReason = Mock(HscCustomReason)
    Edi274 edi274 = Mock(Edi274)
    DrugRounding drugRounding = Mock(DrugRounding)
    MemberCoverage memberCoverage = Mock(MemberCoverage)
    Customer customer = Mock(Customer)
    SessionThreadLocal sessionThreadLocal = Mock(SessionThreadLocal)

    private final static long TEST_HSC_ID = 1234L
    private final static long TEST_MEMBER_ID = 5555L

    def setup() {
        hscController = new HscController()
        hscController.member = member
        hscController.memberIdentifier = memberIdentifier
        hscController.hsc = hsc
        hscController.hscHelper = hscHelper
        hscController.hscClone = hscClone
        hscController.hscDuplicate = hscDuplicate
        hscController.hscUpdate = hscUpdate
        hscController.hscProvider = hscProvider
        hscController.hscProviderRole = hscProviderRole
        hscController.hscSearch = hscSearch
        hscController.hscAssessment = hscAssessment
        hscController.hscAttribute = hscAttribute
        hscController.hscSummary = hscSummary
        hscController.hscDetail = hscDetail
        hscController.memberTelephone = memberTelephone
        hscController.hscFollowUpContact = hscFollowUpContact
        hscController.hscComponentStatus = hscComponentStatus
        hscController.hscService = hscService
        hscController.authorizationRuleHelper = authorizationRuleHelper
        hscController.documentManagerService = documentManagerService
        hscController.authorizationRuleView = authorizationRuleView
        hscController.ruleException = ruleException
        hscController.customerReference = customerReference
        hscController.communicationTransaction = communicationTransaction
        hscController.genericRuleServiceProcessor = genericRuleServiceProcessor
        hscController.userHscHistory = userHscHistory
        hscController.cancelSubmittedAuthorization = cancelSubmittedAuthorization
        hscController.reopenAuthorization = reopenAuthorization
        hscController.jbpmHelper = jbpmHelper
        hscController.specialtyProceduresView = specialtyProceduresView
        hscController.hscCustomReason = hscCustomReason
        hscController.edi274 = edi274
        hscController.drugRounding = drugRounding
        hscController.memberCoverage = memberCoverage
        hscController.customer = customer

        System.setProperty(MultiPayerConstants.APPROVAL_TYPE, '1')

        FeatureFlagUtility.featureFlagManager = featureFlagManager
    }

    def 'test generateInProgressHSC'() {
        given:
        MemberVO memberVO = new MemberVO(memberID: TEST_HSC_ID, hscID: TEST_HSC_ID)
        String authType = "1"
        GenerateHscDO generateHscDO = new GenerateHscDO(memberVO: memberVO, authType: authType)

        when:
        CommonResponse response = hscController.generateInProgressHSC(generateHscDO)

        then:
        1 * hscHelper.generateInProgressHSC(generateHscDO)
        1 * userHscHistory.saveUserHscHistory(TEST_HSC_ID)
        0 * _

        and:
        response.getEmbedded().get(CommonResponse.EMBEDDED) == generateHscDO
    }

    def 'test generateInProgressHSC - Future Dated'() {
        given:
        MemberVO memberVO = new MemberVO(memberID: TEST_HSC_ID, hscID: TEST_HSC_ID, memberCoverageVOs: [new MemberCoverageVO(coverageEffectiveDate: UhgCalendarUtilities.getTodaysDate()-1, coverageEndDate: UhgCalendarUtilities.getTodaysDate()+1, memberCoverageSeqNum: 1),
                                                                                                        new MemberCoverageVO(coverageEffectiveDate: UhgCalendarUtilities.getTodaysDate()+2, coverageEndDate: UhgCalendarUtilities.getTodaysDate()+4, memberCoverageSeqNum: 2)])
        String authType = "1"
        GenerateHscDO generateHscDO = new GenerateHscDO(memberVO: memberVO, authType: authType, authStartDate: UhgCalendarUtilities.getTodaysDate()+3, memberCoverageSequenceNumber: 2)

        when:
        CommonResponse response = hscController.generateInProgressHSC(generateHscDO)

        then:
        1 * hscHelper.generateInProgressHSC(generateHscDO)
        1 * userHscHistory.saveUserHscHistory(TEST_HSC_ID)
        0 * _

        and:
        response.getEmbedded().get(CommonResponse.EMBEDDED) == generateHscDO
    }

    def 'test generateInProgressHSC - no hsc'() {
        given:
        MemberVO memberVO = new MemberVO(memberID: TEST_HSC_ID)
        String authType = "1"
        GenerateHscDO generateHscDO = new GenerateHscDO(memberVO: memberVO, authType: authType)

        when:
        CommonResponse response = hscController.generateInProgressHSC(generateHscDO)

        then:
        1 * hscHelper.generateInProgressHSC(generateHscDO)
        0 * _

        and:
        response.getEmbedded().get(CommonResponse.EMBEDDED) == generateHscDO
    }

    def "updateNotes"() {
        given:
        CommonResponse notesResponse = new CommonResponse()

        when:
        CommonResponse response = hscController.updateNotes(TEST_HSC_ID)

        then:
        1 * hscUpdate.updateNotes(TEST_HSC_ID) >> notesResponse
        0 * _

        and:
        response == notesResponse
    }

    def "saveHsc"() {
        given:
        HscVO hscVO = new HscVO(hscID: TEST_HSC_ID, memberID: 5555)

        when:
        CommonResponse response = hscController.saveHsc(hscVO)

        then:
        1 * hscHelper.saveHsc(hscVO)
        0 * _

        and:
        response
    }

    def "getProviderList"() {
        when:
        hscController.getProviderList()

        then:
        1 * hscHelper.getProviders()
        0 * _
    }

    @Unroll
    def "getStatusList"() {
        given:
        System.setProperty(MultiPayerConstants.PAYER, payer)
        SessionThreadLocal.session = httpUserSession

        when:
        List<SelectDataVO> returnList = hscController.getStatusList()

        then:
        1 * customerReference.getReferenceDescription(SpclCareNonPersistedFieldConstants.HSC_OVERALL_STATUS_TYPE, SpclCareReferenceConstants.HSCOVERALLSTATUSTYPE_APPROVED) >> 'ref1'
        1 * customerReference.getReferenceDescription(SpclCareNonPersistedFieldConstants.HSC_OVERALL_STATUS_TYPE, SpclCareReferenceConstants.HSCOVERALLSTATUSTYPE_PENDING_REVIEW) >> 'ref2'
        1 * customerReference.getReferenceDescription(SpclCareNonPersistedFieldConstants.HSC_OVERALL_STATUS_TYPE, SpclCareReferenceConstants.HSCOVERALLSTATUSTYPE_DENIED) >> 'ref3'
        1 * customerReference.getReferenceDescription(SpclCareNonPersistedFieldConstants.HSC_OVERALL_STATUS_TYPE, SpclCareReferenceConstants.HSCOVERALLSTATUSTYPE_WITHDRAWN) >> 'ref4'
        isProvider * customerReference.getReferenceDescription(SpclCareNonPersistedFieldConstants.HSC_OVERALL_STATUS_TYPE, SpclCareReferenceConstants.HSCOVERALLSTATUSTYPE_UNDER_APPEALS_REVIEW) >> 'ref5'
        isProvider * customerReference.getReferenceDescription(SpclCareNonPersistedFieldConstants.HSC_OVERALL_STATUS_TYPE, SpclCareReferenceConstants.HSCOVERALLSTATUSTYPE_RECONSIDERATION) >> 'ref6'
        (isProvider ? 0 : 1) * hscHelper.isMSKUser() >> mskUserCheck
        1 * customerReference.getReferenceDescription(SpclCareNonPersistedFieldConstants.HSC_OVERALL_STATUS_TYPE, SpclCareReferenceConstants.HSCOVERALLSTATUSTYPE_SUBMISSION_NOT_REQUIRED) >> 'ref7'
        0 * _

        and:
        returnList.size() == listSize

        where:
        listSize | payer    | isBCBSSCProvider | isProvider | httpUserSession                                                                                                         | mskUserCheck
        5        | 'UHC'    | 0                | 0          | new HttpUserSession(userSecurity: new UserSecurityVO(userID: 'TESTUSER', userGroupID: SpclCareConstants.ROLE_PROVIDER)) | true
        7        | 'UHC'    | 1                | 1          | new HttpUserSession(userSecurity: new UserSecurityVO(userID: 'TESTUSER', userGroupID: 'ADMINISTRATOR'))                 | false
        7        | 'UHC'    | 1                | 1          | new HttpUserSession(userSecurity: new UserSecurityVO(userID: 'TESTUSER'))                                               | false
        7        | 'UHC'    | 1                | 1          | new HttpUserSession()                                                                                                   | false
        7        | 'UHC'    | 1                | 1          | null                                                                                                                    | false
        7        | 'BCBSSC' | 1                | 1          | new HttpUserSession(userSecurity: new UserSecurityVO(userID: 'TESTUSER', userGroupID: SpclCareConstants.ROLE_PROVIDER)) | true
    }

    def "getStatusListDraft"() {
        given:
        List<SelectDataVO> expectedList = [new SelectDataVO(value: SpclCareReferenceConstants.HSCOVERALLSTATUSTYPE_DRAFT, label: 'ref1'),
                                           new SelectDataVO(value: SpclCareReferenceConstants.HSCOVERALLSTATUSTYPE_CANCELLED_DRAFT, label: 'ref2'),
                                           new SelectDataVO(value: SpclCareReferenceConstants.HSCOVERALLSTATUSTYPE_EXPIRED, label: 'ref3')]

        when:
        List<SelectDataVO> returnList = hscController.getStatusListDraft()

        then:
        1 * customerReference.getReferenceDescription(SpclCareNonPersistedFieldConstants.HSC_OVERALL_STATUS_TYPE, SpclCareReferenceConstants.HSCOVERALLSTATUSTYPE_DRAFT) >> 'ref1'
        1 * customerReference.getReferenceDescription(SpclCareNonPersistedFieldConstants.HSC_OVERALL_STATUS_TYPE, SpclCareReferenceConstants.HSCOVERALLSTATUSTYPE_CANCELLED_DRAFT) >> 'ref2'
        1 * customerReference.getReferenceDescription(SpclCareNonPersistedFieldConstants.HSC_OVERALL_STATUS_TYPE, SpclCareReferenceConstants.HSCOVERALLSTATUSTYPE_EXPIRED) >> 'ref3'
        0 * _

        and:
        returnList == expectedList
    }

    def 'test hscQuery'() {
        given:
        QueryProperties queryProperties = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        List<HscVO> hscVOList = [new HscVO(memberID: TEST_MEMBER_ID, hscID: TEST_HSC_ID)]

        when:
        CommonResponse response = hscController.hscQuery(queryProperties)

        then:
        1 * hscHelper.getAuthSearch(queryProperties) >> new CommonResponse().setEmbedded(hscVOList)
        0 * _

        and:
        response.getEmbedded().get(CommonResponse.EMBEDDED) == hscVOList
    }

    def "getHsc"() {
        given:
        HscVO hscVO = new HscVO(hscID: TEST_HSC_ID)

        when:
        CommonResponse response = hscController.getHsc(TEST_HSC_ID)

        then:
        1 * hscHelper.readCascadingSpclCare(TEST_HSC_ID) >> hscVO
        1 * hsc.save(_)
        1 * userHscHistory.saveUserHscHistory(_)
        0 * _

        and:
        response.getEmbedded() == ['_embedded': hscVO]
    }

    def "getRequestingProvider"() {
        given:
        short providerSeqNum = 1
        HscProviderVO requestingProvider = new HscProviderVO(hscID: TEST_HSC_ID, providerSeqNum: providerSeqNum)

        when:
        CommonResponse response = hscController.getRequestingProvider(TEST_HSC_ID, providerSeqNum)

        then:
        1 * hscProvider.read(TEST_HSC_ID, providerSeqNum) >> requestingProvider
        0 * _

        and:
        response.getEmbedded() == ['_embedded': requestingProvider]
    }

    @Unroll
    def "saveRequestingProvider"() {
        given:
        long hscID = 5555L
        long memberID = 5678L
        short providerSeqNum = 1
        String stepperLocation = SpclCareReferenceConstants.AUTH_STEPPER_REQUESTING_PROVIDER
        HscProviderVO requestingProvider = new HscProviderVO(hscID: TEST_HSC_ID, providerSeqNum: providerSeqNum)
        HscVO hscVO = new HscVO(hscID: hscID, memberID: memberID)
       List<MemberCoverageVO> memberCoverageVOList = [new MemberCoverageVO()]

        when:
        CommonResponse response = hscController.saveRequestingProvider(requestingProvider)

        then:
        1 * hsc.read(_) >> hscVO
        1 * hscHelper.isEandI(TEST_HSC_ID) >> isEandIMember
        1 * hscProvider.saveProviderAndRole(requestingProvider, HsrReferenceConstants.PROVIDER_ROLE_REQUESTING) >> requestingProvider
        1 * hscProvider.listByHscWithRoles(TEST_HSC_ID) >> []
        FeatureFlagUtility.getManager().isActive(SpclCareFeatureFlagConstants.DRAFT_JBPM_CALLS) >> false
        1 * hscHelper.autoTrackDraft(TEST_HSC_ID, stepperLocation)

        and:
        response.getEmbedded() == ['_embedded': requestingProvider]
        requestingProvider.requestingProviderInd

        where:
        isEandIMember | authTypeCheck | authType                                                     | deleteProviders
       // false         | 0             | SpclCareReferenceConstants.AUTH_TYPE_INJECTABLE_CHEMOTHERAPY | 0
        true          | 1             | SpclCareReferenceConstants.AUTH_TYPE_INJECTABLE_CHEMOTHERAPY | 1
        true          | 1             | SpclCareReferenceConstants.AUTH_TYPE_SPECIALTY_PHARMACY      | 0
    }

   @Unroll
    def "saveRequestingProvider with Par, Non-Par Indicator"() {
        given:
        long hscID = 5555L
        long memberID = 5678L
        short providerSeqNum = 1
        boolean featureFlag = true
        String parNonPar = '2'
        String stepperLocation = SpclCareReferenceConstants.AUTH_STEPPER_REQUESTING_PROVIDER
        HscProviderVO requestingProvider = new HscProviderVO(hscID: TEST_HSC_ID, providerSeqNum: providerSeqNum)
        HscVO hscVO = new HscVO(hscID: hscID, memberID: memberID)
        List<MemberCoverageVO> memberCoverageVOList = [new MemberCoverageVO()]
        ProviderDetails providerDetails = new ProviderDetails()

        when:
        CommonResponse response = hscController.saveRequestingProvider(requestingProvider)

        then:
        1 * hscHelper.isEandI(TEST_HSC_ID) >> isEandIMember
        1 * hscProvider.saveProviderAndRole(requestingProvider, HsrReferenceConstants.PROVIDER_ROLE_REQUESTING) >> requestingProvider
        1 * hscProvider.listByHscWithRoles(TEST_HSC_ID) >> []
        1 * hscHelper.autoTrackDraft(TEST_HSC_ID, stepperLocation)
        1 * hscHelper.isPHTherapyAuthorization(authType) >> true
        1 * hsc.read(TEST_HSC_ID) >> hscVO
        1 * memberCoverage.listByMemberID(_) >> memberCoverageVOList
        1 * hscHelper.getProviderDetails(requestingProvider, memberCoverageVOList?.first()) >> providerDetails
        (1..3) * hscHelper.getAuthType(TEST_HSC_ID) >> authType
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_PROVIDER_DETAILS_FOR_AUTH_TYPE) >> featureFlag
        (0..1) * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_PROVIDER_BLOCKING_RULES) >> featureFlag
        (0..1) * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_MAP_UNIQUE_UNET_CONTRACT_LIST) >> featureFlag
        1 * hscHelper.isInOrOutOfNetwork(_,_) >> parNonPar
        //0 * _

        and:
        response.getEmbedded() == ['_embedded': requestingProvider]
        requestingProvider.requestingProviderInd

        where:
        isEandIMember | authTypeCheck | authType                                                     | deleteProviders
        true          | 1             | SpclCareReferenceConstants.AUTH_TYPE_PHYSICAL_THERAPY        | 0
        true          | 1             | SpclCareReferenceConstants.AUTH_TYPE_SPEECH_THERAPY          | 1
        true          | 1             | SpclCareReferenceConstants.AUTH_TYPE_OCCUPATIONAL_THERAPY    | 0
    }

    def "saveRequestingProvider - RF and SJ"() {
        given:
        long hscID = 5555L
        long memberID = 5678L
        short providerSeqNum = 1
        String authType
        boolean featureFlag = false
        String stepperLocation = SpclCareReferenceConstants.AUTH_STEPPER_REQUESTING_PROVIDER
        HscProviderVO requestingProvider = new HscProviderVO(hscID: TEST_HSC_ID, providerSeqNum: providerSeqNum)
        List<MemberCoverageVO> memberCoverageVOList = [new MemberCoverageVO()]
        HscVO hscVO = new HscVO(hscID: hscID, memberID: memberID)

        when:
        CommonResponse response = hscController.saveRequestingProvider(requestingProvider)

        then:
        1 * hscHelper.isEandI(TEST_HSC_ID) >> false
        1 * hscProvider.saveProviderAndRole(requestingProvider, HsrReferenceConstants.PROVIDER_ROLE_REQUESTING) >> requestingProvider
        1 * hscProvider.listByHscWithRoles(TEST_HSC_ID) >> [
                new HscProviderVO(
                        hscID: TEST_HSC_ID,
                        providerSeqNum: providerSeqNum,
                        hscProviderRoleVOs: [new HscProviderRoleVO(providerRole: HsrReferenceConstants.PROVIDER_ROLE_REQUESTING),
                                             new HscProviderRoleVO(providerRole: HsrReferenceConstants.PROVIDER_ROLE_SERVICING)])
        ]
        FeatureFlagUtility.getManager().isActive(SpclCareFeatureFlagConstants.DRAFT_JBPM_CALLS) >> false
        1 * hscHelper.autoTrackDraft(TEST_HSC_ID, stepperLocation)
        0 * hscHelper.isPHTherapyAuthorization(authType) >> true
        1 * hsc.read(TEST_HSC_ID) >> hscVO
        1 * memberCoverage.listByMemberID(_) >> memberCoverageVOList
        (1..3) * hscHelper.getAuthType(TEST_HSC_ID) >> authType
        2 * featureFlagManager.isActive(_) >> false
        0 * _

        and:
        response.getEmbedded() == ['_embedded': requestingProvider]
        requestingProvider.requestingProviderInd
        requestingProvider.servicingProviderInd
    }

    def "saveServicingProvider Feature Flag enabled with HscSpecialtyProcedureVO"() {
        given:
        short providerSeqNum = 1
        String stepperLocation = SpclCareReferenceConstants.AUTH_STEPPER_SERVICING_PROVIDER
        HscProviderVO servicingProvider = new HscProviderVO(hscID: TEST_HSC_ID, providerSeqNum: providerSeqNum)
        boolean featureFlag = true
        long testProcedureID = 1234
        String testDrugClass = "testDrugClass"
        String testProcedureCode = "testProcedureCode"
        String testProcedureBrandName = "testProcedureBrandName"
        SpecialtyProceduresViewVO specialtyProceduresViewVO = new SpecialtyProceduresViewVO()
        specialtyProceduresViewVO.setSpecialtyProcedureID(1234)
        specialtyProceduresViewVO.setDrugClass("testDrugClass")
        specialtyProceduresViewVO.setProcedureCode("testProcedureCode")
        specialtyProceduresViewVO.setProcedureBrandName("testBrandName")

        HscVO hscVO = new HscVO()
        HscSpecialtyProcedureVO hscSpecialtyProcedureVO = new HscSpecialtyProcedureVO()
        hscSpecialtyProcedureVO.setSpecialtyProcedureID(testProcedureID)
        hscVO.setHscSpecialtyProcedureVO(hscSpecialtyProcedureVO)

        when:
        CommonResponse response = hscController.saveServicingProvider(servicingProvider)

        then:
        1 * hscProvider.saveProviderAndRole(servicingProvider, HsrReferenceConstants.PROVIDER_ROLE_SERVICING) >> servicingProvider
        1 * hscProvider.listByHscWithRoles(TEST_HSC_ID) >> []
        FeatureFlagUtility.getManager().isActive(SpclCareFeatureFlagConstants.DRAFT_JBPM_CALLS) >> false
        1 * hscHelper.autoTrackDraft(TEST_HSC_ID, stepperLocation)
        1 * featureFlagManager.isActive(_) >> featureFlag
        1 * hscHelper.checkServicingProviderExceptionRequest(*_)
        0 * _

        and:
        response.getEmbedded() == ['_embedded': servicingProvider]
        servicingProvider.servicingProviderInd
    }

    def "saveServicingProvider Feature Flag disabled with HscSpecialtyProcedureVO"() {
        given:
        short providerSeqNum = 1
        String stepperLocation = SpclCareReferenceConstants.AUTH_STEPPER_SERVICING_PROVIDER
        HscProviderVO servicingProvider = new HscProviderVO(hscID: TEST_HSC_ID, providerSeqNum: providerSeqNum)
        boolean featureFlag = false
        long testProcedureID = 1234
        String testDrugClass = "testDrugClass"
        String testProcedureCode = "testProcedureCode"
        String testProcedureBrandName = "testProcedureBrandName"
        SpecialtyProceduresViewVO specialtyProceduresViewVO = new SpecialtyProceduresViewVO()
        specialtyProceduresViewVO.setSpecialtyProcedureID(1234)
        specialtyProceduresViewVO.setDrugClass("testDrugClass")
        specialtyProceduresViewVO.setProcedureCode("testProcedureCode")
        specialtyProceduresViewVO.setProcedureBrandName("testBrandName")

        HscVO hscVO = new HscVO()
        HscSpecialtyProcedureVO hscSpecialtyProcedureVO = new HscSpecialtyProcedureVO()
        hscSpecialtyProcedureVO.setSpecialtyProcedureID(testProcedureID)
        hscVO.setHscSpecialtyProcedureVO(hscSpecialtyProcedureVO)

        when:
        CommonResponse response = hscController.saveServicingProvider(servicingProvider)

        then:
        1 * hscProvider.saveProviderAndRole(servicingProvider, HsrReferenceConstants.PROVIDER_ROLE_SERVICING) >> servicingProvider
        1 * hscProvider.listByHscWithRoles(TEST_HSC_ID) >> []
        FeatureFlagUtility.getManager().isActive(SpclCareFeatureFlagConstants.DRAFT_JBPM_CALLS) >> false
        1 * hscHelper.autoTrackDraft(TEST_HSC_ID, stepperLocation)
        1 * featureFlagManager.isActive(_) >> featureFlag
        0 * _

        and:
        response.getEmbedded() == ['_embedded': servicingProvider]
        servicingProvider.servicingProviderInd
    }

    def "saveServicingProvider Feature Flag enabled with HscSpecialtyProcedureVO and jbpm exception"() {
        given:
        short providerSeqNum = 1
        String stepperLocation = SpclCareReferenceConstants.AUTH_STEPPER_SERVICING_PROVIDER
        HscProviderVO servicingProvider = new HscProviderVO(hscID: TEST_HSC_ID, providerSeqNum: providerSeqNum)
        boolean featureFlag = true
        long testProcedureID = 1234
        String testDrugClass = "testDrugClass"
        String testProcedureCode = "testProcedureCode"
        String testProcedureBrandName = "testProcedureBrandName"
        SpecialtyProceduresViewVO specialtyProceduresViewVO = new SpecialtyProceduresViewVO()
        specialtyProceduresViewVO.setSpecialtyProcedureID(1234)
        specialtyProceduresViewVO.setDrugClass("testDrugClass")
        specialtyProceduresViewVO.setProcedureCode("testProcedureCode")
        specialtyProceduresViewVO.setProcedureBrandName("testBrandName")

        HscVO hscVO = new HscVO()
        HscSpecialtyProcedureVO hscSpecialtyProcedureVO = new HscSpecialtyProcedureVO()
        hscSpecialtyProcedureVO.setSpecialtyProcedureID(testProcedureID)
        hscVO.setHscSpecialtyProcedureVO(hscSpecialtyProcedureVO)

        when:
        CommonResponse response = hscController.saveServicingProvider(servicingProvider)

        then:
        1 * hscProvider.saveProviderAndRole(servicingProvider, HsrReferenceConstants.PROVIDER_ROLE_SERVICING) >> servicingProvider
        1 * hscProvider.listByHscWithRoles(TEST_HSC_ID) >> []
        FeatureFlagUtility.getManager().isActive(SpclCareFeatureFlagConstants.DRAFT_JBPM_CALLS) >> false
        1 * hscHelper.autoTrackDraft(TEST_HSC_ID, stepperLocation)
        1 * featureFlagManager.isActive(_) >> featureFlag
        1 * hscHelper.checkServicingProviderExceptionRequest(*_) >> {
            throw new UhgRuntimeException(SpclCareMessages.ERR_SYS_UNAVAILABLE)
        }
        0 * _

        and:
        thrown(UhgRuntimeException)
    }

    def "saveServicingProvider Feature Flag disabled with HscSpecialtyProcedureVO and JBPM exception"() {
        given:
        short providerSeqNum = 1
        String stepperLocation = SpclCareReferenceConstants.AUTH_STEPPER_SERVICING_PROVIDER
        HscProviderVO servicingProvider = new HscProviderVO(hscID: TEST_HSC_ID, providerSeqNum: providerSeqNum)
        boolean featureFlag = false
        long testProcedureID = 1234
        String testDrugClass = "testDrugClass"
        String testProcedureCode = "testProcedureCode"
        String testProcedureBrandName = "testProcedureBrandName"
        SpecialtyProceduresViewVO specialtyProceduresViewVO = new SpecialtyProceduresViewVO()
        specialtyProceduresViewVO.setSpecialtyProcedureID(1234)
        specialtyProceduresViewVO.setDrugClass("testDrugClass")
        specialtyProceduresViewVO.setProcedureCode("testProcedureCode")
        specialtyProceduresViewVO.setProcedureBrandName("testBrandName")

        HscVO hscVO = new HscVO()
        HscSpecialtyProcedureVO hscSpecialtyProcedureVO = new HscSpecialtyProcedureVO()
        hscSpecialtyProcedureVO.setSpecialtyProcedureID(testProcedureID)
        hscVO.setHscSpecialtyProcedureVO(hscSpecialtyProcedureVO)
        jbpmHelper.sendStepperContinueSignal(*_) >> {
            throw new UhgRuntimeException(SpclCareMessages.ERR_SYS_UNAVAILABLE)
        }

        when:
        CommonResponse response = hscController.saveServicingProvider(servicingProvider)

        then:
        1 * hscProvider.saveProviderAndRole(servicingProvider, HsrReferenceConstants.PROVIDER_ROLE_SERVICING) >> servicingProvider
        1 * hscProvider.listByHscWithRoles(TEST_HSC_ID) >> []
        FeatureFlagUtility.getManager().isActive(SpclCareFeatureFlagConstants.DRAFT_JBPM_CALLS) >> false
        1 * hscHelper.autoTrackDraft(TEST_HSC_ID, stepperLocation)
        1 * featureFlagManager.isActive(_) >> featureFlag
        0 * _

        and:
        response.getEmbedded() == ['_embedded': servicingProvider]
        servicingProvider.servicingProviderInd
        notThrown(UhgRuntimeException)
    }

    def "saveServicingProvider - RF and SJ"() {
        given:
        short providerSeqNum = 1
        String stepperLocation = SpclCareReferenceConstants.AUTH_STEPPER_SERVICING_PROVIDER
        HscProviderVO servicingProvider = new HscProviderVO(hscID: TEST_HSC_ID, providerSeqNum: providerSeqNum)

        when:
        CommonResponse response = hscController.saveServicingProvider(servicingProvider)

        then:
        1 * hscProvider.saveProviderAndRole(servicingProvider, HsrReferenceConstants.PROVIDER_ROLE_SERVICING) >> servicingProvider
        1 * hscProvider.listByHscWithRoles(TEST_HSC_ID) >> [
                new HscProviderVO(
                        hscID: TEST_HSC_ID,
                        providerSeqNum: providerSeqNum,
                        hscProviderRoleVOs: [new HscProviderRoleVO(providerRole: HsrReferenceConstants.PROVIDER_ROLE_REQUESTING),
                                             new HscProviderRoleVO(providerRole: HsrReferenceConstants.PROVIDER_ROLE_SERVICING)])
        ]
        FeatureFlagUtility.getManager().isActive(SpclCareFeatureFlagConstants.DRAFT_JBPM_CALLS) >> false
        1 * hscHelper.autoTrackDraft(TEST_HSC_ID, stepperLocation)
        1 * featureFlagManager.isActive(_)
        0 * _

        and:
        response.getEmbedded() == ['_embedded': servicingProvider]
        servicingProvider.servicingProviderInd
        servicingProvider.requestingProviderInd
    }

    def "saveRequestDetails"() {
        given:
        AuthRequestDetailsDO authRequestDetailsDO = new AuthRequestDetailsDO(hscID: TEST_HSC_ID, memberID: 5555L)

        when:
        CommonResponse response = hscController.saveRequestDetails(authRequestDetailsDO)

        then:
        1 * hscHelper.saveRequestDetails(authRequestDetailsDO)
        0 * _

        and:
        response.getEmbedded() == ['_embedded': authRequestDetailsDO]
    }

    def "saveClinicalStatus"() {
        given:
        HscAssessmentVO hscAssessmentVO = new HscAssessmentVO(hscID: TEST_HSC_ID, assessmentID: 5555L)

        when:
        CommonResponse response = hscController.saveClinicalStatus(hscAssessmentVO)

        then:
        1 * hscAssessment.save(hscAssessmentVO)
        0 * _

        and:
        response.getEmbedded() == ['_embedded': hscAssessmentVO]
    }

    def "saveRegimen"() {
        given:
        RegimenSelectionDO regimenSelectionDO = new RegimenSelectionDO(hscID: TEST_HSC_ID, diseaseTraversalID: 5555L)

        when:
        CommonResponse response = hscController.saveRegimen(regimenSelectionDO)

        then:
        1 * hscHelper.saveRegimenSelectionDetails(regimenSelectionDO) >> regimenSelectionDO
        0 * _

        and:
        response.getEmbedded() == ['_embedded': regimenSelectionDO]
    }

    def "saveRequestingContactDetails"() {
        given:
        HscFollowUpContactVO contactVO = new HscFollowUpContactVO(hscID: TEST_HSC_ID)

        when:
        CommonResponse response = hscController.saveRequestingContactDetails(contactVO)

        then:
        1 * hscFollowUpContact.save(contactVO)
        0 * _

        and:
        response.getEmbedded() == ['_embedded': contactVO]
    }

    def "getHscAndMemberQuery"() {
        given:
        QueryProperties qp = new QueryProperties(filterType: QueryProperties.FilterType.IS_FILTERING,
                queryFilters: [new QueryFilter(FieldConstants.HSCID, TEST_HSC_ID),
                               new QueryFilter(FieldConstants.MEMBERID, 5555L)])
        CommonResponse memberResponse = new CommonResponse()

        when:
        CommonResponse response = hscController.getHscAndMemberQuery(qp)

        then:
        1 * hscSearch.getHscAndMember(qp) >> memberResponse
        0 * _

        and:
        response == memberResponse
    }

    def "getHscStatus"() {
        given:
        CommonResponse memberResponse = new CommonResponse()

        when:
        CommonResponse response = hscController.getHscStatus(TEST_HSC_ID)

        then:
        1 * hscSearch.getHsc(TEST_HSC_ID) >> memberResponse
        0 * _

        and:
        response == memberResponse
    }

    def "getHistoricalAuthSummary"() {
        given:
        QueryProperties qp = new QueryProperties(filterType: QueryProperties.FilterType.IS_FILTERING,
                queryFilters: [new QueryFilter(FieldConstants.HSCID, TEST_HSC_ID),
                               new QueryFilter(FieldConstants.MEMBERID, 5555L)])
        CommonResponse memberResponse = new CommonResponse()

        when:
        CommonResponse response = hscController.getHistoricalAuthSummary(qp)

        then:
        1 * hscSummary.readHistoricalAuthSummary(qp) >> memberResponse
        0 * _

        and:
        response == memberResponse
    }

    def "getHistoricalAuthDetail"() {
        given:
        QueryProperties qp = new QueryProperties(filterType: QueryProperties.FilterType.IS_FILTERING,
                queryFilters: [new QueryFilter(FieldConstants.HSCID, TEST_HSC_ID),
                               new QueryFilter(FieldConstants.MEMBERID, 5555L)])
        CommonResponse histAuthDetailResposne = new CommonResponse()

        when:
        CommonResponse response = hscController.getHistoricalAuthDetail(qp)

        then:
        1 * hscDetail.getHistoricalAuthDetail(qp) >> histAuthDetailResposne
        0 * _

        and:
        response == histAuthDetailResposne
    }

    @RequestMapping(path = "/hsc/historyDetail/query", method = RequestMethod.POST)
    @ResponseBody
    CommonResponse getHistoricalAuthDetail(@RequestBody QueryProperties query) {
        hscDetail.getHistoricalAuthDetail(query)
    }

    def "saveCustomRegimen"() {
        given:
        CustomRegimenDO customRegimenDO = new CustomRegimenDO(hscID: TEST_HSC_ID)
        List<HscServiceVO> hscServiceVOS = [new HscServiceVO(hscID: TEST_HSC_ID)]

        when:
        CommonResponse response = hscController.saveCustomRegimen(customRegimenDO)

        then:
        1 * hscHelper.saveCustomRegimenDetails(customRegimenDO) >> customRegimenDO
        1 * hscService.listServiceAndFacility(customRegimenDO.hscID, true) >> hscServiceVOS
        0 * _

        and:
        response.getEmbedded() == ['_embedded': customRegimenDO]
        customRegimenDO.getHscServiceVOs() == hscServiceVOS
    }

    def "saveSupportiveCareRegimen"() {
        given:
        SupportiveCareRegimenDO supportiveCareRegimenDO = new SupportiveCareRegimenDO(hscID: TEST_HSC_ID)

        when:
        CommonResponse response = hscController.saveSupportiveCareRegimen(supportiveCareRegimenDO)

        then:
        1 * hscHelper.saveSupportiveCareRegimenDetails(supportiveCareRegimenDO) >> supportiveCareRegimenDO
        0 * _

        and:
        response.getEmbedded() == ['_embedded': supportiveCareRegimenDO]
    }

    def "getHscComponentStatus"() {
        given:
        List<HscComponentStatusVO> hscComponentStatusVOS = [new HscComponentStatusVO(hscID: TEST_HSC_ID)]

        when:
        CommonResponse response = hscController.getHscComponentStatus(TEST_HSC_ID)

        then:
        1 * hscComponentStatus.listByHscID(TEST_HSC_ID) >> hscComponentStatusVOS
        0 * _

        and:
        response.getEmbedded() == ['_embedded': hscComponentStatusVOS]
    }

    @Unroll
    def "saveHscComponentStatus"() {
        given:
        HscComponentStatusVO hscComponentStatusVO = new HscComponentStatusVO(hscID: TEST_HSC_ID, hscComponentType: '5')

        when:
        CommonResponse response = hscController.saveHscComponentStatus(hscComponentStatusVO)

        then:
        1 * hscComponentStatus.read(hscComponentStatusVO.hscID, hscComponentStatusVO.hscComponentType) >> currentStatus
        1 * hscComponentStatus.save(hscComponentStatusVO)
        0 * _

        and:
        response.getEmbedded() == ['_embedded': hscComponentStatusVO]
        hscComponentStatusVO.updateVersion == updateVersion

        where:
        currentStatus                                                                          | updateVersion
        new HscComponentStatusVO(hscID: TEST_HSC_ID, hscComponentType: '5', updateVersion: 10) | 10
        null                                                                                   | 0
        new HscComponentStatusVO(hscID: TEST_HSC_ID, hscComponentType: '5')                    | -1
        new HscComponentStatusVO(hscID: TEST_HSC_ID, hscComponentType: '5', updateVersion: 5)  | 5
    }

    // todo: Delete Me
    def 'deleteHscComponentStatusFromSave'() {
        given:
        HscComponentStatusVO voDel = new HscComponentStatusVO(hscID: TEST_HSC_ID, hscComponentStatusType: '0', hscComponentType: 'componentType')

        when:
        CommonResponse response = hscController.saveHscComponentStatus(voDel)

        then:
        2 * hscComponentStatus.read(voDel.hscID, voDel.hscComponentType) >> voDel
        1 * hscComponentStatus.delete(voDel)
        0 * _

        and:
        response.getEmbedded() == ['_embedded': voDel]
    }

    def 'deleteHscComponentStatus'() {
        given:
        HscComponentStatusVO vo = new HscComponentStatusVO(hscID: TEST_HSC_ID, hscComponentType: '2')

        when:
        CommonResponse response = hscController.deleteHscComponentStatus(vo)

        then:
        1 * hscComponentStatus.read(vo.hscID, vo.hscComponentType) >> vo
        1 * hscComponentStatus.delete(vo)
        0 * _

        and:
        response.getEmbedded() == ['_embedded': vo]
    }

    def "getNPIList"() {
        given:
        List<SelectDataVO> npiList = [new SelectDataVO(value: "test", label: "test label")]

        when:
        List<SelectDataVO> responseList = hscController.getNPIList()

        then:
        1 * hscHelper.getNPIList() >> npiList
        0 * _

        and:
        responseList == npiList
    }

    @Unroll
    def "cancelAuthorization #testCase"() {
        given:
        String cancelReason = '1'
        String cancelReasonResolutionType = '43'
        HscVO hscVO = new HscVO(hscID: TEST_HSC_ID)

        when:
        CommonResponse response = hscController.cancelAuthorization(TEST_HSC_ID, cancelReason)

        then:
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.CANCEL_REASON_DEAD_LOCK) >> cancelReasonDeadLock
        if(cancelReasonDeadLock)
        {
            1 * hsc.read(TEST_HSC_ID) >> hscVO
        } else {
            1 * hsc.readCascadingSpclCare(TEST_HSC_ID) >> hscVO
        }
        1 * hsc.save(_ as HscVO) >> { HscVO saveVO ->
            assert saveVO.hscStatusType == HsrReferenceConstants.HSCSTATUSTYPE_CANCELLED
            assert saveVO.hscStatusReasonType == cancelReason
            assert saveVO == hscVO
        }
        1 * hscHelper.cancelEPARequest(hscVO) >> true
        1 * hsc.logHscAutomatedActivity(SpclCareReferenceConstants.ACTIVITYTYPE_DRAFT_AUTH_CANCELLED, hscVO)
        1 * documentManagerService.deleteAttachmentsByHSC(TEST_HSC_ID)
        (_..1) * cancelSubmittedAuthorization.autoTrackCancelActivity(hscVO,cancelReasonResolutionType)

        and:
        response.getEmbedded() == ['_embedded': hscVO]

        where:
        testCase                | cancelReasonDeadLock
        'featureFlag Enabled'   | true
        'featureFlag Disabled'  | false

    }

    def "checkRegimenDrugException"() {
        given:
        DrugExceptionCheckDO drugExceptionCheckDO = new DrugExceptionCheckDO(hscID: TEST_HSC_ID)

        when:
        CommonResponse response = hscController.checkRegimenDrugException(drugExceptionCheckDO)

        then:
        1 * authorizationRuleHelper.checkRulesForRegimen(drugExceptionCheckDO) >> drugException
        0 * _

        and:
        response.getEmbedded() == ['_embedded': embeddedResponse]

        where:
        drugException                                                           | embeddedResponse
        new TreatmentProcedureAuthorizationRuleVO(treatmentProcAuthRuleID: 123) | new TreatmentProcedureAuthorizationRuleVO(treatmentProcAuthRuleID: 123)
        null                                                                    | null
    }

    def 'saveCommunicationTransaction'() {
        given:
        CommunicationTransactionVO commTransVO = new CommunicationTransactionVO()

        when:
        CommonResponse response = hscController.saveCommunicationTransaction(commTransVO)

        then:
        1 * communicationTransaction.save(commTransVO)
        0 * _

        and:
        response.getEmbedded() == ['_embedded': commTransVO]
    }

    def 'getCommunicationTransaction'() {
        given:
        CommunicationTransactionVO commTransVO = new CommunicationTransactionVO()

        when:
        CommonResponse response = hscController.getCommunicationTransactionByHscID(1234L)

        then:
        1 * communicationTransaction.getByHscID(1234L) >> commTransVO
        0 * _

        and:
        response.getEmbedded() == ['_embedded': commTransVO]
    }

    def 'isSubmissionRequiredWithList'() {
        given:
        List<HscMemberCoverageVO> voList = new ArrayList<>()

        when:
        CommonResponse response = hscController.isSubmissionRequired(voList)

        then:
        1 * hscHelper.isHCAMember(voList)
        0 * _

        and:
        response.getEmbedded() == ['_embedded': false]
    }

    def 'isSubmissionRequiredWithString'() {
        given:
        String authorizationType = '1'
        String taxId = '349954'

        when:
        CommonResponse response = hscController.isSubmissionRequired(authorizationType, taxId)

        then:
        1 * hscHelper.isHscSubmissionRequired(authorizationType, taxId)
        0 * _

        and:
        response.getEmbedded() == ['_embedded': false]
    }

    def 'callRulesEngine'() {
        given:
        GenericRuleServiceResponse receivedResponse = new GenericRuleServiceResponse(returnDecisionValueType: 'test')
        MemberVO fakeMember = new MemberVO()
        HscProviderVO fakeProvider = new HscProviderVO()
        HscAttributeVO returnedVO = new HscAttributeVO()
        RuleEngineDetailsDO successRuleDO = new RuleEngineDetailsDO(
                hscID: TEST_HSC_ID,
                hscAttributeType: 'attributeType',
                memberVO: fakeMember,
                hscProviderVO: fakeProvider,
                ruleServiceType: 'Type',
                ruleServiceSubType: 'subType'
        )

        when:
        CommonResponse response = hscController.callRulesEngine(successRuleDO)

        then:
        1 * genericRuleServiceProcessor.processGenericRuleService(successRuleDO.memberVO, successRuleDO.hscProviderVO, successRuleDO.ruleServiceType, successRuleDO.ruleServiceSubType) >> receivedResponse
        1 * hscAttribute.read(successRuleDO.hscID, successRuleDO.hscAttributeType) >> returnedVO
        1 * hscAttribute.save(returnedVO)
        0 * _

        and:
        response.getEmbedded() == ['_embedded': returnedVO]
    }

    def 'deleteRegimen'() {
        when:
        CommonResponse response = hscController.deleteRegimen(TEST_HSC_ID)

        then:
        1 * hsc.read(TEST_HSC_ID) >> vo
        1 * hsc.save(vo)
        1 * hscService.deleteServicesForHsc(TEST_HSC_ID)
        0 * _

        and:
        response.getEmbedded() == ['_embedded': vo]
        vo.diseaseTraversalID == 0
        vo.reqTreatmentRegimenVersionID == 0

        where:
        type | vo
        '1'  | new HscVO(diseaseTraversalID: 0, reqTreatmentRegimenVersionID: 0)
        '2'  | new HscVO(diseaseTraversalID: 2, reqTreatmentRegimenVersionID: 2)
    }


    def 'getCloneAuthDetails'() {
        given:
        SpecialtyProceduresViewVO specvo = new SpecialtyProceduresViewVO()
        ProcedureViewVO procvo = new ProcedureViewVO()
        String authType = '4'

        when:

        CommonResponse response = hscController.getCloneAuthDetails(TEST_HSC_ID, authType)

        then:
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_PROC_BRAND_REFACTOR) >> enableProcBrandRefactor
        if(enableProcBrandRefactor)
        {
            1 * hscClone.getCloneAuthDetailsProcedure(TEST_HSC_ID, authType) >> procvo
        } else {
            1 * hscClone.getCloneAuthDetails(TEST_HSC_ID, authType) >> specvo
        }
        0 * _

        and:
        if(enableProcBrandRefactor)
        {
            response.getEmbedded() == ['_embedded': procvo]
        } else {
            response.getEmbedded() == ['_embedded': specvo]
        }

        where: enableProcBrandRefactor << [ false, true ]
    }

    def 'cloneAuthorization'() {
        given:
        String authType = 'authType'
        String cancerType = 'cancerType'
        HscCloningDO returnDO = new HscCloningDO()
        CloneRequestDO cloneRequestDO = new CloneRequestDO()
        boolean isFromAuthNotReqPopup = false
        int customerId = 1
        System.setProperty(MultiPayerConstants.APPROVAL_TYPE, "${customerId}")

        when:
        CommonResponse response = hscController.cloneAuthorizations(cloneRequestDO)

        then:
        1 * hscClone.cloneAuthorization(customerId, cloneRequestDO) >> returnDO
        0 * _

        and:
        response.getEmbedded() == ['_embedded': returnDO]
    }

    def 'cancel submitted authorization'() {
        given:
        HscVO hscVO = new HscVO(hscID: TEST_HSC_ID)
        List<ItemTask> itemTaskList = [new ItemTask(itemTaskId: 1),new ItemTask(itemTaskId: 1)]

        CancelSubmittedAuthDO cancelSubmittedAuthDO = new CancelSubmittedAuthDO()
        cancelSubmittedAuthDO.setHscID(TEST_HSC_ID)
        cancelSubmittedAuthDO.setCancelReason('1')
        cancelSubmittedAuthDO.setDecisionReason('1')
        cancelSubmittedAuthDO.setActivityResolutionReason('94')
        cancelSubmittedAuthDO.setItemTaskCriteriaResponseList(itemTaskList)

        when:
        CommonResponse response = hscController.cancelWorkQueueAuth(cancelSubmittedAuthDO)

        then:
        1 * cancelSubmittedAuthorization.cancelRequest(cancelSubmittedAuthDO) >> new CommonResponse().setEmbedded(hscVO)

        and:
        response.getEmbedded() == ['_embedded': hscVO]
    }

    def 'reopen closed authorization'() {
        given:

        HscVO hscVO = new HscVO(hscID: TEST_HSC_ID)
        List<ItemTaskCriteriaResponse> itemTaskCriteriaResponseList = [new ItemTaskCriteriaResponse(itemTaskId: 1), new ItemTaskCriteriaResponse(itemTaskId: 1)]

        ReopenAuthDO reopenAuthDO = new ReopenAuthDO()
        reopenAuthDO.setUserID('testID')
        reopenAuthDO.setReopenReason('1')
        reopenAuthDO.setHscID(TEST_HSC_ID)
        reopenAuthDO.setActivityResolutionReason('94')
        reopenAuthDO.setItemTaskCriteriaResponseList(itemTaskCriteriaResponseList)
        boolean featureFlag = false

        when:
        CommonResponse response = hscController.reopenAuth(reopenAuthDO)

        then:
        1 * featureFlagManager.isActive(_) >> featureFlag
        1 * reopenAuthorization.reopenRequest(reopenAuthDO) >> hscVO

        and:
        response.getEmbedded() == ['_embedded': hscVO]
    }

    def 'get parsed drug data for drug dosage rounding'(){
        given:
        DrugRoundingRequestDO drugRoundingRequestDO = new DrugRoundingRequestDO(hscID: TEST_HSC_ID)
        DrugRoundingResponseDO drugRoundingResponseDO = new DrugRoundingResponseDO()

        when:
        CommonResponse response = hscController.drugRounding(drugRoundingRequestDO)

        then:
        1 * drugRounding.drugRoundingParsing(1, drugRoundingRequestDO) >> drugRoundingResponseDO

        and:
        response.getEmbedded() == ['_embedded': drugRoundingResponseDO]
    }

    def 'test checkDrugOnPocList' () {
        given:
        HscSpecialtyProcedureVO hscSpecialtyProcedureVO = new HscSpecialtyProcedureVO()

        when:
        CommonResponse response = hscController.checkDrugOnPocList(hscSpecialtyProcedureVO)

        then:
        1 * hscHelper.doesSpecialtyDrugExistOnServicingProviderSOCList(*_) >> true
        0 * _

        and:
        response.embedded.get("_embedded") == true;
    }

    def 'test checkDrugOnMseList' () {
        given:
        HscSpecialtyProcedureVO hscSpecialtyProcedureVO = new HscSpecialtyProcedureVO()

        when:
        CommonResponse response = hscController.checkDrugOnMseList(hscSpecialtyProcedureVO)

        then:
        1 * hscHelper.doesSpecialtyDrugExistOnMSEList(*_) >> true
        0 * _

        and:
        response.embedded.get("_embedded") == true;
    }

    def 'checkRXClaimAndPA feature flag disabled'(){
        given:

        MemberVO memberVO = new MemberVO(memberID: TEST_HSC_ID, hscID: TEST_HSC_ID)
        String authType = "4"
        GenerateHscDO generateHscDO = new GenerateHscDO(memberVO: memberVO, authType: authType)
        boolean featureFlag = false

        when:
        Boolean checkPaAndClaim = hscController.checkRXClaimAndPA(generateHscDO)
        then:
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.CHECK_RX_CLAIM_PA) >> featureFlag
        0 *_
    }

    def 'checkRXClaimAndPA feature flag enabled'(){
        given:

        MemberVO memberVO = new MemberVO(memberID: TEST_HSC_ID, hscID: TEST_HSC_ID)
        String authType = "4"
        GenerateHscDO generateHscDO = new GenerateHscDO(memberVO: memberVO, authType: authType)
        boolean featureFlag = true

        when:
        Boolean checkPaAndClaim = hscController.checkRXClaimAndPA(generateHscDO)
        then:
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.CHECK_RX_CLAIM_PA) >> featureFlag
        1 * hscHelper.checkRXClaimandPA(generateHscDO) >> true
        0 *_
    }

    def 'getCustomReasons'(){
        given:
        long hscID = 1234
        HscCustomReasonVO hscCustomReasonVO = new HscCustomReasonVO(hscID: hscID)

        when:
        CommonResponse response = hscController.getCustomReasons(hscID)

        then:
        1 * hscHelper.getHscCustomReasons(hscID) >> [hscCustomReasonVO]

        and:
        response.getEmbedded() == ['_embedded': [hscCustomReasonVO]]
    }

    def 'saveHscAttributeVO'(){
        given:
        long hscId = 1234
        String typeId = '119'
        HscAttributeVO hscAttributeVO = new HscAttributeVO(hscID: hscId, hscAttributeType: typeId, hscAttributeValue: "test delete")

        when:
        CommonResponse response = hscController.saveHscAttributeVO(hscAttributeVO)

        then:
        1 * hscHelper.saveHscAttribute(_ as HscAttributeVO) >> hscAttributeVO

        and:
        response.getEmbedded() == ['_embedded': hscAttributeVO]
    }

    def 'deleteHscAttributeVO'(){
        given:
        long hscId = 1234
        String typeId = '119'
        HscAttributeVO hscAttributeVO = new HscAttributeVO(hscID: hscId, hscAttributeType: typeId, hscAttributeValue: "test delete")

        when:
        CommonResponse response = hscController.deleteHscAttributeVO(hscId, typeId)

        then:
        1 * hscHelper.deleteHscAttribute(hscId, typeId) >> hscAttributeVO

        and:
        response.getEmbedded() == ['_embedded': hscAttributeVO]
    }

    @Unroll
    def 'callRulesPreHSC - #sheetName'() {
        given:
        HscAttributeVO hscAttributeVO1 = new HscAttributeVO(hscAttributeType: SpclCareReferenceConstants.HSCATTRIBUTETYPE_AUTHORIZATION_TYPE, hscAttributeValue: SpclCareReferenceConstants.AUTH_TYPE_SPECIALTY_PHARMACY)
        HscAttributeVO hscAttributeVO2 = new HscAttributeVO(hscAttributeType: SpclCareReferenceConstants.HSCATTRIBUTETYPE_AUTHORIZATION_START_DATE, hscAttributeValue: '2021-08-01T00:00:00.000Z')
        List<HscAttributeVO> hscAttributeVOList = new ArrayList<>()
        hscAttributeVOList.add(hscAttributeVO1)
        hscAttributeVOList.add(hscAttributeVO2)
        HscSignal hscSignal = new HscSignal()
        hscSignal.hscAttributeVOs.addAll(hscAttributeVOList)
        HscSpecialtyProcedureSignal hscSpecialtyProcedureSignal = new HscSpecialtyProcedureSignal(procedureCode: "J7318", procedureBrandName: "Durolane&reg;")
        hscSignal.setHscSpecialtyProcedureVO(hscSpecialtyProcedureSignal)
        StepperSignal stepperSignal = new StepperSignal(memberSignal: new MemberSignal(customerID: 1, memberCoverageVOs: [new MemberCoverageSignal(productCategoryType: '0')]), hscSignal: hscSignal)
        DroolsRuleRequest droolsRuleRequest = new DroolsRuleRequest(sheetName: sheetName, stepperSignal: stepperSignal)

        when:
        CommonResponse response = hscController.callRulesPreHSC(droolsRuleRequest)

        then:
        1 * customer.read(_) >> new CustomerVO(customerID: 1, organizationID: 1)
        1 * jbpmHelper.callRules(_) >> rulesResponse

        and:
        response.embedded.values()[0]

        where:
        sheetName                   | rulesResponse
        'Self-Administered Drug'    | new ArrayList<>(["{\"self_administered_drug\":true}"])
        'Buy And Bill'              | new ArrayList<>(["{\"buy_and_bill\":true}"])
    }

    def "saveHscCustomReason"(){

        given:
        HscCustomReasonDO hscCustomReasonDO = new HscCustomReasonDO(hscID: 1, changeUserID: changeUserId)
        Session session = new HttpUserSession()
        UserSecurityVO securityVO = new UserSecurityVO()
        securityVO.setUserID("John Cena")
        session.setUserSecurity(securityVO)
        sessionThreadLocal.setSession(session)


        when:
        CommonResponse commonResponse = hscController.saveHscCustomReason(hscCustomReasonDO)

        then:
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_CREDENTIAL_VALIDATION) >> FF
        _ * hsc.read(1) >> new HscVO(hscID: 1, hscStatusType: hscStatusType)
        _ * hscHelper.saveHscCustomReason(hscCustomReasonDO) >> true

        and:
        commonResponse.embedded.size() == result

        where:
        testcase | FF       | changeUserId                                                       | hscStatusType | result
        0        | true     | "SYSTEM"                                                           | "5"           | 1
        1        | true     | "SYSTEM"                                                           | "1"           | 0
        2        | true     | "John Cena"                                                        | "5"           | 1
        3        | true     | "John Cena"                                                        | "1"           | 1
        4        | true     | "Rock"                                                             | "1"           | 0
        5        | true     | "Rock"                                                             | "5"           | 0
        6        | false    | "SYSTEM"                                                           | "5"           | 1
        7        | false    | "John Cena"                                                        | "5"           | 1
    }

    def "successful cancel authorization with deadlock ON/OFF, cancel EPA true, cloud mirgration true/false"() {
        given:
        String cancelReason = '1'
        String cancelReasonResolutionType = '43'
        HscVO hscVO = new HscVO(hscID: TEST_HSC_ID)
        when:
        CommonResponse commonResponse=hscController.cancelAuthorization(TEST_HSC_ID, cancelReason)
        then:
        featureFlagManager.isActive(SpclCareFeatureFlagConstants.CANCEL_REASON_DEAD_LOCK) >> deadLock
        if (deadLock) {
            1 * hsc.read(TEST_HSC_ID) >> hscVO
        } else {
            1 * hsc.readCascadingSpclCare(TEST_HSC_ID) >> hscVO
        }
        1 * hscHelper.cancelEPARequest(hscVO) >> true
        1 * hsc.save(hscVO)
        1 * hsc.logHscAutomatedActivity(SpclCareReferenceConstants.ACTIVITYTYPE_DRAFT_AUTH_CANCELLED,hscVO)
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_FDS_CLOUD_MIGRATION) >> cloudMigration
        if (cloudMigration) {
            1 * documentManagerService.deleteDocumentsByHSC(TEST_HSC_ID)
        } else {
            1 * documentManagerService.deleteAttachmentsByHSC(TEST_HSC_ID)
        }
        1 * cancelSubmittedAuthorization.autoTrackCancelActivity(hscVO, _ as String)

        commonResponse.getEmbedded() == new CommonResponse().setEmbedded(hscVO).getEmbedded()

        where:
        testCases | deadLock | cloudMigration
        0         | true     | true
        1         | false    | false

    }

    def "successful cancel authorization with deadlock ON/OFF, cancel EPA false, cloud mirgration true/false"() {
        given:
        String cancelReason = '1'
        HscVO hscVO = new HscVO(hscID: TEST_HSC_ID)
        CommonResponse commonResponseStubbed = new CommonResponse()
        commonResponseStubbed.setEmbedded(hscVO)
        commonResponseStubbed.setErrorExists(true)
        commonResponseStubbed.addGlobalMessages(SystemGlobalMessages.ERR_GENERAL_UNKNOWN)
        when:
        CommonResponse commonResponse = hscController.cancelAuthorization(TEST_HSC_ID, cancelReason)
        then:
        featureFlagManager.isActive(SpclCareFeatureFlagConstants.CANCEL_REASON_DEAD_LOCK) >> true

        1 * hsc.read(TEST_HSC_ID) >> hscVO

        1 * hscHelper.cancelEPARequest(hscVO) >> false

        commonResponse.getErrorExists() == true
        commonResponse.getEmbedded() == commonResponseStubbed.setEmbedded(hscVO).getEmbedded()

    }
}
