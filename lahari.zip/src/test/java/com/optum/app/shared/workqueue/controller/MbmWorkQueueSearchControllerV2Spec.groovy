package com.optum.app.shared.workqueue.controller

import com.optum.app.ocm.controller.support.CommonResponse
import com.optum.app.shared.spclcare.SpecialtyCareReadLogicSpecification
import com.optum.app.shared.workqueue.businesslogic.impl.MbmWorkQueueSearchImpl
import com.optum.app.shared.workqueue.controller.v2.MbmWorkQueueSearchControllerV2
import com.optum.app.shared.workqueue.data.v2.WorkQueueHelperDO
import com.optum.app.shared.workqueue.data.v2.WorkQueueItemsDO
import com.optum.mbm.workqueue.data.v2.response.ItemTaskCriteriaResponse
import com.optum.rf.core.util.UhgCalendar
import com.optum.rf.dao.sql.query.QueryFilter
import com.optum.rf.dao.sql.query.QueryProperties

import java.sql.Timestamp

class MbmWorkQueueSearchControllerV2Spec extends SpecialtyCareReadLogicSpecification{

    MbmWorkQueueSearchControllerV2 mbmWorkQueueSearchController
    MbmWorkQueueSearchImpl mbmWorkQueueSearch

    def setup() {
        mbmWorkQueueSearchController = new MbmWorkQueueSearchControllerV2()
        mbmWorkQueueSearch = Mock(MbmWorkQueueSearchImpl)

        mbmWorkQueueSearchController.mbmWorkQueueSearch = mbmWorkQueueSearch
    }

    def 'getWorkQueueItems'(){
        given:
        int orgId = 3
        QueryProperties query = new QueryProperties()
        query.addQueryFilter(new QueryFilter('owner', owner))
        query.addQueryFilter(new QueryFilter('workQueueId', workQueueId))
        query.addQueryFilter(new QueryFilter('assignmentDueDate', assignmentDueDate))
        ItemTaskCriteriaResponse itemTaskResponse = new ItemTaskCriteriaResponse(hscId: 123, itemTaskId: 123, workQueueId: 123, descriptionId: '1', assignmentTypeId: '04', owner: 'Test',
                assignmentDueDate: new Timestamp(new UhgCalendar().year - 1900, new UhgCalendar().month - 2, new UhgCalendar().day, 23, 59, 00, 00), createDateTime: new Timestamp(11, 0, 12, 0, 0, 0, 0))
        List<WorkQueueItemsDO> doList = [new WorkQueueItemsDO(itemTaskResponse: itemTaskResponse, authorizationType: '4', anticipatedStartDt: '2019-11-11', memberName: 'Test',
                policyGroup: '0908410', policyName: 'OXFORD HEALTH INSURANCE, INC.', insuranceType: '4', reviewPriority: '1', stateOfIssue: 'AR', stateOfResidence: 'NJ', stateOfService: 'OH',
                serviceReferenceNum: 'A003011288', providerName: 'HAZRA ANUPINDER', tatDueDate: new UhgCalendar(), tatExists: '0')]
        WorkQueueHelperDO helperDO = new WorkQueueHelperDO(doList: doList,totalRecordsCount: 1)

        when:
        CommonResponse response = mbmWorkQueueSearchController.getWorkQueueItems(orgId, query)

        then:
        1 * mbmWorkQueueSearch.getWorkQueueItems(orgId, query) >> helperDO
        0*_

        and:
        response.getEmbedded().get('_embedded') == helperDO.doList

        where:
        Sno | owner  | workQueueId | assignmentDueDate
        1   | ''     | 1234        | ''
        2   | 'test' | null        | '1'

    }


    def 'getAssignments'(){
        given:
        QueryProperties query = new QueryProperties()
        List<ItemTaskCriteriaResponse> assignmentList = [new ItemTaskCriteriaResponse(hscId: 123, itemTaskId: 123, workQueueId: 123, descriptionId: '1', assignmentTypeId: '04',
                owner: 'Test', assignmentDueDate: new Timestamp(new UhgCalendar().year - 1900, new UhgCalendar().month - 2, new UhgCalendar().day, 23, 59, 00, 00), createDateTime: new Timestamp(11, 0, 12, 0, 0, 0, 0),
                assignmentComments: 'test', statusId: '1', outcomeId: '1', priorityTypeId: '1', createUserId: 'SYSTEM', assignedTo: '100')]
        WorkQueueHelperDO helperDO = new WorkQueueHelperDO(assignmentList: assignmentList,totalRecordsCount: 1)
        int custId = 2
        when:
        CommonResponse response = mbmWorkQueueSearchController.getAssignments(custId,query)
        then:
        1 * mbmWorkQueueSearch.getAssignments(custId, query) >> helperDO
        0*_
        and:
        response.getEmbedded().get('_embedded') == helperDO.assignmentList
    }
}
