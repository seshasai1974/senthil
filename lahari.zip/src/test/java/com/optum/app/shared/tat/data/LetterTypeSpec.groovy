package com.optum.app.shared.tat.data

import com.optum.rf.dao.exception.UhgRuntimeException
import spock.lang.Specification

class LetterTypeSpec extends Specification{

    def "fromCode(\"1\")" () {
        given:
        String code = '1'

        when:
        LetterType letterType = LetterType.fromCode(code)

        then:
        letterType == LetterType.APPROVAL
    }

    def "fromCode(\"2\")" () {
        given:
        String code = '2'

        when:
        LetterType letterType = LetterType.fromCode(code)

        then:
        letterType == LetterType.LACK_OF_INFORMATION
    }

    def "fromCode(\"3\")" () {
        given:
        String code = '3'

        when:
        LetterType letterType = LetterType.fromCode(code)

        then:
        letterType == LetterType.DENIAL
    }

    def "fromCode invalid" () {
        given:
        String code = '4'

        when:
        LetterType.fromCode(code)

        then:
        final UhgRuntimeException exception = thrown()

        exception.message == 'Invalid LetterType code specified.'
    }
}
