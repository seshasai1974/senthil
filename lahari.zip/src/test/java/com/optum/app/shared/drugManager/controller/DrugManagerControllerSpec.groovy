package com.optum.app.shared.drugManager.controller

import com.optum.app.ocm.controller.support.CommonResponse
import com.optum.app.shared.drugManager.data.DrugManagerViewVO
import com.optum.app.shared.drugManager.helper.DrugManagerHelper
import com.optum.app.shared.procedure.data.ProcedureBrandVO
import com.optum.rf.dao.sql.query.QueryProperties
import spock.lang.Specification

class DrugManagerControllerSpec extends Specification {

    DrugManagerController drugManagerController = new DrugManagerController()
    DrugManagerHelper drugManagerHelper = Mock(DrugManagerHelper)

    def setup() {
        drugManagerController.drugManagerHelper = drugManagerHelper
    }

    def 'test getDrugManagerView'() {
        given:
        QueryProperties queryProperties = new QueryProperties()
        List<DrugManagerViewVO> drugManagerViewVOs = [new DrugManagerViewVO()]

        when:
        CommonResponse commonResponse = drugManagerController.getDrugManagerView(queryProperties)

        then:
        1 * drugManagerHelper.performDrugManagerSearch(queryProperties) >> new CommonResponse().setEmbedded(drugManagerViewVOs)
        0 * _

        and:
        commonResponse.getEmbedded().get('_embedded') == drugManagerViewVOs
    }

    def 'test saveDrugRecords'() {
        given:
        List<DrugManagerViewVO> drugManagerViewVOs = [new DrugManagerViewVO()]

        when:
        CommonResponse commonResponse = drugManagerController.saveDrugRecords(drugManagerViewVOs)

        then:
        1 * drugManagerHelper.saveDrugRecords(drugManagerViewVOs) >> new CommonResponse().setEmbedded(drugManagerViewVOs)
        0 * _

        and:
        commonResponse.getEmbedded().get('_embedded') == drugManagerViewVOs
    }

    def 'test saveProcedureRecords'() {
        given:
        List<ProcedureBrandVO> procedureBrandVOS = [new ProcedureBrandVO()]

        when:
        CommonResponse commonResponse = drugManagerController.saveProcedureRecords(procedureBrandVOS)

        then:
        1 * drugManagerHelper.saveProcedureRecords(procedureBrandVOS) >> new CommonResponse().setEmbedded(procedureBrandVOS)
        0 * _

        and:
        commonResponse.getEmbedded().get('_embedded') == procedureBrandVOS
    }

    def 'test getProcedureRecords'() {
        given:
        int procedureBrandID = 123
        List<ProcedureBrandVO> procedureBrandVOS = [new ProcedureBrandVO()]

        when:
        CommonResponse commonResponse = drugManagerController.getProcedureRecords(procedureBrandID)

        then:
        1 * drugManagerHelper.getProcedureRecords(procedureBrandID) >> new CommonResponse().setEmbedded(procedureBrandVOS)
        0 * _

        and:
        commonResponse.getEmbedded().get('_embedded') == procedureBrandVOS
    }
}
