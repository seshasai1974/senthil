package com.optum.app.shared.whitelabel.controller

import com.optum.app.MockExternalException
import com.optum.app.ocm.controller.support.CommonResponse
import com.optum.app.shared.whitelabel.WhiteLabelTestData
import com.optum.app.shared.whitelabel.WhiteLabel
import spock.lang.Specification

class WhiteLabelControllerSpec extends Specification implements WhiteLabelTestData {
    // Mocks for apis external to the current module.
    def whiteLabel = Mock(WhiteLabel)
    // Subject Under Test
    def whiteLabelController = new WhiteLabelController(whiteLabel)

    def 'Success read whiteLabels'() {
        given:
        def sharedWhiteLabelsDto = newCustomerWhiteLabelsDto(1)

        when: "read whiteLabels success"
        CommonResponse response = whiteLabelController.customerWhiteLabels(sharedWhiteLabelsDto.customerId)

        then:
        noExceptionThrown()
        assert response != null
        1 * whiteLabel.customerWhiteLabels(sharedWhiteLabelsDto.customerId) >> sharedWhiteLabelsDto
    }

    def 'Failure read whiteLabels'() {

        when:
        whiteLabelController.customerWhiteLabels(customerID)

        then:
        thrown(MockExternalException)
        1 * whiteLabel.customerWhiteLabels(customerID) >> { throw new MockExternalException() }

        where:
        _ | customerID
        _ | 1
        _ | null
    }

}
