package com.optum.app.shared.epaOrx.controller

import com.optum.app.ocm.controller.support.CommonResponse
import com.optum.app.shared.constants.SpclCareFeatureFlagConstants
import com.optum.app.shared.microservice.controller.EpaRequestController
import com.optum.app.shared.epaOrx.v1.businesslogic.EpaService
import com.optum.app.shared.epaOrx.v1.data.EpaTransaction
import com.optum.app.shared.microservice.constants.RestConstants
import com.optum.app.shared.microservice.data.EpaRequest
import com.optum.app.shared.spclcare.SpecialtyCareReadLogicSpecification
import com.optum.rf.common.featureflag.util.FeatureFlagManager
import com.optum.rf.common.featureflag.util.FeatureFlagUtility
import org.ncpdp.schema.datatypes.NameType
import org.ncpdp.schema.datatypes.QualifiedAddress
import org.ncpdp.schema.script.PARequest
import org.ncpdp.schema.transport.BodyType
import org.ncpdp.schema.transport.HeaderType
import org.ncpdp.schema.transport.MessageType
import org.ncpdp.schema.transport.SenderSoftwareType
import spock.lang.Unroll

class EpaRequestControllerSpec extends SpecialtyCareReadLogicSpecification {

    EpaRequestController epaRequestController
    EpaService epaService
    FeatureFlagManager featureFlagManager
    def setup() {
        epaRequestController = new EpaRequestController()
        epaService = Mock(EpaService)
        epaRequestController.epaService = epaService
        featureFlagManager = Mock(FeatureFlagManager)
        FeatureFlagUtility.featureFlagManager = featureFlagManager
    }

    @Unroll
    def "test getPAInitiationRequest"() {
        given:
        EpaRequest epaRequest= new EpaRequest()
        when:
        CommonResponse response = epaRequestController.paInitiationRequest(epaRequest)
        then:
        1 * epaService.getPAInitiationRequest(epaRequest) >> getStatusMessage()
        (String) response.getEmbedded().get(CommonResponse.EMBEDDED)
        0 *_._
        2 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_EPA_ORX_V2) >> false
    }
    @Unroll
    def "test getPARequest"() {
        given:
        String jsonRequest
        when:
        CommonResponse response = epaRequestController.paRequest()
        then:
        1 * epaService.getPARequest(jsonRequest) >> getStatusMessage()
        (String) response.getEmbedded().get(CommonResponse.EMBEDDED)
        0 *_._
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_EPA_ORX_V2) >> false
    }

    @Unroll
    def "test getPACancelRequest"(){
        when:
        CommonResponse response = epaRequestController.paCancelRequest()
        then:
        1* epaService.getPACancelRequest() >> getStatusMessage()
        (String) response.getEmbedded().get(CommonResponse.EMBEDDED)
        0 *_._
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_EPA_ORX_V2) >> false
    }


    @Unroll
    def "test fetchEpaQuestion"(){
        given:
        EpaTransaction epaTransaction = new EpaTransaction()
        epaTransaction.setHscId(199876)
        when:
        epaRequestController.fetchEpaQuestion(epaTransaction)
        then:
        1* epaService.fetchEpaQuestion(_)
    }

    private static String getStatusMessage() {
        return  RestConstants.TRANSACTION_SUCCESSFUL
    }
    @Unroll
    def "test paSaveAnswerRequest"(){
        given:
        List<EpaTransaction> epaTransactions = setEpaTransaction()
        when:
        CommonResponse response = epaRequestController.paSaveAnswerRequest(epaTransactions)
        then:
        1* epaService.saveAnswer(epaTransactions) >> getStatusMessage()
        (String) response.getEmbedded().get(CommonResponse.EMBEDDED)
    }
    private List<EpaTransaction> setEpaTransaction(){
        List<EpaTransaction> epaTransactions = new ArrayList<>()
        EpaTransaction epaTransaction = new EpaTransaction()
        QualifiedAddress to = new QualifiedAddress()
        to.setValue('OPTUM')
        QualifiedAddress from = new QualifiedAddress()
        from.setValue('MBMNOW')
        SenderSoftwareType sendType = new SenderSoftwareType()
        sendType.setSenderSoftwareVersionRelease('V1.0')
        sendType.setSenderSoftwareProduct('CGP-UHC')
        sendType.setSenderSoftwareDeveloper('MBMNOW')
        HeaderType headerType = new HeaderType()
        headerType.setTo(to)
        headerType.setFrom(from)
        headerType.setSenderSoftware(sendType)
        NameType name = new NameType()
        name.setFirstName('DAN')
        name.setLastName('HUMPHREY')
        PARequest paRequest = new PARequest()
        paRequest.setPAReferenceID("PA-UHC-DEV-100655")
        BodyType bodyType = new BodyType()
        bodyType.setPARequest(paRequest)
        MessageType messageType = new MessageType()
        messageType.setHeader(headerType)
        messageType.setBody(bodyType)
        epaTransaction.setMessageType(messageType)
        epaTransaction.setHscId(123098)

        epaTransactions.add(epaTransaction)
        epaTransactions
    }

    def "fetchPARespOverallSts"() {
        given:
        long hscId
        when:
        epaRequestController.fetchPARespOverallSts(hscId);
        then:
        1 * epaService.fetchPARespOverallSts(hscId)
    }

    def "fetchPAInitRespOverallSts"() {
        given:
        long hscId
        when:
        epaRequestController.fetchPAInitRespOverallSts(hscId);
        then:
        1 * epaService.fetchPAInitRespOverallSts(hscId)
    }
}