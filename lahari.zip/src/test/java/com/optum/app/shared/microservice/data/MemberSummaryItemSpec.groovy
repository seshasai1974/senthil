package com.optum.app.shared.microservice.data

import com.optum.app.shared.microservice.data.MemberSummaryItem
import org.apache.commons.lang.StringUtils
import spock.lang.Specification

/**
 * Created by cnadipin on 1/10/19.
 */
class MemberSummaryItemSpec extends Specification {

    MemberSummaryItem memberSummaryItem

    def setup() {
        memberSummaryItem = new MemberSummaryItem(firstName: 'AAAA', lastName:'BBBB', subscriberID: '123',
                 sourceMemberID: '1234', sourceMemberIDPartitionNumber: '123456', policyNumber: '222')
    }
    def "equals true"() {

        when:
        boolean retVal = memberSummaryItem.equals(memberSummaryItem)

        then:
        0 * _

        and:
        retVal
    }

    def "equals false"() {
        given:
        MemberSummaryItem object = new MemberSummaryItem(firstName: 'AAAA', lastName:'BBBB', subscriberID: '123',
                sourceMemberID: '1234', sourceMemberIDPartitionNumber: '123456', policyNumber: '222')

        when:
        boolean retVal = object.equals(_)

        then:
        0 * _

        and:
        !retVal
    }

    def "hash"() {
        given:

        MemberSummaryItem object = new MemberSummaryItem(firstName: 'AAAA', lastName:'BBBB', subscriberID: '123',
                sourceMemberID: '1234', sourceMemberIDPartitionNumber: '123456', policyNumber: '222')

        when:
        int retVal = object.hashCode()

        then:
        0 * _

        and:
        retVal
        retVal > 0
    }

    def "to String"() {
        given:

        MemberSummaryItem object = new MemberSummaryItem(firstName: 'AAAA', lastName:'BBBB', subscriberID: '123',
                sourceMemberID: '1234', sourceMemberIDPartitionNumber: '123456', policyNumber: '222')

        when:
        String retVal = object.toString()

        then:
        0 * _

        and:
        StringUtils.isNotBlank(retVal)
    }

    def "getters"() {

        when:
        String fName = memberSummaryItem.getfirstName()
        String lName = memberSummaryItem.getlastName()
        String subScbrId = memberSummaryItem.getsubscriberID()
        String srcMemId = memberSummaryItem.getsourceMemberID()
        String srcMemPartId = memberSummaryItem.getsourceMemberIDPartitionNumber()
        String plcyNumber = memberSummaryItem.getpolicyNumber()

        then:
        0 * _

        and:
        fName.equalsIgnoreCase("AAAA")
        lName.equalsIgnoreCase("BBBB")
        subScbrId.equalsIgnoreCase('123')
        srcMemId.equalsIgnoreCase('1234')
        srcMemPartId.equalsIgnoreCase('123456')
        plcyNumber.equalsIgnoreCase("222")
    }
}
