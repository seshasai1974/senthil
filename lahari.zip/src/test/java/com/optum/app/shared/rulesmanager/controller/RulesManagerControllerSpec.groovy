package com.optum.app.shared.rulesmanager.controller

import com.optum.app.ocm.controller.support.CommonResponse
import com.optum.app.shared.constants.SpclCareFeatureFlagConstants
import com.optum.app.shared.rulesmanager.businesslogic.RulesManagerService
import com.optum.app.shared.rulesmanager.data.RuleRequestDO
import com.optum.app.shared.spclcare.SpecialtyCareReadLogicSpecification
import com.optum.mbm.flow.data.v1.rules.Sheet
import com.optum.mbm.flow.data.v1.rules.SheetVersion
import com.optum.mbm.flow.data.v1.rules.SheetVersionValue
import com.optum.rf.common.featureflag.util.FeatureFlagManager
import com.optum.rf.common.featureflag.util.FeatureFlagUtility
import com.optum.rf.dao.sql.query.QueryFilter
import com.optum.rf.dao.sql.query.QueryProperties
import com.uhg.app.common.constants.spclcare.FieldConstants
import org.springframework.http.HttpStatus
import spock.lang.Unroll

class RulesManagerControllerSpec extends  SpecialtyCareReadLogicSpecification{
    RulesManagerController controller = new RulesManagerController()
    RulesManagerService rulesManagerService = Mock(RulesManagerService)
    FeatureFlagManager featureFlagManager = Mock(FeatureFlagManager)

    def setup() {
        controller.rulesManagerService = rulesManagerService
        FeatureFlagUtility.featureFlagManager = featureFlagManager
    }

    @Unroll
    def 'getRulesManagerSheets #testCase'() {
        when:
        CommonResponse commonResponse = controller.getRulesManagerSheets()

        then:
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_RULES_MANAGER) >> featureFlag
        isfeatureFlagEnabled * rulesManagerService.getAllRuleSheets() >> result

        and:
        commonResponse.getEmbedded().get('body') == result.getEmbedded().get('body')
        commonResponse.getEmbedded().get('errorExists') == result.getEmbedded().get('errorExists')
        commonResponse.getEmbedded().get('status') == result.getEmbedded().get('status')

        where:
        testCase | featureFlag | isfeatureFlagEnabled | queryProperties       | result
        0        | true        | 1                    | new QueryProperties() | new CommonResponse().setEmbedded(HttpStatus.OK)
        1        | false       | 0                    | new QueryProperties() | new CommonResponse()
    }

    @Unroll
    def 'getRulesExceptionSheet'() {
        when:
        CommonResponse commonResponse = controller.getRulesManagerSheet(queryProperties)

        then:
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_RULES_MANAGER) >> featureFlag
        isfeatureFlagEnabled * rulesManagerService.getRulesManagerSheet(queryProperties) >> result

        and:
        commonResponse.getEmbedded().get('body') == result.getEmbedded().get('body')
        commonResponse.getEmbedded().get('errorExists') == result.getEmbedded().get('errorExists')
        commonResponse.getEmbedded().get('status') == result.getEmbedded().get('status')

        where:
        testCase | featureFlag | isfeatureFlagEnabled | queryProperties       | result
        0        | true        | 1                    | new QueryProperties() | new CommonResponse().setEmbedded(HttpStatus.OK)
        1        | false       | 0                    | new QueryProperties() | new CommonResponse()
    }

    def 'getRulesManagerSheetFilters'(){
        when:
        CommonResponse commonResponse = controller.getRulesManagerSheetFilters(sheetId, version, queryProperties)

        then:
        1 * rulesManagerService.getRulesManagerSheetFilters(sheetId, version, queryProperties) >> result
        0 * _

        and:
        commonResponse.getEmbedded().get('body') == result.getEmbedded().get('body')

        where:
        testcase | sheetId | version | queryProperties        | result
        0        |    1     | 18     |   getQueryProperties() |  new CommonResponse().setEmbedded(getSheet())

    }
    private QueryProperties getQueryProperties(){
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.IS_FILTERING)
        qp.addQueryFilter(new QueryFilter(FieldConstants.FIRSTNAME, 'joy'))
        qp.setPosition(0)
        qp.setResultSize(25)
        qp
    }

    private  Sheet getSheet(){
        Sheet sheet = new Sheet()
        List<SheetVersion> sheetVersions = new ArrayList<>()
        SheetVersion version = new SheetVersion()
        version.setTotalRecords(25L)
        sheetVersions.add(version)
        sheet.setSheetVersion(sheetVersions)
        sheet
    }
    @Unroll
    def 'deleteRulesManagerSheet'(){
        when:
        CommonResponse commonResponse = controller.deleteRulesManagerSheet(sheetId, ruleRequestDO)

        then:
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_RULES_MANAGER) >> featureFlag
        isfeatureFlagEnabled * rulesManagerService.deleteRule(sheetId, ruleRequestDO) >> result

        and:
        commonResponse.getEmbedded().get('body') == result.getEmbedded().get('body')
        commonResponse.getEmbedded().get('errorExists') == result.getEmbedded().get('errorExists')
        commonResponse.getEmbedded().get('status') == result.getEmbedded().get('status')

        where:
        testcase | featureFlag | sheetId | ruleRequestDO                                                  | isfeatureFlagEnabled | result
        0        | true        | 1L      | new RuleRequestDO(sheetVersionValueId: 1L, sheetVersionId: 1L) | 1                    | new CommonResponse().setEmbedded(body: null, status: HttpStatus.OK, errorExists: false)
        1        | true        | 1L      | new RuleRequestDO(sheetVersionValueId: 1L, sheetVersionId: 1L) | 1                    | new CommonResponse().setEmbedded(body: null, status: HttpStatus.NO_CONTENT, errorExists: true)
        2        | true        | 1L      | new RuleRequestDO(sheetVersionValueId: 1L, sheetVersionId: 1L) | 1                    | new CommonResponse().setEmbedded(body: null, status: HttpStatus.INTERNAL_SERVER_ERROR, errorExists: true)
        3        | false       | 1L      | new RuleRequestDO(sheetVersionValueId: 1L, sheetVersionId: 1L) | 0                    | new CommonResponse()
    }
}
