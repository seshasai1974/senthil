package com.optum.app.shared.documentManager.controller


import com.optum.app.shared.documentManager.businesslogic.DocumentManagerService
import spock.lang.Specification

class DocumentManagerControllerV2Spec extends  Specification {

    DocumentManagerControllerV2 documentManagerController
    DocumentManagerService documentManagerService = Mock(DocumentManagerService)

    def setup(){
        documentManagerController = new DocumentManagerControllerV2()
        documentManagerController.documentManagerService = documentManagerService
    }

    def "test getAttachment"(){

        when:
        documentManagerController.getAttachment('7676','7865')

        then:
        1 * documentManagerService.getAttachment('7676','7865')
    }





}
