package com.optum.app.shared.technique.controller

import com.optum.app.ocm.controller.support.CommonResponse
import com.optum.app.shared.diseaseTraversal.data.TechniqueViewVO
import com.optum.app.shared.spclcare.SpecialtyCareReadLogicSpecification
import com.optum.app.shared.technique.Technique
import com.optum.rf.dao.sql.query.QueryProperties
import com.uhg.app.common.constants.spclcare.FieldConstants
import spock.lang.Unroll

class TechniqueControllerSpec extends SpecialtyCareReadLogicSpecification{

    TechniqueController techniqueController
    Technique technique = Mock(Technique)


    def setup(){
        techniqueController = new TechniqueController()
        techniqueController.technique = technique
    }

    @Unroll
    def 'test listAllTechniques'() {
        given:
        List<TechniqueViewVO> techniqueViewVOList = new ArrayList<TechniqueViewVO>()
        QueryProperties qp = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        qp.setListFields(FieldConstants.TECHNIQUENAME)
        qp.setDistinct(true)
        qp.setOrderByAscFields(FieldConstants.TECHNIQUENAME)

        when:
        CommonResponse response = techniqueController.listAllTechnique()

        then:
        1 *  technique.listTechniques(qp) >> new ArrayList<TechniqueViewVO>()

        and:
        response.getEmbedded().get('_embedded') == techniqueViewVOList
    }

}
