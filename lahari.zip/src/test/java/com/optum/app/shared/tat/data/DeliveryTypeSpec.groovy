package com.optum.app.shared.tat.data

import com.optum.rf.dao.exception.UhgRuntimeException
import spock.lang.Specification

class DeliveryTypeSpec extends Specification{

    def 'fromCode(\"1\")' () {
        given:
        String code = '1'

        when:
        DeliveryType deliveryType = DeliveryType.fromCode(code)

        then:
        deliveryType == DeliveryType.PHYSICAL_MAIL
    }

    def 'fromCode(\"2\")' () {
        given:
        String code = '2'

        when:
        DeliveryType deliveryType = DeliveryType.fromCode(code)

        then:
        deliveryType == DeliveryType.PDF
    }

    def 'fromCode(\"3\")' () {
        given:
        String code = '3'

        when:
        DeliveryType deliveryType = DeliveryType.fromCode(code)

        then:
        deliveryType == DeliveryType.FAX
    }

    def "fromCode invalid" () {
        given:
        String code = '4'

        when:
        DeliveryType.fromCode(code)

        then:
        final UhgRuntimeException exception = thrown()
        exception.message == 'Invalid DeliveryType code specified.'
    }
}
