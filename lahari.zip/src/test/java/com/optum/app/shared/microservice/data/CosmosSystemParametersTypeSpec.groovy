package com.optum.app.shared.microservice.data

import com.optum.app.shared.microservice.data.CosmosSystemParametersType
import org.apache.commons.lang.StringUtils
import spock.lang.Specification

class CosmosSystemParametersTypeSpec extends Specification {
    CosmosSystemParametersType cosmosSystemParametersType

    def setup() {
        cosmosSystemParametersType = new CosmosSystemParametersType(sourceId: 'MBM_TEST', userId: 'TESTING')
    }

    def "equals true"() {

        when:
        boolean retVal = cosmosSystemParametersType.equals(cosmosSystemParametersType)

        then:
        0 * _

        and:
        retVal
    }

    def "equals false"() {
        given:
        CosmosSystemParametersType object = new CosmosSystemParametersType(sourceId: 'MBM_TEST', userId: 'TESTING')

        when:
        boolean retVal = object.equals(_)

        then:
        0 * _

        and:
        !retVal
    }

    def "hash"() {
        given:

        CosmosSystemParametersType object = new CosmosSystemParametersType(sourceId: 'MBM_TEST', userId: 'TESTING')

        when:
        int retVal = object.hashCode()

        then:
        0 * _

        and:
        retVal
        retVal > 0
    }

    def "to String"() {
        given:

        CosmosSystemParametersType object = new CosmosSystemParametersType(sourceId: 'MBM_TEST', userId: 'TESTING')

        when:
        String retVal = object.toString()

        then:
        0 * _

        and:
        StringUtils.isNotBlank(retVal)
    }
}
