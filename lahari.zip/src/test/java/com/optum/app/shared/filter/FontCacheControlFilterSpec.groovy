package com.optum.app.shared.filter

import com.optum.rf.web.util.ControllerUtilities
import org.apache.commons.logging.Log
import org.junit.Rule
import spock.lang.Specification
import spock.lang.Unroll

import javax.servlet.FilterChain
import javax.servlet.FilterConfig
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse

class FontCacheControlFilterSpec extends Specification {
    FontCacheControlFilter mbmHttpCacheControlFilter = new FontCacheControlFilter()
    Log logger = Mock(Log.class)
    FilterChain filterChain = Mock(FilterChain)
    HttpServletRequest request = Mock(HttpServletRequest)
    HttpServletResponse response = Mock(HttpServletResponse)

    @Rule ReplacePrivateFinalMember replacePrivateFinalMember = new ReplacePrivateFinalMember(FontCacheControlFilter.class, logger, "LOGGER")


    def setup() {

    }

    @Unroll
    def "doFilter"() {
        given:


        when:
        mbmHttpCacheControlFilter.doFilter(request, response, filterChain)

        then:
        getRequestUri * request.getRequestURI() >> path
        isNotFont * response.containsHeader('Cache-Control') >> false
        isNotFont * request.getMethod() >> 'get'
        isNotFont * response.setHeader('Cache-Control', cacheControl)
        isNotFont * response.setHeader('Pragma', pragma)
        isFont * response.containsHeader('Cache-Control') >> hadCacheControl
        checkPragma * response.containsHeader('Pragma') >> hadPragma
        clearHeaders * response.setHeader(ControllerUtilities.CACHE_CONTROL_HEADER, null)
        clearHeaders * response.setHeader(ControllerUtilities.PRAGMA_HEADER, null)
        1 * filterChain.doFilter(_ as FontRequestWrapper, response)
        0 * _

        where:
        path                                 | getRequestUri | isNotFont | isFont | cacheControl                          | pragma     | hadCacheControl | checkPragma | hadPragma | clearHeaders
        '/ui/ocm/memberservice/v1/getMember' | 3             | 1         | 0      | 'no-cache, no-store, must-revalidate' | 'no-cache' | false           | 0           | false     | 0
        '/static/css/fonts/'                 | 2             | 0         | 1      | null                                  | null       | false           | 1           | false     | 0
        'test/static/css/fonts/testFont.eff' | 2             | 0         | 1      | null                                  | null       | false           | 1           | false     | 0
        '/static/css/fonts/'                 | 2             | 0         | 1      | null                                  | null       | true            | 0           | false     | 1
        'test/static/css/fonts/testFont.eff' | 2             | 0         | 1      | null                                  | null       | false           | 1           | true      | 1
        'test/static/help.html'              | 3             | 0         | 1      | null                                  | null       | false           | 1           | true      | 1
    }

    @Unroll
    def "doFilterExceptionTest"() {
        given:


        when:
        mbmHttpCacheControlFilter.doFilter(request, response, filterChain)

        then:
        1 * request.getRequestURI() >> {throw new NumberFormatException("This is a test")}
        1 * logger.error(_, _)
    }

    @Unroll
    def "test init #testCase"() {
        given:
        FilterConfig filterConfig = Mock(FilterConfig)

        when:
        mbmHttpCacheControlFilter.init(filterConfig)

        then:
        1 * filterConfig.getInitParameter('enabled')  >> enabled
        1 * filterConfig.getInitParameter('sharable') >> sharable
        1 * filterConfig.getInitParameter('seconds')  >> seconds

        where:
        testCase | enabled        | sharable        | seconds
        0        | ""             | ""              | ""
        1        | "true"         | "true"          | "0"
    }

}
