package com.optum.app.shared.workqueue.mapper

import com.optum.app.shared.constants.SpclCareFeatureFlagConstants
import com.optum.app.shared.microservice.constants.RestConstants
import com.optum.app.shared.workqueue.mapper.impl.MbmWorkQueueSearchRequestMapperImpl
import com.optum.clinical.security.jwt.client.service.JwtClientService
import com.optum.rf.common.featureflag.util.FeatureFlagManager
import com.optum.rf.common.featureflag.util.FeatureFlagUtility
import com.optum.rf.common.settings.businesslogic.SystemSettingsWebService
import com.optum.rf.common.settings.data.SystemSettingsWebServiceVO
import com.optum.app.constants.SettingsReferenceConstants
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory
import org.springframework.web.client.HttpClientErrorException
import org.springframework.web.client.RestTemplate
import spock.lang.Specification
import org.springframework.http.HttpHeaders

class MbmWorkQueueSearchRequestMapperImplSpec extends Specification{

    MbmWorkQueueSearchRequestMapperImpl mbmWorkQueueSearchRequestMapperImpl
    RestTemplate restTemplate =  Mock(RestTemplate)
    SystemSettingsWebService systemSettingsWebService = Mock(SystemSettingsWebService)
    JwtClientService jwtClientService = Mock(JwtClientService)
    FeatureFlagManager featureFlagManager = Mock(FeatureFlagManager)


    def setup() {
        mbmWorkQueueSearchRequestMapperImpl = new MbmWorkQueueSearchRequestMapperImpl()
        mbmWorkQueueSearchRequestMapperImpl.systemSettingsWebService = systemSettingsWebService
        mbmWorkQueueSearchRequestMapperImpl.jwtClientService = jwtClientService
        FeatureFlagUtility.featureFlagManager = featureFlagManager

    }

    def "test getSystemSettingsWebServiceVO"() {
        given:
        SystemSettingsWebServiceVO systemSettingsWebServiceVO = new SystemSettingsWebServiceVO()

        when:
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.FEDERATED_PLATFORM_ENDPOINT_UPDATES) >> false
        SystemSettingsWebServiceVO systemSettingsWebServiceV01 = mbmWorkQueueSearchRequestMapperImpl.getSystemSettingsWebServiceVO()

        then:
        1 * systemSettingsWebService.read(SettingsReferenceConstants.WSID_MBMWRKQ) >> systemSettingsWebServiceVO
        systemSettingsWebServiceVO == systemSettingsWebServiceV01
    }

    def "test getSystemSettingsWebServiceVO exception thrown"() {
        given:

        when:
        mbmWorkQueueSearchRequestMapperImpl.getSystemSettingsWebServiceVO()

        then:
        thrown(HttpClientErrorException)
    }

    def "test getWorkQueueSearchRestTemplate"() {
        given:
        HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory()
        requestFactory.setConnectTimeout(RestConstants.WORK_QUEUE_CONNECTION_TIMEOUT)
        requestFactory.setReadTimeout(RestConstants.WORK_QUEUE_READ_TIMEOUT)

        when:
        mbmWorkQueueSearchRequestMapperImpl.setWorkQueueSearchRestTemplateTimeout(restTemplate)
        then:
        1 * restTemplate.getRequestFactory() >> requestFactory
        1 * restTemplate.setRequestFactory(requestFactory)
    }

    def "test buildHttpHeader"() {
        given:

        when:
        HttpHeaders headers = mbmWorkQueueSearchRequestMapperImpl.buildHttpHeader()

        then:
        1 * jwtClientService.getToken('OCM-SPCL-CARE', 'OCM-SPCL-CARE', 30) >> 'tokenString'
        0 * _

        and:
        headers
    }
}
