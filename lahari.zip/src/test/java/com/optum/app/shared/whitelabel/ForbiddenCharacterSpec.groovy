package com.optum.app.shared.whitelabel

import com.optum.app.common.organization.data.OrganizationVO
import com.optum.app.ocm.customer.businesslogic.Customer
import com.optum.app.ocm.organization.businesslogic.Organization
import com.optum.app.shared.authorization.businesslogic.Authorizations
import com.optum.app.shared.common.messages.SpclCareMessages
import com.optum.app.shared.whitelabel.dto.ForbiddenWordsDto
import com.optum.rf.dao.exception.UhgRuntimeException
import spock.lang.Shared
import spock.lang.Specification

class ForbiddenCharacterSpec extends Specification implements WhiteLabelTestData {
    @Shared def nonBreakingSpace = '\u00A0'
    // Mocks dependencies external to the current module.
    Customer customer = Mock(Customer)
    Authorizations authorizations = Mock(Authorizations)
    Organization organization = Mock(Organization)
    CustomerWLSubmodule customerWhiteLabelsSubmodule = Mock(CustomerWLSubmodule)
    ForbiddenWordsSubmodule forbiddenWordsSubmodule = Mock(ForbiddenWordsSubmodule)
    // Subject Under Test. Instantiating here ensures we restart internal state in each test
    WhiteLabel whiteLabel = new WhiteLabelConfiguration().whiteLabel(
            authorizations,
            customer,
            organization,
            customerWhiteLabelsSubmodule,
            forbiddenWordsSubmodule
    )

    def 'Failure to consume customer whiteLabels - forbidden characters'() {

        given:
        def customerVO = newCustomerVO(1)
        def organizationVO = new OrganizationVO(organizationShortName: "org-0")

        when: 'consume'
        whiteLabel.customerWhiteLabels(customerVO.customerID)

        then:
        UhgRuntimeException e = thrown(exception)
        e.getErrorVO().getGlobalMessages().contains(SpclCareMessages.ERR_FORBIDDEN_CHARACTER_IN_WHITE_LABELS(customerVO.customerName))
        1 * authorizations.validateCustomer(_)
        1 * customer.read(customerVO.customerID, []) >> customerVO
        1 * organization.read(organizationVO.organizationID, []) >> organizationVO
        1 * forbiddenWordsSubmodule.getMergedForbiddenWords(customerVO.customerName, organizationVO.organizationShortName) >> forbiddenWords
        1 * customerWhiteLabelsSubmodule.getMergedCustomerWhiteLabels(customerVO.customerName, organizationVO.organizationShortName) >> toOptionalJson(invalidWhiteLabels)

        where:
        exception           | forbiddenWords   | invalidWhiteLabels
        UhgRuntimeException | []               | '{ "aKey": "This has an illegal' + nonBreakingSpace +  'whitespace" }'
        UhgRuntimeException | []               | '{ "illegal' + nonBreakingSpace + 'key": "Legal value" }'
        UhgRuntimeException | []               | '{ "illegal key": "Legal value" }'
        UhgRuntimeException | forbiddenWords() | '{ "aKey": "This has an illegal' + nonBreakingSpace +  'whitespace" }'
        UhgRuntimeException | forbiddenWords() | '{ "illegal' + nonBreakingSpace + 'key": "Legal value" }'
        UhgRuntimeException | forbiddenWords() | '{ "illegal key": "Legal value" }'
    }

    def 'Failure to save customer level whiteLabels - forbidden characters'() {

        given:
        def customerVO = newCustomerVO(1)

        when: 'save'
        whiteLabel.customerWhiteLabelsMaintenance.saveWLCustomerLevelValues(newCustomerWhiteLabelsDto(customerVO.customerID, invalidWhiteLabels))

        then:
        UhgRuntimeException e = thrown(exception)
        e.getErrorVO().getGlobalMessages().contains(SpclCareMessages.ERR_FORBIDDEN_CHARACTER_IN_WHITE_LABELS(customerVO.customerName))
        1 * authorizations.validateCustomer(_)
        1 * customer.read(customerVO.customerID, []) >> customerVO
        1 * organization.read(0, []) >> new OrganizationVO(organizationShortName: "org-0")
        1 * forbiddenWordsSubmodule.getMergedForbiddenWords(customerVO.customerName, "org-0") >> forbiddenWords

        where:
        exception           | forbiddenWords   | invalidWhiteLabels
        UhgRuntimeException | []               | '{ "aKey": "This has an illegal' + nonBreakingSpace +  'whitespace" }'
        UhgRuntimeException | []               | '{ "illegal' + nonBreakingSpace + 'key": "Legal value" }'
        UhgRuntimeException | []               | '{ "illegal key": "Legal value" }'
        UhgRuntimeException | forbiddenWords() | '{ "aKey": "This has an illegal' + nonBreakingSpace +  'whitespace" }'
        UhgRuntimeException | forbiddenWords() | '{ "illegal' + nonBreakingSpace + 'key": "Legal value" }'
        UhgRuntimeException | forbiddenWords() | '{ "illegal key": "Legal value" }'
    }

    def 'Failure to save organization level whiteLabels - forbidden characters'() {

        given:
        def customerVO = newCustomerVO(1)

        when: 'save'
        whiteLabel.customerWhiteLabelsMaintenance.saveWLOrganizationLevelValues(newCustomerWhiteLabelsDto(customerVO.customerID, invalidWhiteLabels))

        then:
        UhgRuntimeException e = thrown(exception)
        e.getErrorVO().getGlobalMessages().contains(SpclCareMessages.ERR_FORBIDDEN_CHARACTER_IN_WHITE_LABELS(customerVO.customerName))
        1 * authorizations.validateCustomer(_)
        1 * customer.read(customerVO.customerID, []) >> customerVO
        1 * organization.read(0, []) >> new OrganizationVO(organizationShortName: "org-0")
        1 * forbiddenWordsSubmodule.getMergedForbiddenWords(customerVO.customerName, "org-0") >> forbiddenWords

        where:
        exception           | forbiddenWords   | invalidWhiteLabels
        UhgRuntimeException | []               | '{ "aKey": "This has an illegal' + nonBreakingSpace +  'whitespace" }'
        UhgRuntimeException | []               | '{ "illegal' + nonBreakingSpace + 'key": "Legal value" }'
        UhgRuntimeException | []               | '{ "illegal key": "Legal value" }'
        UhgRuntimeException | forbiddenWords() | '{ "aKey": "This has an illegal' + nonBreakingSpace +  'whitespace" }'
        UhgRuntimeException | forbiddenWords() | '{ "illegal' + nonBreakingSpace + 'key": "Legal value" }'
        UhgRuntimeException | forbiddenWords() | '{ "illegal key": "Legal value" }'
    }

    def 'Failure to save customer Level forbidden words - forbidden characters (internal)'() {

        given:
        def customerVO = newCustomerVO(1)

        when: 'save'
        whiteLabel.forbiddenWordsMaintenance.saveFWCustomerLevelValues(
                new ForbiddenWordsDto(customerId: customerVO.customerID, forbiddenWords: forbiddenWords)
        )

        then:
        UhgRuntimeException e = thrown(exception)
        e.getErrorVO().getGlobalMessages().contains(SpclCareMessages.ERR_FORBIDDEN_CHARACTER_IN_WHITE_LABELS(customerVO.customerName))
        1 * authorizations.validateCustomer(_)
        1 * customer.read(customerVO.customerID, []) >> customerVO
        1 * organization.read(0, []) >> new OrganizationVO(organizationShortName: "org-0")
        1 * customerWhiteLabelsSubmodule.getMergedCustomerWhiteLabels(customerVO.customerName, "org-0") >> Optional.empty()

        where:
        exception                 | forbiddenWords
        UhgRuntimeException      | [ "This has an illegal" + nonBreakingSpace +  "whitespace" ]
        UhgRuntimeException      | [ "illegal\nvalue" ]
    }

}
