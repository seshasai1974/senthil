package com.optum.app.shared.termsOfUse.controller

import com.optum.app.ocm.controller.support.CommonResponse
import com.optum.app.shared.spclcare.SpecialtyCareReadLogicSpecification
import com.optum.app.shared.termsOfUse.businesslogic.TermsOfUse
import com.optum.app.shared.termsOfUse.data.TermsOfUseResponseDO

class TermsOfUseControllerSpec extends SpecialtyCareReadLogicSpecification {

    TermsOfUseController termsOfUseController
    TermsOfUse termsOfUse

    def setup() {
        termsOfUseController = new TermsOfUseController()
        termsOfUse = Mock(TermsOfUse)

        termsOfUseController.termsOfUse = termsOfUse
    }

    def "test getTermsAcceptance"() {
        when:
        CommonResponse commonResponse = termsOfUseController.getTermsAcceptance()

        then:
        1 * termsOfUse.getTermsAcceptance() >> new CommonResponse().setEmbedded(new TermsOfUseResponseDO(termsAccepted: true))
        ((TermsOfUseResponseDO) commonResponse.getEmbedded().get(CommonResponse.EMBEDDED)).isTermsAccepted()
    }

    def "test saveTermsAcceptance"() {
        when:
        CommonResponse commonResponse = termsOfUseController.saveTermsAcceptance()

        then:
        1 * termsOfUse.saveTermsAcceptance() >> new CommonResponse().setEmbedded(new TermsOfUseResponseDO(termsAccepted: true))
        ((TermsOfUseResponseDO) commonResponse.getEmbedded().get(CommonResponse.EMBEDDED)).isTermsAccepted()
    }
}
