package com.optum.app.shared.amqp

import com.optum.app.shared.amqp.SpclCareAMQPDestinationProvider
import com.optum.app.shared.authorization.amqp.AuthRefreshListener
import com.optum.app.shared.messaging.SpclCareMessageDestination
import com.optum.rf.core.message.InternalMessageDestination
import spock.lang.Specification

/**
 * Created by jboyd34 on 10/10/18.
 */
class SpclCareAMQPDestinationProviderSpec extends Specification {


    def "test default constructor"(){
        given:
        SpclCareAMQPDestinationProvider spclCareAMQPDestinationProvider = new SpclCareAMQPDestinationProvider()

        when:
        spclCareAMQPDestinationProvider != null
        InternalMessageDestination refreshAuthQueue = spclCareAMQPDestinationProvider.getMessageDestination(SpclCareMessageDestination.AUTHORIZATION_REFRESH_QUEUE)

        then:
        spclCareAMQPDestinationProvider.getMessageDestinationNames().size() == 1
        refreshAuthQueue.getQueueName().equals('refreshAuthQueue')
        refreshAuthQueue.getConnectionName().equals('refreshAuthQueue')
        refreshAuthQueue.getListenerClass().equals(AuthRefreshListener)
        refreshAuthQueue.getTransactional()
        refreshAuthQueue.getReplyTo() == null
        refreshAuthQueue.getPriority() == 4
        refreshAuthQueue.getPersistence()
        refreshAuthQueue.getMessageTrackingType() == null
        !refreshAuthQueue.getPublishSubscribeDestination()
    }

}
