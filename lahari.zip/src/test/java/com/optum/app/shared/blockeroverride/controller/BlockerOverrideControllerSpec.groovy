package com.optum.app.shared.blockeroverride.controller

import com.optum.app.ocm.controller.support.CommonResponse
import com.optum.app.shared.blockeroverride.data.BlockerOverrideVO
import com.optum.app.shared.blockeroverride.data.CustomBlockerDetailsDO
import com.optum.app.shared.blockeroverride.helper.BlockerOverrideHelper
import com.optum.rf.common.featureflag.util.FeatureFlagManager
import com.optum.rf.common.featureflag.util.FeatureFlagUtility
import spock.lang.Specification
import spock.lang.Unroll

class BlockerOverrideControllerSpec extends Specification {
    BlockerOverrideController blockerOverrideController

    BlockerOverrideHelper blockerOverrideHelper
    FeatureFlagManager featureFlagManager

    def setup() {
        blockerOverrideHelper = Mock(BlockerOverrideHelper)
        featureFlagManager = Mock(FeatureFlagManager)

        blockerOverrideController = new BlockerOverrideController()
        blockerOverrideController.blockerOverrideHelper = blockerOverrideHelper

        FeatureFlagUtility.featureFlagManager = featureFlagManager
    }

    @Unroll
    def 'test checkOverridePermission'() {
        given:
        boolean featureFlag = true

        when:
        CommonResponse commonResponse = blockerOverrideController.checkOverridePermission()

        then:
        1 * blockerOverrideHelper.checkOverridePermission()
        0 * _
    }

    @Unroll
    def 'test overrideBlockers featureFlag Active'() {
        given:
        boolean featureFlag = true

        when:
        CommonResponse commonResponse = blockerOverrideController.overrideBlockers(customBlockerDetailsDO)

        then:
        1 * blockerOverrideHelper.overrideBlockers(customBlockerDetailsDO)
        1 * featureFlagManager.isActive(_) >> featureFlag
        0 * _

        where:
        testCase | customBlockerDetailsDO
        0        | new CustomBlockerDetailsDO(overrideTypeIDList: Arrays.asList(1), blockerOverrideVOList: Arrays.asList(new BlockerOverrideVO(hscID: 1234L, overrideTypeID: "1", overrideReasonCode: "2", overrideDescription: "abc", primaryServiceReferenceNum: "A1234")))
        1        | new CustomBlockerDetailsDO(overrideTypeIDList: Arrays.asList(1,3), blockerOverrideVOList: Arrays.asList(new BlockerOverrideVO(hscID: 1234L, overrideTypeID: "1", overrideReasonCode: "2", overrideDescription: "abc", primaryServiceReferenceNum: "A1234"), new BlockerOverrideVO(hscID: 1234L, overrideTypeID: "3", overrideReasonCode: "4", overrideDescription: "abc", primaryServiceReferenceNum: "A1234")))
        2        | new CustomBlockerDetailsDO()
    }

    @Unroll
    def 'test overrideBlockers featureFlag Inactive'() {
        given:
        boolean featureFlag = false

        when:
        CommonResponse commonResponse = blockerOverrideController.overrideBlockers(customBlockerDetailsDO)

        then:
        1 * featureFlagManager.isActive(_) >> featureFlag
        0 * _

        where:
        testCase | customBlockerDetailsDO
        0        | new CustomBlockerDetailsDO(overrideTypeIDList: Arrays.asList(1), blockerOverrideVOList: Arrays.asList(new BlockerOverrideVO(hscID: 1234L, overrideTypeID: "1", overrideReasonCode: "2", overrideDescription: "abc", primaryServiceReferenceNum: "A1234")))
        1        | new CustomBlockerDetailsDO(overrideTypeIDList: Arrays.asList(1,3), blockerOverrideVOList: Arrays.asList(new BlockerOverrideVO(hscID: 1234L, overrideTypeID: "1", overrideReasonCode: "2", overrideDescription: "abc", primaryServiceReferenceNum: "A1234"), new BlockerOverrideVO(hscID: 1234L, overrideTypeID: "3", overrideReasonCode: "4", overrideDescription: "abc", primaryServiceReferenceNum: "A1234")))
        2        | new CustomBlockerDetailsDO()
    }

    @Unroll
    def 'test getOverriddenBlockers featureFlag active'(){
        when:
        CommonResponse response = blockerOverrideController.getOverriddenBlockers(hscID)

        then:
        1 * featureFlagManager.isActive(_) >> featureFlag
        1 * blockerOverrideHelper.getOverriddenBlockers(hscID)

        where:
        testCase | hscID |  featureFlag
        0        |  1L   |  true
        1        |  2L   |  true
    }

    @Unroll
    def 'test getOverriddenBlockers featureFlag inactive'(){
        when:
        CommonResponse response = blockerOverrideController.getOverriddenBlockers(hscID)

        then:
        1 * featureFlagManager.isActive(_) >> featureFlag

        and:
        response.getEmbedded() == result.getEmbedded()

        where:
        testCase | hscID | featureFlag | result
        0        |  0L   | false       | new CommonResponse().setEmbedded([])
        1        |  1L   | false       | new CommonResponse().setEmbedded([])
    }

    @Unroll
    def 'test deleteSpecificOverriddenBlockers featureFlag Active'() {
        given:
        boolean featureFlag = true

        when:
        CommonResponse commonResponse = blockerOverrideController.deleteSpecificOverriddenBlockers(hscID, overrideTypeIDList)

        then:
        1 * blockerOverrideHelper.deleteSpecificOverriddenBlockers(hscID, overrideTypeIDList)
        1 * featureFlagManager.isActive(_) >> featureFlag
        0 * _

        where:
        testCase | hscID | overrideTypeIDList
        0        | 1L    | Arrays.asList(new Long(1L), new Long(3L))
        1        | 2L    | Arrays.asList(new Long(3L))
    }

    @Unroll
    def 'test deleteSpecificOverriddenBlockers featureFlag Inactive'() {
        given:
        boolean featureFlag = false

        when:
        CommonResponse commonResponse = blockerOverrideController.deleteSpecificOverriddenBlockers(hscID, overrideTypeIDList)

        then:
        1 * featureFlagManager.isActive(_) >> featureFlag
        0 * _

        where:
        testCase | hscID | overrideTypeIDList
        0        | 1L    | Arrays.asList(new Long(1L), new Long(3L))
        1        | 2L    | Arrays.asList(new Long(3L))
    }
}
