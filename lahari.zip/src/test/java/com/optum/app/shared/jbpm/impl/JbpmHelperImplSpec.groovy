package com.optum.app.shared.jbpm.impl

import com.fasterxml.jackson.databind.ObjectMapper
import com.optum.app.common.activity.data.ActivityVO
import com.optum.app.ocm.common.member.businesslogic.Member
import com.optum.app.ocm.customer.businesslogic.Customer
import com.optum.app.shared.constants.SpclCareReferenceConstants
import com.optum.app.shared.diseaseTraversal.data.TreatmentRegimenVersionVO
import com.optum.app.shared.hsc.businesslogic.HscHelper
import com.optum.app.shared.jbpm.data.JbpmConstants
import com.optum.app.shared.microservice.constants.RestConstants
import com.optum.app.shared.procedure.businesslogic.ProcedureBrand
import com.optum.app.shared.tat.businesslogic.TatHelper
import com.optum.clinical.security.jwt.client.service.JwtClientService
import com.optum.mbm.flow.data.v1.request.DroolsRuleRequest
import com.optum.mbm.flow.data.v1.response.DroolsProcessResponse
import com.optum.mbm.flow.data.v1.signal.StepperSignal
import com.optum.mbm.flow.data.v1.signal.hsc.HscSignal
import com.optum.mbm.flow.data.v1.signal.hsc.TreatmentRegimenVersionSignal
import com.optum.rf.common.featureflag.util.FeatureFlagManager
import com.optum.rf.common.featureflag.util.FeatureFlagUtility
import com.optum.rf.common.settings.businesslogic.SystemSettingsWebService
import com.optum.rf.common.settings.businesslogic.SystemSettingsWebServiceModifier
import com.optum.rf.common.settings.data.SystemSettingsWebServiceModifierVO
import com.optum.rf.common.settings.data.SystemSettingsWebServiceVO
import com.optum.rf.common.webservice.logging.businesslogic.WebServiceLog
import com.optum.rf.dao.exception.UhgRuntimeException
import com.optum.app.common.hsr.businesslogic.Hsc
import com.optum.app.common.hsr.businesslogic.HscAttribute
import com.optum.app.common.hsr.data.HscAttributeVO
import com.optum.app.common.hsr.data.HscVO
import com.optum.app.common.member.core.data.MemberVO
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory
import org.springframework.web.client.RestClientException
import org.springframework.web.client.RestTemplate
import spock.lang.Specification
import spock.lang.Unroll

import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpSession
import java.sql.Date

class JbpmHelperImplSpec extends Specification {

    JbpmHelperImpl jbpmHelperImpl
    HscAttribute hscAttribute = Mock(HscAttribute)
    JwtClientService jwtClientService = Mock(JwtClientService)
    SystemSettingsWebService systemSettingsWebService = Mock(SystemSettingsWebService)
    SystemSettingsWebServiceModifier systemSettingsWebServiceModifier = Mock(SystemSettingsWebServiceModifier)
    WebServiceLog webServiceLog = Mock(WebServiceLog)
    ObjectMapper jsonObjectMapper = Mock(ObjectMapper)
    TatHelper tatHelper = Mock(TatHelper)
    RestTemplate restTemplate = Mock(RestTemplate)
    ProcedureBrand procedureBrand = Mock(ProcedureBrand)
    HttpSession httpSession = Mock(HttpSession)
    HttpServletRequest httpServletRequest = Mock(HttpServletRequest)
    Member member = Mock(Member)
    Hsc hsc = Mock(Hsc)
    HscHelper hscHelper = Mock(HscHelper)
    Customer customer = Mock(Customer)

    FeatureFlagManager featureFlagManager = Mock(FeatureFlagManager)

    def setup() {
        jbpmHelperImpl = new JbpmHelperImpl()
        jbpmHelperImpl.hscAttribute = hscAttribute
        jbpmHelperImpl.jwtClientService = jwtClientService
        jbpmHelperImpl.systemSettingsWebService = systemSettingsWebService
        jbpmHelperImpl.systemSettingsWebServiceModifier = systemSettingsWebServiceModifier
        jbpmHelperImpl.webServiceLog = webServiceLog
        jbpmHelperImpl.jsonObjectMapper = jsonObjectMapper
        jbpmHelperImpl.tatHelper = tatHelper
        jbpmHelperImpl.restTemplate = restTemplate
        jbpmHelperImpl.httpSession = httpSession
        jbpmHelperImpl.httpServletRequest = httpServletRequest
        jbpmHelperImpl.member = member
        jbpmHelperImpl.hsc = hsc
        jbpmHelperImpl.hscHelper = hscHelper
        jbpmHelperImpl.customer = customer
        FeatureFlagUtility.featureFlagManager = featureFlagManager
    }

    @Unroll
    def 'test signalJbpmProcess success #testCase'() {
        when:
        DroolsProcessResponse response = jbpmHelperImpl.signalJbpmProcess(hscVO, processInstanceId, signalName, signalEvent)

        then:
        1 * systemSettingsWebServiceModifier.read(RestConstants.WSID_MBM_FLOW, RestConstants.WSMODCATEGORY_JBPM_CONTAINER, RestConstants.WSMOD_JBPM_KEY) >> new SystemSettingsWebServiceModifierVO(webServiceModifierValue: 'jbpm_1.0.0-SNAPSHOT')
        1 * jwtClientService.getToken(RestConstants.JWTTOKEN_NAME, RestConstants.JWTTOKEN_NAME, 30)
        2 * systemSettingsWebService.read(RestConstants.WSID_MBM_FLOW) >> new SystemSettingsWebServiceVO(wsUrl: '')
        1 * httpSession.getId()
        1 * httpServletRequest.getHeader("mbmtransactionid")
        1 * restTemplate.getRequestFactory() >> requestFactory
        1 * restTemplate.setRequestFactory(requestFactory)
        1 * restTemplate.postForEntity(_, _, _) >> new ResponseEntity<DroolsProcessResponse>(droolsProcessResponse, HttpStatus.OK)
        1 * webServiceLog.addNewTransaction(_)

        and:
        droolsProcessResponse == response

        where:
        testCase | hscVO                    | processInstanceId | signalName | signalEvent | droolsProcessResponse                              | requestFactory
        0        | new HscVO(customerID:1)  | 12                | 'signal'   | null        | new DroolsProcessResponse(processInstanceId: 12)   | new HttpComponentsClientHttpRequestFactory()
        1        | new HscVO(customerID:1)  | 12                | 'signal'   | 'test'      | new DroolsProcessResponse(processInstanceId: 12)   | new HttpComponentsClientHttpRequestFactory()
    }

    def 'test signalJbpmProcess exception'() {
        given:
        HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory()

        when:
        jbpmHelperImpl.signalJbpmProcess(new HscVO(), 12, 'signal', 'test')

        then:
        1 * systemSettingsWebServiceModifier.read(RestConstants.WSID_MBM_FLOW, RestConstants.WSMODCATEGORY_JBPM_CONTAINER, RestConstants.WSMOD_JBPM_KEY) >> new SystemSettingsWebServiceModifierVO(webServiceModifierValue: 'jbpm_1.0.0-SNAPSHOT')
        1 * jwtClientService.getToken(RestConstants.JWTTOKEN_NAME, RestConstants.JWTTOKEN_NAME, 30)
        2 * systemSettingsWebService.read(RestConstants.WSID_MBM_FLOW) >> new SystemSettingsWebServiceVO(wsUrl: '')
        1 * httpSession.getId()
        1 * httpServletRequest.getHeader("mbmtransactionid")
        1 * restTemplate.getRequestFactory() >> requestFactory
        1 * restTemplate.setRequestFactory(requestFactory)
        1 * restTemplate.postForEntity(_, _, _) >> { throw new RestClientException('An error has occurred.') }
        1 * webServiceLog.addNewTransaction(_)

        and:
        thrown(UhgRuntimeException)
    }

    @Unroll
    def 'test signalJbpmProcessSafe success #testCase'() {
        when:
        DroolsProcessResponse response = jbpmHelperImpl.signalJbpmProcessSafe(hscVO, processInstanceId, signalName, signalEvent)

        then:
        1 * systemSettingsWebServiceModifier.read(RestConstants.WSID_MBM_FLOW, RestConstants.WSMODCATEGORY_JBPM_CONTAINER, RestConstants.WSMOD_JBPM_KEY) >> new SystemSettingsWebServiceModifierVO(webServiceModifierValue: 'jbpm_1.0.0-SNAPSHOT')
        1 * jwtClientService.getToken(RestConstants.JWTTOKEN_NAME, RestConstants.JWTTOKEN_NAME, 30)
        2 * systemSettingsWebService.read(RestConstants.WSID_MBM_FLOW) >> new SystemSettingsWebServiceVO(wsUrl: '')
        1 * httpSession.getId()
        1 * httpServletRequest.getHeader("mbmtransactionid")
        1 * restTemplate.getRequestFactory() >> requestFactory
        1 * restTemplate.setRequestFactory(requestFactory)
        1 * restTemplate.postForEntity(_, _, _) >> new ResponseEntity<DroolsProcessResponse>(droolsProcessResponse, HttpStatus.OK)
        1 * webServiceLog.addNewTransaction(_)

        and:
        droolsProcessResponse == response

        where:
        testCase | hscVO                    |   processInstanceId   | signalName | signalEvent | droolsProcessResponse                              | requestFactory
        0        | new HscVO(customerID: 1) | 12                    | 'signal'   | null        | new DroolsProcessResponse(processInstanceId: 12)   | new HttpComponentsClientHttpRequestFactory()
        1        | new HscVO(customerID: 1) | 12                    | 'signal'   | 'test'      | new DroolsProcessResponse(processInstanceId: 12)   | new HttpComponentsClientHttpRequestFactory()
    }

    def 'test signalJbpmProcessSafe exception'() {
        given:
        HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory()

        when:
        jbpmHelperImpl.signalJbpmProcessSafe(new HscVO(), 12, 'signal', 'test')

        then:
        1 * systemSettingsWebServiceModifier.read(RestConstants.WSID_MBM_FLOW, RestConstants.WSMODCATEGORY_JBPM_CONTAINER, RestConstants.WSMOD_JBPM_KEY) >> new SystemSettingsWebServiceModifierVO(webServiceModifierValue: 'jbpm_1.0.0-SNAPSHOT')
        1 * jwtClientService.getToken(RestConstants.JWTTOKEN_NAME, RestConstants.JWTTOKEN_NAME, 30)
        2 * systemSettingsWebService.read(RestConstants.WSID_MBM_FLOW) >> new SystemSettingsWebServiceVO(wsUrl: '')
        1 * httpSession.getId()
        1 * httpServletRequest.getHeader("mbmtransactionid")
        1 * restTemplate.getRequestFactory() >> requestFactory
        1 * restTemplate.setRequestFactory(requestFactory)
        1 * restTemplate.postForEntity(_, _, _) >> { throw new RestClientException('An error has occurred.') }
        1 * webServiceLog.addNewTransaction(_)

        and:
        thrown(UhgRuntimeException)
    }

    @Unroll
    def 'test sendStepperContinueSignal - #testCase'() {
        when:
        DroolsProcessResponse response = jbpmHelperImpl.sendStepperContinueSignal(hscVO, memberVO, null, JbpmConstants.DYNAMIC_AUTH_STEPPER_FLOW, stepperLocation)

        then:
        1 * systemSettingsWebServiceModifier.read(RestConstants.WSID_MBM_FLOW, RestConstants.WSMODCATEGORY_JBPM_CONTAINER, RestConstants.WSMOD_JBPM_KEY) >> new SystemSettingsWebServiceModifierVO(webServiceModifierValue: 'jbpm_1.0.0-SNAPSHOT')
        1 * jwtClientService.getToken(RestConstants.JWTTOKEN_NAME, RestConstants.JWTTOKEN_NAME, 30)
        2 * systemSettingsWebService.read(RestConstants.WSID_MBM_FLOW) >> new SystemSettingsWebServiceVO(wsUrl: '')
        2 * httpSession.getId()
        2 * httpServletRequest.getHeader("mbmtransactionid")
        1 * restTemplate.getRequestFactory() >> requestFactory
        1 * restTemplate.setRequestFactory(requestFactory)
        1 * restTemplate.postForEntity(_, _, _) >> new ResponseEntity<DroolsProcessResponse>(droolsProcessResponse, HttpStatus.OK)
        1 * webServiceLog.addNewTransaction(_)
        (newProcessInstance ? 1 : 0) * hscAttribute.save(_)

        and:
        droolsProcessResponse == response

        where:
        testCase                                          | hscVO                                                                                                                                                    | memberVO                                        | stepperLocation | newProcessInstance | droolsProcessResponse                                               |   requestFactory
        'No process instance ID'                          | new HscVO(customerID: 1, hscAttributeVOs: [])                                                                                                                           | new MemberVO(birthDate: new Date(1992, 11, 12)) | '35'            | true               | new DroolsProcessResponse(processInstanceId: 12L)  |   new HttpComponentsClientHttpRequestFactory()
        'No process instance ID, no JBPM response'        | new HscVO(customerID: 1, hscAttributeVOs: [])                                                                                                                           | new MemberVO(birthDate: new Date(1992, 11, 12)) | '35'            | false              | null                                               |   new HttpComponentsClientHttpRequestFactory()
        'New process instance created'                    | new HscVO(customerID: 1, hscAttributeVOs: [new HscAttributeVO(hscAttributeType: SpclCareReferenceConstants.HSCATTRIBUTETYPE_JBPM_PROCESS_ID, hscAttributeValue: '10')]) | new MemberVO(birthDate: new Date(1992, 11, 12)) | '35'            | true               | new DroolsProcessResponse(processInstanceId: 12L)  |   new HttpComponentsClientHttpRequestFactory()
        'Process instance exists, no JBPM response'       | new HscVO(customerID: 1, hscAttributeVOs: [new HscAttributeVO(hscAttributeType: SpclCareReferenceConstants.HSCATTRIBUTETYPE_JBPM_PROCESS_ID, hscAttributeValue: '10')]) | new MemberVO(birthDate: new Date(1992, 11, 12)) | '35'            | false              | null                                               |   new HttpComponentsClientHttpRequestFactory()
        'Existing process instance signaled successfully' | new HscVO(customerID: 1, hscAttributeVOs: [new HscAttributeVO(hscAttributeType: SpclCareReferenceConstants.HSCATTRIBUTETYPE_JBPM_PROCESS_ID, hscAttributeValue: '12')]) | new MemberVO(birthDate: new Date(1992, 11, 12)) | '35'            | true              | new DroolsProcessResponse(processInstanceId: 12L)  |   new HttpComponentsClientHttpRequestFactory()
    }

    @Unroll
    def 'testMapStepperSignal - #testCase'() {
        when:
        StepperSignal stepperSignal = jbpmHelperImpl.mapStepperSignal(hscVO, memberVO, activityVO, stepperLocation)

        then:
        noExceptionThrown()

        where:
        testCase        | hscVO         | memberVO          | activityVO        | stepperLocation
        'Null memberVO' | new HscVO()   | null              | new ActivityVO()  | 'testLocation'
        'NULL hscVO'    | null          | new MemberVO()    | new ActivityVO()  | 'testLocation'
    }

    def 'test mapTreatmentRegimenVersionSignal'() {
        given:
        TreatmentRegimenVersionVO treatmentRegimenVersionVO = new TreatmentRegimenVersionVO()
        treatmentRegimenVersionVO.setDrugClass("abc")
        jbpmHelperImpl.jsonObjectMapper = new ObjectMapper()

        when:
        TreatmentRegimenVersionSignal actual = jbpmHelperImpl.mapTreatmentRegimenVersionSignal(treatmentRegimenVersionVO)

        then:
        actual.getDrugClass() == "abc"
    }

    def 'test callRules'() {
        given:
        HscSignal hscSignal = new HscSignal(customerID: 123l)
        StepperSignal stepperSignal = new StepperSignal(hscSignal: hscSignal)
        DroolsRuleRequest request = new DroolsRuleRequest(groupName: "abc", stepperSignal: stepperSignal)
        SystemSettingsWebServiceVO systemSettingsWebServiceVO = new SystemSettingsWebServiceVO()

        when:
        Object actual = jbpmHelperImpl.callRules(request)

        then:
        1 * systemSettingsWebService.read(RestConstants.WSID_MBM_FLOW) >> systemSettingsWebServiceVO
        1 * restTemplate.getRequestFactory() >> new HttpComponentsClientHttpRequestFactory()
        1 * restTemplate.postForEntity(systemSettingsWebServiceVO.getWsUrl() +  RestConstants.MBM_FLOW_CALL_RULES, _, Object) >> responseEntity

        and:
        actual == responseBody

        where:
        testCase                                    | responseEntity                                      | responseBody
        'When Rules Response is a valid string'     | new ResponseEntity<Object>("hello", HttpStatus.OK)  | "hello"
        'When Rules Response is an array of null'   | new ResponseEntity<Object>([null], HttpStatus.OK)   | [null]
        'When Rules Response is null'               | new ResponseEntity<Object>(null, HttpStatus.OK)     | null
    }

}
