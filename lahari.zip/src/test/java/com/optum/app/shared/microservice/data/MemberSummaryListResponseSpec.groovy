package com.optum.app.shared.microservice.data

import com.optum.app.shared.microservice.data.MemberSummaryListResponse
import org.apache.commons.lang.StringUtils
import spock.lang.Specification

/**
 * Created by cnadipin on 1/10/19.
 */
class MemberSummaryListResponseSpec extends Specification{

    MemberSummaryListResponse memberSummaryListResponse

    def setup(){
        memberSummaryListResponse = new MemberSummaryListResponse(pageNumber:'1', pageSize:'2', recordCount: '3', totalCount: '4', totalPages: '5')
    }

    def "equals"(){
        when:
        boolean result = memberSummaryListResponse.equals(memberSummaryListResponse)

        then:
        0 * _

        and:
        result
    }

    def "not equals"(){
        when:
        boolean result = memberSummaryListResponse.equals(_)

        then:
        0 * _

        and:
        !result
    }

    def "hash"(){
        given:
        MemberSummaryListResponse testObj = new MemberSummaryListResponse(pageNumber:'1', pageSize:'2', recordCount: '3', totalCount: '4', totalPages: '5')

        when:
        int hashVal = testObj.hashCode()

        then:
        0 * _

        and:
        hashVal
        hashVal > 0
        memberSummaryListResponse.hashCode() == hashVal
    }

    def "to String"(){
        given:
        MemberSummaryListResponse testObj = new MemberSummaryListResponse(pageNumber:'1', pageSize:'2', recordCount: '3', totalCount: '4', totalPages: '5')

        when:
        String val = testObj.toString()

        then:
        0 * _

        and:
        StringUtils.isNotBlank(val)
    }
}
