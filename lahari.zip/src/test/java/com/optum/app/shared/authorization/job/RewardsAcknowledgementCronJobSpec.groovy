package com.optum.app.shared.authorization.job

import spock.lang.Specification

class RewardsAcknowledgementCronJobSpec extends Specification{

    def "test RewardsAcknowledgementCronJob"(){
        given:
        RewardsAcknowledgementCronJob rewardsAcknowledgementCronJob = new RewardsAcknowledgementCronJob()

        when:
        rewardsAcknowledgementCronJob != null

        then:
        rewardsAcknowledgementCronJob.getCronPattern() == "1 0 1 2,8 *"
        rewardsAcknowledgementCronJob.getSystemJobID() == "PRA"
        rewardsAcknowledgementCronJob.getDescription() == "Pathways Reward Acknowledgement"
        rewardsAcknowledgementCronJob.getTask() != null
    }

}
