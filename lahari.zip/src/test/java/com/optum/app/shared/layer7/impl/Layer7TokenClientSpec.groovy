package com.optum.app.shared.layer7.impl

import com.optum.app.shared.layer7.data.Layer7Token
import com.optum.app.shared.layer7.impl.Layer7TokenClientImpl
import com.optum.app.shared.microservice.constants.RestConstants
import com.optum.rf.common.settings.businesslogic.SystemSettingsWebServiceModifier
import com.optum.rf.common.settings.data.SystemSettingsWebServiceModifierVO
import com.optum.rf.common.webservice.logging.businesslogic.WebServiceLog
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.client.HttpClientErrorException
import org.springframework.web.client.RestTemplate
import spock.lang.Specification
import spock.lang.Unroll

import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpSession

class Layer7TokenClientSpec extends Specification {

    Layer7TokenClientImpl layer7TokenClient
    RestTemplate restTemplate
    SystemSettingsWebServiceModifier systemSettingsWebServiceModifier
    WebServiceLog webServiceLog
    HttpServletRequest httpServletRequest
    HttpSession httpSession

    def setup() {
        layer7TokenClient = new Layer7TokenClientImpl()
        restTemplate = Mock(RestTemplate)
        systemSettingsWebServiceModifier = Mock(SystemSettingsWebServiceModifier)
        webServiceLog = Mock(WebServiceLog)

        layer7TokenClient.restTemplate = restTemplate
        layer7TokenClient.systemSettingsWebServiceModifier = systemSettingsWebServiceModifier
        layer7TokenClient.webServiceLog = webServiceLog
        httpServletRequest = Mock(HttpServletRequest)
        httpSession = Mock(HttpSession)
        layer7TokenClient.httpSession = httpSession
        layer7TokenClient.httpServletRequest = httpServletRequest
    }

    @Unroll
    def 'test getToken(webServiceID) #testCase'() {
        given:
        Layer7Token newToken = new Layer7Token(expiresIn: 30)

        when:
        Layer7Token returnedToken = layer7TokenClient.getToken(webServiceID)

        then:
        1 * systemSettingsWebServiceModifier.read(webServiceID, RestConstants.WSMODCATEGORY_OAUTH_SECURITY, RestConstants.WSMODKEY_ACCESS_TOKEN_URL) >> new SystemSettingsWebServiceModifierVO(webServiceModifierValue: trustBrokerURL)
        1 * systemSettingsWebServiceModifier.read(webServiceID, RestConstants.WSMODCATEGORY_OAUTH_SECURITY, RestConstants.WSMODKEY_CLIENT_ID) >> new SystemSettingsWebServiceModifierVO(webServiceModifierValue: clientId)
        1 * systemSettingsWebServiceModifier.read(webServiceID, RestConstants.WSMODCATEGORY_OAUTH_SECURITY, RestConstants.WSMODKEY_CLIENT_SECRET) >> new SystemSettingsWebServiceModifierVO(webServiceModifierValue: clientSecret)
        1 * restTemplate.postForEntity(trustBrokerURL, _, Layer7Token) >> ResponseEntity.ok(newToken)
        newToken == returnedToken

        where:
        testCase | webServiceID | trustBrokerURL             | clientId | clientSecret
        0        | 'wsID'       | null                       | null     | null
        1        | 'wsID'       | 'http://example.com:8082/' | 'client' | 'secret'
    }

    @Unroll
    def 'test getToken(trustBrokerURL, clientId, clientSecret) #testCase'() {
        given:
        Layer7Token newToken = new Layer7Token(expiresIn: 30)

        when:
        Layer7Token returnedToken = layer7TokenClient.getToken(trustBrokerURL, clientId, clientSecret)

        then:
        1 * restTemplate.postForEntity(trustBrokerURL, _, Layer7Token) >> ResponseEntity.ok(newToken)
        newToken == returnedToken

        where:
        testCase | trustBrokerURL             | clientId | clientSecret
        0        | null                       | null     | null
        1        | 'http://example.com:8082/' | 'client' | 'secret'
    }

    @Unroll
    def 'test buildWebServiceHeaders success #testCase'() {
        given:
        Layer7Token newToken = new Layer7Token(accessToken: 'test', tokenType: 'Bearer', expiresIn: 30, scope: 'oob')

        when:
        HttpHeaders headers = layer7TokenClient.buildWebServiceHeaders(webServiceID)

        then:
        1 * systemSettingsWebServiceModifier.read(webServiceID, RestConstants.WSMODCATEGORY_OAUTH_HEADER, RestConstants.WSMODKEY_ACTOR) >> new SystemSettingsWebServiceModifierVO(webServiceModifierValue: authActor)
        1 * systemSettingsWebServiceModifier.read(webServiceID, RestConstants.WSMODCATEGORY_OAUTH_SECURITY, RestConstants.WSMODKEY_ACCESS_TOKEN_URL) >> new SystemSettingsWebServiceModifierVO(webServiceModifierValue: trustBrokerURL)
        1 * systemSettingsWebServiceModifier.read(webServiceID, RestConstants.WSMODCATEGORY_OAUTH_SECURITY, RestConstants.WSMODKEY_CLIENT_ID) >> new SystemSettingsWebServiceModifierVO(webServiceModifierValue: clientId)
        1 * systemSettingsWebServiceModifier.read(webServiceID, RestConstants.WSMODCATEGORY_OAUTH_SECURITY, RestConstants.WSMODKEY_CLIENT_SECRET) >> new SystemSettingsWebServiceModifierVO(webServiceModifierValue: clientSecret)
        1 * httpSession.getId()
        1 * httpServletRequest.getHeader('mbmtransactionid')
        1 * restTemplate.postForEntity(trustBrokerURL, _, Layer7Token) >> ResponseEntity.ok(newToken)
        0 * _

        and:
        headers.getFirst(RestConstants.CLIENT_SCOPE) == 'oob'
        headers.getFirst(RestConstants.CLIENTID) == clientId
        headers.getFirst(RestConstants.CLIENT_AUTH_ACTOR) == authActor
        headers.getFirst(HttpHeaders.AUTHORIZATION) == 'Bearer test'

        where:
        testCase | webServiceID | authActor | trustBrokerURL             | clientId | clientSecret
        0        | 'wsID'       | null      | null                       | null     | null
        1        | 'wsID'       | 'actor'   | 'http://example.com:8082/' | 'client' | 'secret'
    }


    @Unroll
    def 'test buildWebServiceHeaders exception #testCase'() {
        when:
        layer7TokenClient.buildWebServiceHeaders(webServiceID)

        then:
        1 * systemSettingsWebServiceModifier.read(webServiceID, RestConstants.WSMODCATEGORY_OAUTH_HEADER, RestConstants.WSMODKEY_ACTOR) >> new SystemSettingsWebServiceModifierVO(webServiceModifierValue: authActor)
        1 * systemSettingsWebServiceModifier.read(webServiceID, RestConstants.WSMODCATEGORY_OAUTH_SECURITY, RestConstants.WSMODKEY_ACCESS_TOKEN_URL) >> new SystemSettingsWebServiceModifierVO(webServiceModifierValue: trustBrokerURL)
        1 * systemSettingsWebServiceModifier.read(webServiceID, RestConstants.WSMODCATEGORY_OAUTH_SECURITY, RestConstants.WSMODKEY_CLIENT_ID) >> new SystemSettingsWebServiceModifierVO(webServiceModifierValue: clientId)
        1 * systemSettingsWebServiceModifier.read(webServiceID, RestConstants.WSMODCATEGORY_OAUTH_SECURITY, RestConstants.WSMODKEY_CLIENT_SECRET) >> new SystemSettingsWebServiceModifierVO(webServiceModifierValue: clientSecret)
        1 * restTemplate.postForEntity(trustBrokerURL, _, Layer7Token) >> ResponseEntity.ok(layer7Token)
        0 * _

        and:
        HttpClientErrorException exception = thrown()
        exception.getStatusCode() == HttpStatus.UNAUTHORIZED

        where:
        testCase | webServiceID | authActor | trustBrokerURL             | clientId | clientSecret | layer7Token
        0        | 'wsID'       | 'actor'   | 'http://example.com:8082/' | 'client' | 'secret'     | new Layer7Token()
        1        | 'wsID'       | 'actor'   | 'http://example.com:8082/' | 'client' | 'secret'     | new Layer7Token(tokenType: 'type')
        2        | 'wsID'       | 'actor'   | 'http://example.com:8082/' | 'client' | 'secret'     | new Layer7Token(accessToken: 'access')
    }

    def 'test restTemplate'() {
        when:
        RestTemplate template = Layer7TokenClientImpl.restTemplate()

        then:
        template
    }
}
