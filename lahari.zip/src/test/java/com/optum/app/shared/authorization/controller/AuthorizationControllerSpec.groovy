package com.optum.app.shared.authorization.controller

import com.optum.app.common.activity.data.CommunicationTransactionVO
import com.optum.app.common.hsr.businesslogic.Hsc
import com.optum.app.common.hsr.businesslogic.HscFollowUpContact
import com.optum.app.common.hsr.businesslogic.HscProvider
import com.optum.app.common.hsr.businesslogic.HscProviderRole
import com.optum.app.common.hsr.businesslogic.UserHscHistory
import com.optum.app.common.hsr.constants.HsrReferenceConstants
import com.optum.app.common.hsr.data.HscProviderRoleVO
import com.optum.app.common.hsr.data.HscAttributeVO
import com.optum.app.common.hsr.data.HscFollowUpContactVO
import com.optum.app.common.hsr.data.HscProviderRoleVO
import com.optum.app.common.hsr.data.HscProviderVO
import com.optum.app.common.hsr.data.HscSpecialtyProcedureVO
import com.optum.app.common.hsr.data.HscVO
import com.optum.app.common.member.core.data.MemberCoverageVO
import com.optum.app.common.member.core.data.MemberVO
import com.optum.app.ocm.common.activity.businesslogic.CommunicationTransaction
import com.optum.app.ocm.common.member.businesslogic.MemberCoverage
import com.optum.app.ocm.controller.support.CommonResponse
import com.optum.app.shared.authorization.businesslogic.Authorizations
import com.optum.app.shared.common.messages.SpclCareMessages
import com.optum.app.shared.constants.MultiPayerConstants
import com.optum.app.shared.constants.SpclCareFeatureFlagConstants
import com.optum.app.shared.constants.SpclCareReferenceConstants
import com.optum.app.shared.diseaseTraversal.businesslogic.AuthorizationRuleHelper
import com.optum.app.shared.documentManager.businesslogic.DocumentManagerService
import com.optum.app.shared.drugRounding.businesslogic.DrugRounding
import com.optum.app.shared.drugRounding.data.DrugRoundingRequestDO
import com.optum.app.shared.drugRounding.data.DrugRoundingResponseDO
import com.optum.app.shared.hsc.businesslogic.HscHelper
import com.optum.app.shared.hsc.businesslogic.HscSearch
import com.optum.app.shared.hsc.businesslogic.HscUpdate
import com.optum.app.shared.hsc.data.GenerateHscDO
import com.optum.app.shared.jbpm.JbpmHelper
import com.optum.app.shared.microservice.data.ProviderDetails
import com.optum.app.shared.specialtyPharmacy.data.SpecialtyProceduresViewVO
import com.optum.rf.common.featureflag.util.FeatureFlagManager
import com.optum.rf.common.featureflag.util.FeatureFlagUtility
import com.optum.rf.common.security.data.UserSecurityVO
import com.optum.rf.dao.controller.session.Session
import com.optum.rf.dao.controller.session.SessionThreadLocal
import com.optum.rf.dao.exception.UhgRuntimeException
import com.optum.rf.dao.sql.query.QueryFilter
import com.optum.rf.dao.sql.query.QueryProperties
import com.optum.rf.dao.util.UhgCalendarUtilities
import com.optum.rf.web.controller.session.HttpUserSession
import com.uhg.app.common.constants.spclcare.FieldConstants
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.multipart.MultipartFile
import spock.lang.Specification
import com.optum.app.shared.constants.SpclCareConstants
import spock.lang.Unroll

class AuthorizationControllerSpec extends Specification{

    Authorizations authorizations
    AuthorizationsController authorizationsController
    CommunicationTransaction communicationTransaction
    DocumentManagerService documentManagerService
    FeatureFlagManager featureFlagManager
    Hsc hsc
    HscFollowUpContact hscFollowUpContact
    HscHelper hscHelper
    HscProvider hscProvider
    HscProviderRole hscProviderRole
    HscSearch hscSearch
    HscUpdate hscUpdate
    JbpmHelper jbpmHelper
    DrugRounding drugRounding
    UserHscHistory userHscHistory
    AuthorizationRuleHelper authorizationRuleHelper
    MemberCoverage memberCoverage
    SessionThreadLocal sessionThreadLocal

    def setup() {
        authorizationsController = new AuthorizationsController()

        authorizations = Mock(Authorizations)
        communicationTransaction = Mock(CommunicationTransaction)
        documentManagerService = Mock(DocumentManagerService)
        featureFlagManager = Mock(FeatureFlagManager)
        hsc =  Mock(Hsc)
        hscFollowUpContact = Mock(HscFollowUpContact)
        hscHelper = Mock(HscHelper)
        hscProvider = Mock(HscProvider)
        hscProviderRole = Mock(HscProviderRole)
        hscSearch = Mock(HscSearch)
        hscUpdate = Mock(HscUpdate)
        jbpmHelper = Mock(JbpmHelper)
        userHscHistory = Mock(UserHscHistory)
        drugRounding = Mock(DrugRounding)
        authorizationRuleHelper = Mock(AuthorizationRuleHelper)
        memberCoverage = Mock(MemberCoverage)
        sessionThreadLocal = Mock(SessionThreadLocal)

        authorizationsController.authorizations = authorizations
        authorizationsController.communicationTransaction = communicationTransaction
        authorizationsController.documentManagerService = documentManagerService
        authorizationsController.hsc = hsc
        authorizationsController.hscFollowUpContact = hscFollowUpContact
        authorizationsController.hscHelper = hscHelper
        authorizationsController.hscProvider = hscProvider
        authorizationsController.hscProviderRole = hscProviderRole
        authorizationsController.hscSearch = hscSearch
        authorizationsController.userHscHistory = userHscHistory
        authorizationsController.drugRounding = drugRounding
        authorizationsController.hscUpdate = hscUpdate
        authorizationsController.authorizationRuleHelper = authorizationRuleHelper
        authorizationsController.memberCoverage = memberCoverage


        FeatureFlagUtility.featureFlagManager = featureFlagManager
    }

    def "getHsc"() {
        given:
        long hscID = 1L
        int customerID = 1

        HscVO hscVO = new HscVO(hscID: hscID)

        when:
        CommonResponse response = authorizationsController.getHsc(customerID,hscID)

        then:
        1 * authorizations.validateAuthorization(customerID,hscID,false)
        1 * hscHelper.readCascadingSpclCare(hscID) >> hscVO
        1 * userHscHistory.saveUserHscHistory(_)
        0 * _

        and:
        response.getEmbedded() == ['_embedded': hscVO]
    }

    def "getHscStatus"() {
        given:
        long hscID = 1L
        int customerID = 1

        HscVO hscVO = new HscVO(hscID: hscID)
        CommonResponse searchResult = new CommonResponse()
        searchResult.setEmbedded(hscVO)

        when:
        CommonResponse response = authorizationsController.getHscStatus(customerID,hscID)

        then:
        1 * authorizations.validateAuthorization(customerID,hscID,false)
        1 * hscSearch.getHsc(hscID) >> searchResult
        0 * _

        and:
        response.getEmbedded() == ['_embedded': hscVO]
    }

    def 'getCommunicationTransaction'() {
        given:
        long hscID = 1L
        int customerID = 1

        CommunicationTransactionVO commTransVO = new CommunicationTransactionVO()

        when:
        CommonResponse response = authorizationsController.getCommunicationTransactionByHscID(customerID, hscID)

        then:
        1 * authorizations.validateAuthorization(customerID,hscID,false)
        1 * communicationTransaction.getByHscID(hscID) >> commTransVO
        0 * _

        and:
        response.getEmbedded() == ['_embedded': commTransVO]
    }

    def 'saveCommunicationTransaction'() {
        given:
        long hscID = 1L
        int customerID = 1

        CommunicationTransactionVO commTransVO = new CommunicationTransactionVO()

        when:
        CommonResponse response = authorizationsController.saveCommunicationTransaction(customerID, hscID, commTransVO)

        then:
        1 * authorizations.validateAuthorization(customerID, hscID,true)
        1 * communicationTransaction.save(commTransVO)
        0 * _

        and:
        response.getEmbedded() == ['_embedded': commTransVO]
    }

    def "saveRequestingContactDetails"() {
        given:
        long hscID = 1L
        int customerID = 1

        HscFollowUpContactVO contactVO = new HscFollowUpContactVO(hscID: hscID)

        when:
        CommonResponse response = authorizationsController.saveRequestingContactDetails(customerID, hscID, contactVO)

        then:
        1 * authorizations.validateAuthorization(customerID, hscID,true)
        1 * hscFollowUpContact.save(contactVO)
        0 * _

        and:
        response.getEmbedded() == ['_embedded': contactVO]
    }

    @Unroll
    def "saveRequestingProvider"() {
        given:
        long hscID = 5555L
        long TEST_HSC_ID = 1234L
        long memberID = 5678L
        int customerID = 1
        short providerSeqNum = 1
        boolean featureFlag = true
        String stepperLocation = SpclCareReferenceConstants.AUTH_STEPPER_REQUESTING_PROVIDER
        HscProviderVO requestingProvider = new HscProviderVO(hscID: TEST_HSC_ID, providerSeqNum: providerSeqNum)
        HscVO hscVO = new HscVO(hscID: hscID, memberID: memberID, authTypeID: authType)
        List<MemberCoverageVO> memberCoverageVOList = [new MemberCoverageVO()]
        List<String> ipaNumberList = [new String()]
        ProviderDetails providerDetails = new ProviderDetails()

        when:
        CommonResponse response = authorizationsController.saveRequestingProvider(customerID, hscID, requestingProvider)

        then:
        1 * hscHelper.isEandI(TEST_HSC_ID) >> isEandIMember
        1 * hscProvider.saveProviderAndRole(requestingProvider, HsrReferenceConstants.PROVIDER_ROLE_REQUESTING) >> requestingProvider
        1 * hscProvider.listByHscWithRoles(TEST_HSC_ID) >> []
        FeatureFlagUtility.getManager().isActive(SpclCareFeatureFlagConstants.DRAFT_JBPM_CALLS) >> false
        1 * hscHelper.autoTrackDraft(TEST_HSC_ID, stepperLocation)
        3 * hscHelper.getAuthType(TEST_HSC_ID) >> authType
        1 * hscHelper.isPHTherapyAuthorization(authType) >> true
        1 * hsc.read(TEST_HSC_ID) >> hscVO
        1 * memberCoverage.listByMemberID(_) >> memberCoverageVOList
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_PROVIDER_DETAILS_FOR_AUTH_TYPE) >> featureFlag
        1 * hscHelper.getProviderDetails(requestingProvider, memberCoverageVOList?.first()) >> providerDetails
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_PROVIDER_BLOCKING_RULES) >> featureFlag
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_MAP_UNIQUE_UNET_CONTRACT_LIST) >> featureFlag
        1 * hscHelper.getProviderIPAList(providerDetails, memberCoverageVOList?.first()) >> ipaNumberList
        1 * hscHelper.isPHTherapyAuthorization(hscVO.authTypeID) >> true
        1 * hscHelper.makeServicingProviderRoleSameAsRequestingProviderRole(hscVO.hscID)

        and:
        response.getEmbedded() == ['_embedded': requestingProvider]
        requestingProvider.requestingProviderInd

        where:
        isEandIMember | authTypeCheck | authType                                                     | deleteProviders
        true          | 1             | SpclCareReferenceConstants.AUTH_TYPE_PHYSICAL_THERAPY        | 0
        true          | 1             | SpclCareReferenceConstants.AUTH_TYPE_SPEECH_THERAPY          | 1
        true          | 1             | SpclCareReferenceConstants.AUTH_TYPE_OCCUPATIONAL_THERAPY    | 0
    }

    def "saveRequestingProvider - Save Provider DEA Number - UHC Payer"() {
        given:
        long hscID = 5555L
        long memberID = 5678L
        long TEST_HSC_ID = 1234L
        short providerSeqNum = 1
        int clientID = MultiPayerConstants.UHC_PAYER_ID
        boolean featureFlag = true
        HscProviderVO requestingProvider = new HscProviderVO(hscID: TEST_HSC_ID, providerSeqNum: providerSeqNum)
        HscVO hscVO = new HscVO(hscID: hscID, memberID: memberID, authTypeID: authType, hscAttributeVOs: [new HscAttributeVO(hscAttributeType: SpclCareReferenceConstants.HSCATTRIBUTETYPE_AUTHORIZATION_TYPE, hscAttributeValue: authType)])
        List<MemberCoverageVO> memberCoverageVOList = [new MemberCoverageVO(memberID: 2220L, reportCode: reportCode)]
        ProviderDetails providerDetails = new ProviderDetails(providerDEA: providerDEA)

        when:
        authorizationsController.saveRequestingProvider(clientID, hscID, requestingProvider)

        then:
        1 * hscProvider.saveProviderAndRole(requestingProvider, HsrReferenceConstants.PROVIDER_ROLE_REQUESTING) >> requestingProvider
        1 * hscProvider.listByHscWithRoles(TEST_HSC_ID) >> []
        2 * hscHelper.getAuthType(TEST_HSC_ID) >> authType
        1 * hsc.read(TEST_HSC_ID) >> hscVO
        1 * memberCoverage.listByMemberID(_) >> memberCoverageVOList
        1 * hscHelper.getProviderDetails(requestingProvider, memberCoverageVOList?.first()) >> providerDetails
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_PROVIDER_DETAILS_FOR_AUTH_TYPE) >> featureFlag
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_NETWORK_STATUS_DERIVATION_FOR_EXCHANGE) >> featureFlag

        and:
        requestingProvider.providerDEA == result

        where:
        testCase   | authType                                                     |  reportCode  | providerDEA | result
        0          | SpclCareReferenceConstants.AUTH_TYPE_INJECTABLE_CHEMOTHERAPY | 'EXGN'       | "FW0487353" | "FW0487353"
        1          | SpclCareReferenceConstants.AUTH_TYPE_INJECTABLE_CHEMOTHERAPY | 'EXGN'       | null        | null
        2          | SpclCareReferenceConstants.AUTH_TYPE_INJECTABLE_CHEMOTHERAPY |  null        | "FW0487353" | null
        3          | SpclCareReferenceConstants.AUTH_TYPE_INJECTABLE_CHEMOTHERAPY |  null        | null        | null
        4          | SpclCareReferenceConstants.AUTH_TYPE_SUPPORTIVE_DRUGS        | 'EXGN'       | "FW0487353" | "FW0487353"
        5          | SpclCareReferenceConstants.AUTH_TYPE_SUPPORTIVE_DRUGS        | 'EXGN'       | null        | null
        6          | SpclCareReferenceConstants.AUTH_TYPE_SUPPORTIVE_DRUGS        |  null        | "FW0487353" | null
        7          | SpclCareReferenceConstants.AUTH_TYPE_SUPPORTIVE_DRUGS        |  null        | null        | null
        8          | SpclCareReferenceConstants.AUTH_TYPE_RADIATION_ONCOLOGY      | 'EXGN'       | "FW0487353" | "FW0487353"
        9          | SpclCareReferenceConstants.AUTH_TYPE_RADIATION_ONCOLOGY      | 'EXGN'       | null        | null
        10         | SpclCareReferenceConstants.AUTH_TYPE_RADIATION_ONCOLOGY      |  null        | "FW0487353" | null
        11         | SpclCareReferenceConstants.AUTH_TYPE_RADIATION_ONCOLOGY      |  null        | null        | null
        12         | SpclCareReferenceConstants.AUTH_TYPE_RADIOPHARMACEUTICAL     | 'EXGN'       | "FW0487353" | "FW0487353"
        13         | SpclCareReferenceConstants.AUTH_TYPE_RADIOPHARMACEUTICAL     | 'EXGN'       | null        | null
        14         | SpclCareReferenceConstants.AUTH_TYPE_RADIOPHARMACEUTICAL     |  null        | "FW0487353" | null
        15         | SpclCareReferenceConstants.AUTH_TYPE_RADIOPHARMACEUTICAL     |  null        | null        | null
        16         | SpclCareReferenceConstants.AUTH_TYPE_SPECIALTY_PHARMACY      | 'EXGN'       | "FW0487353" | "FW0487353"
        17         | SpclCareReferenceConstants.AUTH_TYPE_SPECIALTY_PHARMACY      | 'EXGN'       | null        | null
        18         | SpclCareReferenceConstants.AUTH_TYPE_SPECIALTY_PHARMACY      |  null        | "FW0487353" | null
        19         | SpclCareReferenceConstants.AUTH_TYPE_SPECIALTY_PHARMACY      |  null        | null        | null
        20         | SpclCareReferenceConstants.AUTH_TYPE_PHYSICAL_THERAPY        | 'EXGN'       | "FW0487353" | "FW0487353"
        21         | SpclCareReferenceConstants.AUTH_TYPE_PHYSICAL_THERAPY        | 'EXGN'       | null        | null
        22         | SpclCareReferenceConstants.AUTH_TYPE_PHYSICAL_THERAPY        |  null        | "FW0487353" | null
        23         | SpclCareReferenceConstants.AUTH_TYPE_PHYSICAL_THERAPY        |  null        | null        | null
        24         | SpclCareReferenceConstants.AUTH_TYPE_SPEECH_THERAPY          | 'EXGN'       | "FW0487353" | "FW0487353"
        25         | SpclCareReferenceConstants.AUTH_TYPE_SPEECH_THERAPY          | 'EXGN'       | null        | null
        26         | SpclCareReferenceConstants.AUTH_TYPE_SPEECH_THERAPY          |  null        | "FW0487353" | null
        27         | SpclCareReferenceConstants.AUTH_TYPE_SPEECH_THERAPY          |  null        | null        | null
        28         | SpclCareReferenceConstants.AUTH_TYPE_OCCUPATIONAL_THERAPY    | 'EXGN'       | "FW0487353" | "FW0487353"
        29         | SpclCareReferenceConstants.AUTH_TYPE_OCCUPATIONAL_THERAPY    | 'EXGN'       | null        | null
        30         | SpclCareReferenceConstants.AUTH_TYPE_OCCUPATIONAL_THERAPY    |  null        | "FW0487353" | null
        31         | SpclCareReferenceConstants.AUTH_TYPE_OCCUPATIONAL_THERAPY    |  null        | null        | null
    }

    def "saveRequestingProvider - Save Provider DEA Number - BCBS Payer"() {
        given:
        long hscID = 5555L
        long memberID = 5678L
        long TEST_HSC_ID = 1234L
        int clientId = MultiPayerConstants.BCBS_SC_PAYER_ID
        short providerSeqNum = 1
        boolean featureFlag = true
        HscProviderVO requestingProvider = new HscProviderVO(hscID: TEST_HSC_ID, providerSeqNum: providerSeqNum)
        HscVO hscVO = new HscVO(hscID: hscID, memberID: memberID, authTypeID: authType, hscAttributeVOs: [new HscAttributeVO(hscAttributeType: SpclCareReferenceConstants.HSCATTRIBUTETYPE_AUTHORIZATION_TYPE, hscAttributeValue: authType)])
        List<MemberCoverageVO> memberCoverageVOList = [new MemberCoverageVO(memberID: 2220L, reportCode: null)]
        ProviderDetails providerDetails = new ProviderDetails(providerDEA: null)

        when:
        authorizationsController.saveRequestingProvider(clientId, hscID, requestingProvider)

        then:
        1 * hscProvider.saveProviderAndRole(requestingProvider, HsrReferenceConstants.PROVIDER_ROLE_REQUESTING) >> requestingProvider
        1 * hscProvider.listByHscWithRoles(TEST_HSC_ID) >> []
        2 * hscHelper.getAuthType(TEST_HSC_ID) >> authType
        1 * hsc.read(TEST_HSC_ID) >> hscVO
        1 * memberCoverage.listByMemberID(_) >> memberCoverageVOList
        1 * hscHelper.getProviderDetails(requestingProvider, memberCoverageVOList?.first()) >> providerDetails
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_PROVIDER_DETAILS_FOR_AUTH_TYPE) >> featureFlag
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_NETWORK_STATUS_DERIVATION_FOR_EXCHANGE) >> featureFlag

        and:
        requestingProvider.providerDEA == result

        where:
        testCase   | authType                                                       | result
        0          | SpclCareReferenceConstants.AUTH_TYPE_INJECTABLE_CHEMOTHERAPY   | null
        1          | SpclCareReferenceConstants.AUTH_TYPE_INJECTABLE_CHEMOTHERAPY   | null
        2          | SpclCareReferenceConstants.AUTH_TYPE_SUPPORTIVE_DRUGS          | null
        3          | SpclCareReferenceConstants.AUTH_TYPE_SUPPORTIVE_DRUGS          | null
        4          | SpclCareReferenceConstants.AUTH_TYPE_RADIOPHARMACEUTICAL       | null
        5          | SpclCareReferenceConstants.AUTH_TYPE_RADIOPHARMACEUTICAL       | null
    }

    def "saveRequestingProvider - Save Provider DEA Number - OC Payer"() {
        given:
        long hscID = 5555L
        long memberID = 5678L
        long TEST_HSC_ID = 1234L
        short providerSeqNum = 1
        boolean featureFlag = true
        HscProviderVO requestingProvider = new HscProviderVO(hscID: TEST_HSC_ID, providerSeqNum: providerSeqNum)
        HscVO hscVO = new HscVO(hscID: hscID, memberID: memberID, authTypeID: authType, hscAttributeVOs: [new HscAttributeVO(hscAttributeType: SpclCareReferenceConstants.HSCATTRIBUTETYPE_AUTHORIZATION_TYPE, hscAttributeValue: authType)])
        List<MemberCoverageVO> memberCoverageVOList = [new MemberCoverageVO(memberID: 2220L, reportCode: null)]
        ProviderDetails providerDetails = new ProviderDetails(providerDEA: null)


        when:
        authorizationsController.saveRequestingProvider(clientId, hscID, requestingProvider)

        then:
        1 * hscProvider.saveProviderAndRole(requestingProvider, HsrReferenceConstants.PROVIDER_ROLE_REQUESTING) >> requestingProvider
        1 * hscProvider.listByHscWithRoles(TEST_HSC_ID) >> []
        2 * hscHelper.getAuthType(TEST_HSC_ID) >> authType
        1 * hsc.read(TEST_HSC_ID) >> hscVO
        1 * memberCoverage.listByMemberID(_) >> memberCoverageVOList
        1 * hscHelper.getProviderDetails(requestingProvider, memberCoverageVOList?.first()) >> providerDetails
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_PROVIDER_DETAILS_FOR_AUTH_TYPE) >> featureFlag
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_NETWORK_STATUS_DERIVATION_FOR_EXCHANGE) >> featureFlag

        and:
        requestingProvider.providerDEA == result

        where:
        testCase   | clientId                                  | authType                                                     | result
        0          | MultiPayerConstants.OC_OMN_AZ_PAYER_ID    | SpclCareReferenceConstants.AUTH_TYPE_INJECTABLE_CHEMOTHERAPY | null
        1          | MultiPayerConstants.OC_OMN_AZ_PAYER_ID    | SpclCareReferenceConstants.AUTH_TYPE_INJECTABLE_CHEMOTHERAPY | null
        2          | MultiPayerConstants.OC_OMN_AZ_PAYER_ID    | SpclCareReferenceConstants.AUTH_TYPE_SUPPORTIVE_DRUGS        | null
        3          | MultiPayerConstants.OC_OMN_AZ_PAYER_ID    | SpclCareReferenceConstants.AUTH_TYPE_SUPPORTIVE_DRUGS        | null
        3          | MultiPayerConstants.OC_OMN_AZ_PAYER_ID    | SpclCareReferenceConstants.AUTH_TYPE_RADIOPHARMACEUTICAL     | null
        4          | MultiPayerConstants.OC_OMN_AZ_PAYER_ID    | SpclCareReferenceConstants.AUTH_TYPE_RADIOPHARMACEUTICAL     | null
        5          | MultiPayerConstants.OC_SMA_PAYER_ID       | SpclCareReferenceConstants.AUTH_TYPE_INJECTABLE_CHEMOTHERAPY | null
        6          | MultiPayerConstants.OC_SMA_PAYER_ID       | SpclCareReferenceConstants.AUTH_TYPE_INJECTABLE_CHEMOTHERAPY | null
        7          | MultiPayerConstants.OC_SMA_PAYER_ID       | SpclCareReferenceConstants.AUTH_TYPE_SUPPORTIVE_DRUGS        | null
        8          | MultiPayerConstants.OC_SMA_PAYER_ID       | SpclCareReferenceConstants.AUTH_TYPE_SUPPORTIVE_DRUGS        | null
        9          | MultiPayerConstants.OC_SMA_PAYER_ID       | SpclCareReferenceConstants.AUTH_TYPE_RADIOPHARMACEUTICAL     | null
        10         | MultiPayerConstants.OC_SMA_PAYER_ID       | SpclCareReferenceConstants.AUTH_TYPE_RADIOPHARMACEUTICAL     | null
        11         | MultiPayerConstants.OC_OMN_UT_PAYER_ID    | SpclCareReferenceConstants.AUTH_TYPE_INJECTABLE_CHEMOTHERAPY | null
        12         | MultiPayerConstants.OC_OMN_UT_PAYER_ID    | SpclCareReferenceConstants.AUTH_TYPE_INJECTABLE_CHEMOTHERAPY | null
        13         | MultiPayerConstants.OC_OMN_UT_PAYER_ID    | SpclCareReferenceConstants.AUTH_TYPE_SUPPORTIVE_DRUGS        | null
        14         | MultiPayerConstants.OC_OMN_UT_PAYER_ID    | SpclCareReferenceConstants.AUTH_TYPE_SUPPORTIVE_DRUGS        | null
        15         | MultiPayerConstants.OC_OMN_UT_PAYER_ID    | SpclCareReferenceConstants.AUTH_TYPE_RADIOPHARMACEUTICAL     | null
        16         | MultiPayerConstants.OC_OMN_UT_PAYER_ID    | SpclCareReferenceConstants.AUTH_TYPE_RADIOPHARMACEUTICAL     | null
        17         | MultiPayerConstants.OC_OMN_CO_PAYER_ID    | SpclCareReferenceConstants.AUTH_TYPE_INJECTABLE_CHEMOTHERAPY | null
        18         | MultiPayerConstants.OC_OMN_CO_PAYER_ID    | SpclCareReferenceConstants.AUTH_TYPE_INJECTABLE_CHEMOTHERAPY | null
        19         | MultiPayerConstants.OC_OMN_CO_PAYER_ID    | SpclCareReferenceConstants.AUTH_TYPE_SUPPORTIVE_DRUGS        | null
        20         | MultiPayerConstants.OC_OMN_CO_PAYER_ID    | SpclCareReferenceConstants.AUTH_TYPE_SUPPORTIVE_DRUGS        | null
        21         | MultiPayerConstants.OC_OMN_CO_PAYER_ID    | SpclCareReferenceConstants.AUTH_TYPE_RADIOPHARMACEUTICAL     | null
        22         | MultiPayerConstants.OC_OMN_CO_PAYER_ID    | SpclCareReferenceConstants.AUTH_TYPE_RADIOPHARMACEUTICAL     | null
    }

    def "saveRequestingProvider - Save Provider DEA Number - PHN Payer"() {
        given:
        long hscID = 5555L
        long memberID = 5678L
        long TEST_HSC_ID = 1234L
        int clientId = MultiPayerConstants.PHN_PAYER_ID
        short providerSeqNum = 1
        boolean featureFlag = true
        HscProviderVO requestingProvider = new HscProviderVO(hscID: TEST_HSC_ID, providerSeqNum: providerSeqNum)
        HscVO hscVO = new HscVO(hscID: hscID, memberID: memberID, authTypeID: authType, hscAttributeVOs: [new HscAttributeVO(hscAttributeType: SpclCareReferenceConstants.HSCATTRIBUTETYPE_AUTHORIZATION_TYPE, hscAttributeValue: authType)])
        List<MemberCoverageVO> memberCoverageVOList = [new MemberCoverageVO(memberID: 2220L, reportCode: null)]
        ProviderDetails providerDetails = new ProviderDetails(providerDEA: null)

        when:
        authorizationsController.saveRequestingProvider(clientId, hscID, requestingProvider)

        then:
        1 * hscProvider.saveProviderAndRole(requestingProvider, HsrReferenceConstants.PROVIDER_ROLE_REQUESTING) >> requestingProvider
        1 * hscProvider.listByHscWithRoles(TEST_HSC_ID) >> []
        2 * hscHelper.getAuthType(TEST_HSC_ID) >> authType
        1 * hsc.read(TEST_HSC_ID) >> hscVO
        1 * memberCoverage.listByMemberID(_) >> memberCoverageVOList
        1 * hscHelper.getProviderDetails(requestingProvider, memberCoverageVOList?.first()) >> providerDetails
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_PROVIDER_DETAILS_FOR_AUTH_TYPE) >> featureFlag
        1 * featureFlagManager.isActive(SpclCareFeatureFlagConstants.ENABLE_NETWORK_STATUS_DERIVATION_FOR_EXCHANGE) >> featureFlag

        and:
        requestingProvider.providerDEA == result

        where:
        testCase  | authType                                                     | result
        0         | SpclCareReferenceConstants.AUTH_TYPE_INJECTABLE_CHEMOTHERAPY | null
        1         | SpclCareReferenceConstants.AUTH_TYPE_INJECTABLE_CHEMOTHERAPY | null
        2         | SpclCareReferenceConstants.AUTH_TYPE_SUPPORTIVE_DRUGS        | null
        3         | SpclCareReferenceConstants.AUTH_TYPE_SUPPORTIVE_DRUGS        | null
        4         | SpclCareReferenceConstants.AUTH_TYPE_RADIOPHARMACEUTICAL     | null
        5         | SpclCareReferenceConstants.AUTH_TYPE_RADIOPHARMACEUTICAL     | null
    }

    def "saveServicingProvider Feature Flag enabled with HscSpecialtyProcedureVO"() {
        given:
        long hscID = 1L
        int customerID = 1
        short providerSeqNum = 1
        String stepperLocation = SpclCareReferenceConstants.AUTH_STEPPER_SERVICING_PROVIDER
        HscProviderVO servicingProvider = new HscProviderVO(hscID: hscID, providerSeqNum: providerSeqNum)
        boolean featureFlag = true
        long testProcedureID = 1234
        String testDrugClass = "testDrugClass"
        String testProcedureCode = "testProcedureCode"
        String testProcedureBrandName = "testProcedureBrandName"
        SpecialtyProceduresViewVO specialtyProceduresViewVO = new SpecialtyProceduresViewVO()
        specialtyProceduresViewVO.setSpecialtyProcedureID(1234)
        specialtyProceduresViewVO.setDrugClass("testDrugClass")
        specialtyProceduresViewVO.setProcedureCode("testProcedureCode")
        specialtyProceduresViewVO.setProcedureBrandName("testBrandName")

        HscVO hscVO = new HscVO()
        HscSpecialtyProcedureVO hscSpecialtyProcedureVO = new HscSpecialtyProcedureVO()
        hscSpecialtyProcedureVO.setSpecialtyProcedureID(testProcedureID)
        hscVO.setHscSpecialtyProcedureVO(hscSpecialtyProcedureVO)

        when:
        CommonResponse response = authorizationsController.saveServicingProvider(customerID, hscID, servicingProvider)

        then:
        1 * authorizations.validateAuthorization(customerID, hscID,false)
        1 * hscProvider.saveProviderAndRole(servicingProvider, HsrReferenceConstants.PROVIDER_ROLE_SERVICING) >> servicingProvider
        1 * hscProvider.listByHscWithRoles(hscID) >> []
        2 * featureFlagManager.isActive(_) >> featureFlag
        1 * hscHelper.checkServicingProviderExceptionRequest(*_)
        1 * hscHelper.getAuthType(hscID)
        1 * hscHelper.logMissingHscServiceRecord(hscID, null)
        1 * hscProvider.deleteAdministeringProvider(_, _)
        0 * _

        and:
        response.getEmbedded() == ['_embedded': servicingProvider]
        servicingProvider.servicingProviderInd
    }

    def "saveServicingProvider Feature Flag disabled with HscSpecialtyProcedureVO"() {
        given:
        long hscID = 1L
        int customerID = 1
        short providerSeqNum = 1
        String stepperLocation = SpclCareReferenceConstants.AUTH_STEPPER_SERVICING_PROVIDER
        HscProviderVO servicingProvider = new HscProviderVO(hscID: hscID, providerSeqNum: providerSeqNum)
        boolean featureFlag = false
        long testProcedureID = 1234
        String testDrugClass = "testDrugClass"
        String testProcedureCode = "testProcedureCode"
        String testProcedureBrandName = "testProcedureBrandName"
        SpecialtyProceduresViewVO specialtyProceduresViewVO = new SpecialtyProceduresViewVO()
        specialtyProceduresViewVO.setSpecialtyProcedureID(1234)
        specialtyProceduresViewVO.setDrugClass("testDrugClass")
        specialtyProceduresViewVO.setProcedureCode("testProcedureCode")
        specialtyProceduresViewVO.setProcedureBrandName("testBrandName")

        HscVO hscVO = new HscVO()
        HscSpecialtyProcedureVO hscSpecialtyProcedureVO = new HscSpecialtyProcedureVO()
        hscSpecialtyProcedureVO.setSpecialtyProcedureID(testProcedureID)
        hscVO.setHscSpecialtyProcedureVO(hscSpecialtyProcedureVO)

        when:
        CommonResponse response = authorizationsController.saveServicingProvider(customerID, hscID, servicingProvider)

        then:
        1 * authorizations.validateAuthorization(customerID, hscID,false)
        1 * hscProvider.saveProviderAndRole(servicingProvider, HsrReferenceConstants.PROVIDER_ROLE_SERVICING) >> servicingProvider
        1 * hscProvider.listByHscWithRoles(hscID) >> []
        1 * hscHelper.autoTrackDraft(hscID, stepperLocation)
        2 * featureFlagManager.isActive(_) >> featureFlag
        1 * hscHelper.getAuthType(hscID)
        1 * hscHelper.logMissingHscServiceRecord(hscID, null)
        1 * hscProvider.deleteAdministeringProvider(_, _)
        0 * _

        and:
        response.getEmbedded() == ['_embedded': servicingProvider]
        servicingProvider.servicingProviderInd
    }

    def "saveServicingProvider Feature Flag enabled with HscSpecialtyProcedureVO and jbpm exception"() {
        given:
        long hscID = 1L
        int customerID = 1
        short providerSeqNum = 1
        String stepperLocation = SpclCareReferenceConstants.AUTH_STEPPER_SERVICING_PROVIDER
        HscProviderVO servicingProvider = new HscProviderVO(hscID: hscID, providerSeqNum: providerSeqNum)
        boolean featureFlag = true
        long testProcedureID = 1234
        String testDrugClass = "testDrugClass"
        String testProcedureCode = "testProcedureCode"
        String testProcedureBrandName = "testProcedureBrandName"
        SpecialtyProceduresViewVO specialtyProceduresViewVO = new SpecialtyProceduresViewVO()
        specialtyProceduresViewVO.setSpecialtyProcedureID(1234)
        specialtyProceduresViewVO.setDrugClass("testDrugClass")
        specialtyProceduresViewVO.setProcedureCode("testProcedureCode")
        specialtyProceduresViewVO.setProcedureBrandName("testBrandName")

        HscVO hscVO = new HscVO()
        HscSpecialtyProcedureVO hscSpecialtyProcedureVO = new HscSpecialtyProcedureVO()
        hscSpecialtyProcedureVO.setSpecialtyProcedureID(testProcedureID)
        hscVO.setHscSpecialtyProcedureVO(hscSpecialtyProcedureVO)

        when:
        CommonResponse response = authorizationsController.saveServicingProvider(customerID, hscID, servicingProvider)

        then:
        1 * authorizations.validateAuthorization(customerID, hscID,false)
        1 * hscProvider.saveProviderAndRole(servicingProvider, HsrReferenceConstants.PROVIDER_ROLE_SERVICING) >> servicingProvider
        1 * hscProvider.listByHscWithRoles(hscID) >> []
        2 * featureFlagManager.isActive(_) >> featureFlag
        1 * hscHelper.checkServicingProviderExceptionRequest(*_) >> {
            throw new UhgRuntimeException(SpclCareMessages.ERR_SYS_UNAVAILABLE)
        }
        1 * hscProvider.deleteAdministeringProvider(_, _)
        0 * _

        and:
        thrown(UhgRuntimeException)
    }

    def "saveServicingProvider Feature Flag disabled with HscSpecialtyProcedureVO and JBPM exception"() {
        given:
        long hscID = 1L
        int customerID = 1
        short providerSeqNum = 1
        String stepperLocation = SpclCareReferenceConstants.AUTH_STEPPER_SERVICING_PROVIDER
        HscProviderVO servicingProvider = new HscProviderVO(hscID: hscID, providerSeqNum: providerSeqNum)
        boolean featureFlag = false
        long testProcedureID = 1234
        String testDrugClass = "testDrugClass"
        String testProcedureCode = "testProcedureCode"
        String testProcedureBrandName = "testProcedureBrandName"
        SpecialtyProceduresViewVO specialtyProceduresViewVO = new SpecialtyProceduresViewVO()
        specialtyProceduresViewVO.setSpecialtyProcedureID(1234)
        specialtyProceduresViewVO.setDrugClass("testDrugClass")
        specialtyProceduresViewVO.setProcedureCode("testProcedureCode")
        specialtyProceduresViewVO.setProcedureBrandName("testBrandName")

        HscVO hscVO = new HscVO()
        HscSpecialtyProcedureVO hscSpecialtyProcedureVO = new HscSpecialtyProcedureVO()
        hscSpecialtyProcedureVO.setSpecialtyProcedureID(testProcedureID)
        hscVO.setHscSpecialtyProcedureVO(hscSpecialtyProcedureVO)
        jbpmHelper.sendStepperContinueSignal(*_) >> {
            throw new UhgRuntimeException(SpclCareMessages.ERR_SYS_UNAVAILABLE)
        }

        when:
        CommonResponse response = authorizationsController.saveServicingProvider(customerID, hscID, servicingProvider)

        then:
        1 * authorizations.validateAuthorization(customerID, hscID,false)
        1 * hscProvider.saveProviderAndRole(servicingProvider, HsrReferenceConstants.PROVIDER_ROLE_SERVICING) >> servicingProvider
        1 * hscProvider.listByHscWithRoles(hscID) >> []
        1 * hscHelper.autoTrackDraft(hscID, stepperLocation)
        2 * featureFlagManager.isActive(_) >> featureFlag
        1 * hscHelper.getAuthType(hscID)
        1 * hscHelper.logMissingHscServiceRecord(hscID, null)
        1 * hscProvider.deleteAdministeringProvider(_, _)
        0 * _

        and:
        response.getEmbedded() == ['_embedded': servicingProvider]
        servicingProvider.servicingProviderInd
        notThrown(UhgRuntimeException)
    }

    def "saveServicingProvider - RF and SJ"() {
        given:
        long hscID = 1L
        int customerID = 1
        short providerSeqNum = 1
        String stepperLocation = SpclCareReferenceConstants.AUTH_STEPPER_SERVICING_PROVIDER
        HscProviderVO servicingProvider = new HscProviderVO(hscID: hscID, providerSeqNum: providerSeqNum)

        when:
        CommonResponse response = authorizationsController.saveServicingProvider(customerID, hscID, servicingProvider)

        then:
        1 * authorizations.validateAuthorization(customerID, hscID,false)
        1 * hscProvider.saveProviderAndRole(servicingProvider, HsrReferenceConstants.PROVIDER_ROLE_SERVICING) >> servicingProvider
        1 * hscProvider.listByHscWithRoles(hscID) >> [
                new HscProviderVO(
                        hscID: hscID,
                        providerSeqNum: providerSeqNum,
                        hscProviderRoleVOs: [new HscProviderRoleVO(providerRole: HsrReferenceConstants.PROVIDER_ROLE_REQUESTING),
                                             new HscProviderRoleVO(providerRole: HsrReferenceConstants.PROVIDER_ROLE_SERVICING)])
        ]
        1 * hscHelper.autoTrackDraft(hscID, stepperLocation)
        2 * featureFlagManager.isActive(_)
        1 * hscHelper.getAuthType(hscID)
        1 * hscHelper.logMissingHscServiceRecord(hscID, null)
        1 * hscProvider.deleteAdministeringProvider(_, _)
        0 * _

        and:
        response.getEmbedded() == ['_embedded': servicingProvider]
        servicingProvider.servicingProviderInd
        servicingProvider.requestingProviderInd
    }

    def 'test generateInProgressHSC'() {
        given:
        long TEST_HSC_ID = 1234L
        int customerID = 1
        MemberVO memberVO = new MemberVO(memberID: TEST_HSC_ID, hscID: TEST_HSC_ID)
        String authType = "1"
        GenerateHscDO generateHscDO = new GenerateHscDO(memberVO: memberVO, authType: authType,authStartDate: UhgCalendarUtilities.getLocalCalendar().addDay(-2).getSQLDate())
        Session session = new HttpUserSession()
        session.setUserSecurity(new UserSecurityVO(userGroupID: SpclCareConstants.ROLE_PROVIDER))
        sessionThreadLocal.setSession(session)

        when:
        CommonResponse response = authorizationsController.generateInProgressHSC(customerID, generateHscDO)

        then:
        _ * FeatureFlagUtility.getManager().isActive(SpclCareFeatureFlagConstants.ENABLE_PH_REQUEST_DETAILS_CHANGE) >> true
        1 * userHscHistory.saveUserHscHistory(_)
        1 * authorizations.validateCustomer(customerID);
        1 * hscHelper.generateInProgressHSC(generateHscDO)
        0 * _

        and:
        response.getEmbedded().get(CommonResponse.EMBEDDED) == generateHscDO
    }

    def 'test generateInProgressHSC - no hsc'() {
        given:
        long TEST_HSC_ID = 1234L
        int customerID = 1
        MemberVO memberVO = new MemberVO(memberID: TEST_HSC_ID)
        String authType = "1"
        GenerateHscDO generateHscDO = new GenerateHscDO(memberVO: memberVO, authType: authType)

        when:
        CommonResponse response = authorizationsController.generateInProgressHSC(customerID, generateHscDO)

        then:
        _ * FeatureFlagUtility.getManager().isActive(SpclCareFeatureFlagConstants.ENABLE_PH_REQUEST_DETAILS_CHANGE) >> false
        1 * authorizations.validateCustomer(customerID);
        1 * hscHelper.generateInProgressHSC(generateHscDO)
        0 * _
        and:
        response.getEmbedded().get(CommonResponse.EMBEDDED) == generateHscDO
    }

    def 'test createDocument'() {
        given:
        long hscID = 1L
        int customerID = 1
        List<MultipartFile> file
        String userID = "userId"
        long rowNumber = 1L

        String responseStr = "expected response"

        when:
        CommonResponse response = authorizationsController.createDocument(customerID, hscID, file, userID, rowNumber)

        then:
        1 * authorizations.validateAuthorization(customerID, hscID,false)
        1 * documentManagerService.createDocument(file, hscID, userID) >> new CommonResponse().setEmbedded(responseStr)
        0 * _

        and:
        response.getEmbedded() == ['_embedded': responseStr]
    }

    def 'test deleteDocument'() {
        given:
        long hscID = 1L
        int customerID = 1

        long fileId = 1L
        ResponseEntity responseEntity = new ResponseEntity<>(HttpStatus.OK)

        when:
        CommonResponse response = authorizationsController.deleteDocument(customerID, hscID, fileId)

        then:
        1 * authorizations.validateAuthorization(customerID, hscID,false)
        1 * documentManagerService.deleteAttachment(fileId) >> responseEntity
        0 * _

        and:
        response.getEmbedded() == ['_embedded': responseEntity]
    }

    def 'test deleteDocuments'() {
        given:
        long hscID = 1L
        int customerID = 1

        ResponseEntity responseEntity = new ResponseEntity<>(HttpStatus.OK)

        when:
        CommonResponse response = authorizationsController.deleteDocuments(customerID, hscID)

        then:
        1 * authorizations.validateAuthorization(customerID, hscID,false)
        1 * documentManagerService.deleteAttachmentsByHSC(hscID) >> responseEntity
        0 * _

        and:
        response.getEmbedded() == ['_embedded': responseEntity]
    }

    def 'test getDocuments'() {
        given:
        long hscID = 1L
        int customerID = 1

        String responseStr = "expected response"

        when:
        CommonResponse response = authorizationsController.getDocuments(customerID, hscID)

        then:
        1 * authorizations.validateAuthorization(customerID, hscID,false)
        1 * documentManagerService.getAttachmentsByHSC(hscID) >> new CommonResponse().setEmbedded(responseStr)
        0 * _

        and:
        response.getEmbedded() == ['_embedded': responseStr]
    }

    def 'test updateNotes'() {
        given:
        long hscID = 1L
        int customerID = 1

        String responseStr = "expected response"

        when:
        CommonResponse response = authorizationsController.updateNotes(customerID, hscID)

        then:
        1 * authorizations.validateAuthorization(customerID, hscID,false)
        1 * hscUpdate.updateNotes(hscID) >> new CommonResponse().setEmbedded(responseStr)
        0 * _

        and:
        response.getEmbedded() == ['_embedded': responseStr]
    }

    def 'test getDocumentById'() {
        given:
        long hscID = 1L
        int customerID = 1

        String fdsAttachmentId = "fdsAttachmentId"
        byte[] byteArray = [10,20,30]

        when:
        CommonResponse response = authorizationsController.getDocumentById(customerID, hscID, fdsAttachmentId)

        then:
        1 * authorizations.validateAuthorization(customerID, hscID,false)
        1 * documentManagerService.getAttachment(fdsAttachmentId) >> byteArray
        0 * _

        and:
        response.getEmbedded() == ['_embedded': byteArray]
    }

    def 'get parsed drug data for drug dosage rounding'(){
        given:
        long TEST_HSC_ID = 1234L
        int customerID = 1
        DrugRoundingRequestDO drugRoundingRequestDO = new DrugRoundingRequestDO(hscID: TEST_HSC_ID)
        DrugRoundingResponseDO drugRoundingResponseDO = new DrugRoundingResponseDO()

        when:
        CommonResponse response = authorizationsController.drugRounding(customerID, TEST_HSC_ID, drugRoundingRequestDO)

        then:
        1 * authorizations.validateAuthorization(customerID, TEST_HSC_ID,false)
        1 * drugRounding.drugRoundingParsing(customerID, drugRoundingRequestDO) >> drugRoundingResponseDO

        and:
        response.getEmbedded() == ['_embedded': drugRoundingResponseDO]
    }

    def 'get medicare part b list'(){

        given:
        List<String> partBList = new ArrayList<String>()
        partBList.add("11111")

        when:
        CommonResponse response = authorizationsController.checkMedicarePartB(customerID)

        then:
        1 * authorizations.validateCustomer(customerID)
        1 * authorizationRuleHelper.filterDrugsForMedicarePartB(customerID) >> partBList

        and:
        (response.getEmbedded().get('_embedded')).size() == partBList.size()

        where:
        Sno|   customerID
        1   |   3

    }

    def 'test getOrxPAHistory'() {
        given:
        int customerID = 1
        QueryProperties queryProperties = new QueryProperties(QueryProperties.FilterType.LIST_ALL)
        queryProperties.addQueryFilter(new QueryFilter(FieldConstants.MEMBERIDTEXT, "test"))
        ResponseEntity responseEntity = new ResponseEntity<>(HttpStatus.OK)

        when:
        CommonResponse response = authorizationsController.getOrxPAHistory(customerID, queryProperties)

        then:
        1 * authorizations.validateCustomer(customerID)
        1 * hscHelper.getOrxPAHistory(queryProperties , customerID) >> responseEntity
        0 * _

        and:
        response.getEmbedded() == ['_embedded': responseEntity.body]
    }

    @Unroll
    def 'test saveServicingProvider'() {
        given:
        long hscID = 5555L
        long TEST_HSC_ID = 1234L
        short providerSeqNum = 1
        int customerId = 2
        String stepperLocation = SpclCareReferenceConstants.AUTH_STEPPER_SERVICING_PROVIDER
        HscProviderVO servicingProvider = new HscProviderVO(hscID: TEST_HSC_ID, providerSeqNum: providerSeqNum)

        when:
        CommonResponse response = authorizationsController.saveServicingProvider(customerId, hscID, servicingProvider)

        then:
        1 * hscProvider.saveProviderAndRole(servicingProvider, HsrReferenceConstants.PROVIDER_ROLE_SERVICING) >> servicingProvider
        1 * hscProvider.listByHscWithRoles(TEST_HSC_ID) >> [new HscProviderVO(hscID: TEST_HSC_ID, providerSeqNum: 1, hscProviderRoleVOs: [new HscProviderRoleVO(providerRole: HsrReferenceConstants.PROVIDER_ROLE_REQUESTING)])]
        1 * FeatureFlagUtility.getManager().isActive(SpclCareFeatureFlagConstants.DRAFT_JBPM_CALLS) >> false
        1 * hscHelper.autoTrackDraft(TEST_HSC_ID, stepperLocation)
        hscHelper.getAuthType(TEST_HSC_ID) >> SpclCareReferenceConstants.AUTH_TYPE_SPECIALTY_PHARMACY
        1 * FeatureFlagUtility.getManager()?.isActive(SpclCareFeatureFlagConstants.ENABLE_SITE_OF_CARE_PROVIDER_EXCEPTIONS) >> FF
        1 * FeatureFlagUtility.getManager()?.isActive(SpclCareFeatureFlagConstants.ENABLE_SGP_PREFERRED_SUPPLIER) >> false
        1 * hscHelper.logMissingHscServiceRecord(_, _)
        1 * hscHelper.checkMSEAndPreferredSupplier(_, _)
        _ * hscHelper.checkServicingProviderExceptionRequest(_)

        and:
        response.getEmbedded() == ['_embedded': servicingProvider]
        servicingProvider.servicingProviderInd

        where:
        testCase | FF
        0        | true
        1        | false
    }
}
