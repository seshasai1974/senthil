package com.optum.app.shared.authorization.job

import spock.lang.Specification

class ImportPriorAuthFailureReportCronJobSpec extends Specification {

    def "testImportPriorAuthFailureReportCronJob"(){
        given:
        ImportPriorAuthFailureCronJob importPriorAuthFailureCronJob = new ImportPriorAuthFailureCronJob()

        when:
        importPriorAuthFailureCronJob != null

        then:
        importPriorAuthFailureCronJob.getCronPattern() == "0 12 * * *"
        importPriorAuthFailureCronJob.getSystemJobID() == "IPF"
        importPriorAuthFailureCronJob.getDescription() == "Import Prior Authorization Failure Report"
        importPriorAuthFailureCronJob.getTask() != null
    }

}
