package com.optum.app.shared.authorization.job

import com.optum.app.shared.authorization.job.AuthorizationReprocessorCronJob
import spock.lang.Specification
import spock.lang.Unroll


/**
 * Created by jboyd34 on 10/8/18.
 */
class AuthorizationReprocessorCronJobSpec extends Specification {

    @Unroll
    def "test AuthReprocessorCronJob"() {
       given:
       AuthorizationReprocessorCronJob authorizationReprocessorCronJob = new AuthorizationReprocessorCronJob()

       when:
       authorizationReprocessorCronJob != null
        
       then:
        authorizationReprocessorCronJob.getCronPattern() == "0,30 * * * *"
        authorizationReprocessorCronJob.getSystemJobID() == "RFA"
        authorizationReprocessorCronJob.getDescription() == "Reprocess Failed Authorizations"
        authorizationReprocessorCronJob.getTask() != null

    }

}
