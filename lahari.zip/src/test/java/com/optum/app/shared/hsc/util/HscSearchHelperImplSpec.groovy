package com.optum.app.shared.hsc.util

import com.optum.app.common.dao.PreparedStatementProperties
import com.optum.app.common.hsr.businesslogic.HscMemProvView
import com.optum.app.common.hsr.data.HscMemProvViewVO
import com.optum.rf.dao.sql.query.QueryProperties
import spock.lang.Specification
import spock.lang.Unroll

import java.util.concurrent.CompletableFuture

class HscSearchHelperImplSpec extends Specification {

    HscSearchHelperImpl hscSearchHelperImpl = new HscSearchHelperImpl()
    HscMemProvView hscMemProvView = Mock(HscMemProvView)

    def setup() {
        hscSearchHelperImpl.hscMemProvView = hscMemProvView
    }

   @Unroll
    def 'test getHscMemProv'(){
       given:
       PreparedStatementProperties properties = new PreparedStatementProperties()
       QueryProperties queryProperties = new QueryProperties()
       String userType = 'INTERNAL OPERATIONS'
       int clientID = 1

       when:
       List<HscMemProvViewVO> response =  hscSearchHelperImpl.getHscMemProv(properties, queryProperties, userType, clientID)

       then:
       1 * hscMemProvView.callStoredProc(*_) >> [new HscMemProvViewVO()]

       and :
       response
   }

    @Unroll
    def 'test getHscMemProvConcurrent'(){
        given:
        PreparedStatementProperties properties = new PreparedStatementProperties()
        QueryProperties queryProperties = new QueryProperties()
        String userType = 'INTERNAL OPERATIONS'
        int clientID = 1

        when:
        CompletableFuture<List<HscMemProvViewVO>> response =  hscSearchHelperImpl.getHscMemProvConcurrent(properties, queryProperties, userType, clientID)

        then:
        1 * hscMemProvView.callStoredProc(*_) >> [new HscMemProvViewVO()]

        and :
        response
    }

    @Unroll
    def 'test getHscMemProvCountConcurrent'(){
        given:
        PreparedStatementProperties properties = new PreparedStatementProperties()
        String userType = 'INTERNAL OPERATIONS'
        int clientID = 1

        when:
        CompletableFuture<Integer> response =  hscSearchHelperImpl.getHscMemProvCountConcurrent(properties, userType, clientID)

        then:
        1 * hscMemProvView.callCountStoredProc(*_) >> new Integer(1)

        and :
        response
    }

}
