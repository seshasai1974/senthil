package com.optum.app.shared.authorization.job

import com.optum.app.shared.authorization.job.ExpiredAuthCronJob
import spock.lang.Specification

/**
 * Created by cnadipin on 1/9/19.
 */
class ExpiredAuthCronJobSpec extends Specification{

    def "test ExpiredAuthECronJob"(){
        given:
        ExpiredAuthCronJob expiredAuthCronJob = new ExpiredAuthCronJob()

        when:
        expiredAuthCronJob != null

        then:
        expiredAuthCronJob.getCronPattern() == "0 0 * * *"
        expiredAuthCronJob.getSystemJobID() == "EAJ"
        expiredAuthCronJob.getDescription() == "Expire Auths Job"
        expiredAuthCronJob.getTask() != null
    }

}
