package com.optum.app.shared.whitelabel

import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.databind.ObjectMapper
import com.optum.app.shared.whitelabel.dto.CustomerWhiteLabelsDto
import com.optum.app.common.customer.data.CustomerVO
import com.optum.app.shared.whitelabel.dto.ForbiddenWordsDto

/** Helper methods to manage WhiteLabel Test Data
 * Note: static methods can create unpredictable errors when used in @Shared fields. Instance methods are preferred.
 */
trait WhiteLabelTestData {
    private static final ObjectMapper mapper = new ObjectMapper()

    CustomerVO newCustomerVO(int customerId) {
        return newCustomerVO(customerId, "customer-" + customerId)
    }

    CustomerVO newCustomerVO(int customerId, String customerName) {
        assert customerId != 0
        def customerVO = new CustomerVO()
        customerVO.customerID = customerId
        customerVO.customerName = customerName
        return customerVO
    }

    CustomerWhiteLabelsDto toCustomerDto(CustomerVO customerVO) {
        return newCustomerWhiteLabelsDto(customerVO.customerID, "{\"customerName\":\"" + customerVO.customerName + "\" }")
    }

    CustomerWhiteLabelsDto newCustomerWhiteLabelsDto(int customerId) {
        return toCustomerDto(newCustomerVO(customerId))
    }

    CustomerWhiteLabelsDto newCustomerWhiteLabelsDto(Integer customerId, String jsonString) {
        return new CustomerWhiteLabelsDto(
                customerId: customerId,
                whiteLabels: jsonString ? mapper.readValue(jsonString, JsonNode.class) : null,
        )
    }

    List<CustomerVO> namesToCustomerVOList(Collection<String> names) {
        return names.withIndex().collect { String name, Integer i ->
            return newCustomerVO(i + 1, name)
        }
    }

    List<CustomerVO> newCustomerVOList(Integer size) {
        assert size != null
        def list = new ArrayList<CustomerVO>()

        for(int i = 0; i < size; i++) {
            list.add(newCustomerVO(i + 1))
        }

        return list
    }

    ForbiddenWordsDto forbiddenWordsDtoFor(CustomerVO customerVO) {
        return new ForbiddenWordsDto(customerId: customerVO.customerID, forbiddenWords: forbiddenWords())
    }

    List<String> forbiddenWords() {
        def singleWordMatch = "FoRbIddEnWOrD"
        def multipleWordMatch = "forbidden WORDS"
        def partialWordWontMatch = "custo"
        return  [singleWordMatch, multipleWordMatch, partialWordWontMatch]
    }

    Optional<JsonNode> toOptionalJson(String jsonString) {
        if (jsonString == null) {
            return Optional.empty()
        } else {
            return Optional.of(mapper.readValue(jsonString, JsonNode.class))
        }
    }

    Optional<JsonNode> toOptionalJson(CustomerVO customerVO) {
        return Optional.of(toCustomerDto(customerVO).whiteLabels)
    }

    WLCustomerModel toCustomerModel(CustomerVO customerVO) {
        return new WLCustomerModel(
                customerId: customerVO.customerID,
                customerName: customerVO.customerName,
                organizationName: "org-" + customerVO.organizationID
        )
    }

}
