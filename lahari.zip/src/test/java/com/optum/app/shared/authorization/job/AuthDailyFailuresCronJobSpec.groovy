package com.optum.app.shared.authorization.job

import com.optum.app.shared.authorization.job.AuthDailyFailuresCronJob
import spock.lang.Specification

class AuthDailyFailuresCronJobSpec extends Specification {

    def "test AuthDailyFailuresCronJob"(){
        given:
        AuthDailyFailuresCronJob authDailyFailuresCronJob = new AuthDailyFailuresCronJob()

        when:
        authDailyFailuresCronJob != null

        then:
        authDailyFailuresCronJob.getCronPattern() == "0 6 * * *"
        authDailyFailuresCronJob.getSystemJobID() == "ADF"
        authDailyFailuresCronJob.getDescription() == "Auth Refresh Failures Report"
        authDailyFailuresCronJob.getTask() != null
    }
}
