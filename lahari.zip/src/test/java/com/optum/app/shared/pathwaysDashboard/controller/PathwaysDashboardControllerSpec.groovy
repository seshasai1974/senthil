package com.optum.app.shared.pathwaysDashboard.controller

import com.optum.app.ocm.controller.support.CommonResponse
import com.optum.app.shared.authorization.businesslogic.Authorizations
import com.optum.app.shared.pathwaysDashboard.businesslogic.PathwaysDashboard
import com.optum.app.shared.pathwaysDashboard.businesslogic.PathwaysNationalAverage
import com.optum.app.shared.pathwaysDashboard.businesslogic.PathwaysRewardAttestation
import com.optum.app.shared.pathwaysDashboard.data.PathwaysDashboardHelperDO
import com.optum.app.shared.pathwaysDashboard.data.PathwaysDashboardRequestDO
import com.optum.app.shared.pathwaysDashboard.data.PathwaysRewardAttestationVO
import com.optum.app.shared.pathwaysDashboard.data.PathwaysRewardsRequestDO
import com.optum.app.shared.pathwaysDashboard.data.PathwaysRewardsResponseDO
import com.optum.app.shared.spclcare.SpecialtyCareReadLogicSpecification
import com.optum.rf.core.util.UhgCalendar
import spock.lang.Unroll

class PathwaysDashboardControllerSpec extends SpecialtyCareReadLogicSpecification{

    PathwaysDashboardController pathwaysDashboardController
    PathwaysDashboard pathwaysDashboard = Mock(PathwaysDashboard)
    PathwaysNationalAverage pathwaysNationalAverage = Mock(PathwaysNationalAverage)
    PathwaysRewardAttestation pathwaysRewardAttestation = Mock(PathwaysRewardAttestation)
    Authorizations authorizations = Mock(Authorizations)

    private final static String TEST_TAX_ID = '20282199'

    def setup(){
        pathwaysDashboardController = new PathwaysDashboardController()
        pathwaysDashboardController.pathwaysDashboard = pathwaysDashboard
        pathwaysDashboardController.pathwaysNationalAverage = pathwaysNationalAverage
        pathwaysDashboardController.pathwaysRewardAttestation = pathwaysRewardAttestation
        pathwaysDashboardController.authorizations = authorizations
    }

    @Unroll
    def 'get pathways summary'() {
        given:
        PathwaysDashboardRequestDO pathwaysDashboardRequestDO = new PathwaysDashboardRequestDO()
        pathwaysDashboardRequestDO.setFederalTaxID(TEST_TAX_ID)
        pathwaysDashboardRequestDO.setPeriodStartDate(new UhgCalendar(2020, 01, 01))
        pathwaysDashboardRequestDO.setPeriodEndDate(new UhgCalendar(2020, 06, 30) )
        pathwaysDashboardRequestDO.setCustomerID(1)
        List<Integer> pathwaysNationalAverageMonthly = new ArrayList<Integer>()
        pathwaysNationalAverageMonthly.push(70)
        pathwaysNationalAverageMonthly.push(80)
        PathwaysDashboardHelperDO pathwaysDashboardHelperDO = new PathwaysDashboardHelperDO()
        when:
        CommonResponse response = pathwaysDashboardController.pathwaysSummary(pathwaysDashboardRequestDO)
        then:
        1 * authorizations.validateCustomer(_)
        1 * pathwaysDashboard.getPathwaysSummary(pathwaysDashboardRequestDO) >> pathwaysDashboardHelperDO
        1 * pathwaysNationalAverage.getPathwaysNationalAverageMonthly(pathwaysDashboardRequestDO, pathwaysDashboardHelperDO) >> pathwaysDashboardHelperDO
        and:
        response.getEmbedded().get('_embedded') == pathwaysDashboardHelperDO
    }

    @Unroll
    def 'check Reward Status'() {
        given:
        PathwaysRewardsRequestDO pathwaysRewardsRequestDO = new PathwaysRewardsRequestDO()
        pathwaysRewardsRequestDO.setFederalTaxID(TEST_TAX_ID)
        pathwaysRewardsRequestDO.setPeriodStartDate(new UhgCalendar(2020, 01, 01))
        pathwaysRewardsRequestDO.setPeriodEndDate(new UhgCalendar(2020, 06, 30))
        pathwaysRewardsRequestDO.setCustomerID(1)
        PathwaysRewardsResponseDO pathwaysRewardsResponseDO = new PathwaysRewardsResponseDO()
        when:
        CommonResponse response = pathwaysDashboardController.pathwaysRewardStatus(pathwaysRewardsRequestDO)
        then:
        1 * authorizations.validateCustomer(_)
        1 * pathwaysRewardAttestation.checkRewardStatus(pathwaysRewardsRequestDO) >> pathwaysRewardsResponseDO
        and:
        response.getEmbedded().get('_embedded') == pathwaysRewardsResponseDO
    }

    @Unroll
    def 'save Reward Attestation'() {
        given:
        PathwaysRewardsRequestDO pathwaysRewardsRequestDO = new PathwaysRewardsRequestDO()
        pathwaysRewardsRequestDO.setFederalTaxID(TEST_TAX_ID)
        pathwaysRewardsRequestDO.setPeriodStartDate(new UhgCalendar(2020, 01, 01))
        pathwaysRewardsRequestDO.setPeriodEndDate(new UhgCalendar(2020, 06, 30))
        pathwaysRewardsRequestDO.setCustomerID(1)
        PathwaysRewardAttestationVO pathwaysRewardAttestationVO = new PathwaysRewardAttestationVO()
        when:
        CommonResponse response = pathwaysDashboardController.saveRewardAttestation(pathwaysRewardsRequestDO)
        then:
        1 * authorizations.validateCustomer(_)
        1 * pathwaysRewardAttestation.saveRewardAttestation(pathwaysRewardsRequestDO) >>  pathwaysRewardAttestationVO
        and:
        response.getEmbedded().get('_embedded') == pathwaysRewardAttestationVO
    }
}
