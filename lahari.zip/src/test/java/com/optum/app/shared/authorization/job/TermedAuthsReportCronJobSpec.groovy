package com.optum.app.shared.authorization.job

import com.optum.app.shared.authorization.job.TermedAuthsReportCronJob
import spock.lang.Specification

class TermedAuthsReportCronJobSpec extends Specification {

    def "test AuthErrorReportCronJob"(){
        given:
        TermedAuthsReportCronJob termedAuthsReportCronJob = new TermedAuthsReportCronJob()

        when:
        termedAuthsReportCronJob != null

        then:
        termedAuthsReportCronJob.getCronPattern() == "0 4 * * *"
        termedAuthsReportCronJob.getSystemJobID() == "TAR"
        termedAuthsReportCronJob.getDescription() == "Overlapping Auth Report"
        termedAuthsReportCronJob.getTask() != null
    }

}
