package com.optum.app.common.constants.spclcare;
public final class StoredProcConstants {
    public static final String TRUNCATE_TABLE = "TRUNCATE_TABLE";
    public static final String SP_INSERT_COSMOS_GROUP = "SP_INSERT_COSMOS_GROUP";
    public static final String SP_TRUNC_INSERT_COSMOS_MAPS = "SP_TRUNC_INSERT_COSMOS_MAPS";
    public static final String SP_TRUNC_INSERT_NICE_MAPS = "SP_TRUNC_INSERT_NICE_MAPS";
    public static final String SP_COMMIT_CPT4_BASE = "SP_COMMIT_CPT4_BASE";
    public static final String SP_COMMIT_HCPCS_BASE = "SP_COMMIT_HCPCS_BASE";
    public static final String SP_COMMIT_ICD9_BASE = "SP_COMMIT_ICD9_BASE";
    public static final String SP_COMMIT_ICD10_BASE = "SP_COMMIT_ICD10_BASE";
    public static final String SP_COMMIT_CPT4_KEYWORD = "SP_COMMIT_CPT4_KEYWORD";
    public static final String SP_COMMIT_HCPCS_KEYWORD = "SP_COMMIT_HCPCS_KEYWORD";
    public static final String SP_COMMIT_ICD9_KEYWORD = "SP_COMMIT_ICD9_KEYWORD";
    public static final String SP_COMMIT_ICD10_KEYWORD = "SP_COMMIT_ICD10_KEYWORD";
    public static final String SP_PRESERVE_DELETED_CPT4_BASE = "SP_PRESERVE_DELETED_CPT4_BASE";
    public static final String SP_PRESERVE_DELETED_HCPCS_BASE = "SP_PRESERVE_DELETED_HCPCS_BASE";
    public static final String SP_PRESERVE_DELETED_ICD9_BASE = "SP_PRESERVE_DELETED_ICD9_BASE";
    public static final String SP_PRESERVE_DELETED_ICD10_BASE = "SP_PRESERVE_DELETED_ICD10_BASE";
    public static final String SP_PRESERVE_DELETED_CPT4_KWD = "SP_PRESERVE_DELETED_CPT4_KWD";
    public static final String SP_PRESERVE_DELETED_HCPCS_KWD = "SP_PRESERVE_DELETED_HCPCS_KWD";
    public static final String SP_PRESERVE_DELETED_ICD9_KWD = "SP_PRESERVE_DELETED_ICD9_KWD";
    public static final String SP_PRESERVE_DELETED_ICD10_KWD = "SP_PRESERVE_DELETED_ICD10_KWD";
    public static final String DB_GATHER_STATS = "DB_GATHER_STATS";
    public static final String MNT_LOG = "MNT_LOG";
}
