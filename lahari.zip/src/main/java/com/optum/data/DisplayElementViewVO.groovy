package com.optum.data

import com.optum.rf.dao.data.ValueObject
import groovy.transform.CompileStatic

/* Physical Table Name = display_element_view */
@CompileStatic
class DisplayElementViewVO extends ValueObject{
    private static final long serialVersionUID = 1L

    long displayElementID      // dspl_elmnt_id
    String displayElementName // dspl_elmnt_nm
    String displayElementDesc //dspl_elmnt_desc
    long displayElementParentID  // dspl_elmnt_par_id
    String displayElementParentName //dspl_elmnt_nm
}
