package com.optum.data

import com.optum.rf.dao.data.ValueObject
import groovy.transform.CompileStatic

/* Physical Table Name = BB_TABLE_FIELDS_X_FIELDS */
@CompileStatic
class TableFieldsXFieldsVO extends ValueObject {

    /** Serialization Version ID compatibility - indication of what version may be restored.*/
    private static final long serialVersionUID = 1L

    String table_name // TABLE_NAME
    String field_name // FIELD_NAME
    String field_name_physical // FIELD_NAME_PHYSICAL
    String sort_num // SORT_NUM
    String data_type // DATA_TYPE
    String field_length // FIELD_LENGTH
    String field_precision // FIELD_PRECISION
    String field_descriptiontext // FIELD_DESCRIPTIONTEXT
    boolean uppercaseonly // UPPERCASEONLY
    boolean primary_key // PRIMARY_KEY
    String field_xref // FIELD_XREF
    String table_descriptiontext // TABLE_DESCRIPTIONTEXT
    String table_or_view // TABLE_OR_VIEW
}
