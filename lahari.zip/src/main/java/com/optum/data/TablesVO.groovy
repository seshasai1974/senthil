package com.optum.data

import com.optum.rf.dao.annotation.NonPersisted
import com.optum.rf.dao.data.ValueObject
import groovy.transform.CompileStatic

/* Physical Table Name = BB_TABLES */
@CompileStatic
class TablesVO extends ValueObject {
    /** Serialization Version ID compatibility - indication of what version may be restored.*/
    private static final long serialVersionUID = 1L

    String table_name // TABLE_NAME
    String descriptiontext // DESCRIPTIONTEXT
    String voclass // VOCLASS
    String daoclass // DAOCLASS
    String daoclassimpl // DAOCLASSIMPL
    String auditnotestable // AUDITNOTESTABLE
    String pk_partitioned_index_name //PK_PARTITIONED_INDEX_NAME
    boolean view_indicator // VIEW_INDICATOR
    boolean distinct_indicator // DISTINCT_INDICATOR
    boolean virtual_indicator // VIRTUAL_INDICATOR
    boolean under_construction // UNDER_CONSTRUCTION
    boolean secured // SECURED
    boolean logHistory // LOGHISTORY
	int num_pk_index_partitions // NUM_PK_INDEX_PARTITIONS
    String db_category //DB_CATEGORY
    boolean translatable //TRANSLATABLE

    @NonPersisted
    List<TableDefViewerVO> tableFields
    @NonPersisted
    Set<String> dependentTables
    @NonPersisted
    List<TableDefViewForeignKeyVO> foreignKeyTables
    @NonPersisted
    List<String> indices
    @NonPersisted
    List<String> constraints
    @NonPersisted
    boolean cached
    @NonPersisted
    boolean hiLowIncrement
    @NonPersisted
    String incrementedKey

}
