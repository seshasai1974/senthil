package com.optum.data

import com.optum.rf.dao.data.NoTableDef
import com.optum.rf.dao.data.ValueObject
import groovy.transform.CompileStatic

/**
 * Created by achunh on 7/20/18.
 */
@CompileStatic
class TableDefViewForeignKeyVO extends ValueObject implements Serializable, NoTableDef {

    String tableName
    String fkeyTable
    String fieldName

    TableDefViewForeignKeyVO(String tableName, String fkeyTable, String fieldName) {
        this.tableName = tableName
        this.fieldName = fieldName
        this.fkeyTable = fkeyTable
    }

    String getIncrementedKey() {
        return ""
    }

    List<String> getRequiredFields() {
        return new ArrayList<String>()
    }

    List<String> getPrimaryKeyFields() {
        return new ArrayList<String>()
    }
}
