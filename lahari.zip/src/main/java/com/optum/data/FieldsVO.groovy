package com.optum.data

import com.optum.rf.dao.data.ValueObject
import groovy.transform.CompileStatic

/* Physical Table Name = BB_FIELDS */
@CompileStatic
class FieldsVO extends ValueObject {
    /** Serialization Version ID compatibility - indication of what version may be restored.*/
    private static final long serialVersionUID = 1L;

    String field_name // FIELD_NAME
    String data_type // DATA_TYPE
    String field_length // FIELD_LENGTH
    String field_precision // FIELD_PRECISION
    String descriptiontext // DESCRIPTIONTEXT
    String doubleclick_uri // DOUBLECLICK_URI
    String doubleclick // DOUBLECLICK
    boolean uppercaseonly // UPPERCASEONLY
    String field_xref // FIELD_XREF
    String field_name_physical // FIELD_NAME_PHYSICAL
}
