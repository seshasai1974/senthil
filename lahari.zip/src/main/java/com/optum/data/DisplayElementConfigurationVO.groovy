package com.optum.data

import com.optum.rf.dao.data.ValueObject

/**
 * Created by jyadeau on 3/28/19.
 */
class DisplayElementConfigurationVO extends ValueObject {
    int customerID
    String userGroupID
    String displayElementName
    boolean elementVisibleIndicator
    boolean readIndicator
    boolean requiredIndicator
    boolean readOnlyIndicator
}
