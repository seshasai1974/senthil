package com.optum.data

import com.optum.rf.dao.data.NoTableDef
import com.optum.rf.dao.data.ValueObject

/**
 * Created by achunh on 7/20/18.
 */
class TableDefViewerVO extends ValueObject implements Serializable, NoTableDef {

    String tableName
    Class valueObjectClass
    String fieldName
    String physicalName
    boolean key
    boolean listField
    boolean updateField
    boolean phiField
    boolean requiredField
    boolean encryptedField
    String dbCategory
    boolean cached

    TableDefViewerVO(String tableName, String fieldName) {
        this.tableName = tableName
        this.fieldName = fieldName
    }

    TableDefViewerVO(String field) {
        this.fieldName = field
    }

    String getValueObjectClassName() {
        if (valueObjectClass != null) {
            return valueObjectClass.getName().substring(valueObjectClass.getName().lastIndexOf(".") + 1)
        }
        return ""
    }

    String getIncrementedKey() {
        return ""
    }

    List<String> getRequiredFields() {
        return new ArrayList<String>()
    }

    List<String> getPrimaryKeyFields() {
        return new ArrayList<String>()
    }
}
