package com.optum.data

import com.optum.rf.dao.data.ValueObject
import groovy.transform.CompileStatic

/* Physical Table Name = BB_TABLE_FIELDS */
@CompileStatic
class TableFieldsVO extends ValueObject {
    /** Serialization Version ID compatibility - indication of what version may be restored.*/
    private static final long serialVersionUID = 1L;

    String table_name // TABLE_NAME
    String field_name // FIELD_NAME
    String sort_num // SORT_NUM
    boolean primary_key // PRIMARY_KEY
    boolean incremented_key // INCREMENTED_KEY
    String seq_name // SEQ_NAME
    boolean required // REQUIRED
    boolean defaultlist // DEFAULTLIST
    boolean phi // PHI
    String fkey_table // FKEY_TABLE
    String fkey_field // FKEY_FIELD
    int hilo_block_size // HILO_BLOCK_SIZE
}
