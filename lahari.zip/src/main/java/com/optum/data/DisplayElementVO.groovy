package com.optum.data

import com.optum.rf.dao.data.ValueObject
import groovy.transform.CompileStatic

/* Physical Table Name = dspl_elmnt */
@CompileStatic
class DisplayElementVO extends ValueObject {

    /** Serialization Version ID compatibility - indication of what version may be restored.*/
    private static final long serialVersionUID = 1L;

    long displayElementID      // dspl_elmnt_id
    String displayElementName // dspl_elmnt_nm
    String displayElementTypeID // dspl_elmnt_typ_id
    String displayElementDesc // dspl_elmnt_desc
}
