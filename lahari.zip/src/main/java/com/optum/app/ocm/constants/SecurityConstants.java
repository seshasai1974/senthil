package com.optum.app.ocm.constants;

import com.optum.rf.dao.constants.SystemSecurityConstants;

public final class SecurityConstants implements SystemSecurityConstants {
    public static final String SYSTEM_DATA_PROP = "SYSTEM_DATA_PROP";
    public static final String SYSTEM_HIPAA_278A = "SYSTEM_HIPAA_278A";
    public static final String SYSTEM_HIPAA_278N = "SYSTEM_HIPAA_278N";
    public static final String SYSTEM_HIPAA_278I = "SYSTEM_HIPAA_278I";
    public static final String SYSTEM_UHCOL = "SYSTEM_UHCOL";
    public static final String SYSTEM_AUTHLOGSSF = "SYSTEM_AUTHLOGSSF";
    public static final String SYSTEM_UHG_CRC = "SYSTEM_UHG_CRC";
    public static final String SYSTEM_HSR = "SYSTEM_HSR";
    public static final String SYSTEM = "SYSTEM";
    public static final String SYSTEM_USER_ID_PREFIX = "SYSTEM_";
    public static final String OLDPASSWORD = "oldPassword";
    public static final String CONFIRMPASSWORD = "confirmPassword";
    public static final String USER_GROUP_CCS_VIEW = "CCS_VIEW";
    public static final String SYSTEM_PTP = "SYSTEM_PTP";
    public static final String SYSTEM_PCP_REFERRAL = "SYSTEM_PCP_REFERRAL";
    public static final String MARK_INACTIVE = "(INACTIVE)";
    public static final String ADMINISTRATOR = "ADMINISTRATOR";
}

