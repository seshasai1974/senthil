package com.optum.app.ocm.messaging

import com.optum.rf.core.message.InternalMessageDestination
import com.optum.rf.core.message.MessageDestinationProvider
import groovy.transform.CompileStatic
import org.springframework.beans.factory.InitializingBean

import java.util.concurrent.ConcurrentHashMap

@CompileStatic
class BaseMessageDestination implements InitializingBean {

    /* Message Destination Names used by OCM BASE */
    public static final String LOCALE_STORAGE_REFERENCE_CACHE = "LOCALE_STORAGE_REFERENCE_CACHE";
    public static final String CUSTOMER_REFERENCE_READ_CACHE_TOPIC = "CUSTOMER_REFERENCE_READ_CACHE_TOPIC";
    public static final String CUSTOMER_REFERENCE_QUERY_CACHE_TOPIC = "CUSTOMER_REFERENCE_QUERY_CACHE_TOPIC";
    public static final String CUSTOMER_REF_FILTER_CHILD_VIEW_QUERY_CACHE_TOPIC = "CUSTOMER_REF_FILTER_CHILD_VIEW_QUERY_CACHE_TOPIC";
    public static final String CUSTOMER_REF_FILTER_CUSTOM_VIEW_QUERY_CACHE_TOPIC = "CUSTOMER_REF_FILTER_CUSTOM_VIEW_QUERY_CACHE_TOPIC";
    public static final String CUSTOMER_REF_FILTER_CUSTOM_QUERY_CACHE_TOPIC = "CUSTOMER_REF_FILTER_CUSTOM_QUERY_CACHE_TOPIC";
    public static final String CUSTOMER_REF_FILTER_CHILD_QUERY_CACHE_TOPIC = "CUSTOMER_REF_FILTER_CHILD_QUERY_CACHE_TOPIC";

    private static MessageDestinationProvider internalMessageDestinationProvider;

    // property method used to set the static field
    public void setMessageDestinationProvider(MessageDestinationProvider messageDestinationProvider) {
        internalMessageDestinationProvider = messageDestinationProvider;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        if(internalMessageDestinationProvider == null) {
            throw new RuntimeException("BaseMessageDestination: messageDestinationProvider property must be set.");
        }
    }

    public static InternalMessageDestination getDestination(String name) {
        if (internalMessageDestinationProvider != null) {
            return internalMessageDestinationProvider.getMessageDestination(name);
        } else {
            return null;
        }
    }

    public static Map<String, InternalMessageDestination> getMsgDestinationsByMessageType() {
        Map<String, InternalMessageDestination> msgDestinationsByClassName = new ConcurrentHashMap<>();
        for (String destName : internalMessageDestinationProvider.getMessageDestinationNames()) {
            InternalMessageDestination internalMessageDestination = getDestination(destName);
            if (internalMessageDestination.getMessageTrackingType() != null) {
                msgDestinationsByClassName.put(internalMessageDestination.getMessageTrackingType().getMessageTypeCode(), internalMessageDestination);
            }
        }
        return msgDestinationsByClassName;
    }

    public static boolean isMessageTrackingEnabledForMessageType(String forMessageType) {
        boolean enabled = false;
        if(forMessageType != null) {
            Map<String, InternalMessageDestination> msgDestinations = getMsgDestinationsByMessageType();
            InternalMessageDestination msgDestination = msgDestinations.get(forMessageType);
            if(msgDestination != null) {
                enabled = msgDestination.isMessageTrackingEnabled();
            }
        }
        return enabled;
    }

}
