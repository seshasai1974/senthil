package com.optum.app.ocm.display

import com.optum.rf.bl.businesslogic.BusinessLogic
import com.optum.data.DisplayElementViewVO
import groovy.transform.CompileStatic

@CompileStatic
interface DisplayElementView extends BusinessLogic<DisplayElementViewVO> {

    boolean isValid(long displayElementID)

    DisplayElementViewVO read(long displayElementID, String... readFields)

    List<DisplayElementViewVO> listForParent(long displayElementParentID, String displayElementName)


}