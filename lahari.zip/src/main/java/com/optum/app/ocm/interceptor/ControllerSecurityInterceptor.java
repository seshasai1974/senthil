package com.optum.app.ocm.interceptor;

import com.optum.app.common.constants.DataSecurityConstants;
import com.optum.app.ocm.cache.OcmCacheRefresh;
import com.optum.app.ocm.common.constants.FeatureFlagConstants;
import com.optum.app.ocm.customer.businesslogic.CustomerUser;
import com.optum.app.ocm.security.SecurityBypassConfiguration;
import com.optum.app.ocm.user.group.permission.business.UserGroupPermissionCache;
import com.optum.rf.common.featureflag.util.FeatureFlagUser;
import com.optum.rf.common.featureflag.util.FeatureFlagUtility;
import com.optum.rf.common.security.data.UserSecurityVO;
import com.optum.rf.core.controller.cache.ControllerRequestCache;
import com.optum.rf.core.util.Environment;
import com.optum.rf.dao.constants.SystemFieldConstants;
import com.optum.rf.dao.constants.SystemSecurityConstants;
import com.optum.rf.dao.controller.session.Session;
import com.optum.rf.dao.controller.session.SessionThreadLocal;
import com.optum.rf.dao.security.UserSecurity;
import com.optum.rf.web.constants.WebConstants;
import com.optum.rf.web.controller.request.Request;
import com.optum.rf.web.controller.session.HttpUserSession;
import com.optum.rf.web.controller.session.SessionException;
import com.optum.rf.web.security.PermissionCache;
import com.optum.rf.web.security.SecurityException;
import com.optum.rf.web.util.ControllerUtilities;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.TimeZone;

@Component
public class ControllerSecurityInterceptor extends HandlerInterceptorAdapter {
    private Logger logger = LoggerFactory.getLogger(ControllerSecurityInterceptor.class);
    public static final String CURRENT_PATH = "currentPath";
    public static final String HANDLER_MAPPING = "org.springframework.web.servlet.HandlerMapping.bestMatchingPattern";
    public static final String PRODUCES_ATTR = "org.springframework.web.servlet.HandlerMapping.producibleMediaTypes";
    public static final String AJAX_HEADER = "X-Requested-With";
    public static final String REFERER_HEADER = "REFERER";
    public static final String ORIGIN_HEADER = "ORIGIN";
    public static final String AJAX_VALUE = "XMLHttpRequest";
    public static final String CHAT_ACTION = "/chat/**";
    public static final String UI_CHAT_ACTION = "/ui/chat/**";
    public static final String EPA_RESP_ACTION = "/epa/resp/**";
    public static final String UI_EPA_RESP_ACTION = "/ui/epa/resp/**";

    @Autowired Environment environment;
    @Autowired PermissionCache permissionCache;
    @Autowired ControllerRequestCache controllerRequestCache;
    @Autowired CustomerUser customerUser;
    @Autowired private OcmCacheRefresh cacheRefresh;
    @Autowired UserGroupPermissionCache userGroupPermissionCache;
    @Autowired( required = false ) boolean stripContext = true;
    @Autowired( required = false ) private Set<SecurityBypassConfiguration> securityBypass = new HashSet<>();

    public ControllerSecurityInterceptor() {
        String url;
        if (FeatureFlagUtility.getManager().isActive(FeatureFlagConstants.FEDERATED_PLATFORM_ENDPOINT_UPDATES)) {
            url = "/ui/customers/{customerId}/references/{referenceName}";
        } else {
            url = "/ui/referenceService/v1/locale/{locale}/reference/{referenceName}";
        }
        SecurityBypassConfiguration loginDomain = new SecurityBypassConfiguration( "GET", url);
        loginDomain.addAllowedPathVariable( "{referenceName}", "loginDomain");
        securityBypass.add( loginDomain );
    }

    @Override
    public boolean preHandle(HttpServletRequest httpRequest, HttpServletResponse response, Object handler) throws Exception {
        String action = (String)httpRequest.getAttribute(HANDLER_MAPPING);
        LinkedHashSet produces = (LinkedHashSet) httpRequest.getAttribute(PRODUCES_ATTR);
        String referer = httpRequest.getHeader( REFERER_HEADER );
        String origin = httpRequest.getHeader( ORIGIN_HEADER );
        String whitelist = System.getProperty("WHITELIST");
        try{
            logger.debug("ControllerSecurityInterceptor preHandle action: {}", action);
            // check security and create the session
            HttpSession httpSession = httpRequest.getSession( false );
            Session session = doSessionAndSecurity( httpRequest, httpSession, action );
            SessionThreadLocal.setSession(session);
            controllerRequestCache.initialize();
            processWhiteList(referer, origin, whitelist);

        } catch(SessionException sessionException) {
            logger.error("session exception for method: {}, uri: {} ", cleanMethod(httpRequest.getMethod()), cleanLogMessage(httpRequest.getRequestURI()), sessionException );
            response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "timeout");
            return false;
        } catch(SecurityException sec) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN, "forbidden");
            logger.debug("SecurityException: Returning HTTP Status {} for method {}, uri: {}", HttpServletResponse.SC_FORBIDDEN, cleanMethod(httpRequest.getMethod()), cleanLogMessage(httpRequest.getRequestURI()), sec);
            return false;
        } catch(Exception ex) {
            logger.error("Caught exception while performing security check on request: {} {} ", cleanMethod(httpRequest.getMethod()), cleanLogMessage(httpRequest.getRequestURI()), ex);
            response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
            return false;
        }

        processHandler(response, handler, produces);

        return true;
    }

    private void processHandler(HttpServletResponse response, Object handler, LinkedHashSet produces) {
        if (handler instanceof HandlerMethod) {
            response.setHeader(DataSecurityConstants.LAST_REFERENCE_CACHE_REFRESH, cacheRefresh.getLastCacheRefresh());
            response.setHeader(DataSecurityConstants.CACHE_CONTROL_HEADER, "no-cache, no-store");
            response.setHeader(DataSecurityConstants.PRAGMA_HEADER, "no-cache");
            if (produces != null && produces.contains(MediaType.APPLICATION_PDF)) {
                response.setHeader(DataSecurityConstants.X_FRAME_OPTIONS_HEADER, "sameorigin");
            } else {
                response.setHeader(DataSecurityConstants.X_FRAME_OPTIONS_HEADER, "deny");
            }
        }
    }

    private void processWhiteList(String referer, String origin, String whitelist) throws SecurityException {
        if(StringUtils.isNotBlank(whitelist)){
            String[] validReferers = whitelist.split(",");
            boolean matchFound = false;
            for(String validReferer: validReferers){
                if((StringUtils.isNotBlank(referer) && referer.matches("(http|https):\\/\\/.*"+validReferer+"\\/.*")) || (StringUtils.isNotBlank(origin) && origin.matches("(http|https):\\/\\/.*"+validReferer+"\\/.*"))){
                    matchFound = true;
                    break;
                }
            }
            if(!matchFound) {
                throw new SecurityException();
            }
        }
    }

    @Override
    public void postHandle( HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
        String cleanMethod = cleanMethod(request.getMethod());
        String cleanLogMessage = cleanLogMessage(request.getRequestURI());
        logger.trace("ControllerSecurityInterceptor postHandle method: {}, uri: {}", cleanMethod, cleanLogMessage);
        SessionThreadLocal.removeSession();
    }


    /**
     * Get the session, check security, and bind values to the SessionThreadLocal
     *
     * @param request     request
     * @param httpSession session
     * @param action      action to perform
     * @return Session session
     * @throws Exception exception
     */
    private Session doSessionAndSecurity(HttpServletRequest request, HttpSession httpSession, String action) throws SecurityException, SessionException {
        UserSecurity userSecurity = validateSession( request, httpSession);
        String permissionID = getPermissionID( request, action );
        if( permissionID == null || !checkSecurity( userSecurity, permissionID )){
            logger.error( DENY_NOMATCH, userSecurity.getUserID(), request.getRequestURI(), action );
            throw new SecurityException();
        }

        Session ses = createSession(request,httpSession, permissionID, userSecurity);
        request.setAttribute(SystemFieldConstants.CHANGEUSERID, userSecurity.getUserID());
        return ses;
    }
    //error message placed here to allow ease of reading it, made public for testability
    public static final String DENY_NOMATCH = "DENY - user: {} unable to match requestUri:{} to action: {}";

    /**
     * Construct the permission ID string.
     *
     * @param request request
     * @param action  action to perform
     * @return permissionID
     */
    private String getPermissionID( HttpServletRequest request, String action ){
        String permissionUrl = determinePermissionUrl(request, action);
        if( permissionUrl == null ){
            request.setAttribute(SystemSecurityConstants.PERMISSION_STRING, null );
            return null;
        }
        if(stripContext){
            String context = request.getContextPath();
            if( permissionUrl.startsWith( context )){
                permissionUrl = permissionUrl.substring( context.length());
            }
        }
        String permissionID = request.getMethod() + " " + permissionUrl;
        request.setAttribute(SystemSecurityConstants.PERMISSION_STRING, permissionID);
        return permissionID;
    }

    /**
     * Ensure the user's current session is valid by getting the HttpSession and pulling the SecurityVO from that.
     * The SessionThreadLocal value will be set from the pulled SecurityVO.
     * If valid, return the user's SecurityVO. Otherwise, throw the SESSION_EXCEPTION.
     *
     * @param session session
     * @return UserSecurit
     * @throws Exception exception
     */
    protected UserSecurity validateSession(final HttpServletRequest request, final HttpSession session) throws SessionException {

        if(session == null) {
            String cleanMethod = cleanMethod(request.getMethod());
            String cleanLogMessage = cleanLogMessage(request.getRequestURI());
            logger.error( DENY_NULLSESSION, cleanMethod, cleanLogMessage);
            throw new SessionException();
        }
        UserSecurity userSecurity = setTenantConnections((UserSecurityVO) session.getAttribute(SystemSecurityConstants.SECURITY_OBJECT));
        if(userSecurity == null) {
            String cleanMethod = cleanMethod(request.getMethod());
            String cleanLogMessage = cleanLogMessage(request.getRequestURI());
            logger.error( DENY_NULLUSERSEC, cleanMethod, cleanLogMessage);
            throw new SessionException();
        }
        return userSecurity;
    }
    //these are public for testability and are located here to make it easy to change the message
    public static final String DENY_NULLSESSION = "DENY - HttpSession is null in HttpController.validateSession for request: {} {}";
    public static final String DENY_NULLUSERSEC = "DENY - HttpSession is NOT null in HttpController.validateSession, but UserSecurity IS null for request: {} {}";

    private UserSecurityVO setTenantConnections (UserSecurityVO userSecurityVO) {
        if (userSecurityVO != null) {
            userSecurityVO.setActiveTenantIDs(customerUser.getActiveCustomerByUserID(userSecurityVO.getUserID()));
            String contextTenantID = System.getProperty("APPROVAL_TYPE");
            userSecurityVO.setContextTenantID(contextTenantID == null ? 0L : Long.parseLong(contextTenantID));
        }
        return userSecurityVO;
    }

    /**
     * Bind the HttpSession object to a ThreadLocal by creating a new
     * Session object and binding that.
     * <p/>
     * Note: the HttpSession is passed in for future when there may be session attributes that
     * must be bound to the Session object.
     *
     * @param httpSession  session
     * @param permissionID permission ID
     * @param userSecurity user security
     * @return session
     */
    protected Session createSession(HttpServletRequest request, HttpSession httpSession, String permissionID, UserSecurity userSecurity) {
        Session session = new HttpUserSession(httpSession);
        session.setUserSecurity(userSecurity);
        session.setPermissionID(permissionID);
        // Time zone should already be set in Http Session if logged in to ICUE using login page through the offset parameter.
        // For SSO Login, the offset parameter will passed in transfer page and time zone is set in the Http Session.
        if(httpSession.getAttribute(WebConstants.TIME_ZONE_OFFSET)!=null){
            session.setUserTimeZone((TimeZone) httpSession.getAttribute(WebConstants.TIME_ZONE_OFFSET));
        }else{
            if(StringUtils.isNotBlank(request.getParameter(WebConstants.TIME_ZONE_OFFSET))){
                TimeZone timeZone = ControllerUtilities.getTimeZone(request);
                session.setUserTimeZone(timeZone);
                httpSession.setAttribute(WebConstants.TIME_ZONE_OFFSET,timeZone);
            }
        }

        return session;
    }

    /**
     * Check to ensure the user has sufficient security to the requested function.
     *
     * @param userSecurity The user security object from the session
     *                     context that contains the user's list of roles, etc.
     * @param permissionID The requested permission (normally the path +
     *                     the action but may also include other variables like fields, etc.)
     * @return True if the user has security, else False.
     */
    private boolean checkSecurity(UserSecurity userSecurity, String permissionID) {
        logger.trace("checkSecurity( userSecurity: {}, permissionID: {}", userSecurity, permissionID );
        FeatureFlagUser featureFlagUser = new FeatureFlagUser();
        featureFlagUser.setUserID(userSecurity.getUserID());
        featureFlagUser.setPermissionGroups(userSecurity.getPermissionGroups());
        List<String> list = permissionCache.getPermissionGroups(permissionID);
        String cleanLogMessage = cleanLogMessage(permissionID);
            logger.trace("permissionGroups for permissionID: {} => {}", list, cleanLogMessage );
            if( list == null ){
                logger.error( DENY_NOPERMISSIONLIST, userSecurity.getUserID(), permissionID );
                return false;
            }
            for(String permGroup : list) {
                if( userSecurity.getPermissionGroups().contains(permGroup)) {
                    logger.debug( ALLOW_PERMISSIONGROUP, userSecurity.getUserID(), permissionID, permGroup );
                    return true;
                }
            }
            logger.debug( DENY, userSecurity.getUserID(), permissionID );
            return false;
    }
    //Notice these strings are public to allow testing them and are located here for easy readability
    public static final String DENY = "DENY - user: {} access to permissionID: {} no matching permission groups.";
    public static final String ALLOW_NOSECURITYCHECK = "ALLOW - user: {} access to permissionID: {} checkSecurity OFF";
    public static final String ALLOW_PERMISSIONGROUP = "ALLOW - user: {} access to permissionID: {} due to permissionGroup: {}";
    public static final String DENY_NOPERMISSIONLIST = "DENY - user: {} access to permissionID: {} null permission list.";
    private String determinePermissionUrl( HttpServletRequest request, String action ){
        String requestUri = request.getRequestURI();
        StringMatcher matcher = new StringMatcher( requestUri );
        boolean matched = matcher.match( action );
        if( matched ){
            return matcher.getModified();
        } else if(CHAT_ACTION.equals(action)) {
            return UI_CHAT_ACTION;
        } else if(EPA_RESP_ACTION.equals(action)) {
            return UI_EPA_RESP_ACTION;
        }
        return null;
    }

    private class StringMatcher {
        private List<String> modifiedSourceParts = new ArrayList<>();
        private String source;

        public StringMatcher( String source ){
            this.source = source;
        }
        private int findStart( String toSearch, int start ){
            int slashPos = toSearch.indexOf( "/", start );
            if( slashPos < 0 ){
                slashPos = 0;
            }else{
                ++slashPos;
            }
            return slashPos;
        }
        public boolean match( String toMatch ){

            String[] parts = toMatch.split( "/");
            int part = "".equals( parts[0])? 1 : 0;//if have leading slash, get empty first element, so we skip it.
            int prevEnd = 0;
            int start = findStart( source, 0 );
            if(isInvalidStart(parts[part], start)){
                return false;
            }
            boolean noMatches = true;
            boolean done = false;
            while( !done ){
                boolean matches = matchPart(parts[part], start);
                boolean repVar = parts[part].startsWith( "{"); //beginning of a PathVariable replacement var in Spring
                boolean asterisk = "*".equals( parts[part]);
                if( matches ){
                    noMatches = false;
                    ++part;
                }else if( repVar || asterisk ){//replacement variable
                    modifiedSourceParts.add( source.substring( prevEnd, start ));
                    modifiedSourceParts.add( parts[part]);
                    ++part;
                }

                start = findStart( source, start );
                if( repVar || asterisk ){
                    prevEnd = start - 1;
                }
                boolean eoToMatch = part >= parts.length;
                boolean eoSource = start >= source.length() || start <= 0;//index past end if had trailing slash, or did not find another slash
                if (checkeSourceAndMatch(toMatch, eoToMatch, eoSource, "nonMatching due to toMatch too long. source: {}, toMatch: {}")) return false;
                if (checkeSourceAndMatch(toMatch, eoSource, eoToMatch, "nonMatching due to source too long. source: {}, toMatch: {}")) return false;
                done = isDone(prevEnd, done, eoToMatch, eoSource);
            }
            return !noMatches;
        }

        private boolean isInvalidStart(String part1, int start) {
            return start >= source.length() - 1 || start + part1.length() > source.length();
        }

        private boolean isDone(int prevEnd, boolean done, boolean eoToMatch, boolean eoSource) {
            if( eoSource && eoToMatch){
                if( prevEnd >= 0 ) {//if ended with a repvar and no trailing slash get prevEnd < 0
                    modifiedSourceParts.add(source.substring(prevEnd));
                }
                done = true;
            }
            return done;
        }

        private boolean checkeSourceAndMatch(String toMatch, boolean eoToMatch, boolean eoSource, String s) {
            if (eoSource && !eoToMatch) {
                logger.debug(s, source, toMatch);
                return true;
            }
            return false;
        }

        private boolean matchPart( String part, int start ){
            int charIndex = 0;
            for( ; charIndex + start < source.length() && charIndex < part.length(); charIndex++ ){
                if( source.charAt(start + charIndex ) != part.charAt( charIndex )){
                    return false;
                }
            }
            return (charIndex + start) >= source.length() || source.charAt( start + charIndex ) == '/'; //matched if we hit end of source or the delimiter
        }
        public String getModified(){
            if( modifiedSourceParts.isEmpty() ){
                return null;
            }

            StringBuilder sb = new StringBuilder(modifiedSourceParts.size() * 4);
            for( String part : modifiedSourceParts ){
                sb.append( part );
            }
            return sb.toString();
        }
    }

    protected final String getCurrentUserID(Request request) {
        return request.getSession().getUserSecurity().getUserID();
    }

    public Set<SecurityBypassConfiguration> getSecurityBypass() {
        return securityBypass;
    }

    public void setSecurityBypass(Set<SecurityBypassConfiguration> securityBypass) {
        this.securityBypass = securityBypass;
    }

    private String cleanLogMessage(String message){
        String cleanMessage = "";
        if(message != null) {
            cleanMessage = message.toLowerCase()
                    .replace('\n', '_').replace('\r', '_')
                    .replace("insert", " ")
                    .replace("update", " ")
                    .replace("delete", " ");
        }
        return cleanMessage;
    }

    private String cleanMethod(String message){
        String cleanMethod = "";

        if("GET".equalsIgnoreCase(message)) {
            cleanMethod = "GET";
        }else if("POST".equalsIgnoreCase(message)) {
            cleanMethod = "POST";
        }
        return cleanMethod;
    }
}
