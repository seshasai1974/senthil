package com.optum.app.ocm.interceptor;

import com.optum.rf.common.constants.SettingConstants;
import com.optum.rf.common.settings.businesslogic.SystemSettingsFramework;
import com.optum.rf.common.settings.businesslogic.TemporarySystemSetting;
import com.optum.rf.common.settings.data.SystemSettingsFrameworkVO;
import com.optum.rf.core.util.Environment;
import com.optum.rf.dao.constants.SystemSecurityConstants;
import com.optum.rf.dao.security.UserSecurity;
import com.optum.rf.web.controller.request.HttpRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Created by skohl on 8/11/2016.
 */
public class DebugSlowConnectionSimulatorInterceptor extends HandlerInterceptorAdapter {
    @Autowired Environment environment;
    @Autowired SystemSettingsFramework systemSettingsFramework;
    @Autowired TemporarySystemSetting temporarySystemSetting;

    private static final Logger logger = LoggerFactory.getLogger( DebugSlowConnectionSimulatorInterceptor.class );

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        performSlowConnectionSimulation( request );
        return true;
    }

    protected void performSlowConnectionSimulation(HttpServletRequest request) throws InterruptedException{
        if(checkSimulateSlowConnection()){
            SystemSettingsFrameworkVO systemSettingsFrameworkVO = systemSettingsFramework.read();
            if(systemSettingsFrameworkVO.isSimulateSlowConnection()){
                HttpSession session = request.getSession( false );
                if( session == null ){
                    logger.warn( "Could not retrieve session for request: {} {}", cleanMethod(request.getMethod()), request.getRequestURI());
                    return;
                }
                UserSecurity userSecurity = (UserSecurity) session.getAttribute(SystemSecurityConstants.SECURITY_OBJECT);
                int sleepTime = temporarySystemSetting.getIntSetting((userSecurity.getUserID().toLowerCase() + SettingConstants.TEMP_SIMULATE_SLOW_CONN_SETTING));
                if(sleepTime < 0){
                    sleepTime = temporarySystemSetting.getIntSetting((userSecurity.getUserID() + SettingConstants.TEMP_SIMULATE_SLOW_CONN_SETTING));
                }
                if(sleepTime > 0){
                    logger.warn("***** Simulating slow network connection for: {} seconds. ***** on request: {} {}", sleepTime / 1000, cleanMethod(request.getMethod()), request.getRequestURI());
                    Thread.sleep(sleepTime);
                }
            }
        }
    }

    /**
     * This is used to check for Production a environment for the slow connection simulation should never run.
     *
     * @return boolean - true if slow connection can be simulated, otherwise false.
     */
    private boolean checkSimulateSlowConnection() {
        return !environment.getEnvironment().getID().equals(Environment.Env.PRODUCTION.getID());
    }

    private String cleanMethod(String message){
        String cleanMethod = "";

        if("GET".equalsIgnoreCase(message)) {
            cleanMethod = "GET";
        }else if("POST".equalsIgnoreCase(message)) {
            cleanMethod = "POST";
        }
        return cleanMethod;
    }
}
