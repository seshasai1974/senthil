package com.optum.app.ocm.interceptor;

import org.apache.commons.lang.StringEscapeUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * DebugHttpStatusInterceptor is an interceptor that looks for a particular request param and will return
 * the http status suggested by that param. It can be used for debugging UI code when it is difficult to
 * create the conditions that would be needed to get the service to naturally return that http status.
 *
 * Notice if the parameter does not exist, the call is allowed to continue. If the status is not numeric
 * the httpStatus is set to 400 with a message stating that the httpStatus passed was not numeric.
 *
 * Created by skohl on 7/12/2016.
 */
public class DebugHttpStatusInterceptor extends HandlerInterceptorAdapter {
    private static final Logger logger = LoggerFactory.getLogger( DebugHttpStatusInterceptor.class );
    private static final String STATUS_PARAMETER_DEFAULT = "debugHttpStatus";

    private String statusParameter = STATUS_PARAMETER_DEFAULT;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        logger.trace( "preHandle( method: {}, url: {}", cleanMethod(request.getMethod()), request.getRequestURI() );
        String sstatus = request.getParameter( getStatusParameter());
        if( sstatus == null ){
            logger.trace( "No status found. Allowing chain to continue.");
            return true;
        }
        try{
            int status = Integer.valueOf( sstatus );
            logger.trace( "Status found. interrupting request with status: {}", status );
            response.sendError( status );
            return false;
        }catch ( NumberFormatException nfe ){
            logger.error( "Caller sent bad httpStatus: {}", null, nfe );
            response.sendError( HttpServletResponse.SC_BAD_REQUEST, StringEscapeUtils.escapeHtml("httpStatus was not numeric. status: "+sstatus));
            return false;
        }
    }

    public String getStatusParameter() {
        return statusParameter;
    }
    public void setStatusParameter(String statusParameter) {
        this.statusParameter = statusParameter;
    }

    private String cleanMethod(String message){
        String cleanMethod = "";

        if("GET".equalsIgnoreCase(message)) {
            cleanMethod = "GET";
        }else if("POST".equalsIgnoreCase(message)) {
            cleanMethod = "POST";
        }
        return cleanMethod;
    }
}
