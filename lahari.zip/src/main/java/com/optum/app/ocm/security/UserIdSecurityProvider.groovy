package com.optum.app.ocm.security

import com.optum.rf.common.constants.CommonFieldConstants
import com.optum.rf.common.constants.CommonReferenceConstants
import com.optum.rf.common.messages.SecurityMessages
import com.optum.rf.common.security.businesslogic.User
import com.optum.rf.common.security.data.UserVO
import com.optum.rf.common.util.CommonUtilities
import com.optum.rf.dao.constants.SystemGlobalMessages
import com.optum.rf.dao.constants.SystemSecurityConstants
import com.optum.rf.dao.exception.UhgRuntimeException
import com.optum.rf.dao.sql.exception.FinderException
import groovy.transform.CompileStatic
import org.apache.commons.lang.StringUtils
import org.apache.commons.logging.Log
import org.apache.commons.logging.LogFactory
import org.springframework.security.authentication.AuthenticationProvider
import org.springframework.security.authentication.BadCredentialsException
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken
import org.springframework.security.core.Authentication
import org.springframework.security.core.AuthenticationException

/**
 * An Authentication Provider that only requires the existence of a valid UserID
 * in the application User table.  Although passwords are required to be present,
 * no validation of the password is performed.  This implementation can be used in
 * while testing an application or in environments without formal password validation.
 */
@CompileStatic
class UserIdSecurityProvider implements AuthenticationProvider {
    protected final Log logger = LogFactory.getLog(getClass());
    private User user;

    public final void setRequiredUser(User user) {
        this.user = user;
    }

    @Override
    Authentication authenticate(Authentication authentication) throws AuthenticationException {

        String loginId = authentication.getName();
        String passwd = authentication.getCredentials().toString();
        UserVO userVO = validateUserInApp(loginId, passwd);

        if(userVO.errorMessagesExist()) {
            throw new UhgRuntimeException(userVO);
        }

        // audit trail for user login
        updateLastLoginDate(userVO);

        // return a valid User Authentication
        return new UsernamePasswordAuthenticationToken(authentication.getPrincipal(), authentication.getCredentials(), []);
    }

    @Override
    public boolean supports(Class<?> authentication) {
        return UsernamePasswordAuthenticationToken.class.isAssignableFrom(authentication);
    }

    private void updateLastLoginDate(UserVO userVO) {
        userVO.setLastLoginDate(new java.sql.Date(System.currentTimeMillis()));
        try {
            this.user.updateLastLoginDate(userVO);
        } catch(FinderException ue) {
            // this can only happen if the user was deleted after retrieval and before this update
            userVO.addGlobalMessage(SecurityMessages.ERR_AUTHENTICATION_FAILED);
            throw new BadCredentialsException(CommonUtilities.getErrorString(userVO));
        }
    }

    /*
     * check if the user exists in the database
     */
    private UserVO validateUserInApp(String loginId, String passwd) {
        UserVO userVO = new UserVO();
        if(StringUtils.isBlank(loginId)) {
            userVO.addMessage(CommonFieldConstants.USERID, SystemGlobalMessages.ERR_REQUIRED_VALUE);
        } else if(StringUtils.isBlank(passwd)) {
            userVO.addMessage(CommonFieldConstants.PASSWORD, SystemGlobalMessages.ERR_REQUIRED_VALUE);
        } else {
            userVO = this.user.read(loginId);
            if(userVO == null) {
                userVO = new UserVO();
                userVO.addGlobalMessage(SecurityMessages.ERR_INVALID_USERID);
            } else {
                if(CommonReferenceConstants.LOGIN_STATUS_DISABLED.equals(userVO.getLoginStatus())) {
                    userVO.addGlobalMessage(SecurityMessages.ERR_DISABLED_USER);
                }
                if(userVO.getUserID().startsWith(SystemSecurityConstants.SYSTEM_USER)){
                    userVO.addGlobalMessage(SecurityMessages.ERR_SYSTEM_USER_INVALID);
                }
            }
        }
        return userVO;
    }


}