package com.optum.app.ocm


def runTests(type, goals) {
    try {
        sh "mvn test-compile ${goals} -B"
    } catch(e) {
        if(currentBuild.result == 'UNSTABLE') {
            currentBuild.result = 'FAILURE'
        }
        throw e
    } finally {
        junit "**/target/${type}-reports/TEST-*.xml"
        }
    }

/**
 * Run tests with maven
 *
 * @param type - the test type
 * @param goals - maven goals
 */
def installAndRunTests() {
    try {
        //sh "mvn test-compile ${goals} -B"
        sh 'mvn -B -U install'
    } catch(e) {
        if(currentBuild.result == 'UNSTABLE') {
            currentBuild.result = 'FAILURE'
        }
        throw e
    } finally {
        junit "**/target/surefire-reports/TEST-*.xml"
        }
    }

def testCall() {
    echo 'Testing Pipeline'
}

return this