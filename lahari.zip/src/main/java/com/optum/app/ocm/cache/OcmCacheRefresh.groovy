package com.optum.app.ocm.cache

import com.optum.rf.common.cache.businesslogic.CacheRefresh
import com.optum.rf.common.cache.data.CacheRefreshVO
import com.optum.rf.core.message.InternalMessageListener

interface OcmCacheRefresh extends CacheRefresh, InternalMessageListener {

    void clearAppCaches(CacheRefreshVO vo)

    Date getLastCacheRefreshDate()

    String getLastCacheRefresh()

    void resetLastReferenceCacheRefresh()
}
