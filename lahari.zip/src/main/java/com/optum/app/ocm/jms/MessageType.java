package com.optum.app.ocm.jms;

import com.optum.rf.core.util.edi.JmsMessageType;

import org.apache.commons.lang.ArrayUtils;

/**
 */
public enum MessageType implements JmsMessageType {
    SMART_DB_COMM_CARE("Test", "Inbound feed from Community Care"),
    DATE("Date", "Sending a date");

    private String messageTypeCode;
    private String messageTypeDescription;
    private String[] searchFields;

    MessageType(final String messageTypeCode, final String messageTypeDescription, final String... searchFields) {
        this.searchFields = searchFields;
        this.messageTypeCode = messageTypeCode;
        this.messageTypeDescription = messageTypeDescription;
    }

    public String getMessageTypeCode() {
        return messageTypeCode;
    }

    public String getMessageTypeDescription() {
        return messageTypeDescription;
    }

    public String[] getSearchFields() {
        return (String[]) ArrayUtils.clone(searchFields);
    }

    public static String[] getSearchFields(final String messageType) {
        for (final MessageType mt : MessageType.values()) {
            if (mt.getMessageTypeCode().equals(messageType)) {
                return mt.getSearchFields();
            }
        }
        return new String[]{};
    }
}