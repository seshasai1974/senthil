package com.optum.app.ocm.common

import com.optum.app.ocm.amqp.BaseAMQPDestinationProvider
import com.optum.app.ocm.jms.BaseJMSDestinationProvider
import com.optum.app.ocm.messaging.BaseMessageDestination
import com.optum.rf.common.amqp.AMQPMessageDestinationProvider
import com.optum.rf.common.jms.JMSMessageDestinationProvider
import com.optum.rf.common.messaging.CommonMessageDestination
import com.optum.rf.common.settings.businesslogic.SystemSettingsWorkManager
import com.optum.rf.common.settings.data.SystemSettingsWorkManagerVO
import com.optum.rf.core.message.MessageDestinationProvider
import com.optum.rf.core.util.async.AsyncExecutor
import com.optum.rf.core.util.async.impl.AsyncExecutorImpl
import com.optum.rf.dao.tabledef.FieldPropertyFactory
import com.optum.rf.dao.tabledef.TableDefFactory
import com.optum.rf.dao.tabledef.TableDefFactoryLoader
import com.optum.app.constants.SettingsReferenceConstants
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.context.annotation.Bean

import java.util.concurrent.SynchronousQueue
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit

abstract class BaseApplicationConfigurationLoader {

    // Set the following member variables in the static
    // initializer section of the subclass.  Example:
    //      static {
    //          MERGED_FIELDS_URI = "/resources/backbone/common/merged_fields.xml"
    //          TABLEDEF_FACTORY_LOADER = new TableDefFactoryLoaderImpl()
    //      }
    
    protected static String MERGED_FIELDS_URI
    protected static TableDefFactoryLoader TABLEDEF_FACTORY_LOADER

    protected static String MSG_PROVIDER_TYPE_JMS = "JMS"
    protected static String MSG_PROVIDER_TYPE_AMQP = "AMQP"
    protected static String MSG_PROVIDER_TYPE = System.getProperty("MSG_PROVIDER_TYPE")
   
    @Autowired
    @Qualifier(value = "com.optum.rf.common.settings.businesslogic.SystemSettingsWorkManager")
    @org.springframework.context.annotation.Lazy
    protected SystemSettingsWorkManager settingsWorkManager

    // --------------------------------------------------------------------------
    // Message Destination information must be configured BEFORE the TableDefFactory
    // Need to specify either JMS or AMQP messaging destinations and providers

    @Bean(name = "com.optum.rf.common.messaging.CommonMessageDestination")
    public static CommonMessageDestination getCommonMessageDestination() {
        MessageDestinationProvider commonProvider
        if (MSG_PROVIDER_TYPE_AMQP.equalsIgnoreCase(MSG_PROVIDER_TYPE)) {
            commonProvider = new AMQPMessageDestinationProvider()
        } else {
            commonProvider = new JMSMessageDestinationProvider()
        }
        new CommonMessageDestination(messageDestinationProvider: commonProvider)
    }

    @Autowired
    @Qualifier(value = "com.optum.rf.common.messaging.CommonMessageDestination")
    private final CommonMessageDestination commonMessageDestination

    // --------------------------------------------------------------------------

    @Bean(name = "com.optum.app.ocm.messaging.BaseMessageDestination")
    public static BaseMessageDestination getBaseMessageDestination() {
        MessageDestinationProvider baseProvider
        if (MSG_PROVIDER_TYPE_AMQP.equalsIgnoreCase(MSG_PROVIDER_TYPE)) {
            baseProvider = new BaseAMQPDestinationProvider()
        } else  {
            baseProvider = new BaseJMSDestinationProvider()
        }
        new BaseMessageDestination(messageDestinationProvider: baseProvider)
    }

    @Autowired
    @Qualifier(value = "com.optum.app.ocm.messaging.BaseMessageDestination")
    private final BaseMessageDestination baseMessageDestination

    // --------------------------------------------------------------------------

    // Field Property Factory 
    @Bean(name = "com.optum.rf.dao.tabledef.FieldPropertyFactory")
    public static FieldPropertyFactory getFieldPropertyFactory() {
        FieldPropertyFactory.getInstanceFromResource(MERGED_FIELDS_URI)
    }

    @Autowired
    @Qualifier(value = "com.optum.rf.dao.tabledef.FieldPropertyFactory")
    protected final FieldPropertyFactory fieldPropertyFactory

    @Bean(name = "com.optum.rf.dao.tabledef.TableDefFactory")
    public static TableDefFactory getTableDefFactory() {
        new TableDefFactory(TABLEDEF_FACTORY_LOADER)
    }

    @Autowired
    @Qualifier(value = "com.optum.rf.dao.tabledef.TableDefFactory")
    protected final TableDefFactory tableDefFactory

    @Bean(name = "com.optum.rf.core.util.async.AsyncExecutor")
    public AsyncExecutor getDefaultAsyncExecutor() {

        SystemSettingsWorkManagerVO systemSettingsWorkManagerVO = settingsWorkManager.read(SettingsReferenceConstants.WORKMANAGERID_DEFAULT)
        // create an AsyncExecutor with a specific Thread Pool
        new AsyncExecutorImpl(concurrentExecutor: new ThreadPoolExecutor(systemSettingsWorkManagerVO ? systemSettingsWorkManagerVO.minThreadCount : 0,
                                                                         systemSettingsWorkManagerVO ? systemSettingsWorkManagerVO.maxThreadCount : 10,
                                                                         systemSettingsWorkManagerVO ? systemSettingsWorkManagerVO.threadIdleTimeMaxSecondsCount : 60L,
                                                                         TimeUnit.SECONDS, new SynchronousQueue<Runnable>()))
    }
}
