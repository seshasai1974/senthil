package com.optum.app.ocm.util;

import com.optum.rf.common.scheduler.util.ScheduledJobInitializer;
import com.optum.rf.common.scheduler.util.SystemJobType;
import com.optum.rf.common.scheduler.util.trigger.SchedulerControl;
import com.optum.rf.common.security.util.SecuredDataCache;
import com.optum.rf.common.security.util.SecuredDataCacheImpl;
import com.optum.rf.io.FileSystemInitializer;
import com.optum.rf.core.spring.ApplicationContextHolder;
import com.optum.rf.dao.tabledef.FieldPropertyFactory;
import com.optum.rf.core.util.Environment;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class AppInitializer extends HttpServlet {

    private static final Log LOG = LogFactory.getLog(AppInitializer.class);

    /**
     * Initialize resources used by the application. Several Singletons and other
     * data-caching classes are turned on to begin processing, receiving JMS
     * messages, cache resources, etc. This is invoked once by the InitializationServlet
     * and once in the SessionProcessorAY when initializing the EJB tier.
     */
    public void initialize() {
        // initialize singletons that cache data
        try {
            FieldPropertyFactory.getInstance();
        } catch (Exception e) {
            LOG.error("Error initializing application.", e);
        }
    }

    /**
     * Initialize resources for the caches and Job Scheduler. These resources <b>do not</b> include
     * those initialized in the initialize method. Those resources should be
     * initialized separately.
     */
    public void initializeCaches() {
        ((SecuredDataCacheImpl) ApplicationContextHolder.getBean(SecuredDataCache.class)).initCache();
    }

    /**
     * Make sure that the File System is setup as it's defined within the
     */
    private void initializeFileSystem() {
        FileSystemInitializer fileSystemInitializer = ApplicationContextHolder.getBean(FileSystemInitializer.class);
        fileSystemInitializer.initialize();
    }

    /**
     * Initialize the scheduler, including creation of system generated scheduled jobs and starting
     * the scheduler thread.
     */
    private void initializeSchedulers() {
        ScheduledJobInitializer scheduledJobInitializer = ApplicationContextHolder.getBean(ScheduledJobInitializer.class);
        Environment.Env env = ApplicationContextHolder.getBean(Environment.class).getEnvironment();
        if (Environment.Env.LOCAL != env) {
            scheduledJobInitializer.initializeSystemJobs(getSystemJobs());
        }
        if (Environment.Env.LOCAL == env) {
            LOG.info("The scheduler thread will not start in a LOCAL environment.  Please start it manually using the Job Scheduler Maintenance function in the System Menu.");
        } else {
            ApplicationContextHolder.getBean(SchedulerControl.class).startScheduler();
        }
    }

    /**
     * @return list of system jobs to be scheduled
     */
    protected List<SystemJobType> getSystemJobs() {
        List<SystemJobType> systemJobTypes = new ArrayList<>();
        Collection<SystemJobType> systemJobTypeBeans = ApplicationContextHolder.getBeans(SystemJobType.class).values();
        LOG.info("Found " + systemJobTypeBeans.size() + " beans of " + SystemJobType.class.getName() + " used to initialize the job scheduler");
        systemJobTypes.addAll(systemJobTypeBeans);
        return systemJobTypes;
    }

    @Override
    public void init(ServletConfig servletConfig) throws ServletException {
        super.init(servletConfig);
        try {
            if (LOG.isDebugEnabled()) {
                LOG.debug("Initializing the Application");
            }
            initialize();
            initializeCaches();
            initializeFileSystem();
            initializeSchedulers();
        } catch (Exception e) {
            LOG.error("Error loading AppInitializer: " + e.getMessage(), e);
        }
    }

    @Override
    public void destroy() {
        ApplicationContextHolder.getBean(SchedulerControl.class).stopScheduler();
    }

}
