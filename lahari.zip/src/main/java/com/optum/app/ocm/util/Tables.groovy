package com.optum.app.ocm.util

import com.optum.rf.bl.businesslogic.BusinessLogic
import com.optum.data.TablesVO

/**
 * Created by achunh on 7/20/18.
 */
interface Tables extends BusinessLogic<TablesVO>{

    boolean isValid(String table_name)

    TablesVO read(String table_name, String ... readFields)

    List<TablesVO> listTablesByTableName(String tableName)

    List<TablesVO> listTablesForValueObjectClass(String valueObjectClass)
}
