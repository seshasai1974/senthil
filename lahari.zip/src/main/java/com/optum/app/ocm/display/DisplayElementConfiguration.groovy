package com.optum.app.ocm.display

import com.optum.rf.bl.businesslogic.BusinessLogic
import com.optum.data.DisplayElementConfigurationVO

/**
 * Created by jyadeau on 3/28/19.
 */
interface DisplayElementConfiguration extends BusinessLogic<DisplayElementConfigurationVO> {

    /**
     * List by customerIDs and element name
     *
     * @param customerIDs
     * @param displayElementName
     * @return
     */
    List<DisplayElementConfigurationVO> listForCustomersByElementName(Set<Integer> customerIDs, String displayElementName)

    /**
     * List by customerID
     *
     * @param customerIDs
     * @return
     */
    List<DisplayElementConfigurationVO> listForCustomerIDs(Set<Integer> customerIDs)

}