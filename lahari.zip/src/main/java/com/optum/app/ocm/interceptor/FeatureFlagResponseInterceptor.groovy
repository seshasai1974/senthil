package com.optum.app.ocm.interceptor

import com.optum.rf.common.featureflag.util.FeatureFlagManager
import com.optum.rf.common.featureflag.util.FeatureFlagUtility
import com.optum.rf.dao.controller.session.Session
import com.optum.rf.dao.controller.session.SessionThreadLocal
import com.optum.rf.web.util.ControllerUtilities
import groovy.transform.CompileStatic
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.web.servlet.ModelAndView
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter

import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse

@CompileStatic
class FeatureFlagResponseInterceptor  extends HandlerInterceptorAdapter {

    private Logger logger = LoggerFactory.getLogger(FeatureFlagResponseInterceptor.class)

    @Override
    void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
        // retrieve all client-side Feature Flags and the values for the current user
        FeatureFlagManager featureFlagManager = FeatureFlagUtility.getManager()
        if (featureFlagManager != null) {
            Map<String, Object> userFeatureFlags = featureFlagManager.getClientFeatures()
            if (logger.isDebugEnabled()) {
                logger.debug("postHandle( method: {}, url: {}, user: {}, feature flags: {}", request.getMethod(), request.getRequestURI(), getUserId(), userFeatureFlags)
            }
            request.setAttribute(ControllerUtilities.CLIENT_FEATURE_FLAGS, userFeatureFlags)
        }
    }

    private String getUserId() {
        Session session = SessionThreadLocal.getSession()
        if (session && session.userSecurity) {
            session.userSecurity.userID
        } else {
            "unknown"
        }

    }
}
