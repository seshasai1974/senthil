package com.optum.app.ocm.jms;

import com.optum.app.ocm.messaging.BaseMessageDestination;
import com.optum.rf.common.jms.JmsDestinationHelper;
import com.optum.rf.common.messaging.CommonMessageDestination;

import com.optum.rf.core.message.MessageDestination;

/**
 */
public class JmsDestinationHelperImpl implements JmsDestinationHelper {

    public JmsDestinationHelperImpl() {
        super();
    }

    public MessageDestination getDescriptionCacheTopic() {
        return CommonMessageDestination.getDestination(CommonMessageDestination.DESCRIPTION_CACHE_TOPIC);
    }

    public MessageDestination getTableCacheTopic() {
        return CommonMessageDestination.getDestination(CommonMessageDestination.TABLE_CACHE_TOPIC);
    }

    public boolean isMessageTrackingEnabledForMessageType(String messageTypeID) {
        return CommonMessageDestination.isMessageTrackingEnabledForMessageType(messageTypeID) ||
            BaseMessageDestination.isMessageTrackingEnabledForMessageType(messageTypeID);
    }

    public String[] getSearchFields(String messageType) {
        return MessageType.getSearchFields(messageType);
    }
}
