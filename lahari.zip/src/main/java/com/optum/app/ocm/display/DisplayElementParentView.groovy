package com.optum.app.ocm.display

import com.optum.rf.bl.businesslogic.BusinessLogic
import com.optum.data.DisplayElementParentViewVO
import groovy.transform.CompileStatic

@CompileStatic
interface DisplayElementParentView extends BusinessLogic<DisplayElementParentViewVO>{

    List<DisplayElementParentViewVO> listForParent(long displayElementParentID)

    DisplayElementParentViewVO read(long displayElementID, long displayElementParentID, String... readFields)

}