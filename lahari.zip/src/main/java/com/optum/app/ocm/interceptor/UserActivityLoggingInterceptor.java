package com.optum.app.ocm.interceptor;

import com.optum.rf.web.annotation.NoUserActivityLog;
import com.optum.rf.web.log.LogCreator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * UserActivityLoggingInterceptor intercepts REST requests and logs them to the user activity log.
 * Created by skohl on 6/24/2016.
 *
 */
public class UserActivityLoggingInterceptor extends HandlerInterceptorAdapter {
    @Autowired LogCreator logCreator;
    private ThreadLocal<Long> startTime = new ThreadLocal<>();
    private static final Logger logger = LoggerFactory.getLogger( UserActivityLoggingInterceptor.class );

    @Override
    public boolean preHandle( HttpServletRequest request, HttpServletResponse response, Object handler ){
        String cleanMethod = cleanMethod(request.getMethod());
        logger.trace("preHandle( method: {}, url: {}", cleanMethod, request.getRequestURI());
        startTime.set( System.currentTimeMillis());
        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
        String cleanMethod = cleanMethod(request.getMethod());
        logger.trace("postHandle( method: {}, url: {}, object: {}) => status: {}", cleanMethod, request.getRequestURI(), handler, response.getStatus());
        Map<String, String> allParams = new HashMap<>();
        long start = System.currentTimeMillis();
        if( handler instanceof HandlerMethod){
            HandlerMethod handlerMethod = (HandlerMethod)handler;
            if( handlerMethod.getMethodAnnotation(NoUserActivityLog.class) != null ){
                logger.debug( "not performing UserActivityLogging due to presence of NoUserActivityLog annotation. method: {}, url: {}, class:{}, object:{}", cleanMethod, request.getRequestURI(), handler.getClass(), handler);
                return;
            }
            Map<String, String> urlParams = extractUrlParameters( request, handlerMethod );
            if( urlParams != null ){
                allParams.putAll( urlParams );
            }
        }else{
            logger.warn("Not sure what is being passed in. NoUserActivityLog annotation will be disabled for this request. method: {}, url: {}, class:{}, object:{}", cleanMethod, request.getRequestURI(), handler.getClass(), handler );
        }
        Map<String, String> queryParams = extractQueryVariables( request.getQueryString());
        if( queryParams != null ){
            allParams.putAll( queryParams );
        }
        logCreator.createRestLogWithNewTransaction((int) (System.currentTimeMillis() - startTime.get()), request, allParams );
        logger.debug("postHandle( method: {}, url: {}, object: {}) => status: {} :: completed in {} millis.", cleanMethod, request.getRequestURI(), handler, response.getStatus(), (System.currentTimeMillis() - start));
    }
    private Map<String, String> extractUrlParameters( HttpServletRequest request, HandlerMethod handlerMethod ){
        String requestUri = request.getRequestURI();
        RequestMapping requestMapping = handlerMethod.getMethodAnnotation( RequestMapping.class);
        for( String pattern : requestMapping.path()){
            logger.trace("looking at pattern: {}", pattern);
            Map<String, String> keyMap = extractPathVariables(requestUri, pattern);
            if( !keyMap.isEmpty()){//there may be some possibility that it gets confused by similar patterns?
                return keyMap;
            }
        }
         return null;
    }
    private Map<String, String> extractQueryVariables( String queryString ){
        logger.trace( "extractQueryVariables( queryString: {}{}", "", queryString );
        if( queryString == null || queryString.equals("")){
            return null;
        }
        String[] pairs = queryString.split( "&");
        if( pairs == null || pairs.length < 1 ){
            return null;
        }
        Map<String, String> queryVars = new HashMap<>();
        for( String pair : pairs ){
            String[] nvp = pair.split( "=");
            if( nvp.length < 2 ){
                logger.warn( "bad query string: {}{}", "",pair );
            }else{
                queryVars.put( nvp[0], nvp[1]);
        }}
        return queryVars;
    }
    private Map<String, String> extractPathVariables(String requestUri, String pattern){
        logger.trace("determineValue(replacementName: {},  requestUri: {}, pattern: {}", "", requestUri, pattern);
        Map<String, String> replacementValues = new HashMap<>();
        String[] uriParts = requestUri.split( "/");
        String[] patParts = pattern.split( "/");
        String uriPartsForLog = Arrays.toString(uriParts);
        String patPartsForLog = Arrays.toString(uriParts);
        logger.trace("{}, uriParts: {}, patParts: {}", "",uriPartsForLog, patPartsForLog);

        int uriIndex = 0;
        int patIndex = 0;
        boolean done = false;
        while( !done ){
            String patPart = patParts[ patIndex ];
            if(isValidPartLength(patParts, patIndex, patPart)){
                patIndex++;
                continue;
            }
            String uriPart = uriParts[ uriIndex ];
            if(isValidPartLength(uriParts, uriIndex, uriPart)){
                uriIndex++;
                continue;
            }
            boolean isRvar = isRvar(patPart);
            boolean match = isMatch(patPart, uriPart);

            logger.trace("isRvar: {}, match: {}, patPart: {}, uriPart: {}", isRvar, match, patPart, uriPart);
            if( isRvar ){
                logger.trace( "patPart:{}, replacementValue: {}", patPart, uriPart );
                replacementValues.put( strip( patPart ), uriPart );
            }
            if( match || isRvar ){
                patIndex++;
                uriIndex++;
            }else{
                uriIndex++;
            }
            if( patIndex >= patParts.length || uriIndex >= uriParts.length ){
                done = true;
        }}
        return replacementValues;
    }

    private boolean isMatch(String patPart, String uriPart) {
        return patPart != null && patPart.equals(uriPart);
    }

    private boolean isRvar(String patPart) {
        return patPart != null && patPart.startsWith("{");
    }

    private boolean isValidPartLength(String[] patParts, int patIndex, String patPart) {
        return patPart == null && patIndex < patParts.length - 1;
    }

    private String strip( String s ){
        return s.substring( s.indexOf( '{' ) + 1, s.indexOf( '}'));
    }

    private String cleanMethod(String message){
        String cleanMethod = "";

        if("GET".equalsIgnoreCase(message)) {
            cleanMethod = "GET";
        }else if("POST".equalsIgnoreCase(message)) {
            cleanMethod = "POST";
        }
        return cleanMethod;
    }
}
