package com.optum.app.ocm.jobs;

import com.optum.rf.common.scheduler.util.CronJobType;
import com.optum.rf.common.scheduler.util.ScheduledTask;
import com.optum.rf.common.system.util.FileCleanupTask;
import com.optum.rf.core.annotation.InjectedBean;

@InjectedBean
public class FileCleanupCronJob extends CronJobType {
    @Override
    public String getDescription() {
        return "Old File Clean Up";
    }

    @Override
    public ScheduledTask getTask() {
        return new FileCleanupTask();
    }

    @Override
    public String getCronPattern() {
        return "0 23 * * *";
    }

    @Override
    public String getSystemJobID() {
        return "FCU";
    }
}
