package com.optum.app.ocm.jms

import com.optum.app.ocm.cache.OcmCacheRefresh
import com.optum.app.ocm.ref.cache.CustomerRefFilterChildViewQueryCache
import com.optum.app.ocm.ref.cache.CustomerRefFilterCustomViewQueryCache
import com.optum.app.ocm.ref.cache.CustomerReferenceFilterChildQueryCache
import com.optum.app.ocm.ref.cache.CustomerReferenceFilterCustomQueryCache
import com.optum.app.ocm.ref.cache.CustomerReferenceQueryCache
import com.optum.app.ocm.ref.cache.CustomerReferenceReadCache
import com.optum.rf.core.message.InternalMessageDestination
import com.optum.rf.core.message.InternalMessageListener
import com.optum.rf.core.message.MessageTrackingType
import com.optum.rf.core.message.MessagingConstants
import groovy.transform.CompileStatic

@CompileStatic
enum BaseJMSMessageDestinationEnum  implements InternalMessageDestination  {

    LOCALE_STORAGE_REFERENCE_CACHE('jms/ExtCacheTopic', 'jms/TopicConnectionFactory', OcmCacheRefresh, null, false, true, false),
    CUSTOMER_REFERENCE_READ_CACHE_TOPIC('jms/ExtCacheTopic', 'jms/TopicConnectionFactory', CustomerReferenceReadCache, null, false, false, true),
    CUSTOMER_REFERENCE_QUERY_CACHE_TOPIC('jms/ExtCacheTopic', 'jms/TopicConnectionFactory', CustomerReferenceQueryCache, null, false, true, true),
    CUSTOMER_REF_FILTER_CHILD_VIEW_QUERY_CACHE_TOPIC('jms/ExtCacheTopic', 'jms/TopicConnectionFactory', CustomerRefFilterChildViewQueryCache, null, false, true, true),
    CUSTOMER_REF_FILTER_CUSTOM_VIEW_QUERY_CACHE_TOPIC('jms/ExtCacheTopic', 'jms/TopicConnectionFactory', CustomerRefFilterCustomViewQueryCache, null, false, true, true),
    CUSTOMER_REF_FILTER_CUSTOM_QUERY_CACHE_TOPIC('jms/ExtCacheTopic', 'jms/TopicConnectionFactory', CustomerReferenceFilterCustomQueryCache, null, false, true, true),
    CUSTOMER_REF_FILTER_CHILD_QUERY_CACHE_TOPIC('jms/ExtCacheTopic', 'jms/TopicConnectionFactory', CustomerReferenceFilterChildQueryCache, null, false, true, true)

    private String queueName
    private String connectionName
    private Class<? extends InternalMessageListener> targetClass
    private MessageTrackingType messageTrackingType
    private boolean messageTrackingEnabled
    private boolean persistence
    private int priority
    private String replyTo
    private boolean transactional
    private boolean publishSubscribeDestination

    BaseJMSMessageDestinationEnum(String queueName, String connectionName,
                                  Class<? extends InternalMessageListener> targetClass) {
        this(queueName, connectionName, targetClass, null, false)
    }

    BaseJMSMessageDestinationEnum(String queueName, String connectionName,
                                  Class<? extends InternalMessageListener> targetClass,
                                             MessageTrackingType messageTrackingType, boolean trackMessages) {
        this(queueName, connectionName, targetClass, messageTrackingType, trackMessages, true, false)
    }

    BaseJMSMessageDestinationEnum(String queueName, String connectionName,
                                  Class<? extends InternalMessageListener> targetClass,
                                  MessageTrackingType messageTrackingType, boolean trackMessages, boolean transactional,
                                  boolean publishSubscribeDestination) {
        this.queueName = queueName
        this.connectionName = connectionName
        this.targetClass = targetClass
        this.messageTrackingType = messageTrackingType
        this.messageTrackingEnabled = trackMessages
        this.persistence = true
        this.priority = MessagingConstants.DEFAULT_PRIORITY
        this.replyTo = null
        this.transactional = transactional
        this.publishSubscribeDestination = publishSubscribeDestination
    }

    String getQueueName() {
        return queueName
    }

    String getConnectionName() {
        return connectionName
    }

    Class<? extends InternalMessageListener> getListenerClass() {
        return targetClass
    }

    int getPriority() {
        return priority
    }

    boolean isMessageTrackingEnabled() {
        return messageTrackingEnabled
    }

    MessageTrackingType getMessageTrackingType() {
        return messageTrackingType
    }

    String getReplyTo() {
        return replyTo
    }

    boolean getPersistence() {
        return persistence
    }

    static Map<String, InternalMessageDestination> getMessageDestinationsByClassName() {
        return new HashMap<>()
    }

    boolean getTransactional() {
        return transactional
    }

    boolean getPublishSubscribeDestination() {
        return publishSubscribeDestination
    }

}