package com.optum.app.ocm.util


import com.optum.rf.bl.businesslogic.BusinessLogic

/**
 * Created by achunh on 7/23/18.
 */
interface TableFields extends BusinessLogic<com.optum.data.TableFieldsVO> {

    boolean isValid(String tableName, String fieldName)

    com.optum.data.TableFieldsVO read(String tableName, String fieldName, String ... readFields)

    List<com.optum.data.TableFieldsVO> listTableFieldsByTableName(String tableName)
}
