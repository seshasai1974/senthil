package com.optum.app.ocm.security

interface OcmSecurityConstants {

    String CUSTOMER_USER_LIST = "customerUserList"
    String REFERRER = "referrer"
    String BRANDING = "branding"
    String ASSOCIATED_CUSTOMER_TO_USER__LIST = "associatedCustomerToUserList"

}