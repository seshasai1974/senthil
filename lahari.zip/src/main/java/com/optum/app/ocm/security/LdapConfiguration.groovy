package com.optum.app.ocm.security
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer
import org.springframework.core.io.ClassPathResource
import org.springframework.core.io.FileSystemResource

@Configuration
class LdapConfiguration {

    // LDAP Configuration is externalized 
    private static final LDAP_PROPERTIES_URL_PROP = 'ldap.properties.url'

    @Bean
    public static PropertySourcesPlaceholderConfigurer getLdapPropertyConfig() {

        @SuppressWarnings("unchecked")
        List propertySources = new ArrayList<?>()
        
        // default properties will come from a known location on the classpath
        ClassPathResource defaultProperties = new ClassPathResource("/resources/ldap.properties")
        propertySources.add(defaultProperties)
        
        // get the location of the external LDAP properties file from a System Property
        FileSystemResource externalLdapProperties
        String ldapConfigProperty = System.getProperty(LDAP_PROPERTIES_URL_PROP)
        if (ldapConfigProperty) {
            URL ldapConfigUrl = new URL(ldapConfigProperty)
            println('ldapConfigURL = ' + ldapConfigUrl)
            if (ldapConfigProperty.startsWith("file:")) {
                externalLdapProperties = new FileSystemResource(ldapConfigUrl.getFile())
                propertySources.add(externalLdapProperties)
            }
        }
        println('LDAP Property Sources = ' + propertySources)

        PropertySourcesPlaceholderConfigurer pspc = new PropertySourcesPlaceholderConfigurer(
                ignoreResourceNotFound: true,
                locations: propertySources
        )
        pspc
    }
}                           
