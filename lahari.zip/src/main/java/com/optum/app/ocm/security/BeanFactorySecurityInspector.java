package com.optum.app.ocm.security;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.ListableBeanFactory;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.Controller;

import java.util.Map;

/**
 * BeanFactorySecurityInspector is a class that inspects a beanFactory for beans that are banned from that
 * factory for security reasons. If it finds a such a class it logs it and calls System.exit().
 *
 * Banned classes are:
 * - classes implementing Controller or extending a Controller
 * - classes with a class annotation of RestController
 * - classes with a class annotation of Controller
 *
 * Created by skohl on 8/23/2016.
 */
public class BeanFactorySecurityInspector implements BeanFactoryAware, ApplicationListener<ContextRefreshedEvent> {
    ListableBeanFactory beanFactory;
    private Logger logger = LoggerFactory.getLogger( BeanFactorySecurityInspector.class );
    private Class<?>[] annotations = { RestController.class, org.springframework.stereotype.Controller.class };
    private Class<?>[] classes = { Controller.class };

    @Override
    public void onApplicationEvent( ContextRefreshedEvent event ){
        boolean foundBannedClass = false;
        for( Class klass : classes ){
            Map<String, Controller> banned = beanFactory.getBeansOfType( klass );
            for( String name : banned.keySet()){
                logger.error("found banned class: " + name + " => " + banned.get(name));
                foundBannedClass = true;
        }}

        for( Class klass : annotations ){
            Map<String, Object> banned = beanFactory.getBeansWithAnnotation( klass );
            for( String name : banned.keySet()){
                logger.error("found banned class: " + name + " => " + banned.get(name));
                foundBannedClass = true;
        }}

        if( foundBannedClass ){
            System.exit( -1 );
        }
    }

    public void setBeanFactory( BeanFactory beanFactory ){
        this.beanFactory = (ListableBeanFactory)beanFactory;
    }
}