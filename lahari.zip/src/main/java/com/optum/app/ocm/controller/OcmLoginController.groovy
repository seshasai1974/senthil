package com.optum.app.ocm.controller

import com.optum.app.ocm.customCss.helper.BrandingHelper
import com.optum.app.ocm.customer.businesslogic.CustomerUserView
import com.optum.app.ocm.security.OcmSecurityConstants
import com.optum.rf.common.controller.LoginController
import com.optum.rf.common.controller.ReturnConstants
import com.optum.rf.common.security.data.UserProfileVO
import com.optum.rf.common.webservice.security.UserPermissionGroupProvider
import com.optum.rf.dao.controller.session.SessionThreadLocal
import com.optum.rf.dao.security.UserSecurity
import com.optum.rf.web.controller.response.Response
import com.uhg.app.common.constants.spclcare.FieldConstants
import com.optum.app.common.customer.data.CustomerUserViewVO
import com.optum.app.ocm.common.settings.businesslogic.ApplicationSettings
import com.optum.app.ocm.common.settings.data.ApplicationSettingsVO
import groovy.transform.CompileStatic
import org.codehaus.jettison.json.JSONArray
import org.codehaus.jettison.json.JSONObject
import org.springframework.beans.factory.annotation.Autowired
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpSession
/**
 * Login Controller that includes Application specific behavior.
 */
@CompileStatic
class OcmLoginController extends LoginController {

    @Autowired UserPermissionGroupProvider userPermissionGroupProvider
    @Autowired private ApplicationSettings applicationSettings
    @Autowired CustomerUserView customerUserView
    @Autowired BrandingHelper brandingHelper

    final void setRequiredApplicationSettings(ApplicationSettings applicationSettings) {
        this.applicationSettings = applicationSettings
    }

    @Override
    protected String setSessionAndSuccessView(HttpServletRequest request, HttpSession session, UserSecurity userSecurity) {

        // call the super method to set the standard session attributes and set the view path
        String viewPath = super.setSessionAndSuccessView(request, session, userSecurity)

        // referrer - only allows letters numbers and characters '-' '_' '/'
        if(request?.getParameter(OcmSecurityConstants.REFERRER)?.matches("^[a-zA-Z0-9\\-/_]*\$")) {
            SessionThreadLocal.getSession().setAttribute(OcmSecurityConstants.REFERRER, request?.getParameter(OcmSecurityConstants.REFERRER))
        }

        // get the current Customers that are associated with the User
        SessionThreadLocal.getSession().setAttribute(OcmSecurityConstants.CUSTOMER_USER_LIST, customerUserView.getActiveByUserID(userSecurity.getUserID()))

        // return the view path obtained from the super class
        viewPath
    }

    @Override
    protected void setSuccessResponseObjects(Response response) {
        ApplicationSettingsVO applicationSettingsVO = applicationSettings.read()
        response.addResponseObject(FieldConstants.LOCALETYPE, applicationSettingsVO.localeType)
        response.addResponseObject(FieldConstants.ENVIRONMENTID, applicationSettingsVO.environmentID)

        // permission list - temp, will remove
        UserProfileVO userProfileVO = response.getResponseObject(ReturnConstants.USERPROFILEVO) as UserProfileVO
        response.addResponseObject(ReturnConstants.PERMISSIONLIST, new JSONArray(userPermissionGroupProvider.getUserPermissionGroups(userProfileVO.getUserID())))

        // get the current Customers that are associated with the User
        Set<Integer> customerList = []
        List<CustomerUserViewVO> customerUserNameVoList = []
        for(CustomerUserViewVO vo: customerUserView.getActiveByUserID(userProfileVO.getUserID())) {
            customerList.add(vo.getCustomerID())
            customerUserNameVoList.add(vo)
        }
        response.addResponseObject(OcmSecurityConstants.CUSTOMER_USER_LIST, new JSONArray(customerList))
        response.addResponseObject(OcmSecurityConstants.ASSOCIATED_CUSTOMER_TO_USER__LIST, generateUserCustomerList(customerUserNameVoList))

        // referrer
        if(SessionThreadLocal.getSession().getAttribute(OcmSecurityConstants.REFERRER)) {
            userProfileVO.setMainMenu(SessionThreadLocal.getSession().getAttribute(OcmSecurityConstants.REFERRER) as String)
        }
    }

    /**
     * Generate JSON array based on the
     * associated customer to the user
     *
     * @param custUserList
     * @return
     */
    private JSONArray generateUserCustomerList(List<CustomerUserViewVO> custUserList) {
        StringBuilder userCustomerSb = new StringBuilder()
        userCustomerSb.append('{')
        userCustomerSb.append('\"customers\":[')
        StringBuilder customerListSb = new StringBuilder()
        for(CustomerUserViewVO vo : custUserList) {
            if(customerListSb.size() > 0) {
                customerListSb.append(',')
            }
            customerListSb.append('{')
            customerListSb.append('\"customerID\":\"').append((vo.customerID ?: '')).append('\",')
            customerListSb.append('\"customerName\":\"').append((vo.customerName ?: '')).append('\"')
            customerListSb.append('}')
        }
        userCustomerSb.append(customerListSb)
        userCustomerSb.append(']}')

        JSONObject custUserJson = new JSONObject(userCustomerSb.toString())
        JSONArray jsonArray = custUserJson.optJSONArray("customers");
        jsonArray
    }
}
