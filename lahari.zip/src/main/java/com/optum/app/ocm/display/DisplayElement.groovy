package com.optum.app.ocm.display

import com.optum.rf.bl.businesslogic.BusinessLogic
import com.optum.data.DisplayElementVO
import groovy.transform.CompileStatic

@CompileStatic
interface DisplayElement extends BusinessLogic<DisplayElementVO> {

    boolean isValid(long displayElementID)

    boolean isValid(String displayElementName)

    DisplayElementVO read(long displayElementID, String... readFields)

    DisplayElementVO read(String displayElementName)

    DisplayElementVO readCascading(long displayElementID)

}