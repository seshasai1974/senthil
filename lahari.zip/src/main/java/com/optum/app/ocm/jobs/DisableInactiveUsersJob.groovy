package com.optum.app.ocm.jobs

import com.optum.rf.common.scheduler.util.CronJobType
import com.optum.rf.common.scheduler.util.ScheduledTask
import com.optum.rf.common.system.util.DisableInactiveUsersTask

class DisableInactiveUsersJob extends CronJobType  {
    @Override
    public String getDescription() {
        return "Disable Inactive Users";
    }

    @Override
    public ScheduledTask getTask() {
        return new DisableInactiveUsersTask()
    }

    @Override
    public String getCronPattern() {
        return "0 23 * * *";
    }

    @Override
    public String getSystemJobID() {
        return "DIU";
    }
}
