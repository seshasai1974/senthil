package com.optum.app.ocm.security;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * SecurityBypassConfiguration is a class to represent the configuration of a security bypass. It is
 * consumed by the ControllerSecurityInterceptor.
 *
 * @see com.optum.app.ocm.interceptor.ControllerSecurityInterceptor
 * Created by skohl on 8/12/2016.
 */
public class SecurityBypassConfiguration {
    private final String permissionUrl;
    private final String method;
    private final Map<String, String> allowedPathVariables = new HashMap<String, String>();

    public SecurityBypassConfiguration( String method, String permissionUrl ){
        if( method == null || permissionUrl == null ){
            throw new NullPointerException( "method and permissionUrl cannot be null.");
        }
        this.method = method;
        this.permissionUrl = permissionUrl;
    }

    public SecurityBypassConfiguration addAllowedPathVariable( String pathVariable, String allowedValue ){
        allowedPathVariables.put( pathVariable, allowedValue );
        return this;
    }
    @Override
    public boolean equals(Object otherObject) {
        if (otherObject == null) {
            return false;
        }
        if (otherObject.getClass() == this.getClass()) {
            SecurityBypassConfiguration other = ((SecurityBypassConfiguration)otherObject);
            return permissionUrl.equals( other.permissionUrl ) && method.equals( other.method );
        }
        return false;
    }
    @Override
    public int hashCode(){
        return permissionUrl.hashCode() + method.hashCode();
    }
    public String getMethod() {
        return method;
    }
    public Map<String, String> getAllowedPathVariables() {
        return allowedPathVariables;
    }
    public String getPermissionUrl(){ return permissionUrl; }
}
