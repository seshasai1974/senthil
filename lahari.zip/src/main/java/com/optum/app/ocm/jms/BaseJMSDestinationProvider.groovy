package com.optum.app.ocm.jms

import com.optum.app.ocm.messaging.BaseMessageDestination
import com.optum.rf.core.message.AbstractMessageDestinationProvider
import com.optum.rf.core.message.InternalMessageDestination

class BaseJMSDestinationProvider extends AbstractMessageDestinationProvider {

    private final List<String> supportedNameList = [
            BaseMessageDestination.LOCALE_STORAGE_REFERENCE_CACHE,
            BaseMessageDestination.CUSTOMER_REFERENCE_READ_CACHE_TOPIC,
            BaseMessageDestination.CUSTOMER_REFERENCE_QUERY_CACHE_TOPIC,
            BaseMessageDestination.CUSTOMER_REF_FILTER_CHILD_VIEW_QUERY_CACHE_TOPIC,
            BaseMessageDestination.CUSTOMER_REF_FILTER_CUSTOM_VIEW_QUERY_CACHE_TOPIC,
            BaseMessageDestination.CUSTOMER_REF_FILTER_CUSTOM_QUERY_CACHE_TOPIC,
            BaseMessageDestination.CUSTOMER_REF_FILTER_CHILD_QUERY_CACHE_TOPIC
    ]

    BaseJMSDestinationProvider() {
        supportedNameList.each {
            messageDestinationMap.put(it, (InternalMessageDestination)BaseJMSMessageDestinationEnum.find { e ->
                it.equals(e.name())
            })
        }
    }
}
