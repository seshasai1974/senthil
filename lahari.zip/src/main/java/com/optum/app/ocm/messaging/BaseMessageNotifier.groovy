package com.optum.app.ocm.messaging

import com.optum.rf.core.annotation.InjectedBean

@InjectedBean
interface BaseMessageNotifier {
    
    void clearLocalStorageReferenceCache(Date date)

    void clearCustomerReferenceCache()
}