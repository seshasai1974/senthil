package com.optum.app.ocm.display

import com.optum.rf.bl.businesslogic.BusinessLogic
import com.optum.data.DisplayElementParentVO
import groovy.transform.CompileStatic

@CompileStatic
interface DisplayElementParent extends BusinessLogic<DisplayElementParentVO> {

    List<DisplayElementParentVO> listForParent(long displayElementParentID)

}