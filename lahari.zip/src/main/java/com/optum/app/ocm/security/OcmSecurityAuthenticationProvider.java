package com.optum.app.ocm.security;

import com.optum.rf.common.constants.CommonFieldConstants;
import com.optum.rf.common.constants.CommonReferenceConstants;
import com.optum.rf.common.messages.SecurityMessages;
import com.optum.rf.common.security.businesslogic.User;
import com.optum.rf.common.security.data.UserVO;
import com.optum.rf.common.util.CommonUtilities;
import com.optum.rf.core.util.Environment;
import com.optum.rf.dao.constants.SystemFieldConstants;
import com.optum.rf.dao.constants.SystemGlobalMessages;
import com.optum.rf.dao.constants.SystemSecurityConstants;
import com.optum.rf.dao.exception.UhgRuntimeException;
import com.optum.rf.dao.sql.exception.FinderException;
import org.apache.commons.lang.StringUtils;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.ldap.authentication.LdapAuthenticationProvider;
import org.springframework.security.ldap.authentication.LdapAuthenticator;
import org.springframework.security.ldap.userdetails.LdapAuthoritiesPopulator;

/**
 * Class to authenticate the user against LDAP or the database.
 *
 * Changed messages for OCM to prevent account enumeration
 */
public class OcmSecurityAuthenticationProvider extends LdapAuthenticationProvider {

    private User user;
    private Environment environment;

    public final void setRequiredUser(User user) {
        this.user = user;
    }

    public final void setRequiredEnvironment(Environment environment) {
        this.environment = environment;
    }

    public OcmSecurityAuthenticationProvider(LdapAuthenticator authenticator, LdapAuthoritiesPopulator ldapAuthoritiesPopulator) {
        super(authenticator, ldapAuthoritiesPopulator);
    }

    @Override public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        String loginId = authentication.getName();
        String passwd = authentication.getCredentials().toString();
        UserVO userVO = validateUserInApp(loginId, passwd);

        if(userVO.errorMessagesExist()) {
            throw new UhgRuntimeException(userVO);
        }

        // authenticate training user for non-prod vs. Active Directory user
        if(loginId.startsWith(SystemSecurityConstants.TRAINING_USER)) {
            authentication = validateTrainingUser(authentication, loginId, userVO);
        } else {
            authentication = super.authenticate(authentication);
        }

        // audit trail for user login
        if(authentication.isAuthenticated()) {
            updateLastLoginDate(userVO);
        }

        return authentication;
    }

    private void updateLastLoginDate(UserVO userVO) {
        userVO.setLastLoginDate(new java.sql.Date(System.currentTimeMillis()));
        try {
            this.user.updateLastLoginDate(userVO);
        } catch(FinderException ue) {
            // this can only happen if the user was deleted after retrieval and before this update
            userVO.addGlobalMessage(SecurityMessages.ERR_AUTHENTICATION_FAILED);
            throw new BadCredentialsException(CommonUtilities.getErrorString(userVO));
        }
    }

    /*
     * check if the user exists in the database before authenticating against LDAP
     */
    private UserVO validateUserInApp(String loginId, String passwd) {
        UserVO userVO = new UserVO();
        if(StringUtils.isBlank(loginId)) {
            userVO.addMessage(CommonFieldConstants.USERID, SystemGlobalMessages.ERR_REQUIRED_VALUE);
        } else if(StringUtils.isBlank(passwd)) {
            userVO.addMessage(CommonFieldConstants.PASSWORD, SystemGlobalMessages.ERR_REQUIRED_VALUE);
        } else {
            userVO = this.user.read(loginId);
            if(userVO == null) {
                userVO = new UserVO();
                userVO.addGlobalMessage(SecurityMessages.ERR_AUTHENTICATION_FAILED);
            } else if(CommonReferenceConstants.LOGIN_STATUS_DISABLED.equals(userVO.getLoginStatus()) || userVO.getUserID().startsWith(SystemSecurityConstants.SYSTEM_USER)) {
                userVO.addGlobalMessage(SecurityMessages.ERR_AUTHENTICATION_FAILED);
            }
        }
        return userVO;
    }

    private Authentication validateTrainingUser(Authentication authentication, String loginId, UserVO userVO) {
        // generic TRAINING users not allowed in production
        if(this.environment.getEnvironment() == Environment.Env.PRODUCTION) {
            userVO.addMessage(SystemFieldConstants.CHANGEUSERID, SecurityMessages.ERR_TRAINING_USER_INVALID);
            throw new UhgRuntimeException(userVO);
        }
        // valid user, create authentication to return
        return new UsernamePasswordAuthenticationToken(authentication.getPrincipal(), authentication.getCredentials(), getAuthoritiesPopulator().getGrantedAuthorities(null, loginId));
    }
}
