package com.optum.app.bcbssc.constants

import com.google.common.collect.ImmutableMap
import com.optum.mbm.membereligibility.shared.constants.ReferenceConstants
import groovy.transform.CompileStatic

@CompileStatic
class BCBSSCSpclCareConstants {
    // Provider RPN
    public static final String RPN_001 = "001"
    public static final String RPN_035 = "035"

    // Line Of Business
    public static final String LINE_OF_BUSINESS_PIX = "PIX"
    public static final String LINE_OF_BUSINESS_KIX = "KIX"

    // Network Types
    public static final String NETWORKTYPE_IE = "Blue Essentials"
    public static final String NETWORKTYPE_BE = "Blue Option Network"

}
