package com.optum.app.ast.annotation

import org.codehaus.groovy.transform.GroovyASTTransformationClass

import java.lang.annotation.ElementType
import java.lang.annotation.Retention
import java.lang.annotation.RetentionPolicy
import java.lang.annotation.Target

/**
 * Method annotation to wrap a method in a try catch to delegating calls to the WorkListDataReceiver
 * to update the Worklist tables in an efficient matter. This annotation should only be used on methods
 * that have one or more parameters. Attempting to use it any other way will result in a compiler error.
 * <p><p>
 * <em>Example usage:</em>
 * <pre>
 * class UpdateWorklistExample {
 *     {@code @}UpdateWorklist
 *     public [void or Object] processData(ValueObject vo1, ValueObject vo2) {
 *         // Something To Do
 *         // Possibly return someObject
 *     }
 * }
 * </pre>
 * which becomes:
 * <pre>
 * class UpdateWorklistExample {
 *     public [void or Object] processData(ValueObject vo1, ValueObject vo2) {
 *         if(WorklistDataThreadLocal.isActive()) {
 *             WorklistDataThreadLocal.addArgs(vo1,vo2)
 *             __UpdateWorklistASTTransformation__processData(vo1,vo2)
 *         } else {
 *             try {
 *                 WorklistDataThreadLocal.setActive()
 *                 WorklistDataThreadLocal.addArgs(vo1,vo2)
 *
 *                 Object returnObject = __UpdateWorklistASTTransformation__processData(vo1,vo2) // if void, returnObject assignment omitted
 *
 *                 WorkListDataReceiver worklistDataReceiver = ApplicationContextHolder.getBean(WorkListDataReceiver.class)
 *                 if(worklistDataReceiver != null) {
 *                     worklistDataReceiver.processData(WorklistDataThreadLocal.getArgs())
 *                 }
 *                 returnObject // if void then this is omitted
 *             } finally {
 *                 WorklistDataThreadLocal.cleanLocalData()
 *             }
 *         }
 *     }
 *
 *     public [void or Object] __UpdateWorklistASTTransformation__processData(ValueObject vo1, ValueObject vo2) {
 *         // Something to do
 *         return someObject
 *     }
 * }
 * </pre>
 *
 * @author Craig Rykal
 */
@Retention(RetentionPolicy.SOURCE)
@Target([ElementType.METHOD])
@GroovyASTTransformationClass(["UpdateWorklistASTTransformation"])
public @interface UpdateWorklist {

}

