package com.optum.app.shared.whitelabel

import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration

@Configuration
class ForbiddenWordsSubmoduleConfig {

    @Bean
    ForbiddenWordsRepo fwCustomerLevelRepo() {
        return new ForbiddenWordsRepoResource("resources/whitelabel/customer-forbidden-words/")
    }

    @Bean
    ForbiddenWordsRepo fwOrganizationLevelRepo() {
        return new ForbiddenWordsRepoResource("resources/whitelabel/organization-forbidden-words/")
    }

    @Bean
    ForbiddenWordsSubmodule forbiddenWordsSubmoduleBean(
            ForbiddenWordsRepo fwCustomerLevelRepo,
            ForbiddenWordsRepo fwOrganizationLevelRepo
    ) {
        return new ForbiddenWordsSubmodule(fwCustomerLevelRepo, fwOrganizationLevelRepo)
    }

    ForbiddenWordsSubmodule forbiddenWordsSubmoduleWithInMemoryRepos() {
        return forbiddenWordsSubmoduleBean(
                new ForbiddenWordsRepoInMemory(),
                new ForbiddenWordsRepoInMemory()
        )
    }

    ForbiddenWordsSubmodule forbiddenWordsSubmoduleWithResourceRepos() {
        return new ForbiddenWordsSubmodule(
                fwCustomerLevelRepo(),
                fwOrganizationLevelRepo()
        )
    }
}
