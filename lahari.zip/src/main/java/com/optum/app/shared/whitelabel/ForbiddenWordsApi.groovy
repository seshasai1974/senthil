package com.optum.app.shared.whitelabel

/**
 * Exposes a method to consume forbidden words, merging customer and org definitions.
 * The "Api" suffix indicates this class methods are meant to be exposed by the module.
 */
class ForbiddenWordsApi {

    private final WLCustomerService wlCustomerService
    private final ForbiddenWordsSubmodule forbiddenWordsSubmodule
    private final ForbiddenWordsMaintenanceApi forbiddenWordsMaintenanceApi

    ForbiddenWordsApi(
            WLCustomerService wlCustomerService,
            ForbiddenWordsSubmodule forbiddenWordsSubmodule,
            ForbiddenWordsMaintenanceApi forbiddenWordsMaintenanceApi
    ) {
        this.wlCustomerService = wlCustomerService
        this.forbiddenWordsSubmodule = forbiddenWordsSubmodule
        this.forbiddenWordsMaintenanceApi = forbiddenWordsMaintenanceApi
        Objects.requireNonNull(this.wlCustomerService)
        Objects.requireNonNull(this.forbiddenWordsSubmodule)
        Objects.requireNonNull(this.forbiddenWordsMaintenanceApi)
    }

    List<String> consumeForbiddenWords(Integer customerId) {
        Objects.requireNonNull(customerId)

        WLCustomerModel customerModel = wlCustomerService.getCustomerModelAuthorized(customerId)
        List<String> forbiddenWords = forbiddenWordsSubmodule.getMergedForbiddenWords(
                customerModel.customerName,
                customerModel.organizationName
        )
        forbiddenWordsMaintenanceApi.validateFWAgainstEmptyWhiteLabels(customerModel.customerName, forbiddenWords)
        return forbiddenWords
    }
}
