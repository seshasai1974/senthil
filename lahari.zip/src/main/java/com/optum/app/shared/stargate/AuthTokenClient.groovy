package com.optum.app.shared.stargate

import com.optum.rf.core.annotation.InjectedBean
import org.springframework.http.HttpHeaders

@InjectedBean
interface AuthTokenClient {

    /**
     * Build an HttpHeaders object for calling the web service including the stargate authentication
     * components.
     *
     * @return An HttpHeaders object for calling the web service.
     */
    HttpHeaders buildHeader();

}