package com.optum.app.shared.interceptor

import com.optum.app.ocm.customer.businesslogic.CustomerUserView
import com.optum.app.ocm.security.SecurityBypassConfiguration
import com.optum.app.shared.constants.MultiPayerConstants
import com.optum.rf.dao.constants.SystemSecurityConstants
import com.optum.rf.dao.security.UserSecurity
import com.optum.rf.web.controller.session.SessionException
import com.optum.rf.web.security.SecurityException
import com.optum.app.common.customer.data.CustomerUserViewVO
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.core.env.Environment
import org.springframework.http.HttpStatus
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter

import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse
import javax.servlet.http.HttpSession

class CustomerSecurityInterceptor extends HandlerInterceptorAdapter {

    private Logger logger = LoggerFactory.getLogger(CustomerSecurityInterceptor.class)

    @Autowired CustomerUserView customerUserView
    @Autowired Environment environment
    @Autowired( required = false ) private Set<SecurityBypassConfiguration> securityBypass = new HashSet<>()

    CustomerSecurityInterceptor(){
        SecurityBypassConfiguration loginDomain = new SecurityBypassConfiguration( 'GET', '/ui/referenceService/v1/locale/{locale}/reference/{referenceName}')
        loginDomain.addAllowedPathVariable( '{referenceName}', 'loginDomain')
        securityBypass.add( loginDomain )
    }

    boolean preHandle(HttpServletRequest httpRequest, HttpServletResponse response, Object handler) throws Exception {
        try {
            // check security and create the session
            HttpSession httpSession = httpRequest.getSession(false)
            validateCustomer(httpRequest, httpSession)
        } catch(SessionException sessionException) {
            logger.error('session exception for method: {}, uri: {} ', cleanMethod(httpRequest.getMethod()), cleanLogMessage(httpRequest.getRequestURI()), sessionException )
            response.sendError(HttpServletResponse.SC_UNAUTHORIZED, 'timeout')
            return false
        } catch(SecurityException sec) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN, 'forbidden')
            logger.debug('SecurityException: Returning HTTP Status {} for method {}, uri: {}', HttpServletResponse.SC_FORBIDDEN, cleanMethod(httpRequest.getMethod()), cleanLogMessage(httpRequest.getRequestURI()), sec)
            return false
        } catch(Exception ex) {
            logger.error('Caught exception while performing security check on request: {} {} ', cleanMethod(httpRequest.getMethod()), cleanLogMessage(httpRequest.getRequestURI()), ex)
            response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value())
            return false
        }

        return true
    }

    // Validates if the user has access to customer
    protected void validateCustomer(final HttpServletRequest request, final HttpSession session) throws SessionException {
        if(!session) {
            logger.error( DENY_NULLSESSION, cleanMethod(request.getMethod()), cleanLogMessage(request.getRequestURI()))
            throw new SessionException()
        }

        UserSecurity userSecurity = (UserSecurity) session.getAttribute(SystemSecurityConstants.SECURITY_OBJECT)
        if(!userSecurity) {
            logger.error( DENY_NULLUSERSEC, cleanMethod(request.getMethod()), cleanLogMessage(request.getRequestURI()))
            throw new SessionException()
        }

        List<CustomerUserViewVO> customerUsers = customerUserView.getActiveByUserID(userSecurity.getUserID())
        boolean isBcbsEnv = System.getProperty(MultiPayerConstants.APPROVAL_TYPE) == MultiPayerConstants.CUSTOMER_ID_BCBSSC.toString()

        if (!customerUsers.any { CustomerUserViewVO customerUser ->
                isBcbsEnv && customerUser.customerID == MultiPayerConstants.CUSTOMER_ID_BCBSSC ||
                !isBcbsEnv && customerUser.customerID != MultiPayerConstants.CUSTOMER_ID_BCBSSC }) {
            logger.error( DENY_NOPERMISSIONLIST, cleanMethod(request.getMethod()), cleanLogMessage(request.getRequestURI()))
            throw new SessionException()
        }
    }

    //these are public for testability and are located here to make it easy to change the message
    public static final String DENY_NULLSESSION = 'DENY - HttpSession is null in HttpController.validateSession for request: {} {}'
    public static final String DENY_NULLUSERSEC = 'DENY - HttpSession is NOT null in HttpController.validateSession, but UserSecurity IS null for request: {} {}'
    public final static String DENY_NOPERMISSIONLIST = 'DENY - user: {} access to permissionID: {} null permission list.'

    /**
     *
     * @param message
     * @return
     */
    private static String cleanLogMessage(String message){
        String cleanMessage = ''
        if(message != null) {
            cleanMessage = message.toLowerCase()
                    .replace('\n', '_').replace('\r', '_')
                    .replace('insert', ' ')
                    .replace('update', ' ')
                    .replace('delete', ' ')
        }
        return cleanMessage
    }

    /**
     *
     * @param message
     * @return
     */
    private static String cleanMethod(String message){
        String cleanMethod = ''

        if('GET'.equalsIgnoreCase(message)) {
            cleanMethod = 'GET'
        }else if('POST'.equalsIgnoreCase(message)) {
            cleanMethod = 'POST'
        }
        return cleanMethod
    }
}
