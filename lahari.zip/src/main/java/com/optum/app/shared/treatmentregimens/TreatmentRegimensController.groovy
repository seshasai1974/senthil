package com.optum.app.shared.treatmentregimens

import com.optum.app.ocm.controller.support.CommonResponse
import com.optum.app.shared.authorization.businesslogic.Authorizations
import com.optum.app.shared.diseaseTraversal.businesslogic.RegimenProcedureView
import com.optum.app.shared.diseaseTraversal.businesslogic.TreatmentRegimen
import com.optum.app.shared.diseaseTraversal.businesslogic.TreatmentRegimenVersion
import com.optum.mbm.commonlogging.annotations.MbmHttpLogger
import com.optum.rf.dao.sql.query.QueryProperties
import groovy.transform.CompileStatic
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.ResponseBody
import org.springframework.web.bind.annotation.RestController

@CompileStatic
@RestController
@RequestMapping('/customers/{customerId}/treatment-regimens')
class TreatmentRegimensController {

    @Autowired Authorizations authorizations
    @Autowired TreatmentRegimen treatmentRegimen
    @Autowired TreatmentRegimenVersion treatmentRegimenVersion
    @Autowired RegimenProcedureView regimenProcedureView

    @MbmHttpLogger
    @PostMapping(
            path = 'query',
            produces = 'application/json;v=1.0')
    @ResponseBody CommonResponse getRegimenDetail(@PathVariable int customerId, @RequestBody QueryProperties query){
        authorizations.validateCustomer(customerId)
        new CommonResponse().setEmbedded(treatmentRegimenVersion.listAndCascade(query, customerId)).setPaginationInfo(query).setTotalRecordsCount(treatmentRegimenVersion.count(query))
    }

    @MbmHttpLogger
    @DeleteMapping(
            path = '{treatmentRegimenId}',
            produces = 'application/json;v=1.0')
    @ResponseBody CommonResponse deleteTreatmentRegimen(@PathVariable int customerId, @PathVariable int treatmentRegimenId) {
        authorizations.validateCustomer(customerId)
        new CommonResponse().setEmbedded(treatmentRegimen.deleteCascading(treatmentRegimenId, customerId))
    }

    @MbmHttpLogger
    @GetMapping(
            path = '{treatmentRegimenId}',
            produces = 'application/json;v=1.0')
    @ResponseBody CommonResponse getTreatmentRegimenByID(@PathVariable int customerId, @PathVariable int treatmentRegimenId){
        authorizations.validateCustomer(customerId)
        new CommonResponse().setEmbedded(treatmentRegimen.readCascading(treatmentRegimenId, customerId))
    }

    @MbmHttpLogger
    @PostMapping(
            path = 'procedures/query',
            produces = 'application/json;v=1.0')
    @ResponseBody CommonResponse getRegimenProcedures(@PathVariable int customerId, @RequestBody QueryProperties query){
        authorizations.validateCustomer(customerId)
        new CommonResponse().setEmbedded(regimenProcedureView.listDraftOrApproved(query, customerId)).setPaginationInfo(query).setTotalRecordsCount(regimenProcedureView.countDraftOrApproved(query))
    }
}
