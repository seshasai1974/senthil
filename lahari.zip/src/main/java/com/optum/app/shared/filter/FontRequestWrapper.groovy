package com.optum.app.shared.filter

import com.optum.rf.web.util.ControllerUtilities

import javax.servlet.ServletRequest
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletRequestWrapper

class FontRequestWrapper extends HttpServletRequestWrapper {

    private final ServletRequest request

    FontRequestWrapper(HttpServletRequest request) {
        super(request)
        this.request = request
    }

    String getHeader(String name) {
        if(isFont() && ControllerUtilities.CACHE_CONTROL_HEADER.equalsIgnoreCase(name)) {
            return null
        } else if (isFont() && ControllerUtilities.PRAGMA_HEADER.equalsIgnoreCase(name)) {
            return null
        }
        return super.getHeader(name)
    }

    Enumeration<String> getHeaders(String name) {
        return super.getHeaders(name)
    }

    Enumeration<String> getHeaderNames() {
        return super.getHeaderNames()
    }

    boolean isFont() {
        request instanceof  HttpServletRequest ? ((HttpServletRequest) request).getRequestURI().contains('/fonts/') : false
    }

    boolean isHtml() {
        request instanceof  HttpServletRequest ? ((HttpServletRequest) request).getRequestURI().contains('.html') : false
    }

}
