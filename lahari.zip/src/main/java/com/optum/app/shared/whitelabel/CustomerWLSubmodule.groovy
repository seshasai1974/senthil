package com.optum.app.shared.whitelabel

import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.databind.node.ObjectNode
import com.optum.app.shared.common.messages.SpclCareMessages
import com.optum.rf.dao.exception.UhgRuntimeException

class CustomerWLSubmodule {

    private final WhiteLabelRepo customerLevelRepo
    private final WhiteLabelRepo organizationLevelRepo
    private final JsonNode emptyJsonObject = new ObjectMapper().createObjectNode()

    CustomerWLSubmodule(
            WhiteLabelRepo customerLevelRepo,
            WhiteLabelRepo organizationLevelRepo
    ) {
        this.customerLevelRepo = customerLevelRepo
        this.organizationLevelRepo = organizationLevelRepo
        Objects.requireNonNull(this.customerLevelRepo)
        Objects.requireNonNull(this.organizationLevelRepo)
    }

    Optional<JsonNode> getMergedCustomerWhiteLabels(String customerName, String organizationName) {
        def organizationWhiteLabels = organizationLevelRepo.findByName(organizationName)
        def customerWhiteLabels = customerLevelRepo.findByName(customerName)

        if (!organizationWhiteLabels.isPresent() && !customerWhiteLabels.isPresent()) {
            return Optional.empty()
        }

        def mergedWhiteLabels = merge(
                organizationWhiteLabels.orElse(emptyJsonObject) as ObjectNode,
                customerWhiteLabels.orElse(emptyJsonObject)
        )
        return Optional.of(mergedWhiteLabels)
    }

    JsonNode getWLCustomerLevelValues(String customerName) {
        return customerLevelRepo.findByName(customerName).orElseThrow {
            new UhgRuntimeException(SpclCareMessages.ERR_MISSING_CONFIGURATION_FOR("customerName " + customerName))
        }
    }

    void saveWLCustomerLevelValues(String customerName, JsonNode whiteLabels) {
        customerLevelRepo.save(customerName, whiteLabels)
    }

    Set<String> getCustomerNamesWithCustomerLevelValues() {
        return customerLevelRepo.savedNames()
    }

    JsonNode getWLOrganizationLevelValues(String organizationName) {
        return organizationLevelRepo.findByName(organizationName).orElseThrow {
            new UhgRuntimeException(SpclCareMessages.ERR_MISSING_CONFIGURATION_FOR("organizationName " + organizationName))
        }
    }

    void saveWLOrganizationLevelValues(String organizationName, JsonNode whiteLabels) {
        organizationLevelRepo.save(organizationName, whiteLabels)
    }

    Set<String> getOrganizationNamesWithOrganizationLevelValues() {
        return organizationLevelRepo.savedNames()
    }

    private static JsonNode merge(ObjectNode mainNode, JsonNode updateNode) {
        Iterator<String> fieldNames = updateNode.fieldNames()
        while (fieldNames.hasNext()) {

            String fieldName = fieldNames.next()
            JsonNode jsonChildObject = mainNode.get(fieldName)
            // if field exists and is an embedded object
            if (jsonChildObject != null && jsonChildObject.isObject()) {
                merge(jsonChildObject as ObjectNode, updateNode.get(fieldName))
            }
            else {
                // Overwrite field
                JsonNode value = updateNode.get(fieldName)
                ((ObjectNode) mainNode).replace(fieldName, value)
            }
        }

        return mainNode
    }
}
