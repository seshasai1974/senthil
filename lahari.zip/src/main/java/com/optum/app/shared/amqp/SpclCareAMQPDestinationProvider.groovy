package com.optum.app.shared.amqp

import com.optum.app.shared.messaging.SpclCareMessageDestination
import com.optum.rf.core.message.AbstractMessageDestinationProvider
import com.optum.rf.core.message.InternalMessageDestination

/**
 * This class is used to keep a reference to the existing message queues within Spcl Care
 * 
 *
 * Note: There are additional queues that Spcl Care uses but they are from the base framework.
 * These queues are specific for Spcl Care
 */
class SpclCareAMQPDestinationProvider extends AbstractMessageDestinationProvider {

    //List of queues
    private final List<String> supportedNameList = [
            SpclCareMessageDestination.AUTHORIZATION_REFRESH_QUEUE
    ]

    SpclCareAMQPDestinationProvider() {
        supportedNameList.each {
            messageDestinationMap.put(it, (InternalMessageDestination)SpclCareAMQPMessageDestinationEnum.find { e ->
                it.equals(e.name())
            })
        }
    }
}
