package com.optum.app.shared.cache

import java.util.concurrent.ConcurrentHashMap

class EntityIdCache {
    Map<String, Integer> map = new ConcurrentHashMap<>()
    private static EntityIdCache instance

    private EntityIdCache(){}

    static EntityIdCache getInstance(){
        if(instance == null){
            instance = new EntityIdCache()
        }
        return instance
    }

    boolean contains(String entityId){
        return map.containsKey(entityId)
    }

    Integer get(String entityId){
        return map.get(entityId)
    }

    void put(String entityId, Integer customerID){
        map.put(entityId, customerID)
    }
}
