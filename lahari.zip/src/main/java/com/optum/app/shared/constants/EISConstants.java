package com.optum.app.shared.constants;

public class EISConstants {
    //Key Values
    public static final String SSL_KEYSTORE_LOCATION = "ssl.keystore.location";
    public static final String SSL_KEYSTORE_PWORD = "ssl.keystore.password";
    public static final String SSL_KEY_PWORD = "ssl.key.password";

    //Env Variables
    public static final String EIS_SSL_TRUSTSTORE_LOCATION = "eis.ssl.truststore.location";
    public static final String EIS_SSL_TRUSTSTORE_PWORD = "eis.ssl.truststore.password";
    public static final String EIS_SERVER_PORT = "eis.server.port";
    public static final String EIS_TOPIC = "eis.topic";

    //User details
    public static final String USER_ID = "userId";
    public static final String USER_ROLE = "userRole";
    public static final String USER_AGENT = "userAgent";
    public static final String X_FORWARDED_FOR = "XForwardedFor";
    public static final String X_FORWARDED_PROTO = "XForwardedProto";
    public static final String REASON = "reason";

}
