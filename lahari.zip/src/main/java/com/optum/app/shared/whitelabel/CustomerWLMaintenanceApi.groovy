package com.optum.app.shared.whitelabel

import com.fasterxml.jackson.databind.JsonNode
import com.optum.app.shared.whitelabel.dto.CustomerWhiteLabelsDto
import groovy.transform.PackageScope

/**
 * Adds validation to the save methods
 * The "Api" suffix indicates this class methods are meant to be exposed by the module.
 */
class CustomerWLMaintenanceApi {

    private final WLCustomerService wlCustomerService
    private final CustomerWLSubmodule customerWLSubmodule
    private final ForbiddenWordsSubmodule forbiddenWordsSubmodule

    CustomerWLMaintenanceApi(
            WLCustomerService wlCustomerService,
            CustomerWLSubmodule customerWLSubmodule,
            ForbiddenWordsSubmodule forbiddenWordsSubmodule) {
        this.wlCustomerService = wlCustomerService
        this.customerWLSubmodule = customerWLSubmodule
        this.forbiddenWordsSubmodule = forbiddenWordsSubmodule
        Objects.requireNonNull(this.wlCustomerService)
        Objects.requireNonNull(this.customerWLSubmodule)
        Objects.requireNonNull(this.forbiddenWordsSubmodule)
    }

    JsonNode getWLCustomerLevelValues(Integer customerId) {
        Objects.requireNonNull(customerId)

        def customerName = wlCustomerService.getCustomerNameAuthorized(customerId)
        return customerWLSubmodule.getWLCustomerLevelValues(customerName)
    }

    void saveWLCustomerLevelValues(CustomerWhiteLabelsDto customerWhiteLabelsDto) {
        Objects.requireNonNull(customerWhiteLabelsDto)
        Objects.requireNonNull(customerWhiteLabelsDto.customerId)
        Objects.requireNonNull(customerWhiteLabelsDto.whiteLabels)

        WLCustomerModel customerModel = wlCustomerService.getCustomerModelAuthorized(customerWhiteLabelsDto.customerId)
        validateWhiteLabels(customerModel, customerWhiteLabelsDto.whiteLabels)

        customerWLSubmodule.saveWLCustomerLevelValues(customerModel.customerName, customerWhiteLabelsDto.whiteLabels)
    }

    Set<String> getCustomerNamesWithCustomerLevelValues() {
        return customerWLSubmodule.getCustomerNamesWithCustomerLevelValues()
    }

    JsonNode getWLOrganizationValues(Integer customerId) {
        Objects.requireNonNull(customerId)

        WLCustomerModel customerModel = wlCustomerService.getCustomerModelAuthorized(customerId)
        return customerWLSubmodule.getWLOrganizationLevelValues(customerModel.organizationName)
    }

    void saveWLOrganizationLevelValues(CustomerWhiteLabelsDto customerWhiteLabelsDto) {
        Objects.requireNonNull(customerWhiteLabelsDto)
        Objects.requireNonNull(customerWhiteLabelsDto.customerId)
        Objects.requireNonNull(customerWhiteLabelsDto.whiteLabels)

        WLCustomerModel customerModel = wlCustomerService.getCustomerModelAuthorized(customerWhiteLabelsDto.customerId)
        validateWhiteLabels(customerModel, customerWhiteLabelsDto.whiteLabels)

        customerWLSubmodule.saveWLOrganizationLevelValues(customerModel.organizationName, customerWhiteLabelsDto.whiteLabels)
    }

    Set<String> getOrganizationNamesWithOrganizationLevelValues() {
        return customerWLSubmodule.getOrganizationNamesWithOrganizationLevelValues()
    }

    @PackageScope
    void validateWhiteLabels(Integer customerId, JsonNode whiteLabels) {
        Objects.requireNonNull(customerId)
        Objects.requireNonNull(whiteLabels)

        WLCustomerModel customerModel = wlCustomerService.getCustomerModelAuthorized(customerId)
        new WhiteLabelsValidator(
                customerModel.customerName,
                whiteLabels,
                forbiddenWordsSubmodule.getMergedForbiddenWords(customerModel.customerName, customerModel.organizationName)
        ).validate()
    }

    @PackageScope
    void validateWhiteLabels(WLCustomerModel customerModel, JsonNode whiteLabels) {
        Objects.requireNonNull(customerModel)
        Objects.requireNonNull(whiteLabels)

        new WhiteLabelsValidator(
                customerModel.customerName,
                whiteLabels,
                forbiddenWordsSubmodule.getMergedForbiddenWords(customerModel.customerName, customerModel.organizationName)
        ).validate()
    }
}
