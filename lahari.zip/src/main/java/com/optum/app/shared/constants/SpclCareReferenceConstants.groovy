package com.optum.app.shared.constants

import com.optum.rf.common.constants.CommonReferenceConstants
import com.optum.rf.ref.core.annotation.Reference
import com.uhg.app.common.constants.spclcare.FieldConstants

class SpclCareReferenceConstants extends CommonReferenceConstants {
    //***********************************************************************************************
    //* This section <b>should</b> contain constants pertaining to the reference table.
    //* All other constants should be either outside of this section or in the global constants class.
    //* Any new entries into this section, isValid the code by running the ReferenceConstantsValidation program.
    //**********************************************************************************************
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_HEIGHT_IN_INCHES = '1'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_WEIGHT_IN_POUNDS = '2'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_INIT_DIAG_DATE = '3'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_PRIMARY_CANCER = '4'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_CHEMO_TRIAL_CANCER = '5'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_DISEASE_PROGRESSED = '6'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_DATE_OF_PROGRESSION = '7'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_INIT_CHNG_TREATMENT = '8'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_DISEASE_PROGRESSION = '9'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_ADVERSE_EVENTS = '10'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_TOXICITY = '11'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_MED_CONTRAINDICATION = '12'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_NON_MEDICAL_CONCERNS = '13'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_MAINT_THERAPY = '14'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_MEMBER_PHONE_NUMBER = '15'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_PLACE_OF_SERVICE = '16'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_INITIAL_TREATMENT_DATE = '17'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_SUPPORTIVE_CARE = '18'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_AUTHORIZATION_START_DATE = '20'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_URGENT_REQUEST = '21'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_URGENT_REQUEST_OUTCOME = '22'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_BACKDATING_AUTH = '23'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_BACKDATE_AUTH_JUST = '24'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_SUPPORT_HIGH_RISK = '25'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_SUPPORT_DRUG_HIGH_RISK = '26'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_CHEMO_14_DAYS = '27'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_AUTH_SUBMIT_RETRY_COUNT = '28'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_AUTH_SUBMIT_SENT_IN_ERROR_REPORT = '29'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_INITIAL_SUBMISSION_DATETIME = '30'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_AUTH_UPDATE_RETRY_COUNT = '32'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_AUTH_UPDATE_SENT_IN_ERROR_REPORT = '33'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_INITIAL_SUBMISSION_DATE = '34'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_EXPECTED_ADMISSION_DATE = '37'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_EXPECTED_DISCHARGE_DATE = '38'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_ACTUAL_ADMISSION_DATE = '39'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_ACTUAL_DISCHARGE_DATE = '40'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_SERVICE_DETAIL_TYPE = '41'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_MBM_ASSESSMENT = '42'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_AUTH_EXCEPTION = '43'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_PERFORMANCE_SCALE = '44'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_PERFORMANCE_STATUS = '45'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_TREATMENT_START_DATE = '46'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_ADDITIONAL_CLINICAL_DOCUMENT = '47'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_PROVIDER_EXCEPTION = '48'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_FIRST_LINE_THERAPY = '49'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_RADPHARMA_DRUG = '50'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_RADPHARMA_LEUPROLIDE_ACETATE = '51'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_RADPHARMA_OCTREOTIDE = '52'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_AUTHORIZATION_TYPE = '53'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_DIAGNOSIS_TYPE = '58'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_GRACE_PERIOD = '59'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_JBPM_PROCESS_ID = '60'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_BUY_AND_BILL = '61'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_SUPPORTIVE_TYPE = '62'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_SUPPORTIVE_CARE_PROCEDURE_ID = '63'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_AUTH_DURATION = '64'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_AUTH_DURATION_UNITS = '65'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_OVERALL_STATUS_ON_SUBMISSION = '66'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_OFFPATHWAY_REASON_TYPE = '67'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_OFFPATHWAY_REASON_TXT_LABEL = '68'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_INITIAL_INFUSION_QUESTION = '69'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_MSE_EXCEPTION_SELECTION = '70'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_MSK_PLACE_OF_SERVICE = '75'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_MSK_PRMY_CAUSE_CURRENT_EPISODE = '77'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_PATIENT_TYPE = '72'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_NATURE_OF_TREATMENT = '73'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_NATURE_OF_CONDITION = '74'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_DATE_RECEIVED = '80'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSC_ATTR_SURGERY_TYPE_OTHER = '81'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_IMAGE_NUMBER = '82'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSC_ATTR_MSK_TREATMENT_START_DATE = '84'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_MSK_TREATMENT_START_DATE = '84'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_SECONDARY_TYPE_OF_SURGERY = '90'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_SECONDARY_SURGERY_DATE = '91'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_METASTATIC_DISEASE= '93'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_METASTATIC_DISEASE_TYPE= '94'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSC_AUTH_ADMIN_DENIAL = '102'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSC_AUTH_ADMIN_DENIAL_REVIEW_COMMENT = '103'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSC_ATTR_ADMIN_DENIAL = '104'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSC_ATTR_PROVIDER_ADMIN_DENIAL = '107'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSC_ATTR_MEMBER_ADMIN_DENIAL = '108'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_ADDITIONAL_SERVICE_TEMPLATE = '109'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_HYPOFRACTIONATION_IND = '110'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSC_ATTR_HOME_CARE_ADMIN_DENIAL = '111'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSC_ATTR_SPLIT_DECISION_OVERALL_STATUS = '112'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSC_ATTR_AUTH_SUBMIT_RETRY_COUNT = '116'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSC_ATTR_BOOST_TECHNIQUE_IND = '117'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSC_ATTR_RULES_PROC_NOTES = '119'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSC_ATTR_FUSION_ENGINE = '120'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSC_ATTR_INNOVATIVE_PROV_NETWORK = '121'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSC_ATTR_PREFERRED_SUPPLIER = '122'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSC_ATTR_SITE_OF_CARE = '123'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSC_ATTR_PROVIDER_EXCEPTION = '124'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSC_ATTR_PREFERRED_PRODUCT = '125'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSC_ATTR_RECOMMENDED_PRODUCT = '126'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSC_ATTR_MANUFACTURE_ASSISTANCE = '127'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSC_ATTR_FUSION_PREFERRED_PROC = '128'

    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSC_ATTR_STEP_THERAPY_DRUG = '131'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSC_ATTR_PRE_DETERMINATION = '132'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSC_ATTR_DELEGATION_OF_CARE = '134'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSC_ATTR_AUTH_DOMR_STATUS = '135'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSC_ATTR_PREFERRED_PATHWAY_CLIENT = '140'


    //HscAttributeType Id to store Ae Risk
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_ANTI_EMESIS_RISK = '113'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_AE_RISK_SELECTION = '114'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_GF_RISK_SELECTION = '115'
    @Reference(name = SpclCareNonPersistedFieldConstants.HSC_ID_FORMAT_TYPE)
    public static final String HSCIDFORMATTYPE_HSC_ID_PREFIX_MED_NEC = '1'
    @Reference(name = SpclCareNonPersistedFieldConstants.HSC_ID_FORMAT_TYPE)
    public static final String HSC_ID_ZERO_PADDED_FORMAT = '2'
    @Reference(name = SpclCareNonPersistedFieldConstants.HSC_ID_FORMAT_TYPE)
    public static final String HSCIDFORMATTYPE_HSC_ID_PREFIX_NOT_MED_NEC = '3'

    @Reference(name = FieldConstants.ACTIVITYTYPE)
    public static final String ACTIVITYTYPE_AUTH_SUBMITTED = '5'
    @Reference(name = FieldConstants.ACTIVITYTYPE)
    public static final String ACTIVITYTYPE_DRAFT_AUTH_CANCELLED = '6'
    @Reference(name = FieldConstants.ACTIVITYTYPE)
    public static final String ACTIVITYTYPE_NEW_AUTH_REQ = '9'
    @Reference(name = FieldConstants.ACTIVITYTYPE)
    public static final String ACTIVITYTYPE_CLOSE_AUTHORIZATION = '36'

    @Reference(name = FieldConstants.ACTIVITYTYPE)
    public static final String ACTIVITYTYPE_PROVIDER_DECISION_COMMUNICATION_ = '29'

    @Reference(name = FieldConstants.ACTIVITYTYPE)
    public static final String ACTIVITYTYPE_RECPT_COMPLETE_CLIN_INFO = '30'
    @Reference(name = FieldConstants.ACTIVITYTYPE)
    public static final String ACTIVITYTYPE_RECPT_PARTIAL_CLIN_INFO = '31'
    @Reference(name = FieldConstants.ACTIVITYTYPE)
    public static final String ACTIVITYTYPE_UNABLE_TO_OBTN_COMPLT_CLIN_INFO = '34'
    @Reference(name = FieldConstants.ACTIVITYTYPE)
    public static final String ACTIVITYTYPE_CLINICAL_RECEIVED = '8'
    @Reference(name = FieldConstants.ACTIVITYTYPE)
    public static final String FAX_ACTIVITY_TYPE = '20'
    @Reference(name = FieldConstants.ACTIVITYTYPE)
    public static final String ACTIVITYTYPE_SERVICE_DATE = '43'
    @Reference(name = FieldConstants.ACTIVITYTYPE)
    public static final String ACTIVITYTYPE_FAILED = '44'
    @Reference(name = FieldConstants.ACTIVITYTYPE)
    public static final String ACTIVITYTYPE_ORPHANED_FAX_STATUS = '45'
    @Reference(name = FieldConstants.ACTIVITYTYPE)
    public static final String ACTIVITYTYPE_LETTER_SENT = '22'
    @Reference(name = FieldConstants.ACTIVITYTYPE)
    public static final String ACTIVITYTYPE_LOI_LETTER_SENT = '23'
    @Reference(name = FieldConstants.ACTIVITYTYPE)
    public static final String ACTIVITYTYPE_FUTURE_DATED_HSC = '46'
    @Reference(name = FieldConstants.ACTIVITYTYPE)
    public static final String ACTIVITYTYPE_FUTURE_DATED_HSC_TERMED = '47'
    @Reference(name = FieldConstants.ACTIVITYTYPE)
    public static final String ACTIVITYTYPE_NEW_INITIAL_TREATMENT_DATE = '48'
    @Reference(name = FieldConstants.ACTIVITYTYPE)
    public static final String ACTIVITYTYPE_SELECTED_PREFERRED_SGP = '50'
    @Reference(name = FieldConstants.ACTIVITYTYPE)
    public static final String ACTIVITYTYPE_SELECTED_NON_PREFERRED_SGP = '51'
    @Reference(name = FieldConstants.ACTIVITYTYPE)
    public static final String ACTIVITYTYPE_SELECTED_PREFERRED_CGP = '52'
    @Reference(name = FieldConstants.ACTIVITYTYPE)
    public static final String ACTIVITYTYPE_SHOWN_PREFERRED_CGP = '53'
    @Reference(name = FieldConstants.ACTIVITYTYPE)
    public static final String ACTIVITYTYPE_DRUG_ROUNDING_REJECTED = '54'
    @Reference(name = FieldConstants.ACTIVITYTYPE)
    public static final String ACTIVITYTYPE_SELECTED_NO_PREFERENCE_SGP = '55'
    @Reference(name = FieldConstants.ACTIVITYTYPE)
    public static final String ACTIVITYTYPE_SELECTED_PREFERRED_SUPPORTIVE = '56'
    @Reference(name = FieldConstants.ACTIVITYTYPE)
    public static final String ACTIVITYTYPE_SELECTED_NON_PREFERRED_SUPPORTIVE = '57'
    @Reference(name = FieldConstants.ACTIVITYTYPE)
    public static final String ACTIVITYTYPE_SELECTED_NO_PREFERENCE_SUPPORTIVE = '58'
    @Reference(name = FieldConstants.ACTIVITYTYPE)
    public static final String ACTIVITYTYPE_PH_CLONING_REQUEST = '73'
    @Reference(name = FieldConstants.ACTIVITYTYPE)
    public static final String ACTIVITYTYPE_PH_DUPLICATE_DECISIONED = '75'
    @Reference(name = FieldConstants.ACTIVITYTYPE)
    public static final String ACTIVITYTYPE_REVISE_REQUEST = '74'

    @Reference(name = FieldConstants.COMMUNICATIONTYPE)
    public static final String COMMUNICATION_TYPE_INBOUND = '1'
    @Reference(name = FieldConstants.COMMUNICATIONTYPE)
    public static final String COMMUNICATION_TYPE_OUTBOUND = '2'
    @Reference(name = FieldConstants.COMMUNICATIONTYPE)
    public static final String COMMUNICATION_TYPE_INTERNAL = '3'
    @Reference(name = FieldConstants.COMMUNICATIONTYPE)
    public static final String COMMUNICATION_TYPE_ADMINISTRATIVE = '4'

    @Reference(name = FieldConstants.USERSETTYPEID)
    public static final String USERSETTYPEID_TERMSOFUSE_UHC = '1'
    @Reference(name = FieldConstants.USERSETTYPEID)
    public static final String USERSETTYPEID_MSK_USER = '2'

    @Reference(name = FieldConstants.DECISIONOUTCOMETYPE)
    public static final String DECISIONOUTCOMETYPE_COVERED_APPROVED = '1'
    @Reference(name = FieldConstants.DECISIONOUTCOMETYPE)
    public static final String DECISIONOUTCOMETYPE_COVERED_DENIED = '2'
    @Reference(name = FieldConstants.DECISIONOUTCOMETYPE)
    public static final String DECISIONOUTCOMETYPE_CANCELLED = '4'
    @Reference(name = FieldConstants.DECISIONOUTCOMETYPE)
    public static final DECISIONOUTCOMETYPE_CONTACTEXTERNALPBM  = '5'
    @Reference(name = FieldConstants.DECISIONREASONTYPE)
    public static final String DECISIONREASONTYPE_TREATMENT_DUP_NOTIFICATION = '11'
    @Reference(name = FieldConstants.DECISIONREASONTYPE)
    public static final String DECISIONREASONTYPE_TREATMENT_CONSISTENT = '31'
    @Reference(name = FieldConstants.DECISIONREASONTYPE)
    public static final DECISIONREASIONTYPE_ELIGIBILITY_NOT_ESTABLISHED = '63'
    @Reference(name = FieldConstants.DECISIONREASONTYPE)
    public static final String DECISIONREASONTYPE_APPROVE_MEDICALLY_APPROPRIATE = '220'
    @Reference(name = FieldConstants.DECISIONREASONTYPE)
    public static final String DECISIONREASONTYPE_INFUSION_SITE_OF_CARE = '587'
    @Reference(name = FieldConstants.DECISIONREASONTYPE)
    public static final String DECISIONREASONTYPE_CLINICAL_ASSESSMENT_APPROVED = '593'
    @Reference(name = FieldConstants.DECISIONSUBTYPE)
    public static final String DECISIONSUBTYPE_ADMINISTRATIVE = '1'
    @Reference(name = FieldConstants.DECISIONSUBTYPE)
    public static final String DECISIONSUBTYPE_CLINICAL = '2'
    @Reference(name = FieldConstants.SERVICEDESCRIPTIONTYPE)
    public static final String SERVICEDESCRIPTIONTYPE_SCHEDULED = '1'

    @Reference(name = FieldConstants.SERVICEDETAILTYPE)
    public static final String SERVICEDETAILTYPE_PT = '24'
    @Reference(name = FieldConstants.SERVICEDETAILTYPE)
    public static final String SERVICEDETAILTYPE_OT = '20'
    @Reference(name = FieldConstants.SERVICEDETAILTYPE)
    public static final String SERVICEDETAILTYPE_ST = '32'

    @Reference(name = FieldConstants.PROCEDURECODE)
    public static final String PROCEDURECODE_ST = '92507'
    @Reference(name = FieldConstants.PROCEDURECODE)
    public static final String PROCEDURECODE_PT = '97139'
    @Reference(name = FieldConstants.PROCEDURECODE)
    public static final String PROCEDURECODE_OT = '97039'

    @Reference(name = FieldConstants.DECNCLINICALRESPCATGRYID)
    public static final Integer DECNCLINICALRESPCATGRYID_LATE_SUBMISSION = 1
    @Reference(name = FieldConstants.DECNCLINICALRESPCATGRYID)
    public static final Integer DECNCLINICALRESPCATGRYID_APPROVED = 2
    @Reference(name = FieldConstants.DECNCLINICALRESPCATGRYID)
    public static final Integer DECNCLINICALRESPCATGRYID_DENIED = 3

    @Reference(name = FieldConstants.PROCEDUREFREQUENCYTYPE)
    public static final String PROCEDUREFREQUENCYTYPE_APPROVED = '7'
    @Reference(name = FieldConstants.PROCEDUREUNITOFMEASURETYPE)
    public static final String PROCEDUREUNITOFMEASURETYPE_APPROVED = '5'
    @Reference(name = FieldConstants.UNITPERFREQUENCYCOUNT)
    public static final Integer UNITPERFREQUENCYCOUNT_APPROVED = 4

    @Reference(name = FieldConstants.EDITYPE)
    public static final String EDITYPE_AUTH_NTF_CREATE = '10'
    @Reference(name = FieldConstants.EDITYPE)
    public static final String EDITYPE_AUTH_NTF_UPDATE = '11'
    @Reference(name = FieldConstants.EDITYPE)
    public static final String EDITYPE_HSC_DETAIL = '12'
    @Reference(name = FieldConstants.EDITYPE)
    public static final String EDITYPE_HSC_SUMMARY = '13'
    @Reference(name = FieldConstants.EDITYPE)
    public static final String EDITYPE_HSC_UPDATE = '14'
    @Reference(name = FieldConstants.EDITYPE)
    public static final String EDITYPE_AUTH_REFRESH = '15'
    @Reference(name = FieldConstants.EDITYPE)
    public static final String EDITYPE_INBOUND_AUTH_REFRESH = '16'

    @Reference(name = SpclCareNonPersistedFieldConstants.SUPPORTIVE_TYPE)
    public static final String SUPPORTIVE_TYPE_ANTIEMETIC = 'AE'
    @Reference(name = SpclCareNonPersistedFieldConstants.SUPPORTIVE_TYPE)
    public static final String SUPPORTIVE_TYPE_BONE_MODIFYING = 'BM'
    @Reference(name = SpclCareNonPersistedFieldConstants.SUPPORTIVE_TYPE)
    public static final String SUPPORTIVE_TYPE_EXCEPTION = 'EX'
    @Reference(name = SpclCareNonPersistedFieldConstants.SUPPORTIVE_TYPE)
    public static final String SUPPORTIVE_TYPE_WBC_GROWTH_FACTOR = 'GF'
    @Reference(name = SpclCareNonPersistedFieldConstants.SUPPORTIVE_TYPE)
    public static final String SUPPORTIVE_TYPE_HORMONAL_AGENTS = 'HA'
    @Reference(name = SpclCareNonPersistedFieldConstants.SUPPORTIVE_TYPE)
    public static final String SUPPORTIVE_TYPE_HORMONE_RECEPTOR = 'HR'
    @Reference(name = SpclCareNonPersistedFieldConstants.SUPPORTIVE_TYPE)
    public static final String SUPPORTIVE_TYPE_PRE_MEDICATION = 'PM'
    @Reference(name = SpclCareNonPersistedFieldConstants.SUPPORTIVE_TYPE)
    public static final String SUPPORTIVE_TYPE_RADIOPHARMACEUTICAL = 'RP'
    @Reference(name = SpclCareNonPersistedFieldConstants.SUPPORTIVE_TYPE)
    public static final String SUPPORTIVE_TYPE_RBC_GROWTH_FACTORS = 'RGF'
    @Reference(name = SpclCareNonPersistedFieldConstants.SUPPORTIVE_TYPE)
    public static final String SUPPORTIVE_TYPE_SOMATOSTATIN_ANALOGS = 'SA'
    @Reference(name = SpclCareNonPersistedFieldConstants.SUPPORTIVE_TYPE)
    public static final String SUPPORTIVE_TYPE_THYROID_IMAGING_ABLATION = 'TI'

    @Reference(name = FieldConstants.MEDICATIONADMINROUTETYPE)
    public static final String ORAL_DRUGS = "01"
    @Reference(name = FieldConstants.HSCCOVERAGETYPE)
    public static final String PHARMACY_BENEFIT_COVERAGE_AUTHORIZED = "RX"

    @Reference(name = FieldConstants.BENEFITTYPEID)
    public static final String BENEFITTYPEID_MEDICAL = '1'
    @Reference(name = FieldConstants.BENEFITTYPEID)
    public static final String BENEFITTYPEID_PHARMACY = '23'

    @Reference(name = FieldConstants.CLINICALVARIABLETYPE)
    public static final String CLINICALVARIABLETYPE_SUPPORTIVE_CARE = '20'
    @Reference(name = FieldConstants.CLINICALVARIABLETYPE)
    public static final String CLINICALVARIABLETYPE_RADIOPHARMA = '63'
    @Reference(name = FieldConstants.CLINICALVARIABLETYPE)
    public static final String CLINICALVARIABLETYPE_SPECIALTYPHARMACY = '64'

    @Reference(name = SpclCareNonPersistedFieldConstants.RADIOPHARMA_DRUG_TYPE)
    public static final String RADIOPHARMA_DRUG_TYPE_RADIUM = '1'
    @Reference(name = SpclCareNonPersistedFieldConstants.RADIOPHARMA_DRUG_TYPE)
    public static final String RADIOPHARMA_DRUG_TYPE_LUTETIUM = '2'
    @Reference(name = SpclCareNonPersistedFieldConstants.RADIOPHARMA_DRUG_TYPE)
    public static final String RADIOPHARMA_DRUG_TYPE_AZEDRA = '3'

    @Reference(name = SpclCareNonPersistedFieldConstants.CONFIG_TEXT_TYPE)
    public static final String CONFIGTEXTTYPE_OPERATIONS_PHONE = '1'

    @Reference(name = SpclCareNonPersistedFieldConstants.URGENT_REQUEST_OUTCOME_TYPE)
    public static final String URGENTREQUESTOUTCOMETYPE_APPROVED_JEOPARDIZE_LIFE = '1'
    @Reference(name = SpclCareNonPersistedFieldConstants.URGENT_REQUEST_OUTCOME_TYPE)
    public static final String URGENTREQUESTOUTCOMETYPE_APPROVED_SEVERE_PAIN = '2'
    @Reference(name = SpclCareNonPersistedFieldConstants.URGENT_REQUEST_OUTCOME_TYPE)
    public static final String URGENTREQUESTOUTCOMETYPE_APPROVED_PHYSICIAN_KNOWLEDGE = '3'
    @Reference(name = SpclCareNonPersistedFieldConstants.URGENT_REQUEST_OUTCOME_TYPE)
    public static final String URGENTREQUESTOUTCOMETYPE_DENIED_NONE_OF_THE_ABOVE = '4'


    @Reference(name = SpclCareNonPersistedFieldConstants.HSC_OVERALL_STATUS_TYPE)
    public static final String HSCOVERALLSTATUSTYPE_APPROVED = '1'
    @Reference(name = SpclCareNonPersistedFieldConstants.HSC_OVERALL_STATUS_TYPE)
    public static final String HSCOVERALLSTATUSTYPE_DENIED = '2'
    @Reference(name = SpclCareNonPersistedFieldConstants.HSC_OVERALL_STATUS_TYPE)
    public static final String HSCOVERALLSTATUSTYPE_WITHDRAWN = '3'
    @Reference(name = SpclCareNonPersistedFieldConstants.HSC_OVERALL_STATUS_TYPE)
    public static final String HSCOVERALLSTATUSTYPE_PENDING_REVIEW = '4'
    @Reference(name = SpclCareNonPersistedFieldConstants.HSC_OVERALL_STATUS_TYPE)
    public static final String HSCOVERALLSTATUSTYPE_UNDER_APPEALS_REVIEW = '5'
    @Reference(name = SpclCareNonPersistedFieldConstants.HSC_OVERALL_STATUS_TYPE)
    public static final String HSCOVERALLSTATUSTYPE_RECONSIDERATION = '6'
    @Reference(name = SpclCareNonPersistedFieldConstants.HSC_OVERALL_STATUS_TYPE)
    public static final String HSCOVERALLSTATUSTYPE_DRAFT = '7'
    @Reference(name = SpclCareNonPersistedFieldConstants.HSC_OVERALL_STATUS_TYPE)
    public static final String HSCOVERALLSTATUSTYPE_EXPIRED = '8'
    @Reference(name = SpclCareNonPersistedFieldConstants.HSC_OVERALL_STATUS_TYPE)
    public static final String HSCOVERALLSTATUSTYPE_CANCELLED_DRAFT = '9'
    @Reference(name = SpclCareNonPersistedFieldConstants.HSC_OVERALL_STATUS_TYPE)
    public static final String HSCOVERALLSTATUSTYPE_SUBMISSION_NOT_REQUIRED = '10'
    @Reference(name = SpclCareNonPersistedFieldConstants.HSC_OVERALL_STATUS_TYPE)
    public static final String HSCOVERALLSTATUSTYPE_MIXED_DECISION = '12'

    @Reference(name = FieldConstants.HSCSTATUSREASONTYPE)
    public static final String HSCSTATUSREASONTYPE_APPEALS = '25'

    @Reference(name = SpclCareNonPersistedFieldConstants.ORX_STATUS)
    public static final String ORX_STATUS_APPROVED = '1'
    @Reference(name = SpclCareNonPersistedFieldConstants.ORX_STATUS)
    public static final String ORX_STATUS_IN_PROCESS = '13'
    @Reference(name = SpclCareNonPersistedFieldConstants.ORX_STATUS)
    public static final String ORX_STATUS_COMPLETED = '10'
    @Reference(name = SpclCareNonPersistedFieldConstants.ORX_STATUS)
    public static final String ORX_STATUS_DENIED = '12'
    @Reference(name = SpclCareNonPersistedFieldConstants.ORX_STATUS)
    public static final String ORX_STATUS_CONTACT_RX = '14'
    @Reference(name = SpclCareNonPersistedFieldConstants.ORX_STATUS)
    public static final String ORX_STATUS_CANCELLED = '15'
    @Reference(name = SpclCareNonPersistedFieldConstants.ORX_STATUS)
    public static final String ORX_STATUS_AWAITING_PROVIDER = '16'
    @Reference(name = SpclCareNonPersistedFieldConstants.ORX_STATUS)
    public static final String ORX_STATUS_AWAITING_MEMBER = '17'
    @Reference(name = SpclCareNonPersistedFieldConstants.ORX_STATUS)
    public static final String ORX_STATUS_PENDING_PHARMACIST_REVIEW = '18'
    @Reference(name = SpclCareNonPersistedFieldConstants.ORX_STATUS)
    public static final String ORX_STATUS_PENDING_MD_REVIEW = '19'
    @Reference(name = SpclCareNonPersistedFieldConstants.ORX_STATUS)
    public static final String ORX_STATUS_CALL_FOR_EXPLANATION = '20'


    @Reference(name = FieldConstants.PREFERREDRULEATTRIBUTETYPE)
    public static final String PREFERREDRULEATTRIBUTETYPE_STATE = '1'
    @Reference(name = FieldConstants.PREFERREDRULEATTRIBUTETYPE)
    public static final String PREFERREDRULEATTRIBUTETYPE_LOB = '2'
    @Reference(name = FieldConstants.PREFERREDRULEATTRIBUTETYPE)
    public static final String PREFERREDRULEATTRIBUTETYPE_POLICY = '3'

    @Reference(name = FieldConstants.PROVIDERPROCEDUREEXCPTATTRTYPE)
    public static final String PROVIDERPROCEDUREEXCPTATTRTYPE_LOB = '1'

    @Reference(name = FieldConstants.TREATMENTAUTHRULEEXCEPTIONTYPE)
    public static final String TREATMENTAUTHRULEEXCEPTIONTYPE_STATE = '1'
    @Reference(name = FieldConstants.TREATMENTAUTHRULEEXCEPTIONTYPE)
    public static final String TREATMENTAUTHRULEEXCEPTIONTYPE_LOB = '2'
    @Reference(name = FieldConstants.TREATMENTAUTHRULEEXCEPTIONTYPE)
    public static final String TREATMENTAUTHRULEEXCEPTIONTYPE_REGIMEN = '3'
    @Reference(name = FieldConstants.TREATMENTAUTHRULEEXCEPTIONTYPE)
    public static final String TREATMENTAUTHRULEEXCEPTIONTYPE_CUSTOM = '4'
    @Reference(name = FieldConstants.TREATMENTAUTHRULEEXCEPTIONTYPE)
    public static final String TREATMENTAUTHRULEEXCEPTIONTYPE_SUPPORTIVE = '5'
    @Reference(name = FieldConstants.TREATMENTAUTHRULEEXCEPTIONTYPE)
    public static final String TREATMENTAUTHRULEEXCEPTIONTYPE_POLICY = '6'
    @Reference(name = FieldConstants.TREATMENTAUTHRULEEXCEPTIONTYPE)
    public static final String TREATMENTAUTHRULEEXCEPTIONTYPE_BLOCK_ON_AUTH = '7'
    @Reference(name = FieldConstants.TREATMENTAUTHRULEEXCEPTIONTYPE)
    public static final String TREATMENTAUTHRULEEXCEPTIONTYPE_RADIOPHARMACEUTICAL = '8'
    @Reference(name = FieldConstants.TREATMENTAUTHRULEEXCEPTIONTYPE)
    public static final String TREATMENTAUTHRULEEXCEPTIONTYPE_BOOK_OF_BUSINESS = '10'
    @Reference(name = FieldConstants.TREATMENTAUTHRULEEXCEPTIONTYPE)
    public static final String TREATMENTAUTHRULEEXCEPTIONTYPE_REPORT_CODE = '11'
    @Reference(name = FieldConstants.TREATMENTAUTHRULEEXCEPTIONTYPE)
    public static final String TREATMENTAUTHRULEEXCEPTIONTYPE_FUNDING_TYPE = '12'

    @Reference(name = SpclCareNonPersistedFieldConstants.ERRORMAXRETRIES)
    public static final String ERROR_MAX_RETRIES = '1'

    @Reference(name = FieldConstants.PHONETYPE)
    public static final int PHONETYPE_PHONENUMBER = 1
    @Reference(name = FieldConstants.PHONETYPE)
    public static final int PHONETYPE_FAXNUMBER = 3
    @Reference(name = FieldConstants.PHONETYPE)
    public static final int ICUE_PHONETYPE_NUMBER = 14

    @Reference(name = FieldConstants.VENDORTYPEID)
    public static final String VENDORTYPEID_MBM_ID = '1'
    @Reference(name = FieldConstants.VENDORTYPEID)
    public static final String VENDORTYPEID_PAS = '2'

    @Reference(name = FieldConstants.TREATMENTGUIDELINETYPE)
    public static final String TREATMENTGUIDELINETYPE_NCCN = '1'

    @Reference(name = FieldConstants.HSCASSESSMENTSTATUSTYPE)
    public static final String HSCASSESSMENTSTATUSTYPE_NEW = '0'
    @Reference(name = FieldConstants.HSCASSESSMENTSTATUSTYPE)
    public static final String HSCASSESSMENTSTATUSTYPE_IN_PROGRESS = '1'
    @Reference(name = FieldConstants.HSCASSESSMENTSTATUSTYPE)
    public static final String HSCASSESSMENTSTATUSTYPE_CANCELLED = '2'
    @Reference(name = FieldConstants.HSCASSESSMENTSTATUSTYPE)
    public static final String HSCASSESSMENTSTATUSTYPE_COMPLETED = '3'
    @Reference(name = FieldConstants.HSCASSESSMENTSTATUSTYPE)
    public static final String HSCASSESSMENTSTATUSTYPE_INCOMPLETE = '4'
    @Reference(name = FieldConstants.HSCASSESSMENTSTATUSTYPE)
    public static final String HSCASSESSMENTSTATUSTYPE_IN_PROGRESS_PEND_SIGN = '5'

    @Reference(name = SpclCareNonPersistedFieldConstants.DECISIONVALUE)
    public static final String DEC_VALUE_YES = '1'
    @Reference(name = SpclCareNonPersistedFieldConstants.DECISIONVALUE)
    public static final String DEC_VALUE_NO = '2'
    @Reference(name = SpclCareNonPersistedFieldConstants.DECISIONVALUE)
    public static final String DEC_VALUE_UNDETERMINED = '3'
    @Reference(name = SpclCareNonPersistedFieldConstants.DECISIONVALUE)
    public static final String DEC_VALUE_STOP = '4'
    @Reference(name = SpclCareNonPersistedFieldConstants.DECISIONVALUE)
    public static final String DEC_VALUE_NEED_QUESTNARE = '5'
    @Reference(name = SpclCareNonPersistedFieldConstants.DECISIONVALUE)
    public static final String DEC_VALUE_AUTOAPPROVAL= '6'
    @Reference(name = SpclCareNonPersistedFieldConstants.DECISIONVALUE)
    public static final String DEC_VALUE_AGGREGATE_YES = '7'
    @Reference(name = SpclCareNonPersistedFieldConstants.DECISIONVALUE)
    public static final String DEC_VALUE_ADDITIONAL_INFO = '8'
    @Reference(name = SpclCareNonPersistedFieldConstants.DECISIONVALUE)
    public static final String DEC_VALUE_CONDITIONAL_NO = '13'

    @Reference(name = FieldConstants.CUSTOMTREATMENTAPPROVALTYPE)
    public static final String CUSTOMTREATMENTAPPROVALTYPE_UHC = '1'
    @Reference(name = FieldConstants.CUSTOMTREATMENTAPPROVALTYPE)
    public static final String CUSTOMTREATMENTAPPROVALTYPE_BCBS_BC = '2'

    @Reference(name = SpclCareNonPersistedFieldConstants.AUTHORIZATION_TYPE)
    public static final String AUTH_TYPE_INJECTABLE_CHEMOTHERAPY = '1'
    @Reference(name = SpclCareNonPersistedFieldConstants.AUTHORIZATION_TYPE)
    public static final String AUTH_TYPE_SUPPORTIVE_DRUGS = '2'
    @Reference(name = SpclCareNonPersistedFieldConstants.AUTHORIZATION_TYPE)
    public static final String AUTH_TYPE_RADIOPHARMACEUTICAL = '3'
    @Reference(name = SpclCareNonPersistedFieldConstants.AUTHORIZATION_TYPE)
    public static final String AUTH_TYPE_SPECIALTY_PHARMACY = '4'
    @Reference(name = SpclCareNonPersistedFieldConstants.AUTHORIZATION_TYPE)
    public static final String AUTH_TYPE_ORAL_DRUGS = '5'
    @Reference(name = SpclCareNonPersistedFieldConstants.AUTHORIZATION_TYPE)
    public static final String AUTH_TYPE_PHYSICAL_THERAPY = '6'
    @Reference(name = SpclCareNonPersistedFieldConstants.AUTHORIZATION_TYPE)
    public static final String AUTH_TYPE_SPEECH_THERAPY = '7'
    @Reference(name = SpclCareNonPersistedFieldConstants.AUTHORIZATION_TYPE)
    public static final String AUTH_TYPE_OCCUPATIONAL_THERAPY = '8'
    @Reference(name = SpclCareNonPersistedFieldConstants.AUTHORIZATION_TYPE)
    public static final String AUTH_TYPE_RADIATION_ONCOLOGY = '9'

    @Reference(name = FieldConstants.PROCCODETYPE)
    public static final String PROCCODETYPE_CPT4 = '2'
    @Reference(name = FieldConstants.PROCCODETYPE)
    public static final String PROCCODETYPE_HCPCS = '4'
    @Reference(name = FieldConstants.PROCCODETYPE)
    public static final String PROCCODETYPE_NDC = '6'

    @Reference(name = FieldConstants.TREATMENTREGIMENAPRVSTSTYPE)
    public static final String TREATMENTREGIMENAPRVSTSTYPE_DRAFT = '1'
    @Reference(name = FieldConstants.TREATMENTREGIMENAPRVSTSTYPE)
    public static final String TREATMENTREGIMENAPRVSTSTYPE_APPROVED = '2'
    @Reference(name = FieldConstants.TREATMENTREGIMENAPRVSTSTYPE)
    public static final String TREATMENTREGIMENAPRVSTSTYPE_EXPIRED = '3'

    // Member ID Type Constants
    @Reference(name = FieldConstants.MEMBERIDTYPE)
    public static final String MEMBERIDTYPE_SUBSCRIBER_ID = '1'
    @Reference(name = FieldConstants.MEMBERIDTYPE)
    public static final String MEMBERIDTYPE_MEMBER_ID = '2'
    @Reference(name = FieldConstants.MEMBERIDTYPE)
    public static final String MEMBERIDTYPE_MEMBER_ALT_ID = '3'
    @Reference(name = FieldConstants.MEMBERIDTYPE)
    public static final String MEMBERIDTYPE_SSN = '4'
    @Reference(name = FieldConstants.MEMBERIDTYPE)
    public static final String MEMBERIDTYPE_MEDICARE_NBR = '5'
    @Reference(name = FieldConstants.MEMBERIDTYPE)
    public static final String MEMBERIDTYPE_MEDICAID_RECPT_NBR = '6'
    @Reference(name = FieldConstants.MEMBERIDTYPE)
    public static final String MEMBERIDTYPE_OTHER = '7'
    @Reference(name = FieldConstants.MEMBERIDTYPE)
    public static final String MEMBERIDTYPE_CCS_PATIENT_NBR = '8'
    @Reference(name = FieldConstants.MEMBERIDTYPE)
    public static final String MEMBERIDTYPE_SUBSCRIBER_SSN = '9'
    @Reference(name = FieldConstants.MEMBERIDTYPE)
    public static final String MEMBERIDTYPE_INDIVIDUAL_ID = '10'
    @Reference(name = FieldConstants.MEMBERIDTYPE)
    public static final String MEMBERIDTYPE_ALERE_PATIENT_ID = '11'
    @Reference(name = FieldConstants.MEMBERIDTYPE)
    public static final String MEMBERIDTYPE_EXT_MEDICARE_ALT_ID = '12'
    @Reference(name = FieldConstants.MEMBERIDTYPE)
    public static final String MEMBERIDTYPE_EXT_MEMBER_ALT_ID = '13'
    @Reference(name = FieldConstants.MEMBERIDTYPE)
    public static final String MEMBERIDTYPE_EXT_OTHER_ID = '14'
    @Reference(name = FieldConstants.MEMBERIDTYPE)
    public static final String MEMBERIDTYPE_THIRD_PARTY_PORTAL_ID = '15'
    @Reference(name = FieldConstants.MEMBERIDTYPE)
    public static final String MEMBERIDTYPE_AARP_SHIP_SUB_ID = '16'
    @Reference(name = FieldConstants.MEMBERIDTYPE)
    public static final String MEMBERIDTYPE_NICE_SUFFIX = '17'
    @Reference(name = FieldConstants.MEMBERIDTYPE)
    public static final String MEMBERIDTYPE_OPTUM_TELEHEALTH_PATIENT_ID = '19'
    @Reference(name = FieldConstants.MEMBERIDTYPE)
    public static final String MEMBERIDTYPE_CSD_MEMBER_ID = '22'
    @Reference(name = FieldConstants.MEMBERIDTYPE)
    public static final String MEMBERIDTYPE_RX_MEMBER_ID = '20'
    @Reference(name = FieldConstants.MEMBERIDTYPE)
    public static final String MEMBERIDTYPE_SCRIPT_MED_PATIENT_ID = '26'
    @Reference(name = FieldConstants.MEMBERIDTYPE)
    public static final String MEMBERIDTYPE_FAMILY_LINK_ID = '21'
    @Reference(name = FieldConstants.MEMBERIDTYPE)
    public static final String MEMBERIDTYPE_CAREONE_ID = '27'
    @Reference(name = FieldConstants.MEMBERIDTYPE)
    public static final String MEMBERIDTYPE_SURROGATE_KEY = '31'
    @Reference(name = FieldConstants.MEMBERIDTYPE)
    public static final String MEMBERIDTYPE_ID_CARD_SN = '28'
    @Reference(name = FieldConstants.MEMBERIDTYPE)
    public static final String MEMBERIDTYPE_PULSE_ID = '29'
    @Reference(name = FieldConstants.MEMBERIDTYPE)
    public static final String MEMBERIDTYPE_EVI_MEMBER_ID = '32'
    @Reference(name = FieldConstants.MEMBERIDTYPE)
    public static final String MEMBERIDTYPE_ALT_ID = '33'
    @Reference(name = FieldConstants.MEMBERIDTYPE)
    public static final String MEMBERIDTYPE_SURV_SPOUSE_ID = '34'
    @Reference(name = FieldConstants.MEMBERIDTYPE)
    public static final String MEMBERIDTYPE_EMPLOYEE_ID = '35'
    @Reference(name = FieldConstants.MEMBERIDTYPE)
    public static final String MEMBERIDTYPE_XREF_ID = '36'
    @Reference(name = FieldConstants.MEMBERIDTYPE)
    public static final String MEMBERIDTYPE_FAMILY_ID = '37'
    @Reference(name = FieldConstants.MEMBERIDTYPE)
    public static final String MEMBERIDTYPE_XREF_ID_PARTITION_NUMBER = '38'
    @Reference(name = FieldConstants.MEMBERIDTYPE)
    public static final String MEMBERIDTYPE_EMPLOYER_ASSIGNED_ID = '41'
    @Reference(name = FieldConstants.MEMBERIDTYPE)
    public static final String MEMBERIDTYPE_SUBSCRIBER_SURROGATE_KEY = '43'
    @Reference(name = FieldConstants.MEMBERIDTYPE)
    public static final String MEMBERIDTYPE_LINE_OF_BUSINESS_ID = '44'

    @Reference(name = FieldConstants.CUSTOMERSETTYPEID)
    public static final String CUSTOMER_SET_TYPE_ID = '3'

    @Reference(name = FieldConstants.MEASUREMENTTYPE)
    public static final String MEASUREMENTTYPE_HEIGHT = 'HGT'
    @Reference(name = FieldConstants.MEASUREMENTTYPE)
    public static final String MEASUREMENTTYPE_WEIGHT = 'WGT'

    @Reference(name = FieldConstants.HCPCSUNITTYPE)
    public static final String HCPCSUNITTYPE_INJECTIONS = 'INJ'
    @Reference(name = FieldConstants.HCPCSUNITTYPE)
    public static final String HCPCSUNITTYPE_MILLIGRAMS = 'MG'
    @Reference(name = FieldConstants.HCPCSUNITTYPE)
    public static final String HCPCSUNITTYPE_UNITS = 'UNITS'
    @Reference(name = FieldConstants.HCPCSUNITTYPE)
    public static final String HCPCSUNITTYPE_MICROGRAMS = 'MCG'
    @Reference(name = FieldConstants.HCPCSUNITTYPE)
    public static final String HCPCSUNITTYPE_MILLILITERS = 'ML'
    @Reference(name = FieldConstants.HCPCSUNITTYPE)
    public static final String HCPCSUNITTYPE_GRAMS = 'G'
    @Reference(name = FieldConstants.HCPCSUNITTYPE)
    public static final String HCPCSUNITTYPE_VIAL = 'VIAL'

    @Reference(name = FieldConstants.PREFERREDPATHWAY)
    public static final String PREFERREDPATHWAY_ON_PATHWAY = '01'
    @Reference(name = FieldConstants.PREFERREDPATHWAY)
    public static final String PREFERREDPATHWAY_OFF_PATHWAY = '02'
    @Reference(name = FieldConstants.PREFERREDPATHWAY)
    public static final String PREFERREDPATHWAY_NO_PATHWAY = '03'

    public static final String HSC_TREATMENT_THERAPY_INITIAL = '1'
    public static final String HSC_TREATMENT_THERAPY_CONTINUATION = '2'

//    WQ Constants
    public static final String ITEMTASKTYPE_OWNERSHIP = '1'
    public static final String ITEMTASKTYPE_INITIATE_LETTER = '2'
    public static final String ITEMTASKTYPE_MD_REVIEW = '3'
    public static final String ITEMTASKTYPE_PHARMACIST_REVIEW = '4'
    public static final String ITEMTASKTYPE_REQ_INFO_ACCT_MGMT = '5'
    public static final String ITEMTASKTYPE_REQ_MISSING_INFO = '6'
    public static final String ITEMTASKTYPE_REVIEW_CASE = '7'
    public static final String ITEMTASKTYPE_FAILED_LETTER = '10'

    public static final String ITEMSTATUSTYPE_OPEN = '1'
    public static final String ITEMSTATUSTYPE_COMPLETED = '2'
    public static final String ITEMSTATUSTYPE_CANCELLED = '3'

    public static final String ITEMDESCRIPTOR_REQUESTING_PROVIDER = '11'
    public static final String ITEMDESCRIPTOR_SERVICING_PROVIDER = '12'
    public static final String ITEMDESCRIPTOR_MEMBER = '13'

    @Reference(name = FieldConstants.ASSIGNMENTDUEDATE)
    public static final String PAST_DUE = '1'
    @Reference(name = FieldConstants.ASSIGNMENTDUEDATE)
    public static final String TODAY = '2'
    @Reference(name = FieldConstants.ASSIGNMENTDUEDATE)
    public static final String TOMMORROW = '3'
    @Reference(name = FieldConstants.ASSIGNMENTDUEDATE)
    public static final String NEXT_SEVEN_DAYS = '4'

    // Anti-emetics
    @Reference(name = FieldConstants.ANTIEMETICCATEGORYUSETYPE)
    public static final String ANTIEMETICCATEGORYUSETYPE_BTNV = "1"
    @Reference(name = FieldConstants.ANTIEMETICCATEGORYUSETYPE)
    public static final String ANTIEMETICCATEGORYUSETYPE_HIGH = "2"
    @Reference(name = FieldConstants.ANTIEMETICCATEGORYUSETYPE)
    public static final String ANTIEMETICCATEGORYUSETYPE_LOW = "3"
    @Reference(name = FieldConstants.ANTIEMETICCATEGORYUSETYPE)
    public static final String ANTIEMETICCATEGORYUSETYPE_MODERATE = "4"

    public static final String TAT_PAST_DUE = '4'
    public static final String DUE_WITHIN_24_HOURS = '3'
    public static final String DUE_WITHIN_48_HOURS = '2'
    public static final String DUE_WITHIN_7_DAYS = '1'

    //Auth Stepper Location Constant
    // Dynamic Stepper Flow Constants
    @Reference(name = SpclCareNonPersistedFieldConstants.STEPPER_LOCATION)
    public static final String AUTH_STEPPER_NEW_AUTH = '0'
    @Reference(name = SpclCareNonPersistedFieldConstants.STEPPER_LOCATION)
    public static final String AUTH_STEPPER_REQUESTING_PROVIDER = '5'
    @Reference(name = SpclCareNonPersistedFieldConstants.STEPPER_LOCATION)
    public static final String AUTH_STEPPER_SERVICING_PROVIDER = '10'
    @Reference(name = SpclCareNonPersistedFieldConstants.STEPPER_LOCATION)
    public static final String AUTH_STEPPER_REQUEST_DETAILS = '15'
    @Reference(name = SpclCareNonPersistedFieldConstants.STEPPER_LOCATION)
    public static final String AUTH_STEPPER_CLINICAL_STATUS = '20'
    @Reference(name = SpclCareNonPersistedFieldConstants.STEPPER_LOCATION)
    public static final String AUTH_STEPPER_PATIENT_QUESTIONS = '22'
    @Reference(name = SpclCareNonPersistedFieldConstants.STEPPER_LOCATION)
    public static final String AUTH_STEPPER_REGIMEN = '25'
    @Reference(name = SpclCareNonPersistedFieldConstants.STEPPER_LOCATION)
    public static final String AUTH_STEPPER_ADD_ClINICAL_DOC = '27'
    @Reference(name = SpclCareNonPersistedFieldConstants.STEPPER_LOCATION)
    public static final String AUTH_STEPPER_CUSTOM_REGIMEN = '30'
    @Reference(name = SpclCareNonPersistedFieldConstants.STEPPER_LOCATION)
    public static final String AUTH_STEPPER_FUNCTIONAL_OUTCOME_MEASURES = '33'
    @Reference(name = SpclCareNonPersistedFieldConstants.STEPPER_LOCATION)
    public static final String AUTH_STEPPER_LOCATION_SUBMIT = '35'
    @Reference(name = SpclCareNonPersistedFieldConstants.STEPPER_LOCATION)
    public static final String AUTH_STEPPER_EDIT_AUTH = '40'
    @Reference(name = SpclCareNonPersistedFieldConstants.STEPPER_LOCATION)
    public static final String AUTH_STEPPER_BAR_AUTO_APPROVAL = '45'
    @Reference(name = SpclCareNonPersistedFieldConstants.STEPPER_LOCATION)
    public static final String AUTH_STEPPER_LOCATION_SUBMIT_WIHTOUT_WORKQUEUE = '50'

    // Dynamic UM Flow Constants
    @Reference(name = SpclCareNonPersistedFieldConstants.STEPPER_LOCATION)
    public static final String AUTH_STEPPER_SAVE_DECISION = '100'
    @Reference(name = SpclCareNonPersistedFieldConstants.STEPPER_LOCATION)
    public static final String AUTH_STEPPER_BACKDATE_AUTH = '125'
    @Reference(name = SpclCareNonPersistedFieldConstants.STEPPER_LOCATION)
    public static final String AUTH_STEPPER_SEND_FAX = '150'
    @Reference(name = SpclCareNonPersistedFieldConstants.STEPPER_LOCATION)
    public static final String AUTH_STEPPER_SEND_LETTER = '151'
    @Reference(name = SpclCareNonPersistedFieldConstants.STEPPER_LOCATION)
    public static final String AUTH_STEPPER_LETTER_MAILED = '152'
    @Reference(name = SpclCareNonPersistedFieldConstants.STEPPER_LOCATION)
    public static final String AUTH_STEPPER_FAX_PURGED = '153'
    @Reference(name = SpclCareNonPersistedFieldConstants.STEPPER_LOCATION)
    public static final String AUTH_STEPPER_SAVE_ASSIGNMENT = '200'
    @Reference(name = SpclCareNonPersistedFieldConstants.STEPPER_LOCATION)
    public static final String AUTH_SAVE_ACTIVITY = '250'
    @Reference(name = SpclCareNonPersistedFieldConstants.STEPPER_LOCATION)
    public static final String AUTH_STEPPER_ADD_NOTE = '300'
    @Reference(name = SpclCareNonPersistedFieldConstants.STEPPER_LOCATION)
    public static final String AUTH_STEPPER_ADD_CLINICAL_DOC_UM = '350'
    @Reference(name = SpclCareNonPersistedFieldConstants.STEPPER_LOCATION)
    public static final String AUTH_STEPPER_CLOSE_AUTH = '400'
    @Reference(name = SpclCareNonPersistedFieldConstants.STEPPER_LOCATION)
    public static final String AUTH_STEPPER_REOPEN = '401'
    @Reference(name = SpclCareNonPersistedFieldConstants.STEPPER_LOCATION)
    public static final String CANCEL_AUTH_ACTIVITY = '402'

    @Reference(name = FieldConstants.ACTIVITYRESOLUTIONREASONTYPE)
    public static final String CLINICAL_RECEIVED = '36'
    @Reference(name = FieldConstants.ACTIVITYRESOLUTIONREASONTYPE)
    public static final String SUBMITTED_STANDARD = '12'
    @Reference(name = FieldConstants.ACTIVITYRESOLUTIONREASONTYPE)
    public static final String SUBMITTED_URGENT = '13'
    @Reference(name = FieldConstants.ACTIVITYRESOLUTIONREASONTYPE)
    public static final String SAVED_AS_DRAFT = '14'
    @Reference(name = FieldConstants.ACTIVITYRESOLUTIONREASONTYPE)
    public static final String CANCELLED_BEFORE_SUBMIT = '37'
    @Reference(name = FieldConstants.ACTIVITYRESOLUTIONREASONTYPE)
    public static final String CANCELLED_NOTIFICATION_NOT_REQ = '43'


    @Reference(name = FieldConstants.ACTIVITYRESOLUTIONREASONTYPE)
    public static final String COVERAGE_DETERMINATION = '62'
    @Reference(name = FieldConstants.ACTIVITYRESOLUTIONREASONTYPE)
    public static final String RECEIVED_COMPLETE_CLINICAL_INFO = '76'
    @Reference(name = FieldConstants.ACTIVITYRESOLUTIONREASONTYPE)
    public static final String FAX_SUCCESSFUL = '87'
    @Reference(name = FieldConstants.ACTIVITYRESOLUTIONREASONTYPE)
    public static final String FAX_FAILED = '88'
    @Reference(name = FieldConstants.ACTIVITYRESOLUTIONREASONTYPE)
    public static final String BACKDATE_SERVICE_DATE = '89'
    @Reference(name = FieldConstants.ACTIVITYRESOLUTIONREASONTYPE)
    public static final String TERMINATION_SERVICE_DATE = '90'
    @Reference(name = FieldConstants.ACTIVITYRESOLUTIONREASONTYPE)
    public static final String EXTEND_SERVICE_DATE = '91'
    @Reference(name = FieldConstants.ACTIVITYRESOLUTIONREASONTYPE)
    public static final String FAILED_AFTER_RIGHT_FAX_PROCS = '92'
    @Reference(name = FieldConstants.ACTIVITYRESOLUTIONREASONTYPE)
    public static final String RIGHT_FAX_BAD_FILE = '93'
    @Reference(name = FieldConstants.ACTIVITYRESOLUTIONREASONTYPE)
    public static final String FAX_GENERATED = '128'
    @Reference(name = FieldConstants.ACTIVITYRESOLUTIONREASONTYPE)
    public static final String COVERAGE_DETERMINATION_APPV_LTR = '58'
    @Reference(name = FieldConstants.ACTIVITYRESOLUTIONREASONTYPE)
    public static final String PH_THERAPY_AUTH_SUCCESSFULLY_CLONED= '207'
    @Reference(name = FieldConstants.ACTIVITYRESOLUTIONREASONTYPE)
    public static final String PH_THERAPY_AUTH_SUCCESSFULLY_END_DATED= '212'

    @Reference(name = FieldConstants.DRUGCLASS)
    public static final String DRUG_CLASS_INFLAMMATORY_AGENTS = '14'
    @Reference(name = FieldConstants.DRUGCLASS)
    public static final String DRUG_CLASS_REVIEW_AT_LAUNCH = '21'
    @Reference(name = FieldConstants.DRUGCLASS)
    public static final String DRUG_CLASS_UNMANAGED_CODE = '74'
    @Reference(name = FieldConstants.PLANFEATURETYPE)
    public static final String PLAN_FEATURE_TYPE_INJECTABLE_MEDICATIONS_INFLAMMATORY = '000010827'
    @Reference(name = FieldConstants.PLANFEATURECATEGORYTYPE)
    public static final String PLAN_FEATURE_CATEGORY_TYPE_ASO_BUYUP = '1'
    @Reference(name = FieldConstants.PLANFEATURECATEGORYTYPE)
    public static final String PLAN_FEATURE_CATEGORY_TYPE_CIRRUS_PLAN_TYPE = '3'

    @Reference(name = FieldConstants.PROCEDURECATEGORYTYPE)
    public static final String PROCEDURECATEGORYTYPE_SPECIALTY = '1'
    @Reference(name = FieldConstants.PROCEDURECATEGORYTYPE)
    public static final String PROCEDURECATEGORYTYPE_ORAL = '2'
    @Reference(name = FieldConstants.PROCEDURECATEGORYTYPE)
    public static final String PROCEDURECATEGORYTYPE_TOPICAL = '3'
    @Reference(name = FieldConstants.PROCEDURECATEGORYTYPE)
    public static final String PROCEDURECATEGORYTYPE_INJECTABLE = '4'

    @Reference(name = FieldConstants.LINEOFBUSINESSTYPE)
    public static final String LINEOFBUSINESSTYPE_COMMERCIAL = 'C'
    @Reference(name = FieldConstants.LINEOFBUSINESSTYPE)
    public static final String LINEOFBUSINESSTYPE_EXCHANGE = 'E'

    @Reference(name = SpclCareConstants.FUNDING_ARRANGEMENT_PREFIX)
    public static final String FUNDINGARRANGEMENTPREFIX_STATE_HEALTH_PLAN = '00'

    @Reference(name = FieldConstants.FUNDINGARRANGEMENTID)
    public static final String FUNDINGARRANGEMENTID_SELF_INSURED_ASO = 'S'
    @Reference(name = FieldConstants.FUNDINGARRANGEMENTID)
    public static final String FUNDINGARRANGEMENTID_ASO_UNKNOWN_ERISA = 'B'
    @Reference(name = FieldConstants.FUNDINGARRANGEMENTID)
    public static final String FUNDINGARRANGEMENTID_ASO = 'A'
    @Reference(name = FieldConstants.FUNDINGARRANGEMENTID)
    public static final String FUNDINGARRANGEMENTID_ASO_NON_ERISA = 'N'
    @Reference(name = FieldConstants.FUNDINGARRANGEMENTID)
    public static final String FUNDINGARRANGEMENTID_FI = 'F'
    @Reference(name = FieldConstants.FUNDINGARRANGEMENTID)
    public static final String FUNDINGARRANGEMENTID_ALL = 'L'
    @Reference(name = FieldConstants.FUNDINGARRANGEMENTID)
    public static final String FUNDINGARRANGEMENTID_EXCESSIVE_RISK = 'R'
    @Reference(name = FieldConstants.FUNDINGARRANGEMENTID)
    public static final String FUNDINGARRANGEMENTID_UNKNOWN = 'U'
    
    public static final List<String> FUNDINGARRANGEMENTID_FI_LIST = [FUNDINGARRANGEMENTID_FI,
                                                                     FUNDINGARRANGEMENTID_ALL,
                                                                     FUNDINGARRANGEMENTID_EXCESSIVE_RISK,
                                                                     FUNDINGARRANGEMENTID_UNKNOWN]
    
    public static final List<String> FUNDINGARRANGEMENTID_ASO_LIST = [FUNDINGARRANGEMENTID_SELF_INSURED_ASO,
                                                                      FUNDINGARRANGEMENTID_ASO_UNKNOWN_ERISA,
                                                                      FUNDINGARRANGEMENTID_ASO,
                                                                      FUNDINGARRANGEMENTID_ASO_NON_ERISA]

    @Reference(name = FieldConstants.ERISATYPID)
    public static final String ERISATYPEID_NON_ERISA = '0'
    @Reference(name = FieldConstants.ERISATYPID)
    public static final String ERISATYPEID_ERISA = '1'

    public static final String REF_NAME_MBR_APPV_LTR = 'mbrappvletter'
    public static final String REF_NAME_PROV_APPV_LTR = 'provappvletter'

    @Reference(name = SpclCareNonPersistedFieldConstants.LETTER_STATUS)
    public static final String LETTER_STATUS_VIEWABLE = '3'
    @Reference(name = SpclCareNonPersistedFieldConstants.LETTER_STATUS)
    public static final String LETTER_STATUS_SUCCESS = '4'
    @Reference(name = SpclCareNonPersistedFieldConstants.LETTER_STATUS)
    public static final String LETTER_STATUS_USPS_CONF= '5'

    @Reference(name = SpclCareNonPersistedFieldConstants.INSURANCE_SUB_TYPE)
    public static final String INSURANCE_SUB_TYPE_EXCHANGE = '1'
    @Reference(name = SpclCareNonPersistedFieldConstants.INSURANCE_SUB_TYPE)
    public static final String INSURANCE_SUB_TYPE_PREMIUM_COMMERCIAL = '2'
    @Reference(name = SpclCareNonPersistedFieldConstants.INSURANCE_SUB_TYPE)
    public static final String INSURANCE_SUB_TYPE_STANDARD_COMMERCIAL= '3'

    // EX - exchange, NA - national alliance, BC - commercial, SH - Commercial

    @Reference(name = SpclCareNonPersistedFieldConstants.INSURANCE_CARRIER_TYPE_CODE)
    public static final String CARRIER_TYPE_EXCHANGE = 'EX'
    @Reference(name = SpclCareNonPersistedFieldConstants.INSURANCE_CARRIER_TYPE_CODE)
    public static final String CARRIER_TYPE_NATIONAL_ALLIANCE = 'NA'
    @Reference(name = SpclCareNonPersistedFieldConstants.INSURANCE_CARRIER_TYPE_CODE)
    public static final String CARRIER_TYPE_STANDARD_COMMERCIAL_SH = 'SH'
    @Reference(name = SpclCareNonPersistedFieldConstants.INSURANCE_CARRIER_TYPE_CODE)
    public static final String CARRIER_TYPE_STANDARD_COMMERCIAL_BC = 'BC'

    @Reference(name = FieldConstants.SOURCEAPPLICATIONTYPE)
    public static final String SOURCEAPPLICATIONTYPE_PAAN = '25'
    @Reference(name = FieldConstants.SOURCEAPPLICATIONTYPE)
    public static final String SOURCEAPPLICATIONTYPE_NPI_REGISTRY = '35'
    @Reference(name = FieldConstants.SOURCEAPPLICATIONTYPE)
    public static final String SOURCEAPPLICATIONTYPE_NDB = '36'
    @Reference(name = FieldConstants.SOURCEAPPLICATIONTYPE)
    public static final String SOURCEAPPLICATIONTYPE_BCBS_SC = '37'
    @Reference(name = FieldConstants.SOURCEAPPLICATIONTYPE)
    public static final String SOURCEAPPLICATIONTYPE_DATALAKE = '38'

    @Reference(name = FieldConstants.VERSIONSTATUSTYPE)
    public static final String VERSION_STATUS_DEPLOYED = '1'
    @Reference(name = FieldConstants.VERSIONSTATUSTYPE)
    public static final String VERSION_STATUS_APPROVED = '2'
    @Reference(name = FieldConstants.VERSIONSTATUSTYPE)
    public static final String VERSION_STATUS_DRAFT = '3'
    @Reference(name = FieldConstants.VERSIONSTATUSTYPE)
    public static final String VERSION_STATUS_LOCKED = '4'
    @Reference(name = FieldConstants.VERSIONSTATUSTYPE)
    public static final String VERSION_STATUS_RETIRED = '5'
    @Reference(name = FieldConstants.VERSIONSTATUSTYPE)
    public static final String VERSION_STATUS_INACTIVE = '6'
    @Reference(name = FieldConstants.VERSIONSTATUSTYPE)
    public static final String VERSION_STATUS_ERROR = '7'

    public static final List<String> VERSIONSTATUSTYPE_LIST = [VERSION_STATUS_DRAFT,
                                                               VERSION_STATUS_LOCKED,
                                                               VERSION_STATUS_ERROR]

    @Reference(name = FieldConstants.VERSIONSTATUSSUBTYPE)
    public static final String VERSION_STATUS_SUBTYPE_IMPORTING = '1'
    @Reference(name = FieldConstants.VERSIONSTATUSSUBTYPE)
    public static final String VERSION_STATUS_SUBTYPE_LINKING = '2'
    @Reference(name = FieldConstants.VERSIONSTATUSSUBTYPE)
    public static final String VERSION_STATUS_DATA_CLEARED = '3'
    @Reference(name = FieldConstants.VERSIONSTATUSSUBTYPE)
    public static final String VERSION_STATUS_VALIDATION = '4'

    @Reference(name = FieldConstants.CUSTOMERSETTYPEID)
    public static final String CUSTOMER_SET_TYPE_SSO_SOURCE_APPS = '1'
    @Reference(name = FieldConstants.CUSTOMERSETTYPEID)
    public static final String CUSTOMER_SET_TYPE_SSO_SOURCE_ID = '2'

    @Reference(name = SpclCareNonPersistedFieldConstants.SPECIALTY_PHARMA_DIAGNOSIS_TYPE)
    public static final String SPECIALTY_PHARMA_DIAGNOSIS_TYPE_OTHER = '142'

    @Reference(name = FieldConstants.GROWFACFEBNEUTRORISK)
    public static final String GROW_FAC_FEB_NEUTRO_RISK_HIGH = '01'

    @Reference(name = SpclCareNonPersistedFieldConstants.CUSTOM_REQUEST_REASON_TYPE)
    public static final String MEMBER_POLICY_EXCEPTION = '13'

    @Reference(name = SpclCareNonPersistedFieldConstants.CUSTOM_REQUEST_REASON_TYPE)
    public static final String BAR_PROVIDER_EXCEPTION = '15'

    @Reference(name = SpclCareNonPersistedFieldConstants.CUSTOM_REQUEST_REASON_TYPE)
    public static final String DRUG_EXCEPTION = '12'

    @Reference(name = SpclCareNonPersistedFieldConstants.CUSTOM_REQUEST_REASON_TYPE)
    public static final String CLINICAL_STATUS_EXCEPTION = '19'

    @Reference(name = SpclCareNonPersistedFieldConstants.CUSTOM_REQUEST_REASON_TYPE)
    public static final String REVIEW_AT_LAUNCH_EXCEPTION = '22'

    @Reference(name = SpclCareNonPersistedFieldConstants.CUSTOM_REQUEST_REASON_TYPE)
    public static final String MSE_PROVIDER_EXCEPTION = '16'

    @Reference(name = SpclCareNonPersistedFieldConstants.CUSTOM_REQUEST_REASON_TYPE)
    public static final String PREFERRED_SUPPLIER_NOT_SELECTED = '59'

    @Reference(name = SpclCareNonPersistedFieldConstants.CUSTOM_REQUEST_REASON_TYPE)
    public static final String OTHER_EXCEPTION = '11'

    @Reference(name = SpclCareNonPersistedFieldConstants.CUSTOM_REQUEST_REASON_TYPE)
    public static final String NO_TECHNIQUE_FOUND = '50'

    @Reference(name = SpclCareNonPersistedFieldConstants.CUSTOM_REQUEST_REASON_TYPE)
    public static final String CREATED_CUSTOM_TECHNIQUE = '51'

    @Reference(name = SpclCareNonPersistedFieldConstants.CUSTOM_REQUEST_REASON_TYPE)
    public static final String NON_AUTO_APPROVED_TECHNIQUE = '52'

    @Reference(name = SpclCareNonPersistedFieldConstants.CUSTOM_REQUEST_REASON_TYPE)
    public static final String SELECTED_NO_TECHNIQUE_ADD_ON_SERVICES = '54'

    @Reference(name = SpclCareNonPersistedFieldConstants.CUSTOM_REQUEST_REASON_TYPE)
    public static final String AUTO_REASON_DECISION = '56'

    @Reference(name = SpclCareNonPersistedFieldConstants.CUSTOM_REQUEST_REASON_TYPE)
    public static final String NON_PRE_DRUG_ROUTE_FORMULATION = '60'

    @Reference(name = FieldConstants.SYSTEMTYPE)
    public static final String SYSTEMTYPE_NICE = "13"
    @Reference(name = FieldConstants.SYSTEMTYPE)
    public static final String SYSTEMTYPE_UHCISL = "23"

    @Reference(name = SpclCareNonPersistedFieldConstants.RULE_OUTCOME_ACTION)
    public static final String ALLOW_AUTH = '1'

    @Reference(name = SpclCareNonPersistedFieldConstants.RULE_OUTCOME_ACTION)
    public static final String BLOCK_AUTH = '2'

    @Reference(name = SpclCareNonPersistedFieldConstants.RULE_OUTCOME_ACTION)
    public static final String NOTIFY_AUTH = '3'

    public static final String CUSTOMERSETTINGSTYPEID_ENTITY_ID= "3"

    public static final String TRANSITION_MTB_START_VALUE = '119'

    public static final String TRANSITION_MTB_END_VALUE = '124'

    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_PRIMARY_PROVIDER_CREDENTIAL = '76'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_PRIMARY_CAUSE_OF_CURRENT_EPISODE = '77'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String HSCATTRIBUTETYPE_SECONDARY_PROVIDER_CREDENTIAL = '88'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String   HSCATTRIBUTETYPE_SECONDARY_CAUSE_OF_CURRENT_EPISODE = '89'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String  HSCATTRIBUTETYPE_SURGERY_DATE = '79'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String  HSCATTRIBUTETYPE_SURGERY_TYPE = '78'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String  HSCATTRIBUTETYPE_REASON_FOR_LATE_SUBMISSION = '83'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String  HSCATTRIBUTETYPE_LATE_SUBMISSION_NOTE_INCLUDED = '100'
    @Reference(name = FieldConstants.HSCATTRIBUTETYPE)
    public static final String  HSCATTRIBUTETYPE_OUTBOUND_SYSTEM = '99'

    public static final String NICE_MEMBER_DERIVED_RISK_TYPE='D'

    public static final int PROVIDER_BLOCKING_CUST_REASON_STATE = 47
    public static final int PROVIDER_BLOCKING_CUST_REASON_ACN = 46
    public static final int PROVIDER_BLOCKING_CUST_REASON_ZERO_PEN = 48

    public static final int MEMBER_BLOCKING_CUST_REASON_NOT_ELIGIBILE = 41
    public static final int MEMBER_BLOCKING_CUST_REASON_HOME_CARE = 43
    public static final int MEMBER_BLOCKING_CUST_REASON_NICE_CAPITATED = 44

    public static final int ADMIN_DENIAL_PRI_RESP_FOR_LATE_SUBMISSION = 19
    public static final int ADMIN_DENIAL_SEC_RESP_FOR_LATE_SUBMISSION = 31
    public static final int ADMIN_DENIAL_PRI_RESP_FOR_LATE_COMPLETELY = 49
    public static final int ADMIN_DENIAL_SEC_RESP_FOR_LATE_COMPLETELY = 79
    public static final int PROVIDER_BLOCKING_PRI_RESP_STATE = 74
    public static final int PRI_RESP_MEMBER_CAPITATION_AGREEMENT = 126
    public static final int HOME_CARE_SUB_NOT_REQUIRED = 129
    public static final int PRI_RESP_ACN_PROVIDER = 127
    public static final int PRI_RESP_ZERO_PENALTY = 128
    public static final int PRI_RESP_MEMBER_OUT_OF_SCOPE = 125
    public static final int NO_TECHNIQUE = 50
    public static final int CREATED_CUSTOM = 51

    public static final String PLACE_OF_SERVICE_HOME_CARE = '12'
    @Reference(name = SpclCareNonPersistedFieldConstants.SUBMITRETRYWAITTIME)
    public static final String SUBMIT_RETRY_WAIT_TIME = '1'
    @Reference(name = SpclCareNonPersistedFieldConstants.MAXSUBMITRETRYCOUNT)
    public static final String MAX_SUBMIT_RETRY_COUNT = '1'

    public static final String MIN_SUBMIT_RETRY_COUNT = '0'
    public static final String HSC_OUTBOUND_STATUS_TYPE_PENDING = '1'
    public static final String HSC_OUTBOUND_STATUS_TYPE_IN_PROGRESS = '2'
    public static final String HSC_OUTBOUND_STATUS_TYPE_COMPLETE = '3'
    public static final String HSC_OUTBOUND_STATUS_TYPE_FAILED = '4'
    public static final String HSC_OUTBOUND_STATUS_TYPE_CANCELED = '5'
    public static final String HSC_OUTBOUND_SYS_TYPE_ACCREDO = '1'
    public static final String HSC_OUTBOUND_SYS_TYPE_CAREMARK = '2'
    public static final String HSC_OUTBOUND_SYS_TYPE_OPTUMPHARMACY = '3'
    public static final String HSC_OUTBOUND_SYS_TYPE_OPTIONCARE = '4'
    public static final String HSC_OUTBOUND_SYS_TYPE_OPTUM_INFUSION = '5'
    public static final String HSC_OUTBOUND_SYS_TYPE_ORSINI = '6'
    public static final String HSC_OUTBOUND_SYS_TYPE_EVERSANA = '7'
    public static final String HSC_OUTBOUND_SYS_TYPE_US_BIOSERVICES = '8'
    public static final String HSC_OUTBOUND_SYS_TYPE_ALIANCERXWAL = '9'
    public static final String HSC_OUTBOUND_SYS_TYPE_PANTHERXSP = '10'
    public static final String HSC_OUTBOUND_SYS_TYPE_KROGER = '11'

    public static final String TCOC_METRICS_CUSTOMERS = 'TcocMetrics.Customers'

    @Reference(name = FieldConstants.CLAIMSTATUS)
    public static final String CLAIM_STATUS_PAID = '1'

    @Reference(name = FieldConstants.DOSAGETYPE)
    public static final String DOSAGE_TYPE_INITIAL = '1'
    @Reference(name = FieldConstants.DOSAGETYPE)
    public static final String DOSAGE_TYPE_MAX = '2'

    @Reference(name = FieldConstants.BENEFITINDICATOR)
    public static final String BENEFIT_INDICATOR_MEDICAL = '1'
    @Reference(name = FieldConstants.BENEFITINDICATOR)
    public static final String BENEFIT_INDICATOR_PHARMACY = '2'
    @Reference(name = FieldConstants.BENEFITINDICATOR)
    public static final String BENEFIT_INDICATOR_MEDICAL_PHARMACY = '3'
}
