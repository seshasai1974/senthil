package com.optum.app.shared.whitelabel

import com.optum.app.common.organization.data.OrganizationVO
import com.optum.app.ocm.customer.businesslogic.Customer
import com.optum.app.ocm.organization.businesslogic.Organization
import com.optum.app.shared.authorization.businesslogic.Authorizations
import com.optum.app.shared.common.controller.advice.BadRequestException
import com.optum.app.shared.common.messages.SpclCareMessages
import com.optum.app.common.customer.data.CustomerVO
import com.optum.rf.dao.sql.query.QueryProperties

class WLCustomerService {

    private final Authorizations authorizations
    private final Customer customer
    private final Organization organization

    WLCustomerService(Authorizations authorizations, Customer customer, Organization organization) {
        this.authorizations = authorizations
        this.customer = customer
        this.organization = organization
        Objects.requireNonNull(this.authorizations)
        Objects.requireNonNull(this.customer)
        Objects.requireNonNull(this.organization)
    }

    String getCustomerNameAuthorized(Integer customerId) {
        Objects.requireNonNull(customerId)

        authorizations.validateCustomer(customerId)
        CustomerVO customerVO = getCustomerVOWithoutAuthCheck(customerId)
        return customerVO.customerName
    }

    WLCustomerModel getCustomerModelAuthorized(Integer customerId) {
        Objects.requireNonNull(customerId)

        authorizations.validateCustomer(customerId)
        return getCustomerModelWithoutAuthCheck(customerId)
    }

    List<WLCustomerModel> customerModelListWithoutAuthCheck() {
        return customer.list(new QueryProperties()).collect { getCustomerModelWithoutAuthCheck(it.customerID) }
    }

    WLCustomerModel getCustomerModelWithoutAuthCheck(Integer customerId) {
        Objects.requireNonNull(customerId)

        CustomerVO customerVO = getCustomerVOWithoutAuthCheck(customerId)
        OrganizationVO organizationVO = organization.read(customerVO.organizationID)

        Objects.requireNonNull(organizationVO)
        Objects.requireNonNull(organizationVO.organizationShortName)

        return new WLCustomerModel(
                customerName: customerVO.customerName,
                organizationName: organizationVO.organizationShortName,
                customerId: customerId
        )
    }

    private CustomerVO getCustomerVOWithoutAuthCheck(Integer customerId) {
        Objects.requireNonNull(customerId)

        CustomerVO customerVO = customer.read(customerId)
        if (customerVO == null) {
            throw new BadRequestException(SpclCareMessages.ERR_INVALID_CUSTOMER)
        } else {
            return customerVO
        }
    }

}
