package com.optum.app.shared.amqp


import com.optum.app.shared.authorization.amqp.AuthRefreshListener
import com.optum.rf.core.message.InternalMessageDestination
import com.optum.rf.core.message.InternalMessageListener
import com.optum.rf.core.message.MessageTrackingType
import com.optum.rf.core.message.MessagingConstants

/**
 * Created by jrescsa on 12/14/2017.
 */
enum SpclCareAMQPMessageDestinationEnum implements InternalMessageDestination  {

    AUTHORIZATION_REFRESH_QUEUE('refreshAuthQueue', 'refreshAuthQueue', AuthRefreshListener, null, false, true, false)

    private final String queueName
    private final String connectionName
    private final Class<? extends InternalMessageListener> targetClass
    private final MessageTrackingType messageTrackingType
    private final boolean messageTrackingEnabled
    private final boolean persistence
    private final int priority
    private final String replyTo
    private final boolean transactional
    private final boolean publishSubscribeDestination

    SpclCareAMQPMessageDestinationEnum(String queueName, String connectionName,
                                   Class<? extends InternalMessageListener> targetClass) {
        this(queueName, connectionName, targetClass, null, false, true, false)
    }

    SpclCareAMQPMessageDestinationEnum(String queueName, String connectionName,
                                   Class<? extends InternalMessageListener> targetClass,
                                   MessageTrackingType messageTrackingType, boolean trackMessages) {
        this(queueName, connectionName, targetClass, messageTrackingType, trackMessages, true, false)
    }

    SpclCareAMQPMessageDestinationEnum(String queueName, String connectionName,
                                   Class<? extends InternalMessageListener> targetClass,
                                   MessageTrackingType messageTrackingType, boolean trackMessages,
                                   boolean transactional,
                                   boolean publishSubscribeDestination) {
        // application prefix is used to enable multiple application instances to use the same AMQP server
        String applicationPrefix = System.getProperty(MessagingConstants.MQ_APPL_PREFIX, '')

        this.queueName = applicationPrefix ? applicationPrefix + queueName : queueName
        this.connectionName = applicationPrefix ? applicationPrefix + connectionName : connectionName
        this.targetClass = targetClass
        this.messageTrackingType = messageTrackingType
        this.messageTrackingEnabled = trackMessages
        this.persistence = true
        this.priority = MessagingConstants.DEFAULT_PRIORITY
        this.replyTo = null
        this.transactional = transactional
        this.publishSubscribeDestination = publishSubscribeDestination
    }

    String getQueueName() {
        return queueName
    }

    String getConnectionName() {
        return connectionName
    }

    Class<? extends InternalMessageListener> getListenerClass() {
        return targetClass
    }

    int getPriority() {
        return priority
    }

    boolean isMessageTrackingEnabled() {
        return messageTrackingEnabled
    }

    MessageTrackingType getMessageTrackingType() {
        return messageTrackingType
    }

    String getReplyTo() {
        return replyTo
    }

    boolean getPersistence() {
        return persistence
    }

    static Map<String, InternalMessageDestination> getMessageDestinationsByClassName() {
        return new HashMap<>()
    }

    boolean getTransactional() {
        return transactional
    }

    boolean getPublishSubscribeDestination() {
        return publishSubscribeDestination
    }

}
