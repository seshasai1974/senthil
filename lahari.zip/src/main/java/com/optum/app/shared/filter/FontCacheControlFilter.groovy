package com.optum.app.shared.filter

import com.optum.app.shared.customlog.LogFactory
import com.optum.rf.web.util.ControllerUtilities
import org.apache.commons.lang.StringUtils
import org.apache.commons.logging.Log

import javax.servlet.Filter
import javax.servlet.FilterChain
import javax.servlet.FilterConfig
import javax.servlet.ServletException
import javax.servlet.ServletRequest
import javax.servlet.ServletResponse
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse

/**
 * Code initially came from HttpCacheControlFilter in Resolution-framework, updated in order to fix issue with caching font files in IE.
 */
class FontCacheControlFilter implements Filter {
    private static final Log LOGGER = LogFactory.getLog(FontCacheControlFilter.class)
    private boolean cachingEnabled = true
    private boolean shareableCachingAllowed = true
    private int cachingSeconds = 0

    void destroy() {
    }

    void init(FilterConfig filterConfig) throws ServletException {
        String param = filterConfig.getInitParameter('enabled')
        cachingEnabled = StringUtils.isNotBlank(param) ? Boolean.parseBoolean(param) : false
        param = filterConfig.getInitParameter('sharable')
        shareableCachingAllowed = StringUtils.isNotBlank(param) ? Boolean.parseBoolean(param) : true
        param = filterConfig.getInitParameter('seconds')
        cachingSeconds = StringUtils.isNotBlank(param) ? Integer.parseInt(param) : 0
    }

    void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain) throws IOException, ServletException {
        try {
            if (request instanceof HttpServletRequest) {
                HttpServletRequest req = new FontRequestWrapper((HttpServletRequest) request)
                String path = req.getRequestURI()
                HttpServletResponse res = (HttpServletResponse) response
                if (path && !req.isFont() && !req.isHtml()) {
                    //don't set caching if the controller has already set it.
                    if (!res.containsHeader(ControllerUtilities.CACHE_CONTROL_HEADER)) {
                        ControllerUtilities.setCacheControlHeaders(req, res, cachingEnabled, cachingSeconds, shareableCachingAllowed, false)
                    }
                } else if (path) {
                    if (res.containsHeader(ControllerUtilities.CACHE_CONTROL_HEADER) || res.containsHeader(ControllerUtilities.PRAGMA_HEADER)) {
                        res.setHeader(ControllerUtilities.CACHE_CONTROL_HEADER, null)
                        res.setHeader(ControllerUtilities.PRAGMA_HEADER, null)
                    }
                }
                filterChain.doFilter(req, response)
            }
        } catch(NumberFormatException e){
            LOGGER.error(e.getClass().getName() + " in FontCacheControlFilter: " + e.getMessage() + request.queryString, e)
        }
    }

}
