package com.optum.app.shared.whitelabel

import com.optum.app.ocm.customer.businesslogic.Customer
import com.optum.app.ocm.organization.businesslogic.Organization
import com.optum.app.shared.authorization.businesslogic.Authorizations
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration

@Configuration
class WhiteLabelConfiguration {

    @Bean WhiteLabelPreloaderTimeout productionPreloaderTimeout() {
        return WhiteLabelPreloaderTimeout.PRODUCTION
    }

    @Bean
    WhiteLabel whiteLabelBean(
            Authorizations authorizations,
            Customer customer,
            Organization organization,
            CustomerWLSubmodule customerWLSubmodule,
            ForbiddenWordsSubmodule forbiddenWordsSubmodule,
            WhiteLabelPreloaderTimeout preloaderTimeout
    ) {
        def wLCustomerService = new WLCustomerService(authorizations, customer, organization)

        def forbiddenWordsMaintenanceApi = new ForbiddenWordsMaintenanceApi(wLCustomerService, forbiddenWordsSubmodule, customerWLSubmodule)
        def forbiddenWordsApi = new ForbiddenWordsApi(wLCustomerService, forbiddenWordsSubmodule, forbiddenWordsMaintenanceApi)

        def customerWLMaintenanceApi = new CustomerWLMaintenanceApi(wLCustomerService, customerWLSubmodule, forbiddenWordsSubmodule)
        def customerWLApi = new CustomerWLApi(wLCustomerService, customerWLSubmodule, customerWLMaintenanceApi)

        def whiteLabelPreloader = new WhiteLabelPreloader(customerWLApi, wLCustomerService, preloaderTimeout)

        return new WhiteLabel(
                wLCustomerService,
                whiteLabelPreloader,
                customerWLMaintenanceApi,
                forbiddenWordsMaintenanceApi,
                customerWLApi,
                forbiddenWordsApi
        )
    }

    /** This function helps us to inject external modules and use resources repos in tests */
    WhiteLabel whiteLabelWithResourceRepos(
            Authorizations authorizations,
            Customer customer,
            Organization organization
    ) {
        return whiteLabelBean(
                authorizations,
                customer,
                organization,
                new CustomerWLSubmoduleConfig().customerWLSubmoduleWithResourceRepos(),
                new ForbiddenWordsSubmoduleConfig().forbiddenWordsSubmoduleWithResourceRepos(),
                productionPreloaderTimeout()
        )
    }

    /** This function helps us to inject external modules and internal submodules in tests */
    WhiteLabel whiteLabel(
            Authorizations authorizations,
            Customer customer,
            Organization organization,
            CustomerWLSubmodule customerWLSubmodule,
            ForbiddenWordsSubmodule forbiddenWordsSubmodule
    ) {
        return whiteLabelBean(
                authorizations,
                customer,
                organization,
                customerWLSubmodule,
                forbiddenWordsSubmodule,
                WhiteLabelPreloaderTimeout.TEST
        )
    }

}
