package com.optum.app.shared.technique

import com.optum.app.shared.diseaseTraversal.data.DiseaseTraversalDO
import com.optum.app.shared.diseaseTraversal.data.TechniqueViewVO
import com.optum.rf.bl.businesslogic.BusinessLogic
import com.optum.rf.dao.sql.query.QueryProperties

interface Technique extends BusinessLogic<TechniqueViewVO> {

    List<TechniqueViewVO> readTechniquesList(int customerId, long hscId)
    List<TechniqueViewVO> readTechniquesList(DiseaseTraversalDO diseaseTraversalDO)
    List<TechniqueViewVO> readTechniqueType(long techniqueVersionID)

    List<TechniqueViewVO> listTechniques(QueryProperties queryProperties)
}
