package com.optum.app.shared.whitelabel

import com.optum.app.shared.common.messages.SpclCareMessages
import com.optum.app.shared.whitelabel.dto.CustomerWhiteLabelsDto
import com.optum.mbm.commonlogging.annotations.MbmNonHttpLogger
import com.optum.rf.dao.exception.UhgRuntimeException
import groovy.transform.Memoized
import groovy.transform.PackageScope

/**
 * Exposes a method to consume customer whiteLabels, merging customer and org level definitions.
 * The "Api" suffix indicates this class methods are meant to be exposed by the module.
 */
class CustomerWLApi {

    private final WLCustomerService wlCustomerService
    private final CustomerWLSubmodule customerWLSubmodule
    private final CustomerWLMaintenanceApi customerWLMaintenanceApi

    CustomerWLApi(
            WLCustomerService wlCustomerService,
            CustomerWLSubmodule customerWLSubmodule,
            CustomerWLMaintenanceApi customerWLMaintenanceApi) {
        this.wlCustomerService = wlCustomerService
        this.customerWLSubmodule = customerWLSubmodule
        this.customerWLMaintenanceApi = customerWLMaintenanceApi
        Objects.requireNonNull(this.wlCustomerService)
        Objects.requireNonNull(this.customerWLSubmodule)
        Objects.requireNonNull(this.customerWLMaintenanceApi)
    }

    @MbmNonHttpLogger
    CustomerWhiteLabelsDto customerWhiteLabels(Integer customerId) {
        Objects.requireNonNull(customerId)

        WLCustomerModel customerModel = wlCustomerService.getCustomerModelAuthorized(customerId)
        return memoGetCustomerWhiteLabelsWithoutAuthorizationCheck(customerModel)
    }

    /** Memoized saves time in disk reads, json parsing and words validation
     * Unsafe because no session authorization is made in this function
     * Do not remove @PackageScope as it prevents exposing method this publicly */
    @Memoized
    @PackageScope CustomerWhiteLabelsDto memoGetCustomerWhiteLabelsWithoutAuthorizationCheck(
            WLCustomerModel customerModel
    ) {
        Objects.requireNonNull(customerModel)
        Objects.requireNonNull(customerModel.customerName)
        Objects.requireNonNull(customerModel.organizationName)

        def whiteLabels = customerWLSubmodule.getMergedCustomerWhiteLabels(customerModel.customerName, customerModel.organizationName).orElseThrow {
            new UhgRuntimeException(SpclCareMessages.ERR_MISSING_CONFIGURATION_FOR("customerName " + customerModel.customerName))
        }
        customerWLMaintenanceApi.validateWhiteLabels(customerModel, whiteLabels)

        return new CustomerWhiteLabelsDto(
                customerId: customerModel.customerId,
                whiteLabels: whiteLabels
        )
    }

    /**
     * Do not use in a controller. This does not validate that the user has permissions
     * to check the customer information.
     */
    CustomerWhiteLabelsDto unsafeCustomerWhiteLabels(Integer customerId) {
        Objects.requireNonNull(customerId)

        WLCustomerModel customerModel = wlCustomerService.getCustomerModelWithoutAuthCheck(customerId)
        return memoGetCustomerWhiteLabelsWithoutAuthorizationCheck(customerModel)
    }

}
