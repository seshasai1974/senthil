package com.optum.app.shared.constants

import groovy.transform.CompileStatic

@CompileStatic
class MultiPayerConstants {

    static final String BCBSSC = 'BCBSSC'

    static final String UHC = 'UHC'

    static final String PHN = 'PHN'

    static final String OPTUM_RX = 'ORX'

    static final String OPTUMCARE_ORG_NAME = 'OptumCare'

    static final int OPTUMCARE_ORG_ID = 3

    static final int UHG_ORG_ID = 1

    static final String PAYER = 'PAYER'

    static final String FACILITY_IDENTIFIER = 'Group'

    static final String PRACTITIONER_TYPE = 'provider-type'

    static final String APPROVAL_TYPE = 'APPROVAL_TYPE'

    @Deprecated /* not recommended to use these, these are being used temporarily for the conversion to support multiple payers with the Federated Platform */
    static final int CUSTOMER_ID_UHC = 1
    @Deprecated /* not recommended to use these, these are being used temporarily for the conversion to support multiple payers with the Federated Platform */
    static final int CUSTOMER_ID_BCBSSC = 2

    static final int CUSTOMER_ID_ORX = 8

    static final String PRODUCT = 'PRODUCT'

    static final String PRODUCT_CGP = 'CGP'

    static final String FILE_TYPE = 'fileType'

    static final String FILE_TYPE_CLAIMS = "claims"

    static final String CLAIMS_INTEGRATION = "claims"

    static final String PROVIDER_INACTIVATING = 'providerInactivating'

    static final String PRACTITIONER = 'provider'

    static final String OPTUM_CARE = 'OptumCare'

    static final int UHC_PAYER_ID = 1

    static final int BCBS_SC_PAYER_ID = 2

    static final int OC_OMN_AZ_PAYER_ID = 3

    static final int OC_SMA_PAYER_ID = 4

    static final int OC_OMN_UT_PAYER_ID = 5

    static final int OC_OMN_CO_PAYER_ID = 6

    static final int PHN_PAYER_ID = 7

    static final int ORX_PAYER_ID = 8

    static final int MBM_PAYER_ID = 9

    static final String DEFAULT_CUSTOMER_ID = 0

    static final String MEMBER_ELIGIBILITY_RULES_INTEGRATION = "member-eligibility-rules"

    static final String WORK_QUEUE_RULES_ROUTING_INTEGRATION = "work-queue-routing-rules"

    static final String CASE_DECISION_PROCESSING_INTEGRATION = "case-decision-processing"

    static final String NPI_AUTO_SEARCH_INTEGRATION = "npi-auto-search"

    static final String PRIMARY_MEMBER_BENEFIT = "primary-member-benefit"

    static final String PRIMARY_MEMBER_BENEFIT_PHARMACY = "pharmacy"

    static final String MBM_INTEGRATION = "MBM"

    static final String ICUE_INTEGRATION = "ICUE"

    static final String ORX_FUSION_ENGINE = "orx-fusion-engine"

    static final String FIND_DUPLICATE_HISTORICAL_AUTHS = "find-duplicate-historical-auths"

    static final String BYPASS_TAT_POINTS = "bypass-tat-points"

    static final String CALL_AUTO_DECISION_RULES = "call-auto-decision-sheet-rules"

    static final String  CALL_AUTH_DECISION_RULES= "call-auth-decision-rules"

    /**
     * Federated config field used to determine which state field should be used in retrieving traversal data.
     */
    static final String TRAVERSAL_STATE_FIELD = "traversal-state-field"

}
