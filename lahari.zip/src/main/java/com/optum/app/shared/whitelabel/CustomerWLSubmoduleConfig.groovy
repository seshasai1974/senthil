package com.optum.app.shared.whitelabel

import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration

@Configuration
class CustomerWLSubmoduleConfig {

    @Bean WhiteLabelRepo wlCustomerLevelRepo() {
        return new WhiteLabelRepoResource("resources/whitelabel/customer/")
    }

    @Bean WhiteLabelRepo wlOrganizationLevelRepo() {
        return new WhiteLabelRepoResource("resources/whitelabel/organization/")
    }

    @Bean CustomerWLSubmodule customerWLSubmoduleBean(
            WhiteLabelRepo wlCustomerLevelRepo,
            WhiteLabelRepo wlOrganizationLevelRepo
    ) {
        return new CustomerWLSubmodule(
                wlCustomerLevelRepo,
                wlOrganizationLevelRepo
        )
    }

    CustomerWLSubmodule customerWLSubmoduleWithResourceRepos() {
        return customerWLSubmoduleBean(
                wlCustomerLevelRepo(),
                wlOrganizationLevelRepo()
        )
    }

    CustomerWLSubmodule customerWLSubmoduleWithInMemoryRepos() {
        return customerWLSubmoduleBean(
                new WhiteLabelRepoInMemory(),
                new WhiteLabelRepoInMemory()
        )
    }
}
