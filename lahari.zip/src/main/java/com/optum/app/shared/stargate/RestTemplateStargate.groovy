package com.optum.app.shared.stargate

import com.optum.rf.core.annotation.InjectedBean
import org.springframework.web.client.RestTemplate

@InjectedBean
interface RestTemplateStargate {

    /**
     * Generic method for getting Rest Template for Stargate
     */
    RestTemplate restTemplate()

}