package com.optum.app.shared.constants

import groovy.transform.CompileStatic

@CompileStatic
class SpclCareNonPersistedFieldConstants {
    public static final String CONFIG_TEXT_TYPE = 'configTextType'
    public static final String HSC_ID_FORMAT_TYPE = 'hscIDFormatType'
    public static final String HSC_OVERALL_STATUS_TYPE = 'hscOverallStatusType'
    public static final String ORX_STATUS = 'orxStatus'
    public static final String HSC_OVERALL_STATUS_DESC = 'hscOverallStatusDesc'
    public static final String SUBMISSION_NOT_REQUIRED_TIN = 'submissionNotRequiredTIN'
    public static final String BRIOVA_TIN = 'briovaTIN'
    public static final String SUPPORTIVE_TYPE = 'supportiveType'
    public static final String URGENT_REQUEST_OUTCOME_TYPE = 'urgentRequestOutcomeType'
    public static final String ERRORMAXRETRIES = 'errorMaxRetries'
    public static final String NYE_MEMBER_POLICY_IDENTIFIER = 'nyeMemberPolicyNumber'
    public static final String HCA_MEMBER_POLICY_IDENTIFIER = 'hcaMemberPolicyNumber'
    public static final String BAR_MEMBER_POLICY_IDENTIFIER = 'barPolicy'
    public static final String DECISIONVALUE = 'decisionValue'
    public static final String AUTHORIZATION_TYPE = 'authorizationType'
    public static final String RADIOPHARMA_DRUG_TYPE = 'radioPharmaRequest'
    public static final String SUPPORTED_SOURCE_SYSTEM_MBM_INTAKE = 'supportedSourceSystemsMbmIntake'
    public static final String LEUPROLIDE_ACETATE= 'leuprolideAcetate'
    public static final String AUTH_DURATION = 'authDuration'
    public static final String AUTH_DURATION_UNITS = 'authDurationUnits'
    public static final String SPECIALTY_PHARMA_DIAGNOSIS_TYPE = 'specialtyPharmaDiagnosisType'
    public static final String DRUGCLASS = 'drugClass'
    public static final String ICD10_CANCER_DIAGNOSIS_CODE = 'icd10CancerDiagnosisCode'
    public static final String STEPPER_LOCATION = 'authStepperLocation'
    public static final String LETTER_STATUS = 'letterStatus'
    public static final String NPI_SEARCH_ONLY = 'npiSearchOnly'
    public static final String INSURANCE_SUB_TYPE = 'insuranceSubType'
    public static final String INSURANCE_CARRIER_TYPE_CODE = 'insuranceCarrierTypeCode'
    public static final String RULES_MANAGER_PROVIDER_SEARCH = 'rulesManagerProviderSearch'
    public static final String PATHWAY_PRODUCT_CATEGORY_TYPE = 'pathwayProductCategoryType'
    public static final String PATHWAYS_ELIGIBLE_PRODUCT = 'pathwaysEligibleProduct'
    public static final String CUSTOM_REQUEST_REASON_TYPE = 'customRequestReasonType'
    public static final String TECHNIQUE_COMBINATION_VOS = 'comboVOs'
    public static final String RULE_OUTCOME_ACTION = "ruleOutcomeAction"
    public static final String SECONDARY_CAUSE_OF_CURRENT_EPISODE = "secondaryCauseOfCurrentEpisode"
    public static final String PRIMARY_CAUSE_OF_CURRENT_EPISODE = "primaryCauseOfCurrentEpisode"
    public static final String PATIENT_TYPE = "patientType"
    public static final String NATURE_OF_CONDITION = "natureOfCondition"
    public static final String PRIMARY_PROVIDER_CREDENTIAL = "primaryProviderCredential"
    public static final String SURGERY_TYPE = "typeOfSurgery"
    public static final String SECONDARY_PROVIDER_CREDENTIAL = "secondaryProviderCredential"
    public static final String SECONDARY_TYPE_OF_SURGERY = "secondaryTypeOfSurgery"
    public static final String SUBMITRETRYWAITTIME = 'submitRetryWaitTime'
    public static final String MAXSUBMITRETRYCOUNT = 'maxSubmitRetryCount'
    public static final String CIRRUS_PLAN_TYPE = 'cirrusPlanType'

}
