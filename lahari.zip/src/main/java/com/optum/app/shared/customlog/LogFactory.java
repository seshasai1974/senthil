package com.optum.app.shared.customlog;

import org.apache.commons.logging.Log;


public class LogFactory {

    public static Log getLog(Class<?> clazz) {
        return new CustomLogWrapper(clazz);
    }
}
