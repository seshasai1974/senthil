package com.optum.app.shared.edi;

import com.optum.rf.core.annotation.InjectedBean;
import com.optum.app.common.edi.data.EdiVO;

@InjectedBean
public interface EdiHelper {

    void logEdiRequest(EdiVO ediVO, String hscID, String ediType, String requestText);

    void logEdiResponse(EdiVO ediVO, String response);

    void logEdiError(EdiVO ediVO, String response, String errorMessage);
}
