package com.optum.app.shared.whitelabel

import com.fasterxml.jackson.databind.JsonNode

class WhiteLabelRepoInMemory implements WhiteLabelRepo {

    private final HashMap<String, JsonNode> nameToWhiteLabels = new HashMap<>()

    @Override
    Optional<JsonNode> findByName(String name) {
        JsonNode whiteLabels = nameToWhiteLabels.get(name)
        return Optional.ofNullable(whiteLabels)
    }

    @Override
    void save(String name, JsonNode whiteLabels) {
        nameToWhiteLabels.put(name, whiteLabels)
    }

    Set<String> savedNames() {
        return nameToWhiteLabels.keySet()
    }

}

