package com.optum.app.shared.whitelabel

import com.fasterxml.jackson.core.type.TypeReference
import com.fasterxml.jackson.databind.ObjectMapper

class ForbiddenWordsRepoResource implements ForbiddenWordsRepo {

    private final ObjectMapper objectMapper = new ObjectMapper()
    private final TypeReference<List<String>> listOfStringsType = new TypeReference<List<String>>(){}
    private final String path

    ForbiddenWordsRepoResource(String path) {
        this.path = path
        Objects.nonNull(this.path)
    }

    @Override
    List<String> findByName(String customerName) {
        InputStream forbiddenValuesInputStream = getClass()
                .getClassLoader()
                .getResourceAsStream(path + customerName + ".json")

        if(forbiddenValuesInputStream == null) {
            return new ArrayList<>()
        }

        return objectMapper.readValue(forbiddenValuesInputStream, listOfStringsType) as List<String>
    }

    @Override
    void save(String customerName, List<String> forbiddenWords) {
        throw new UnsupportedOperationException(
                "These values can only be modified by developers because this repository uses hardcoded json files"
        )
    }
}
