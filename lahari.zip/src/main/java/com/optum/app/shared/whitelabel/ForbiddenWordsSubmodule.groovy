package com.optum.app.shared.whitelabel


/**
 * This submodule allows us to hide different levels of forbidden words.
 * Right now the level is customer only, but we could add org level eventually.
 * */
class ForbiddenWordsSubmodule {

    private final ForbiddenWordsRepo customerLevelRepo
    private final ForbiddenWordsRepo organizationLevelRepo

    ForbiddenWordsSubmodule(ForbiddenWordsRepo customerLevelRepo, ForbiddenWordsRepo organizationLevelRepo) {
        this.customerLevelRepo = customerLevelRepo
        this.organizationLevelRepo = organizationLevelRepo
        Objects.requireNonNull(this.customerLevelRepo)
        Objects.requireNonNull(this.organizationLevelRepo)
    }

    List<String> getMergedForbiddenWords(String customerName, String organizationName) {
        def customerWhiteLabels = customerLevelRepo.findByName(customerName)
        def organizationWhiteLabels = organizationLevelRepo.findByName(organizationName)

        List<String> mergedForbiddenWords = []
        mergedForbiddenWords.addAll(customerWhiteLabels)
        mergedForbiddenWords.addAll(organizationWhiteLabels)

        return mergedForbiddenWords
    }

    List<String> getFWCustomerLevelValues(String customerName) {
        return customerLevelRepo.findByName(customerName)
    }

    void saveFWCustomerLevelValues(String customerName, List<String> forbiddenWords) {
        customerLevelRepo.save(customerName, forbiddenWords)
    }

    List<String> getFWOrganizationLevelValues(String organizationName) {
        return organizationLevelRepo.findByName(organizationName)
    }

    void saveFWOrganizationLevelValues(String organizationName, List<String> forbiddenWords) {
        organizationLevelRepo.save(organizationName, forbiddenWords)
    }
}
