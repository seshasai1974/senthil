package com.optum.app.shared.messaging

import com.optum.rf.core.message.InternalMessageDestination
import com.optum.rf.core.message.MessageDestinationProvider
import org.springframework.beans.factory.InitializingBean

import java.util.concurrent.ConcurrentHashMap

class SpclCareMessageDestination implements InitializingBean {

    /* Message Destination Names used by OCM BASE */
    public static final String AUTHORIZATION_REFRESH_QUEUE = 'AUTHORIZATION_REFRESH_QUEUE'

    private static MessageDestinationProvider internalMessageDestinationProvider

    // property method used to set the static field
    static void setMessageDestinationProvider(MessageDestinationProvider messageDestinationProvider) {
        internalMessageDestinationProvider = messageDestinationProvider
    }

    SpclCareMessageDestination(MessageDestinationProvider mdp){
        setMessageDestinationProvider(mdp)
    }

    @Override
    void afterPropertiesSet() throws Exception {
        if(internalMessageDestinationProvider == null) {
            throw new RuntimeException('SpclCareMessageDestination: messageDestinationProvider property must be set.')
        }
    }

    static InternalMessageDestination getDestination(String name) {
        if (internalMessageDestinationProvider != null) {
            return internalMessageDestinationProvider.getMessageDestination(name)
        } else {
            return null
        }
    }

    static Map<String, InternalMessageDestination> getMsgDestinationsByMessageType() {
        Map<String, InternalMessageDestination> msgDestinationsByClassName = new ConcurrentHashMap<>()
        for (String destName : internalMessageDestinationProvider.getMessageDestinationNames()) {
            InternalMessageDestination internalMessageDestination = getDestination(destName)
            if (internalMessageDestination.getMessageTrackingType() != null) {
                msgDestinationsByClassName.put(internalMessageDestination.getMessageTrackingType().getMessageTypeCode(), internalMessageDestination)
            }
        }
        return msgDestinationsByClassName
    }

    static boolean isMessageTrackingEnabledForMessageType(String forMessageType) {
        boolean enabled = false
        if(forMessageType != null) {
            Map<String, InternalMessageDestination> msgDestinations = getMsgDestinationsByMessageType()
            InternalMessageDestination msgDestination = msgDestinations.get(forMessageType)
            if(msgDestination != null) {
                enabled = msgDestination.isMessageTrackingEnabled()
            }
        }
        return enabled
    }

}
