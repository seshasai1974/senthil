package com.optum.app.shared.whitelabel

import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.databind.ObjectMapper
import com.optum.app.shared.whitelabel.dto.ForbiddenWordsDto
import groovy.transform.PackageScope

/**
 * Adds validation to the save methods
 * The "Api" suffix indicates this class methods are meant to be exposed by the module.
 */
class ForbiddenWordsMaintenanceApi {

    private final WLCustomerService wlCustomerService
    private final ForbiddenWordsSubmodule forbiddenWordsSubmodule
    private final CustomerWLSubmodule customerWLSubmodule
    private final JsonNode emptyWhiteLabelConfig = new ObjectMapper().createObjectNode()

    ForbiddenWordsMaintenanceApi(WLCustomerService wlCustomerService, ForbiddenWordsSubmodule forbiddenWordsSubmodule, CustomerWLSubmodule customerWLSubmodule) {
        this.wlCustomerService = wlCustomerService
        this.forbiddenWordsSubmodule = forbiddenWordsSubmodule
        this.customerWLSubmodule = customerWLSubmodule
        Objects.requireNonNull(this.wlCustomerService)
        Objects.requireNonNull(this.forbiddenWordsSubmodule)
        Objects.requireNonNull(this.customerWLSubmodule)
    }

    List<String> getFWCustomerLevelValues(Integer customerId) {
        Objects.requireNonNull(customerId)

        String customerName = wlCustomerService.getCustomerNameAuthorized(customerId)
        return forbiddenWordsSubmodule.getFWCustomerLevelValues(customerName)
    }

    void saveFWCustomerLevelValues(ForbiddenWordsDto forbiddenWordsDto) {
        Objects.requireNonNull(forbiddenWordsDto)
        Objects.requireNonNull(forbiddenWordsDto.customerId)
        Objects.requireNonNull(forbiddenWordsDto.forbiddenWords)

        WLCustomerModel customerModel = wlCustomerService.getCustomerModelAuthorized(forbiddenWordsDto.customerId)
        validateFWAgainstSavedWhiteLabels(customerModel,  forbiddenWordsDto)
        forbiddenWordsSubmodule.saveFWCustomerLevelValues(customerModel.customerName, forbiddenWordsDto.forbiddenWords)
    }

    List<String> getFWOrganizationLevelValues(Integer customerId) {
        Objects.requireNonNull(customerId)

        WLCustomerModel customerModel = wlCustomerService.getCustomerModelAuthorized(customerId)
        return forbiddenWordsSubmodule.getFWOrganizationLevelValues(customerModel.organizationName)
    }

    void saveFWOrganizationLevelValues(ForbiddenWordsDto forbiddenWordsDto) {
        Objects.requireNonNull(forbiddenWordsDto)
        Objects.requireNonNull(forbiddenWordsDto.customerId)
        Objects.requireNonNull(forbiddenWordsDto.forbiddenWords)

        WLCustomerModel customerModel = wlCustomerService.getCustomerModelAuthorized(forbiddenWordsDto.customerId)
        validateFWAgainstSavedWhiteLabels(customerModel,  forbiddenWordsDto)
        forbiddenWordsSubmodule.saveFWOrganizationLevelValues(customerModel.customerName, forbiddenWordsDto.forbiddenWords)
    }

    @PackageScope WLCustomerModel validateFWAgainstSavedWhiteLabels(WLCustomerModel customerModel, ForbiddenWordsDto forbiddenWordsDto) {
        Objects.requireNonNull(customerModel)
        Objects.requireNonNull(customerModel.customerName)
        Objects.requireNonNull(customerModel.organizationName)
        Objects.requireNonNull(forbiddenWordsDto)
        Objects.requireNonNull(forbiddenWordsDto.forbiddenWords)

        JsonNode whiteLabels = customerWLSubmodule.getMergedCustomerWhiteLabels(customerModel.customerName, customerModel.organizationName).orElse(emptyWhiteLabelConfig)
        new WhiteLabelsValidator(
                customerModel.customerName,
                whiteLabels,
                forbiddenWordsDto.forbiddenWords
        ).validate()
        return customerModel
    }

    @PackageScope void validateFWAgainstEmptyWhiteLabels(String customerName, List<String> forbiddenWords) {
        Objects.requireNonNull(customerName)
        Objects.requireNonNull(forbiddenWords)

        new WhiteLabelsValidator(
                customerName,
                emptyWhiteLabelConfig,
                forbiddenWords
        ).validate()
    }

}
