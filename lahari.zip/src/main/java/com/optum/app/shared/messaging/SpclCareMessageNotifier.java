package com.optum.app.shared.messaging;

import com.optum.app.shared.authorization.amqp.AuthRefreshMessage;

public interface SpclCareMessageNotifier {
    
    void refreshAuthorization(AuthRefreshMessage authRefreshMessage);
}