package com.optum.app.shared.eis;

import com.optum.app.shared.constants.EISConstants;
import com.optum.eis.constants.PropertyKeyConstants;
import com.optum.rf.dao.controller.session.Session;
import com.optum.rf.dao.controller.session.SessionThreadLocal;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Properties;

public class EISUtility {
    /**
     * Utility Method to Fetch and Set SSL Properties
     * For EISLogger Configuration
     *
     * @return Properties Object with SSL Properties
     */
    public static Properties getSSLProps() {
        Properties sslProps = new Properties();
        sslProps.put(PropertyKeyConstants.SSL_TRUSTSTORE_LOCATION, System.getenv(EISConstants.EIS_SSL_TRUSTSTORE_LOCATION));
        sslProps.put(PropertyKeyConstants.SSL_TRUSTSTORE_PWORD, System.getenv(EISConstants.EIS_SSL_TRUSTSTORE_PWORD));
        sslProps.put(EISConstants.SSL_KEYSTORE_LOCATION, System.getenv(EISConstants.EIS_SSL_TRUSTSTORE_LOCATION));
        sslProps.put(EISConstants.SSL_KEYSTORE_PWORD, System.getenv(EISConstants.EIS_SSL_TRUSTSTORE_PWORD));
        sslProps.put(EISConstants.SSL_KEY_PWORD, System.getenv(EISConstants.EIS_SSL_TRUSTSTORE_PWORD));
        sslProps.put(PropertyKeyConstants.SERVER_PORT, System.getenv(EISConstants.EIS_SERVER_PORT));
        sslProps.put(PropertyKeyConstants.TOPIC, System.getenv(EISConstants.EIS_TOPIC));
        sslProps.put(PropertyKeyConstants.ASK_ID, System.getenv(PropertyKeyConstants.ASK_ID));
        sslProps.put(PropertyKeyConstants.APPLICATION_CI, System.getenv(PropertyKeyConstants.APPLICATION_CI));
        sslProps.put(PropertyKeyConstants.CLIENT_ID, System.getenv(PropertyKeyConstants.ASK_ID));
        return sslProps;
    }

    /**
     * Utility Method to Fetch user details
     *
     * @param httpRequest
     * @return userdetails hashmap
     */
    public static HashMap<String, String> getUserDetails(HttpServletRequest httpRequest, String reason) {
        HashMap<String, String> userDetails = new HashMap<>();
        Session session = SessionThreadLocal.getSession();
        userDetails.put(EISConstants.USER_ID, session.getUserSecurity().getUserID());
        userDetails.put(EISConstants.USER_ROLE, session.getUserSecurity().getUserGroupID());
        userDetails.put(EISConstants.USER_AGENT, httpRequest.getHeader("user-agent"));
        userDetails.put(EISConstants.X_FORWARDED_FOR, httpRequest.getHeader("X-Forwarded-For") == null ? httpRequest.getRemoteAddr() : httpRequest.getHeader("X-Forwarded-For"));
        userDetails.put(EISConstants.X_FORWARDED_PROTO, httpRequest.getHeader("X-Forwarded-Proto") == null ? "https" : httpRequest.getHeader("X-Forwarded-Proto"));
        userDetails.put(EISConstants.REASON, reason);
        return userDetails;
    }
}
