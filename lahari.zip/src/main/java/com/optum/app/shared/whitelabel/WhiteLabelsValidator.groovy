package com.optum.app.shared.whitelabel

import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.databind.node.ContainerNode
import com.fasterxml.jackson.databind.node.TextNode
import com.optum.app.shared.common.messages.SpclCareMessages
import com.optum.rf.dao.exception.UhgRuntimeException

import java.util.regex.Matcher
import java.util.regex.Pattern

class WhiteLabelsValidator {

    private final String customerName
    private final JsonNode whiteLabels
    private final List<String> preparedForbiddenWords
    private final List<String> whiteLabelValueIllegalCharacters
    private final List<String> forbiddenWordsIllegalCharacters
    private final Pattern whiteLabelKeyIllegalPattern

    WhiteLabelsValidator(String customerName, JsonNode whiteLabels, List<String> forbiddenWords) {
        this.customerName = customerName
        this.whiteLabels = whiteLabels
        Objects.requireNonNull(forbiddenWords)
        this.preparedForbiddenWords = forbiddenWords.collect {
            forbiddenValue -> prepareStringForWordsValidation(forbiddenValue)
        }
        def nonBreakingSpace = '\u00A0'
        this.whiteLabelValueIllegalCharacters = [nonBreakingSpace]
        this.forbiddenWordsIllegalCharacters = ["\n"]
        this.forbiddenWordsIllegalCharacters.addAll(whiteLabelValueIllegalCharacters)
        this.whiteLabelKeyIllegalPattern = Pattern.compile("[\\s" + nonBreakingSpace + "]")
        Objects.requireNonNull(this.customerName)
        Objects.requireNonNull(this.whiteLabels)
        Objects.requireNonNull(this.preparedForbiddenWords)
        Objects.requireNonNull(this.whiteLabelValueIllegalCharacters)
        Objects.requireNonNull(this.forbiddenWordsIllegalCharacters)
        Objects.requireNonNull(this.whiteLabelKeyIllegalPattern)
    }

    void validate() {
        // Validate forbidden words
        preparedForbiddenWords.each { validateForbiddenCharacters(it, forbiddenWordsIllegalCharacters) }

        // Validate whiteLabels
        if (!whiteLabels.isObject()) {
            throw new IllegalArgumentException("WhiteLabels must be a valid json object")
        }

        validateWhiteLabelJsonRecursively(whiteLabels)
    }

    private void validateWhiteLabelJsonRecursively(JsonNode whitelabelNode) {
        if (whitelabelNode instanceof ContainerNode) {
            Iterator<JsonNode> containerElements = whitelabelNode.elements()

            if (whitelabelNode.isObject()) {
                validateWhiteLabelKeys(whitelabelNode)
            }

            while(containerElements.hasNext()) {
                validateWhiteLabelJsonRecursively(containerElements.next())
            }
        } else if(whitelabelNode instanceof TextNode) {
            validateWhiteLabelTextValue(whitelabelNode.asText())
        }
    }

    private void validateWhiteLabelKeys(JsonNode whitelabelNode) {
        whitelabelNode.fieldNames().each { fieldName ->
            Matcher whiteSpaceMatcher = whiteLabelKeyIllegalPattern.matcher(fieldName)
            if(whiteSpaceMatcher.find()) {
                throwForbiddenCharacterException(fieldName)
            }
        }
    }

    private void validateWhiteLabelTextValue(String whiteLabelValue) {
        validateForbiddenCharacters(whiteLabelValue, whiteLabelValueIllegalCharacters)

        String preparedWhiteLabelValue = prepareStringForWordsValidation(whiteLabelValue)

        // Validate forbidden Words aren't included in the WhiteLabel configuration
        if(preparedForbiddenWords.any { forbiddenWord -> preparedWhiteLabelValue.contains(forbiddenWord) }) {
            throw new UhgRuntimeException(
                    SpclCareMessages.ERR_FORBIDDEN_WORD_IN_WHITE_LABELS(customerName.toString()),
                    "WhiteLabel configuration for " + customerName + " contains forbidden text on '" + whiteLabelValue + "'"
            )
        }
    }

    private void validateForbiddenCharacters(String value, List<String> forbiddenCharacters) {
        if(forbiddenCharacters.any { forbiddenCharacter -> value.contains(forbiddenCharacter) }) {
            throwForbiddenCharacterException(value)
        }
    }

    private void throwForbiddenCharacterException(String value) {
        throw new UhgRuntimeException(
                SpclCareMessages.ERR_FORBIDDEN_CHARACTER_IN_WHITE_LABELS(customerName.toString()),
                "WhiteLabel configuration for " + customerName + " contains forbidden character on '" + value + "'"
        )
    }

    private String prepareStringForWordsValidation(String string) {
        // Adding this whitespace ensures we don't match parts of words as forbidden words.
        String stringWithLeadingAndTrailingWhiteSpace = " " + string + " "
        // Includes all whitespaces matched by \\s excluding new lines
        String whiteSpaceRegex = "[^\\S\\n\\r]+"
        return stringWithLeadingAndTrailingWhiteSpace.replaceAll(whiteSpaceRegex, " ").toLowerCase()
    }

}
