package com.optum.app.shared.interceptor;


import com.optum.app.shared.constants.SpclCareFeatureFlagConstants;
import com.optum.app.shared.eis.EISUtility;
import com.optum.eis.event.model.logClass;
import com.optum.mbm.commonlogging.annotations.EISAudit;
import com.optum.mbm.commonlogging.eis.logger.EISLogger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;
import com.optum.rf.common.featureflag.util.FeatureFlagUtility;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

class EISInterceptor extends HandlerInterceptorAdapter {

    private Logger logger = LoggerFactory.getLogger(EISInterceptor.class);

    /**
     * EISInterceptor prehandle method to invoke EISLogger
     * on all methods marked off with the @EISAudit annotation
     *
     * @param httpRequest HttpServletRequest Object to get request details
     * @param response    HttpServletResponse Object to capture response
     * @param handler     Object for the invoking method
     * @return True in all cases, as we don't want to stop execution
     */
    public boolean preHandle(HttpServletRequest httpRequest, HttpServletResponse response, Object handler) {
        try {
            if (FeatureFlagUtility.getManager().isActive(SpclCareFeatureFlagConstants.ENABLE_EIS_LOGGING)) {
                if (handler instanceof HandlerMethod) {
                    HandlerMethod handlerMethod = (HandlerMethod) handler;
                    EISAudit methodAnnotation = handlerMethod.getMethodAnnotation(EISAudit.class);
                    //Check If @EISAudit annotation is present on method
                    if (null != methodAnnotation) {
                        //Invoke EISLogger Driver method & Check for Log Stream Queue Status
                        //Successful Queue means a true value is returned
                            EISLogger.AuditLog(handlerMethod.getMethod(), EISUtility.getSSLProps(), logClass.SECURITY_AUDIT, EISUtility.getUserDetails(httpRequest, null));
                    }
                }
            }
        } catch (Exception e) {
            logger.error("Error during EIS interception");
        }
        return true;
    }
}
