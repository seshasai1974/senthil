package com.optum.app.shared.constants

class SpclCareSettingsReferenceConstants {
    //***********************************************************************************************
    //* This section <b>should</b> contain constants pertaining to the reference table.
    //* All other constants should be either outside of this section or in the global constants class.
    //* Any new entries into this section, isValid the code by running the ReferenceConstantsValidation program.
    //***********************************************************************************************
//    @Reference(name = FieldConstants.PROVIDERWSID)
//    public static final String PROVIDERWSID_SERVICEPLANDETAIL_V1 = 'SvPlnDtlV1'
//    @Reference(name = FieldConstants.PROVIDERWSID)
//    public static final String PROVIDERWSID_SERVICEPLANMEETING_V1 = 'SvPlnMtgV1'
}
