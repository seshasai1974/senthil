package com.optum.app.shared.customlog;

import com.optum.rf.common.log.log4j.UhgLogger;
import org.apache.commons.logging.Log;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.spi.ExtendedLogger;
import org.apache.logging.log4j.spi.ExtendedLoggerWrapper;

public class CustomLogWrapper implements Log {
    private static final String FQCN = CustomLogWrapper.class.getName();
    private final ExtendedLoggerWrapper extendedWrapper;
    public Logger logger;

    public CustomLogWrapper(Class<?> clazz) {
        logger = LogManager.getLogger(clazz);
        extendedWrapper = new ExtendedLoggerWrapper((ExtendedLogger) logger,
                logger.getName(), logger.getMessageFactory());
    }

    @Override
    public void error(Object message) {
        extendedWrapper.logIfEnabled(FQCN, Level.ERROR, null, message, null);
        new UhgLogger(logger.getName()).error(message);
    }

    @Override
    public void error(final Object message, final Throwable t) {
        extendedWrapper.logIfEnabled(FQCN, Level.ERROR, null, message, t);
        new UhgLogger(logger.getName()).error(message, t);
    }

    @Override
    public boolean isDebugEnabled() {
        return extendedWrapper.isEnabled(Level.DEBUG, null, null);
    }

    @Override
    public boolean isErrorEnabled() {
        return extendedWrapper.isEnabled(Level.ERROR, null, null);
    }

    @Override
    public boolean isFatalEnabled() {
        return extendedWrapper.isEnabled(Level.FATAL, null, null);
    }

    @Override
    public boolean isInfoEnabled() {
        return extendedWrapper.isEnabled(Level.INFO, null, null);
    }

    @Override
    public boolean isTraceEnabled() {
        return extendedWrapper.isEnabled(Level.TRACE, null, null);
    }

    @Override
    public boolean isWarnEnabled() {
        return extendedWrapper.isEnabled(Level.WARN, null, null);
    }

    @Override
    public void trace(final Object message) {
        extendedWrapper.logIfEnabled(FQCN, Level.TRACE, null, message, null);
    }

    @Override
    public void trace(final Object message, final Throwable t) {
        extendedWrapper.logIfEnabled(FQCN, Level.TRACE, null, message, t);
    }

    @Override
    public void debug(final Object message) {
        extendedWrapper.logIfEnabled(FQCN, Level.DEBUG, null, message, null);
    }

    @Override
    public void debug(final Object message, final Throwable t) {
        extendedWrapper.logIfEnabled(FQCN, Level.DEBUG, null, message, t);
    }

    @Override
    public void info(final Object message) {
        extendedWrapper.logIfEnabled(FQCN, Level.INFO, null, message, null);
    }

    @Override
    public void info(final Object message, final Throwable t) {
        extendedWrapper.logIfEnabled(FQCN, Level.INFO, null, message, t);
    }

    @Override
    public void warn(final Object message) {
        extendedWrapper.logIfEnabled(FQCN, Level.WARN, null, message, null);
    }

    @Override
    public void warn(final Object message, final Throwable t) {
        extendedWrapper.logIfEnabled(FQCN, Level.WARN, null, message, t);
    }

    @Override
    public void fatal(final Object message) {
        extendedWrapper.logIfEnabled(FQCN, Level.FATAL, null, message, null);
    }

    @Override
    public void fatal(final Object message, final Throwable t) {
        extendedWrapper.logIfEnabled(FQCN, Level.FATAL, null, message, t);
    }
}
