package com.optum.app.shared.whitelabel

import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit

enum WhiteLabelPreloaderTimeout {
    PRODUCTION(5, TimeUnit.MINUTES), TEST(200, TimeUnit.MILLISECONDS)
    final Integer timeoutValue
    final TimeUnit timeUnit

    private WhiteLabelPreloaderTimeout(Integer timeoutValue, TimeUnit timeUnit) {
        this.timeoutValue = timeoutValue
        this.timeUnit = timeUnit
    }
}

/** This class allows async preloading WhiteLabels to populate caches and avoid slow response times */
class WhiteLabelPreloader {

    private final CustomerWLApi customerWLApi
    private final WLCustomerService wlCustomerService
    private final WhiteLabelPreloaderTimeout timeout

    private Future<Set<String>> futureSuccessList

    WhiteLabelPreloader(CustomerWLApi customerWLApi, WLCustomerService wlCustomerService, WhiteLabelPreloaderTimeout timeout) {
        this.customerWLApi = customerWLApi
        this.wlCustomerService = wlCustomerService
        this.timeout = timeout
        Objects.requireNonNull(this.customerWLApi)
        Objects.requireNonNull(this.wlCustomerService)
        Objects.requireNonNull(this.timeout)
    }

    /** Handle execution and timeout for the future to preload customer white labels asynchronously */
    Future<Set<String>> asyncPreload() {
        if (futureSuccessList != null) {
            return futureSuccessList
        }

        ScheduledExecutorService futureWithTimeoutExecutor = Executors.newScheduledThreadPool(2)
        Objects.requireNonNull(futureWithTimeoutExecutor)

        futureSuccessList = futureWithTimeoutExecutor.submit (
                { return preloadCustomerWhiteLabels() } as Callable<Set<String>>
        )
        Objects.requireNonNull(futureSuccessList)

        futureWithTimeoutExecutor.schedule(
                { futureSuccessList.cancel(true) },
                timeout.timeoutValue,
                timeout.timeUnit
        )
        futureWithTimeoutExecutor.shutdown()

        return futureSuccessList
    }

    /** Preload white labels
     * Errors don't bubble up as this is an internal call and not a user requesting information */
    private Set<String> preloadCustomerWhiteLabels() {
        Set<String> successfulCustomers = new HashSet<>()

        wlCustomerService.customerModelListWithoutAuthCheck().each{ customerModel ->
            try {
                customerWLApi.memoGetCustomerWhiteLabelsWithoutAuthorizationCheck(customerModel)
                successfulCustomers.add(customerModel.customerName)
            } catch(Exception ignored) { }
        }

        return successfulCustomers
    }

}
