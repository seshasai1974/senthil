package com.optum.app.shared.constants

import groovy.transform.CompileStatic

@CompileStatic
class SpclCareFeatureFlagConstants {

    public final static String ANGULAR_UPGRADE = 'AngularUpgrade'

    public final static String BLOCKER_OVERRIDE = 'CheckBlockerOverride'
    public final static String MEMBER_REFRESH = 'MemberRefresh'
    public final static String EXISTING_AUTH_CHECK = 'ExistingAuthCheck'
    public final static String EXISTING_AUTH_TERM = 'ExistingAuthTerm'
    public final static String OON_PROVIDERS_RESTRICTED = 'oonProvidersRestricted'
    public final static String SYSTEM_UNAVAILABLE = 'SystemUnavailable'
    public final static String GENERIC_RULE_SERVICE = 'genericRuleService'
    public final static String ENABLE_CHECKBOX_SUPPLEMENTARY_RESPONSE = 'enableSuppResponses'
    public final static String APPROVED_BY_PAYER = 'ApprovedByPayer'
    public final static String PROCESS_TAT = 'ProcessTAT'
    public final static String DRUG_POLICY_DISEASE_STATES = 'DrugPolicyDiseaseStates'
    public final static String SAVE_EXECUTION_LOG = 'saveExecutionLog'
    public final static String HSC_TRAVERSAL_DURATION = 'HscTraversalDuration'
    public final static String INVOKE_JBPM_FOR_UHC_AUTHS = 'InvokeJbpmForUhcAuths'
    public final static String USE_DB_MEMBERS_ON_FAILURE = 'AllowCachedMembers'
    public final static String IGNORE_JBPM_ERRORS = 'SkipJBPM'
    public final static String ENABLE_ORALS = 'EnableOrals'
    public final static String ENABLE_SITE_OF_CARE_PROVIDER_EXCEPTIONS = 'EnableProviderSiteOfCareExceptions'
    public final static String FUTURE_DATING_AUTHS_ALL = 'FutureDatingAuthsAll'
    public final static String FUTURE_DATING_AUTHS_SUPP_CARE = 'FutureDatingAuthsSuppCare'
    public final static String FUTURE_DATING_AUTHS_CHEMO = 'FutureDatingAuthsChemo'
    public final static String FUTURE_DATING_AUTHS_SPECIALTY = 'FutureDatingAuthsSpecialty'
    public final static String FUTURE_DATING_AUTHS_RADIO_PHARMA = 'FutureDatingAuthsRadioPharma'
    public final static String FUTURE_DATING_AUTHS_RAD_ONC = 'FutureDatingAuthsRadOnc'
    public final static String ENABLE_NEW_TRAVERSAL_DATA_MODEL_BL = 'enableNewTraversalDataModelBL'
    public final static String ENABLE_PATHWAYS_FOR_RADIATION_ONCOLOGY = 'enablePathwaysRadOnc'
    public final static String LIMITED_SUPPLIER_POS = 'LimitedSupplierPOS'
    public final static String ENABLE_INSURANCE_SUB_TYPE = 'InsuranceSubType'
    public final static String ENABLE_SGP_CHANNEL_SOURCE = 'enableSendChannelSourceSGPToIcue'
    public final static String ENABLE_RULES_MANAGER = 'EnableRulesManager'
    public final static String BAR_POLICY_EXCEPTION = 'BarPolicyException'
    public final static String CHECK_MEMBER_EXCEPTION = 'CheckMemberException'
    public final static String SYNC_ICUE_MBM_DATA = 'SyncIcueMbmData'
    public final static String ENABLE_EIS_LOGGING = 'EISLogging'
    public final static String ALLOW_ALL_MEMBER_COVERAGES = 'AllowAllMemberCoverages'
    public final static String ENABLE_MEMBER_INSURANCE_TYPE = 'MemberInsuranceType'
    public final static String EXTEND_END_DATE_ALL_AUTHS = 'ExtendEndDateAllAuths'
    public final static String PREFERRED_CSFS = 'PreferredCSFs'
    public final static String ENABLE_MSE_BEHAVIOUR = 'ProviderGroupMSE'
    public final static String ENABLE_INITIAL_INFUSION_QUESTION = 'EnableInitialInfusionQuestion'
    public final static String ENABLE_MOVE_TREATMENT_STATUS_TO_MEMBER_SEARCH = 'EnableMoveTreatmentStatusToMemberSearch'
    public final static String SELF_ADMINISTERED_DRUG = 'SelfAdministeredDrug'
    public final static String RAR_JOB_ENHANCEMENT = 'RARJobEnhancement'
    public final static String RFA_JOB_ENHANCEMENT = 'RFAJobEnhancement'
    public final static String PH_THERAPY_AUTH_REPROCESS_REWRITE = 'PHTherapyAuthReprocessRewrite'
    public final static String RUA_JOB_ENHANCEMENT = 'RUAJobEnhancement'
    public final static String CHECK_SERVICING_PROVIDER_EXCEPTION = 'CheckServicingProviderExceptions'
    public final static String ENABLE_FUTURE_DATED_AUTH_BLOCKING = 'EnableFutureDatedAuthBlocking'
    public final static String APPEALS_ENHANCEMENT = 'AppealsEnhancement'
    public final static String CHECK_POLICY_PLAN_PROFILE = 'CheckPolicyPlanProfile'
    public final static String AUTO_PRINT_LETTERS = 'AutoPrintLetters'
    public final static String LETTER_FAX_MULTI_CLIENT = 'LetterFaxMultiClient'
    public final static String ENABLE_CREDENTIAL_VALIDATION = 'CheckCredentialValidation'
    public final static String DRAFT_JBPM_CALLS = 'DraftJBPMCalls'
    public final static String ENABLE_PHTHERAPY_CLAIMS_HISTORY = 'EnablePHTherapyClaimsHistory'


    public final static String FEDERATED_PLATFORM_ENDPOINT_UPDATES = 'FederatedPlatformEndpointUpdates'
    public final static String ENABLE_PH_THERAPY_UM = 'EnablePHTherapyUM'
    public final static String ENABLE_AUTO_DECISIONING = 'EnableAutoDecisioning'
    public final static String RULES_CHECK_BCBSSC_PROVIDER_OON = 'RulesCheckBCBSSCProvOON'

    // to deprecating unnecessary cascade methods
    public final static String DEAD_LOCK_CANCEL_AUTHOROZATION = 'DeadLockCancelAuthorization'
    public final static String CANCEL_REASON_DEAD_LOCK = 'CancelReasonDeadLock'
    public final static String REQUEST_DETAILS_DEAD_LOCK = 'RequestDetailsDeadLock'
    public final static String REGIMENS_DEAD_LOCK = 'RegimensDeadLock'

    // Preferred Drugs flags
    public final static String ENABLE_PREFERRED_DRUGS_ALL_AUTH_TYPES = 'EnablePreferredDrugsAllAuthTypes'
    public final static String ENABLE_PREFERRED_DRUGS_CHEMOTHERAPY = 'EnablePreferredDrugsChemotherapy'
    public final static String ENABLE_PREFERRED_DRUGS_SUPPORTIVE = 'EnablePreferredDrugsSupportive'
    public final static String ENABLE_PREFERRED_DRUGS_SUPPORTIVE_DETERRENCE = 'EnablePreferredDrugsSupportiveDeterrence'
    public final static String ENABLE_PREFERRED_DRUGS_SPECIALTY_PHARMACY = 'EnablePreferredDrugsSpecialtyPharm'
    public final static String ENABLE_PREFERRED_DRUGS_SPECIALTY_PHARMACY_DETERRENCE = 'EnablePreferredDrugsSpecialtyPharmDeterrence'
    public final static String ENABLE_PREFERRED_DRUGS_MAINTENANCE = 'EnablePreferredDrugsMaintenance'

    public final static String ENABLE_NONERISA_PAI = 'NonErisaPAI'
    public final static String ENABLE_SECURED_POLICY = 'EnableSecuredPolicy'
    public final static String ENABLE_NONERISA_TCC = 'NonErisaTCC'
    public final static String ENABLE_AUTH_NTF_V8 = 'enableauthNTFV8version'

   // Antiemetic Category Use Type Flag
    public final static String ENABLE_ANTIEMETIC_CATEGORY_USE_TYPE_SUPPORTIVE_DRUGS = 'addAntiemeticCategoryUseTypeDrugs'


    //ProviderContract Flags
    public final static String ENABLE_PROVIDER_DETAILS_FOR_AUTH_TYPE = 'EnableProviderDetailCallForCertainAuthType'

    public final static String ENABLE_HSC_DETAIL_V9 = 'enableHscDetailV9'
    public final static String ENABLE_HSC_MEMBER_SUMMARY_V9 = 'enableHscMemberSummaryV9'
    public final static String ENABLE_HSC_MEMBER_PROVIDER_V9 = 'enableHscMemberProviderV9'
    public final static String ENABLE_HSC_UPDATE_V2 = 'enableHscUpdateV2'

    public final static String CHECK_RX_CLAIM_PA = 'CheckRXPriorAuthAndClaim'

    public final static String ENABLE_CUSTOM_REASONS_SGP = 'EnableCustomReasonsSGP'
    public final static String ENABLE_CUSTOM_REASONS_CGP = 'EnableCustomReasonsCGP'
    public final static String ENABLE_SEND_CUSTOM_REASON_ICUE_SUPPORTIVE_CGP = 'EnableSendCustomReasonICUESupportiveCGP'
    public final static String ENABLE_GENRIC_RULE_SERVICE_V1 = 'enableGenericRuleV1'
    public final static String ENABLE_SGP_PREFERRED_SUPPLIER = 'enableBCBSSGPPreferredSupplier'

    public final static String ENABLE_ELASTIC_SEARCH = 'EnableElasticSearch'
    public final static String REMOVE_OON_FILTER_PROVIDER_SEARCH_CGP = 'RemoveOONFilterProviderSearchCGP'

    public final static String REQUEST_NICE_MEMBER_DATA = 'RequestNiceMemberData'


    public final static String ENABLE_WORK_QUEUE_ROUTING_RULES = 'EnableWorkQueueRoutingRules'
    public final static String ENABLE_EDIT_DRAFT_REQUEST_POPUP ='EnableEditDraftRequestPopup'

    public final static String MEMBER_BLOCKING = 'MemberBlocking'
    public final static String CGP_HIST_CLIN_VAR = 'CGPHistoryClinVar'

    public final static String ENABLE_OPTUM_CARE_USER_AUTH = 'enableOptumCareUserAuth'

    public final static String ENABLE_PREFIX_AUTHORIZATIONS = 'AddSRNPrefixAuth'

    public final static String ENABLE_RADONC_CLONING = 'EnableRadoncCloning'

    public final static String CHECK_THERAPY_AUTH_AUTO_DENIAL = 'CheckTherapyAuthAutoDenial'

    public final static String ENABLE_PH_DUPLICATE_ON_DECISIONED = 'enablePHDupAuthEndDateOnDecisioned'

    public final static String ENABLE_PH_DUPLICATE_AUTH_ADJUST_ON_PENDING = 'enablePHDupAuthAdjustOnPending'

    public final static String CHECK_THERAPY_AUTH_EXPERT_RULE = 'CheckTherapyAuthExpertRule'

    public final static String ENABLE_ECP_MEMBER_SUMMARY = 'enableECPMemberSummary'

    public final static String ENABLE_MULTIPLE_COVERAGES = 'EnableMultipleCoverages'

    public final static String ENABLE_PHARMACY_AUTHORIZATION_SEARCH = 'EnablePharmacyAuthorizationSearch'

    public final static String REQUEST_TYPE_LETTER_COLUMN = 'RequestTypeLetterColumn'

    public final static String ENABLE_HISTORICAL_COVERAGES = 'EnableHistoricalCoverages'

    public final static String ENABLE_PROVIDER_BLOCKING_RULES = 'ProviderBlocking'

    public final static String FEDERATED_FAX_LETTER = 'FederatedFaxLetter'

    public final static String ENABLE_THERAPY_HOME_CARE = 'EnablePHTherapyHomeCare'

    public final static String ENABLE_CGP_ANTIEMETIC_LOGIC ='EnableCGPAntiEmeticLogic'

    public final static String ENABLE_DUMMY_MEMBER_SEARCH = 'EnableDummyMemberSearch'

    public final static String ENABLE_CGP_MSO_LOGIC ='EnableCGPMSOLogic'
    public final static String ENABLE_HSC_OUTBOUND = 'MSOHscOutbound'
    public final static String ENABLE_SGP_HSC_OUTBOUND = 'SGPHscOutbound'
    public final static String ENABLE_SOC_DECISION_REASON = 'EnableSOCDecisionReason'

    public final static String ORIG_SYSTEMMEMBERIDTYPE_OXFORD = 'CR'
    public final static String ENABLE_TREATMENT_REGIMEN_VERSION_IN_STEPPER_SIGNAL ='EnableTreatmentRegimenVersionInStepperSignal'

    public final static String ENABLE_URGENT_LETTER_REQUEST = 'EnableUrgentLetterRequest'

    public final static String ENABLE_LETTER_ERROR_HANDLING = 'EnableLetterErrorHandling'

    public final static String LETTER_FAX_RECIPIENT_CONFIGURATION = 'LetterAndFaxRecipientConfiguration'

    public final static String ENABLE_MULTIPLE_CLIENT_AUTH_SEARCH = 'EnableMultipleClientAuthSearch'

    public final static String ENABLE_FDS_CLOUD_MIGRATION = 'enableFDSCloudMigration'

    public final static String DO_NOT_INVOKE_TAT_POINTS = 'DoNotInvokeTATPoints'

    // this will allow MBM to map/save multiple servicing providers from iCUE
    public final static String ALLOW_MSO_MULTIPLE_SERVICING_PROVIDERS = 'AllowMSOMultipleServicingProviders'

    public final static String ENABLE_OUT_PATIENT_FACILITY = 'EnableOutPatientFacility'

    public final static String ENABLE_OXFORD_MEMBER_SEARCH = 'enableOxfordMemberSearch'

    public final static String SPLIT_DECESION = 'EnableSplitDecision'

    public final static String ENABLE_OXFORD_PROVIDER_SEARCH = 'EnableOxfordProviderSearch'

    public final static String SPLIT_DECISION_OVERALL_STATUS = 'splitDecisionOverallStatus'
    //ORx Fusion API Integration Flags

    public final static String ENABLE_FUSION_INTEGRATION = 'EnableFusionIntegrationForSpecialtyBCBS'

    public final static String ENABLE_FUSION_CLIENT = 'EnableFusionClient'

    public final static String ENABLE_TRAVERSAL_CLIENT_ENHANCEMENT = 'EnableTraversalClientEnhancement'

    public final static String ENABLE_EPA_ORX_V2 = 'enableEPAV2'

    public final static String RETRY_AUTH_SUBMIT = 'retryAuthSubmit'

    public final static String ENABLE_PROC_BRAND_REFACTOR = 'enableProcBrandRefactor'

    public final static String ENABLE_SPECIALITY_PHARMACY_SUPPLEMENTORY_RESPONSE_CUSTOM = 'enableSpecPharSupResponseCustom'

    public final static String ENABLE_PH_THERAPY_CLONING = 'enablePHTherapyCloning'

    public final static String ENABLE_REGIMEN_MAINTENANCE_PROC_BRAND = 'enableRegimenMaintenanceProcBrand'

    public final static String BCBS_SGP_OSF_POS = 'enableBCBSSGPPlaceOfService'

    public final static String ENABLE_EPA_INTERGRATION_FOR_SPECIALTY_BCBS = 'enableEPAIntergrationForSpecialtyBCBS'
    public final static String ENABLE_DATE_RANGE_SUBMITTED_AUTH_SEARCH = 'enableDateRangeSubmittedAuthSearch'
    public final static String ENABLE_ORX_MEMBER_SEARCH = 'enableORXMemberSearch'

    public final static String RAD_ONC_EXISTING_AUTH_CHECK = 'RadOncExistingAuthCheck'
    public final static String FEDERATED_PLATFORM_TERMING_CONFIG = 'FederatedPlatformTermingConfig'

    public final static String ENABLE_URGENT_LETTER_REQUEST_FOR_ALL_CATEGORIES = 'EnableUrgentLetterRequestForAllCategories'

    public final static String MAP_MEMBER_COVERAGE_SET = 'mapMemberCoverageSet'

    public final static String ENABLE_CPT4_CODES_FOR_RAD_ONC_EXCEPTION = 'EnableCpt4CodesForRadOncException'

    public final static String ENABLE_MAP_UNIQUE_UNET_CONTRACT_LIST = 'mapUniqueUnetContractList'

    public final static String ENABLE_AUTH_PENDING_POPUP = 'EnableAuthPendingPopup'

    public final static String ENABLE_DRUG_POLICY_SEASON = 'enableDrugPolicySeasonDetails'

    public final static String ENABLE_NEW_DRUG_MANAGER_SCREEN = 'EnableNewDrugManagerScreen'

    public final static String ENABLE_SSB_UPDATE = 'FetchSSBDetailsforCirrusMembers'

    public final static String ENABLE_HSC_SERVICE_DETAIL_UPDATES = 'enableHscServiceDetailUpdates'
    public final static String ENABLE_REPROCESS_AUTH_ICUE_SYNC = 'EnableReprocessAuthIcueSync'

    public final static String TURN_OFF_EARLY_DECISIONING_FOR_TAT = 'turnOffEarlyDecisioningForTAT'

    public final static String INTERNAL_MEMBER_SEARCH = 'InternalMemberSearch'
    public final static String SET_CORE_MED_NEC_IND_CIRRUS_MEMBERS = 'setCoreMedNecIndCirrusMembers'

    public final static String ENABLE_SGP_CGP_AUTO_DECISION_RULES = 'EnableSgpCgpAutoDecisionRules'

    public final static String ENABLE_CAPTURE_PH_DECISIONS = 'EnableCapturePHDecisions'

    public final static String ENABLE_CLIENT_CONFIG_FOR_COMMUNICATION = 'EnableClientConfigForCommunication'

    public final static String BYPASS_JBPM_IN_TAT = 'BypassJBPMinTATWorkflow'

    public final static String BYPASS_JBPM_IN_UM_ACTIVITY = "BypassJBPMinUMActivity"

    public final static String ENABLE_SPLIT_SERVICE_PENDING_AUTH = 'EnableSplitServicePendingAuth'

    public final static String OSF_PRACTICE_NPI = 'OSFPracticeNPI'

    public final static String SEND_SSK_ESK_FOR_SSB_CALL = 'SendSSKandESKForSSBCall'
    public final static String ENABLE_MEMBER_REFRESH_FOR_BCBS = 'EnableMemberRefreshForBCBS'
    public final static String ENABLE_BCBS_MEMBER_COVERAGE_REFRESH = 'EnableBCBSMemberCoverageRefresh'

    public final static String SPLIT_OXFORD_BENEFITS_INTO_COVERAGES = 'SplitOxfordBenefitsIntoCoverages'

    public final static String ENABLE_MAINTAIN_REGIMEN_PROCEDURES_FOR_PROC_BRAND = 'enableMaintainRegimenProceduresForProcBrand'

    public final static String ENABLE_BCBS_WORKQUEUE_ROUTING_TO_RULESENGINE = 'EnableBcbsWorkQueueRoutingToRulesEngine'

    public final static String EXELA_AUTH_MEMBER_BLOCKING_ADMIN_DENIAL = 'exelaAuthMemberBlockingAdminDenial'

    public final static String EXELA_PROVIDER_BLOCKING = 'EnableExelaProviderBlocking'

    /**
     * This flag will instruct MBM to save any new services that were created in ICUE when syncing an HSC with ICUE.
     */
    public static final String ENABLE_SYNCHING_OF_NEW_ICUE_SERVICES = "syncNewServicesWithIcue"

    public final static String SGP_DOSAGE_REPORTING = 'sgpDosageReporting'

    public final static String ENABLE_PH_MULTIPLE_OTHER_ASSESSMENTS_FOM = 'EnablePHMultipleOtherAssessmentsFOM'

    public final static String ENABLE_PH_REQUEST_DETAILS_CHANGE = "EnablePHChangeForAuthDateAndSchldFreq"

    public final static String ENABLE_NETWORK_STATUS_DERIVATION_FOR_EXCHANGE = 'enableNetworkStatusDerivationForExchange'

    public final static String ENABLE_NETWORK_INFO_FOR_CIRRUS_MEMBERS = 'enableNetworkInfoForCirrusMembers'

    public final static String LIMIT_UNET_CONTRACT_TO_ACTIVE = 'limitUnetContractToActive'

    public final static String ENABLE_CLAIM_CHECK_FOR_ORX = 'enableClaimCheckForORX'

    public final static String ENABLE_DISEASE_STATE_ICD10_CODE = 'enableDiseaseStateICD10Code'

    public final static String ENABLE_LETTERS_DEDUP_CACHE = 'EnableLettersDedupCache'

    public final static String ENABLE_TCOC_FOR_TRAVERSALS= 'EnableTCoCForTraversals'

    public final static String ENABLE_CONCURRENT_AUTH_SEARCH= 'enableConcurrentAuthSearch'

    public final static String USE_DB_MEMBERS_WHEN_NOT_FOUND_VIA_API = 'useDBMembersWhenNotFoundViaAPI'

    public final static String ENABLE_PHARMACY_BENEFIT_FOR_AUTH = 'EnablePharmacyBenefitForAuth'

    /**
     * Determines whether or not the book of business filter will be displayed on the exceptions screen, and whether or
     * not exception logic will account for the book of business field.
     */
    public final static String DISPLAY_BOOK_OF_BUSINESS = 'displayBookOfBusiness'

    public final static String ENABLE_DELEGATION_OF_CARE = 'EnableDelegationOfCare'

    public final static String ENABLE_BENEFITS_SUPPORTIVE_DRUGS = 'EnableBenefitsSupportiveDrugs'

    public final static String MERGE_MULTIPLE_FUSION_RESPONSES = 'mergeMultipleFusionResponses'

    public final static String ENABLE_DRUG_STRENGTH_CANCER_SUPPORTIVE = 'enableDrugStrengthCancerSupportive'

    public final static String DISPLAY_REPORT_CODE = 'displayReportCode'

    public final static String ENABLE_AUTO_POPULATE_ADD_SERV_QUESTIONS = 'enableAutoPopulateAddServQuestions'

    public final static String ENABLE_ORAL_FUNCTIONALITY_UHC_EI_AND_EXCHANGES = 'EnableOralFunctionalityUhcEiAndExchanges'

    /**
     * Whether or not the state field used to retrieve traversal data should be determined by the traversal-state-field
     * federated config value or default to policy issue state.
     */
    public static final String USE_FEDERATED_CONFIG_FOR_TRAVERSAL_STATE = 'UseFederatedConfigForTraversalState'

    public final static String ENABLE_DEFAULT_HTTP_HEADERS = 'EnableDefaultHttpHeaders'

    public final static String ICUE_MEMBER_BLOCKING = 'ICUEMemberBlocking'

    public final static String DISPLAY_FUNDING_TYPE = 'displayFundingType'

    public final static String ENABLE_PARALLEL_STREAM_FILTER_OVERLAPPING_DATES_PH = 'EnableParallelStreamFilterOverlappingDatesPH'

    public final static String ENABLE_SGP_UHC_MEDICAID_MEMBER_ONBOARDING = 'sgpMedicaidCnsOnboarding'

    public final static String TRACK_PREDETERMINATION_CONVERSION = 'trackPredetConversion'

}
