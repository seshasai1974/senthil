package com.optum.app.shared.customer

import com.optum.rf.core.data.DataObject
import groovy.transform.CompileStatic

/**
 * Data object used for updating cust_user records. This DO should only contain those values that the
 * user can access and update through on their own such as selecting the default customer to be loaded.
 */
@CompileStatic
class CustomerUserSelectionDO extends DataObject {

    boolean selectedInd = false

}
