package com.optum.app.shared.constants

import groovy.transform.CompileStatic

@CompileStatic
class TatConstants {
    public static final String TAT_SUMMARY_RESPONSE = 'tatSummaryResponse'
    public static final String UR_JURIS_CLIENT = 'CL'
    public static final String TAT_CLIENT = 'tat_client'

    public static final String TATPOINTTYPE_NOTIFICATION = '01'
    public static final String TATPOINTTYPE_REQ_MORE_INFO = '02'
    public static final String TATPOINTTYPE_RECP_ALL_INFO = '03'
    public static final String TATPOINTTYPE_DECISION = '04'
    public static final String TATPOINTTYPE_WRITTEN_NOTICE = '05'
    public static final String TATPOINTTYPE_PROV_VERBAL_NOTICE = '06'
    public static final String TATPOINTTYPE_MEMBER_VERBAL_NOTICE = '07'
    public static final String TATPOINTTYPE_WRITTEN_NOTICE_EXTENSION_LETTER = '08'

    public static final String TATPERIODCATEGORYTYPEID_DECISION = '01'
    public static final String TATPERIODCATEGORYTYPEID_WRITTEN_NOTICE = '02'
    public static final String TATPERIODCATEGORYTYPEID_VERBALNOTICE = '03'
    public static final String TATPERIODCATEGORYTYPEID_CLIENT_DECISION = '08'

    public static final String PRODUCT_CATEGORY_TYPE_MEDICAID = '1'
    public static final String PRODUCT_CATEGORY_TYPE_MEDICARE = '2'
    public static final String PRODUCT_CATEGORY_TYPE_DUAL = '3'
    public static final String PRODUCT_CATEGORY_TYPE_COMMERCIAL = '4'

    public static final String PROCESS_TYPE_ST = 'ST'
    public static final String PROCESS_TYPE_MCARE = 'MCARE'
    public static final String PROCESS_TYPE_MCAID = 'MCAID'

    public static final String VENDOR_TYPE_ID_PAS = '2'
    //will need to check env properties
    public static final String CLINICAL_TAT_ENDPOINT = '/getSummary'
    public static final int TAT_READ_TIMEOUT = 20000
    public static final int TAT_CONNECT_TIMEOUT = 20000

    public static final String SERVICEDETAILTYPE__MENTALHEALTH = '1'
    public static final String SERVICEDETAILTYPE_SUBSTANCEABUSE = '33'
    public static final String SERVICEDETAILTYPE_PSYCHIATRIC = '6'

    public static final Map<String, String> ACTIVITY_TRIGGER_POINT_MAP = ['30':'03', '34':'03','29':'06','26':'07','23':'02','24':'02','22':'05','25':'05']
}
