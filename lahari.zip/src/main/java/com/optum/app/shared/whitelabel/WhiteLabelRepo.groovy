package com.optum.app.shared.whitelabel

import com.fasterxml.jackson.databind.JsonNode

interface WhiteLabelRepo {

    /** WhiteLabels are queried by name to make sure they can be queried across different environments
     * (test, stage, production) as ids can vary */
    Optional<JsonNode> findByName(String name)

    void save(String name, JsonNode whiteLabels)

    Set<String> savedNames()

}

