package com.optum.app.shared.authentication

import com.fasterxml.jackson.core.type.TypeReference
import com.fasterxml.jackson.databind.DeserializationFeature
import com.fasterxml.jackson.databind.ObjectMapper
import com.optum.app.ocm.controller.OcmLoginController
import com.optum.app.shared.constants.MultiPayerConstants
import com.optum.app.shared.constants.SpclCareFeatureFlagConstants
import com.optum.app.shared.eis.EISUtility
import com.optum.app.shared.policySecurity.businesslogic.UserPolicySecurity
import com.optum.app.shared.ssoauthentication.helper.OcmSsoHelper
import com.optum.eis.event.model.logClass
import com.optum.mbm.commonlogging.eis.logger.EISLogger
import com.optum.rf.common.constants.CommonFieldConstants
import com.optum.rf.common.controller.CommonViewMapping
import com.optum.rf.common.controller.ReturnConstants
import com.optum.rf.common.exception.RestrictedAccessException
import com.optum.rf.common.featureflag.util.FeatureFlagUtility
import com.optum.rf.common.messages.SecurityMessages
import com.optum.rf.common.security.businesslogic.Security
import com.optum.rf.common.security.data.UserSecurityVO
import com.optum.rf.common.util.CommonUtilities
import com.optum.rf.dao.constants.SystemSecurityConstants
import com.optum.rf.dao.controller.session.Session
import com.optum.rf.dao.controller.session.SessionThreadLocal
import com.optum.rf.dao.data.ValueObject
import com.optum.rf.dao.exception.UhgRuntimeException
import com.optum.rf.dao.security.UserSecurity
import com.optum.rf.web.constants.WebConstants
import com.optum.rf.web.controller.response.Response
import com.optum.rf.web.controller.session.HttpUserSession
import com.optum.rf.web.log.LogCreator
import com.optum.rf.web.util.ControllerUtilities
import com.optum.rf.ws.security.AuthoritiesHelper
import com.optum.app.common.customer.data.CustomerUserViewVO
import groovy.transform.CompileStatic
import org.apache.commons.lang.StringUtils
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.security.authentication.AuthenticationProvider
import org.springframework.security.authentication.AuthenticationServiceException
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken
import org.springframework.security.core.Authentication
import org.springframework.security.core.AuthenticationException
import org.springframework.web.servlet.ModelAndView
import org.springframework.web.servlet.mvc.Controller

import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse
import javax.servlet.http.HttpSession
import java.lang.reflect.Method

/**
 * Overriding rf framework to intercept the HttpSession created and implement multitenancy logic with Redis
 */

@CompileStatic
class LoginController extends OcmLoginController implements Controller {
    private Security security
    private Map<String, AuthenticationProvider> authenticationProviderMap
    private AuthoritiesHelper authoritiesHelper
    private static final Logger logger = LoggerFactory.getLogger(LoginController.class)

    @Autowired UserPolicySecurity userPolicySecurity
    @Autowired LogCreator logCreator
    @Autowired OcmSsoHelper ocmSsoHelper

    private ObjectMapper objectMapper = objectMapper()

    LoginController() {

    }

    final void setSecurity(Security security) {
        this.security = security
    }

    final void setAuthenticationProviderMap(Map<String, AuthenticationProvider> authenticationProviderMap) {
        this.authenticationProviderMap = authenticationProviderMap
    }

    void setRequiredAuthoritiesHelper(AuthoritiesHelper authoritiesHelper) {
        this.authoritiesHelper = authoritiesHelper
    }

    @Override
    ModelAndView handleRequest(HttpServletRequest httpRequest, HttpServletResponse httpResponse) {
        String viewPath
        Response response
        try {
            long startTime = System.currentTimeMillis()
            String permissionID
            response = new Response()
            HttpSession httpSession = httpRequest.getSession(true)
            String userID = httpRequest.getParameter(CommonFieldConstants.USERID)
            String reason
            if (!StringUtils.isBlank(userID)) {
                userID = userID.trim()
            }
            response.addResponseObject(CommonFieldConstants.USERID, userID)
            String password = httpRequest.getParameter(CommonFieldConstants.PASSWORD)
            String domain = httpRequest.getParameter(CommonFieldConstants.LOGINDOMAIN)

            ocmSsoHelper.populateDefaultSessionAttributes(httpRequest, httpSession)

            Session session = createSession(httpSession, userID, domain)

            if (FeatureFlagUtility.getManager()?.isActive(SpclCareFeatureFlagConstants.ENABLE_SECURED_POLICY)) {
                if(userID){
                    session.setAttribute('userPolicies', userPolicySecurity.readUserPolicy(userID.toLowerCase()))
                }
            }
            SessionThreadLocal?.setSession(session)
            try {
                ControllerUtilities.validateLoginIsPost(httpRequest)

                AuthenticationProvider authProvider = authenticationProviderMap.get(domain)
                if (authProvider == null) {
                    throw new AuthenticationServiceException('No configured AuthenticationProvider for domain: ' + domain)
                }

                Authentication authentication = authProvider.authenticate(new UsernamePasswordAuthenticationToken(userID, password))

                // user is authenticated at this point but need to check if the system is restricting
                // access at this time.
                UserSecurity userSecurity = security.getUserSecurityVO(userID)
                httpSession.setAttribute('permissionGroups', objectMapper.writeValueAsString(userSecurity.getPermissionGroups()))
                // valid log on, set the security session attribute
                viewPath = setSessionAndSuccessView(httpRequest, httpSession, userSecurity)
                response.addResponseObject(ReturnConstants.USERPROFILEVO,security.buildUserProfileVO(userID))

                // now add ldap permission groups
                addLdapPermissionGroupsToSession(authentication)
                permissionID = SystemSecurityConstants.SUCESS_LOGIN_PERMISSIONID

                // Check if user has access to payer
                verifyUserAccess(httpSession)
            } catch (RestrictedAccessException rae) {
                ValueObject errorVO = new ValueObject()
                errorVO.addGlobalMessage(SecurityMessages.ERR_ACCESS_RESTRICTED)
                response.addResponseObject(WebConstants.EMPTYVO, errorVO)
                viewPath = CommonViewMapping.SIGN_ON_MAIN.getPath()+ '?errorMessage=' + CommonUtilities.getMessageString(errorVO)
                permissionID = SystemSecurityConstants.FAILURE_LOGIN_PERMISSIONID
            } catch (UhgRuntimeException ue) {
                ValueObject errorVO = ue.getErrorVO()
                response.addResponseObject(WebConstants.EMPTYVO, errorVO)
                viewPath = CommonViewMapping.SIGN_ON_MAIN.getPath()+ '?errorMessage=' + CommonUtilities.getMessageString(errorVO)
                permissionID = SystemSecurityConstants.FAILURE_LOGIN_PERMISSIONID
            } catch (AuthenticationException e) {
                ValueObject errorVO = new ValueObject()
                errorVO.addGlobalMessage(SecurityMessages.ERR_AUTHENTICATION_FAILED)
                response.addResponseObject(WebConstants.EMPTYVO, errorVO)
                viewPath = CommonViewMapping.SIGN_ON_MAIN.getPath()+ '?errorMessage=' + CommonUtilities.getMessageString(errorVO)
                permissionID = SystemSecurityConstants.FAILURE_LOGIN_PERMISSIONID
            }
            logUserAction(startTime, permissionID, response, userID, httpRequest)
            response.addResponseObject(ControllerUtilities.LAST_USER_ACTIVITY_LOG, SessionThreadLocal.getSession().getUserActivityLogID())
            ControllerUtilities.setCacheControlHeaders(httpRequest, httpResponse, false, 0, true, false)
            if (FeatureFlagUtility.getManager().isActive(SpclCareFeatureFlagConstants.ENABLE_EIS_LOGGING)) {
                //Queue for EIS Streaming
                if (permissionID == SystemSecurityConstants.SUCESS_LOGIN_PERMISSIONID) {
                    //Login Success
                    queueForEISStream(logClass.SECURITY_SUCCESS, EISUtility.getUserDetails(httpRequest, "SUCCESS"))
                } else {
                    //Login Failure
                    reason = ((ValueObject)response.getResponseObject(WebConstants.EMPTYVO)).globalMessages[0]
                    queueForEISStream(logClass.SECURITY_FAILURE, EISUtility.getUserDetails(httpRequest,  reason))
                }
            }
        } finally {
            SessionThreadLocal?.removeSession()
        }

        return new ModelAndView(viewPath, response.getResponseObjects())
    }

    private static void queueForEISStream(logClass logclass, HashMap<String, String> userDetails) {
        try {
            Method handlerMethod = LoginController.getMethods().find({ method -> method.name == "handleRequest" })
            EISLogger.AuditLog(handlerMethod, EISUtility.getSSLProps(), logclass, userDetails)
        }
        catch (Exception e) {
            logger.debug("Error invoking EISLogger", e)
        }
    }

    private static Session createSession(HttpSession httpSession, String userID, String domain) {
        Session session = new HttpUserSession(httpSession)
        UserSecurityVO userSecurityVO = new UserSecurityVO()
        userSecurityVO.setUserID(userID)
        session.setUserSecurity(userSecurityVO)
        session.setUserTimeZone((TimeZone) httpSession.getAttribute(WebConstants.TIME_ZONE_OFFSET))
        session.setDomain(domain)
        return session
    }

    /**
     * Add groups from ldap that the user is a member of
     * to the list of permission groups in security
     * context contained within the session.
     *
     * @param authentication authentication provider
     */
    private void addLdapPermissionGroupsToSession(Authentication authentication) {
        Session session = SessionThreadLocal.getSession()
        if (session != null) {
            UserSecurity userSecurity = session.getUserSecurity()
            if (userSecurity != null) {
                userSecurity.getPermissionGroups().addAll(authoritiesHelper.getUserPermissionGroups(authentication.getAuthorities()))
            }
        }
    }

    ObjectMapper objectMapper(){
        ObjectMapper objectMapper = new ObjectMapper()
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
        objectMapper
    }

    // Checks if user has access to the payer
    private void verifyUserAccess(HttpSession session) {
        if (session != null) {
            boolean isBcbsEnv = System.getProperty(MultiPayerConstants.APPROVAL_TYPE) == MultiPayerConstants.CUSTOMER_ID_BCBSSC.toString()
            List<CustomerUserViewVO> customerUserViewVOS = objectMapper.readValue(session.getAttribute('customerUserVOs') as String, new TypeReference<List<CustomerUserViewVO>>(){}) as List<CustomerUserViewVO>

            if (!customerUserViewVOS.any { CustomerUserViewVO customerUser ->
                    isBcbsEnv && customerUser.customerID == MultiPayerConstants.CUSTOMER_ID_BCBSSC ||
                    !isBcbsEnv && customerUser.customerID != MultiPayerConstants.CUSTOMER_ID_BCBSSC }) {
                throw new UhgRuntimeException(SecurityMessages.ERR_INVALID_USERID)
            }
        }
    }

    void logUserAction(long startTime, String permissionID, Response response, String userID, HttpServletRequest httpServletRequest) {
        try {
            this.logCreator.createLogWithNewTransaction((int)(System.currentTimeMillis() - startTime), ControllerUtilities.buildHttpRequest(httpServletRequest, permissionID), response, SessionThreadLocal.getSession().getDatabaseTransactionCountAndReset())
        } catch (Exception e) {
            logger.error('Error creating user activity log entry for permissionID: ' + permissionID + ' userID: ' + userID)
        }
    }

}
