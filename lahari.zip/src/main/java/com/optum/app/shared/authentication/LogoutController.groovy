package com.optum.app.shared.authentication

import com.optum.app.ocm.controller.support.CommonResponse
import com.optum.app.ocm.controller.ui.base.ExceptionHandlingController
import com.optum.app.shared.constants.SpclCareConstants
import com.optum.app.shared.eis.EISUtility
import com.optum.eis.event.model.logClass
import com.optum.mbm.commonlogging.eis.logger.EISLogger
import org.apache.commons.logging.Log
import com.optum.app.shared.customlog.LogFactory
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.ResponseBody
import org.springframework.web.bind.annotation.RestController

import javax.servlet.http.HttpServletRequest
import java.lang.reflect.Method

@RestController
@RequestMapping(SpclCareConstants.AUTHENTICATION_BASE)
class LogoutController extends ExceptionHandlingController {
    private static final Log log = LogFactory.getLog(LogoutController)

    /**
     * Method to queue EIS Streaming & send a response back to UI
     * @param httpRequest To capture the user-agent details
     * @return logout stream successful/failed
     */
    @PostMapping(path = SpclCareConstants.AUTHENTICATION_LOGOUT)
    @ResponseBody
    CommonResponse streamEIS(HttpServletRequest httpRequest) {
        new CommonResponse().setEmbedded(queueStreaming(EISUtility.getUserDetails(httpRequest, null)))
    }

    /**
     * Helper method to invoke EISLogger
     * @param userDetails contains user-agent details
     * @return stream status message
     */
    private String queueStreaming(HashMap<String, String> userDetails) {
        userDetails.put("isLogout", "yes")
        try {
            Method handlerMethod = LogoutController.getMethods().find({ method -> method.name == "streamEIS" })
            EISLogger.AuditLog(handlerMethod, EISUtility.getSSLProps(), logClass.SECURITY_SUCCESS, userDetails)
            return "Logout Stream Successful"
        }
        catch (Exception e) {
            log.debug("Error invoking EISLogger", e)
            return "Logout Stream Failed"
        }
    }
}
