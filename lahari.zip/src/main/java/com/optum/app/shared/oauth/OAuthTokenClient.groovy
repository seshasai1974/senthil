package com.optum.app.shared.oauth

import com.optum.app.shared.oauth.data.OAuthToken
import com.optum.rf.core.annotation.InjectedBean
import org.springframework.http.HttpHeaders

@InjectedBean
public interface OAuthTokenClient {

    /**
     * Get the Layer 7 token for the web service with the given ID using client credentials grant type.
     * @param webServiceID The ID of the web service for which to retrieve a OAuth token.
     * @return A OAuthToken object to authenticate against the webservice with the given ID.
     */
    OAuthToken getToken(String webServiceID)

    /**
     * Get the Layer 7 token from the given trustbroker using the given client ID and secret using client credentials
     * grant type.
     * @param trustBrokerURL The URL for the trustbroker from which to retrieve the layer 7 token.
     * @param clientId The client ID for which to retrieve the layer 7 token.
     * @param clientSecret The client secret for which to retrieve the layer 7 token.
     * @return A OAuthToken object to use for authentication.
     */
    OAuthToken getToken(String trustBrokerURL, String clientId, String clientSecret)

    /**
     * Build an HttpHeaders object for calling the web service with the given ID including the OAuth authentication
     * components.
     * @param webServiceID The ID of the web service for which to retrieve the HTTP headers.
     * @return An HttpHeaders object for calling the web service with the given ID.
     */
    HttpHeaders buildWebServiceHeaders(String webServiceID)

}
