package com.optum.app.shared.whitelabel

import com.optum.app.shared.common.groovy.ModuleDto;

@ModuleDto
class WLCustomerModel {
    String organizationName
    String customerName
    Integer customerId
}
