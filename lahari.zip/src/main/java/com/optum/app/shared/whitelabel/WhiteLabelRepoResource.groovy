package com.optum.app.shared.whitelabel

import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.databind.ObjectMapper
import org.springframework.core.io.support.PathMatchingResourcePatternResolver

class WhiteLabelRepoResource implements WhiteLabelRepo {

    private final ObjectMapper objectMapper = new ObjectMapper()
    private final String path

    WhiteLabelRepoResource(String path) {
        this.path = path
        Objects.nonNull(this.path)
    }

    @Override
    Optional<JsonNode> findByName(String name) {
        return Optional.ofNullable(readJsonResource(name))
    }

    @Override
    void save(String name, JsonNode whiteLabels) {
        throw new UnsupportedOperationException(
                "These values can only be modified by developers because this repository uses hardcoded json files"
        )
    }

    private JsonNode readJsonResource(String name) {
        InputStream inputStream = getClass()
                .getClassLoader()
                .getResourceAsStream(path + name + ".json")

        if(inputStream == null) {
            return null
        }

        JsonNode whiteLabels = objectMapper.readValue(inputStream, JsonNode.class)
        Objects.requireNonNull(whiteLabels)

        return whiteLabels
    }

    Set<String> savedNames() {
        def list = new HashSet<String>()

        PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver()
        def resources = resolver.getResources("classpath*:" + path + "*.json")

        for(int i = 0; i < resources.length; i++) {
            def filename = resources[i].getFilename()
            def name = filename.substring(0, filename.length() - 5)
            list.add(name)
        }

        return list
    }

}
