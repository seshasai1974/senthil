package com.optum.app.shared.whitelabel

class ForbiddenWordsRepoInMemory implements ForbiddenWordsRepo {

    private final HashMap<String, List<String>> nameToWhiteLabels = new HashMap<>()

    @Override
    List<String> findByName(String customerName) {
        return nameToWhiteLabels.getOrDefault(customerName, new ArrayList<>())
    }

    @Override
    void save(String customerName, List<String> forbiddenWords) {
        nameToWhiteLabels.containsKey(customerName)
        nameToWhiteLabels.put(customerName, forbiddenWords)
    }
}
