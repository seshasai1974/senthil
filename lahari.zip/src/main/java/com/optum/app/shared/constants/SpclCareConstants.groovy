package com.optum.app.shared.constants

import com.google.common.collect.ImmutableMap
import com.optum.mbm.membereligibility.shared.constants.ReferenceConstants
import groovy.transform.CompileStatic

@CompileStatic
class SpclCareConstants {

    public static final String TEST = 'test'

    //member detail request constants
    public static final String MBR_DETAILS_CDB_XREF_ID = '45'
    public static final String MBR_DETAILS_BRANDING_TYPES = 'Name-20'
    public static final String MBR_DETAILS_BLS_ELIGIBILITY_IND = 'Y'
    public static final String MBR_DETAILS_APPLICATION_NAME = 'CCR'
    public static final String MBR_DETAILS_APPLICATION_INSTANCE_NAME = 'CCR'
    public static final String MBR_DETAILS_LOG_LEVEL = 'DEBUG'
    public static final String MBR_DETAILS_ROLE_ID = 'CCR'
    public static final String MBR_DETAILS_USER_ID = '90239'
    public static final String MBR_DETAILS_APPLICATION_ID = 'CCR'
    public static final String MBR_DETAILS_ATTRIBUTE_SET = 'detail_0002'
    public static final String MBR_DETAILS_PROJECT_ID = 'CTB'
    public static final String MBR_DETAILS_REQUEST_COVERAGE_TYPE = 'M'
    public static final String MBR_DETAILS_REQUEST_EXPANDED_DATA_IND = 'E'
    public static final String MBR_DETAILS_REQUEST_HEALTH_SERVICES = 'ALL'
    public static final Boolean MBR_DETAILS_REQUEST_MEMBER_POPULATION = true
    public static final String MBR_DETAILS_REQUEST_PLAN_VARITATION_TEXT_DESCRIPTION = 'Y'
    public static final String PROV_CONTRACT_STATUS = 'Y'
    public static final String ELIGIBILITYSYSTEMTYPEID_CSPFACETS = 'A9'
    public static final String MBR_SUMMARY_MAX_RECORD_COUNT = '100'
    public static final String MBR_SUMMARY_MAX_DATE = '9999-12-31'
    public static final String MBR_SUMMARY_MIN_DATE = '1970-01-01'
    public static final String MBR_SUMMARY_DATE_PATTERN = 'yyyy-MM-dd'
    public static final String MBR_SUMMARY_COVERAGE_TYPE = 'M'

    public static final String DATE_TIME_PATTERN = "yyyy-MM-dd'T'HH:mm:ss'Z'"
    public static final String DATE_PATTERN = "yyyy-MM-dd"

    // constants used for linking with OAM
    public static final String OAM_ASMT_CHAR_CANCER_TYPE = 'Cancer Type'
    public static final String OAM_QUEST_CHAR_CLINICAL_VARIABLE_TYPE = 'Clinical Variable Type'
    public static final String OAM_SUPPORTIVE_CARE_CUSTOM = 'custom'
    public static final String OAM_SUPPORTIVE_CARE_AUTO_APPROVE = 'auto-approve'
    public static final String OAM_QUES_CHAR_TREATMENT_SITE = 'Treatment Site'
    public static final String OAM_QUES_CHAR_ORIGIN_SITE = 'Origin Site'
    public static final String OAM_QUES_CHAR_PREV_RAD_THERAPY = 'Prev RadTherapy'
    public static final String OAM_QUES_CHAR_PREV__BRAIN_RAD_THERAPY = 'Prev Whole Brain RadTherapy'
    public static final String MSTAGE = 'M Stage'

    //AE Risks from OAM responses
    public static final String OAM_SUPPORTIVE_CARE_ANTI_EMETIC_RISK = 'ae-risk'
    public static final String OAM_SUPPORTIVE_CARE_AE_HIGH_RISK = 'HIGH'
    public static final String OAM_SUPPORTIVE_CARE_AE_MODERATE_RISK = 'MODERATE'
    public static final String OAM_SUPPORTIVE_CARE_AE_LOW_RISK = 'LOW'
    public static final String OAM_SUPPORTIVE_CARE_AE_BTNV = 'BTNV'

    public static final String OAM_AUTH_DURATION_DAYS = 'DAYS'
    public static final String OAM_AUTH_DURATION_WEEKS = 'WEEKS'
    public static final String OAM_AUTH_DURATION_MONTHS = 'MONTHS'
    public static final String OAM_AUTH_DURATION_DAY = 'DAY'
    public static final String OAM_AUTH_DURATION_WEEK = 'WEEK'
    public static final String OAM_AUTH_DURATION_MONTH = 'MONTH'
    public static final List<String> OAM_AUTH_DURATION_TYPES = [OAM_AUTH_DURATION_DAYS, OAM_AUTH_DURATION_WEEKS, OAM_AUTH_DURATION_MONTHS, OAM_AUTH_DURATION_DAY, OAM_AUTH_DURATION_WEEK, OAM_AUTH_DURATION_MONTH]
    public static final int SPECIALTY_PHARMACY_DEFAULT_AUTH_DURATION_CONTINUATION = 12
    public static final int SPECIALTY_PHARMACY_DEFAULT_AUTH_DURATION_INITIAL = 6
    public static final int SPECIALTY_PHARMACY_AUTH_DURATION_GRACE_MONTH = 1
    public static final int SPECIALTY_PHARMACY_AUTH_DURATION_GRACE_DAYS = 28
    public static final int SPECIALTY_PHARMACY_AUTH_DURATION_SOC_WEEKS = 26
    public static final int SPECIALTY_PHARMACY_AUTH_DURATION_SOC_DAYS = 183
    public static final int SPECIALTY_PHARMACY_GRACE_AUTH_DURATION_WEEKS = 4
    public static final int SPECIALTY_PHARMACY_DEFAULT_AUTH_DURATION_GRACE = 30
    public static final int SPECIALTY_PHARMACY_BCBS_DEFAULT_AUTH_DURATION = 12
    public static final int AUTH_FUTURE_DATE_MAX_DAYS = 59
    public static final String DRUG_POLICY_DISEASE_STATE_OTHER = 'Other'

    //HscSummary Call check
    public static final String ACCEPTED_PROCEDURE_CODES_FOR_TERM_CHECK = 'AccProcCodeForTerm'
    public static final String ROLE_INTERNAL_OPERATIONS = 'INTERNAL OPERATIONS'
    public static final String ROLE_OPERATIONS_MANAGER = 'OPERATIONS MANAGER'
    public static final String ROLE_PROVIDER = 'PROVIDER'
    public static final String ROLE_NURSE = 'NURSE'
    public static final String ROLE_UHC_ONCOLOGY = 'UHC ONCOLOGY'
    public static final String ROLE_GUIDELINE_REVIEWER = 'GUIDELINE REVIEWER'
    public static final String ROLE_GUIDELINE_CONFIGURATION = 'GUIDELINE CONFIGURATION'
    public static final String ROLE_MBM_OCM_ADMIN = 'MBM OCM ADMIN'
    public static final String ROLE_ADMINISTRATOR = 'ADMINISTRATOR'
    public static final String ROLE_APPEALS = 'APPEALS'

    // traversal maintenance
    public static final String PERMISSION_TRAVERSAL_APPROVAL = 'TRAVERSAL_APPROVAL'
    public static final String PERMISSION_TRAVERSAL_DEPLOYMENT = 'TRAVERSAL_DEPLOYMENT'

    //GenericRuleService Decision Type Check
    public static final String DECISION_VALUE_TYPE_CONTINUE = 'CONTINUE'
    public static final String DECISION_VALUE_TYPE_EVICORE = 'EVICORE'
    public static final String DECISION_VALUE_TYPE_AUTH_NOT_REQUIRED = 'AUTH NOT REQUIRED'
    public static final String DECISION_VALUE_TYPE_AUTH_REQUIRED = 'AUTHREQUIRED'
    public static final String DECISION_VALUE_TYPE_SRVC_NOT_FOUND = 'Service is not found'
    public static final String DECISION_VALUE_TYPE_STOP = 'STOP'
    public static final String DECISION_VALUE_TYPE_AUTH_NOT_ALLOWED = 'Auth Not Allowed'
    public static final String DECISION_VALUE_TYPE_PREDETERMINATION = 'Predetermination'
    public static final String DECISION_VALUE_TYPE_CA_SPECIAL = 'CASPECIAL'
    public static final String DECISION_VALUE_TYPE_ALLOW_OON = 'AllowOON'
    public static final String DECISION_VALUE_TYPE_SGP_AUTH_NOT_REQUIRED = "SGPAuthNotRequired"
    public static final String DECISION_VALUE_TYPE_SGPPRED = "SGPPreD"
    public static final String DECISION_VALUE_TYPE_UHC_INTAKE = "UHCIntake"
    public static final String DECISION_VALUE_TYPE_OXFORD = "Oxford"

    public static final String RESPONSE_STATUS_SUCCESS = 'Success'
    public static final String MESSAGE_EVICORE = 'Authorizations for this member either aren’t required or can’t be processed through this application. Please access uhcprovider.com or call the number on back of member’s card if you have questions.'
    public static final String MESSAGE_AUTH_NOT_REQUIRED = "An authorization cannot be requested through this application based on the member’s health plan and/or authorization type. Please contact the number on the back of the member’s insurance card to determine if an authorization is required for this member through another application/program."
    public static final String MESSAGE_AUTH_NOT_REQUIRED_POPUP = 'authNotReqPopup'
    public static final String MESSAGE_CA_SPECIAL = 'Authorization cannot be provided by UnitedHealthcare for this member.  Please contact the County CCS program to refer this member and request  Service Authorization Request (SAR) from CCS.'
    public static final String MESSAGE_AUTH_NOT_ALLOWED = "An authorization is not allowed for this member based on the member’s health plan. Please contact the number on the back of the member's insurance card for additional questions."
    public static final String MESSAGE_AUTHBLOCK_SGP_AUTH_NOT_REQUIRED = "An authorization is not required for this member based on the member’s health plan. Please contact the number on the back of the member's insurance card for additional questions."
    public static final String MESSAGE_AUTHBLOCK_SGPPRED = "sgpAuthPredeterminationPopup"
    public static final String MESSAGE_AUTHBLOCK_UHC_INTAKE = "An authorization for this member needs to be obtained by contacting UHC Intake at 877-842-3210"
    public static final String MESSAGE_AUTHBLOCK_OXFORD = "An authorization for this member needs to be obtained by contacting Oxford at 800-666-1363"
    public static final String MESSAGE_BLOCK_NOTIFY_THERAPY_AUTH = "Provider is ineligible to submit for a Therapy authorization"

    // generic drug codes for any new drug not in hcpcs table
    public static final String GENERIC_NEW_DRUG_CODE_J9999 = 'J9999'
    public static final String GENERIC_NEW_DRUG_CODE_J3490 = 'J3490'
    public static final String GENERIC_NEW_DRUG_CODE_J3590 = 'J3590'
    public static final String GENERIC_RADIOPHARMA_DRUG_CODE = 'A9699'
    public static final String GENERIC_NEW_DRUG_CODE_C9399 = 'C9399'

    public static final String SYSTEMTYPE_HSR = "00"

    public static final String PAGE_ID = "pageID"
    public static final String PRIOR_AUTH_SEARCH_SUBMITTED = "PASS"
    public static final String DASHBOARD_PRIOR_AUTH_SUBMITTED = "DPAS"

    public static final List<String> PEQUOT_UM_POLICIES = Collections.unmodifiableList(Arrays.asList('00003012', '00003071', '00003154', '00003825', '00003065', '00003788', '00003786', '00003740', '00003557', '00004186'))

    //PHS Fields
    public static final int PHS_COMPANY_CODE = 1
    public static final int PHS_SUBSCRIBER_ID = 2
    public static final int PHS_MEMBER_SUFFIX = 3

    // Text Field Labels
    public static final String MEMBER_FIRST_NAME_TEXT = 'Member First Name'
    public static final String MEMBER_LAST_NAME_TEXT = 'Member Last Name'
    public static final String SUBSCRIBER_ID_TEXT = 'Subscriber ID'

    // REGEX Patterns
    public static final String REGEX_VALIDATE_NAME = "[^a-zA-Z,'*-]"
    public static final String REGEX_ALPHA_NUMERIC_DASH = "[^a-zA-Z0-9-]"

    public static final String YES = 'Y'
    public static final String NO = 'N'

    //plan codes
    public static final String POLICY_NAME_AP = 'AP'
    public static final String POLICY_NAME_CO = 'CO'
    public static final String POLICY_NAME_CS = 'CS'
    public static final String POLICY_NAME_PA = 'PA'
    public static final String POLICY_NAME_CR = 'CR'

    public static final List<String> COVERAGE_TYPE_MEDICAL = ['M', 'ME', 'MS', 'MC', 'MH']
    public static final List<String> COVERAGE_TYPE_BEHAVIOR = ['B']

    public static final List<String> MAPPED_COVERAGE_TYPE_CODES = COVERAGE_TYPE_MEDICAL + COVERAGE_TYPE_BEHAVIOR
    public static final String OBLIGOR_MEDICA = '02'

    public static final String OXFORD_M_AND_R_PANEL_ID_150 = '150'
    public static final String OXFORD_M_AND_R_PANEL_ID_151 = '151'
    public static final String OXFORD_M_AND_R_LEGAL_ENTITY_ID_01253 = '01253'
    public static final String OXFORD_M_AND_R_LEGAL_ENTITY_ID_01307 = '01307'
    public static final String OXFORD_M_AND_R_LEGAL_ENTITY_ID_01308 = '01308'
    public static final String OXFORD_M_AND_R_LEGAL_ENTITY_ID_01309 = '01309'
    public static final String OXFORD_M_AND_R_LEGAL_ENTITY_ID_01310 = '01310'

    public static final List<String> OXFORD_M_AND_R_LEGAL_ENTITY_LIST = [OXFORD_M_AND_R_LEGAL_ENTITY_ID_01253, OXFORD_M_AND_R_LEGAL_ENTITY_ID_01307, OXFORD_M_AND_R_LEGAL_ENTITY_ID_01308, OXFORD_M_AND_R_LEGAL_ENTITY_ID_01309, OXFORD_M_AND_R_LEGAL_ENTITY_ID_01310]

    public static final String CIP_M_AND_R_LEGAL_ENTITY_ID_02003 = '02003'
    public static final String CIP_M_AND_R_LEGAL_ENTITY_ID_02004 = '02004'
    public static final String CIP_M_AND_R_LEGAL_ENTITY_ID_02006 = '02006'
    public static final String CIP_M_AND_R_LEGAL_ENTITY_ID_02002 = '02002'
    public static final String CIP_M_AND_R_LEGAL_ENTITY_ID_02005 = '02005'
    public static final String CIP_M_AND_R_LEGAL_ENTITY_ID_02073 = '02073'

    public static final List<String> CIP_M_AND_R_LEGAL_ENTITY_LIST = [CIP_M_AND_R_LEGAL_ENTITY_ID_02003, CIP_M_AND_R_LEGAL_ENTITY_ID_02004, CIP_M_AND_R_LEGAL_ENTITY_ID_02006, CIP_M_AND_R_LEGAL_ENTITY_ID_02002, CIP_M_AND_R_LEGAL_ENTITY_ID_02005, CIP_M_AND_R_LEGAL_ENTITY_ID_02073]

    public static final String NO_SHARED_ARRANGEMENT = '00'
    public static final String ADDENDUM_OR_NETWORK_ALLIANCE_PASSPORT = '03'

    public static final String POLICY_NUMBER_30500 = '30500'
    public static final String SFL_LEGAL_ENTITY_ID_02007 = '02007'
    public static final String SFL_LEGAL_ENTITY_ID_02008 = '02008'

    public static final String LEGALENTITYNAME_OXFORD_HEALTH_INSURANCE = '58545'
    public static final String LEGALENTITYNAME_UHC_PLAN_RIVERVALLEY = '55600'
    public static final String LEGALENTITYNAME_UHC_INSURANCE_COMPANY_RIVERVALLEY = '33600'
    public static final String LEGALENTITYNAME_NEIGH_HEALTH_PARTNERS = '55215'

    public static final String PROCEDUREFREQUENCY_DAYS = '1'
    public static final String PROCEDUREFREQUENCY_WEEKS = '2'
    public static final String PROCEDUREFREQUENCY_MONTHS = '3'
    public static final String PROCEDUREFREQUENCY_OTHER = '4'
    public static final String PROCEDUREFREQUENCY_TIMES = '7'

    public static final String DRUGUNITOFMEASURETYPE_INJECTIONS = '1'
    public static final String DRUGUNITOFMEASURETYPE_MG = '2'
    public static final String DRUGUNITOFMEASURETYPE_MG_PER_KG = '3'
    public static final String DRUGUNITOFMEASURETYPE_UNITS = '4'
    public static final String DRUGUNITOFMEASURETYPE_UNITS_PER_KG = '5'
    public static final String DRUGUNITOFMEASURETYPE_UNITS_PER_METER_SQUARED = '6'
    public static final String DRUGUNITOFMEASURETYPE_MCG_PER_KG = '7'
    public static final String DRUGUNITOFMEASURETYPE_MCG_PER_METER_SQUARED = '8'
    public static final String DRUGUNITOFMEASURETYPE_MILLILITERS = '9'
    public static final String DRUGUNITOFMEASURETYPE_GRAMS = '10'
    public static final String DRUGUNITOFMEASURETYPE_INTERNATIONAL_UNITS = '11'
    public static final String DRUGUNITOFMEASURETYPE_MCG = '12'
    public static final String DRUGUNITOFMEASURETYPE_MG_PER_METER_SQUARED = '13'


    public static final int ICUE_MAX_PROCEDURE_UNIT_COUNT = 9999
    public static final double CENTIMETERS_PER_INCH = 2.54
    public static final double KILOGRAMS_PER_POUND = 0.453592
    public static final double MICROGRAMS_PER_MILLIGRAM = 1000.0

    public static final String ON_PATHWAY_ACTIVITY = '35'

    public static final String WORK_QUEUE_TYPE = 'workType'
    public static final String MY_WORK_QUEUE_TYPE = 'myWork'
    public static final String ASSIGNMENT_STATUS_OPEN = '1'

    //JBPM EVENT Types
    public static final int JBPM_EVENT_TAT = 1
    public static final int JBPM_EVENT_ACTIVITIES = 2

    public static final String TAT_SUMMARY_RESPONSE = 'tatSummaryResponse'

    public static final String FIELDLABELID_ASGN_DESCRIPTOR = '1'
    public static final String FIELDLABELID_ASGN_STATUS = '2'
    public static final String FIELDLABELID_ASGN_PRIORITY = '3'
    public static final String FIELDLABELID_ASGN_DUE_DT = '4'
    public static final String FIELD_LABELID_ASSIGNEDTO = '5'

    public static final String TASK_DESCRIPTION = "itemTaskDescriptor"
    public static final String ITEM_STATUS_TYPE = "itemTaskStatus"
    public static final String PRIORITY_TYPE = "itemTaskPriority"
    public static final String FIELDLABEL_ID = "fieldLabelId"

    public static final String DECISION_STATUS_TYPE_YES = "1"
    public static final String DECISION_STATUS_TYPE_NO = "0"

    //Response from PAInitiation Request
    public static final String RESPONSE_PAINITIATIONREQUEST_ACK = "Success"
    //Response from PAApproved Ack
    public static final String RESPONSE_PAAPPROVED_ACK = "Success"
    //Response from PAResponseDeniedAck
    public static final String RESPONSE_PA_RESPONSE_ACK = "Success"
    //Response with Denied Status
    public static final String RESPONSE_PA_DENIED_ACK = "Denied"
    //Response with Approved Status
    public static final String RESPONSE_APPROVED = "Approved"

    public static final String PRIMARY_ADDRESS_TYPE = '1'
    public static final String IS_CURRENT = 'isCurrent'

    public static final String SERVICE_REF_NUMBER_PREFIX = "SC"
    public static final char SERVICEREFNUM_SEQ_LOGIC_PREFIX_CHAR = '0'
    public static final String SERVICE_REF_NUMBER_SYS_KEY = "service_ref_num"
    public static final String BCBS_SC = "bcbssc"
    public static final String UHC = "uhc"

    public static final String CONSUMER_APP_ID = 'MBM'
    public static final String CONSUMER_APP_TYPE = 'IA'
    public static final String RX_CLAIM_INSTANCE_ID = 'BOOK1'
    public static final String PBM_USER_ID = 'MBM_USER'
    public static final String RX_ACTIVE_IND = "ActiveInd"
    public static final String RX_REPACKAGER_IND = "RepackagerInd"

    public static final String DEFAULT = 'Default'
    public static final String POWDER = 'POWD'
    public static final String SOLUTION = 'SOLN'
    public static final String SOLUTION_ALT_CODE = 'SOLR'
    public static final String SOLUTION_AUTOINJECT = 'SOAJ'
    public static final String SYRINGE = 'SOSY'

    public static final String MEMBER_ID_NUMBER = "memberIdNumber"
    public static final String PATIENT_FIRST_NAME = "patientFirstName"
    public static final String PATIENT_LAST_NAME = "patientLastName"
    public static final String REFERRING_PROVIDER_ID = "referringProviderId"
    public static final String VENDOR_RECORD_NUMBER = "vendorRecordNumber"
    public static final String HISTORICAL_AUTH_ID = "historicalAuthId"
    public static final String INBOUND = 'inbound'
    public static final String SUCCESSFUL = 'success'
    public static final String SYSTEM = 'SYSTEM'

    public static final String FUNDING_ARRANGEMENT_PREFIX = 'fundingArrangementPrefix'
    public static final String FUNDING_ARRANGEMENT_PREFIX_ASO = 'fundingArrangementPrefixASO'
    public static final String NON_ERISA_GROUP_IDENTIFIER = 'nonErisaGroupIdentifier'
    public static final String DOSAGE_FORM_CODE_FILTER = 'DosageFormCodeFilter'
    public static final String SPEC_PHARM_DOSAGE_FORM_CODE_FILTER = 'SpecPharmDosageFormCodeFilter'

    public static final String FUNDING_ARRANGEMENT_PREFIX_PAI_FI = 'fundingArrangementPrefixPAIFI'
    public static final String FUNDING_ARRANGEMENT_PREFIX_PAI_ASO = 'fundingArrangementPrefixPAIASO'
    public static final String FUNDING_ARRANGEMENT_PAI_PREFIX = "PAI"
    public static final String FUNDING_ARRANGEMENT_TCC_PREFIX = "TCC"

    public static final String RAD_ONC_DISEASE_TYPE = 'radOncDiseaseType'

    public static final String ASSIGNMENT_TYPE_OWNERSHIP = '1'
    public static final String ASSIGNMENT_TYPE_MD_REVIEW = '3'

    public static final String MANAGER_DASHBOARD_USER_NAME = "username"
    public static final String MANAGER_DASHBOARD_QUEUE_NAME = "queueName"

    public static final String DRUG_POLICY_LOB_COMMERCIAL = 'Commercial'
    public static final String DRUG_POLICY_LOB_PREMIUM_COMMERCIAL = 'Premium Commercial'
    public static final String DRUG_POLICY_LOB_EXCHANGE = 'Exchange'
    public static final String DRUG_POLICY_LOB_MEDICARE = 'Medicare'
    public static final String DRUG_POLICY_LOB_MEDICARE_MEDICAID = 'Medicare & Medicaid'
    public static final String DRUG_POLICY_LOB_MEDICAID = 'Medicaid'

    public static final String ASSESSMENT_BUILDER_STATUS_TYPE ="2,3"

    public static final String BUILDER_ASSESSMENT_ID_CANCER_TYPE = "220"
    public static final String BUILDER_ASSESSMENT_CHAR_TYPE_TEXT = 'Cancer Type'

    public static final String TRAVERSAL_CLINICAL_VARIABLE_TYPE = "clinicalVariableType"
    public static final String LOB_BOTH_MEDICARE_MEDICAID = 'Both Medicare and Medicaid'
    public static final String LOB_MEDICAID = 'Medicaid'

    public static final String SUPPORTIVE_DRUG_SELECT_ON_REGIMEN_PAGE = 'suppDrugSelectOnRegPage'

    public static final String AUTHENTICATION_BASE = "/authentication"
    public static final String AUTHENTICATION_LOGOUT = "/logout"
    public static String SUBMISSION_PROCESS_AUTH_END_DATE_EXTENSION_THRESHOLD_START = 'SubmissionProcess.AuthEndDateExtension.thresholdStartDate'
    public static String SUBMISSION_PROCESS_AUTH_END_DATE_EXTENSION_THRESHOLD_END = 'SubmissionProcess.AuthEndDateExtension.thresholdEndDate'
    public static String SUBMISSION_PROCESS_AUTH_END_DATE_EXTENSION_EXTEND_TO_DATE = 'SubmissionProcess.AuthEndDateExtension.extendToDate'
    public static String SUBMISSION_PROCESS_AUTH_END_DATE_EXTENSION_DAYS = 'SubmissionProcess.AuthEndDateExtension.extensionDays'

    public static String IMPORT_PROCESS_ASSESSMENT_TRAVERSAL_LIMIT='ImportProcess.Assessment.TraversalLimit'
    public static String IMPORT_TRAVERSAL_SPREADSHEET_FILE_SIZE_LIMIT='SpreadsheetProcess.Traversal.FileSizeLimit'

    public static final String PATHWAY_USERS = "pathwayUsers"

    public static final String CLINICAL_AUTO_ANSWER_SHEET_NAME = "Clinical Auto Answer"
    public static final String MEMBER_EXCEPTION = "Member Exception"
    public static final String PROVIDER_EXCEPTION = "Provider Exception"
    public static final String PROGRAM_EXCEPTIONS = "Program Exceptions"
    public static final String MSO_SUPPLIER_LIST_SHEET_NAME = "Supplier List"
    public static final String DRUG_GROUP_SHEET_NAME = "Drug Group"
    public static final String MSO_DRUG_GROUP = "2"
    public static final String RAD_ONC_GROUP_SHEET_NAME = "Radiation Oncology"


    public static final String PREFERRED_PROCEDURE = "Preferred Procedures"
    public static final String WORK_QUEUE_RULES = "Work Queue Rules"
    public static final String MEMBER_BLOCKING = "Member Eligibility"
    public static final String AUTO_DECISIONING_GROUP = "Auto Decisioning";

    public static final String NCCN = "NCCN"

    public static final String ICUE_SYSTEM = 'ICUE_SYSTEM'

    //Authorization Type Constants
    public static final String AUTH_TYPE_OUTPATIENT_CHEMOTHERAPY_DESC = 'Outpatient Chemotherapy'
    public static final String AUTH_TYPE_SUPPORTIVE_DRUGS_DESC = 'Supportive Drugs'
    public static final String AUTH_TYPE_RADIOPHARMACEUTICAL_DESC = 'Radiopharmaceuticals'
    public static final String AUTH_TYPE_SPECIALTY_PHARMACY_DESC = 'Specialty Pharmacy'

    public static final String ORX_PA_END_DATE = '20391231'

    public static final String COMMA_LINE_SEPERATOR = ', '
    public static final String NOTE_CATEGORY_AUTH_LOG = '93'
    public static final String NOTE_CATEGORY_AUTH_NOTE_INDICATOR = '96'

    public static final long DEFAULT_MEMBER_COVERAGE_SEQUENCE_NUMBER = 1

    public static final String EMAIL_GROUP_IMPORT_TRAVERSAL_SPREADSHEET = 'ITS'
    public static final String TRAVERSAL_SPREADSHEET = 'TRAVERSAL'
    public static final String MAINTAIN_TCOC_SPREADSHEET = 'TCOC'
    public static final String TOTAL_COST_OF_CARE = 'TCOC'

    static final String PRIMARY_CANCER = 'primary cancer'
    static final String REGIMEN_ID = 'regimen id'
    static final String INDICATION = 'indication'
    static final String PAYER = 'payer'
    static final String AUTO_APPROVED = 'auto-approve'
    static final String PATHWAY = 'pathway'
    static final String TRAVERSAL_CLIENT = 'traversal client'
    static final String TCOC_CLIENT = 'tcoc client'
    static final String ADMISSION_PERCENT = 'admission percent'
    static final String THERAPY_DURATION = 'therapy duration'
    static final String THERAPY_COST = 'therapy cost'
    static final String TOTAL_THERAPY_COST = 'total therapy cost'
    static final String LINE_OF_BUSINESSES = 'line of business'
    static final String STATE = 'state'


    static final List<String> COMMON_HEADERS = [PRIMARY_CANCER, REGIMEN_ID, PAYER, AUTO_APPROVED, PATHWAY]
    static final List<String> CLIENT_HEADERS = [TRAVERSAL_CLIENT, LINE_OF_BUSINESSES, STATE]

    static final List<String> TCOC_COMMON_HEADERS = [PRIMARY_CANCER, REGIMEN_ID, TCOC_CLIENT, ADMISSION_PERCENT, THERAPY_DURATION, THERAPY_COST, TOTAL_THERAPY_COST]

    public static final String DECISION_SOURCE_TYPE = 'decisionSourceType'
    public static final String CUSTOMER = 'p_customerId'

    public static final String PLAN_NAME = 'planName'
    public static final String PLAN_BENEFIT_PACKAGE = 'PlanBenefitPackage'
    public static final String PLAN_TYPE = 'planType'

    // todo: remove when in reference constants
    public static final String ADDRESS_TYPE_PHYSICAL = "1"
    public static final String ADDRESS_TYPE_TAX= "2"

    // Will use this when white labeling feature flag is off
    public static final String NO_PROVIDER_FOUND_MESSAGE_FOR_UHC= 'No eligible providers were found with the search criteria provided. Please try searching again or contact Optum Oncology Provider Prior Authorization Support at 1-888-397-8129.'
    public static final String NO_PROVIDER_FOUND_MESSAGE_FOR_BCBSSC= 'No eligible providers were found with the search criteria provided. Please try searching again or contact Optum Oncology Provider Prior Authorization Support at 1-877-440-0089.'
    public static final String NO_PROVIDER_FOUND_MESSAGE_DEFAULT= 'No eligible providers were found with the search criteria provided. Please refer to the phone number on the back of the member\'s ID card for any questions.'

    public static final String PROVIDER_SOURCE_APPLICATION_TYPE = 'providerSourceApplicationType'

    public static final String CUST_REF_INFUSION_PUMP_DRUGS = 'infusionPumpDrugs'

    public static final String HISTORICAL_AUTH_CUSTOMER_ID = 'custId'

    public static final String TEST_POLICY_END_DATE_ALL = 'all'

    public static final String MEDICAL_NECESSITY_RESPONSE_CATEGORY = 'NM'
    public static final String RESPONSE_TRANSITION_MTB = 'Other: THMC - Transition (370)'
    public static final String TRANSITION_RESPONSE = 'T'
    public static final String DENIAL_RESPONSE = 'D'
    public static final String NO_RESPONSE = 'N'
    public static final String RC_RESPONSE = 'RC'
    public static final String COMMA_SEPERATOR = ','

    public static final String RESP_CODE_ACTIVE = 1
    public static final short SERVICE_SEQ_NUMBER = 1

    // Jpbm rule request constants
    public static final String EXPERT_RULE_SHEET_NAME = 'Expert Rules'

    //Member Eligibility
    public static final String MEMBER_ELIGIBILITY_PARAMETER = 'MemberBlocked'
    public static final String OUTCOME_MESSAGE = 'OutcomeMessage'
    public static final String PRE_DETERMINATION_OUTCOME_MESSAGE = 'PREDET'
    public static final String EMPTY_OUTCOME_MESSAGE = '.*'
    public static final String EMPTY_BLOCK_MESSAGE = '2:.*'
    public static final String EMPTY_NOTIFICATION_MESSAGE = '3:.*'
    public static final String RAD_ONC_CPT4 = "radOncCpt4"
    public static final String RAD_ONC_HCPCS = "radOncHcpcs"
    public static final String HYPO_FRACTION_POLICY_SHEET_NAME = 'Hypofractionation Policy'
    public static final String HYPO_FRACTION = 'HF'
    public static final String HYPO_FRACTION_NO_LIMIT = 'NLHF'
    public static final String INTENT = 'Intent'
    public static final String METASTATIS = 'Metastatic Disease'
    public static final String ADDITIONAL_SERVICES_TEMPLATE_SHEET_NAME = 'Additional Service Template'

    public static final String ASSESSMENT_TYPE_CLINICAL_STATUS = "1"
    public static final String ASSESSMENT_TYPE_ADDITIONAL_SERVICE = "2"
    public static final int RAD_ONC_TECHNIQUE_TRT_SC_PROC_ID = 0
    public static final int RAD_ONC_ADTN_SRVC_TRT_SC_PROC_ID = 1
    public static final int RAD_ONC_CSTM_REQ_TRT_SC_PROC_ID = 2
    public static final String RAD_ONC_ADTN_SRVC_TMPLT_EXIST = 'Template Exist'
    public static final String RAD_ONC_NO_TECHNIQUE = 'No Technique'
    public static final int RAD_ONC_NO_TECHNIQUE_ID = 9999999


    //Provider Eligibility
    public static final String PROVIDER_ELIGIBILITY_SHEET_NAME = 'Provider Eligibility'
    public static final String PROVIDER_ELIGIBILITY_PARAMETER = 'ProviderEligibilityBlocked'

    //AE Drugs
    public static final List<String> ANTIEMETIC_COMBINATION_DRUGS = ['J8655', 'J86670']
    public static final List<String> ANTIEMETIC_HT3RECEPTOR_DRUGS = ['J1627', 'Q0166','J1626', 'Q0162','J2405', 'J2469']
    public static final List<String> ANTIEMETIC_NEUROKININ_RECEPTOR_DRUGS = ['J8501', 'J0185','J1453', 'J8655','J1454', 'J8670']

    public static  final List<String> ANTIEMETIC_BTNV_DRUGS = ['Q0166', 'J1626', 'Q0162', 'J2405']
    public static  final List<String> ANTIEMETIC_LOW_AE_DRUGS = ['Q0166', 'Q0162']
    public static  final List<String> ANTIEMETIC_MODERATE_AE_DRUGS = ['Q0166', 'J1626', 'J1627', 'Q0162', 'J2405', 'J2469']

    // Dummy Member
    public static final String DUMMY_MEMBER = 'dummyMember'

    //Standard Letter Request
    public static final int STANDARD_LETTER_REQUEST = 1

    //Urgent Letter Request
    public static final int URGENT_LETTER_REQUEST = 2

    public static final String SOURCE_SYSTEM_CODE_CR = 'CR'
    public static final String REQUEST_TYPE = 'RequestType'
    public static final String REQUEST_TYPE_OXFORD =  'OXFORD_DETAIL'
    public static final String REQUEST_TYPE_DETAIL = 'DETAIL'
    public static final String REQUEST_TYPE_SSB = 'subscriptionBenefit'

    public static final String OXFORD_RELATIONSHIP_CODE = 'oxfordRelationshipCode'

    // TopsRelationshipCode Mapping
    static final Map<String, String> BCBSSC_RELATIONSHIP_CODE_BUILDER = ImmutableMap.<String, String>builder()
            .put(ReferenceConstants.RELATIONSHIP_SELF, "EE")
            .put(ReferenceConstants.RELATIONSHIP_SPOUSE, "001")
            .put(ReferenceConstants.RELATIONSHIP_CHILD, "002")
            .put(ReferenceConstants.RELATIONSHIP_OTHER, "003")
            .build()

    public static final int FUTURE_COVERAGE_MAX_DAYS = 90

    public static final String holdDownStreamEligibility = 'Hold Downstream Eligibility'

    public static final String STATE_SOUTH_CAROLINA = 'SC'
    public static final String STATE_LOUISIANA = 'LA'

    public static final String OXFORD_LINE_OF_BUSINESS_CODE = 'oxfordLineOfBusiness'

    public static final List<String> MSO_AUTH_REPORT_OUTBOUND_SYS_IDS = ["1","2","3"]
    public static final List<List<String>> MSO_AUTH_REPORT_HEADERS = [
            ["primaryServiceReferenceNum","SRN"],
            ["serviceStartDate","Expected Case Start Date"],
            ["serviceEndDate","Expected Case End Date"],
            ["lob","LOB"],
            ["requestingPhysician","Requesting Physician"],
            ["requestingProvPhone","Requesting Provider Phone"],
            ["requestingProvFax","Requesting Provider Fax"],
            ["dmeServiceDescriptionText","Specialty Drug"],
            ["procedureBrandName", "Procedure Brand Name"],
            ["procedureCode", "Procedure Code"],
            ["businessName","Supplier Name"],
            ["firstName","Member First Name"],
            ["lastName","Member Last Name"],
            ["birthDate","Member DOB"],
            ["state","Member State"],
            ["memberPhone","Member Phone"],
            ["contactName","Point of Contact Name"],
            ["primaryPhone","Point of Contact Phone"],
            ["fax","Point of Contact Fax"],
            ["overallStatus","Overall Status"],
            ["memberIDText","MBR ID"],
            ["policyNumber","Member Policy Number"]
    ]
    public static final String COV_TYP_ID_RX = "RX";
    public static final String COV_TYP_ID_M = "M";
    public static final String COV_TYP_ID_PHARMACY = "P";
    public static final String COV_TYP_BOTH = "B";
    public static final String ACTIVE_ONLY_SEARCH = "activeOnly";
    public static final String HSCATTRIBUTEVALUE_PEND_AUTH = 'PendAuth';
    public static final String HALL_CLONE_PH_THERAPY = "HalfClone";
    public static final String HSCATTRIBUTEVALUE_STEP_THERAPY_PREFERRED = 'Step Therapy Preferred';
    public static final String HSCATTRIBUTEVALUE_STEP_THERAPY_NON_PREFERRED = 'Step Therapy Non-Preferred';
    public static final String CIRRUS_UTILIZATION_PLAN_ID = 'UTILIZATION';
    public static final String CIRRUS_UTILIZATION_PLAN_CHEMO_PRECERT = 'CHEMO_PRECERT';
    public static final String SIMPLE_DATE_FORMAT = "yyyyMMdd";
    public static final String COVERAGE_TYPE_STRING_MEDICAL = "MEDICAL"

    public static final int AUTH_DURATION_90_DAYS = 90
    public static final int AUTH_DURATION_12_MONTHS = 12
    public static final String DEFAULT_OSF_SERVICING_PHARMACY_NPI = "1154306801"
    public static final String CORE_MED_NEC_INC_CIRRUS = 'A'
    public static final String CUSTOMER_BENEFIT_ACTIVE = "Active"
    public static final String BULK_ADD_ACTION_VALUE = '1'
    public static final String BULK_REPLACE_ACTION_VALUE = '2'
    public static final String SERVICING_PROVIDER_PAGE = "servicingProvider"
    public static final String SPECIALTY_PHARMACY_TREATMENT_STATUS_NEW = '1'
    public static final String SPECIALTY_PHARMACY_TREATMENT_STATUS_CONTINUATION = '2'
    public static final String PH_FOM_ASSESSMENT_TYPE_OTHER = '6'
    public static final String EXCHANGE_REPORT_CODE = 'EXGN'
    public static final String CLAIM_TYPE_PHARMACY = "Pharmacy"
    public static final String CLAIM_STATUS_PAID = "Paid"
    public static final String BOOST_TECHNIQUE_IND = "Boost of"
    public static final String RAD_ONC_SBRT_PROC_CODE_G0339 = "G0339"
    public static final int RAD_ONC_SBRT_PROC_CODE_G0339_DEFAULT_UNIT = 1
    public static final String BENEFIT_TYPE_MEDICAL = "Medical"
    public static final String BENEFIT_TYPE_PHARMACY = "Pharmacy"
    public static final String FACILITY_PROVIDER_NAME = "facilityProviderName"
    public static final String FACILITY_PROVIDER_TIN = "facilityProviderTIN"
    public static final String FACILITY_PROVIDER_NPI = "facilityProviderNPI"

}
