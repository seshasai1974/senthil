package com.optum.app.shared.jbpm

import com.optum.app.shared.diseaseTraversal.data.TreatmentRegimenVersionVO
import com.optum.mbm.flow.data.v1.request.DroolsRuleRequest
import com.optum.mbm.flow.data.v1.response.DroolsProcessResponse
import com.optum.mbm.flow.data.v1.signal.StepperSignal
import com.optum.mbm.flow.data.v1.signal.hsc.TreatmentRegimenVersionSignal
import com.optum.rf.core.annotation.InjectedBean
import com.optum.app.common.activity.data.ActivityVO
import com.optum.app.common.hsr.data.HscVO
import com.optum.app.common.member.core.data.MemberVO
import groovy.transform.CompileStatic

@CompileStatic
@InjectedBean
interface JbpmHelper {
     StepperSignal mapStepperSignal(HscVO hscVO, MemberVO memberVO, ActivityVO activityVO, String stepperSignal)

     TreatmentRegimenVersionSignal mapTreatmentRegimenVersionSignal(TreatmentRegimenVersionVO treatmentRegimenVersionVO)

     DroolsProcessResponse startJbpmProcess(HscVO hscVO, String processName)

     DroolsProcessResponse signalJbpmProcess(HscVO hscVO, Long processInstanceId, String signalName)

     DroolsProcessResponse signalJbpmProcess(HscVO hscVO, Long processInstanceId, String signalName, Object signalEvent)

     DroolsProcessResponse signalJbpmProcessSafe(HscVO hscVO, Long processInstanceId, String processId, String signalName, Object signalEvent)

     DroolsProcessResponse sendStepperContinueSignal(HscVO hscVO, MemberVO memberVO, ActivityVO activityVO, String processId, String stepperLocation)

     DroolsProcessResponse getProcessVariable(Long customerId, Long processInstanceId, String processVariableId)

     LinkedHashMap<String, Object> callRuleSheet(HscVO hscVO, String stepperLocation, String groupId)

     DroolsRuleRequest mapRulesRequestFromDB(DroolsRuleRequest ruleSheetRequestDO)

     Object callRules(DroolsRuleRequest ruleSheetRequestDO)
}
