package com.optum.app.shared.whitelabel

import com.optum.app.shared.common.groovy.ModuleApi
import com.optum.mbm.commonlogging.annotations.MbmNonHttpLogger
import groovy.transform.PackageScope

import javax.annotation.PostConstruct
import java.util.concurrent.Future

/**
 * Allows us to define whiteLabels by customer or by organization names and consume the merged whiteLabels by customerId
 *
 * Exposes a method to consume customer whiteLabels and forbidden words (merging all definition layers).
 * This class also preloads the whiteLabels after being created by Spring.
 * To be published: Exposes object to access customer whiteLabels maintenance methods.
 * To be published: Exposes object to access forbidden words maintenance methods.
 *
 * This class encapsulates all logic this module wants to expose to other modules and controllers.
 * From a Hexagonal Architecture perspective this class public methods are the primary ports of the application
 *
 * The methods that belong to classes with the suffix "Api" are meant to be exposed by this class:
 * - @Delegate exposes only public methods (Using @PackageScope annotated methods will lead to Missing Method Exceptions)
 * - Getter exposes the object's public methods but also let's you use the @PackageScope methods.
 * */
@ModuleApi
class WhiteLabel {

    private final WhiteLabelPreloader preloader
    private final WLCustomerService customerService
    private final CustomerWLMaintenanceApi customerWhiteLabelsMaintenance
    private final ForbiddenWordsMaintenanceApi forbiddenWordsMaintenance
    @Delegate private final CustomerWLApi customerWLApi
    @Delegate private final ForbiddenWordsApi forbiddenWordsApi

    WhiteLabel(
            WLCustomerService customerService,
            WhiteLabelPreloader preloader,
            CustomerWLMaintenanceApi customerWhiteLabelsMaintenance,
            ForbiddenWordsMaintenanceApi forbiddenWordsMaintenance,
            CustomerWLApi customerWLApi,
            ForbiddenWordsApi forbiddenWordsApi
    ) {
        this.preloader = preloader
        this.customerService = customerService
        this.customerWhiteLabelsMaintenance = customerWhiteLabelsMaintenance
        this.forbiddenWordsMaintenance = forbiddenWordsMaintenance
        this.customerWLApi = customerWLApi
        this.forbiddenWordsApi = forbiddenWordsApi
        Objects.requireNonNull(this.preloader)
        Objects.requireNonNull(this.customerService)
        Objects.requireNonNull(this.customerWhiteLabelsMaintenance)
        Objects.requireNonNull(this.forbiddenWordsMaintenance)
        Objects.requireNonNull(this.customerWLApi)
        Objects.requireNonNull(this.forbiddenWordsApi)
    }

    /** Preload whiteLabels asynchronously to achieve warm caches
     * @returns A future that wraps a set of customer names that loaded whiteLabels successfully. */
    @PostConstruct
    @MbmNonHttpLogger
    @PackageScope Future<Set<String>> asyncPreload() {
        return preloader.asyncPreload()
    }

    // Remove @PackageScope to publish
    @PackageScope CustomerWLMaintenanceApi getCustomerWhiteLabelsMaintenance() {
        return customerWhiteLabelsMaintenance
    }

    // Remove @PackageScope to publish
    @PackageScope ForbiddenWordsMaintenanceApi getForbiddenWordsMaintenance() {
        return forbiddenWordsMaintenance
    }
}
