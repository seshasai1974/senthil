package com.optum.app.shared.whitelabel

interface ForbiddenWordsRepo {
    /** Queried by name to make sure they can be queried across different environments
     * (test, stage, production) as ids can vary */
    List<String> findByName(String customerName)

    void save(String customerName, List<String> forbiddenWords)
}


