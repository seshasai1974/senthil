package com.optum.app.common

import com.fasterxml.jackson.core.JsonParser
import com.fasterxml.jackson.core.JsonProcessingException
import com.fasterxml.jackson.databind.DeserializationContext

/**
 * Custom deserializer to parse dates in YYYY-MM-DD format into
 * java.util.Date objects.
 */
class JSONUtilDateDeserializer extends JSONDateDeserializer<java.util.Date> {
    
    /**
     * Deserialize "YYYY-MM-DD*" values into java.util.Date objects.
     *  
     * @param jsonparser parser containing source value
     * @param context context - not used
     * @return valid util date object
     * @throws IOException
     * @throws JsonProcessingException
     */
    @Override
    public java.util.Date deserialize(JsonParser jsonparser, DeserializationContext context) throws IOException, JsonProcessingException {
        getUtilDate(jsonparser.getText())
    }
                                
    @Override
    public Class<java.util.Date> handledType() {
        return java.util.Date.class
    }
}