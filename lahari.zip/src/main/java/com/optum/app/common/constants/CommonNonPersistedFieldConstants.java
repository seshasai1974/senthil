package com.optum.app.common.constants;

import com.optum.rf.ref.core.annotation.NonPersistedReferenceField;

/**
 */
public class CommonNonPersistedFieldConstants {

    public static final String CARE_TEAM_CATEGORY = "careTeamCategory";
    public static final String ACTIVE = "active";
    public static final String CONTACTROLETYPECOMM = "contactRoleTypeCOMM";
    public static final String RELATIONSHIPREASONTYPE = "relationshipReasonType";



}