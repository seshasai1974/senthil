package com.optum.app.common

import com.fasterxml.jackson.core.JsonParser
import com.fasterxml.jackson.core.JsonProcessingException
import com.fasterxml.jackson.databind.DeserializationContext

/**
 * Custom deserializer to parse dates in YYYY-MM-DD format into
 * java.sql.Date objects.
 */
class JSONSQLDateDeserializer extends JSONDateDeserializer<java.sql.Date> {
    
    /**
     * Deserialize "YYYY-MM-DD*" values into java.sql.Date objects.
     *  
     * @param jsonparser parser containing source value
     * @param context context - not used
     * @return valid sql date objeect
     * @throws IOException
     * @throws JsonProcessingException
     */
    @Override
    public java.sql.Date deserialize(JsonParser jsonparser, DeserializationContext context) throws IOException, JsonProcessingException {

        java.util.Date utilDate = getUtilDate(jsonparser.getText())
        utilDate ? new java.sql.Date(utilDate.getTime()) : null
    }

    @Override
    public Class<java.sql.Date> handledType() {
        return java.sql.Date.class
    }
}