package com.optum.app.common.dashboard

import com.optum.rf.dao.data.ValueObject
import groovy.transform.CompileStatic

@CompileStatic
class DashboardViewVO extends ValueObject {

    /** Serialization Version ID compatibility - indication of what version may be restored.*/
    private static final long serialVersionUID = 1L

    String userGroupID      // user_grp_id
    int customerID          // cust_id
    int tileID              // tile_id
    int tilePosition        // tile_pstn
    String templateUrl      // template_url
    String title            // title
    String descriptiontext  // descriptiontext
    int tileWidth           // tile_wdth
    int requiredInd         // rqr_ind
}
