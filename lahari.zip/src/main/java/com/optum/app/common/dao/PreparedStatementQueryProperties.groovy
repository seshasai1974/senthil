package com.optum.app.common.dao

import com.optum.rf.dao.sql.query.QueryCriteria

class PreparedStatementQueryProperties {
    // column should always be populated
    String column
    Object parameter
    List<Object> parameters
    // =, <>, IN, NOT IN, LIKE, etc
    QueryCriteria criteria

    /** use this if you have multiple fields that should be used within the OR clause
     * This should be marked as true and the list should contain a separate preparedstatmentqueryproperty for each condition in the OR clause
     * eg. orConditions contains psqp1 and psqp2
     * psqp1 = column: hscID, parameter: A0001234, criteria: =
     * psqp2 = column: vendorCaseID, parameter: A0001234, criteria =
     * Would result in a generated OR statement of WHERE ( hscID = A0001234 OR vendorCaseID = A0001234 )
      */
    boolean orConditionIncluded
    List<PreparedStatementQueryProperties> orConditions

    PreparedStatementQueryProperties(){
        orConditions = new ArrayList<>()
        parameters = new ArrayList<>()
    }
}
