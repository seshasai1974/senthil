package com.optum.app.common

import com.fasterxml.jackson.databind.JsonDeserializer

import java.text.SimpleDateFormat
import java.util.regex.Pattern

/**
 * Abstract custom deserializer to parse dates in YYYY-MM-DD format into
 * Date objects.
 */
abstract class JSONDateDeserializer<T> extends JsonDeserializer<T> {
    
    private static final DATE_FORMAT = "yyyy-MM-dd"
    private static final YYYY_MM_DD_DATE_PATTERN  = Pattern.compile("([0-9]{4})-([0-9]{2})-([0-9]{2}).*")

    /**
     * Deserialize "YYYY-MM-DD*" values into java.sql.Date objects.
     * 
     * @param dateValue string date value to parse
     * @return valid java.util.Date object 
     */
    protected java.util.Date getUtilDate(String dateValue) {

        if (dateValue && YYYY_MM_DD_DATE_PATTERN.matcher(dateValue).matches()) {
            new SimpleDateFormat(DATE_FORMAT).parse(dateValue.substring(0, 10))
        } else if (dateValue && dateValue.isNumber()) {
            try {
                return new Date(dateValue.toLong())
            } catch (Exception e) {
                return null
            }
        } else {
            null
        }
    }
}
