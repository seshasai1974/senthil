package com.optum.app.common.dao

class StoredProcProperties {
    int sqlType        // using Types (sql library)
    Object parameterValue   // non-specific object type - the type is determined by sqlvaluetype
    String parameterName
}
