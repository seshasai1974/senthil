package com.optum.app.common.constants;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 */
public class WorkListConstants {

    public static final String ASSIGNMENT_SUFFIX = "asgn";
    public static final String REASSIGNMENT_SUFFIX = "reasgn";
    public static final String ASSIGNED_TO_TYPE = "assignedToType";
    public static final String ASSIGNED_TO_TYPE_ALL = "a";
    public static final String ASSIGNED_TO_TYPE_QUEUE = "q";
    public static final String ASSIGNED_TO_TYPE_USER = "u";
    public static final String ASSIGNED_TO_TYPE_MYSELF = "m";
    public static final String ASSIGNMENT_TYPE_ALL = "99";
    public static final String ASSIGNMENT_TYPE_OWNERSHIP = "00";
    public static final String ASSIGNMENT_TYPE_ACTION = "999";
    public static final String ASSIGNED_TO_TYPE_WORK_QUEUE_GROUP = "g";
    public static final String ASSIGNED_TO_TYPE_WORK_QUEUE_GROUP_TYPE = "gt";
    public static final String IS_REASSIGNMENT_REQUEST_PARAMETER = "isReassignment";
    public static final String IS_ASSIGNMENT_TYPE_CONFIGURATION = "isAssignmentTypeConfiguration";
    public static final String IS_ROUTING_DECISION_VALUE = "isRoutingDecisionValue";
    public static final String ASSIGNMENT_CHECK = "assignmentCheck";
    public static final String TURN_AROUND_TIME = "maxTatAndUnitType";

    public static final String RECEIVED_DATE_FROM = "receivedDateFrom";
    public static final String RECEIVED_DATE_TO = "receivedDateTo";
    public static final String DATE_RECEIVED = "dateReceived";
    public static final String SERVICE_DATE_FROM = "serviceDateFrom";
    public static final String SERVICE_DATE_TO = "serviceDateTo";
    public static final String DATE_OF_SERVICE = "dateOfService";
    public static final String ASSIGNMENT_DUE_DATE_FROM = "assignmentDueDateFrom";
    public static final String ASSIGNMENT_DUE_DATE_TO = "assignmentDueDateTo";
    public static final String ASSIGNMENT_CREATE_DATE_FROM = "assignmentCreateDateFrom";
    public static final String ASSIGNMENT_CREATE_DATE_TO = "assignmentCreateDateTo";
    public static final String ALT_ASSIGNMENT_DUE_DATE = "altAssignmentDueDate";
    public static final String ALT_ASSIGNMENT_CREATE_DATE = "altAssignmentCreateDate";
    public static final String REFERRAL_CREATE_DATE = "referralCreateDate";
    public static final String REFERRAL_SYSTEM_CREATE_DATE = "referralSystemCreateDate";
    public static final String REFERRAL_SYS_CREATE_DATE = "referralSysCreateDate";
    public static final String BUSINESS_OR_PERSON_LAST_NAME = "businessOrPersonLastName";
    public static final String NUMBER_RECORDS_TO_DISPLAY = "numberRecordsToDisplay";
    public static final String GENERIC_WORK_QUEUE_GROUP_NAME = "CICR_ALLWORKQUEUE";
    public static final String IPC_REVIEW_WORK_QUEUE_GROUP_NAME = "CICR_IPCREVIEW";
    public static final int DEFAULT_WORKQUEUE_LIST_SIZE = 999;
    public static final String DEFAULT_END_DATE = "9999-12-31";
    public static final String DEFAULT_START_DATE = "1900-01-01";
    public static final String USER_CCS_ID_RESTRICTED = "HSRNT";
    public static final String ASSIGNMENT_STATUS_OPEN = "1";
    public static final String ASSIGNMENT_HIGHLIGHT_TYPE_NEW = "1";
    public static final String DUE_TODAY = "dueToday";
    public static final String DUE_TODAY_ID = "dueTodayId";
    public static final String FILTERWORKQUEUEGROUPTYPE = "filterworkQueueGroupType";

    public static final String ACTION_EXPORT_WORKQUEUE = "csvExport";
    public static final String ACTION_COMBINED_REASSIGNMENT = "getCombinedReassignment";
    public static final String ACTION_MEMBER_REASSIGNMENT = "getMemberReassignment";
    public static final String ACTION_BEHAVIORAL_HEALTH_REASSIGNMENT = "getBehavioralHealthReassignment";
    public static final String ACTION_MEMBER_MYWORKQUEUEPREFERENCES = "getPrivateMemberWorkQueuePreference";
    public static final String ACTION_BEHAVIORAL_HEALTH_MYWORKQUEUEPREFERENCES = "getPrivateBehavioralHealthWorkQueuePreference";

    public static final String ACTIONDISPLAY_EXPORT_WORKQUEUE = "Export Work Queue";
    public static final String ACTIONDISPLAY_REASSIGNASSIGNMENTS = "Reassign Assignment(s)";
    public static final String ACTIONDISPLAY_RESTORE_HEADINGS = "Restore Default Headings";
    public static final String ACTIONDISPLAY_UPDATEBULKASSIGNMENTSTATUS = "Update Bulk Assignment Status";
    public static final String ACTIONDISPLAY_MYWORKQUEUEPREFERENCES = "My Work Queue Preferences";

    public static final String STRING_TYPE = "stringType";
    public static final String INT_TYPE = "intType";
    public static final String DATE_TYPE = "dateType";
    public static final String DOUBLE_TYPE = "doubleType";

    public static final String UPDATE_ASSIGNMENT_FROM_COMBINED_WORKQUEUE = "combinedWorkQueue";
    public static final String UPDATE_ASSIGNMENT_FROM_MEMBER_WORKQUEUE = "fromMemberWorkQueue";
    public static final String UPDATE_ASSIGNMENT_FROM_BEHAVIORAL_HEALTH_WORKQUEUE = "fromBehavioralHealthWorkQueue";

    //below constants used by AssignmentManagementController as part of Sonar Refactoring
    public static final long HOURS = 24L;
    public static final long MINUTES = 60L;
    
    public static final String MEMBERPROGRAMWORKLISTVIEW = "memberProgramWorkListView";
    public static final String HSCWORKLISTVIEW = "hscWorkListView";
    public static final String COMBINEDWORKLISTVIEW = "combinedWorkListView";
    public static final String ADVISORWORKLISTVIEW = "advisorWorkListView";
    public static final String MEMBERWORKLISTVIEW = "memberWorkListView";
    public static final String CACNAME_PIT = "PIT";

    public static final String PHONE_TYPE_TELEPHONE = "2";
    public static final String PHONE_TYPE_FAX = "3";
    public static final List<String> PHONE_TYPES = new ArrayList<>(Arrays.asList(new String[] {PHONE_TYPE_TELEPHONE, PHONE_TYPE_FAX}));
}
