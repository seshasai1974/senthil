package com.optum.app.common

import com.fasterxml.jackson.core.JsonParser
import com.fasterxml.jackson.core.JsonProcessingException
import com.fasterxml.jackson.databind.DeserializationContext
import com.optum.rf.core.util.UhgCalendar

import java.sql.Date

/**
 * Custom deserializer to parse dates in YYYY-MM-DD format into
 * com.optum.rf.core.util.UhgCalendar objects.
 */
class JSONUhgCalendarDateDeserializer extends JSONDateDeserializer<UhgCalendar> {

    /**
     * Deserialize "YYYY-MM-DD*" values into com.optum.rf.core.util.UhgCalendar objects.
     *
     * @param jsonparser parser containing source value
     * @param context context - not used
     * @return valid UhgCalendar  objeect
     * @throws java.io.IOException
     * @throws com.fasterxml.jackson.core.JsonProcessingException
     */
    @Override
    UhgCalendar deserialize(JsonParser jsonparser, DeserializationContext context) throws IOException, JsonProcessingException {
        java.util.Date utilDate = getUtilDate(jsonparser.getText())
        utilDate ? new UhgCalendar(utilDate.getTime()) : null
    }

    @Override
    Class<Date> handledType() {
        return UhgCalendar.class
    }
}