package com.optum.app.common.dao

import au.com.bytecode.opencsv.CSVWriter
import com.optum.rf.dao.data.ValueObject
import com.optum.rf.dao.sql.BaseDataAccessObject
import com.optum.rf.dao.sql.DataAccessObject
import com.optum.rf.dao.sql.exception.DAOException
import groovy.transform.CompileStatic
import org.apache.commons.dbutils.ResultSetHandler
import org.apache.commons.dbutils.handlers.BeanListHandler

import java.lang.reflect.Method
import java.sql.CallableStatement
import java.sql.Connection
import java.sql.ResultSet
import java.sql.SQLException

@CompileStatic
class StoredProcDataAccessObject<V extends ValueObject> extends BaseDataAccessObject {
    private Class<V> beanClass

    /**
     * Constructor for the StoredProcDataAccessObject
     * @param beanClass - the .class of the result object type (eg. HscVO.class)
     */
    public StoredProcDataAccessObject(Class<V> beanClass) {
        super()
        this.beanClass = beanClass
    }

    /**
     * Writes the ResultSet to the CSV file with headers
     * @param dao - The original DAO object which we're using to grab the connection from
     * @param storedProcName - The name of the stored procedure being called
     * @param parameters - A list of StoredProcProperties which contain the parameters passed to the stored proc;
     * @param csvWriter - The CSVWriter Object to write to the file corresponding
     */
    final void writeCsvFromStoredProc(DataAccessObject<V> dao, String storedProcName, List<StoredProcProperties> parameters, CSVWriter csvWriter) {
        ResultSet rs = null

        if (parameters != null) {
            Connection conn = null
            CallableStatement proc = null

            String msg

            try {
                // create the base prepared statement
                String queryString = "{ call " + storedProcName.toUpperCase() + "("
                // add a parameter placeholder (?) for each parameter passed
                for (int i = 0; i < parameters.size(); i++) {
                    if (i == 0) {
                        queryString += "?"
                    } else {
                        queryString += ", ?"
                    }
                }
                queryString += ")}"

                // Get the connection from the DAO passed in
                Method method = dao.getClass().getDeclaredMethod("getInternalConnection", String.class)
                method.setAccessible(true)
                Object response = method.invoke(dao, "list")
                conn = (Connection) response

                proc = conn.prepareCall(queryString)

                int param = 1

                // Add the parameters in order
                for (StoredProcProperties p in parameters) {
                    if (p.getParameterValue() != null) {
                        proc.setObject(param, p.getParameterValue(), p.getSqlType())
                    } else {
                        proc.setNull(param, p.getSqlType())
                    }
                    param++
                }

                // execute the query
                rs = proc.executeQuery()
                csvWriter.writeAll(rs, true)
            } catch (SQLException var12) {
                msg = "SPDAO.list() java.sql.SQLException: " + var12.getMessage()
                this.log.error(msg, var12)
                this.log.error(parameters.toString())
                throw new DAOException(msg, var12)
            } catch (Exception var13) {
                msg = "Exception in SPDAO.list(): " + var13.getMessage()
                this.log.error(msg, var13)
                this.log.error(parameters.toString())
                throw new DAOException(msg, var13)
            } finally {
                // close the connection
                this.close(rs, proc, conn)
            }

        } else if (this.log.isDebugEnabled()) {
            this.log.debug("The incoming parameters were null.")
        }
    }

    /**
     * Return a list of data from a stored procedure
     * @param dao - The original DAO object which we're using to grab the connection from
     * @param storedProcName - The name of the stored procedure being called
     * @param parameters - A list of StoredProcProperties which contain the parameters passed to the stored proc;
     * order of this list should match the order of the parameters passed in
     * @return
     */
    public final List<V> list(DataAccessObject<V> dao, String storedProcName, List<StoredProcProperties> parameters) {
        List<V> list = null
        if (parameters != null) {
            Connection conn = null
            CallableStatement proc = null
            ResultSet rs = null
            List<V> resultSet = new ArrayList<>()
            String msg

            try {
                // create the base prepared statement
                String queryString = "{ call " + storedProcName.toUpperCase() + "("
                // add a parameter placeholder (?) for each parameter passed
                for(int i = 0; i < parameters.size(); i++){
                    if(i == 0){
                        queryString += "?"
                    }
                    else{
                        queryString += ", ?"
                    }
                }
                queryString += ")}"

                // Get the connection from the DAO passed in
                Method method = dao.getClass().getDeclaredMethod("getInternalConnection", String.class)
                method.setAccessible(true)
                Object response = method.invoke(dao, "list")
                conn = (Connection) response

                proc = conn.prepareCall(queryString)

                int param = 1

                // Add the parameters in order
                for(StoredProcProperties p in parameters) {
                    if(p.getParameterValue() != null){
                        proc.setObject(param, p.getParameterValue())
                    }
                    else{
                        proc.setNull(param, p.getSqlType())
                    }
                    param++
                }

                // execute the query
                rs = proc.executeQuery()

                // map the result set to the object type
                ResultSetHandler<List<V>> h = new BeanListHandler<V>(beanClass)
                resultSet = h.handle(rs)

                conn.close()
            } catch (SQLException var12) {
                msg = "SPDAO.list() java.sql.SQLException: " + var12.getMessage()
                this.log.error(msg, var12)
                this.log.error(parameters.toString())
                throw new DAOException(msg, var12)
            } catch (Exception var13) {
                msg = "Exception in SPDAO.list(): " + var13.getMessage()
                this.log.error(msg, var13)
                this.log.error(parameters.toString())
                throw new DAOException(msg, var13)
            } finally {
                // close the connection
                this.close(rs, proc, conn)
            }

            // return the resultset
            return resultSet
        } else if (this.log.isDebugEnabled()) {
            this.log.debug("The incoming parameters were null.")
        }

        return (List)(list != null ? list : new ArrayList(0))
    }

    /**
     * Return a count of data from a stored procedure
     * @param dao - The original DAO object which we're using to grab the connection from
     * @param storedProcName - The name of the stored procedure being called
     * @param parameters - A list of StoredProcProperties which contain the parameters passed to the stored proc;
     * order of this list should match the order of the parameters passed in
     * @return
     */
    public final int count(DataAccessObject<V> dao, String storedProcName, List<StoredProcProperties> parameters) {
        List<V> list = null
        if (parameters != null) {
            Connection conn = null
            CallableStatement proc = null
            ResultSet rs = null
            int r = 0
            String msg

            try {
                String queryString = "{ call " + storedProcName.toUpperCase() + "("
                for(int i = 0; i < parameters.size(); i++){
                    if(i == 0){
                        queryString += "?"
                    }
                    else{
                        queryString += ", ?"
                    }
                }
                queryString += ")}"

                Method method = dao.getClass().getDeclaredMethod("getInternalConnection", String.class)
                method.setAccessible(true)
                Object response = method.invoke(dao, "list")
                conn = (Connection) response

                proc = conn.prepareCall(queryString)

                int param = 1

                for(StoredProcProperties p in parameters) {
                    if(p.getParameterValue() != null) {
                        proc.setObject(param, p.getParameterValue(), p.getSqlType())
                    }
                    else{
                        proc.setNull(param, p.getSqlType())
                    }
                    param++
                }

                rs = proc.executeQuery()

                if(rs.next()) {
                    r =  Integer.parseInt(rs.getObject("count").toString())
                }

                conn.close()

            } catch (SQLException var12) {
                msg = "SPDAO.list() java.sql.SQLException: " + var12.getMessage()
                this.log.error(msg, var12)
                this.log.error(parameters.toString())
                throw new DAOException(msg, var12)
            } catch (Exception var13) {
                msg = "Exception in SPDAO.list(): " + var13.getMessage()
                this.log.error(msg, var13)
                this.log.error(parameters.toString())
                throw new DAOException(msg, var13)
            } finally {
                this.close(rs, proc, conn)
            }

            // return the count
            return r
        } else if (this.log.isDebugEnabled()) {
            this.log.debug("The incoming parameters were null.")
        }

        return 0
    }

}
