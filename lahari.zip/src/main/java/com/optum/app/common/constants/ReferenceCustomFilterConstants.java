package com.optum.app.common.constants;

import com.optum.rf.ref.core.annotation.ReferenceCustomFilter;

/**
 */
public class ReferenceCustomFilterConstants {
    @ReferenceCustomFilter
    public static final String CONTACTROLEFORDECISIONCOMMACTIVITY = "contactRoleForDecnCommActivity";
    @ReferenceCustomFilter
    public static final String CONTACTROLEFORACTIVITY = "contactRoleForActivity";
    @ReferenceCustomFilter
    public static final String SERVICEDESCRIPTOR_FOR_UI = "serviceDescriptorForUI";
    @ReferenceCustomFilter
    public static final String HSCACTIONASSIGNMENTTYPE = "hscActionAssignmentType";

    @ReferenceCustomFilter
    public static final String BEHAVIORALACTIONASSIGNMENTTYPE = "behavioralAssignmentType";
    @ReferenceCustomFilter
    public static final String HSRNOTETYPE = "hsrNoteType";
    @ReferenceCustomFilter
    public static final String HSRNOTECATEGORYTYPEFILTER = "hsrNoteCategoryTypeFilter";
    @ReferenceCustomFilter
    public static final String SSO_REQUIRED = "ssoRequired";
    @ReferenceCustomFilter
    public static final String MED_NEC_SUPPORTED_SPCL_PROCS = "medNecSupportedSpecialProcTypes";
    @ReferenceCustomFilter
    public static final String PROVIDER_SEARCH_DIVID = "providerSearchCosmosDivID";
    @ReferenceCustomFilter
    public static final String TEMPMEMBER_DIVID = "tempMemberDivID";
    @ReferenceCustomFilter
    public static final String HSRACTIVITYTYPE = "hsrActivityType";
    @ReferenceCustomFilter
    public static final String BEHAVIORALACTIVITYTYPE = "behavioralActivityType";
    @ReferenceCustomFilter
    public static final String BEHAVIORALTRANSACTIVITYTYPE = "behavioralTransActivityType";
    @ReferenceCustomFilter
    public static final String HSR_ASSIGNMENT_DESCRIPTOR_TYPE = "hsrAssignmentDescriptorType";
    @ReferenceCustomFilter
    public static final String PRODUCTCATEGORYTYPE_MEDICARE = "productCategoryTypeMedicare";
    @ReferenceCustomFilter
    public static final String PRODUCTCATEGORYTYPE_COSMOS = "productCategoryTypeCosmos";
    @ReferenceCustomFilter
    public static final String CPMPROGRAMTYPE = "cpmProgramType";
    @ReferenceCustomFilter
    public static final String CPMPROGRAMCATEGORYTYPE = "cpmProgramCategoryType";
    @ReferenceCustomFilter
    public static final String MEMBER_IDENTIFIER_TYPE_EXTERNAL = "externalMemberIDType";
    @ReferenceCustomFilter
    public static final String MEMBER_IDENTIFIER_TYPE_INTERNAL = "internalMemberIDType";
    @ReferenceCustomFilter
    public static final String MEMBER_IDENTIFIER_TYPE_HSR = "hsrMemberIDType";
    @ReferenceCustomFilter
    public static final String MEMBER_IDENTIFIER_TYPE_CPM = "cpmMemberIDType";
    @ReferenceCustomFilter
    public static final String CONTACTROLE_FOLLOWUP = "contactRoleForFollowup";
    @ReferenceCustomFilter
    public static final String HSR_LINE_OF_BUSINESS = "hsrLineOfBusinessType";
    @ReferenceCustomFilter
    public static final String PROC_UOM_HSCPSCT1000 = "procUOMHSCPSCT1000";
    @ReferenceCustomFilter
    public static final String PROC_UOM_OTHER = "procUOMOther";
    @ReferenceCustomFilter
    public static final String SRVC_TASK_UNIT_OF_MEASURE = "serviceTaskUnitOfMeasure";

    @ReferenceCustomFilter
    public static final String USER_SPECIFIED_ASSIGNMENT_TYPE = "userSpecifiedAssignmentType";
    @ReferenceCustomFilter
    public static final String ECA_RESOLUTION_REASON = "ecaResolutionReason";
    @ReferenceCustomFilter
    public static final String TEMP_MEMBER_CAPTURE_REASON = "tempMemberCaptureReason";
    @ReferenceCustomFilter
    public static final String HSR_PROCEDURE_CODE_TYPE = "hsrProcedureCodeType";
    @ReferenceCustomFilter
    public static final String TAT_DECISION_OUTCOME_TYPE = "tatDecisionOutcomeType";
    @ReferenceCustomFilter
    public static final String TAT_DECISION_SUB_TYPE = "tatDecisionSubType";
    @ReferenceCustomFilter
    public static final String ACTIVITY_CHANNEL_SOURCE_FILTER = "activityChannelSourceFilter";
    @ReferenceCustomFilter
    public static final String INTAKE_CHANNEL_SOURCE_FILTER = "intakeChannelSourceFilter";
    @ReferenceCustomFilter
    public static final String COPY_HSC_CHANNEL_SOURCE_FILTER = "copyHscChannelSourceFilter";
    @ReferenceCustomFilter
    public static final String COPY_HSC_CARECORE_SOURCE_FILTER = "copyHscCareCoreSourceFilter";
    @ReferenceCustomFilter
    public static final String CHANNEL_REQUIRING_CONTACT_NAME = "channelRequiringContactName";
    @ReferenceCustomFilter
    public static final String CHANNEL_REQUIRING_PRIMARY_PHONE = "channelRequiringPrimaryPhone";
    @ReferenceCustomFilter
    public static final String CHANNEL_REQUIRING_FAX = "channelRequiringFax";
    @ReferenceCustomFilter
    public static final String CHANNEL_REQUIRING_EMAIL = "channelRequiringEmail";
    @ReferenceCustomFilter
    public static final String CHANNEL_REQUIRING_ROLE = "channelRequiringRole";
    @ReferenceCustomFilter
    public static final String MEMBER_CONTACT_ROLE = "memberContactRole";
    @ReferenceCustomFilter
    public static final String PROVIDER_CONTACT_ROLE = "providerContactRole";
    @ReferenceCustomFilter
    public static final String CANCELLED_HSC_COPY_SCENARIO = "cancelledHscCopyScenario";
    @ReferenceCustomFilter
    public static final String INPATIENT_HSC_COPY_SCENARIO = "inpatientHscCopyScenario";
    @ReferenceCustomFilter
    public static final String OPOPF_HSC_COPY_SCENARIO = "opOpfHscCopyScenario";
    @ReferenceCustomFilter
    public static final String OPEN_ANTICIPATING_ADMISSION_STATUS_TYPE = "openAnticipatingAdmStatusType";
    @ReferenceCustomFilter
    public static final String OPEN_STATUS_REASON_TYPE = "openStatusReasonType";
    @ReferenceCustomFilter
    public static final String CLOSED_STATUS_REASON_TYPE = "closedStatusReasonType";
    @ReferenceCustomFilter
    public static final String CANCELLED_STATUS_REASON_TYPE = "cancelledStatusReasonType";
    @ReferenceCustomFilter
    public static final String NDB_PRODUCT_TYPE = "ndbProductType";
    @ReferenceCustomFilter
    public static final String HSC_ALERT_TYPE = "hscAlertType";
    @ReferenceCustomFilter
    public static final String DECISION_REASON = "decisionReason";
    @ReferenceCustomFilter
    public static final String DECISION_TIMEFRAME = "decisionTimeframe";
    @ReferenceCustomFilter
    public static final String DELAWARE_EVV_LEGACY_BENEFIT_PLAN_ID = "deEvvLegBenfId";
    @ReferenceCustomFilter
    public static final String NEW_MEXICO_EVV_LEGACY_BENEFIT_PLAN_ID = "nmEvvLegBenfId";
    @ReferenceCustomFilter
    public static final String DENIAL_BASED_ON = "denialBasedOn";
    @ReferenceCustomFilter
    public static final String DENIAL_INDICATOR = "denialIndicator";
    @ReferenceCustomFilter
    public static final String DENIAL_REASON_TYPE = "denialReasonType";
    @ReferenceCustomFilter
    public static final String LETTER_TEMPLATE_POC_CODES = "letterTemplatePocCodes";
    @ReferenceCustomFilter
    public static final String QIO_STATE = "qioState";
    @ReferenceCustomFilter
    public static final String RESOURCE_FOR_DECISION = "resourceForDecision";
    @ReferenceCustomFilter
    public static final String SERVICE_TYPE = "serviceType";
    @ReferenceCustomFilter
    public static final String PROD_CAT_NICE_TYPE = "productCategoryTypeNice";
    @ReferenceCustomFilter
    public static final String DERIVED_POLICY_LETTER_ATTRIBUTE_TYPE = "derivedPolicyLetterAttributeType";
    @ReferenceCustomFilter
    public static final String DERIVED_LETTER_LINEOFBUSSINESS_TYPE = "derivedLetterLineOfBusinessType";
    @ReferenceCustomFilter
    public static final String PROTOCOL_ASSESSMENT_TYPE = "protocolAssessmentType";
    @ReferenceCustomFilter
    public static final String ICM_NURSE_ROUTE_LOB = "icmNurseRouteLOB";
    @ReferenceCustomFilter
    public static final String NON_CLINICAL_USER = "nonClinicalUser";
    @ReferenceCustomFilter
    public static final String SUB_CATEGORY_TYPE_FOR_UI = "subcategoryTypeForUI";
    @ReferenceCustomFilter
    public static final String EDITYPE_FOR_UI = "ediTypeForUI";
    @ReferenceCustomFilter
    public static final String SUB_CATEGORY_OP_SERVICE_LINE_FILTER = "subcategoryOPServiceLineFltr";
    @ReferenceCustomFilter
    public static final String SUB_CATEGORY_OPF_SERVICE_LINE_FILTER = "subcategoryOPFServiceLineFltr";
    @ReferenceCustomFilter
    public static final String CIRRUS_ERROR_ENTITY_TYPE = "cirrusErrorEntityType";
    @ReferenceCustomFilter
    public static final String EDISUPPORTEDCLAIMPLATFORMID = "ediSupportedClaimPlatformID";
    @ReferenceCustomFilter
    public static final String ASSESSMENT_REVIEW_TEMPLATE_TYPE = "assessentReviewTemplateType";
    @ReferenceCustomFilter
    public static final String SPECIALTY_OPS_PROGRAM_TYPE = "specOpsPgmType";
    @ReferenceCustomFilter
    public static final String MBRNOTETYPEFILTER = "mbrNoteTypeFilter";
    @ReferenceCustomFilter
    public static final String MBRNOTECATEGORYTYPEFILTER = "mbrNoteCategoryTypeFilter";
    @ReferenceCustomFilter
    public static final String MBRFINALDISPOSITIONTYPEPARTD = "mbrFinalDispositionTypePartD";
    @ReferenceCustomFilter
    public static final String UHG_MEMBERS_POLICY_NUMBER = "UHGMembersPolicyNumber";
   }
