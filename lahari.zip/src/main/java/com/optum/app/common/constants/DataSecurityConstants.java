package com.optum.app.common.constants;

/**
 */
public class DataSecurityConstants {
    public static final String DATAGROUPRULE = "dataGroupRule";
    public static final String DATA = "data";
    public static final String LAST_REFERENCE_CACHE_REFRESH = "Last-Reference-Cache-Refresh";
    public static final String PRAGMA_HEADER = "Pragma";
    public static final String CACHE_CONTROL_HEADER = "Cache-Control";
    public static final String X_FRAME_OPTIONS_HEADER = "X-Frame-Options";
}
