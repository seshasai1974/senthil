package com.optum.app.common.dashboard

import com.optum.rf.dao.data.ValueObject
import groovy.transform.CompileStatic

@CompileStatic
class UserDashboardVO extends ValueObject {

    /** Serialization Version ID compatibility - indication of what version may be restored.*/
    private static final long serialVersionUID = 1L

    String userID       // user_id
    int tileID          // tile_id
    int tilePosition    // tile_pstn
}
