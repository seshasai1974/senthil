package com.optum.app.common

import com.fasterxml.jackson.core.JsonGenerator
import com.fasterxml.jackson.core.JsonProcessingException
import com.fasterxml.jackson.databind.JsonSerializer
import com.fasterxml.jackson.databind.SerializerProvider
import com.optum.app.shared.constants.SpclCareConstants

import java.sql.Date
import java.text.SimpleDateFormat
/**
 *
 * Custom serializer to parse java.sql.Date objects into YYYY-MM-DD formatted string
 *
 */
class JSONSQLDateSerializer extends JsonSerializer<Date> {

    private static final SimpleDateFormat dateFormat = new SimpleDateFormat(SpclCareConstants.DATE_PATTERN)
    private static final SimpleDateFormat dateTimeFormat = new SimpleDateFormat(SpclCareConstants.DATE_TIME_PATTERN)

/**
 * serialize java.sql.Date objects into formatted String.
 *
 * @param date
 * @param gen
 * @param provider
 * @throws IOException
 * @throws JsonProcessingException
 */
    @Override
    void serialize(Date date, JsonGenerator gen, SerializerProvider provider) throws IOException, JsonProcessingException {
        String formattedDate
        if (new SimpleDateFormat('HH:mm:ss').format(date) == '00:00:00') {
            formattedDate = dateFormat.format(date)
        } else {
            formattedDate = dateTimeFormat.format(date)
        }

        gen.writeString(formattedDate)
    }

    @Override
    Class<Date> handledType() {
        return Date
    }
}
