package com.optum.app.common.constants;

import com.uhg.app.common.constants.spclcare.FieldConstants;
import com.optum.rf.ref.core.annotation.Reference;

public class FileLoadReferenceContants {
    //***********************************************************************************************
    //* This section <b>should</b> contain constants pertaining to the reference table.
    //* All other constants should be either outside of this section or in the global constants class.
    //* Any new entries into this section, isValid the code by running the ReferenceConstantsValidation program.
    //**********************************************************************************************
    @Reference(name = FieldConstants.WARNINGREASONTYPE)
    public static final String WARNINGREASONTYPE_INVALID_DOB = "1";
    @Reference(name = FieldConstants.WARNINGREASONTYPE)
    public static final String WARNINGREASONTYPE_INVALID_DOD = "2";
    @Reference(name = FieldConstants.WARNINGREASONTYPE)
    public static final String WARNINGREASONTYPE_INVALID_DOB_AND_DOD = "3";
}
