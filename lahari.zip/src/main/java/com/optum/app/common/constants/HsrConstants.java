package com.optum.app.common.constants;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class HsrConstants {
    public static final String UHCONLINE_NOTE_SUFFIX = "uhcOnline";
    public static final String UHCOL = "UHCOL";
    public static final String PTP = "PTP";
    public static final String HSC_NON_FACILITYSERVICE_SCHEDULE = "hscNonFaclSrvcSchedule";
    public static final String ICUE = "ICUE";
    public static final String PREFIX_CARECORE_VENDOR_CASE_ID = "CC";
    public static final String PREFIX_A0_VENDOR_CASE_ID = "A0";
    public static final String RADIOLOGY_SERVICE_DETAIL_TYPE = "13";
    public static final String CARDIOLOGY_SERVICE_DETAIL_TYPE = "44";
    public static final String POLICYNUMBER_ZERO = "0";
    public static final String ACTIONDISPLAY_SAVE = "Save";
    public static final String ACTIONDISPLAY_UPDATE = "Update";
    public static final int PHQ9_SCORE_15 = 15;
    public static final int PHQ9_SCORE_10 = 10;
    public static final int WORKQUEUE_ID_DEPR_HIGH = 2811;
    public static final int WORKQUEUE_ID_DEPR_MED = 2810;
    public static final int WORKQUEUE_ID_AARP_SHIP_INCOMPLETE_PHQ9 = 2814;
    public static final int WORKQUEUE_ID_AARP_SHIP_HRCM = 2830;
    public static final int WORKQUEUE_ID_AARP_SHIP_POSWHOOLEY = 2864;
    public static final int WORKQUEUE_ID_MRSNPCCMHTL = 4857;
    public static final int WORKQUEUE_ID_SFLSNPCCMHTL = 5050;
    public static final int WORKQUEUE_ID_MRGRCCMHTL  = 5051;
    public static final int WORKQUEUE_ID_PNDAC = 2946; // Need to verify for 'Pending Auto Closure'
    public static final int WORKQUEUE_ID_NOLTR = 2947; // Need to verify for 'No Letter'
    public static final int WORKQUEUE_ID_LTSSNEWENROLLEE = 4308;
    public static final int WORKQUEUE_ID_PBSADMIN = 2922; 
    public static final int WORKQUEUE_ID_PBSCLINICAL = 2923; 
    public static final int WORKQUEUE_ID_PBSTX = 2934;
    public static final int WORKQUEUE_ID_CSBHCASEMGMT = 4320;
    public static final int WORKQUEUE_ID_CNSHPMGMT = 4535;
    public static final int WORKQUEUE_ID_MRSNPHRA = 4425;
    public static final int WORKQUEUE_ID_SFLUTRSNP = 4215;
    public static final int WORKQUEUE_ID_CSSNPHRA = 5052;
    public static final int WORKQUEUE_ID_NATIONAL_PERSONAL_PHARMACIST = 5319;
    public static final String PBSTX = "PBSTX";
    public static final String MEMBER_CARE_LEVEL_1 = "1";
    public static final String MEMBER_CARE_LEVEL_2 = "2";
    public static final String MEMBER_CARE_LEVEL_3 = "3";
    public static final List<String> ASSESSMENT_MEMBER_CARE_LEVEL = Arrays.asList(MEMBER_CARE_LEVEL_1, MEMBER_CARE_LEVEL_2, MEMBER_CARE_LEVEL_3);
    public static final String ORIGSYSTEMMEMBERIDTYPE_CATAMARAN = "RXCC";
    public static final String ORIGSYSTEMMEMBERIDTYPE_ORXBOOK1 = "RXCL1";
    public static final String ORIGSYSTEMMEMBERIDTYPE_ORXBOOK2 = "RXCL2";
    public static final List<String> SYSTEMTYPE_RX = Arrays.asList(ORIGSYSTEMMEMBERIDTYPE_CATAMARAN, ORIGSYSTEMMEMBERIDTYPE_ORXBOOK1, ORIGSYSTEMMEMBERIDTYPE_ORXBOOK2);
    public static final int ICM_ELIGIBILE = 1;
    public static final int ICM_DOMESTIC_ONLY = 2;
    public static final String CLAIM_APPEAL_INDICATOR_V = "V";
    public static final String CLAIM_APPEAL_INDICATOR_A = "A";
    public static final String DATA_PROPERTY_TYPE_ID_COMPLETE = "C";
    public static final String ICM_NURSE_ROUTING_SUFFIX = "icmNurseRoutingSuffix";
    public static final String MARK_INACTIVE = "(INACTIVE)";
    public static final String ACTION_DISPLAY_SAVE = "Save";
    public static final String ACTION_SAVE = "saveSpecialProcessTypeConfiguration";
    public static final String ACTION_SAVE_CIRRUS = "saveSpecialProcessTypeCirrusConfiguration";
    public static final String ACTION_DISPLAY_CREATE_COPY = "Create a Copy";
    public static final String ACTION_CREATE_COPY = "createACopySpecialProcessTypeConfiguration";
    public static final String ACTION_CREATE_COPY_CIRRUS = "createACopySpecialProcessTypeCirrusConfiguration";
    public static final String SHARED_ARRANGEMENT_ID = "00";
    public static final String OBLIG_ID = "01";
    public static final String STATUS_ACTIVE = "Active";
    public static final String STATUS_INACTIVE = "Inactive";
    public static final String SPECIAL_PROCESS_TYPE_NAV_COMP_BAL = "03";
    public static final String SPECIAL_PROCESS_TYPE_NAV_COMP_CHART = "02";
    public static final String SPECIAL_PROCESS_TYPE_NAV_COMP_CHART_PLUS = "04";
    public static final String LETTER_TEMPLATE_TYPE_GRACE_PERIOD = "GP001";
    public static final String REF_CUSTOM_FILTERLIST_FOR_CONSULTED = "refFilterCustomList";
    public static final String DECISION_OUTCOME_TYPE_CANCELLED = "4";
    public static final String SUBCATEGORY_TEMP_VALUE = "temp";
    public static final String CSP_FACETS_NEW = "A";
    public static final String CSP_FACETS_SENT_PREVIOUSLY = "R";
    public static final String LEGAL_ENTITY_TYPE1 = "55600";
    public static final String LEGAL_ENTITY_TYPE2 = "33600";
    public static final String BEHAVIORALACTIVITYTYPE = "behavioralActivityType";
    public static final String CARRIER_UHC = "UHC";
    public static final String CARRIER_UH = "UH";
    public static final String MEMBER_ID_TYPE_ALTERNATEID = "3";
    public static final String MEMBER_ID_TYPE_SUBSCRIBERID = "1";
    public static final int NEGOTIATEDRATEMAXVALUE = 999999;
    public static final String PROCEDURE_CODE_T2029 = "T2029";
    public static final String LEGACY_BENEFIT_PLAN_KANSAS_KSLTFEWD = "KSLTFEWD";
    public static final String LEGACY_BENEFIT_PLAN_KANSAS_KSLTFEWN = "KSLTFEWN";
    public static final String LEGACY_BENEFIT_PLAN_KANSAS_KSLTFEMD = "KSLTFEMD";
    public static final String LEGACY_BENEFIT_PLAN_KANSAS_KSLTFEMN = "KSLTFEMN";
    public static final String LEGACY_BENEFIT_PLAN_DELAWARE_DELTC = "DELTC";
    public static final String LEGACY_BENEFIT_PLAN_ID = "legacyBenefitPlanId";
    public static final int DOLLAR_CONFIRMATION_LEVEL = 50000;
    public static final String EMERGENTWRAP_MARKET_NUMBER = "8444444";
    public static final int NEGOTIATEDRATEMINVALUE =1;
    public static final String REPORT_CODE_LTC = "LTC";
    public static final String REPORT_CODE_LMBH = "LMBH";
    public static final String MMP_OH = "OHMMEP";
    public static final String MMP_TX = "TXMMP";
    public static final Set<String> LTC_REPORT_CODES = new HashSet<>(Arrays.asList(new String[] {REPORT_CODE_LMBH, REPORT_CODE_LTC}));

    //External Auth Error Queue
    public static final String SEARCHON_ENTRY_TYPE = "searchonEntryType";
    public static final String SEARCHON_ENTRY_TYPE_CLAIMPLATFORM = "ClaimPlatform";
    public static final String SEARCHON_ENTRY_TYPE_EVVSUBMISSION = "EVVSubmissionsNotSent";

    public static final String ERRORSEARCHSUFFIX = "errorSearchSuffix";

    //Fax Errors
    public static final String FAXFAILED_FAX_NUMBER_BLOCKED_BY_DIALING_RULE = "fax number blocked by dialing rule";
    public static final String FAXFAILED_PHONE_LINE_PROBLEMS = "phone line problems";
    public static final String FAXFAILED_BUSY = "busy";
    public static final String FAXFAILED_CONVERSION_ERROR = "conversion error - rare/system";
    public static final String FAXFAILED_HUMAN_ANSWERED = "human answered";
    public static final String FAXFAILED_UNABLE_TO_SCHEDULE = "unable to schedule - rare/system";
    public static final String FAXFAILED_NO_ANSWER = "no answer";
    public static final String CREATEUSERID = "createUserID";
    public static final String CREATEDATETIME = "createDateTime";

    public static final String DEFAULTTEXTNAMEPOPUP = "defaultTextNamePopUp";
    public static final String DEFAULTTEXTPOPUPLABEL = "defaultTextPopUpLabel";
    public static final String DEFAULTTEXTPOPUPDESC = "Click to select information to include in the Review Request";

    public static final String EDIT_AFTER_DECISION_PERMISSION = "AAA_CSP_FACETS_EDIT_AFTER_DECISION";
    public static final String MEDICALNECESSITY = "MedicalNecessity";
    public static final String UMDETERMINATION_A = "A";
    public static final String OBHENTRYTYPE = "obhEntryType";
    public static final String OBHREFERRALSOURCETYPE = "obhReferralSourceType";

}
