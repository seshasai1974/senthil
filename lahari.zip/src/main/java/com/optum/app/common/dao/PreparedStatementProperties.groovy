package com.optum.app.common.dao

class PreparedStatementProperties {
    List<PreparedStatementQueryProperties> whereClauseParams                  // used for generating a where clause - Key: Column, Value: Param
    List<PreparedStatementQueryProperties> havingClauseParams                 // used for generating a having clause - Key: Column, Value: Param
    LinkedHashMap<String, String> orderByColumns               // used for generating an orderby clause - linkedhashmap because order matters
}