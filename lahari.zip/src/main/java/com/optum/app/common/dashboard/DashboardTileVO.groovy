package com.optum.app.common.dashboard

import com.optum.rf.dao.data.ValueObject
import groovy.transform.CompileStatic

@CompileStatic
class DashboardTileVO extends ValueObject {

    /** Serialization Version ID compatibility - indication of what version may be restored.*/
    private static final long serialVersionUID = 1L

    int tileID              // tile_id
    String tileCategory     // tile_catgy       - DF for default tile
    int tilePosition        // tile_pstn        - will control position of defaults and available tile list
    String templateUrl      // template_url
    String title            // title
    String descriptiontext  // descriptiontext
    int tileWidth           // tile_wdth
}
