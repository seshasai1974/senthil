package com.optum.app.constants

import groovy.transform.CompileStatic

@CompileStatic
class ConductorConstants {
    public static final String CONDUCTOR_PINGFEDERATE_URL_REDIRECT_WITH_TOKEN = "conductorUrlRedirectWithToken";
    public static final String CONDUCTOR_SSO_USER_ID = "userId";
    public static final String CONDUCTOR_SSO_USER_FIRST = "firstName";
    public static final String CONDUCTOR_SSO_USER_LAST = "lastName";
    public static final String CONDUCTOR_SSO_USER_ROLE = "userRole";
    public static final String CONDUCTOR_SSO_USER_PERMISSION = "userPermission";
    public static final String CONDUCTOR_SSO_MEMBER = "member";
    public static final String CONDUCTOR_SSO_CONDUCTOR_REQUEST = "conductorRequest";
    public static final String CONDUCTOR_SSO_SRC_APPL_ID = "applicationId";
    public static final String CONDUCTOR_SSO_DELIMITER = "|";
    public static final String BLANK = "";
    public static final String CONDUCTOR_SSO_HYPHEN  = "-";
    public static final String CONDUCTOR_SSO_PERMISSION_READ_ONLY = "READ_ONLY";
    public static final String CONDUCTOR_SSO_PERMISSION_READ_WRITE = "READ_WRITE";

    // constants for the sso test harness
    public static final String USER_FIRST = "userFirst";
    public static final String USER_LAST = "userLast";
    public static final String SUBJECT_ATTRIBUTE = "sourceApplicationSubjectAttribute";

    // used on the jsps to define parameters
    public static final String UUID = 'uuid'
    public static final String OVERRIDE_UUID = 'overrideUuid'
    public static final String IS_FROM_DECISION_VIEW = 'isFromDecisionView'
}
