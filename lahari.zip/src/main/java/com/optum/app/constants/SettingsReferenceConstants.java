package com.optum.app.constants;

import com.optum.rf.ref.core.annotation.Reference;
import com.uhg.app.common.constants.spclcare.FieldConstants;

public class SettingsReferenceConstants {
    //***********************************************************************************************
    //* This section <b>should</b> contain constants pertaining to the reference table.
    //* All other constants should be either outside of this section or in the global constants class.
    //* Any new entries into this section, isValid the code by running the ReferenceConstantsValidation program.
    //***********************************************************************************************
    @Reference(name = FieldConstants.WSID)
    public static final String WSID_C3_ASMT = "C3Asmt";
    @Reference(name = FieldConstants.WSID)
    public static final String WSID_ASMT_TMPLT_RST = "AsmtTmpRst";
    @Reference(name = FieldConstants.WSID)
    public static final String WSID_ASMT_TMPLT_RST_V2 = "AsmtTmpv2";
    @Reference(name = FieldConstants.WSID)
    public static final String WSID_ASMT_TMPLT_RST_V3 = "AsmtTmpv3";
    @Reference(name = FieldConstants.WSID)
    public static final String WSID_ESSO_SERVICE = "eSSOSrvc";
    @Reference(name = FieldConstants.WORKMANAGERID)
    public static final String WORKMANAGERID_DEFAULT = "wm/default";
    @Reference(name = FieldConstants.PROVIDERWSID)
    public static final String PROVIDERWSID_MEMBERCONTACT_V1 = "CntcDtlV1";
    @Reference(name = FieldConstants.PROVIDERWSID)
    public static final String PROVIDERWSID_MBR_DTL_V1 = "MbrDtlV1";
    @Reference(name = FieldConstants.PINGFEDERATEPARTNERNAME)
    public static final String PINGFEDERATEPARTNERNAME_ACD = "ACD";
    @Reference(name = FieldConstants.WSID)
    public static final String WSID_CSP_MBR_CLM_DET = "CSPClmDtV1";
    @Reference(name = FieldConstants.WSID)
    public static final String WSID_OCM_MBR_DETAIL_V1_SRVC = "OCMMbrDtlV1";
    @Reference(name = FieldConstants.PROVIDERWSID)
    public static final String WSID_MEMBERDOCUMENT_V1 = "MbrDocV1";
    @Reference(name = FieldConstants.PROVIDERWSID)
    public static final String PROVIDERWSID_OFFL_MBR_V1 = "OfflMbrV1";
    @Reference(name = FieldConstants.WSID)
    public static final String C360_MBR_SEARCH = "C360MbrV6";
    @Reference(name = FieldConstants.PROVIDERWSID)
    public static final String OPTUM_PROVISION_V1 = "OptmPrvnV1";
    @Reference(name = FieldConstants.WSID)
    public static final String WSID_MBMWRKQ = "MbmWrkQ";
    @Reference(name = FieldConstants.WSID)
    public static final String WSID_DOCMGR_V2 = "docMgrV2";
    @Reference(name = FieldConstants.WSID)
    public static final String WSID_DOCMGR = "docMgr";
}
