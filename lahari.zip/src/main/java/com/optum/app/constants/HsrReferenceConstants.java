package com.optum.app.constants;


import com.uhg.app.common.constants.spclcare.FieldConstants;
import com.optum.rf.ref.core.annotation.Reference;

public final class HsrReferenceConstants extends CommonReferenceConstants {
    //***********************************************************************************************
    //* This section <b>should</b> contain constants pertaining to the reference table.
    //* All other constants should be either outside of this section or in the global constants class.
    //* Any new entries into this section, isValid the code by running the ReferenceConstantsValidation program.
    //***********************************************************************************************
    @Reference(name = FieldConstants.ENTITYTYPE)
    public static final String MEMBER_PROGRAM_ENTITY_TYPE = "2";
    @Reference(name = FieldConstants.PROVIDERROLE)
    public static final String PROVIDER_ROLE_ADMITTING = "AD";
    @Reference(name = FieldConstants.PROVIDERROLE)
    public static final String PROVIDER_ROLE_ATTENDING = "AT";
    @Reference(name = FieldConstants.PROVIDERROLE)
    public static final String PROVIDER_ROLE_FACILITY = "FA";
    @Reference(name = FieldConstants.PROVIDERROLE)
    public static final String PROVIDER_ROLE_PRIMARY_CARE_PROVIDER = "PC";
    @Reference(name = FieldConstants.PROVIDERROLE)
    public static final String PROVIDER_ROLE_REQUESTING = "RF";
    @Reference(name = FieldConstants.PROVIDERROLE)
    public static final String PROVIDER_ROLE_SERVICING = "SJ";
    @Reference(name = FieldConstants.PROVIDERROLE)
    public static final String PROVIDER_ROLE_SECOND_SURGICAL_OPINION = "SO";
    @Reference(name = FieldConstants.PROVIDERCATEGORY)
    public static final String PROVIDERCATEGORY_FACILITY = "H";
    @Reference(name = FieldConstants.PROVIDERCATEGORY)
    public static final String PROVIDERCATEGORY_PHYSICIAN = "P";
    @Reference(name = FieldConstants.PROVIDERCATEGORY)
    public static final String PROVIDERCATEGORY_ASSOCIATION = "A";
    @Reference(name = FieldConstants.ASSIGNMENTSTATUSTYPE)
    public static final String ASSIGNMENT_STATUS_TYPE_OPEN = "1";
    @Reference(name = FieldConstants.ASSIGNMENTSTATUSTYPE)
    public static final String ASSIGNMENT_STATUS_TYPE_CLOSED = "2";
    @Reference(name = FieldConstants.MEMBERIDTYPE)
    public static final String MEMBERIDTYPE_SUBSCRIBER_ID = "1";
    @Reference(name = FieldConstants.SERVICEDETAILTYPE)
    public static final String SERVICEDETAILTYPE_SUBSTANCE_USE_DISORDER = "33";
    @Reference(name = FieldConstants.SERVICEDETAILTYPE)
    public static final String SERVICEDETAILTYPE_MENTAL_HEALTH = "6";
    @Reference(name = FieldConstants.ADDRESSTYPE)
    public static final String ADDRESSTYPE_PRIMARY = "1";
    @Reference(name = FieldConstants.ADDRESSTYPE)
    public static final String ADDRESSTYPE_PRIMARY_ALT = "2";
}
