package com.optum.app.constants

class HscConstants {

    public static final short UNDEFINED_INT = -1
    public static final int MAX_FAC_SERVICE_LINES = 14
    public static final int MAX_PHS_FAC_SERVICE_LINES = 49
    public static final int MAX_OP_SERVICE_LINES = 15
    public static final int MAX_PHS_OP_SERVICE_LINES = 50
    public static final int MIN_OP_SERVICE_LINES = 1
    public static final String PROCEDURECODE_T1000 = "T1000"
    public static final String HSCSERVICE_SUFFIX = "SRVC"
    public static final String YES = "Yes"
    public static final String NO = "No"
    public static final String TRUE = "true"
    public static final String FALSE = "false"
    public static final int LENGTH_OF_GLOBALID = 16
    public static final int LENGTH_OF_VENDORCASEID_LB = 10
    public static final int LENGTH_OF_VENDORCASEID_UB = 50
    public static final int VALIDITYCHECK_MINIMUM_YEAR = 2003
    public static final String PRIMARY_DIAGNOSIS = "Primary"
    public static final String ADMITTING_DIAGNOSIS = "Admitting"
    public static final String SECONDARY_DIAGNOSIS = "Secondary"
    public static final int NUMBER_OF_DAYS_FOR_NICU_ADMISSION = 366
    public static final String PRODUCT_CODE_TYPE_IS_MEDICAID = "1"
    public static final String LINE_OF_BUSINESS_IS_UHC = "12"
    public static final String POLICY_ISSUE_STATE_CODE_State_PENNSYLVANIA = "PA"
    public static final String PLACESERVICE_OF_TYPE_ACUTEHOSPITAL = "21"
    public static final String SERVICE_DETAIL_OF_TYPE_NICU = "19"
    public static final int XML_INDENT = 4
    public static final String BENEFIT_LEVEL_CODE_COSMOS_DETERMINED = "00"
    public static final String DIVID = "divID"

    enum HscIDTypeEnum {
        SERVICE_REF_NUM,
        HSC_ID,
        GLOBAL_ID,
        VENDOR_CASE_ID,
        CC_VENDOR_CASE_ID,
        HSC_ALTERNATE_ID,
        UNKNOWN
    }

//    public static final String HSC_ALT_ID_NEWMEXICO_REGEX = "U[A-Z][A-Z0-9]{8}\\d{2}"

    public static final String NEGOTIATEDRATE = "uiNegotiatedRate"

    //HscUpdateConstants
    public static final String NOTE_BEGIN_TEXT = 'The following document(s) have been submitted for this case electronically from OCM: '
    public static final String NOTE_END_TEXT = "\nTo view, click on \'View Oncology Clinical Information\' on the member's case."
    public static final String LOG_LEVEL = 'DEBUG'
    public static final String NOTE_CATEGORY_TYPE = '102'

    //HscControllerConstants
    public static final String HSC_CONTROLLER_SOC_PROVIDER_FEATURE_FLAG_DISABLED_TEXT = 'HscController: Enable Servicing Provider Site Of Care Exception Feature Flag Disabled.'
    public static final String HSC_HELPER_IMPL_SOC_PROVIDER_FEATURE_FLAG_DISABLED_TEXT = 'HscHelperImpl: Enable Servicing Provider Site Of Care Exception Feature Flag Disabled.'
    public static final String SERVICING_PROVIDER_SITE_OF_CARE_DRUG_LIST_GROUP_ID = 'providerSocDrugList'
    public static final String MSE_DRUG_LIST_GROUP_ID = 'limitedSupplierDrugList'

    //HscAttributeConstants
    public static final String BACKDATED_NO = '0'
    public static final String BACKDATED_YES = '1'
}
