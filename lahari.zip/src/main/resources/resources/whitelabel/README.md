## WhiteLabeling JSON files

As a temporal measure we are using JSON files to store whiteLabel values. Once a persistence is configured we should expose APIs that validate and modify whiteLabes at runtime.

### Customer and Organization WhiteLabels

The whiteLabels for each customer can be defined at organization level and at customer level.
The customer level values override the organization values for that customer.

This model allows us to define a single configuration at an organization level and only create customer whiteLabel files if a customer needs to be different from the organization baseline.

We need at least one of this configuration files to be present at either org or customer level to respond a customer request successfully

Organization files are saved as <organization-name>.json at:

`/mbm-spcl-care-core/src/main/resources/resources/whitelabel/organization`

Customer files are saved as <customer-name>.json at:

`/mbm-spcl-care-core/src/main/resources/resources/whitelabel/customer/`

### Forbidden Words

Forbidden words is a json file with an array that lists words that shouldn't appear in a customer's configuration (at any level)

Forbidden words files are optional, and so far we have only included for BCBS as we have contractual obligations with them.

Organization forbidden words files are saved as <organization-name>.json at:
`/mbm-spcl-care-core/src/main/resources/resources/whitelabel/organization-forbidden-values`

Customer Forbidden words are saved as <customer-name>.json at:
`/mbm-spcl-care-core/src/main/resources/resources/whitelabel/customer-forbidden-values`

