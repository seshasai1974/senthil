INSERT INTO 
	TBL_EMPLOYEES (first_name, last_name, email) 
VALUES
  	('Ritiesh', 'USA', 'ritiesh@gmail.com'),
  	('Sai', 'Venkat', 'sai@email.com'),
  	('Rajni', 'Kath', 'rajnikanth@email.com');