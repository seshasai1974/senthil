package com.springboot.examples.jpa.springjpahibernateexample.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springboot.examples.jpa.springjpahibernateexample.model.UsersContact;

public interface UsersContactRepository extends JpaRepository<UsersContact, Integer> {
}
