package dre.spring.batch.acccount.mapper;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;

import dre.spring.batch.acccount.dto.AccountDTO;

public class AccountNumberRowMapper implements FieldSetMapper<AccountDTO> {

    @Override
    public AccountDTO mapFieldSet(FieldSet fieldSet) {
        AccountDTO account = new AccountDTO();
        account.setAccountId(fieldSet.readString("accountId"));

        System.out.println(account.getAccountId());
        return account;
    }

}
