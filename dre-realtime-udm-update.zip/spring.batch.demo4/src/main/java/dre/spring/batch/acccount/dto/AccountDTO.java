package dre.spring.batch.acccount.dto;

import lombok.Data;

@Data
public class AccountDTO {

    private String accountId;

}
