package dre.spring.batch.acccount.processor;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

import dre.spring.batch.acccount.dto.AccountDTO;
import dre.spring.batch.acccount.model.Account;

import java.util.Random;

@Component
public class AccountNumberProcessor implements ItemProcessor<AccountDTO, Account> {

    @Override
    public Account process(AccountDTO accountDTO) throws Exception {
        Account account = new Account();
        account.setEmployeeId(accountDTO.getAccountId()+new Random().nextInt(10000000));
        return account;
    }
}
