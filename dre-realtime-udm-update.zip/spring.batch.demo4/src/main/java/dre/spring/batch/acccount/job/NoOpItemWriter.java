package dre.spring.batch.acccount.job;

import java.util.List;

import org.springframework.batch.item.ItemWriter;

public class NoOpItemWriter implements ItemWriter {
  public void write(List items) throws java.lang.Exception {
    // no-op
  }
}