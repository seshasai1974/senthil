package dre.spring.batch.acccount;

import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@EnableBatchProcessing
@ComponentScan(basePackages = {"dre.spring.batch.acccount"})

public class SpringBatchAccountReaderApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBatchAccountReaderApplication.class, args);
	}

}
